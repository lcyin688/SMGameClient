import { HallViewId } from '../view/HallViewId';

const textureDyn = 'hall/dyn/texture/';
const prefabDyn = 'hall/dyn/prefab/';
const audioDyn = 'hall/dyn/audio/';
const aniDyn = 'hall/dyn/animation/';
const fontSta = 'hall/sta/font/';
const langfontDyn = 'hall/dyn/langfont/';
const ctryresDyn = 'hall/dyn/ctryres/';
const prefabSta = 'hall/sta/prefab/';

/** 资源配置 */
export const HallRes = {
    animation: {
        /** 金币动画 */
        coinAnim: aniDyn + 'coinAnim/hw_coin_fly',
        /** 手指动画 */
        finger: aniDyn + 'guide/click_an',
    },

    audio: {
        /** 金币飞行结束音效 */
        ding: audioDyn + 'ding',
        /** 金币滚动音效 */
        addCoinsEfc: audioDyn + 'addCoinsEfc',
        /** 一键领取界面音效 */
        award: audioDyn + 'award/award',
    },

    langfont: {
        /** 游戏入口美术字 */
        preloadLangfont: langfontDyn + '{0}/hall',
    },

    langtexture: {},

    prefab: {
        /** 大厅中间UI */
        HallGames: prefabSta + 'HallGames',
        /** hall banner */
        hall_banner: prefabSta + 'HallBannerArea',
        /** 主界面的下拉菜单 */
        hallMenuDropdown: prefabSta + 'HallMenuDropdown',
        /** 游戏搜索 */
        HallSearchGame: prefabDyn + 'hall/HallSearchGame',
        /** 活动菜单 */
        ActivityMenu: prefabDyn + 'hall/ActivityMenu',
        // -----------------------------------大厅周边----------------------------------------
        DailyRechargeRewardEntry: prefabDyn + 'hall/entry/DailyRechargeRewardEntry',
        /** 独立日活动入口 */
        IndependentEntry: prefabDyn + 'hall/entry/IndependentEntry',
        /** 提现入口 */
        withdrawEntry: prefabDyn + 'hall/entry/WithdrawEntry',
        /** 开斋节入口 */
        CarnivalEntry: prefabDyn + 'hall/entry/CarnivalEntry',
        /** 落地页包赠送奖励入口 */
        OfficialPkgAwardEntry: prefabDyn + 'hall/entry/OfficialPkgAwardEntry',
        /** 加入官方频道入口 */
        JoinUsEntry: prefabDyn + 'hall/entry/JoinUsEntry',
        /** 转盘活动：入口 */
        TurntableEntry: prefabDyn + 'hall/entry/TurntableEntry',
        /** 周卡入口 */
        WeekCardEntry: prefabDyn + 'hall/entry/WeekCardEntry',
        /** 救援金入口 */
        RescueFundsEntry: prefabDyn + 'hall/entry/RescueFundsEntry',
        /** 每日金币入口 */
        DailyAwardEntry: prefabDyn + 'hall/entry/DailyAwardEntry',
        /** 问卷调查入口按钮 */
        QuestionNaireEntry: prefabDyn + 'hall/entry/QuestionNaireEntry',
        /** 安全绑定入口 */
        SafeEntry: prefabDyn + 'hall/entry/SafeEntry',
        /** 新手礼包入口按钮*/
        NewbieGiftBagEntry: prefabDyn + 'hall/entry/NewbieGiftBagEntry',
        /** 银行入口按钮*/
        BankEntry: prefabDyn + 'hall/entry/BankEntry',
        /** vip入口按钮*/
        VIPEntry: prefabDyn + 'hall/entry/VIPEntry',
        /** 30日签到，按天计算 */
        MonthSignEntry: prefabDyn + 'hall/entry/MonthSignEntry',
        /** 30日签到，按次数计算 */
        MonthSign2Entry: prefabDyn + 'hall/entry/MonthSign2Entry',
        /** 七日福利 */
        SevenDayEntry: prefabDyn + 'hall/entry/SevenDayEntry',
        /** 兑换码入口 */
        RedeemCodeEntry: prefabDyn + 'hall/entry/RedeemCodeEntry',

        /** 签到 */
        ActivityDailyAward: prefabDyn + 'activity/dailyaward/ActivityDailyAward',
        /** 代理活动 */
        ActivityAgent: prefabDyn + 'activity/agent/ActivityAgent',
        /** 笔笔送活动 */
        ActivityPenPenDelivery: prefabDyn + 'activity/penPenDelivery/ActivityPenPenDelivery',
        /** 提现活动 */
        ActivityWithdrawal: prefabDyn + 'activity/withdrawal/ActivityWithdrawal',
        /** 账号绑定 */
        ActivityAccountSafe: prefabDyn + 'activity/accountSafe/ActivityAccountSafe',
        /** 通用图片 */
        ActivityCommonPreview: prefabDyn + 'activity/ActivityCommonPreview',

        /** 商城，充值 */
        shop: prefabDyn + 'recharge/StoreDialog',
        /** 活动，事件中心 */
        event: prefabDyn + 'activity/ActivityDialog',
        /** 个人中心 */
        profile: prefabDyn + 'userCenter/UserCenterView',
        /** 加入我们 */
        joinUsWay: prefabDyn + 'joinus/JoinUsWay',
        /** 个人返利 游戏类型Item */
        RebateGroupItem: prefabDyn + 'rebateCode/RebateGroupItem',
        /** 个人返利 vip返利详情Item */
        rebateRatioDetailItem: prefabDyn + 'rebateCode/RebateRatioDetailItem',
        rebateBoxItem: prefabDyn + 'rebateCode/RebateBoxItem',

        userCenter: {
            AvatarItem: prefabDyn + 'userCenter/UserCenterSelectAvatarItem',
            LangSelectItem: prefabDyn + 'userCenter/UserCenterLangSelectItem',
        },
        /** 邮件 */
        mail: {
            contentItm: prefabDyn + 'mail/MailContent',
            item: prefabDyn + 'mail/MailItem',
        },
        /** 狂欢活动 */
        carnival: {
            mainItem: prefabDyn + 'carnival/CarnivalMainContent',
        },
        /** 救援金 */
        rescueFunds: {
            RescueFundsItem: prefabDyn + 'rescueFunds/RescueFundsItem',
            RescueFundsRuleItem: prefabDyn + 'rescueFunds/RescueFundsRuleItem',
        },
        /** 提现 */
        withdraw: {
            main: prefabDyn + 'withdraw/Withdraw',
            broadcast: prefabDyn + 'withdraw/WithdrawBroadcast',
        },
        /** ct4 跑马灯 */
        marquee: prefabDyn + 'marquee/Marquee',
        /** cm4 跑马灯 */
        marqueePop: prefabDyn + 'marquee/MarqueePop',
        /** 代理 */
        agent: {
            /** 代理：邀请返利 */
            AgentInviteRebate: prefabDyn + 'agent/AgentInviteRebate',
            /** 代理：邀请奖励 */
            AgentInviteReward: prefabDyn + 'agent/AgentInviteReward',
            /** 代理：打码返利 */
            AgentCodeRebate: prefabDyn + 'agent/AgentCodeRebate',
            /** 代理：充值返利 */
            AgentRechargeRebate: prefabDyn + 'agent/AgentRechargeRebate',
            /** 代理：人数奖励 */
            AgentQuantityReward: prefabDyn + 'agent/AgentQuantityReward',
            /** 代理：详情列表 */
            AgentDetailsList: prefabDyn + 'agent/prop/AgentDetailsList',
        },
        /** 转盘 */
        turntable: {
            TurntableItem: prefabDyn + 'turntable/TurntableItem',
            TurntableRecordItem: prefabDyn + 'turntable/TurntableRecordItem',
        },
        /** 新手礼包弹窗 */
        newbieGiftBag: prefabDyn + 'recharge/newbieGiftBag/NewbieGiftBagDlg',
        /** 新手引导 */
        ForceGuideDlg: prefabDyn + 'newbieGuide/ForceGuideDlg',

        /** 签到 */
        MonthSignAwardItem: prefabDyn + 'monthSign/MonthSignAwardItem',
        /** 签到2 */
        MonthSign2AwardItem: prefabDyn + 'monthSign2/MonthSign2AwardItem',
        vip: {
            /** vip 进度条标识 */
            VipBarItem: prefabDyn + 'vipinfo/VipBarItem',
            /** vip 奖励项 */
            VipRightsItem: prefabDyn + 'vipinfo/VipRightsItem',
            /** vip 奖励规则项 */
            VipRightsRowItem: prefabDyn + 'vipinfo/VipRightsRowItem',
            /** VIP等级图标 */
            VipToggleItem: prefabDyn + 'vipinfo/VipToggleItem',
        },
    },

    texture: {
        /** 支付类型 */
        payTypeIcon: textureDyn + 'recharge/payTypeIcon/pay_type_',
        /** 支付类型小 */
        payTypeIconSmall: textureDyn + 'recharge/payTypeIcon/icon_',
        /** 支付类型标题 */
        guide_type: textureDyn + 'recharge/guide/guide_type_',
        /** 提现渠道/充值银行 icon */
        channelCode: textureDyn + 'channelCode/',
        /** VIP Logo标志 */
        VIP_Logo_icon: textureDyn + 'vipIcon/vip_lv_',
        /** VIP 等级图标*/
        VIP_Lv_icon: textureDyn + 'vipLv/VIP',
        /** vip 奖励类型 icon */
        vip_award_type_icon: textureDyn + 'vipInfo/vip_rights_icon_',
        /** 返利游戏类型icon */
        gameTypeIcon: textureDyn + 'rebatecode/',
        // 引导
        select_frame1: textureDyn + 'newbieGuide/select_frame1',
        text_bg2: textureDyn + 'newbieGuide/text_bg2',

        /** 道具Icon */
        prop_item_icon: textureDyn + 'propItem/',
        /** 炮台 vip icon */
        prop_equip_big_: textureDyn + 'propItem/equip_big_',
        prop_face_big_: textureDyn + 'propItem/face_big_',
    },

    /**
     * ‼️ 地区差异资源配置，只能增加，不能删除，不能调整顺序，prefab 依赖调用顺序
     * ‼️ 能动态复制的，优先动态赋值
     */
    ctryres: {
        get hallBg() {
            return we.core.assetMgr.getCountryAssetUrl(ctryresDyn + 'id/bg/bg_hall');
        },
        roleBg: ctryresDyn + 'id/role/img_role',
        /** 主大厅界面游戏入口动画 */
        gameEnter: ctryresDyn + 'id/gameEnter/{0}/game_icon',
    },

    /** 预加载资源配置 */
    preload: {
        /** prefab 资源配置 */
        prefab: [
            { priority: 6, type: cc.Prefab, path: HallViewId.TurntableDlg },
            { priority: 6, type: cc.Prefab, path: HallViewId.MonthSignDlg },
            { priority: 6, type: cc.Prefab, path: HallViewId.MonthSign2Dlg },
            { priority: 6, type: cc.Prefab, path: HallViewId.DailyRechargeRewardDlg },
            { priority: 5, type: cc.Prefab, path: HallViewId.NewbieGiveDlg },
            { priority: 5, type: cc.Prefab, path: HallViewId.GetSingPropDlg },
            { priority: 5, type: cc.Prefab, path: HallViewId.ActivityDlg, noLog: true },
            { priority: 5, type: cc.Prefab, path: prefabDyn + 'activity/ActivityDialog', noLog: true },
            { priority: 4, type: cc.Prefab, path: HallViewId.IndependentDlg },
            { priority: 4, type: cc.Prefab, path: HallViewId.CarnivalDlg },
            { priority: 4, type: cc.Prefab, path: HallViewId.RebateCodeDlg },
            { priority: 4, type: cc.Prefab, path: HallViewId.MailDlg },
            { priority: 4, type: cc.Prefab, path: HallViewId.AgentDlg },
            { priority: 3, type: cc.Prefab, path: HallViewId.MemberCenterDlg },
            { priority: 3, type: cc.Prefab, path: HallViewId.DownLoadGuideDlg },
            { priority: 3, type: cc.Prefab, path: prefabDyn + 'marquee/Marquee', noLog: true },
            { priority: 3, type: cc.Prefab, path: prefabDyn + 'marquee/MarqueePop', noLog: true },
            { priority: 2, type: cc.Prefab, path: HallViewId.ForceGuideDlg },
            { priority: 2, type: cc.Prefab, path: HallViewId.WithdrawDlg, noLog: true },
            { priority: 2, type: cc.Prefab, path: HallViewId.StoreDlg, noLog: true },
            { priority: 2, type: cc.Prefab, path: HallViewId.BankDlg },
            { priority: 2, type: cc.Prefab, path: HallViewId.ActivityGiftCodeDlg },
            { priority: 2, type: cc.Prefab, path: HallViewId.VipViewDlg },
            { priority: 1, type: cc.Prefab, path: HallViewId.JoinUsDlg },
            { priority: 1, type: cc.Prefab, path: HallViewId.PhoneBindScreenshotPromptDlg },
            { priority: 1, type: cc.Prefab, path: HallViewId.AppPermissionDlg },
            { priority: 1, type: cc.Prefab, path: HallViewId.OfficialPkgAwardDlg },
            { priority: 1, type: cc.Prefab, path: HallViewId.UserCenterDlg },
        ],
    },
};
