import { HallLanguage } from './const/HallLanguage';
import HallGameListMgr from './manager/HallGameListMgr';
import HallJPRollMgr from './manager/HallJPRollMgr';
import JumpModMgr from './manager/JumpModMgr';
import { HallViewId } from './view/HallViewId';
import { HallPageEnum } from './const/HallConst';
import HallMgr from './manager/HallMgr';
import NewbieGuideMgr from './manager/NewbieGuideMgr';
import MonthSign from './manager/MonthSignMgr';
import { HallRes } from './config/HallRes';
import WeekCardMgr from './manager/WeekCardMgr';
import SevenDayMgr from './manager/SevenDayMgr';
import { HallModel } from './model/HallModel';
import { EnterGameFlow } from './task/entergame/EnterGameFlow';
import { RechargeGuideTask } from './task/RechargeGuideTask';
import { HallPopupMgr } from './manager/HallPopupMgr';

/**
 * 进入大厅
 */
@we.decorator.eventInvoke(we.core.eventInvoke.SceneEnter, we.GameId.HALL)
export class HallSceneEnter extends we.core.AInvokeHandler<we.core.eventInvoke.SceneEnter, void> {
    async handle(args: we.core.eventInvoke.SceneEnter): Promise<void> {
        await args.current.addComponentAsync(HallScene);
        await args.loadingShowFinish();
    }
}

/**
 * 离开大厅
 */
@we.decorator.eventInvoke(we.core.eventInvoke.SceneLeave, we.GameId.HALL)
export class HallSceneLeave extends we.core.AInvokeHandler<we.core.eventInvoke.SceneLeave, void> {
    async handle(args: we.core.eventInvoke.SceneLeave): Promise<void> {
        we.clientScene.getComponent(we.common.GameEventTask)?.brokenTask();
        args.current.removeComponent(HallPopupMgr);
    }
}

@we.decorator.typeRegister('HallScene', we.bundles.hall)
export class HallScene extends we.core.Entity {
    protected async awakeAsync() {
        this.Scene.addComponent(HallModel);
        this.Scene.addComponent(EnterGameFlow);
        this.Scene.addComponent(HallPopupMgr);

        this.setGlobal();

        we.clientScene.getComponent(we.common.GameEventTask)?.registerExecutor(we.common.type.GameEvent.Recharge, RechargeGuideTask);

        we.core.nativeUtil.setScreenOrientation(we.core.flavor.getSkinOrientation());
        JumpModMgr.init();

        this.initData();

        cc.director.on(we.common.EventName.AWARD_RECHARGE_SUC_DLG, this.onOpenRechargeSuc, this);
        cc.director.on(we.common.EventName.AWARD_RECEIVE_SUC_DLG, this.onOpenReceiveAwardDlg, this);
        cc.director.on(we.common.EventName.OPEN_DOWNLOAD_GUIDE, this.onDownloadGuideDlg, this);
        cc.director.on(we.common.EventName.OPEN_DOWNLOAD_USER_INFO_GUIDE, this.onDownloadGuideUserInfoDlg, this);
        cc.director.on(we.common.EventName.NAMING_ALTER_PUSH_MSG_HANDLE, this.onNamingAlterPushMsg, this);
        cc.director.on(we.common.EventName.NAMING_JACKPOT_PUSH_MSG_HANDLE, this.onNamingJackpotPushMsg, this);
        cc.director.on(we.common.EventName.OPEN_USER_REAl_NAME_DLG, this.onOpenUserRealNameDlg, this);

        this.registerI18n();

        await we.core.assetMgr.loadAsset(HallRes.ctryres.hallBg, cc.SpriteFrame, this);
        await we.currentUI.show(HallViewId.HallDlg, HallPageEnum.games);

        this.checkPWAInstall();

        this.preloadAsset().finally(() => {
            if (!CC_DEV) {
                this.Scene?.addComponentAsync(we.common.BundlePreloadTask, we.common.res.gameComBundles);
            }
        });
    }

    protected destroy(): void {
        cc.director.off(we.common.EventName.AWARD_RECHARGE_SUC_DLG, this.onOpenRechargeSuc, this);
        cc.director.off(we.common.EventName.AWARD_RECEIVE_SUC_DLG, this.onOpenReceiveAwardDlg, this);
        cc.director.off(we.common.EventName.OPEN_DOWNLOAD_GUIDE, this.onDownloadGuideDlg, this);
        cc.director.off(we.common.EventName.OPEN_DOWNLOAD_USER_INFO_GUIDE, this.onDownloadGuideUserInfoDlg, this);
        cc.director.off(we.common.EventName.NAMING_ALTER_PUSH_MSG_HANDLE, this.onNamingAlterPushMsg, this);
        cc.director.off(we.common.EventName.NAMING_JACKPOT_PUSH_MSG_HANDLE, this.onNamingJackpotPushMsg, this);
        cc.director.off(we.common.EventName.OPEN_USER_REAl_NAME_DLG, this.onOpenUserRealNameDlg, this);
    }

    /** 注册多语言 */
    protected registerI18n(): void {
        we.clientScene.getComponent(we.ui.I18nData).lang = {
            ...we.launcher.lang,
            ...we.common.lang,
            ...HallLanguage,
        };
    }

    /**
     * 设置 clientScene 全局属性
     */
    private setGlobal() {
        we.core.SceneHelper.setSceneInfo({ bigBgUrl: we.launcher.res.ctryres.bigBg });
    }

    private onOpenRechargeSuc(coins: number, type?: string): void {
        HallMgr.openChargeSucceedDlg(coins, type);
    }

    private onOpenReceiveAwardDlg(award: { id: number; num: number }[] | { [k: string]: number }, closeCallback?: Function): void {
        HallMgr.openGetAwardsDlg(award, closeCallback);
    }

    private onDownloadGuideDlg(): void {
        HallMgr.openDownloadGuideDlg();
    }

    private onDownloadGuideUserInfoDlg(): void {
        we.currentUI.show(HallViewId.DownLoadGuideUserInfoDlg);
    }

    private onNamingAlterPushMsg(data: naming.UserAlertNT): void {
        HallMgr.handleNamingAlterPushMsg(data);
    }

    private onNamingJackpotPushMsg(data: naming.JackpotNT): void {
        HallJPRollMgr.updateJPData(data);
    }

    private onOpenUserRealNameDlg(): void {
        we.currentUI.show(HallViewId.UserCenterRealNameDlg);
    }

    private initData(): void {
        if (we.common.userMgr.isShowGiveDialog) {
            // 是新号并初始金币 > 0，才能触发新手赠送金币弹窗
            we.common.userMgr.isShowGiveDialog = we.common.userMgr.userInfo.gold > 0;
        }

        we.common.withdrawMgr.getBankWithdrawConf();
        we.common.payMgr.processUncompleteTransaction();
        we.common.agentMgr.init();
        we.common.gameMgr.getGameEnterLimitConf();
        we.common.marqueeMgr.init();

        let sceneFrom = we.core.gameConfig.getSceneFrom();
        switch (sceneFrom) {
            case we.SceneFrom.Launcher:
                NewbieGuideMgr.reset();
                MonthSign.month.init();
                MonthSign.month2.init();
                HallJPRollMgr.init();
                WeekCardMgr.init();
                break;
            case we.SceneFrom.Game:
                we.common.namingServiceMgr.sendActionNTReq(we.common.NamingActionNType.RETURN_LOBBY_FROM_Game);
                // 同步服务器时间
                we.core.TimeInfo.Inst.syncServerTime(we.launcher?.maintainMgr?.getServerTimestamp);

                we.common.userMgr.onSyncUserCoinInfo();
                we.common.carnivalMgr.getActivityInfo();
                we.common.independentMgr.getActivityInfo();
                we.common.bankMgr.clearLock();
                we.common.bankMgr.clearRecordData();
                we.common.bankMgr.getBankConf();
                we.common.rescueFundsMgr.clearLock();
                we.common.rescueFundsMgr.getUserApplyList();
                break;
            default:
                break;
        }

        we.common.mailMgr?.init();
        HallGameListMgr.init();
        NewbieGuideMgr.init();
        SevenDayMgr.instance.init();

        // 初始化客服红点数据
        let isNewMsg = we.common.storage.get('common', 'customer');
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.server, isNewMsg ? 1 : 0, true);
    }

    /**
     * 检测是否需要安装 PWA 或安装提示引导
     * @returns
     */
    private checkPWAInstall(): void {
        let isOpenPWA = we.core.projectConfig.settingsConfig?.isPwa;
        if (!isOpenPWA) {
            return;
        }

        // 仅登录界面进入大厅触发
        let sceneFrom = we.core.gameConfig.getSceneFrom();
        if (sceneFrom != we.SceneFrom.Launcher) {
            return;
        }

        if (cc.sys.isBrowser && !we.core.nativeUtil.isPlatformLand()) {
            // 无可安装标识，不执行 PWA 自动安装逻辑
            let pwaTag = we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.pwa);
            if (!pwaTag) {
                return;
            }

            // 处理 PWA 自动安装事件
            let pwaInstallSt = we.core.h5PWA.getInstallStatus();
            switch (pwaInstallSt) {
                case we.core.PWAInstallStatus.Installed:
                    break;
                case we.core.PWAInstallStatus.Installable:
                    {
                        let immediatelyInstall = we.common.utils.compareUrlHostname(window.location.href, we.core.projectConfig.settingsConfig.pwaUrl);
                        if (immediatelyInstall) {
                            we.commonUI.showConfirm({
                                isHideCloseBtn: false,
                                content: we.core.langMgr.getLangText(we.common.lang.PWA_101),
                                yesButtonName: we.core.langMgr.getLangText(we.common.lang.PWA_105),
                                yesHandler: we.core.Func.create(() => {
                                    we.core.h5PWA.install();
                                }, this),
                                priority: we.ui.type.PopupPriority.System,
                            });
                        } else {
                            HallMgr.openPWAInstall();
                        }
                    }
                    break;
                case we.core.PWAInstallStatus.NotInstallable:
                    break;
                case we.core.PWAInstallStatus.NotInstallableNonChrome:
                    HallMgr.openPWAInstall();
                    break;
                case we.core.PWAInstallStatus.NotInstallableIos:
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 预加载资源
     */
    private async preloadAsset() {
        let cfg: we.core.AssetPreloadConfig = [];

        // 预加载强弹弹窗
        const popQueue = HallPopupMgr.Inst.getAppLauncherPopList()
            .filter((item) => {
                return item.res && item.isOpen;
            })
            .map((obj) => {
                return { priority: 9, type: cc.Prefab, path: obj.res };
            });
        if (popQueue.length > 0) {
            cfg = cfg.concat(popQueue);
        }

        // 预加载 大厅入口美术字目录资源，需在必弹窗之后优先加载
        const pathFont = we.core.utils.stringFormat(HallRes.langfont.preloadLangfont, we.core.langMgr.getCurLangCode());
        cfg.push({ priority: 8, path: pathFont, noLog: true });

        // 预加载预设列表
        cfg = cfg.concat(HallRes.preload.prefab);

        // 根据配置预加载资源
        we.currentUI.addComponent(we.core.AssetPreloadTask, cfg);
    }
}
