import { LineConversionTipTask } from './LineConversionTipTask';
import { OngoingGameTask } from './OngoingGameTask';
import { RunGameTask } from './RunGameTask';

export interface EnterGameContext {
    gameId: we.GameId;
}

@we.decorator.typeSingleton('EnterGameFlow')
export class EnterGameFlow extends we.core.Entity {
    static Inst: EnterGameFlow;

    private pipeline: we.core.TaskPipeline<EnterGameContext>;
    protected awake() {
        this.pipeline = new we.core.TaskPipeline();
    }

    protected destroy(): void {
        this.pipeline.reset();
        EnterGameFlow.Inst = null;
    }

    async run(gameId: we.GameId) {
        if (null == gameId || !we.core.gameConfig.isSubGame(gameId)) {
            return;
        }

        if (this.pipeline.isRunning()) {
            return;
        }

        this.pipeline.setCtx({ gameId });
        // 配置进入游戏的一些任务
        this.pipeline.addTask(new OngoingGameTask(this.pipeline));
        if (we.core.gameConfig.isApiSubGame(gameId)) {
            this.pipeline.addTask(new LineConversionTipTask(this.pipeline));
        }
        this.pipeline.addTask(new RunGameTask(this.pipeline));

        await this.pipeline.start().finally(() => {
            this.pipeline.reset();
        });
    }
}
