import HallMgr from '../../manager/HallMgr';
import { EnterGameContext } from './EnterGameFlow';

/**
 * 进行中的游戏
 */
export class OngoingGameTask<T extends EnterGameContext, R extends { onGoingGame: we.IOngoingGameResp }> extends we.core.pipeline.IExecutor<T, R> {
    async execute(ctx: T, signal: AbortSignal, taskCtx: R) {
        we.common.commonMgr.unfinishedGameDialog(+taskCtx.onGoingGame.ongoingGame, taskCtx.onGoingGame.roomIndex);
        throw new Error(`OngoingGameTask execute, unfinishedGameDialog ongoingGame:${taskCtx.onGoingGame.ongoingGame}`);
    }
    config(): we.core.pipeline.TaskConfig<T, R> {
        return {
            ctx: { onGoingGame: null } as R,
            mode: we.core.pipeline.TaskMode.Abort,
            condition: async (ctx: T, taskCtx?: R) => {
                return await this.condition(ctx, taskCtx);
            },
        };
    }

    private async condition(ctx: T, taskCtx: R): Promise<boolean> {
        if (we.core.gameConfig.curGameId !== we.GameId.HALL) {
            return false;
        }

        return new Promise((resolve) => {
            HallMgr.getOngoingGame(
                (data: we.IOngoingGameResp) => {
                    let ongoingGame = +we.common.gameMgr.unfinishedGame.ongoingGame;
                    if (ctx.gameId === ongoingGame) {
                        resolve(false);
                        return;
                    }
                    if (we.core.gameConfig.isSubGame(ongoingGame)) {
                        taskCtx.onGoingGame = data;
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                },
                null,
                true,
                false
            );
        });
    }
}
