import HallMgr from '../../manager/HallMgr';
import { EnterGameContext } from './EnterGameFlow';

/**
 * 启动游戏
 */
export class RunGameTask<T extends EnterGameContext, R extends { onGoingGame: we.IOngoingGameResp }> extends we.core.pipeline.IExecutor<T, R> {
    async execute(ctx: T, signal: AbortSignal, taskCtx?: R) {
        if (!HallMgr.canEnterSubGame(ctx.gameId)) {
            return;
        }
        we.common.gameMgr.runGame(ctx.gameId);
    }
    config(): we.core.pipeline.TaskConfig<T, R> {
        return {
            mode: we.core.pipeline.TaskMode.Abort,
        };
    }
}
