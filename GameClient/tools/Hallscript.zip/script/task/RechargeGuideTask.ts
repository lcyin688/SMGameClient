import { HallPopupMgr } from '../manager/HallPopupMgr';

/**
 * 启动游戏
 */
export class RechargeGuideTask<T extends {}, R extends { onGoingGame: we.IOngoingGameResp }> extends we.core.pipeline.IExecutor<T, R> {
    /**
     * 充值引导任务
     * @param ctx 管线上下文
     * @param signal 中断 signal
     * @returns
     */
    async execute(ctx: T, signal: AbortSignal, taskCtx: R) {
        if (signal.aborted) {
            return;
        }

        await new Promise((resolve) => {
            HallPopupMgr.Inst.insertBackHallPopup(we.common.JumpCmd.Recharge);
            resolve(null);
        });
    }
    config(): we.core.pipeline.TaskConfig<T, R> {
        return {
            mode: we.core.pipeline.TaskMode.Continue,
            condition: () => {
                let sceneFrom = we.core.gameConfig.getSceneFrom();
                if (sceneFrom != we.SceneFrom.Game) {
                    return false;
                }
                // 判断是否有新手礼包
                if (we.common.storeMgr.isNewbieGift) {
                    return false;
                }
                // 暂没有其余条件，也没有商城相关的弹窗队列，先直接返回true
                return true;
            },
        };
    }
}
