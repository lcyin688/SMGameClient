export enum CalendarDayType {
    NULL,
    LAST,
    CURR,
    NEXT,
}

export enum CalendarMoveDir {
    BEFORE,
    AFTER,
}
export interface CalendarDayData {
    day: number;
    clickable: boolean;
    dayType: CalendarDayType;
    year: number;
    month: number;
    hours?: number;
    minutes?: number;
    seconds?: number;
}

export interface CalendarWeekData {
    week: number; // 从0开始
    clickable: boolean;
}

export interface CalendarYearMonthData {
    days: Array<number>; // 一共42(6x7)位
    splitor: Array<number>; // 一共两位，[0,x)表示上月，[x,y)表示当月，[y,42)表示下月
    week: number; // 当月1日星期几，星期从范围[0,6]
}

export interface CalendarCurrentDate {
    year: number;
    month: number;
    day: number;
    hours?: number;
    minutes?: number;
    seconds?: number;
}

export interface CalendarDateBetween {
    start: CalendarCurrentDate;
    end: CalendarCurrentDate;
}

export default class CalendarModel {
    public static canOperationDays: number = 30; // 可以操作的天数，从昨天往前三十天
}
