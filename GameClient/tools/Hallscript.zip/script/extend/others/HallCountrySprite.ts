import { HallRes } from '../../config/HallRes';

const { ccclass, requireComponent, menu, property, disallowMultiple, executeInEditMode } = cc._decorator;

const CtryRes = we.core.EnumHelper.convertStringEnumToNumberEnum(HallRes.ctryres);

@ccclass
@executeInEditMode
@disallowMultiple
@requireComponent(cc.Sprite)
@menu('country/HallCountrySprite(多国家Sprite-Launcher)')
export class HallCountrySprite extends cc.Component {
    /**
     * 资源路径索引
     */
    @property({ type: cc.Enum(CtryRes), tooltip: CC_DEV && '资源ID' })
    private index: number = 0;

    private sprite: cc.Sprite | null = null;

    protected onLoad() {
        this.sprite = this.node.getComponent(cc.Sprite);
        this.setRes();
    }

    public async setRes() {
        if (CC_EDITOR) {
            // 内置白色底图
            this.sprite.spriteFrame = null;
            return;
        }

        this.node.color = cc.Color.WHITE;

        // 默认地区的资源路径
        const index = we.core.EnumHelper.getKeyFromValue(CtryRes, this.index);
        const defaultUrl = HallRes.ctryres[index];

        const spriteFrame = await we.core.assetMgr.loadCountrySprite(defaultUrl, this);
        if (!spriteFrame) {
            we.warn(`HallCountrySprite setRes, spriteFrame null, defaultUrl: ${defaultUrl}`);
            return;
        }

        if (this.sprite) {
            this.sprite.spriteFrame = spriteFrame;
        }
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny({ uuid: uuid }, (err, asset) => {
                if (err) {
                    resolve(null);
                    return;
                }
                resolve(asset);
            });
        });
    }
}
