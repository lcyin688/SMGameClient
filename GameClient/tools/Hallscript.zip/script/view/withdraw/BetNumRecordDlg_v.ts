import { HallViewId } from '../HallViewId';
import BetNumRecordItem_v from './BetNumRecordItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('BetNumRecordDlgView_v', we.bundles.hall)
class BetNumRecordDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_curBetNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_needBetNum: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('BetNumRecordDlg_v', we.bundles.hall)
export class BetNumRecordDlg_v extends we.ui.DlgSystem<BetNumRecordDlgView_v> {
    private pageSize: number = 30;
    private page: number = 0;
    private totalPage: number = 1;
    private recordList: api.WithdrawScoreInfo[] = [];
    private reqRecord: boolean = false; // 正在请求数据

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.view.cc_onScrollViewEvent(this.view.RC_list.node, 'scroll-to-bottom', we.core.Func.create(this.onRecordScrollEnd, this));
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.init();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private init(): void {
        this.page = 0;
        this.totalPage = 1;
        this.recordList = [];

        this.view.RC_lab_needBetNum.string = we.common.utils.formatAmount(we.common.withdrawMgr.config?.withdrawNeededScore, false);
        this.view.RC_lab_curBetNum.string = we.common.utils.formatAmount(we.common.withdrawMgr.config?.withdrawScore, false);

        this.requestRecord(true);
    }

    public onRenderEvent(item: cc.Node, index: number) {
        if (index < this.recordList.length) {
            let data = this.recordList[index];
            item.getComponent(BetNumRecordItem_v).init(data);
        }
    }

    private onRecordScrollEnd() {
        if (this.reqRecord) {
            return;
        }
        this.reqRecord = true;

        this.requestRecord();
    }

    private requestRecord(isFirst: boolean = false): void {
        if (!isFirst) {
            if (this.page + 1 < this.totalPage) {
                this.page += 1;
            } else {
                return;
            }
        }

        we.common.apiMgr.getWithdrawScoreInfo(
            this.page,
            this.pageSize,
            (data: api.WithdrawScoreResp) => {
                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }

                this.reqRecord = false;
                this.totalPage = Math.ceil(data.total / this.pageSize);
                this.recordList = this.recordList.concat(data.info || []);
                this.view.RC_list.numItems = this.recordList.length;
            },
            null
        );
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(BetNumRecordDlg_v, `${HallViewId.BetNumRecordDlg}_v`)
class BetNumRecordDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(BetNumRecordDlg_v, uiBase.addComponent(BetNumRecordDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BetNumRecordDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<BetNumRecordDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(BetNumRecordDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BetNumRecordDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(BetNumRecordDlg_v).beforeUnload();
    }
}
