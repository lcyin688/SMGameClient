import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoPHDlgView_v', we.bundles.hall)
class WithdrawAccountInfoPHDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_account: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_name: cc.EditBox = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirmGray: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoPHDlg_v', we.bundles.hall)
export class WithdrawAccountInfoPHDlg_v extends we.ui.DlgSystem<WithdrawAccountInfoPHDlgView_v> {
    private bankInfo: api.UserBankInfo = null;
    private isAddAccount: boolean = true;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_edit_name.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_NAMED);
        this.view.RC_edit_account.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__RECORD_NUMTIPS);

        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'editingDidBegan', we.core.Func.create(this.onNameEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'textChanged', we.core.Func.create(this.onNameEditBoxEditChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'editingDidEnded', we.core.Func.create(this.onNameEditBoxEditEnded, this));

        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidBegan', we.core.Func.create(this.onAccountNumberEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'textChanged', we.core.Func.create(this.onAccountNumberEditBoxEditChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidEnded', we.core.Func.create(this.onAccountNumberEditBoxEditEnded, this));

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.onClickConfirm, this)).setSleepTime(1.5);
    }

    /** 显示窗口 */
    public async onShow(data: api.UserBankInfo, isAdd: boolean) {
        this.view.RCN_confirm.active = false;
        this.view.RCN_confirmGray.active = true;

        this.bankInfo = null;
        if (!data) {
            return;
        }
        this.bankInfo = data;
        this.isAddAccount = isAdd;

        if (!isAdd) {
            this.view.RC_edit_name.string = this.bankInfo.userName;
            this.view.RC_edit_account.string = this.bankInfo.account;
        }

        // 提现渠道 icon
        let path = HallRes.texture.channelCode + data.channelCode;
        we.common.utils.setComponentSprite(this.view.RC_spr_icon, path);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onNameEditBoxEditStarted() {
        this.view.RC_edit_name.placeholderLabel.string = '';
    }

    private onNameEditBoxEditChanged() {
        let str: string = this.view.RC_edit_name.string;
        str = str.trim();
        this.view.RC_edit_name.string = str;
        // @ts-ignore
        if (this.view.RC_edit_name && this.view.RC_edit_name._impl && this.view.RC_edit_name._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_name._impl._elem.value = str;
        }
    }

    private onNameEditBoxEditEnded() {
        let str: string = this.view.RC_edit_name.string;
        str = str.trim();
        if (str.length <= 0) {
            this.view.RC_edit_name.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_NAMED);
        }
        this.view.RC_edit_name.string = str;
        // @ts-ignore
        if (this.view.RC_edit_name && this.view.RC_edit_name._impl && this.view.RC_edit_name._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_name._impl._elem.value = str;
        }
        this.setConfirmBtn();
    }

    private onAccountNumberEditBoxEditStarted() {
        this.view.RC_edit_account.placeholderLabel.string = '';
    }

    private onAccountNumberEditBoxEditChanged() {
        if (cc.sys.isNative) {
            return;
        }
        let str: string = this.view.RC_edit_account.string;
        str = str.trim();
        this.view.RC_edit_account.string = str;
        // @ts-ignore
        if (this.view.RC_edit_account && this.view.RC_edit_account._impl && this.view.RC_edit_account._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_account._impl._elem.value = str;
        }
    }

    private onAccountNumberEditBoxEditEnded() {
        let str: string = this.view.RC_edit_account.string;
        str = str.trim();
        if (str.length <= 0) {
            this.view.RC_edit_account.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__RECORD_NUMTIPS);
        }
        this.view.RC_edit_account.string = str;
        // @ts-ignore
        if (this.view.RC_edit_account && this.view.RC_edit_account._impl && this.view.RC_edit_account._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_account._impl._elem.value = str;
        }
        this.setConfirmBtn();
    }

    private onClickConfirm(): void {
        // 判定是否有修改
        let isNotEdit = true;

        let nameStr = this.view.RC_edit_name.string;
        let accountStr = this.view.RC_edit_account.string;
        if (this.bankInfo) {
            if (this.bankInfo.account != accountStr || this.bankInfo.userName != nameStr) {
                isNotEdit = false;
            }
        }

        if (isNotEdit) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_MODIFY_TEXT));
            return;
        }

        let account: string = accountStr;
        this.changeBindInfo(account, nameStr);
    }

    private changeBindInfo(account: string, nameStr: string): void {
        let bindInfo = {} as api.UserBankInfo;
        bindInfo.channelType = this.bankInfo.channelType;
        bindInfo.channelCode = this.bankInfo.channelCode;
        bindInfo.account = account;
        bindInfo.userName = nameStr;

        let param = {} as api.UserBankWithdrawUpdateReq;
        param.operationType = this.isAddAccount ? 0 : 1;
        param.originalAccount = this.bankInfo?.account || '';
        param.info = bindInfo;

        we.common.withdrawMgr.modifyWithdrawBindInfo(param, (data: api.UserBankWithdrawUpdateResp) => {
            if (data.suc) {
                // 无可用账号绑定成功时，需要更新提现主界面 绑定账号展示
                let isUpdateMainUI = we.common.withdrawMgr.accountList.length < 1;
                // 更新临时缓存账号信息
                we.common.withdrawMgr.updateAccountInfo(bindInfo, this.isAddAccount ? null : this.bankInfo);

                if (isUpdateMainUI) {
                    cc.director.emit(HallEvent.WITHDRAW_UPDATE_BANK_INFO, bindInfo, true);
                }

                cc.director.emit(HallEvent.WITHDRAW_UPDATE_ACCOUNT_LIST, bindInfo, this.isAddAccount);
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_TIPS_MODIFY_SUCCESS));

                if (cc.isValid(this.view.uiRoot)) {
                    this.closeView();
                }
            }
        });
    }

    private setConfirmBtn(): void {
        if (!this.bankInfo) {
            return;
        }

        let flag: boolean = true;
        if (this.view.RC_edit_account.string.length == 0 || this.view.RC_edit_name.string.length == 0) {
            flag = false;
        }

        this.view.RCN_confirm.active = flag;
        this.view.RCN_confirmGray.active = !flag;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawAccountInfoPHDlg_v, `${HallViewId.WithdrawAccountInfoPHDlg}_v`)
class WithdrawAccountInfoPHDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawAccountInfoPHDlg_v, uiBase.addComponent(WithdrawAccountInfoPHDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoPHDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawAccountInfoPHDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoPHDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoPHDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawAccountInfoPHDlg_v).beforeUnload();
    }
}
