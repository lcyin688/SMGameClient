import WithdrawRoundItem_h from './WithdrawRoundItem_h';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

interface BroadcastInfo {
    userId: number;
    userName: string;
    money: number;
    currency: string;
    finishTime: number;
    costTime: number;
}
interface RoundItem {
    time: string;
    nick: string;
    amountLeft: string;
    amountRight: string;
    costLeft: string;
    costRight: string;
}

enum Scroll_Direction {
    /** 水平 */
    Horizontal = 0,
    /** 垂直方向 */
    Vertical = 1,
}

@ccclass
export default class WithdrawRound_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_bg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property(cc.Prefab)
    private roundItem: cc.Prefab = null;

    @property
    private _direction: Scroll_Direction = Scroll_Direction.Vertical;
    @property({
        type: cc.Enum(Scroll_Direction),
        tooltip: CC_DEV && '滚动方向 默认：垂直方向',
    })
    get direction() {
        return this._direction;
    }
    set direction(value: Scroll_Direction) {
        this._direction = value;
    }

    @property
    private broadcastNum: number = 4;

    @property
    private eachItemHeight: number = 135;

    private broadcastInfoArr: BroadcastInfo[] = [];
    private bNeedUpdate: boolean = true;
    private labelPosition = [];

    /** 是垂直方向 */
    private isVerticalDir: boolean = true;
    private shiftTimeMax: number = 10;
    private nodePool: cc.NodePool = null;
    private firstShowItem: number = 0;
    private itemDisappear: number = 0;
    private speed: number = 50;

    protected onLoad() {
        this.isVerticalDir = this._direction == Scroll_Direction.Vertical;

        this.init();
        this.flushInfo();

        cc.director.on(we.common.EventName.WITHDRAW_BROAD, this.onUpdateBroad, this);
    }

    protected update(dt: number) {
        if (!this.bNeedUpdate || !this.nodePool) {
            return;
        }

        if (this.isVerticalDir) {
            this.verticalScroll(dt);
        } else {
            this.horizontalScroll(dt);
        }
    }

    protected onDestroy() {
        cc.director.off(we.common.EventName.WITHDRAW_BROAD, this.onUpdateBroad, this);

        this.nodePool.clear();
    }

    private init(): void {
        this.nodePool = new cc.NodePool();
        for (let i = 0; i < this.shiftTimeMax; ++i) {
            let obj = cc.instantiate(this.roundItem);
            if (obj) {
                this.nodePool.put(obj);
            }
        }

        this.RC_bg.active = true;

        this.labelPosition = [];
        this.RC_content.children.forEach((label) => {
            this.labelPosition.push(this.isVerticalDir ? label.position.y : label.position.x);
        });
        this.labelPosition.unshift(this.labelPosition[0] - (this.labelPosition[1] - this.labelPosition[0]));
        this.itemDisappear = this.eachItemHeight + this.firstShowItem;
    }

    private onUpdateBroad() {
        this.flushInfo();
    }

    private flushInfo() {
        this.broadcastInfoArr = JSON.parse(JSON.stringify(we.common.withdrawMgr.broadArray));
        this.broadcastInfoArr.sort((a: api.BankWithdrawBroadItem, b: api.BankWithdrawBroadItem) => {
            return a.finishTime - b.finishTime;
        });
    }

    /**
     * 垂直方向 从下往上
     * @param dt
     * @returns
     */
    private verticalScroll(dt: number) {
        if (this.broadcastInfoArr.length < this.broadcastNum) {
            // 不移动
            this.bNeedUpdate = true;
            let children = this.RC_content.children;
            if (children.length < this.broadcastInfoArr.length) {
                // get
                let count = this.broadcastInfoArr.length - children.length;
                for (let i = 0; i < count; i++) {
                    let node = this.nodePool.get();
                    if (node) {
                        node.parent = this.RC_content;
                    }
                }
            } else if (children.length > this.broadcastInfoArr.length) {
                // reuse
                let count = -this.broadcastInfoArr.length + children.length;
                for (let i = 0; i < count; i++) {
                    this.nodePool.put(this.RC_content.children[i]);
                }
            } else {
                return;
            }

            this.RC_content.children.forEach((child, index) => {
                child.y = this.firstShowItem - this.eachItemHeight * index;
                let item = child.getComponent(WithdrawRoundItem_h);
                if (item) {
                    item.init(this.formatDataToItem(this.broadcastInfoArr[index]));
                }
            });
        } else {
            // 循环移动
            this.bNeedUpdate = true;
            if (this.RC_content.children.length != this.broadcastNum + 1) {
                let children = this.RC_content.children;
                let needShowCount = this.broadcastNum + 1;
                if (children.length < needShowCount) {
                    // get
                    let count = needShowCount - children.length;
                    for (let i = 0; i < count; i++) {
                        let node = this.nodePool.get();
                        if (node) {
                            node.parent = this.RC_content;
                        }
                    }
                } else if (children.length > needShowCount) {
                    // reuse
                    let count = -needShowCount + children.length;
                    for (let i = 0; i < count; i++) {
                        this.nodePool.put(this.RC_content.children[i]);
                    }
                }

                this.RC_content.children.forEach((child, index) => {
                    child.y = this.firstShowItem - this.eachItemHeight * index;
                    let item = child.getComponent(WithdrawRoundItem_h);
                    this.broadcastInfoArr.push(this.broadcastInfoArr.shift());
                    if (item) {
                        item.init(this.formatDataToItem(this.broadcastInfoArr[0]));
                    }
                });
            }
            let tempNode = null;
            this.RC_content.children.forEach((child) => {
                child.y += this.speed * dt;
                if (child.y > this.itemDisappear) {
                    tempNode = child;
                    child.y = (this.RC_content.children.length - 1) * this.eachItemHeight * -1;

                    let item = child.getComponent(WithdrawRoundItem_h);
                    this.broadcastInfoArr.push(this.broadcastInfoArr.shift());
                    if (item) {
                        item.init(this.formatDataToItem(this.broadcastInfoArr[0]));
                    }
                }
            });
        }
    }

    /**
     * 水平方向 从右往左
     * @param dt
     * @returns
     */
    private horizontalScroll(dt: number) {
        if (this.broadcastInfoArr.length < this.broadcastNum) {
            // 不移动
            this.bNeedUpdate = true;
            let children = this.RC_content.children;
            if (children.length < this.broadcastInfoArr.length) {
                // get
                let count = this.broadcastInfoArr.length - children.length;
                for (let i = 0; i < count; i++) {
                    let node = this.nodePool.get();
                    if (node) {
                        node.parent = this.RC_content;
                    }
                }
            } else if (children.length > this.broadcastInfoArr.length) {
                // reuse
                let count = -this.broadcastInfoArr.length + children.length;
                for (let i = 0; i < count; i++) {
                    this.nodePool.put(this.RC_content.children[i]);
                }
            } else {
                return;
            }

            this.RC_content.children.forEach((child, index) => {
                child.x = this.firstShowItem + this.eachItemHeight * index;
                let item = child.getComponent(WithdrawRoundItem_h);
                if (item) {
                    item.init(this.formatDataToItem(this.broadcastInfoArr[index]));
                }
            });
        } else {
            // 循环移动
            this.bNeedUpdate = true;
            if (this.RC_content.children.length != this.broadcastNum + 1) {
                let children = this.RC_content.children;
                let needShowCount = this.broadcastNum + 1;
                if (children.length < needShowCount) {
                    // get
                    let count = needShowCount - children.length;
                    for (let i = 0; i < count; i++) {
                        let node = this.nodePool.get();
                        if (node) {
                            node.parent = this.RC_content;
                        }
                    }
                } else if (children.length > needShowCount) {
                    // reuse
                    let count = -needShowCount + children.length;
                    for (let i = 0; i < count; i++) {
                        this.nodePool.put(this.RC_content.children[i]);
                    }
                }

                this.RC_content.children.forEach((child, index) => {
                    child.x = this.firstShowItem + this.eachItemHeight * index;
                    let item = child.getComponent(WithdrawRoundItem_h);
                    this.broadcastInfoArr.push(this.broadcastInfoArr.shift());
                    if (item) {
                        item.init(this.formatDataToItem(this.broadcastInfoArr[0]));
                    }
                });
            }
            let tempNode = null;
            this.RC_content.children.forEach((child) => {
                child.x -= this.speed * dt;
                if (child.x < -this.eachItemHeight) {
                    tempNode = child;
                    child.x = (this.RC_content.children.length - 1) * this.eachItemHeight * 1;

                    let item = child.getComponent(WithdrawRoundItem_h);
                    this.broadcastInfoArr.push(this.broadcastInfoArr.shift());
                    if (item) {
                        item.init(this.formatDataToItem(this.broadcastInfoArr[0]));
                    }
                }
            });
        }
    }

    private formatDataToItem(info: BroadcastInfo): RoundItem {
        let ret: RoundItem = {
            time: '',
            nick: '',
            amountLeft: '',
            amountRight: '',
            costLeft: '',
            costRight: '',
        };

        let date = new Date(info.finishTime * 1000);
        ret.time = we.common.utils.formatDate(date);
        ret.nick = this.formatNick(info.userName) + ' ' + we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__RECORD_STATE6);
        ret.amountLeft = we.core.langMgr.getLangText(HallLanguage.WITHDRAW_TITLE);
        // ret.amountRight = `${we.common.Utils.formatAmount(info.money, false, 0, true)} ${info.currency}`;
        ret.amountRight = we.common.utils.formatAmountCurrency(info.money);
        ret.costLeft = we.core.langMgr.getLangText(HallLanguage.CHRISTMAS_TASK_TIME, '');
        ret.costRight = this.formatTime(info.costTime);

        return ret;
    }

    private formatTime(costTime: number): string {
        let formatDate = we.common.utils.formatSurplusTime(costTime);
        let minute = Number(formatDate.day) * 24 * 60 + Number(formatDate.hours) * 60 + Number(formatDate.minutes);
        let second = Number(formatDate.second);
        if (0 === minute && 0 === second) {
            second = 1;
        }
        let minuteStr = minute + ' ' + we.core.langMgr.getLangText(HallLanguage.WITHDRAW__RECORDROLL_ROLL_MINUTE) + ' ';
        let secondStr = second + ' ' + we.core.langMgr.getLangText(HallLanguage.WITHDRAW__RECORDROLL_ROLL_SECOND);
        return minute == 0 ? secondStr : minuteStr + secondStr;
    }

    private formatNick(realName: string): string {
        if (!realName) {
            realName = '';
        }
        let showName = '';
        if (realName.length > 6) {
            showName = realName.slice(0, 2) + '*'.repeat(realName.length - 4) + realName.slice(-2);
        } else {
            if (realName.length >= 2) {
                if (realName.length == 2) {
                    showName = realName[0] + '*';
                } else {
                    showName = realName.slice(0, 1) + '*'.repeat(realName.length - 2) + realName.slice(-1);
                }
            } else {
                showName = '*';
            }
        }
        return showName;
    }
}
