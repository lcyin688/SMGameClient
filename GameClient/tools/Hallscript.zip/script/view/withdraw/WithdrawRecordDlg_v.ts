import { HallEvent } from '../../config/HallEvent';
import { HallViewId } from '../HallViewId';
import WithdrawRecordItem_v from './WithdrawRecordItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawRecordDlgView_v', we.bundles.hall)
class WithdrawRecordDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_customer: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_noData: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawRecordDlg_v', we.bundles.hall)
export class WithdrawRecordDlg_v extends we.ui.DlgSystem<WithdrawRecordDlgView_v> {
    private recordArray: any[] = [];
    private requestRecordDating: boolean = false;
    private requestRecordDataOver: boolean = false;
    /** 当前选择类型 */
    private withdrawType: number = we.common.withdrawMgr.WithdrawType.Normal;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderRecordList, this));

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(
            this.view.RCN_customer,
            we.core.Func.create(() => {
                we.common.commonMgr.openCustomerDialog();
            }, this)
        );
        this.view.cc_onScrollViewEvent(this.view.RC_list.node, 'scroll-to-bottom', we.core.Func.create(this.onRecordScrollEnd, this));

        this.view.RC_menu.setMenuStateByNodeName('select', 'unselect');
        // 子节点 0:默认提现 1:vip提现
        this.view.RC_menu.onSelected = (menu: cc.Node, index: number) => {
            switch (index) {
                case 0:
                    this.withdrawType = we.common.withdrawMgr.WithdrawType.Normal;
                    break;
                case 1:
                    this.withdrawType = we.common.withdrawMgr.WithdrawType.Vip;
                    break;
                default:
                    break;
            }

            this.reset();
            this.requestRecord();
        };

        cc.director.on(HallEvent.WITHDRAW_UPDATE_ORDER_LIST, this.onUpdateOrderList, this);
    }

    /**
     * 显示窗口
     * @param type
     */
    public async onShow(type: number = we.common.withdrawMgr.WithdrawType.Normal) {
        this.reset();

        this.withdrawType = type;
        let isVip = this.withdrawType == we.common.withdrawMgr.WithdrawType.Vip;
        this.view.RC_menu.onSwitchMenu(isVip ? 1 : 0);

        !isVip && this.switchContentToRecord();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy(): void {
        cc.director.off(HallEvent.WITHDRAW_UPDATE_ORDER_LIST, this.onUpdateOrderList, this);
    }

    private reset(): void {
        this.recordArray = [];
        this.view.RC_list.numItems = 0;
        this.requestRecordDating = false;
        this.requestRecordDataOver = false;
        this.view.RCN_noData.active = false;
    }

    public onRenderRecordList(item: cc.Node, index: number) {
        if (index < this.recordArray.length) {
            const record = this.recordArray[index];
            item.getComponent(WithdrawRecordItem_v)?.init?.(record, this.withdrawType);
        }
    }

    private onRecordScrollEnd() {
        this.requestRecord();
    }

    private switchContentToRecord(): void {
        this.reset();
        this.requestRecord();
    }

    private onUpdateOrderList(): void {
        this.reset();
        this.requestRecord();
    }

    private requestRecord() {
        if (this.requestRecordDating || this.requestRecordDataOver) {
            return;
        }
        this.requestRecordDating = true;

        let dataRequest = {} as api.BankWithdrawRecordReq;
        dataRequest.goldType = 0;
        dataRequest.begin = this.recordArray.length;
        dataRequest.limit = we.common.withdrawMgr.recordEachPageCount;
        dataRequest.orderType = this.withdrawType;

        we.common.withdrawMgr.getBankWithdrawRecord(
            dataRequest,
            (data: api.BankWithdrawRecordResp) => {
                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }

                if (this.withdrawType != dataRequest.orderType) {
                    return;
                }

                this.requestRecordDataOver = 0 == data.records.length;
                this.recordArray = this.recordArray.concat(data.records);

                this.view.RC_list.numItems = this.recordArray.length;
                this.requestRecordDating = false;
                this.view.RCN_noData.active = this.recordArray.length === 0;
            },
            (code) => {
                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }
                this.requestRecordDating = false;
            }
        );
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawRecordDlg_v, `${HallViewId.WithdrawRecordDlg}_v`)
class WithdrawRecordDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
        uiBase.uiConfig.closeTime = 0.36;
        uiBase.uiConfig.openTime = 0.36;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawRecordDlg_v, uiBase.addComponent(WithdrawRecordDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawRecordDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawRecordDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawRecordDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawRecordDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawRecordDlg_v).beforeUnload();
    }
}
