import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import NewbieGuideMgr from '../../manager/NewbieGuideMgr';
import { HallViewId } from '../HallViewId';
import WithdrawFastItem_v from './WithdrawFastItem_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class Withdraw_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Button)
    public RC_btn_add: cc.Button = null;

    @we.ui.ccBind(cc.Button)
    public RC_btn_sub: cc.Button = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_amount: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_account: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_balance: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_curBet: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_needBet: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_rang: cc.Label = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu_fast: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(cc.PageView)
    public RC_page_index: cc.PageView = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_withdrawNum: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.ScrollView)
    public RC_scroll_center: cc.ScrollView = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_amount: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bankEdit: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bankShow: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnEdit: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_customer: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_delegate: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_detail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_question: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_record: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_sendWithdraw: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_sendWithdrawGray: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_vipTips: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private curAccountInfo: api.UserBankInfo = null;
    private userEditRealAmount: number = 0;
    /** 当前选择类型 */
    private withdrawType: number = we.common.withdrawMgr.WithdrawType.Normal;
    /** 选中快捷额度 */
    private selectFastAmount: number = 0;

    protected onLoad() {
        this.RCN_sendWithdraw.active = false;
        this.RCN_sendWithdrawGray.active = true;
        this.RC_lab_balance.string = we.common.utils.formatAmountCurrency(we.common.userMgr.userInfo.gold);

        this.RC_btn_add.interactable = false;
        this.RC_btn_sub.interactable = false;
        this.bindEvent();
        this.initMenu();
    }

    protected onEnable(): void {
        cc.director.on(we.common.EventName.WITHDRAW_UPDATE_VIEW, this.onRefreshView, this);
        cc.director.on(we.common.EventName.WITHDRAW_UPDATE_BET_NUM, this.onUpdateBetNum, this);
        cc.director.on(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.onHideWithdraw, this);
        cc.director.on(we.common.EventName.ON_HIDE_GUIDE, this.onHideGuide, this);

        cc.director.on(HallEvent.WITHDRAW_UPDATE_GOLD, this.onRefreshView, this);
        cc.director.on(HallEvent.WITHDRAW_UPDATE_BANK_INFO, this.onUpWithdrawChnInfo, this);

        we.common.withdrawMgr.getBankWithdrawConf();
        this.initUI();
    }

    protected start(): void {
        const isShow = NewbieGuideMgr.judgeStartModGuide([{ mod: NewbieGuideMgr.ModGuide.WITHDRAW, step: 2 }]);
        this.setScrollCenter(!isShow);
    }

    protected onDisable(): void {
        cc.director.off(we.common.EventName.WITHDRAW_UPDATE_VIEW, this.onRefreshView, this);
        cc.director.off(we.common.EventName.WITHDRAW_UPDATE_BET_NUM, this.onUpdateBetNum, this);
        cc.director.off(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.onHideWithdraw, this);
        cc.director.off(we.common.EventName.ON_HIDE_GUIDE, this.onHideGuide, this);

        cc.director.off(HallEvent.WITHDRAW_UPDATE_GOLD, this.onRefreshView, this);
        cc.director.off(HallEvent.WITHDRAW_UPDATE_BANK_INFO, this.onUpWithdrawChnInfo, this);
    }

    private bindEvent(): void {
        this.onBtnClick(this.RCN_question, we.core.Func.create(this.onClickQuestion, this));
        this.onBtnClick(this.RCN_customer, we.core.Func.create(this.onCloseCustomer, this));
        this.onBtnClick(this.RCN_record, we.core.Func.create(this.onClickRecord, this));

        this.onBtnClick(this.RCN_bankShow, we.core.Func.create(this.onClickOpenAccountBind, this));
        this.onBtnClick(this.RCN_bankEdit, we.core.Func.create(this.onClickOpenAccountBind, this));
        this.onBtnClick(this.RCN_btnEdit, we.core.Func.create(this.onClickOpenAccountBind, this));

        this.onBtnClick(this.RC_btn_add.node, we.core.Func.create(this.onAddClicked, this)).setSleepTime(0);
        this.onBtnClick(this.RC_btn_sub.node, we.core.Func.create(this.onSubClicked, this)).setSleepTime(0);
        this.onBtnClick(this.RCN_sendWithdraw, we.core.Func.create(this.onClickWithdrawSubmit, this)).setSleepTime(0.5);

        this.onBtnClick(this.RCN_delegate, we.core.Func.create(this.onContent2RuleClicked, this)).setSleepTime(0.5);
        this.onBtnClick(this.RCN_detail, we.core.Func.create(this.onClickDetail, this)).setSleepTime(0.5);

        this.onEditBoxEvent(this.RC_edit_amount.node, 'editingDidBegan', we.core.Func.create(this.onContent2EditBoxDidBegin, this));
        this.onEditBoxEvent(this.RC_edit_amount.node, 'editingDidEnded', we.core.Func.create(this.onContent2EditBoxDidEnd, this));

        this.RC_page_index.node.on('page-turning', this.onPageViewIndex, this);
    }

    /**
     * 初始化 UI 界面
     * @param data
     * @returns
     */
    private initUI(data: api.UserBankInfo = null): void {
        let config = we.common.withdrawMgr.config;
        if (!config) {
            return;
        }

        this.selectFastAmount = 0;
        this.userEditRealAmount = 0;
        this.RC_menu_fast.index = -1;

        // 默认菜单栏第二个为 vip 提现通道
        let children = this.RC_menu.node.children;
        if (children.length >= 2) {
            children[0].active = we.common.withdrawMgr.openNormalChn;
            children[1].active = we.common.withdrawMgr.openVipChn;

            this.RC_menu.index = we.common.withdrawMgr.openNormalChn ? 0 : 1;
        }

        this.curAccountInfo = data ? data : we.common.withdrawMgr.getNormalAccountInfo();
        we.common.withdrawMgr.selectAccountInfo = data;
        we.common.withdrawMgr.updateSupportRange(this.curAccountInfo);
        we.common.withdrawMgr.formatAccountData();

        this.RCN_sendWithdraw.active = false;
        this.RCN_sendWithdrawGray.active = true;
        this.RC_btn_add.interactable = false;
        this.RC_btn_sub.interactable = false;
        this.RCN_detail.active = config.showWithdrawFlowSwitch;
        // 余额
        this.RC_lab_balance.string = we.common.utils.formatAmountCurrency(we.common.userMgr.userInfo.gold);
        // 展示剩余次数
        let withdrawNum = config.dailyWithdrawTimeLimit - config.dailyWithdrawTime;
        this.RC_rich_withdrawNum.setStringFormat(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_NUM), withdrawNum + ` / ${config.dailyWithdrawTimeLimit}`);
        // 当日剩余提现次数<=0 当日剩余提现额度<=单日最小提现额度 可以用于提现的金币 < 单日最小提现额度
        this.RCN_delegate.active = !we.common.withdrawMgr.judgeEnableWithdraw();

        this.setAccountShow();
        this.setWithdrawRangShow();
        this.setFastBtn();
        this.onUpdateBetNum();

        if (this.userEditRealAmount == 0) {
            let canWithdrawAmount = we.common.withdrawMgr.getCanWithdrawAmount();
            if (canWithdrawAmount >= we.common.withdrawMgr.minRangNum) {
                this.userEditRealAmount = we.common.withdrawMgr.minRangNum;
            }
        }
        this.updateEditBoxShow();

        this.setOperationSt();
    }

    private initMenu(): void {
        this.RC_menu.setMenuStateByNodeName('select', 'unselect');
        this.RC_menu.onSelected = (node, index) => {
            // 目前菜单栏仅两个分类 常规 / vip，默认 index 为0 是常规提现方式
            if (index == 0) {
                this.userEditRealAmount = 0;
                this.RC_edit_amount.string = '0';
                this.withdrawType = we.common.withdrawMgr.WithdrawType.Normal;
            } else {
                this.selectFastAmount = 0;
                this.withdrawType = we.common.withdrawMgr.WithdrawType.Vip;
            }

            this.setUIShowType(this.withdrawType);
            this.setOperationSt();
            this.setFastBtn();

            this.RC_page_index.setCurrentPageIndex(index);

            // 重置快捷按钮选中下标，防止玩家切换方式后无法选中切页前 index
            this.RC_menu_fast.index = -1;
        };

        // 注册快捷按钮点击事件
        this.RC_menu_fast.onSelected = (node, index) => {
            let amount = node.getComponent(WithdrawFastItem_v).amount;
            if (amount + we.common.withdrawMgr.config?.remain <= we.common.userMgr.userInfo.gold) {
                switch (this.withdrawType) {
                    case we.common.withdrawMgr.WithdrawType.Normal:
                        this.userEditRealAmount = amount;
                        this.updateEditBoxShow();
                        break;
                    case we.common.withdrawMgr.WithdrawType.Vip:
                        node.getComponent(WithdrawFastItem_v).setSelectStatus(true);
                        this.selectFastAmount = amount;
                        break;
                    default:
                        break;
                }
            } else {
                this.selectFastAmount = 0;
            }
            this.setOperationSt();

            let config = we.common.withdrawMgr.config;
            if (we.common.userMgr.userInfo.gold < amount) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS4));
                return;
            }

            // 提现后账户剩余不得低于 xxx
            if (we.common.userMgr.userInfo.gold < amount + config.remain) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS3, we.common.utils.formatAmount(config.remain, false)));
                return;
            }

            // 判定每日提现额度超上限
            if (config.dailyWithdrawAmountLimit < config.dailyWithdrawNum + amount) {
                we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20096));
                return;
            }
        };
        this.RC_menu_fast.onUnselected = (node, index) => {
            if (this.withdrawType == we.common.withdrawMgr.WithdrawType.Vip) {
                node.getComponent(WithdrawFastItem_v).setSelectStatus(false);
            }
        };
    }

    private onHideWithdraw(isShow: boolean): void {
        if (!isShow) {
            we.currentUI.getDlg(HallViewId.HallDlg).onShow();
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20087));
        }
    }

    private onPageViewIndex() {
        const index = this.RC_page_index.getCurrentPageIndex();
        if ((index == 0 && we.common.withdrawMgr.openNormalChn) || (index == 1 && we.common.withdrawMgr.openVipChn)) {
            this.RC_menu.index = index;
        }
    }

    private onRefreshView() {
        if (!cc.isValid(this.node)) {
            return;
        }

        if (!we.common.withdrawMgr.openNormalChn && !we.common.withdrawMgr.openVipChn) {
            // 全部提现通道已关闭
            cc.director.emit(we.common.EventName.HALL_IS_SHOW_WITHDRAW, false);
            return;
        }

        this.initUI(this.curAccountInfo);
    }

    private onUpWithdrawChnInfo(info: api.UserBankInfo, isUpdate: boolean = false): void {
        // 更新银行卡信息修改后，如果当前渠道被选中需要更新银行卡信息
        if (isUpdate) {
            this.initUI(info);
        }
    }

    private onClickRecord() {
        we.currentUI.show(HallViewId.WithdrawRecordDlg);
    }

    private onClickQuestion() {
        we.currentUI.show(HallViewId.WithdrawInstructionDlg);
    }

    private onClickOpenAccountBind(event): void {
        if (NewbieGuideMgr.IsInHallGuide()) {
            cc.director.emit(we.common.EventName.UPDATE_GUIDE_STEP);
            this.setScrollCenter(true);
        }

        // 支持提现渠道配置为空，提示正在加载数据
        if (!we.common.withdrawMgr.supportChannel) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS8));
            return;
        }

        // 无可用提现渠道时，提示暂无可用提现渠道
        let support = we.common.withdrawMgr.supportChannel.withDrawType || [];
        if (support.length < 1) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS9));
            return;
        }

        // 无可用账号 直接打开提现选择界面，有账号时打开提现账号列表
        let accounts = we.common.withdrawMgr.accountList;
        if (accounts.length > 0) {
            we.currentUI.show(HallViewId.WithdrawAccountDlg);
        } else {
            we.currentUI.show(HallViewId.WithdrawSelectChannelDlg);
        }
    }

    private setScrollCenter(enable: boolean): void {
        if (cc.isValid(this.RC_scroll_center)) {
            this.RC_scroll_center.enabled = enable;
        }
    }

    private onHideGuide(): void {
        this.setScrollCenter(true);
    }

    /**
     * 发起提现需要满足以下条件
     *  1.账号类型判定
     *  2.提现次数足够
     *  3.满足提现配置区间，提现保留金+最小提现数值 > 玩家持有金币数
     *  4.打码量满足所需打码量
     *  5.不大于单日提现总额度上限限制
     *  6.不能超过提现通道上限，已使用提现通道限制+提现数量 <= 提现通道最大限制数量
     */
    private onClickWithdrawSubmit(): void {
        let config = we.common.withdrawMgr.config;
        if (!config) {
            return;
        }

        // 账号类型判定
        if (!we.common.userMgr.isFormal()) {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
            return;
        }

        // vip 通道是需要判定支付方式是否实名
        if (this.withdrawType == we.common.withdrawMgr.WithdrawType.Vip) {
            if (!we.common.userMgr.isRealName()) {
                we.currentUI.show(HallViewId.UserCenterRealNameDlg);
                return;
            }
        }

        let str = this.RC_edit_amount.string;
        // 提现金币数 换算成精度与服务器保持一致
        let amount = Number(str) * we.core.flavor.getAmountPrecision();
        // 根据当前菜单类型类型获取提现额度
        if (this.withdrawType == we.common.withdrawMgr.WithdrawType.Vip) {
            amount = this.selectFastAmount;
        }

        if (we.common.userMgr.userInfo.gold < amount) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS4));
            return;
        }

        // 单次提现不得低于 xxx
        if (amount < we.common.withdrawMgr.minRangNum) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20082, we.common.utils.formatAmount(we.common.withdrawMgr.minRangNum, false)));
            return;
        }

        // 提现后账户剩余不得低于 xxx
        if (we.common.userMgr.userInfo.gold < amount + config.remain) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS3, we.common.utils.formatAmount(config.remain, false)));
            return;
        }

        // 判定每日提现额度超上限
        if (config.dailyWithdrawAmountLimit < config.dailyWithdrawNum + amount) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20096));
            return;
        }

        // 提现次数超过上限
        if (config.dailyWithdrawTimeLimit - config.dailyWithdrawTime <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_MODIFY_TEXT_2));
            return;
        }

        // 打码量判定
        if (config.withdrawScore < config.withdrawNeededScore) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20093));
            return;
        }

        let info = we.common.withdrawMgr.getChannelInfoByCode(this.curAccountInfo.channelCode);
        if (!info) {
            we.warn(`Withdraw_v onWithdrawSubmitClick, withdraw conf is null`);
            return;
        }

        // 提现通道限额
        if (info.channelLimitAmount > 0) {
            let useAmount = info.channelUseAmount + we.common.utils.amountToPrice(amount);
            if (useAmount > info.channelLimitAmount) {
                let limitAmountStr = `<color=${we.common.skin.config.color.warn}>${we.common.utils.formatPrice(info.channelLimitAmount, false, false)}</c>`;
                we.commonUI.showConfirm({
                    title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1),
                    content: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_MODIFY_TEXT_1, limitAmountStr),
                    yesButtonName: we.core.langMgr.getLangText(HallLanguage.Withdrawal_USUAL_Btn2),
                    yesHandler: we.core.Func.create(() => {
                        we.currentUI.show(HallViewId.WithdrawAccountDlg);
                    }, this),
                    noButtonName: we.core.langMgr.getLangText(HallLanguage.GAME_ID_CARD_27),
                    noHandler: we.core.Func.create(() => {
                        if (cc.isValid(this.node)) {
                            this.sendWithdrawReq(amount);
                        }
                    }, this),
                });
                return;
            }
        }

        this.sendWithdrawReq(amount);
    }

    private sendWithdrawReq(amount: number): void {
        if (!this.curAccountInfo) {
            we.warn(`Withdraw_v sendWithdrawReq, withdraw conf is null`);
            return;
        }

        let fun = (withdrawAmount: number) => {
            HallMgr.getOngoingGame(
                (data) => {
                    if (!cc.isValid(this.node)) {
                        return;
                    }

                    let gameId = parseInt(data.ongoingGame);
                    if (we.core.gameConfig.isSubGame(gameId)) {
                        we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_CODE_TIPS1));
                    } else {
                        let param = {} as api.UserBankWithdrawReq;
                        param.channelType = this.curAccountInfo.channelType;
                        param.channelCode = this.curAccountInfo.channelCode;
                        param.account = this.curAccountInfo.account;
                        param.orderType = this.withdrawType;
                        param.amount = withdrawAmount;
                        we.currentUI.show(HallViewId.WithdrawConfirmDlg, param);
                    }
                },
                null,
                true,
                false
            );
        };

        // 仅在普通提现的时候判定是否存在首提活动提示
        let existAc = we.common.withdrawMgr.judgeEnableWithdrawAc();
        let acAmount = we.common.withdrawMgr.config.activityMinWithDraw;
        if (this.withdrawType == we.common.withdrawMgr.WithdrawType.Normal && existAc && amount < acAmount) {
            let str = `<color=${we.common.skin.config.color.warn}>${we.common.utils.formatAmountCurrency(acAmount, false)}</c>`;
            let tips = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS7, str);
            we.commonUI.showConfirm({
                content: tips,
                isHideCloseBtn: true,
                yesHandler: we.core.Func.create(() => {
                    fun(amount);
                }, this),
                noHandler: we.core.Func.create(() => {}),
            });
        } else {
            fun(amount);
        }
    }

    private onCloseCustomer(): void {
        we.common.commonMgr.openCustomerDialog();
    }

    private onAddClicked(): void {
        if (!we.common.withdrawMgr.config) {
            return;
        }

        if (this.userEditRealAmount + we.common.withdrawMgr.config.unit <= we.common.withdrawMgr.maxRangNum) {
            this.userEditRealAmount += we.common.withdrawMgr.config.unit;
        }

        this.setOperationSt();
        this.updateEditBoxShow();

        // 重置快捷额度选中 index
        this.RC_menu_fast.index = -1;
    }

    private onSubClicked(): void {
        if (!we.common.withdrawMgr.config) {
            return;
        }

        if (this.userEditRealAmount - we.common.withdrawMgr.config.unit >= we.common.withdrawMgr.minRangNum) {
            this.userEditRealAmount -= we.common.withdrawMgr.config.unit;
        }

        this.setOperationSt();
        this.updateEditBoxShow();
    }

    private onContent2RuleClicked(): void {
        let config = we.common.withdrawMgr.config;
        if (!config) {
            return;
        }

        if (we.common.withdrawMgr.config.dailyWithdrawTimeLimit - we.common.withdrawMgr.config.dailyWithdrawTime <= 0) {
            // 提现次数超过上限
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS6, we.common.withdrawMgr.config.dailyWithdrawTimeLimit));
            return;
        }

        let content = null;
        if (we.common.userMgr.userInfo.gold < we.common.withdrawMgr.minRangNum) {
            // 您的账户余额低于最低提现金额
            content = we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS1, we.common.utils.formatAmount(we.common.withdrawMgr.minRangNum, false));
        } else {
            // 您的账户余额低于最低提现金额{0}，提现后的账户余额不得低于{1}
            if (we.common.userMgr.userInfo.gold < we.common.withdrawMgr.minRangNum + config.remain) {
                content = we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS2, we.common.utils.formatAmount(we.common.withdrawMgr.minRangNum, false), we.common.utils.formatAmount(config.remain, false));
            }
        }

        if (content) {
            we.commonUI.showToast(content);
        }
    }

    private onClickDetail(): void {
        we.currentUI.showSafe(HallViewId.BetNumRecordDlg);
    }

    private onContent2EditBoxDidBegin(): void {
        this.updateEditBoxShow();
    }

    private onContent2EditBoxDidEnd(): void {
        this.RC_menu_fast.index = -1;
        if (!we.common.withdrawMgr.config) {
            return;
        }
        const str = this.RC_edit_amount.string;
        let userEditCount = parseFloat(str) ? parseFloat(str) : 0;

        let canWithdrawAmount = we.common.withdrawMgr.getCanWithdrawAmount();
        let amount = 0;
        let tipsContent = '';
        userEditCount *= we.core.flavor.getAmountPrecision();
        if (userEditCount < we.common.withdrawMgr.minRangNum) {
            amount = we.common.withdrawMgr.minRangNum;
            tipsContent = we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7); // 请输入正确的格式
        } else {
            if (userEditCount > we.common.userMgr.userInfo.gold) {
                amount = canWithdrawAmount;
                tipsContent = we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS4); // 您的账户金额不足
            } else {
                if (userEditCount < we.common.withdrawMgr.minRangNum) {
                    amount = we.common.withdrawMgr.minRangNum;
                    tipsContent = we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20082, we.common.utils.formatAmount(we.common.withdrawMgr.minRangNum, false)); // 单次提现的金币不得低于
                } else if (userEditCount > we.common.withdrawMgr.maxRangNum) {
                    amount = we.common.withdrawMgr.maxRangNum;
                    tipsContent = we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS8, we.common.utils.formatAmount(we.common.withdrawMgr.maxRangNum, false)); // 单次提现的金币不得高于
                } else {
                    if (userEditCount > we.common.userMgr.userInfo.gold - we.common.withdrawMgr.config.remain) {
                        amount = canWithdrawAmount;
                        tipsContent = we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS3, we.common.utils.formatAmount(we.common.withdrawMgr.config.remain, false)); // 提现后的账户余额不得低于{0}
                    } else {
                        if (0 != userEditCount % we.common.withdrawMgr.config.minWithdrawUnit) {
                            amount = Math.floor(userEditCount / we.common.withdrawMgr.config.minWithdrawUnit) * we.common.withdrawMgr.config.minWithdrawUnit;
                        } else {
                            amount = userEditCount;
                        }
                        amount = amount > canWithdrawAmount ? canWithdrawAmount : amount; // 修正玩家当前提现数
                    }
                }
            }
        }

        if (tipsContent) {
            we.commonUI.showToast(tipsContent);
        }

        this.userEditRealAmount = amount;
        this.updateEditBoxShow();
        this.setOperationSt();
    }

    /**
     * 更新打码量
     */
    private onUpdateBetNum(): void {
        this.RC_lab_needBet.string = we.common.utils.formatAmount(we.common.withdrawMgr.config?.withdrawNeededScore, false);
        this.RC_lab_curBet.string = we.common.utils.formatAmount(we.common.withdrawMgr.config?.withdrawScore, false);
    }

    private updateEditBoxShow(): void {
        this.RC_edit_amount.string = this.userEditRealAmount / we.core.flavor.getAmountPrecision() + '';
        this.RC_edit_amount.textLabel.string = we.core.flavor.getCurrencySymbol() + we.common.utils.formatAmount(this.userEditRealAmount, false);
    }

    private setAccountShow() {
        let data = this.curAccountInfo;
        if (data && data.channelCode && data.account) {
            this.RCN_bankShow.active = true;
            this.RCN_bankEdit.active = false;

            // 提现渠道 icon
            let path = HallRes.texture.channelCode + data.channelCode;
            we.common.utils.setComponentSprite(this.RC_spr_icon, path);

            this.RC_lab_account.string = we.common.withdrawMgr.formatBankCardNum(String(data.account));
        } else {
            this.RCN_bankShow.active = false;
            this.RCN_bankEdit.active = true;
        }

        this.RCN_btnEdit.active = true;
    }

    // 提现金额范围
    private setWithdrawRangShow(): void {
        let beginAmount = we.common.utils.formatAmountCurrency(we.common.withdrawMgr.minRangNum);
        let endAmount = we.common.utils.formatAmount(we.common.withdrawMgr.maxRangNum, false);
        this.RC_lab_rang.string = ` ${beginAmount}-${endAmount}`;
    }

    // 设置快捷按钮
    private setFastBtn(): void {
        // 重置 UI 和选中数据
        this.selectFastAmount = 0;
        this.resetFastBtn();

        // 区分两种方式提现方式 常规/vip
        let conf = [];
        switch (this.withdrawType) {
            case we.common.withdrawMgr.WithdrawType.Normal:
                conf = we.common.withdrawMgr.geFastSupportAmounts(this.curAccountInfo?.channelCode);
                break;
            case we.common.withdrawMgr.WithdrawType.Vip:
                conf = we.common.withdrawMgr.config.vipAmounts || [];
                conf = conf.filter((v) => {
                    return !(v < we.common.withdrawMgr.minRangNum || v > we.common.withdrawMgr.maxRangNum);
                });
                break;
            default:
                break;
        }

        let children = this.RC_menu_fast.node.children;
        children.forEach((v, i) => {
            v.active = i < conf.length;
            if (v.active) {
                v.getComponent(WithdrawFastItem_v).amount = conf[i];
            }
        });
    }

    /**
     * 重置所有快捷按钮状态
     * 不控制隐藏
     */
    private resetFastBtn(): void {
        let children = this.RC_menu_fast.node.children;
        children.forEach((v, i) => {
            v.getComponent(WithdrawFastItem_v).setSelectStatus(false);
        });
    }

    private setSubmitSt(): void {
        this.RCN_sendWithdraw.active = false;
        this.RCN_sendWithdrawGray.active = true;

        // 表明未绑定提现账号
        if (!this.RCN_bankShow.active) {
            return;
        }

        // 用户可用提现额度是否可用于提现
        let maxWithdrawAmount = we.common.withdrawMgr.getCanWithdrawAmount();
        if (maxWithdrawAmount > 0) {
            let withdrawAmount = this.withdrawType == we.common.withdrawMgr.WithdrawType.Normal ? this.userEditRealAmount : this.selectFastAmount;
            let canSuccessWithdraw = maxWithdrawAmount >= withdrawAmount;
            if (canSuccessWithdraw && withdrawAmount >= we.common.withdrawMgr.minRangNum) {
                this.RCN_sendWithdraw.active = true;
                this.RCN_sendWithdrawGray.active = false;
            }
        }
    }

    // 设置操作按钮状态
    private setOperationSt(): void {
        if (!we.common.withdrawMgr.config) {
            return;
        }

        let maxAmount = we.common.withdrawMgr.getCanWithdrawAmount();
        // 减
        let enableSub = this.userEditRealAmount - we.common.withdrawMgr.config.unit >= we.common.withdrawMgr.minRangNum;
        this.RC_btn_sub.interactable = enableSub;
        // 加
        let enableAdd = this.userEditRealAmount + we.common.withdrawMgr.config.unit <= maxAmount;
        this.RC_btn_add.interactable = enableAdd;

        this.setSubmitSt();
    }

    /**
     * 两种 UI 状态
     * 1.默认提现状态 UI
     * 2.Vip 提现通道开启 UI
     */
    private setUIShowType(type: number): void {
        this.RCN_amount.active = type == we.common.withdrawMgr.WithdrawType.Normal;
        this.RCN_vipTips.active = type != we.common.withdrawMgr.WithdrawType.Normal;
    }

    public getGuideNode(): cc.Node {
        return this.RCN_bankEdit;
    }
}
