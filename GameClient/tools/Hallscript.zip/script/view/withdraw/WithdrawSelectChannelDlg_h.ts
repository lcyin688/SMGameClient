import { HallViewId } from '../HallViewId';
import WithdrawSelectChannelItem_h from './WithdrawSelectChannelItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawSelectChannelDlgView_h', we.bundles.hall)
class WithdrawSelectChannelDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawSelectChannelDlg_h', we.bundles.hall)
export class WithdrawSelectChannelDlg_h extends we.ui.DlgSystem<WithdrawSelectChannelDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        if (we.common.withdrawMgr.supportChannel) {
            this.addChannelItem();
        } else {
            we.common.withdrawMgr.getWithdrawChannel(() => {
                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }
                this.addChannelItem();
            });
        }
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private addChannelItem(): void {
        let serverSupport = we.common.withdrawMgr.supportChannel?.withDrawType || [];
        if (serverSupport.length < 1) {
            return;
        }

        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list.numItems = serverSupport.length;
    }

    protected onRenderEvent(item: cc.Node, i: number): void {
        let serverSupport = we.common.withdrawMgr.supportChannel.withDrawType || [];
        if (serverSupport.length > i) {
            item.getComponent(WithdrawSelectChannelItem_h)?.init(serverSupport[i]);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawSelectChannelDlg_h, `${HallViewId.WithdrawSelectChannelDlg}_h`)
class WithdrawSelectChannelDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawSelectChannelDlg_h, uiBase.addComponent(WithdrawSelectChannelDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawSelectChannelDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawSelectChannelDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawSelectChannelDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawSelectChannelDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawSelectChannelDlg_h).beforeUnload();
    }
}
