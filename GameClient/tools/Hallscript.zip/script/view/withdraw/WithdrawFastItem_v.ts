const { ccclass, property } = cc._decorator;

@ccclass
export default class WithdrawFastItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_select: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_unSelect: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_select: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_unSelect: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private _amount: number = 0;

    public get amount() {
        return this._amount;
    }

    public set amount(amount: number) {
        this._amount = amount;

        let str = we.common.withdrawMgr.formatAmount(amount);
        this.RC_lab_select.string = str;
        this.RC_lab_unSelect.string = str;
    }

    public setSelectStatus(select: boolean): void {
        this.__initRc();

        this.RCN_select.active = select;
        this.RCN_unSelect.active = !select;
    }
}
