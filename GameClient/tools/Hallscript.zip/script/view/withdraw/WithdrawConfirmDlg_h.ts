import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawConfirmDlgView_h', we.bundles.hall)
class WithdrawConfirmDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_account: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_fee: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawConfirmDlg_h', we.bundles.hall)
export class WithdrawConfirmDlg_h extends we.ui.DlgSystem<WithdrawConfirmDlgView_h> {
    private isRequestInterface: boolean = false;
    private withdrawReq: api.UserBankWithdrawReq = null;
    private isVipWithdraw: boolean = false;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.onConfirm, this));
    }

    /** 显示窗口 */
    public async onShow(data: api.UserBankWithdrawReq) {
        this.withdrawReq = data;
        if (!data) {
            return;
        }
        this.isVipWithdraw = data.orderType == we.common.withdrawMgr.WithdrawType.Vip;

        // 格式化 账号显示
        let info = we.common.withdrawMgr.getChannelInfoByCode(data.channelCode);
        if (info && data.account) {
            let account = '';
            if (we.core.flavor.getCountryCode() == we.core.CountryCode.br) {
                account = (info.code == we.common.payMgr.PAY_TYPE.PHONE_BRL ? `+${we.core.flavor.getCountryNum()}` : '') + data.account;
            } else if (we.core.flavor.getCountryCode() == we.core.CountryCode.in) {
                account = data.account;
            } else {
                let isDigitalPay = we.common.payMgr.isDigitalPay(info.code);
                account = (info.isBank || isDigitalPay ? '' : `+${we.core.flavor.getCountryNum()} `) + data.account;
            }
            this.view.RC_lab_account.string = account;
        }

        // 设置提现渠道 icon
        let path = HallRes.texture.channelCode + data.channelCode;
        we.common.utils.setComponentSprite(this.view.RC_spr_icon, path);

        // vip 提现无需手续费，普通提现正常收取
        let feeAmount = this.isVipWithdraw ? 0 : we.common.withdrawMgr.calculateWithdrawFee(data.amount);
        this.view.RC_lab_fee.string = we.common.utils.formatAmount(feeAmount, false);
        // 设置到账数显示
        let toAmount = data.amount - feeAmount;
        this.view.RC_lab_amount.string = we.common.utils.formatAmount(toAmount, false);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onConfirm(): void {
        if (this.isRequestInterface) {
            return;
        }
        this.isRequestInterface = true;

        this.positiveCallback();
    }

    private positiveCallback(): void {
        if (!this.withdrawReq) {
            return;
        }

        we.common.withdrawMgr.sendWithdrawReq(
            this.withdrawReq,
            (data: api.UserBankWithdrawResp) => {
                if (!we.common.userMgr.isLogin()) {
                    return;
                }

                if (data && data.success) {
                    let conf = we.common.withdrawMgr.config;
                    if (conf) {
                        if (!this.isVipWithdraw) {
                            conf.dailyWithdrawTime = conf.dailyWithdrawTime + 1 > conf.dailyWithdrawTimeLimit ? conf.dailyWithdrawTimeLimit : conf.dailyWithdrawTime + 1;
                        }

                        we.common.withdrawMgr.config.dailyWithdrawNum += this.withdrawReq.amount;
                        we.common.userMgr.onSyncUserCoinInfo();
                        we.common.userMgr.userInfo.gold = we.common.userMgr.userInfo.gold - this.withdrawReq.amount;
                        cc.director.emit(HallEvent.WITHDRAW_UPDATE_GOLD);
                    }
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS2));
                }

                we.currentUI.close(HallViewId.WithdrawDlg);

                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }
                this.closeView();
            },
            (code) => {
                this.errorCodeHandler(code);
                if (cc.isValid(this.view.uiRoot)) {
                    this.closeView();
                }
            }
        );
    }

    /**
     * 提现错误code处理
     * @param code
     */
    public errorCodeHandler(code: number): void {
        let content = null;
        let conf = we.common.withdrawMgr.config;
        if (conf) {
            if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_13) {
                content = we.core.langMgr.getLangText(HallLanguage.WITHDRAW_CODE_TIPS1);
            } else if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_9003) {
                content = we.core.langMgr.getLangText(HallLanguage.EVENT_FIRST_WITHDRAW_TIPS_1, 1);
            } else if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_9009) {
                content = we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_9009, we.common.utils.formatPrice(conf.rechargeThreshold));
            } else if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20082) {
                content = we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20082, conf.withdrawLower);
            } else if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20089) {
                content = we.core.langMgr.getLangText(HallLanguage.WITHDRAW__NEWTIPS6, conf.dailyWithdrawTimeLimit);
            } else if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20090) {
                content = we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20090, 1);
            } else if (
                code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20094 ||
                code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20095 ||
                code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20096
            ) {
                we.commonUI.showConfirm({
                    content: we.core.langMgr.getLangText(we.common.lang[`ERROR_USUAL_TYPE_${code}`]),
                    yesButtonName: we.core.langMgr.getLangText(HallLanguage.Withdrawal_USUAL_Btn1),
                    noButtonName: we.core.langMgr.getLangText(HallLanguage.Withdrawal_USUAL_Btn2),
                    noHandler: we.core.Func.create(() => {
                        we.currentUI.show(HallViewId.WithdrawSelectChannelDlg);
                    }, this),
                });
            }
        }

        if (content) {
            we.commonUI.showToast(`${content}: ${code}`);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawConfirmDlg_h, `${HallViewId.WithdrawConfirmDlg}_h`)
class WithdrawConfirmDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawConfirmDlg_h, uiBase.addComponent(WithdrawConfirmDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawConfirmDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawConfirmDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawConfirmDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawConfirmDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawConfirmDlg_h).beforeUnload();
    }
}
