import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class WithdrawRecordItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_account: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_cost: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_date: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_order: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_state: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_copy: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_copyRoot: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_operation: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_unreceived: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private orderType: number = we.common.withdrawMgr.WithdrawType.Normal;
    private orderInfo: api.BankWithdrawRecordItem = null;

    protected onLoad(): void {
        this.RCN_operation.active = false;
        this.RCN_receive.active = false;
        this.RCN_unreceived.active = false;

        this.onBtnClick(this.RCN_copyRoot, we.core.Func.create(this.onClickCopy, this)).setTransitionNone();
        this.onBtnClick(this.RCN_copy, we.core.Func.create(this.onClickCopy, this));
        this.onBtnClick(this.RCN_receive, we.core.Func.create(this.onClickReceive, this)).setSleepTime(5);
        this.onBtnClick(this.RCN_unreceived, we.core.Func.create(this.onClickUnReceive, this)).setSleepTime(5);
    }

    /**
     * 初始化提现订单记录
     * @param data  订单数据
     * @param orderType 订单类型
     */
    public init(data: api.BankWithdrawRecordItem, orderType: number) {
        this.orderInfo = data;
        this.orderType == orderType;

        let path = HallRes.texture.channelCode + data.channelCode;
        we.common.utils.setComponentSprite(this.RC_spr_icon, path);

        let info = we.common.withdrawMgr.getChannelInfoByCode(data.channelCode);
        this.RC_lab_account.string = data.eWalletPhone;
        if (info) {
            let isDigitalPay = we.common.payMgr.isDigitalPay(info.code);
            this.RC_lab_account.string = (info.isBank || isDigitalPay ? '' : `+${we.core.flavor.getCountryNum()} `) + data.eWalletPhone;
        }

        this.RCN_operation.active = false;
        this.RC_lab_date.string = we.common.utils.formatDate(new Date(data.createTime * 1000));
        this.RC_lab_order.string = data.orderId;
        this.RC_lab_amount.string = we.common.utils.formatAmountCurrency(data.gold);
        this.RC_lab_cost.string = we.common.utils.formatPrice(data.fee, true, false);

        /** 0待审核 1审核通过，提交第三方 2 审核人员已拒绝（人工拒绝） 3提交失败 4提现失败 5人工出款 6提现成功 7自动拒绝 20等待收款 21已冻结 */
        let index = we.common.payMgr.ORDER_STATUS.FAILED;
        let langKey = we.common.lang.ERROR_USUAL_TYPE_3003;
        switch (data.status) {
            case 0:
            case 20:
                index = we.common.payMgr.ORDER_STATUS.WAIT;
                langKey = HallLanguage.WiTHDRAW__RECORD_STATE0;
                break;
            case 1:
            case 5:
            case 21:
                index = we.common.payMgr.ORDER_STATUS.WAIT;
                langKey = HallLanguage.WiTHDRAW__RECORD_STATE1;
                break;
            case 6:
                index = we.common.payMgr.ORDER_STATUS.SUCCEEDED;
                langKey = HallLanguage.WiTHDRAW__RECORD_STATE6;
                break;
            default:
                break;
        }

        // 设置 vip 提现渠道操作按钮展示
        let extra = data.extra;
        if (extra) {
            this.RCN_receive.active = extra.receiveBtn;
            this.RCN_unreceived.active = extra.notReceiveBtn;

            this.RCN_operation.active = orderType == we.common.withdrawMgr.WithdrawType.Vip && (this.RCN_receive.active || this.RCN_unreceived.active);
        } else {
            this.RCN_operation.active = false;
        }
        this.RC_lab_state.string = we.core.langMgr.getLangText(langKey);
        this.RC_lab_state.node.getComponent(we.ui.WENodeColorIndex).setIndex(index);
    }

    private onClickCopy(): void {
        let str = this.RC_lab_order.string;
        if (str.length > 0) {
            we.core.nativeUtil.copyText(str);
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.COMMON_COPY_COMPLETE));
        }
    }

    private onClickReceive(): void {
        // 提示玩家谨慎操作，否则会导致不必要的损失
        if (this.orderType != we.common.withdrawMgr.WithdrawType.Vip) {
            we.commonUI.showConfirm({
                content: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_5),
                yesButtonName: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_7),
                noButtonName: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_8),
                isHideCloseBtn: false,
                yesHandler: we.core.Func.create(() => {
                    we.common.withdrawMgr.vipWithdrawReceivedReq(
                        this.orderInfo.orderId,
                        (data: api.VIPWithdrawReceivedResp) => {
                            if (data.success) {
                                cc.director.emit(HallEvent.WITHDRAW_UPDATE_ORDER_LIST);
                            }
                        },
                        null
                    );
                }),
                noHandler: we.core.Func.create(() => {}),
            });
        }
    }

    private onClickUnReceive(): void {
        // 提示玩家谨慎操作，点击后订单会进入冻结状态，请联系客服
        if (this.orderType != we.common.withdrawMgr.WithdrawType.Vip) {
            we.commonUI.showConfirm({
                content: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_6),
                yesButtonName: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_7),
                noButtonName: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_8),
                isHideCloseBtn: false,
                yesHandler: we.core.Func.create(() => {
                    we.common.withdrawMgr.vipWithdrawNotReceivedReq(
                        this.orderInfo.orderId,
                        (data: api.VIPWithdrawNotReceivedResp) => {
                            if (data.success) {
                                cc.director.emit(HallEvent.WITHDRAW_UPDATE_ORDER_LIST);
                            }
                        },
                        null
                    );

                    we.core.nativeUtil.copyText(this.orderInfo.orderId);
                    we.common.commonMgr.openCustomerDialog();
                }),
                noHandler: we.core.Func.create(() => {}),
            });
        }
    }
}
