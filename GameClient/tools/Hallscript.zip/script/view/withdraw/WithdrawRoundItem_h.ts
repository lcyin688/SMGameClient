const { ccclass, property } = cc._decorator;

@ccclass
export default class WithdrawRoundItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amountTitle: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_cost: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_costTitle: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_nick: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(initObj) {
        this.RC_lab_time.string = initObj.time;
        this.RC_lab_nick.string = initObj.nick;
        this.RC_lab_amountTitle.string = initObj.amountLeft;
        this.RC_lab_amount.string = initObj.amountRight;
        this.RC_lab_costTitle.string = initObj.costLeft;
        this.RC_lab_cost.string = initObj.costRight;
    }
}
