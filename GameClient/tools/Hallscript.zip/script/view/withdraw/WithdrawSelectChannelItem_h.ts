import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class WithdrawSelectChannelItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_range: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnAdd: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private withDrawType: api.WithDrawTypeList = null;

    protected onLoad() {
        this.onBtnClick(this.RCN_btnAdd, we.core.Func.create(this.onClickAdd, this));
    }

    public init(data: api.WithDrawTypeList): boolean {
        this.withDrawType = data;
        if (!data) {
            return;
        }

        // 设置支持提现范围显示
        let conf = we.common.withdrawMgr.config;
        if (conf) {
            let minAmount = Math.max(we.common.utils.amountToPrice(conf.withdrawLower), data.minAmount);
            let maxAmount = Math.min(we.common.utils.amountToPrice(conf.withdrawUpper), data.maxAmount);
            this.RC_lab_range.string = `${we.common.utils.formatPrice(minAmount, false, false)}-${we.common.utils.formatPrice(maxAmount, false, false)}`;
        }

        let path = HallRes.texture.channelCode + data.channelCode;
        we.common.utils.setComponentSprite(this.RC_spr_icon, path);
    }

    private onClickAdd() {
        we.currentUI.close(HallViewId.WithdrawSelectChannelDlg);

        // 检查是否绑定账号上限
        let enableNewAccount = we.common.withdrawMgr.judgeEnableNewAccount(this.withDrawType.channelCode);
        if (enableNewAccount) {
            let param = {} as api.UserBankInfo;
            param.channelCode = this.withDrawType.channelCode;
            param.channelType = this.withDrawType.code;
            HallMgr.openWithdrawAccountInfoDlg(param, true);
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_WINDOW_4));
        }
    }
}
