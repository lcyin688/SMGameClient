import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoBRDlgView_h', we.bundles.hall)
class WithdrawAccountInfoBRDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_cnp: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_cpf: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_email: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_name: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_phone: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phoneArea: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_cnpjInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirmGray: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_emailInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phoneInfo: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoBRDlg_h', we.bundles.hall)
export class WithdrawAccountInfoBRDlg_h extends we.ui.DlgSystem<WithdrawAccountInfoBRDlgView_h> {
    private bankInfo: api.UserBankInfo = null;
    private isAddAccount: boolean = true;
    private oldCpf: string = '';
    private oldCnpj: string = '';

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_edit_name.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_NAMED);
        this.view.RC_edit_cpf.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_CPFACT);
        this.view.RC_edit_cnp.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_ACTD);
        this.view.RC_edit_email.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_ACTD);
        this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_ACTD);

        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'editingDidBegan', we.core.Func.create(this.onNameEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'textChanged', we.core.Func.create(this.onNameEditBoxEditChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'editingDidEnded', we.core.Func.create(this.onNameEditBoxEditEnded, this));

        this.view.cc_onEditBoxEvent(this.view.RC_edit_cpf.node, 'editingDidBegan', we.core.Func.create(this.onCpfNumberEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_cpf.node, 'textChanged', we.core.Func.create(this.onCpfNumberEditBoxEditChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_cpf.node, 'editingDidEnded', we.core.Func.create(this.onCpfNumberEditBoxEditEnded, this));

        this.view.cc_onEditBoxEvent(this.view.RC_edit_cnp.node, 'editingDidBegan', we.core.Func.create(this.onCnpjNumberEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_cnp.node, 'textChanged', we.core.Func.create(this.onCnpjNumberEditBoxEditChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_cnp.node, 'editingDidEnded', we.core.Func.create(this.onCnpjNumberEditBoxEditEnded, this));

        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidBegan', we.core.Func.create(this.onPhoneNumberEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidEnded', we.core.Func.create(this.onPhoneNumberEditBoxEditEnded, this));

        this.view.cc_onEditBoxEvent(this.view.RC_edit_email.node, 'editingDidBegan', we.core.Func.create(this.onEmailNumberEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_email.node, 'editingDidEnded', we.core.Func.create(this.onEmailNumberEditBoxEditEnded, this));

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.onClickConfirm, this)).setSleepTime(1.5);
    }

    /** 显示窗口 */
    public async onShow(data: api.UserBankInfo, isAdd: boolean) {
        this.bankInfo = data;
        if (!data) {
            return;
        }
        this.isAddAccount = isAdd;

        this.view.RC_edit_cpf.string = data.cpf ?? '';
        this.view.RC_edit_name.string = data.userName ?? '';
        this.view.RCN_cnpjInfo.active = false;
        this.view.RCN_emailInfo.active = false;
        this.view.RCN_phoneInfo.active = false;
        switch (data.channelType) {
            case we.common.payMgr.PAY_TYPE.CNPJ_BRL:
                this.view.RC_edit_cnp.string = data.account ?? '';
                this.view.RCN_cnpjInfo.active = true;
                break;
            case we.common.payMgr.PAY_TYPE.EMAIL_BRL:
                this.view.RC_edit_email.string = data.account ?? '';
                this.view.RCN_emailInfo.active = true;
                break;
            case we.common.payMgr.PAY_TYPE.PHONE_BRL:
                this.view.RC_lab_phoneArea.string = `+${we.core.flavor.getCountryNum()}`;
                this.view.RC_edit_phone.string = data.account ?? '';
                this.view.RCN_phoneInfo.active = true;
                break;
            default:
                break;
        }

        // 提现渠道 icon
        let path = HallRes.texture.channelCode + data.channelCode;
        we.common.utils.setComponentSprite(this.view.RC_spr_icon, path);

        this.setConfirmBtn();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onNameEditBoxEditStarted() {
        this.view.RC_edit_name.placeholderLabel.string = '';
    }

    private onNameEditBoxEditChanged() {
        let str: string = this.view.RC_edit_name.string;
        if (str.length == 1 && str == ' ') {
            str = '';
        } else if (str.length > 0 && str[0] == ' ') {
            str = str.slice(1);
        } else if (str.length > 2 && str[str.length - 1] == ' ' && str[str.length - 2] == ' ') {
            str = str.slice(0, str.length - 1);
        }
        this.view.RC_edit_name.string = str;
        // @ts-ignore
        if (this.view.RC_edit_name && this.view.RC_edit_name._impl && this.view.RC_edit_name._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_name._impl._elem.value = str;
        }
    }

    private onNameEditBoxEditEnded() {
        let str: string = this.view.RC_edit_name.string;
        let removeSpace = () => {
            if (str[0] == ' ') {
                str = str.slice(1);
                removeSpace();
            }
        };
        removeSpace();
        if (str.length <= 0) {
            this.view.RC_edit_name.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_NAMED);
        } else {
            if (str[str.length - 1] == ' ') {
                str = str.slice(0, str.length - 1);
            }
        }
        this.view.RC_edit_name.string = str;
        // @ts-ignore
        if (this.view.RC_edit_name && this.view.RC_edit_name._impl && this.view.RC_edit_name._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_name._impl._elem.value = str;
        }
        this.setConfirmBtn();
    }

    private onCpfNumberEditBoxEditStarted() {
        this.view.RC_edit_cpf.placeholderLabel.string = '';
    }

    private onCpfNumberEditBoxEditChanged() {
        if (cc.sys.isNative) {
            return;
        }
        let str: string = this.view.RC_edit_cpf.string;
        if (str.length > this.oldCpf.length) {
            if (str.includes(' ')) {
                str = str.replace(/ /g, '');
            } else if (str.length == 3 && str[str.length - 1] !== '.') {
                str += '.';
            } else if (str.length == 4 && str[str.length - 1] !== '.') {
                str = str.slice(0, 3) + '.' + str.slice(3);
            } else if (str.length == 7 && str[str.length - 1] !== '.') {
                str += '.';
            } else if (str.length == 8 && str[str.length - 1] !== '.') {
                str = str.slice(0, 7) + '.' + str.slice(7);
            } else if (str.length == 11) {
                str += '-';
            } else if (str.length == 12) {
                str = str.slice(0, 11) + '-' + str.slice(11);
            }
            this.view.RC_edit_cpf.string = str;
            this.oldCpf = str;
            // @ts-ignore
            if (this.view.RC_edit_cpf && this.view.RC_edit_cpf._impl && this.view.RC_edit_cpf._impl._elem) {
                // @ts-ignore
                this.view.RC_edit_cpf._impl._elem.value = str;
            }
        } else {
            this.oldCpf = str;
        }
    }

    private onCpfNumberEditBoxEditEnded() {
        let str: string = this.view.RC_edit_cpf.string;
        str = this.formatAccount(str);
        if (str.length <= 0) {
            this.view.RC_edit_cpf.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_CPFACT);
        } else if (!this.isCpf(str)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
        }
        this.oldCpf = str;
        this.view.RC_edit_cpf.string = str;
        // @ts-ignore
        if (this.view.RC_edit_cpf && this.view.RC_edit_cpf._impl && this.view.RC_edit_cpf._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_cpf._impl._elem.value = str;
        }
        this.setConfirmBtn();
    }

    private onCnpjNumberEditBoxEditStarted() {
        this.view.RC_edit_cnp.placeholderLabel.string = '';
    }

    private onCnpjNumberEditBoxEditChanged() {
        if (cc.sys.isNative) {
            return;
        }
        let str: string = this.view.RC_edit_cnp.string;
        if (str.length > this.oldCnpj.length) {
            if (str.includes(' ')) {
                str = str.replace(/ /g, '');
            } else if (str.length == 2) {
                str += '.';
            } else if (str.length == 3) {
                str = str.slice(0, 2) + '.' + str.slice(2);
            } else if (str.length == 6) {
                str += '.';
            } else if (str.length == 7) {
                str = str.slice(0, 6) + '.' + str.slice(6);
            } else if (str.length == 10) {
                str += '/';
            } else if (str.length == 11) {
                str = str.slice(0, 10) + '/' + str.slice(10);
            } else if (str.length == 15) {
                str += '-';
            } else if (str.length == 16) {
                str = str.slice(0, 15) + '-' + str.slice(15);
            }
            this.view.RC_edit_cnp.string = str;
            this.oldCnpj = str;
            // @ts-ignore
            if (this.view.RC_edit_cnp && this.view.RC_edit_cnp._impl && this.view.RC_edit_cnp._impl._elem) {
                // @ts-ignore
                this.view.RC_edit_cnp._impl._elem.value = str;
            }
        } else {
            this.oldCnpj = str;
        }
    }

    private onCnpjNumberEditBoxEditEnded() {
        let str: string = this.view.RC_edit_cnp.string;
        str = this.formatCnpjAccount(str);
        if (str.length <= 0) {
            this.view.RC_edit_cnp.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_ACTD);
        } else if (!this.isCnpj(str)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
        }
        this.oldCnpj = str;
        this.view.RC_edit_cnp.string = str;
        // @ts-ignore
        if (this.view.RC_edit_cnp && this.view.RC_edit_cnp._impl && this.view.RC_edit_cnp._impl._elem) {
            // @ts-ignore
            this.view.RC_edit_cnp._impl._elem.value = str;
        }
        this.setConfirmBtn();
    }

    private onPhoneNumberEditBoxEditStarted() {
        this.view.RC_edit_phone.placeholderLabel.string = '';
    }

    private onPhoneNumberEditBoxEditEnded() {
        let str: string = this.view.RC_edit_phone.string;
        if (str.length <= 0) {
            this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_ACTD);
        } else if (!we.common.utils.isPhoneNumber(str)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
        }
        this.setConfirmBtn();
    }

    private onEmailNumberEditBoxEditStarted() {
        this.view.RC_edit_email.placeholderLabel.string = '';
    }

    private onEmailNumberEditBoxEditEnded() {
        let str: string = this.view.RC_edit_email.string;
        if (str.length <= 0) {
            this.view.RC_edit_email.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_ACTD);
        } else if (!we.common.utils.isEmail(str)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
        }

        this.setConfirmBtn();
    }

    private onClickConfirm(): void {
        // 判定是否有修改
        let nameStr = this.view.RC_edit_name.string;
        let cpfStr = this.view.RC_edit_cpf.string;
        let cnpjStr = this.view.RC_edit_cnp.string;
        let phoneStr = this.view.RC_edit_phone.string;
        let emailStr = this.view.RC_edit_email.string;
        if (this.bankInfo) {
            let isNotEdit = true;
            if (this.bankInfo.userName != nameStr || this.bankInfo.cpf != cpfStr) {
                isNotEdit = false;
            }
            if (this.bankInfo.channelType == we.common.payMgr.PAY_TYPE.CNPJ_BRL && this.bankInfo.account != cnpjStr) {
                isNotEdit = false;
            } else if (this.bankInfo.channelType == we.common.payMgr.PAY_TYPE.PHONE_BRL && this.bankInfo.account != phoneStr) {
                isNotEdit = false;
            } else if (this.bankInfo.channelType == we.common.payMgr.PAY_TYPE.EMAIL_BRL && this.bankInfo.account != emailStr) {
                isNotEdit = false;
            }

            if (isNotEdit) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_MODIFY_TEXT));
                return;
            }
        }

        let account: string = cpfStr;
        if (this.bankInfo.channelType == we.common.payMgr.PAY_TYPE.CNPJ_BRL) {
            account = cnpjStr;
        } else if (this.bankInfo.channelType == we.common.payMgr.PAY_TYPE.PHONE_BRL) {
            account = phoneStr;
        } else if (this.bankInfo.channelType == we.common.payMgr.PAY_TYPE.EMAIL_BRL) {
            account = emailStr;
        }

        this.changeBindInfo(account);
    }

    private changeBindInfo(account: string): void {
        let param = {} as api.UserBankWithdrawUpdateReq;
        param.operationType = this.isAddAccount ? 0 : 1;
        param.originalAccount = this.bankInfo?.account || '';
        let bindInfo = {} as api.UserBankInfo;
        bindInfo.account = account;
        bindInfo.channelType = this.bankInfo.channelType;
        bindInfo.channelCode = this.bankInfo.channelCode;
        bindInfo.userName = this.view.RC_edit_name.string;
        bindInfo.cpf = this.view.RC_edit_cpf.string;
        param.info = bindInfo;

        we.common.withdrawMgr.modifyWithdrawBindInfo(param, (data: api.UserBankWithdrawUpdateResp) => {
            if (data.suc) {
                // 无可用账号绑定成功时，需要更新提现主界面 绑定账号展示
                let isUpdateMainUI = we.common.withdrawMgr.accountList.length < 1;
                // 更新临时缓存账号信息
                we.common.withdrawMgr.updateAccountInfo(bindInfo, this.isAddAccount ? null : this.bankInfo);

                if (isUpdateMainUI) {
                    cc.director.emit(HallEvent.WITHDRAW_UPDATE_BANK_INFO, bindInfo, true);
                }

                cc.director.emit(HallEvent.WITHDRAW_UPDATE_ACCOUNT_LIST, bindInfo, this.isAddAccount);
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_TIPS_MODIFY_SUCCESS));

                if (cc.isValid(this.view.uiRoot)) {
                    this.closeView();
                }
            }
        });
    }

    private setConfirmBtn(): void {
        if (!this.bankInfo) {
            return;
        }

        let flag: boolean = true;
        if (this.view.RC_edit_name.string.length == 0) {
            flag = false;
        }
        let cpfStr = this.view.RC_edit_cpf.string;
        if (!this.isCpf(cpfStr)) {
            flag = false;
        }

        switch (this.bankInfo.channelType) {
            case we.common.payMgr.PAY_TYPE.CNPJ_BRL:
                if (!this.isCnpj(this.view.RC_edit_cnp.string)) {
                    flag = false;
                }
                break;
            case we.common.payMgr.PAY_TYPE.EMAIL_BRL:
                if (!we.common.utils.isEmail(this.view.RC_edit_email.string)) {
                    flag = false;
                }
                break;
            case we.common.payMgr.PAY_TYPE.PHONE_BRL:
                if (!we.common.utils.isPhoneNumber(this.view.RC_edit_phone.string)) {
                    flag = false;
                }
                break;
            default:
                break;
        }

        this.view.RCN_confirm.active = flag;
        this.view.RCN_confirmGray.active = !flag;
    }

    private isCpf(str: string): boolean {
        return /\d{3}\.\d{3}\.\d{3}-\d{2}/.test(str);
    }

    private isCnpj(str: string): boolean {
        return /\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}/.test(str);
    }

    private formatAccount(txt: string): string {
        let str: string = txt.replace(/\D/g, '');
        let strArr = [];
        for (let i = 0; i < Math.ceil(str.length / 3); i++) {
            strArr.push(str.substring(i * 3, i * 3 + 3));
        }
        for (let i = 0; i < strArr.length; i++) {
            if (i == 0) {
                str = strArr[i];
            } else if (i <= 2) {
                str += '.' + strArr[i];
            } else if (i == 3) {
                if (strArr[i].length == 3) {
                    strArr[i] = strArr[i].slice(0, 2);
                }
                str += '-' + strArr[i];
            }
        }
        return str;
    }

    private formatCnpjAccount(txt: string): string {
        let str: string = txt.replace(/\D/g, '');
        let strArr = [];
        str.substring(0, 2).length > 0 && strArr.push(str.substring(0, 2));
        str.substring(2, 5).length > 0 && strArr.push(str.substring(2, 5));
        str.substring(5, 8).length > 0 && strArr.push(str.substring(5, 8));
        str.substring(8, 12).length > 0 && strArr.push(str.substring(8, 12));
        str.substring(12, 14).length > 0 && strArr.push(str.substring(12, 14));
        for (let i = 0; i < strArr.length; i++) {
            if (i == 0) {
                str = strArr[0];
            } else if (i <= 2) {
                str += '.' + strArr[i];
            } else if (i == 3) {
                str += '/' + strArr[i];
            } else if (i == 4) {
                str += '-' + strArr[i];
            }
        }
        return str;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawAccountInfoBRDlg_h, `${HallViewId.WithdrawAccountInfoBRDlg}_h`)
class WithdrawAccountInfoBRDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawAccountInfoBRDlg_h, uiBase.addComponent(WithdrawAccountInfoBRDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoBRDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawAccountInfoBRDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoBRDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoBRDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawAccountInfoBRDlg_h).beforeUnload();
    }
}
