const { ccclass, property } = cc._decorator;

@ccclass
export default class BetNumRecordItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_betNumCharge: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_chargeNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_needBetNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_type: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: api.WithdrawScoreInfo): void {
        this.__initRc();

        if (data) {
            this.RC_lab_betNumCharge.string = we.common.utils.formatAmount(data.changeScore, false);
            this.RC_lab_chargeNum.string = we.common.utils.formatAmount(data.coin, false);
            this.RC_lab_needBetNum.string = we.common.utils.formatAmount(data.withdrawScore, false);
            this.RC_lab_time.string = we.common.utils.formatDate(new Date(data.timestamp * 1000)).replace(' ', '\n'); // '2023-10-09\n14:42:30'
            this.RC_lab_type.string = data.describe;
        }
    }
}
