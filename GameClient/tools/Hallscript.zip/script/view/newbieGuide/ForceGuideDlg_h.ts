import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import NewbieGuideMgr from '../../manager/NewbieGuideMgr';
import { HallDlg_h } from '../hall/HallDlg_h';
import { HallViewId } from '../HallViewId';
import { WithdrawDlg_h } from '../withdraw/WithdrawDlg_h';

const TimerTag = {
    autoClose: 'autoClose',
};

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('ForceGuideDlgView_h', we.bundles.hall)
class ForceGuideDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Widget)
    public RC_adaptN: cc.Widget = null;

    @we.ui.ccBind(cc.Node)
    public RC_arrow: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_arrowTip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_blockLayer: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_frame: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_arrowTip: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Mask)
    public RC_mask: cc.Mask = null;

    @we.ui.ccBind(cc.Widget)
    public RC_shadeBg: cc.Widget = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('ForceGuideDlg_h', we.bundles.hall)
export class ForceGuideDlg_h extends we.ui.DlgSystem<ForceGuideDlgView_h> {
    private curGuideConfig = null;
    private curStepConfig = null;
    private curGuideStep = 0;
    private modName: string = '';

    /** 注册UI事件 */
    public async registerUIEvent() {
        cc.director.on(we.common.EventName.UPDATE_GUIDE_STEP, this.updateGuideStep, this);
        cc.director.on(we.common.EventName.ON_HIDE_GUIDE, this.onHideGuide, this);
        cc.director.on(we.common.EventName.SHOW_GUIDE, this.showCurGuide, this);
        cc.view.on('canvas-resize', this.adaptWinResize, this);
    }

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(we.common.EventName.UPDATE_GUIDE_STEP, this.updateGuideStep, this);
        cc.director.off(we.common.EventName.ON_HIDE_GUIDE, this.onHideGuide, this);
        cc.director.off(we.common.EventName.SHOW_GUIDE, this.showCurGuide, this);

        cc.view.off('canvas-resize', this.adaptWinResize, this);
    }

    /** 显示窗口 */
    public async onShow(name: string) {
        this.modName = name;
        this.curGuideConfig = [];

        this.curGuideConfig = NewbieGuideMgr.modGuideConfig(name);
        this.curGuideStep = NewbieGuideMgr.CurModGuideStep;

        if (!this.curGuideConfig) {
            we.error(`ForceGuideDlg_h init , Cannot find gameGuideConfig in game : ${name}`);
        }

        this.curStepConfig = this.curGuideConfig[this.curGuideStep - 1];

        this.view.RC_blockLayer.active = true;
        this.view.RC_content.active = false;
        this.showCurGuide();

        NewbieGuideMgr.isGuiding = true;
        this.autoClose(8);
    }

    private async modifyStepConfig() {
        await this.scheduleOnce(0);
        let node: cc.Node = null;
        switch (this.curGuideStep) {
            case 1:
                node = we.currentUI.getDlg(HallDlg_h)?.view.RCN_withdraw;
                break;
            case 2:
                node = we.currentUI.getDlg(WithdrawDlg_h)?.view.RCN_bankEdit;
                break;
            default:
                break;
        }

        if (node && cc.isValid(node)) {
            const wPos: cc.Vec2 = node.convertToWorldSpaceAR(cc.v2(0, 0));
            const localPos: cc.Vec2 = this.view.RC_content.convertToNodeSpaceAR(wPos);
            const configPos: cc.Vec2 = this.curStepConfig.pos;
            const offsetPos = localPos.sub(configPos);
            this.curStepConfig.pos = this.curStepConfig.pos.add(offsetPos);
            this.curStepConfig.arrowPos = this.curStepConfig.arrowPos.add(offsetPos);
            this.curStepConfig.arrowTipPos = this.curStepConfig.arrowTipPos.add(offsetPos);
        }
    }

    private async showCurGuide() {
        await this.modifyStepConfig();
        this.autoClose();
        if (!this.curStepConfig) {
            we.error(`ForceGuideDlg_h showCurGuide , Cannot find curStepConfig in guideStep : ${this.curGuideStep}`);
            return;
        }

        this.view.RC_blockLayer.active = false;
        this.view.RC_content.active = true;

        let isAdapt = cc.view.getVisibleSize().width / cc.view.getVisibleSize().height > 1.8 ? true : false;
        // 特殊处理适配
        if (this.curStepConfig.widget && this.curStepConfig.widget.left) {
            this.view.RC_adaptN.isAbsoluteLeft = true;
            this.view.RC_adaptN.isAlignLeft = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left + this.curStepConfig.adaptNotch.left;
            } else {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left;
            }
        }
        if (this.curStepConfig.widget && this.curStepConfig.widget.right) {
            this.view.RC_adaptN.isAbsoluteRight = true;
            this.view.RC_adaptN.isAlignRight = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right + this.curStepConfig.adaptNotch.right;
            } else {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right;
            }
        }
        let arrowPosX = 0;
        let arrowTipPosX = 0;
        if (this.curStepConfig.needAdap) {
            // this.curStepConfig.needAdap = false;
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
            this.view.RC_adaptN.updateAlignment();
            arrowPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowPos.x;
            arrowTipPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowTipPos.x;
        } else {
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
        }

        this.view.RC_shadeBg.updateAlignment();

        // 光圈
        this.view.RC_frame.position = this.view.RC_adaptN.node.position;
        if (this.curStepConfig.size) {
            we.common.utils.setComponentSprite(this.view.RC_frame, HallRes.texture[this.curStepConfig.select_frame]);
            this.view.RC_frame.setContentSize(cc.size(this.curStepConfig.size.width + 28, this.curStepConfig.size.height + 28));
        }

        // 大小
        if (this.curStepConfig.size) {
            this.view.RC_mask.node.setContentSize(this.curStepConfig.size);
            // this.mask.type = cc.Mask.Type.RECT;
            this.view.RC_mask.type = cc.Mask.Type.IMAGE_STENCIL;
            this.loadAsset(HallRes.texture[this.curStepConfig.select_frame], cc.SpriteFrame).then((asset) => {
                this.view.RC_mask.spriteFrame = asset;
            });
        } else {
            this.view.RC_mask.type = cc.Mask.Type.ELLIPSE;
            this.view.RC_mask.node.setContentSize(cc.size(this.curStepConfig.visibleCircleRadius * 2, this.curStepConfig.visibleCircleRadius * 2));
        }

        // 箭头
        this.view.RC_arrow.active = this.curStepConfig.hasArrow;
        if (this.curStepConfig.hasArrow) {
            this.view.RC_arrow.stopAllActions();
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrow.position = cc.v2(arrowPosX, this.curStepConfig.arrowPos.y);
            } else {
                this.view.RC_arrow.position = this.curStepConfig.arrowPos;
            }
            this.view.RC_arrow.angle = this.curStepConfig.arrowAngle;
        }

        // 箭头文本
        if (this.curStepConfig.arrowLangKey) {
            this.view.RC_arrowTip.active = true;
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrowTip.position = cc.v2(arrowTipPosX, this.curStepConfig.arrowTipPos.y);
            } else {
                this.view.RC_arrowTip.position = this.curStepConfig.arrowTipPos;
            }
            this.view.RC_lab_arrowTip.string = we.core.langMgr.getLangText(HallLanguage[this.curStepConfig.arrowLangKey]);

            we.common.utils.setComponentSprite(this.view.RC_arrowTip, HallRes.texture[this.curStepConfig.textbg]);

            if ('text_bg1' == this.curStepConfig.textbg) {
                this.view.RC_lab_arrowTip.node.y = 0;
            } else {
                this.view.RC_lab_arrowTip.node.y = 8;
            }
        } else {
            this.view.RC_arrowTip.active = false;
        }
    }

    /**
     * 更新引导步骤继续引导
     */
    private updateGuideStep(): void {
        this.removeTimerByTag(TimerTag.autoClose);

        NewbieGuideMgr.CurModGuideStep = NewbieGuideMgr.CurModGuideStep + 1;
        we.common.userMgr.isNewbie = false;

        this.onHideGuide();
    }

    private onHideGuide() {
        NewbieGuideMgr.isGuiding = false;
        this.closeView();
    }

    private autoClose(time: number = 15): void {
        this.removeTimerByTag(TimerTag.autoClose);
        this.scheduleOnce(time, this, TimerTag.autoClose).then(() => {
            if (this.modName == NewbieGuideMgr.ModGuide.WITHDRAW) {
                NewbieGuideMgr.CurModGuideStep = NewbieGuideMgr.CurModGuideStep + 1;
            }
            we.log('ForceGuideDlg_h timeoutTimer, auto close!');
            cc.director.emit(we.common.EventName.ON_HIDE_GUIDE);
        });
    }

    private adaptWinResize() {
        this.modifyStepConfig();
        let isAdapt = cc.view.getVisibleSize().width / cc.view.getVisibleSize().height > 1.8 ? true : false;
        // 特殊处理适配
        if (this.curStepConfig.widget && this.curStepConfig.widget.left) {
            this.view.RC_adaptN.isAbsoluteLeft = true;
            this.view.RC_adaptN.isAlignLeft = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left + this.curStepConfig.adaptNotch.left;
            } else {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left;
            }
        }
        if (this.curStepConfig.widget && this.curStepConfig.widget.right) {
            this.view.RC_adaptN.isAbsoluteRight = true;
            this.view.RC_adaptN.isAlignRight = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right + this.curStepConfig.adaptNotch.right;
            } else {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right;
            }
        }
        let arrowPosX = 0;
        let arrowTipPosX = 0;
        if (this.curStepConfig.needAdap) {
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
            this.view.RC_adaptN.updateAlignment();
            arrowPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowPos.x;
            arrowTipPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowTipPos.x;
        } else {
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
        }
        this.view.RC_shadeBg.updateAlignment();
        // 光圈
        this.view.RC_frame.position = this.view.RC_adaptN.node.position;
        // 箭头
        if (this.curStepConfig.hasArrow) {
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrow.position = cc.v2(arrowPosX, this.curStepConfig.arrowPos.y);
            } else {
                this.view.RC_arrow.position = this.curStepConfig.arrowPos;
            }
        }
        // 箭头文本
        if (this.curStepConfig.arrowLangKey) {
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrowTip.position = cc.v2(arrowTipPosX, this.curStepConfig.arrowTipPos.y);
            } else {
                this.view.RC_arrowTip.position = this.curStepConfig.arrowTipPos;
            }
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(ForceGuideDlg_h, `${HallViewId.ForceGuideDlg}_h`)
class ForceGuideDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Fixed;
        uiBase.uiConfig.useBlockInput = we.ui.type.UseBlockInputType.None;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(ForceGuideDlg_h, uiBase.addComponent(ForceGuideDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ForceGuideDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<ForceGuideDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(ForceGuideDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ForceGuideDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(ForceGuideDlg_h).beforeUnload();
    }
}
