import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import NewbieGuideMgr from '../../manager/NewbieGuideMgr';
import { HallDlg_v } from '../hall/HallDlg_v';
import { HallViewId } from '../HallViewId';
import Withdraw_v from '../withdraw/Withdraw_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('ForceGuideDlgView_v', we.bundles.hall)
class ForceGuideDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Widget)
    public RC_adaptN: cc.Widget = null;

    @we.ui.ccBind(cc.Node)
    public RC_arrow: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_arrowTip: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_arrowTipLab: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_blockLayer: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Mask)
    public RC_mask: cc.Mask = null;

    @we.ui.ccBind(cc.Widget)
    public RC_shadeBg: cc.Widget = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

const TimerTag = {
    autoClose: 'autoClose',
};

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('ForceGuideDlg_v', we.bundles.hall)
export class ForceGuideDlg_v extends we.ui.DlgSystem<ForceGuideDlgView_v> {
    private curGuideConfig = null;
    private curStepConfig = null;
    private curGuideStep = 0;
    private modName: string = '';

    /** 注册UI事件 */
    public async registerUIEvent() {
        cc.director.on(we.common.EventName.UPDATE_GUIDE_STEP, this.updateGuideStep, this);
        cc.director.on(we.common.EventName.ON_HIDE_GUIDE, this.onHideGuide, this);
        cc.director.on(we.common.EventName.SHOW_GUIDE, this.showCurGuide, this);

        cc.view.on('canvas-resize', this.adaptWinResize, this);
    }

    /** 显示窗口 */
    public async onShow(name: string) {
        this.modName = name;
        this.curGuideConfig = [];

        this.curGuideConfig = NewbieGuideMgr.modGuideConfig(name);
        this.curGuideStep = NewbieGuideMgr.CurModGuideStep;

        if (!this.curGuideConfig) {
            we.error(`ForceGuideDlg_v init , Cannot find gameGuideConfig in game : ${name}`);
        }

        this.curStepConfig = this.curGuideConfig[this.curGuideStep - 1];

        this.view.RC_blockLayer.active = true;
        this.view.RC_content.active = false;
        this.showCurGuide();

        NewbieGuideMgr.isGuiding = true;
        this.autoClose(8);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    protected destroy(): void {
        cc.director.off(we.common.EventName.UPDATE_GUIDE_STEP, this.updateGuideStep, this);
        cc.director.off(we.common.EventName.ON_HIDE_GUIDE, this.onHideGuide, this);
        cc.director.off(we.common.EventName.SHOW_GUIDE, this.showCurGuide, this);

        cc.view.off('canvas-resize', this.adaptWinResize, this);
    }

    public beforeUnload() {}

    private async modifyStepConfig(): Promise<void> {
        await this.scheduleOnce(0);
        this.curStepConfig = we.npm.lodash.cloneDeep(this.curGuideConfig[this.curGuideStep - 1]);

        let node: cc.Node = null;
        switch (this.curGuideStep) {
            case 1:
                node = we.currentUI.getDlg(HallDlg_v)?.view?.RCN_btn_withdraw;
                break;
            case 2:
                node = we.currentUI.getDlg(HallDlg_v)?.view?.RC_withdraw?.children[0]?.getComponent(Withdraw_v)?.getGuideNode();
                break;
            default:
                break;
        }

        if (node && cc.isValid(node)) {
            const wPos: cc.Vec2 = node.convertToWorldSpaceAR(cc.v2(0, 0));
            const localPos: cc.Vec2 = this.view.RC_content.convertToNodeSpaceAR(wPos);
            const configPos: cc.Vec2 = this.curStepConfig.pos;
            const offsetPos = localPos.sub(configPos);
            this.curStepConfig.pos = this.curStepConfig.pos.add(offsetPos);
            this.curStepConfig.arrowPos = this.curStepConfig.arrowPos.add(offsetPos);
            this.curStepConfig.arrowTipPos = this.curStepConfig.arrowTipPos.add(offsetPos);
        }
    }

    private async showCurGuide(): Promise<void> {
        await this.modifyStepConfig();
        this.autoClose();
        if (!this.curStepConfig) {
            we.error(`ForceGuideDlg_v showCurGuide, Cannot find curStepConfig in guideStep : ${this.curGuideStep}`);
            return;
        }

        this.view.RC_blockLayer.active = false;
        this.view.RC_content.active = true;

        let isAdapt = cc.view.getVisibleSize().width / cc.view.getVisibleSize().height > 1.8 ? true : false;
        // 特殊处理适配
        if (this.curStepConfig.widget && this.curStepConfig.widget.left) {
            this.view.RC_adaptN.isAbsoluteLeft = true;
            this.view.RC_adaptN.isAlignLeft = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left + this.curStepConfig.adaptNotch.left;
            } else {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left;
            }
        }
        if (this.curStepConfig.widget && this.curStepConfig.widget.right) {
            this.view.RC_adaptN.isAbsoluteRight = true;
            this.view.RC_adaptN.isAlignRight = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right + this.curStepConfig.adaptNotch.right;
            } else {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right;
            }
        }
        let arrowPosX = 0;
        let arrowTipPosX = 0;
        if (this.curStepConfig.needAdap) {
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
            this.view.RC_adaptN.updateAlignment();
            arrowPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowPos.x;
            arrowTipPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowTipPos.x;
        } else {
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
        }

        this.view.RC_shadeBg.updateAlignment();

        // 大小
        if (this.curStepConfig.size) {
            this.view.RC_mask.node.setContentSize(this.curStepConfig.size);
            this.view.RC_mask.type = cc.Mask.Type.IMAGE_STENCIL;
            this.view.RC_mask.alphaThreshold = 0.1;
            if (this.curStepConfig.select_frame) {
                this.loadAsset(HallRes.texture[this.curStepConfig.select_frame], cc.SpriteFrame).then((asset) => {
                    this.view.RC_mask.spriteFrame = asset;
                });
            }
        } else {
            this.view.RC_mask.type = cc.Mask.Type.ELLIPSE;
            this.view.RC_mask.node.setContentSize(cc.size(this.curStepConfig.visibleCircleRadius * 2, this.curStepConfig.visibleCircleRadius * 2));
        }

        // 箭头
        this.view.RC_arrow.active = this.curStepConfig.hasArrow;
        if (this.curStepConfig.hasArrow) {
            this.view.RC_arrow.stopAllActions();
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrow.position = cc.v2(arrowPosX, this.curStepConfig.arrowPos.y);
            } else {
                this.view.RC_arrow.position = this.curStepConfig.arrowPos;
            }
            this.view.RC_arrow.angle = this.curStepConfig.arrowAngle;
        }

        // 箭头文本
        if (this.curStepConfig.arrowLangKey) {
            this.view.RC_arrowTip.active = true;
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrowTip.position = cc.v2(arrowTipPosX, this.curStepConfig.arrowTipPos.y);
            } else {
                this.view.RC_arrowTip.position = this.curStepConfig.arrowTipPos;
            }
            this.view.RC_arrowTipLab.string = we.core.langMgr.getLangText(HallLanguage[this.curStepConfig.arrowLangKey]);

            we.common.utils.setComponentSprite(this.view.RC_arrowTip, HallRes.texture[this.curStepConfig.textbg]);
        } else {
            this.view.RC_arrowTip.active = false;
        }
    }

    /**
     * 更新引导步骤继续引导
     */
    private updateGuideStep(): void {
        this.removeTimerByTag(TimerTag.autoClose);

        NewbieGuideMgr.CurModGuideStep = NewbieGuideMgr.CurModGuideStep + 1;
        we.common.userMgr.isNewbie = false;

        this.onHideGuide();
    }

    private onHideGuide(): void {
        this.closeView();
        NewbieGuideMgr.isGuiding = false;
    }

    private autoClose(time: number = 15): void {
        this.removeTimerByTag(TimerTag.autoClose);
        this.scheduleOnce(time, this, TimerTag.autoClose).then(() => {
            if (this.modName == NewbieGuideMgr.ModGuide.WITHDRAW) {
                NewbieGuideMgr.CurModGuideStep = NewbieGuideMgr.CurModGuideStep + 1;
            }
            we.log('ForceGuideDlg_v timeoutTimer, auto close!');
            cc.director.emit(we.common.EventName.ON_HIDE_GUIDE);
        });
    }

    private async adaptWinResize(): Promise<void> {
        await this.modifyStepConfig();
        let isAdapt = cc.view.getVisibleSize().width / cc.view.getVisibleSize().height > 1.8 ? true : false;
        // 特殊处理适配
        if (this.curStepConfig.widget && this.curStepConfig.widget.left) {
            this.view.RC_adaptN.isAbsoluteLeft = true;
            this.view.RC_adaptN.isAlignLeft = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left + this.curStepConfig.adaptNotch.left;
            } else {
                this.view.RC_adaptN.left = this.curStepConfig.widget.left;
            }
        }
        if (this.curStepConfig.widget && this.curStepConfig.widget.right) {
            this.view.RC_adaptN.isAbsoluteRight = true;
            this.view.RC_adaptN.isAlignRight = true;

            if (isAdapt && this.curStepConfig.adaptNotch.enable) {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right + this.curStepConfig.adaptNotch.right;
            } else {
                this.view.RC_adaptN.right = this.curStepConfig.widget.right;
            }
        }
        let arrowPosX = 0;
        let arrowTipPosX = 0;
        if (this.curStepConfig.needAdap) {
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
            this.view.RC_adaptN.updateAlignment();
            arrowPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowPos.x;
            arrowTipPosX = this.view.RC_adaptN.node.x + this.curStepConfig.arrowTipPos.x;
        } else {
            this.view.RC_adaptN.node.position = this.curStepConfig.pos;
        }
        this.view.RC_shadeBg.updateAlignment();
        // 箭头
        if (this.curStepConfig.hasArrow) {
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrow.position = cc.v2(arrowPosX, this.curStepConfig.arrowPos.y);
            } else {
                this.view.RC_arrow.position = this.curStepConfig.arrowPos;
            }
        }
        // 箭头文本
        if (this.curStepConfig.arrowLangKey) {
            if (this.curStepConfig.needAdap) {
                this.view.RC_arrowTip.position = cc.v2(arrowTipPosX, this.curStepConfig.arrowTipPos.y);
            } else {
                this.view.RC_arrowTip.position = this.curStepConfig.arrowTipPos;
            }
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(ForceGuideDlg_v, `${HallViewId.ForceGuideDlg}_v`)
class ForceGuideDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Fixed;
        uiBase.uiConfig.useBlockInput = we.ui.type.UseBlockInputType.None;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(ForceGuideDlg_v, uiBase.addComponent(ForceGuideDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ForceGuideDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<ForceGuideDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(ForceGuideDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ForceGuideDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(ForceGuideDlg_v).beforeUnload();
    }
}
