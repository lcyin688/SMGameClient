import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AppPermissionDlgView_h', we.bundles.hall)
class AppPermissionDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnNegative: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnPositive: cc.Node = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_message: cc.RichText = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AppPermissionDlg_h', we.bundles.hall)
export class AppPermissionDlg_h extends we.ui.DlgSystem<AppPermissionDlgView_h> {
    private permissionType: number = null;
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnNegative, we.core.Func.create(this.onClickNegative, this));
        this.view.cc_onBtnClick(this.view.RC_btnPositive, we.core.Func.create(this.onClickPositive, this));
    }

    /** 显示窗口 */
    public async onShow(type: number) {
        this.permissionType = type;

        let langKey = null;
        switch (type) {
            case HallMgr.Permission_Type.NOTIFICATION:
                langKey = HallLanguage.PERMISSIONS_AUTHORIZE_2;
                break;
            default:
                break;
        }

        if (langKey) {
            this.view.RC_rich_message.string = we.core.langMgr.getLangText(langKey);
        }
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Notice_Permission);
    }

    public beforeUnload() {}

    protected hideAnim(isAllow: boolean = false): void {
        this.closeView();

        switch (this.permissionType) {
            case HallMgr.Permission_Type.NOTIFICATION:
                we.kit.storage.setById('sys', 'app_permission_notification', isAllow ? '2' : '1');
                isAllow && we.core.nativeUtil.oneSignalRequestPermission();
                break;
            default:
                break;
        }
    }

    private onClickPositive(): void {
        this.hideAnim(true);
    }

    private onClickNegative(): void {
        this.hideAnim(false);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AppPermissionDlg_h, `${HallViewId.AppPermissionDlg}_h`)
class AppPermissionDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AppPermissionDlg_h, uiBase.addComponent(AppPermissionDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AppPermissionDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AppPermissionDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AppPermissionDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AppPermissionDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AppPermissionDlg_h).beforeUnload();
    }
}
