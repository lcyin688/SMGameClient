import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import JumpModMgr from '../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class IndependentItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_go: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_progress: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_target: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_taskTitle: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_lockMask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_login: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_over: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_progBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_progressBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_receive: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_task: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private taskData: api.TaskProgressDetail = null;

    protected onLoad(): void {
        this.onBtnClick(this.RC_go, we.core.Func.create(this.onClickGo, this));
        this.onBtnClick(this.RC_receive, we.core.Func.create(this.onClickReceive, this));
    }

    public init(taskIndex: number, taskLength: number, task: api.TaskProgressDetail): void {
        this.__initRc();

        if (!task) {
            return;
        }
        this.taskData = task;
        // 充值类型任务需要换算
        let isRechargeTask = task.typeEnum == we.common.activityMgr.TaskType.recharge;
        // 任务描述
        let langKey = null;
        switch (task.typeEnum) {
            case we.common.activityMgr.TaskType.login:
                langKey = HallLanguage.HOLIDAY_TASK_TYPE_3;
                break;
            case we.common.activityMgr.TaskType.recharge:
                langKey = HallLanguage.HOLIDAY_TASK_TYPE_1;
                break;
            case we.common.activityMgr.TaskType.betAmount:
                langKey = HallLanguage.NEW_Rebate_Bonus20;
                break;
            default:
                break;
        }
        if (langKey) {
            this.RC_lab_taskTitle.string = we.core.langMgr.getLangText(langKey);
        }
        // 总奖励
        this.RC_lab_award.string = we.common.utils.formatAmountCurrency(task.reward || 0);
        // 进度
        let showProgress = task.typeEnum != we.common.activityMgr.TaskType.login;
        this.RC_progressBg.active = showProgress;
        this.RC_progBg && (this.RC_progBg.active = showProgress);
        if (showProgress) {
            // this.RC_progressBar.fillRange = task.progress / task.target;
            let realProgress = task.progress > task.target ? task.target : task.progress;
            let progress = isRechargeTask ? we.common.utils.formatPrice(realProgress, false, true) : we.common.utils.formatAmount(realProgress);
            let target = isRechargeTask ? we.common.utils.formatPrice(task.target, false, true) : we.common.utils.formatAmount(task.target);
            this.RC_lab_progress.string = `${progress}`;
            this.RC_lab_target.string = `/${target}`;
        }
        // 状态
        this.RC_go.active = task.taskStatus == we.common.activityMgr.TaskStatus.ONGOING;
        let isCompleted = task.taskStatus == we.common.activityMgr.TaskStatus.COMPLETED;
        this.RC_receive.active = isCompleted;

        this.RC_over.active = task.taskStatus == we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
        this.RC_lockMask.active = task.taskStatus == we.common.activityMgr.TaskStatus.WAITING;
        // 金币icon
        // let iconIndex = this.getIconIndex(taskIndex, taskLength, this.RC_coin.maxIndex);
        // this.RC_coin.setIndex(iconIndex);
    }

    private onClickGo(): void {
        if (!we.common.independentMgr.isOpenAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
            cc.director.emit(we.common.EventName.CLOSE_INDEPENDENT_VIEW);
            return;
        }

        switch (this.taskData.typeEnum) {
            case we.common.activityMgr.TaskType.recharge:
                cc.director.emit(we.common.EventName.CLOSE_INDEPENDENT_VIEW);
                we.common.payMgr.trackFrom = we.common.JumpCmd.Independent;
                HallMgr.openStoreDlg();
                break;
            case we.common.activityMgr.TaskType.betAmount:
                if (we.core.gameConfig.isSubGame(we.common.gameMgr.getLastGameInfo()?.gameId)) {
                    cc.director.emit(we.common.EventName.CLOSE_INDEPENDENT_VIEW);
                    JumpModMgr.jumpToModule(we.common.gameMgr.getLastGameInfo()?.gameId + '');
                } else {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.QUICK_GAME_TIPS));
                }
                break;
            default:
                break;
        }
    }

    private onClickReceive(): void {
        if (!we.common.independentMgr.isOpenAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
            cc.director.emit(we.common.EventName.CLOSE_INDEPENDENT_VIEW);
            return;
        }

        let param = {} as api.DrawNewTaskAwardReq;
        param.level = this.taskData.level;
        param.taskType = we.common.activityMgr.ActivityType.independence;
        param.typeEnum = this.taskData.typeEnum;
        we.common.apiMgr.drawActivityAward(param, (data: api.DrawNewTaskAwardResp) => {
            if (data.drawAwardStatus == 1) {
                if (cc.isValid(this.node)) {
                    this.taskData.taskStatus = we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
                }

                let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.drawAwardNum }];
                HallMgr.openGetAwardsDlg(awardMap);

                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.independent, -1);
                cc.director.emit(we.common.EventName.UPDATE_INDEPENDENT_TASK);
            } else {
                we.common.activityMgr.getTaskAwardErrorHandle(data?.drawAwardStatus);
            }
        });
    }
}
