import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RebateRatioDetailDlgView_h', we.bundles.hall)
class RebateRatioDetailDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_content: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RebateRatioDetailDlg_h', we.bundles.hall)
export class RebateRatioDetailDlg_h extends we.ui.DlgSystem<RebateRatioDetailDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        let config = we.common.rebateCodeMgr.baseConfig.conf;
        let validBetList: number[] = [];
        config.forEach((item) => {
            item.rebateRates.forEach((bet) => {
                if (validBetList.indexOf(bet.validBet) == -1) {
                    validBetList.push(bet.validBet);
                }
            });
        });

        await this.initTableHead();
        await this.initTableBody(validBetList);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private async initTableHead() {
        const prefab = await this.loadAsset(HallRes.prefab.rebateRatioDetailItem, cc.Prefab);
        let head = cc.instantiate(prefab);
        head.children[0].getChildByName('lab').getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus31);
        let config = we.common.rebateCodeMgr.baseConfig.conf;
        for (let i = 0; i < config.length; i++) {
            let level = config[i].vipLevel;
            head.getChildByName('vip' + level).active = true;
            head.getChildByName('vip' + level).children[0].getComponent(cc.Label).string = 'VIP' + level;
        }
        this.view.RCN_content.addChild(head);
        this.view.RCN_content.width = head.children[0].width + config.length * head.children[1].width;
    }

    private async initTableBody(validBetList: number[]) {
        const prefab = await this.loadAsset(HallRes.prefab.rebateRatioDetailItem, cc.Prefab);
        let config = we.common.rebateCodeMgr.baseConfig.conf;
        for (let index = 0; index < validBetList.length; index++) {
            let node = cc.instantiate(prefab);
            node.children[0].getChildByName('lab').getComponent(cc.Label).string = we.common.utils.formatAmount(validBetList[index], false);
            config.forEach((item) => {
                for (let i = 0; i < item.rebateRates.length; i++) {
                    let itemNode: cc.Node = null;
                    if (index <= validBetList.length - 2 && item.rebateRates[i].validBet >= validBetList[i] && item.rebateRates[i].validBet < validBetList[index + 1]) {
                        itemNode = node.getChildByName('vip' + item.vipLevel);
                    } else if (index == validBetList.length - 1 && item.rebateRates[i].validBet >= validBetList[i]) {
                        itemNode = node.getChildByName('vip' + item.vipLevel);
                    }
                    if (cc.isValid(itemNode)) {
                        itemNode.active = true;
                        itemNode.getChildByName('lab').getComponent(cc.Label).string = item.rebateRates[i].rate / 100 + '%';
                    }
                }
            });
            this.view.RCN_content.addChild(node);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RebateRatioDetailDlg_h, `${HallViewId.RebateRatioDetailDlg}_h`)
class RebateRatioDetailDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RebateRatioDetailDlg_h, uiBase.addComponent(RebateRatioDetailDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateRatioDetailDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RebateRatioDetailDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(RebateRatioDetailDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateRatioDetailDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RebateRatioDetailDlg_h).beforeUnload();
    }
}
