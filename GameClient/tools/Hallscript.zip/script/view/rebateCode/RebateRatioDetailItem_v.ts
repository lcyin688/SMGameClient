import RebateBoxItem_v from './RebateBoxItem_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RebateRatioDetailItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
    /** 设置尺寸数组 */
    @property({
        type: [cc.Size],
        tooltip: CC_DEV && '设置尺寸数组',
        visible: true,
    })
    sizeArr: cc.Size[] = [new cc.Size(175, 48), new cc.Size(176, 48), new cc.Size(132, 48), new cc.Size(132, 48)];

    public init(strArr: string[], prefab: cc.Prefab): void {
        for (let i = 0; i < strArr.length; i++) {
            let groupItem: cc.Node = cc.instantiate(prefab);
            this.RC_content.addChild(groupItem);
            let comp = groupItem.getComponent(RebateBoxItem_v);
            if (comp) {
                let sizeTemp = this.sizeArr.length > i ? this.sizeArr[i] : this.sizeArr[this.sizeArr.length - 1];
                comp.init(strArr[i], sizeTemp);
            }
        }
    }
}
