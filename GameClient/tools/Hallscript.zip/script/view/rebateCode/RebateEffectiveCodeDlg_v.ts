import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import RebateCodeGameItem_v from './RebateCodeGameItem_v';
import RebateGroupItem_v from './RebateGroupItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RebateEffectiveCodeDlgView_v', we.bundles.hall)
class RebateEffectiveCodeDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips3: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips4: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_group: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_navigationBar: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_scroll: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RebateEffectiveCodeDlg_v', we.bundles.hall)
export class RebateEffectiveCodeDlg_v extends we.ui.DlgSystem<RebateEffectiveCodeDlgView_v> {
    /** 当前分组下标 */
    private curGroupIndex: number = 0;
    /** 当前游戏列表 */
    private curGameList: api.GameRebateRatioConfig[] = [];
    private groupKey: string[] = [];

    private font: cc.Font = null;
    private switchOffset: number = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lab_tips1.string = '1.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus21);
        this.view.RC_lab_tips2.string = '2.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus24);
        this.view.RC_lab_tips3.string = '3.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus27);
        this.view.RC_lab_tips4.string = '4.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus29);

        // 设置回掉函数
        this.view.RC_list_group.setRenderEvent(we.core.Func.create(this.onGroupRenderEvent, this));

        this.initNavigationBar();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    /**
     * 初始化导航条所有页签
     */
    private initNavigationBar() {
        this.groupKey = [...we.common.rebateCodeMgr.gameRatioMap.keys()];
        this.curGroupIndex = 0;

        this.view.RC_list_navigationBar.setRenderEvent(we.core.Func.create(this.onRenderGroupItem, this));
        this.view.RC_list_navigationBar.numItems = this.groupKey.length;

        this.view.RC_list_navigationBar.setSelectedEvent(we.core.Func.create(this.onSelectGroupItem, this));
        this.view.RC_list_navigationBar.selectedId = this.curGroupIndex;

        this.updateSwitchOffset();
    }

    private async updateSwitchOffset(): Promise<void> {
        await this.scheduleOnce(0);
        let menuItemWidth = this.view.RC_list_navigationBar.content.width / this.groupKey.length;
        let showMaxItem = Math.floor(this.view.RC_list_navigationBar.node.width / menuItemWidth);
        this.switchOffset = Math.max(showMaxItem - 1, 0);
    }

    private onRenderGroupItem(item: cc.Node, i: number): void {
        let itemComp = item.getComponent(RebateGroupItem_v);
        let showLine = i != this.groupKey.length - 1;
        itemComp?.init(i, this.groupKey[i], showLine);
    }

    private onSelectGroupItem(item: cc.Node, i: number): void {
        this.view.RC_list_navigationBar.scrollTo(i - this.switchOffset);
        this.curGroupIndex = i;
        this.showGameEntryList();
    }

    private showGameEntryList(): void {
        if (we.common.rebateCodeMgr.gameRatioMap.size > 0) {
            this.addGameItem();
        }
    }

    private async resetGameList(): Promise<void> {
        await this.scheduleOnce(0);
        let offset_cur = Math.abs(this.view.RC_list_group.scrollView.getScrollOffset().x);
        let time = offset_cur / 1200;
        this.view.RC_list_group.scrollView.scrollToLeft(time);
    }

    /** 添加子游戏入口 */
    private addGameItem(): void {
        if (!this.view.RC_list_group) {
            return;
        }
        this.resetGameList();
        this.curGameList = we.common.rebateCodeMgr.gameRatioMap.get(this.groupKey[this.curGroupIndex]);
        this.view.RC_list_group.numItems = this.curGameList.length;
    }

    private onGroupRenderEvent(item: cc.Node, index: number): void {
        let config: api.GameRebateRatioConfig = this.curGameList[index];
        this.initEntryItem(item, config);
        if (index >= 4) {
        }
    }

    private initEntryItem(node: cc.Node, config: api.GameRebateRatioConfig): void {
        if (!cc.isValid(node)) {
            return;
        }
        node.getComponent(RebateCodeGameItem_v).init(config, this.font);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RebateEffectiveCodeDlg_v, `${HallViewId.RebateEffectiveCodeDlg}_v`)
class RebateEffectiveCodeDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RebateEffectiveCodeDlg_v, uiBase.addComponent(RebateEffectiveCodeDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateEffectiveCodeDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RebateEffectiveCodeDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(RebateEffectiveCodeDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateEffectiveCodeDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RebateEffectiveCodeDlg_v).beforeUnload();
    }
}
