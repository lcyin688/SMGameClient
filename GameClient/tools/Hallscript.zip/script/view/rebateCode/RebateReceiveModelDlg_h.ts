import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RebateReceiveModelDlgView_h', we.bundles.hall)
class RebateReceiveModelDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_content: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_cancel: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RebateReceiveModelDlg_h', we.bundles.hall)
export class RebateReceiveModelDlg_h extends we.ui.DlgSystem<RebateReceiveModelDlgView_h> {
    private successCall: Function = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RCN_cancel, we.core.Func.create(this.onClickCancelBtn, this));
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.onClickConfirmBtn, this));
    }

    /** 显示窗口 */
    public async onShow(canReceive: boolean, successCall: Function) {
        this.initShow(canReceive, successCall);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    public initShow(canReceive: boolean, successCall: Function) {
        this.successCall = successCall;
        let context: string = null;
        if (canReceive) {
            context = we.core.langMgr.getLangText(HallLanguage.REBATE_BONUS_SAYA_TIPS_003);
        } else {
            context = we.core.langMgr.getLangText(HallLanguage.REBATE_BONUS_SAYA_TIPS_005, we.common.utils.formatAmount(we.common.rebateCodeMgr.baseConfig?.minRebateAmount, false));
        }
        this.view.RC_lab_content.string = context;
    }

    private onClickCancelBtn() {
        this.closeView();
    }

    private onClickConfirmBtn() {
        this.successCall?.();
        this.closeView();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RebateReceiveModelDlg_h, `${HallViewId.RebateReceiveModelDlg}_h`)
class RebateReceiveModelDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RebateReceiveModelDlg_h, uiBase.addComponent(RebateReceiveModelDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateReceiveModelDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RebateReceiveModelDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(RebateReceiveModelDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateReceiveModelDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RebateReceiveModelDlg_h).beforeUnload();
    }
}
