import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RebateCodeDlgView_h', we.bundles.hall)
class RebateCodeDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_bet_count: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_next_ratio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_rabate_ratio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_rebate_count: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_receive_rebate_count: cc.Label = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_bottom_tips: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_effective_help: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_enable: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_help: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_history: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_notice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rebateRatio_help: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RebateCodeDlg_h', we.bundles.hall)
export class RebateCodeDlg_h extends we.ui.DlgSystem<RebateCodeDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        we.common.commonMgr.appendVRedDotNode(this.view.RCN_notice).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.rebateCodeReceive, node: notice });
        });

        this.view.cc_onBtnClick(this.view.RCN_close, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_help, we.core.Func.create(this.onClickHelpBtn, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_history, we.core.Func.create(this.onClickHistoryBtn, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_receive, we.core.Func.create(this.onClickReceiveBtn, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_effective_help, we.core.Func.create(this.onClickBetHelpBtn, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_rebateRatio_help, we.core.Func.create(this.onClickRebateRatioHelpBtn, this)).setSleepTime(0.5);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lab_next_ratio.node.parent.active = false;
        this.view.RCN_enable.active = false;
        this.view.RCN_receive.active = false;

        we.common.rebateCodeMgr.getGameRebateRatioConfig();
        if (we.common.rebateCodeMgr.baseConfig) {
            this.setConfigViewDate();
            we.common.rebateCodeMgr.getRebateInfo(() => {
                if (cc.isValid(this.view.uiRoot)) {
                    this.setInit();
                }
            });
        } else {
            we.common.rebateCodeMgr.getRebateConfig(() => {
                if (cc.isValid(this.view.uiRoot)) {
                    this.setConfigViewDate();
                }
                we.common.rebateCodeMgr.getRebateInfo(() => {
                    if (cc.isValid(this.view.uiRoot)) {
                        this.setInit();
                    }
                });
            });
        }
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private setInit() {
        if (!we.common.rebateCodeMgr.rebateInfo) {
            return;
        }
        let _rebateInfo = we.common.rebateCodeMgr.rebateInfo;
        let _rebateConfig = we.common.rebateCodeMgr.baseConfig;
        this.view.RC_lab_receive_rebate_count.string = we.common.utils.formatAmountCurrency(_rebateInfo.unGetRebate, false);
        this.view.RC_lab_bet_count.string = we.common.utils.formatAmount(_rebateInfo.currentCircleBetAmount, false);
        this.view.RC_lab_rebate_count.string = we.common.utils.formatAmountCurrency(_rebateInfo.predictRebateAmount, false);
        let [curRetio, nextRatio] = this.getCurrentLevelRatio(_rebateInfo.currentCircleBetAmount);
        this.view.RC_lab_rabate_ratio.string = curRetio / 100 + '%';
        let bottomTipsText = we.core.langMgr.getLangText(_rebateConfig.cycle == 1 ? HallLanguage.NEW_Rebate_Bonus11 : HallLanguage.NEW_Rebate_Bonus39);
        let rich_bottom_time = we.core.langMgr.getLangText(HallLanguage.TIP_TIME_1);
        this.view.RC_rich_bottom_tips.setStringFormat(bottomTipsText, rich_bottom_time);
        // 下一个等级返利比例
        if (nextRatio == -1) {
            // 没有满足打码量，不显示下一个Vip等级返利比例
            this.view.RC_lab_next_ratio.node.parent.active = false;
        } else {
            this.view.RC_lab_next_ratio.node.parent.active = true;
            this.view.RC_lab_next_ratio.string = `${we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus8)}(VIP${we.common.userMgr.vipExp.level + 1}):` + nextRatio / 100 + '%';
        }
        // 可领取的值大于等于设置的可领取值额度时显示红点
        if (we.common.rebateCodeMgr.availableNum > 0 && we.common.rebateCodeMgr.availableNum >= we.common.rebateCodeMgr.baseConfig.minRebateAmount) {
            this.view.RCN_receive.active = true;
            this.view.RCN_enable.active = false;
            we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.rebateCodeReceive, 1, true);
        } else {
            this.view.RCN_enable.active = true;
            this.view.RCN_receive.active = false;
            we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.rebateCodeReceive, 0, false);
        }
    }

    private setConfigViewDate() {
        if (!we.common.rebateCodeMgr.baseConfig) {
            return;
        }

        let str2 = we.common.rebateCodeMgr.baseConfig.cycle == 1 ? HallLanguage.Withdrawal_USUAL_Btn1 : HallLanguage.NEW_Rebate_Bonus23;
        this.view.RCN_enable.children[0].getComponent(cc.Label).string = we.core.langMgr.getLangText(str2);
    }

    private onClickHelpBtn() {
        we.currentUI.show(HallViewId.RebateRuleDlg);
    }

    private onClickHistoryBtn() {
        we.currentUI.show(HallViewId.RebateRecordDlg);
    }

    private async onClickReceiveBtn() {
        let canReceive = we.common.rebateCodeMgr.availableNum >= we.common.rebateCodeMgr.baseConfig?.minRebateAmount;

        we.currentUI.show(HallViewId.RebateReceiveModelDlg, canReceive, () => {
            if (!canReceive) {
                return;
            }
            this.view.RCN_receive.active = false;
            we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.rebateCodeReceive, 0, false);
            we.common.rebateCodeMgr.userReceiveRebate(
                (data: api.UserRebateGetResp) => {
                    let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.rebate }];
                    HallMgr.openGetAwardsDlg(awardMap);
                    we.common.userMgr.onSyncUserCoinInfo();
                    if (cc.isValid(this.view.uiRoot)) {
                        this.view.RCN_enable.active = true;
                        we.common.rebateCodeMgr.getRebateInfo((isUpdate) => {
                            if (!isUpdate) {
                                return;
                            }
                            this.setInit();
                        });
                    }
                },
                () => {
                    this.view.RCN_receive.active = true;
                }
            );
        });
    }

    private onClickBetHelpBtn() {
        we.currentUI.show(HallViewId.RebateEffectiveCodeDlg);
    }

    private onClickRebateRatioHelpBtn() {
        we.currentUI.show(HallViewId.RebateRatioDetailDlg);
    }

    // 获取当前VIP等级和下一VIP等级的返利比例
    private getCurrentLevelRatio(betAmount: number): number[] {
        let config = we.common.rebateCodeMgr.baseConfig;
        let level = we.common.userMgr.vipExp.level;
        let curRatio: number = 0;
        let nextRatio: number = -1; // nextRatio默认值-1，表示没有满足打码量，没有返利比例
        config.conf.forEach((item) => {
            if (item.vipLevel == level) {
                item.rebateRates.sort((a, b) => {
                    return a.validBet - b.validBet;
                });
                item.rebateRates.forEach((rate) => {
                    if (betAmount != 0 && betAmount >= rate.validBet) {
                        curRatio = rate.rate;
                    }
                });
            }
            if (level < 10 && item.vipLevel == level + 1) {
                item.rebateRates.sort((a, b) => {
                    return a.validBet - b.validBet;
                });
                item.rebateRates.forEach((rate) => {
                    if (betAmount != 0 && betAmount >= rate.validBet) {
                        nextRatio = rate.rate;
                    }
                });
            }
        });
        return [curRatio, nextRatio];
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RebateCodeDlg_h, `${HallViewId.RebateCodeDlg}_h`)
class RebateCodeDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RebateCodeDlg_h, uiBase.addComponent(RebateCodeDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateCodeDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RebateCodeDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(RebateCodeDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateCodeDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RebateCodeDlg_h).beforeUnload();
    }
}
