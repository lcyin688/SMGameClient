import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('OfficialPkgAwardDlgView_v', we.bundles.hall)
class OfficialPkgAwardDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGet: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnNotice: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_awardLb: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_desc_0: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_desc_1: cc.Label = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_bet: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_recharge: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RCN_tips: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('OfficialPkgAwardDlg_v', we.bundles.hall)
export class OfficialPkgAwardDlg_v extends we.ui.DlgSystem<OfficialPkgAwardDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_btnGet.active = false;
        this.view.RC_btnNotice.active = false;
        this.view.RCN_tips.active = false;
        this.view.RC_lab_awardLb.string = '';

        this.view.RC_lab_desc_0.string = '1';
        this.view.RC_lab_desc_1.string = `= 1 ${we.core.flavor.getCurrencySymbol().trim()}`;

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnGet, we.core.Func.create(this.onClickReceive, this));
        this.view.cc_onBtnClick(this.view.RC_btnNotice, we.core.Func.create(this.onClickNotice, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        await we.common.activityMgr.getOfficialPkgBonusConf();

        this.initUI();
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Official_Award);
    }

    public beforeUnload() {}

    private initUI(): void {
        if (!we.common.activityMgr.getOfficialPkgIsAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.NEW_USER_FOYER_REWARD_TIPS2));
            this.closeView();
            return;
        }

        const officialPkgAward = we.common.activityMgr.officialPkgAward;

        this.view.RC_lab_awardLb.string = we.common.utils.formatAmount(officialPkgAward.bonus || 0);

        if (officialPkgAward.canReceive) {
            this.view.RC_btnNotice.active = true;
        } else {
            const recharge = officialPkgAward.getCondition?.recharge || 0;
            const bet = officialPkgAward.getCondition?.betAmount || 0;

            this.view.RC_rich_recharge.node.active = recharge > 0;
            this.view.RC_rich_recharge.setStringFormat(we.core.langMgr.getLangText(HallLanguage.FIRST_USE_APP_2), we.common.utils.formatPrice(recharge, false, false));

            this.view.RC_rich_bet.node.active = bet > 0;
            this.view.RC_rich_bet.setStringFormat(we.core.langMgr.getLangText(HallLanguage.FIRST_USE_APP_3), we.common.utils.formatAmount(bet, false));

            this.view.RCN_tips.active = recharge > 0 || bet > 0;
        }
    }

    private onClickReceive(): void {
        we.common.activityMgr.getOfficialPkgAward((data: api.ReceiveBonusResp) => {
            // // 领取状态  0 成功 1 领取首次使用指定app奖励开关未开启(活动未开启) 2 金币已领取 3 配置金额为0 4 非官方plt ... 具体状态不细分
            if (data.status == 0) {
                let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.bonus }];
                HallMgr.openGetAwardsDlg(awardMap);
            } else {
                let langKey = data.status == 2 ? HallLanguage.NEW_USER_FOYER_REWARD_TIPS1 : HallLanguage.NEW_USER_FOYER_REWARD_TIPS2;
                we.commonUI.showToast(we.core.langMgr.getLangText(langKey));
            }

            if (we.common.activityMgr.officialPkgAward) {
                we.common.activityMgr.officialPkgAward.canReceive = false;
                we.common.activityMgr.officialPkgAward.officialAppBonusSwitch = false;
                cc.director.emit(we.common.EventName.UPDATE_OFFICIAL_BAG_AWARD);
            }

            if (cc.isValid(this.view.uiRoot)) {
                this.closeView();
            }
        });
    }

    private onClickNotice(): void {
        this.view.RC_btnNotice.active = false;
        this.view.RC_btnGet.active = true;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(OfficialPkgAwardDlg_v, `${HallViewId.OfficialPkgAwardDlg}_v`)
class OfficialPkgAwardDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(OfficialPkgAwardDlg_v, uiBase.addComponent(OfficialPkgAwardDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(OfficialPkgAwardDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<OfficialPkgAwardDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(OfficialPkgAwardDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(OfficialPkgAwardDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(OfficialPkgAwardDlg_v).beforeUnload();
    }
}
