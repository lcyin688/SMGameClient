import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('PhoneBindScreenshotPromptDlgView_v', we.bundles.hall)
class PhoneBindScreenshotPromptDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_email: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_id: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phone: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_pwd: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_sprite_logo: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_capture: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_email: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_qrCode: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_save: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_simpan: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('PhoneBindScreenshotPromptDlg_v', we.bundles.hall)
export class PhoneBindScreenshotPromptDlg_v extends we.ui.DlgSystem<PhoneBindScreenshotPromptDlgView_v> {
    private isRegister: boolean = false;
    private closeNum: number = 0;
    private callFun: Function = null;
    private isCanSave: boolean = false;
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_simpan, we.core.Func.create(this.onClickSimpan, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_save, we.core.Func.create(this.onClickSave, this)).setSleepTime(1.5);
    }

    /**
     * 电话绑定成功截屏提示
     * @param data 透传账号信息
     * @param isRegister 是注册
     * @param callback 关闭回掉
     */
    public async onShow(param: { pwd: string; phone: string; email: string }, isRegister: boolean = false, callback: Function) {
        this.isCanSave = cc.sys.isNative && we.core.nativeUtil.getVersionCode() >= 216;
        this.view.RCN_save.active = this.isCanSave;
        this.view.RC_lab_id.string = '' + we.common.userMgr.userInfo.userId;

        this.loadAssetRemote(we.core.projectConfig.commonConfig.brandLogoUrl, cc.SpriteFrame).then((spf) => {
            this.view.RC_sprite_logo.spriteFrame = spf;
        });

        this.init(param, isRegister, callback);
    }

    /** 隐藏窗口 */
    public async onHide() {
        if (this.isRegister && we.core.projectConfig.settingsConfig?.funcSwitch?.bindPhonePopupSwitch) {
            cc.director.emit(we.common.EventName.JUMP_ACTION_CMD, we.common.JumpCmd.Join_Us);
        }
    }

    public beforeUnload() {}

    /**
     * @param param 是否是注册绑定
     * @param isRegister
     * @param callback
     */
    public init(param: { pwd: string; phone: string; email: string }, isRegister: boolean = false, callback: Function) {
        this.isRegister = isRegister;
        if (callback) {
            this.callFun = callback;
        }
        if (isRegister) {
            this.closeNum = this.isCanSave ? 0 : 3;
            this.view.RC_btnClose.active = false;
        } else {
            if (callback) {
                this.view.RC_btnClose.active = true;
            } else {
                this.view.RC_btnClose.active = false;
            }
        }

        this.view.RC_lab_name.string = we.common.userMgr.userInfo.userName;
        if (param) {
            this.view.RC_lab_pwd.string = param.pwd;
            this.view.RC_lab_phone.string = param.phone ?? we.common.userMgr.userInfo.phone;
            this.view.RC_lab_email.string = param.email ?? we.common.userMgr.userInfo.emailAccount;
        } else {
            this.view.RC_lab_phone.string = we.common.userMgr.userInfo.phone;
            this.view.RC_lab_email.string = we.common.userMgr.userInfo.emailAccount;
            let historyAccount = we.common.loginMgr.getCurLoginAccount();
            if (historyAccount) {
                this.view.RC_lab_pwd.string = historyAccount.password;
            }
            we.common.userMgr.isFirstRegister = false;
        }

        const phoneEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Phone);
        const emailEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Email);
        this.view.RCN_phone.active = phoneEnabled && this.view.RC_lab_phone.string.length > 0;
        this.view.RCN_email.active = emailEnabled && this.view.RC_lab_email.string.length > 0;

        let linkContent = we.core.projectConfig.settingsConfig?.officialUrlWithUid == undefined ? '' : we.core.projectConfig.settingsConfig?.officialUrlWithUid;
        if (linkContent.length > 0) {
            let cchn = we.core.projectConfig.settingsConfig?.cchn == undefined ? '' : we.core.projectConfig.settingsConfig?.cchn;
            let chnData = we.core.utils.base64Encode(cchn);
            let uidData = we.core.utils.base64Encode(we.common.userMgr.userInfo.userId.toString());
            let params = [`chn=${chnData}`, `id=${uidData}`];
            for (let i = 0; i < params.length; i++) {
                let key = params[i].split('=')[0];
                if (linkContent.includes(key + '=')) {
                    continue;
                }
                let oneParams = (linkContent.includes('?') ? '&' : '?') + params[i];
                if (0 === i && linkContent.includes('?')) {
                    oneParams = params[i];
                }
                linkContent = linkContent + oneParams;
            }
        }

        we.common.utils.generateQrCode(this.view.RCN_qrCode, linkContent, this.view.RCN_qrCode.color);

        if (!this.view.RC_lab_pwd.string) {
            this.view.RC_lab_pwd.string = '******';
        }
    }

    private onClickSimpan(event) {
        if (this.isCanSave) {
            this.callFun?.();
            this.closeView();
            return;
        }

        let data = {} as we.ICommonDialog;
        data.title = we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1);
        if (this.isRegister) {
            let msgTxt = '';
            if (this.closeNum == 3) {
                msgTxt = we.core.langMgr.getLangText(HallLanguage.GAME_ID_CARD_22);
            } else if (this.closeNum == 2) {
                msgTxt = we.core.langMgr.getLangText(HallLanguage.GAME_ID_CARD_23);
            } else if (this.closeNum == 1) {
                msgTxt = we.core.langMgr.getLangText(HallLanguage.GAME_ID_CARD_24);
            }

            we.commonUI.showConfirm({
                title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1),
                content: msgTxt,
                yesButtonName: we.core.langMgr.getLangText(HallLanguage.GAME_ID_CARD_12),
                yesHandler: we.core.Func.create(() => {
                    if (!cc.isValid(this.view.uiRoot)) {
                        return;
                    }
                    this.closeNum -= 1;
                    if (this.closeNum <= 0) {
                        this.closeView();
                    }
                }, this),
                noButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CANCEL),
            });
        } else {
            if (this.callFun) {
                we.commonUI.showConfirm({
                    title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1),
                    content: we.core.langMgr.getLangText(HallLanguage.GAME_ID_CARD_26),
                    yesButtonName: we.core.langMgr.getLangText(HallLanguage.GAME_ID_CARD_30),
                    yesHandler: we.core.Func.create(() => {
                        if (!cc.isValid(this.view.uiRoot)) {
                            return;
                        }
                        this.closeView();
                        if (this.callFun) {
                            this.callFun();
                        }
                    }, this),
                    noButtonName: we.core.langMgr.getLangText(HallLanguage.BTN_BACK),
                });
            } else {
                this.closeView();
            }
        }
    }

    private onClickSave(): void {
        if (!this.isCanSave) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.IDCARD_TIPS_2));
            return;
        }

        let dirPath = we.core.nativeUtil.getDownloadPath();
        let filePath = we.common.utils.captureImage(this.view.RCN_capture, 0, 0, dirPath);
        we.core.nativeUtil.addToMedia(filePath);
        we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.IDCARD_TIPS_1));
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(PhoneBindScreenshotPromptDlg_v, `${HallViewId.PhoneBindScreenshotPromptDlg}_v`)
class PhoneBindScreenshotPromptDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(PhoneBindScreenshotPromptDlg_v, uiBase.addComponent(PhoneBindScreenshotPromptDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhoneBindScreenshotPromptDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<PhoneBindScreenshotPromptDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(PhoneBindScreenshotPromptDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhoneBindScreenshotPromptDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(PhoneBindScreenshotPromptDlg_v).beforeUnload();
    }
}
