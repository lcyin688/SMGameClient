import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreBankItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    private RC_lab_limit: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    private RC_spr_icon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad() {
        const nodeGray = this.node.addComponentUnique(we.ui.WENodeGray);
        nodeGray.setGrayMaterial(we.common.res.material.gray);
    }

    public renderBank(data: api.Banks) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        const { name, minAmount } = data;
        this.RC_lab_limit.string = `${we.core.langMgr.getLangText(HallLanguage.GAME_WITHDRAWAL_TEXT_1)} ${we.common.utils.formatPrice(minAmount, false, false)}`;
        const bankIconPath = `${HallRes.texture.channelCode}${name}`;
        this.RC_spr_icon.spriteFrame = null;
        we.common.utils.setComponentSprite(this.RC_spr_icon, bankIconPath);
        this.setStyle(1);
    }

    public renderPay(data: api.VIPRechargeConfig) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.RC_spr_icon.spriteFrame = null;
        if (this.RC_spr_icon.node.active) {
            if (data.isBank) {
                this.RC_lab_limit.string = '';
                const bankIconPath = `${HallRes.texture.channelCode}${data.bankCode}`;
                we.common.utils.setComponentSprite(this.RC_spr_icon, bankIconPath);
            } else {
                const payTypeIconPath = `${HallRes.texture.payTypeIcon}${data.payType}`;
                we.common.utils.setComponentSprite(this.RC_spr_icon, payTypeIconPath);
            }
        }
        this.setStyle(0);
    }

    public renderPayType(data: api.RechargeTypeCategory) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        const { name, payType } = data;
        this.RC_spr_icon.spriteFrame = null;
        if (we.common.payMgr.isTestPay(payType)) {
            this.RC_lab_limit.node.active = true;
            this.RC_spr_icon.node.active = false;
            this.RC_lab_limit.string = name;
        } else {
            this.RC_lab_limit.node.active = false;
            this.RC_spr_icon.node.active = true;
            const bankIconPath = HallRes.texture.payTypeIcon + payType;
            we.common.utils.setComponentSprite(this.RC_spr_icon, bankIconPath);
        }
        this.setStyle(2);
    }

    public setStyle(index: number) {
        const styleIndex = this.node.addComponentUnique(we.ui.WERenderStyleIndex);
        styleIndex.index = index;
        this.node.getComponent(cc.Sprite).sizeMode = cc.Sprite.SizeMode.TRIMMED;
    }

    public setGray(status = false) {
        const nodeGray = this.node.addComponentUnique(we.ui.WENodeGray);
        nodeGray.setGray(status, true);
    }
}
