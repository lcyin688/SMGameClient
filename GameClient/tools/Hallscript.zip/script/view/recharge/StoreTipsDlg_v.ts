import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('StoreTipsDlgView_v', we.bundles.hall)
class StoreTipsDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnConfirm: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('StoreTipsDlg_v', we.bundles.hall)
export class StoreTipsDlg_v extends we.ui.DlgSystem<StoreTipsDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnConfirm, we.core.Func.create(this.onClickConfirm, this));
    }
    public onClickConfirm() {
        this.closeView();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(StoreTipsDlg_v, `${HallViewId.StoreTipsDlg}_v`)
class StoreTipsDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(StoreTipsDlg_v, uiBase.addComponent(StoreTipsDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreTipsDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<StoreTipsDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(StoreTipsDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreTipsDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(StoreTipsDlg_v).beforeUnload();
    }
}
