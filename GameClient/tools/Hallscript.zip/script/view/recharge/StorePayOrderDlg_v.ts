import { HallEvent } from '../../config/HallEvent';
import { HallViewId } from '../HallViewId';
import StoreOrderItem_v from './StoreOrderItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('StorePayOrderDlgView_v', we.bundles.hall)
class StorePayOrderDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_feedback: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_order: we.ui.List = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('StorePayOrderDlg_v', we.bundles.hall)
export class StorePayOrderDlg_v extends we.ui.DlgSystem<StorePayOrderDlgView_v> {
    private listData: api.OrderInfo[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_feedback, we.core.Func.create(this.onClickFeedback, this));
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.view.RC_list_order.setRenderEvent(we.core.Func.create(this.onRenderOrderItem, this));

        cc.director.on(HallEvent.RECHARGE_UPDATE_ORDER_LIST, this.onGetOrderList, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: api.OrderInfo[]) {
        this.listData = showData || [];
        this.view.RC_list_order.numItems = this.listData.length;
    }

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(HallEvent.RECHARGE_UPDATE_ORDER_LIST, this.onGetOrderList, this);
    }

    private onRenderOrderItem(node: cc.Node, index: number) {
        const data: api.OrderInfo = this.listData[index];
        const orderItem = node.addComponentUnique(StoreOrderItem_v);
        orderItem.initUI(data);
    }

    private onClickFeedback() {
        we.common.commonMgr.openCustomerDialog();
    }

    public onGetOrderList() {
        we.common.storeMgr.getOrderList((data: api.GetOrderListResp) => {
            if (!cc.isValid(this.view.uiRoot) || !data) {
                return;
            }
            this.listData = data.orderList || [];
            this.view.RC_list_order.numItems = this.listData.length;
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(StorePayOrderDlg_v, `${HallViewId.StorePayOrderDlg}_v`)
class StorePayOrderDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
        uiBase.uiConfig.closeTime = 0.36;
        uiBase.uiConfig.openTime = 0.36;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(StorePayOrderDlg_v, uiBase.addComponent(StorePayOrderDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StorePayOrderDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<StorePayOrderDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(StorePayOrderDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StorePayOrderDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(StorePayOrderDlg_v).beforeUnload();
    }
}
