import { HallRes } from '../../../config/HallRes';
import { HallViewId } from '../../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('NewbieGiftBagDlgView_v', we.bundles.hall)
class NewbieGiftBagDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnBuy: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_countdown: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_coin: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_original: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_price: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_proportion: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_proportion: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_withdraw: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_withdrawRoot: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('NewbieGiftBagDlg_v', we.bundles.hall)
export class NewbieGiftBagDlg_v extends we.ui.DlgSystem<NewbieGiftBagDlgView_v> {
    private leftTime: number = -1;
    private payChnList: api.RechargeTypeCategory[] = [];
    private goodsInfo: api.NewbieGiftPack = null;

    /** 是否进行下一个弹窗队列 */
    private canNextPopup: boolean = true;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnBuy, we.core.Func.create(this.onClickBuy, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        cc.director.on(we.common.EventName.CLOSE_FIRST_RECHARGE_DIALOG, this.closeViewByEvent, this); // 关闭首冲弹窗
        cc.director.on(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.showWithdraw, this); // 提现入口
        cc.director.on(we.common.EventName.JUMP_ACTION_CMD, this.closeView, this); // 显示提现
    }

    /** 显示窗口 */
    public async onShow(showData?: api.FirstRechargeConfResp) {
        if (!showData) {
            showData = we.common.storeMgr.newbieGift.gbData;
        }
        if (showData.gift?.length > 0) {
            this.goodsInfo = showData.gift[0];

            this.view.RC_lab_coin.string = we.common.utils.formatAmountCurrency(this.goodsInfo.originalPackage).replace(' ', '');
            this.view.RC_lab_price.string = we.common.utils.formatPrice(this.goodsInfo.price, true, false);
            this.view.RC_lab_original.string = we.common.utils.formatPrice(this.goodsInfo.originalPrice, true, false);
            // 折扣
            let proportion = ((this.goodsInfo.originalPrice - this.goodsInfo.price) / this.goodsInfo.price) * 100;
            this.view.RC_lab_proportion.string = Number(proportion.toFixed(1)) + '%';
        } else {
            this.closeView();
            return;
        }
        this.setCountdown();
        this.showWithdraw(we.common.withdrawMgr.judgeIsShowWithdraw());
        this.breath(this.view.RC_proportion);
    }

    protected closeViewByEvent(isClosePopup: boolean) {
        this.canNextPopup = isClosePopup;
        we.currentUI.close(HallViewId.NewbieGiftBagDlg);
    }

    /** 隐藏窗口 */
    public async onHide() {
        this.removeTimerById(this.leftTime);
    }

    public beforeUnload() {
        if (this.canNextPopup) {
            cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Newbie_Gift_Bag);
        }
    }

    protected destroy() {
        we.common.payMgr.trackFrom = '';
        cc.director.off(we.common.EventName.CLOSE_FIRST_RECHARGE_DIALOG, this.closeViewByEvent, this);
        cc.director.off(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.showWithdraw, this);
        cc.director.off(we.common.EventName.JUMP_ACTION_CMD, this.closeView, this);
    }

    /** 点击购买 */
    private onClickBuy(event): void {
        we.common.apiMgr.getActiveRechargeType(
            this.goodsInfo.id,
            (ptData: api.payTypeResp) => {
                we.common.storeMgr.newbieGift.ptData = ptData;

                if (cc.isValid(this.view.uiRoot)) {
                    this.payChnList = ptData.rechargeTypeCategory || [];
                    this.getActiveRechargeType(this.goodsInfo);
                }
            },
            (code) => {},
            true
        );
    }

    private showWithdraw(isShow: boolean) {
        if (isShow) {
            we.commonUI.createNode(HallRes.prefab.withdrawEntry, this.view.RC_withdraw, 0, false);
        }

        this.view.RC_withdrawRoot.active = isShow;
    }

    // 充值活动获取充值类型
    private getActiveRechargeType(goodsData: api.NewbieGiftPack): void {
        if (this.payChnList.length > 0) {
            let payType = this.payChnList[0].payType;
            if (this.payChnList.length == 1 && (we.common.payMgr.isStorePay(payType) || we.common.payMgr.isIntegrationPay(payType))) {
                we.common.payMgr.getOrderInfo(goodsData.id, payType);
            } else {
                we.currentUI.show(HallViewId.StorePayTypeDlg, { productData: goodsData, payTypeDataList: this.payChnList, price: goodsData.price });
            }
        }
    }

    private setCountdown(): void {
        const curData = new Date(we.core.TimeInfo.Inst.serverNow());
        const tempData = new Date(we.core.TimeInfo.Inst.serverNow() + 24 * 60 * 60 * 1000);
        const tomorrowData = new Date(tempData.getFullYear(), tempData.getMonth(), tempData.getDate());
        let interval = (tomorrowData.getTime() - curData.getTime()) / 1000;

        this.leftTime = this.schedule(1, () => {
            interval -= 1;
            if (cc.isValid(this.view.RC_lab_time)) {
                this.view.RC_lab_time.string = we.common.utils.formatSeconds(interval);
                if (interval <= 0) {
                    this.removeTimerById(this.leftTime);
                    this.view.RC_countdown.active = false;
                }
            } else {
                this.removeTimerById(this.leftTime);
            }
        });
    }

    /** 呼吸动画 */
    private breath(node: cc.Node, min = 0.95, max = 1.05) {
        this.tween(node).to(0.7, { scale: max }, { easing: 'sineOut' }).to(0.7, { scale: min }, { easing: 'sineIn' }).union().repeatForever().start();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(NewbieGiftBagDlg_v, `${HallViewId.NewbieGiftBagDlg}_v`)
class NewbieGiftBagDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(NewbieGiftBagDlg_v, uiBase.addComponent(NewbieGiftBagDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(NewbieGiftBagDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<NewbieGiftBagDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(NewbieGiftBagDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(NewbieGiftBagDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(NewbieGiftBagDlg_v).beforeUnload();
    }
}
