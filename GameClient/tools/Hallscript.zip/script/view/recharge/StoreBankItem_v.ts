import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreBankItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    private RC_lab_limit: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    private RC_spr_icon: cc.Sprite = null;
    /* =========================== AUTO CODE TOEND =========================== */

    public data: api.Banks;

    public init(data: api.Banks & { payType?: number }): void {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.data = data;

        const { name, minAmount } = data;
        this.RC_lab_limit.string = `${we.core.langMgr.getLangText(HallLanguage.GAME_WITHDRAWAL_TEXT_1)} ${we.common.utils.formatPrice(minAmount, false, false)}`;
        this.RC_spr_icon.node.active = !we.common.payMgr.isTestPay(data.payType);
        this.RC_spr_icon.spriteFrame = null;
        if (this.RC_spr_icon.node.active) {
            if (data.payType) {
                we.common.utils.setComponentSprite(this.RC_spr_icon, `${HallRes.texture.payTypeIcon}${data.payType}`);
            } else {
                we.common.utils.setComponentSprite(this.RC_spr_icon, `${HallRes.texture.channelCode}${name}`);
            }
        }
    }
}
