import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import StoreGoodsItem_h from './StoreGoodsItem_h';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreScratchCardsPay_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClear_scratch: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecharge_scratch: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_amount_scratch: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_giveAmount_scratch: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_goods_scratch: we.ui.List = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_realAmount: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_tips: we.ui.WERichTags = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private channelConf: api.RechargeTypeCategory = null;
    private rechargeAmount: number = 0; // 充值数量
    private curPayType: number = 0; // 支付类型

    protected onLoad(): void {
        this.RC_rich_realAmount.node.active = false;

        this.RC_list_goods_scratch.setRenderEvent(we.core.Func.create(this.onRenderGoodsItem, this));
        this.RC_list_goods_scratch.setSelectedEvent(we.core.Func.create(this.onSelectGoodsItem, this));
        this.onEditBoxEvent(this.RC_edit_amount_scratch.node, 'editingDidBegan', we.core.Func.create(this.onInputAmountBegin, this));
        this.onEditBoxEvent(this.RC_edit_amount_scratch.node, 'editingDidEnded', we.core.Func.create(this.onInputAmountEnd, this));
        this.onBtnClick(this.RC_btnRecharge_scratch, we.core.Func.create(this.onClickRecharge, this)).setSleepTime(1.5);
        this.onBtnClick(this.RC_btnClear_scratch, we.core.Func.create(this.onClickClearAmount, this));

        this.RC_rich_tips.setStringFormat(we.core.langMgr.getLangText(HallLanguage.TOPUP_WINDOW_4), ` ${we.core.langMgr.getLangText(HallLanguage.TOPUP_WINDOW_5)}`);

        this.RC_lab_giveAmount_scratch.string = we.common.storeMgr.formatPrice(0, true, true);

        const nodeGray = this.RC_btnRecharge_scratch.addComponentUnique(we.ui.WENodeGray);
        nodeGray.setGrayMaterial(we.common.res.material.gray);

        this.setRechargeBtnGray(false);
    }

    public initData(channelConf: api.RechargeTypeCategory): void {
        this.__initRc();

        if (!channelConf) {
            return;
        }

        this.channelConf = channelConf;
        this.curPayType = channelConf.payType;
        this.refreshUI();
    }

    private refreshUI(): void {
        if (!this.channelConf) {
            return;
        }

        this.setMinMaxAmount();
        this.setPreFilledAmount();

        this.RC_list_goods_scratch.numItems = this.channelConf.amounts.length;
    }

    private setMinMaxAmount(): void {
        if (!this.channelConf) {
            return;
        }
    }

    private setPreFilledAmount(): void {
        if (!this.channelConf) {
            return;
        }

        let amount = we.common.storeMgr.prefillAmount;
        if (amount > 0) {
            if (amount < this.channelConf.minAmount) {
                amount = this.channelConf.minAmount;
            } else if (amount > this.channelConf.maxAmount) {
                amount = this.channelConf.maxAmount;
            }

            this.setEditBoxAmount(amount);
        } else {
            this.setEditBoxAmount();
        }

        // 重置预填充充值数量
        we.common.storeMgr.prefillAmount = 0;
    }

    private onInputAmountBegin(): void {
        this.RC_edit_amount_scratch.placeholderLabel.string = ``;
    }

    private onInputAmountEnd(): void {
        let content = this.RC_edit_amount_scratch.string;
        let amount = parseInt(content);
        if (amount > 0) {
            this.setEditBoxAmount(amount * we.core.flavor.getPricePrecision());
        } else {
            this.setEditBoxAmount();
        }

        if (!this.channelConf) {
            return;
        }

        if (!(this.rechargeAmount >= this.channelConf.minAmount && this.rechargeAmount <= this.channelConf.maxAmount)) {
            this.setEditBoxAmount();
            if (content != ``) {
                let content = we.core.langMgr.getLangText(
                    HallLanguage.SHOP_RECHARGE_18,
                    we.common.utils.formatPrice(this.channelConf.minAmount, false, false),
                    we.common.utils.formatPrice(this.channelConf.maxAmount, false, false)
                );
                we.commonUI.showToast(content);
            }
        }
    }

    private setEditBoxAmount(amount: number = 0): void {
        this.rechargeAmount = amount;
        if (amount <= 0) {
            this.RC_edit_amount_scratch.string = ``;
        } else {
            this.RC_edit_amount_scratch.string = amount / we.core.flavor.getPricePrecision() + '';
            this.RC_edit_amount_scratch.textLabel.string = we.common.utils.formatPrice(this.rechargeAmount, true, false);
        }

        if (!this.channelConf) {
            return;
        }

        const { realAmount, feesDesc } = we.common.storeMgr.getScratchCardsFees(amount, this.channelConf);

        if (amount > 0 && realAmount != amount) {
            this.RC_rich_realAmount.node.active = true;
            this.RC_rich_realAmount.setStringFormat(we.core.langMgr.getLangText(HallLanguage.TOPUP_WINDOW_3), we.common.utils.formatPrice(realAmount, true, false), feesDesc);
        } else {
            this.RC_rich_realAmount.node.active = false;
        }

        this.setRechargeBtnGray(false);
        if (realAmount <= 0) {
            this.setRechargeBtnGray(true);
        }

        this.RC_edit_amount_scratch.placeholderLabel.string = `${we.common.utils.formatPrice(this.channelConf.minAmount, false, false)} ~ ${we.common.utils.formatPrice(this.channelConf.maxAmount, false, false)}`;
        this.renderGiveAwayAmount();

        const index = this.channelConf.amounts.findIndex((item) => {
            return item === amount;
        });
        if (this.RC_list_goods_scratch.selectedId === index) {
            return;
        }
        this.RC_list_goods_scratch.selectedId = index;
    }

    private renderGiveAwayAmount(): void {
        if (!this.channelConf) {
            return;
        }

        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(this.rechargeAmount, this.channelConf);
        const giveAmountStr = we.common.storeMgr.formatPrice(amountScale.amount, true, true);
        this.RC_lab_giveAmount_scratch.string = giveAmountStr;
    }

    private onRenderGoodsItem(node: cc.Node, idx: number) {
        const item = node.addComponentUnique(StoreGoodsItem_h);
        const amount = this.channelConf.amounts[idx];
        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(amount, this.channelConf);
        item.init(amount, amountScale);
    }

    private onSelectGoodsItem(node: cc.Node, idx: number) {
        const amount = this.channelConf?.amounts[idx];
        if (!amount) {
            return;
        }
        this.setEditBoxAmount(amount);
    }

    private onClickRecharge(): void {
        if (!this.channelConf) {
            return;
        }

        if (this.channelConf.formalRequired && !we.common.userMgr.isRealName()) {
            we.currentUI.show(HallViewId.UserCenterRealNameDlg);
            return;
        }

        if (this.rechargeAmount <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_17));
            return;
        }
        if (!(this.rechargeAmount >= this.channelConf.minAmount && this.rechargeAmount <= this.channelConf.maxAmount)) {
            const content = we.core.langMgr.getLangText(
                HallLanguage.SHOP_RECHARGE_18,
                we.common.utils.formatPrice(this.channelConf.minAmount, false, false),
                we.common.utils.formatPrice(this.channelConf.maxAmount, false, false)
            );
            we.commonUI.showToast(content);
            return;
        }

        we.common.storeMgr.CheckOrder(() => {
            // 发起订单请求
            let amount = (this.rechargeAmount / we.core.flavor.getPricePrecision()) * we.core.flavor.getAmountPrecision();
            we.common.payMgr.getOrderInfo(we.common.storeMgr.goodsId, this.curPayType, ``, amount);
        });
    }

    private onClickClearAmount(): void {
        this.setEditBoxAmount(0);
    }

    private setRechargeBtnGray(isActive: boolean = false): void {
        const nodeGray = this.RC_btnRecharge_scratch.getComponent(we.ui.WENodeGray);
        nodeGray.setGray(isActive, true);
        const btn = this.RC_btnRecharge_scratch.getComponent(cc.Button);
        btn.interactable = !isActive;
    }
}
