import { HallEvent } from '../../config/HallEvent';
import { HallViewId } from '../HallViewId';
import StoreOrderItem_h from './StoreOrderItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('StorePayOrderDlgView_h', we.bundles.hall)
class StorePayOrderDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnFeedback: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_order: we.ui.List = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('StorePayOrderDlg_h', we.bundles.hall)
export class StorePayOrderDlg_h extends we.ui.DlgSystem<StorePayOrderDlgView_h> {
    private listData: api.OrderInfo[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnFeedback, we.core.Func.create(this.onClickFeedback, this));
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.view.RC_list_order.setRenderEvent(we.core.Func.create(this.onRenderOrderItem, this));

        cc.director.on(HallEvent.RECHARGE_UPDATE_ORDER_LIST, this.onGetOrderList, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: api.OrderInfo[]) {
        this.listData = showData || [];
        this.view.RC_list_order.numItems = this.listData.length;
    }

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(HallEvent.RECHARGE_UPDATE_ORDER_LIST, this.onGetOrderList, this);
    }

    private onRenderOrderItem(node: cc.Node, index: number) {
        const data: api.OrderInfo = this.listData[index];
        const orderItem = node.addComponentUnique(StoreOrderItem_h);
        orderItem.initUI(data);
    }

    private onClickFeedback() {
        we.common.commonMgr.openCustomerDialog();
        this.closeView();
    }

    public onGetOrderList() {
        we.common.storeMgr.getOrderList((data: api.GetOrderListResp) => {
            if (!cc.isValid(this.view.uiRoot) || !data) {
                return;
            }
            this.listData = data.orderList || [];
            this.view.RC_list_order.numItems = this.listData.length;
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(StorePayOrderDlg_h, `${HallViewId.StorePayOrderDlg}_h`)
class StorePayOrderDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(StorePayOrderDlg_h, uiBase.addComponent(StorePayOrderDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StorePayOrderDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<StorePayOrderDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(StorePayOrderDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StorePayOrderDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(StorePayOrderDlg_h).beforeUnload();
    }
}
