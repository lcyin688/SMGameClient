const { ccclass, property } = cc._decorator;

@ccclass
export default class Marquee_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_desc: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_awards: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_game: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_user: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_head: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    /** 闪告 */
    private marqueeLoopTimer: number;

    protected onLoad(): void {
        this.RC_desc.active = false;
        this.updateMarqueeHandler();
        this.marqueeLoopTimer = we.core.timer.schedule(6, we.core.Func.create(this.updateMarqueeHandler, this));
    }

    protected onDestroy(): void {
        we.core.timer.removeById(this.marqueeLoopTimer);
    }

    private updateMarqueeHandler() {
        if (we.common.marqueeMgr.hideMarquee) {
            this.node.active = false;
            return;
        }
        const data = we.common.marqueeMgr.getMarqueeMsg();
        if (data) {
            // 设置值
            const broadData: we.common.IMarqueeData = JSON.parse(data.Template);
            const gold = broadData.Award || 0;
            const odds = broadData.Odds || 0;
            const avatar = broadData.Avatar;
            const userName = we.common.utils.formatNickname(broadData.UserName, 8);
            const gameName = we.core.langMgr.getLangText(we.common.lang['GAME_' + data.BroadCastType]);

            this.RC_desc.active = true;

            we.common.utils.setAvatarSprite(this.RC_spr_head, avatar, 1, false, true, true);

            this.RC_lab_game.string = gameName;
            this.RC_lab_user.string = userName;

            if (gold > 0) {
                this.RC_lab_awards.string = we.common.utils.formatAmountCurrency(gold, true);
            } else {
                this.RC_lab_awards.string = odds + ' x';
            }

            // 显示 + 刷新
            cc.Tween.stopAllByTarget(this.node);
            this.tween(this.node)
                .to(0.3, { y: 50, opacity: 100 }, { easing: 'cubicIn' })
                .set({ y: -50 })
                .call(() => {
                    this.node.active = true;
                    this.tween(this.node).to(0.3, { y: 0, opacity: 255 }, { easing: 'cubicOut' }).start();
                })
                .start();
        }
    }
}
