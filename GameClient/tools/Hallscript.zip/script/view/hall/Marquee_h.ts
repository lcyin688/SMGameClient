import { HallRes } from '../../config/HallRes';
import HallGameIconMgr from '../../manager/HallGameIconMgr';
import HallMgr from '../../manager/HallMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class Marquee_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(sp.Skeleton)
    public RC_anim: sp.Skeleton = null;

    @we.ui.ccBind(cc.Node)
    public RC_btn_game: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_gamename: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_gold: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_multiple: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_nickname_0: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_nickname_1: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_avatar: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_background: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_multiple: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_win: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private gameId: number = -1;
    private showTime: number = 5;
    private isShowingMarquee: boolean = false;
    private backgroundInitPos: cc.Vec2 = cc.v2(0, 0);
    private touchStartPosition: cc.Vec2 = cc.v2(0, 0);
    private touchDelta: number = 30;
    private isMoveBack: boolean = false;
    private touchStartInNode: boolean = false;
    private togoGameId: number = 0;

    protected onLoad() {
        this.RCN_win.active = false;
        this.RCN_multiple.active = false;
        this.isShowingMarquee = false;
        this.node.opacity = 0;
        this.backgroundInitPos = this.RCN_background.getPosition();

        this.RC_icon.node.active = true;
        this.RC_anim.node.active = true;
        this.RC_icon.node.opacity = 0;
        this.RC_anim.node.opacity = 0;

        cc.director.on(we.core.EventName.FULL_TOUCH_START, this.onFullTouchStart, this);
        cc.director.on(we.core.EventName.FULL_TOUCH_END, this.onFullTouchEnd, this);

        this.onBtnClick(this.RC_btn_game, we.core.Func.create(this.onGameIconClick, this)).setSleepTime(1.5);
        this.onBtnClick(this.RCN_background, we.core.Func.create(this.onBackgroundTouch, this)).setSleepTime(1.5);
    }

    protected onEnable() {
        this.RCN_background.x = this.backgroundInitPos.x + this.RCN_background.width;
    }

    protected update(dt) {
        this.updateHandler();
    }

    protected onDestroy(): void {
        cc.director.off(we.core.EventName.FULL_TOUCH_START, this.onFullTouchStart, this);
        cc.director.off(we.core.EventName.FULL_TOUCH_END, this.onFullTouchEnd, this);
    }

    private onFullTouchStart(e: cc.Touch) {
        if (!this.isShowingMarquee) {
            this.touchStartInNode = false;
            return;
        }
        const startPosition = e.getLocation();
        if (startPosition instanceof cc.Vec2) {
            this.touchStartPosition = startPosition;
            this.touchStartInNode = false;

            const worldPoint = startPosition;
            const worldBoundingBox = this.RCN_background.getBoundingBoxToWorld();
            if (!(worldPoint instanceof cc.Vec2) || !(worldBoundingBox instanceof cc.Rect)) {
                this.touchStartInNode = false;
            } else {
                if (this.pointInRect(worldPoint, worldBoundingBox)) {
                    this.touchStartInNode = true;
                } else {
                    this.touchStartInNode = false;
                }
            }
        }
    }

    private onFullTouchEnd(event) {
        if (!this.isShowingMarquee) {
            return;
        }
        const endPosition = event.getLocation();
        if (endPosition instanceof cc.Vec2) {
            let touchDeltaIsMeet = endPosition.x - this.touchStartPosition.x > this.touchDelta;
            if (this.touchStartInNode && touchDeltaIsMeet && !this.isMoveBack) {
                this.onBackgroundTouch();
            }
        }
    }

    private updateHandler() {
        if (we.common.marqueeMgr.hideMarquee || this.isShowingMarquee) {
            return;
        }

        let data = we.common.marqueeMgr.getMarqueeMsg();
        if (data) {
            this.isShowingMarquee = true;
            this.RCN_background.active = true;
        } else {
            this.isShowingMarquee = false;
            this.RCN_background.active = false;
            return;
        }

        this.initContent(data);
    }

    private pointInRect(point, rect: cc.Rect) {
        const vecs = [cc.v2(rect.x, rect.y), cc.v2(rect.x + rect.width, rect.y), cc.v2(rect.x + rect.width, rect.y + rect.height), cc.v2(rect.x, rect.y + rect.height)];
        return cc.Intersection.pointInPolygon(point, vecs);
    }

    private onGameIconClick(event) {
        const startPosition = event.getLocation();
        if (startPosition instanceof cc.Vec2) {
            let touchDeltaIsMeet = false;
            if (startPosition instanceof cc.Vec2) {
                touchDeltaIsMeet = Math.pow(startPosition.x - this.touchStartPosition.x, 2) + Math.pow(startPosition.y - this.touchStartPosition.y, 2) < Math.pow(this.touchDelta, 2);
            }

            const worldPoint = startPosition;
            const worldBoundingBox = this.RC_btn_game.getBoundingBoxToWorld();
            if (touchDeltaIsMeet && worldPoint instanceof cc.Vec2 && worldBoundingBox instanceof cc.Rect && this.pointInRect(worldPoint, worldBoundingBox)) {
                event && event.stopPropagation && event.stopPropagation();

                if (we.core.gameConfig.isSubGame(this.togoGameId)) {
                    if (!HallMgr.canEnterSubGame(this.togoGameId)) {
                        return;
                    }
                    we.common.gameMgr.runGame(this.togoGameId);
                }
            }
        }
    }

    private onBackgroundTouch() {
        if (cc.isValid(this.RCN_background)) {
            this.RCN_background.stopAllActions();
            this.isShowingMarquee = true;
            const backgroundX = this.backgroundInitPos.x + this.RCN_background.width;
            const moveTime = (0.6 * (backgroundX - this.RCN_background.x)) / this.RCN_background.width;

            this.tween(this.RCN_background)
                .call(() => {
                    this.isMoveBack = true;
                    this.isShowingMarquee = true;
                })
                .to(moveTime, { position: cc.v3(backgroundX, 0) })
                .call(() => {
                    this.isMoveBack = false;
                    this.isShowingMarquee = false;
                })
                .start();
        }
    }

    private initContent(data: naming.BroadCastNT): void {
        this.togoGameId = data.BroadCastType;
        this.RCN_win.active = false;
        this.RCN_multiple.active = false;

        this.setGameIcon(data.BroadCastType);

        const broadData: we.common.IMarqueeData = JSON.parse(data.Template);

        this.RC_lab_nickname_0.string = we.common.utils.formatNickname(broadData.UserName, 8);
        this.RC_lab_nickname_1.string = we.common.utils.formatNickname(broadData.UserName, 8);

        let gold = broadData.Award || 0;
        let odds = broadData.Odds || 0;
        if (gold > 0) {
            this.RC_lab_gold.string = we.common.utils.formatAmountCurrency(gold, true);
        } else {
            this.RC_lab_multiple.string = odds + ' x';
        }

        this.RCN_win.active = gold > 0;
        this.RCN_multiple.active = !this.RCN_win.active;

        const successCallback = () => {
            if (!cc.isValid(this.RC_spr_avatar)) {
                this.isShowingMarquee = false;
                this.isMoveBack = false;
                return;
            }

            if (this.RCN_background.getComponent(cc.Widget)) {
                this.RCN_background.removeComponent(cc.Widget);
            }
            this.scheduleOnce(() => {
                this.RCN_background.stopAllActions();
                this.isShowingMarquee = true;
                this.RCN_background.x = this.backgroundInitPos.x + this.RCN_background.width;
                this.tween(this.RCN_background)
                    .call(() => {
                        this.node.opacity = 255;
                    })
                    .by(0.6, { position: cc.v3(-1 * this.RCN_background.width, 0) })
                    .delay(this.showTime - 0.6 * 2)
                    .call(() => {
                        this.isMoveBack = true;
                    })
                    .by(0.6, { position: cc.v3(1 * this.RCN_background.width, 0) })
                    .call(() => {
                        this.isShowingMarquee = false;
                        this.isMoveBack = false;
                    })
                    .start();
            });
        };

        const failedCallback = () => {
            if (!cc.isValid(this.node)) {
                return;
            }

            this.RCN_background.stopAllActions();
            this.isShowingMarquee = false;
            this.isMoveBack = false;
            this.RCN_background.x = this.backgroundInitPos.x + this.RCN_background.width;
        };

        this.initHandler(broadData.Avatar)
            .then(successCallback)
            .catch(() => {
                failedCallback();
            });
    }

    private async initHandler(avatar: string) {
        return new Promise((resolve, reject) => {
            we.common.utils.setAvatarSprite(this.RC_spr_avatar, avatar, 1, false, true, true, resolve, reject);
        });
    }

    private setGameIcon(id: number): void {
        this.gameId = id;
        this.RC_lab_gamename.string = we.common.gameMgr.getGameEntryName(id, false);
        this.RC_icon.node.opacity = 0;
        this.RC_anim.node.opacity = 0;

        HallGameIconMgr.loadIcon({
            gameId: id,
            isBig: false,
            anim: this.RC_anim,
            image: this.RC_icon,
            self: this,
        });
    }
}
