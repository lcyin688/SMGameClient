const { ccclass, property } = cc._decorator;

@ccclass
export default class QuestionNaireEntry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickEntry, this));
    }

    private onClickEntry(): void {
        if (we.common.activityMgr.questionNaireConf?.enable) {
            let url = we.common.activityMgr.questionNaireConf.url;
            if (typeof url == 'string' && url.length > 0) {
                let data = `uid=${we.common.userMgr.userInfo.userId}&lang=${we.core.langMgr.getCurLangCode()}&country=${we.common.userMgr.userInfo.country}`;
                url = url + `?${we.core.utils.base64Encode(data)}`;
                we.core.nativeUtil.openUrl(url);
            }
        }
    }
}
