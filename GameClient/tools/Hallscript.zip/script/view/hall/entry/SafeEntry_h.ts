const { ccclass, property } = cc._decorator;

@ccclass
export default class SafeEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));
    }

    private onClick(): void {
        we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
    }
}
