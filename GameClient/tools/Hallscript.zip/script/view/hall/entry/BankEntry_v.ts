import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class BankEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickBank, this));
    }

    private onClickBank(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Bank);
    }
}
