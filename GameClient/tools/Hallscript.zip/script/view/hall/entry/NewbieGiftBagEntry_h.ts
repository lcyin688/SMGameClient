import { HallLanguage } from '../../../const/HallLanguage';
import HallMgr from '../../../manager/HallMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewbieGiftBagEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_addition: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickOpen, this));
        cc.director.on(we.common.EventName.GIFT_BAG_UPDATE, this.updateUI, this);
    }

    protected onEnable() {
        this.updateUI();
    }

    protected onDestroy(): void {
        cc.director.off(we.common.EventName.GIFT_BAG_UPDATE, this.updateUI, this);
    }

    /**
     * 新手礼包
     */
    private onClickOpen(): void {
        HallMgr.openNewbieGiftBag(true);
    }

    private updateUI() {
        if (!cc.isValid(this.node)) {
            return;
        }
        const data = we.common.storeMgr.newbieGift?.gbData;
        // 活动未开启时提示，活动已关闭，请下次再来
        if (!data?.switch) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_44));
            return;
        }
        if (!data.isBuy && data.gift?.length > 0) {
            this.setAddition(data.gift[0]);
        }
    }

    private setAddition(goodsInfo: api.NewbieGiftPack): void {
        if (!goodsInfo) {
            return;
        }
        const addRatio = ((goodsInfo.originalPrice - goodsInfo.price) / goodsInfo.price) * 100;
        this.RC_lab_addition.string = `+${parseInt(addRatio + '')}%`;
    }
}
