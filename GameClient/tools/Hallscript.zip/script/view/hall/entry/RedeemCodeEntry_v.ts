import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RedeemCodeEntry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickCarnival, this));
    }

    private onClickCarnival(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Gift_Code);
    }
}
