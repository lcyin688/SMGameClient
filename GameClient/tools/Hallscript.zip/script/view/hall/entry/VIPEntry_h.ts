import JumpModMgr from '../../../manager/JumpModMgr';
import { HallViewId } from '../../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class VIPEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickVIP, this));
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vip, node: this.node.getChildByName('notice') });
    }

    private onClickVIP(): void {
        we.currentUI.show(HallViewId.VipViewDlg);
    }
}
