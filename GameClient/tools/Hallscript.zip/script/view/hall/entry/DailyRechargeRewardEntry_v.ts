import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class DailyRechargeRewardEntry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_addition: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_countdown: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_desc: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_addition: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private isStartCountdown: boolean = false;
    private leftTime: number = 0;

    protected onLoad(): void {
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.dailyRecharge, node: this.node.getChildByName('notice') });

        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this)).setSleepTime(0.5);

        cc.director.on(we.core.EventName.GAME_SHOW, this.onGameShow, this);
        cc.director.on(we.common.EventName.UPDATE_DAILY_RECHARGE, this.setBtnStatus, this);

        this.setBtnStatus();
    }

    protected onEnable(): void {
        this.setBtnStatus();
    }

    protected update(dt: number): void {
        this.countdownShow(dt);
    }

    protected onDestroy(): void {
        cc.director.off(we.core.EventName.GAME_SHOW, this.onGameShow, this);
        cc.director.off(we.common.EventName.UPDATE_DAILY_RECHARGE, this.setBtnStatus, this);
    }

    private onClick(): void {
        if (we.common.dailyRechargeMgr.isOpenAct()) {
            let wPos: cc.Vec2 = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
            JumpModMgr.jumpToModule(we.common.JumpCmd.Daily_Recharge, wPos);
        } else {
            // 提示 过期 或 未开启
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
        }
    }

    private onGameShow(): void {
        if (!cc.isValid(this.node)) {
            return;
        }

        this.setBtnStatus();
    }

    private setBtnStatus(): void {
        if (!we.common.dailyRechargeMgr.isOpenAct()) {
            return;
        }

        this.RC_lab_addition.string = we.common.dailyRechargeMgr.computeRation();
        this.leftTime = we.common.dailyRechargeMgr.actInfo.endTime - we.core.TimeInfo.Inst.serverNow() / 1000;

        this.isStartCountdown = this.leftTime > 0;
        this.RC_desc.active = !(this.leftTime > 0);
        this.RC_countdown.active = this.leftTime > 0;
    }

    private countdownShow(dt: number): void {
        if (this.isStartCountdown) {
            this.leftTime -= dt;
            if (this.leftTime > 0) {
                this.RC_lab_time.string = we.common.utils.formatSeconds(Math.ceil(this.leftTime));
            } else {
                this.isStartCountdown = false;
                this.RC_countdown.active = false;
                this.RC_desc.active = true;
            }
        }
    }
}
