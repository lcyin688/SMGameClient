import { HallEvent } from '../../../config/HallEvent';
import SevenDayMgr from '../../../manager/SevenDayMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDayEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.sevenDay, node: this.node });
    }

    private onClick() {
        SevenDayMgr.instance.jump();
    }
}
