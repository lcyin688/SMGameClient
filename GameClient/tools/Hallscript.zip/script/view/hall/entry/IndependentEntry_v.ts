import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class IndependentEntry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));

        we.common.commonMgr.appendVRedDotNode(this.node).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.independent, node: notice });
        });
    }

    private onClick(): void {
        if (we.common.independentMgr.isOpenAct()) {
            JumpModMgr.jumpToModule(we.common.JumpCmd.Independent);
        } else {
            // 提示 过期 或 未开启
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
        }
    }
}
