import { HallViewId } from '../../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class DailyAwardEntry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.dailyAward, node: this.node.getChildByName('notice') });
    }

    private onClick(): void {
        we.currentUI.show(HallViewId.ActivityDailyAwardDlg);
    }
}
