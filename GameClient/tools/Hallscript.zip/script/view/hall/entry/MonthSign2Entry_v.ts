import JumpModMgr from '../../../manager/JumpModMgr';
import MonthSign from '../../../manager/MonthSignMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class MonthSign2Entry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickBank, this));

        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.monthSign2, node: this.node.getChildByName('notice') });
    }

    private onClickBank(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Month_Sign2);
    }
}
