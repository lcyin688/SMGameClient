import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class JoinUsEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));

        we.common.commonMgr.appendVRedDotNode(this.node).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.joinUs, node: notice });
            if (!we.common.activityMgr.isClickJoinUs) {
                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.joinUs, 1, true);
            }
        });
    }

    private onClick(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Join_Us);
    }
}
