const { ccclass, property } = cc._decorator;

@ccclass
export default class WithdrawEntry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickWithdraw, this));
        cc.director.on(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.showWithdraw, this);
    }

    protected onDestroy(): void {
        cc.director.off(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.showWithdraw, this);
    }

    private onClickWithdraw(): void {
        cc.director.emit(we.common.EventName.JUMP_ACTION_CMD, we.common.JumpCmd.Withdraw);
    }

    private showWithdraw(isShow: boolean) {
        if (!isShow) {
            this.node.destroy();
        }
    }
}
