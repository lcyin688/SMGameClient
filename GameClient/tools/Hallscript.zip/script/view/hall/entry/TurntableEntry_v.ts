import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class TurntableEntry_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad() {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));

        we.common.commonMgr.appendVRedDotNode(this.node).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.turntable, node: notice });
            we.common.turntableMgr.getTurntableRedCount();
        });
    }

    private onClick() {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Turntable);
    }
}
