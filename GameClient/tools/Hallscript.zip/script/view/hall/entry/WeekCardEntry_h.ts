import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class WeekCardEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickEntry, this));
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.weekCard, node: this.node.getChildByName('notice') });
    }

    private onClickEntry(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Week_Card);
    }
}
