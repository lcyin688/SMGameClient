import { HallViewId } from '../../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class OfficialPkgAwardEntry_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));
    }

    private onClick(): void {
        if (!we.common.userMgr.isFormal()) {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
        } else {
            we.currentUI.show(HallViewId.OfficialPkgAwardDlg);
        }
    }
}
