import HallJPRollMgr from '../../manager/HallJPRollMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class HallJPRollLabel_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    private label: cc.Label = null;

    private gameId: we.GameId = -1;

    protected onLoad(): void {
        this.label = this.node.getComponent(cc.Label);
    }

    protected onDestroy(): void {
        HallJPRollMgr.deleteJPRoll(this.gameId);
    }

    public init(gameId: we.GameId): void {
        this.gameId = gameId;
        HallJPRollMgr.addJPRoll(gameId, this);
    }

    public updateJP(gameId: number, num: number): void {
        if (!cc.isValid(this.node) || !this.label) {
            return;
        }
        if (this.gameId != gameId) {
            return;
        }

        this.label.string = we.common.utils.formatAmount(num, false, 0);
    }
}
