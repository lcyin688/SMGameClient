import JumpModMgr from '../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class HallBannerArea_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WEPageView)
    public RC_banner: we.ui.WEPageView = null;

    @we.ui.ccBind(cc.Node)
    public RC_indicator: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private data: api.BannerConf[] = null;

    protected onLoad(): void {
        cc.director.on(we.common.EventName.UPDATE_BANNER_SHOW, this.onUpdateBanner, this);
    }

    protected start(): void {
        this.onUpdateBanner();
    }

    protected onDestroy(): void {
        cc.director.off(we.common.EventName.UPDATE_BANNER_SHOW, this.onUpdateBanner, this);
    }

    private onUpdateBanner(): boolean {
        if (!cc.isValid(this.RC_banner)) {
            return;
        }

        this.data = we.common.activityMgr.getHallBanner();

        if (this.data.length <= 0) {
            return;
        }

        this.RC_banner.autoLoop(this.data.length > 1 ? 6 : -1);

        this.RC_banner.setRender(we.core.Func.create(this.onRenderBanner, this));
        this.RC_banner.setClick(we.core.Func.create(this.onClickBanner, this));
        this.RC_banner.totalPage = this.data.length;
        this.RC_banner.jumpToPage(0);
        return true;
    }

    private onRenderBanner(item: cc.Node, idx: number) {
        const nodeSprite = item.getComponent(cc.Sprite);
        const url = this.data[idx]?.banner?.[we.core.langMgr.getCurLangCode()];
        if (url && nodeSprite) {
            this.loadAssetRemote(url, cc.SpriteFrame, item).then((spf) => {
                nodeSprite.spriteFrame = spf;
                let contentSize = item.getContentSize();
                if (contentSize) {
                    item.setContentSize(contentSize);
                }
            });
        }
    }

    private onClickBanner(item: cc.Node, idx: number) {
        if (this.data[idx]) {
            JumpModMgr.jumpToModule(this.data[idx].link);
        }
    }
}
