import HallGameListMgr from '../../manager/HallGameListMgr';
import HallGameItem_v from './HallGameItem_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class HallGameLine_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_big: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_small: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property(cc.Prefab)
    private hallGameItem: cc.Prefab = null;

    @property()
    private up_item_pos: cc.Vec2 = new cc.Vec2(0, 0);

    @property(cc.Vec2)
    private down_item_pos: cc.Vec2 = new cc.Vec2(0, 0);

    bigItem: cc.Node = null;

    smallItem_up: cc.Node = null;

    smallItem_down: cc.Node = null;

    protected onLoad(): void {
        this.bigItem = cc.instantiate(this.hallGameItem);
        this.bigItem.setPosition(0, 0);
        this.RC_big.addChild(this.bigItem);

        this.smallItem_up = cc.instantiate(this.hallGameItem);
        this.smallItem_up.setPosition(this.up_item_pos);
        this.RC_small.addChild(this.smallItem_up);

        this.smallItem_down = cc.instantiate(this.hallGameItem);
        this.smallItem_down.setPosition(this.down_item_pos);
        this.RC_small.addChild(this.smallItem_down);

        this.RC_big.active = false;
        this.RC_small.active = false;
    }

    public init(gameIds: we.GameId[]) {
        if (!this.smallItem_up || !this.smallItem_down || !this.bigItem) {
            return;
        }
        if (gameIds.length === 1) {
            this.RC_big.active = true;
            this.RC_small.active = false;
            // big
            this.initEntryItem(gameIds[0], this.bigItem, true);
        } else if (gameIds.length === 2) {
            this.RC_big.active = false;
            this.RC_small.active = true;
            // up
            this.initEntryItem(gameIds[0], this.smallItem_up, false);
            // down
            this.initEntryItem(gameIds[1], this.smallItem_down, false);
        } else {
            this.RC_big.active = false;
            this.RC_small.active = false;
        }
    }

    private initEntryItem(gameId: we.GameId, item: cc.Node, isBigIcon: boolean) {
        const gameCfg = HallGameListMgr.getGameEntryConfig(gameId, isBigIcon, false);
        const com = item.getComponent(HallGameItem_v);
        com.init(gameCfg);
    }
}
