import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallGameListMgr from '../../manager/HallGameListMgr';
import HallGameItem_v from './HallGameItem_v';
import HallGroupItem_v from './HallGroupItem_v';
import HallSearchVendorItem_v from './HallSearchVendorItem_v';

const { ccclass, property } = cc._decorator;
/** 列表移动速度 */
const ListMoveSpeed: number = 1200;
@ccclass
export default class HallSearchGame_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_searchName: cc.EditBox = null;

    @we.ui.ccBind(cc.Node)
    public RC_groupBg: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_game: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_group: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_vendor: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_search: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_searchMask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_vendorBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnClose: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
    private groupList: string[] = [];

    /** 当前分组下标 */
    private curGroupIndex: number = 0;

    /** 当前游戏列表 */
    private curGameList: we.GameId[] = [];

    /** 上一次搜索内容 */
    private lastSearchStr: string = '';

    /** 游戏厂商列表 */
    private vendorList: { name: string; icon: string; gameList: we.GameId[] }[] = [];
    /** 当前厂商名 */
    private curVendorIndex = -1;

    protected onLoad(): void {
        this.initGroupList();
        this.initVendorList();
        this.initSearchEditBox();
        this.recoverLastEntryLocation();

        this.onBtnClick(this.RC_search, we.core.Func.create(this.onClickSearch, this));
        this.onBtnClick(this.RCN_btnClose, we.core.Func.create(this.onClickClose, this)).setSleepTime(0.5);

        this.onEditBoxEvent(this.RC_edit_searchName.node, 'editingDidBegan', we.core.Func.create(this.onSearchInputStart, this));
        this.onEditBoxEvent(this.RC_edit_searchName.node, 'editingDidEnded', we.core.Func.create(this.onSearchInputEnd, this));

        cc.director.emit(HallEvent.EVENT_SEARCH_GAME_SHOW, true);
        we.event().on('SceneChangeStart', this.onSaveLastEntryLocation, this);
    }

    protected start(): void {}

    protected onEnable(): void {}

    protected update(dt: number): void {}

    protected onDestroy(): void {
        we.event().off('SceneChangeStart', this.onSaveLastEntryLocation, this);
    }

    private hideAnim(): void {
        cc.director.emit(HallEvent.EVENT_SEARCH_GAME_SHOW, false);
    }

    private initGroupList(): void {
        this.curGroupIndex = 0;
        this.groupList = HallGameListMgr.getSearchGroupList();

        this.createGroupList();
    }

    private initVendorList() {
        this.curVendorIndex = -1;
        const list = HallGameListMgr.getVendorGameList();
        this.vendorList = list;

        this.RC_list_vendor.setRenderEvent(
            we.core.Func.create((item: cc.Node, i: number) => {
                item.getComponent(HallSearchVendorItem_v).init(this.vendorList[i].icon, i);
            }, this)
        );

        if (list.length > 0) {
            this.RC_list_vendor.node.active = true;
            this.RC_list_vendor.numItems = list.length;

            this.RC_list_vendor.setSelectedEvent(
                we.core.Func.create((item: cc.Node, i: number) => {
                    if (this.curVendorIndex === i) {
                        this.curVendorIndex = -1;
                        this.RC_list_vendor.selectedId = -1;
                    } else {
                        this.curVendorIndex = i;
                    }
                    this.showGameEntryList();
                }, this)
            );

            if (this.RC_list_vendor.content.width < this.RC_list_vendor.node.width) {
                const widget = this.RC_vendorBg.getComponent(cc.Widget);
                if (widget) {
                    widget.isAlignLeft = false;
                    widget.isAlignRight = false;
                    widget.isAlignHorizontalCenter = true;
                    widget.horizontalCenter = 0;
                }
                this.RC_vendorBg.width = this.RC_list_vendor['_allItemSize'] + 10;
            }
        } else {
            this.RC_list_vendor.node.active = false;

            const height = this.RC_list_vendor.node.height;
            const widget = this.RC_list_game.node.getComponent(cc.Widget);
            widget.top -= height;
        }
    }

    private createGroupList(): void {
        this.RC_list_group.setRenderEvent(we.core.Func.create(this.onRenderGroupItem, this));
        this.RC_list_group.numItems = this.groupList.length;

        this.RC_list_group.setSelectedEvent(we.core.Func.create(this.onSelectGroupItem, this));
        this.RC_list_group.selectedId = this.curGroupIndex;

        this.initGroupBg();
    }

    private onRenderGroupItem(item: cc.Node, i: number): void {
        let itemComp = item.getComponent(HallGroupItem_v);
        itemComp?.init(this.groupList, i);
    }

    private onSelectGroupItem(item: cc.Node, i: number): void {
        this.curGroupIndex = i;
        this.curVendorIndex = -1;
        this.RC_list_vendor.selectedId = -1;
        this.showGameEntryList();
    }

    private initGroupBg(): void {
        this.RC_groupBg.active = false;
        this.RC_groupBg.width = 0;
        this.RC_list_group.content.getComponent(cc.Sprite).enabled = false;

        if (this.groupList.length < 1) {
            return;
        }

        if (this.RC_list_group.content.width > this.RC_list_group.node.width) {
            this.RC_list_group.content.getComponent(cc.Sprite).enabled = true;
        } else {
            this.RC_groupBg.active = true;

            const layout = this.RC_list_group.content.getComponent(cc.Layout);
            const left = layout?.paddingLeft || 0;
            const right = layout?.paddingRight || 0;
            const spacingX = layout?.spacingX || 0;
            const itemWidth = this.RC_list_group.content.children[0]?.width || 0;
            const n = this.groupList.length;

            const width = n > 0 ? left + right + itemWidth * n + spacingX * (n - 1) : 0;
            this.RC_groupBg.width = width;
        }
    }

    private initSearchEditBox(): void {
        this.RC_searchMask.active = false;
        this.lastSearchStr = '';
        this.RC_edit_searchName.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.LIST_FUNCTION_1);
    }

    private onSearchInputStart(): void {
        this.RC_searchMask.active = true;
        this.RC_edit_searchName.placeholderLabel.string = ``;
    }

    private onSearchInputEnd(): void {
        this.RC_searchMask.active = false;
        if (this.RC_edit_searchName.string == '') {
            this.RC_edit_searchName.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.LIST_FUNCTION_1);
        }

        this.onClickSearch();
    }

    private onClickSearch(): void {
        let curSearchStr = this.RC_edit_searchName.string;

        if (HallGameListMgr.formatStr(curSearchStr) == HallGameListMgr.formatStr(this.lastSearchStr)) {
            return;
        }

        this.lastSearchStr = curSearchStr;

        this.showGameEntryList();
    }

    private onClickClose() {
        this.hideAnim();
    }

    private resetGameList(): void {
        this.scheduleOnce(() => {
            let offset_cur = Math.abs(this.RC_list_game.scrollView.getScrollOffset().y);
            let time = offset_cur / ListMoveSpeed;
            this.RC_list_game.scrollView.scrollToTop(time);
        });
    }

    private showGameEntryList(): void {
        this.resetGameList();
        this.createGameList();
    }

    private createGameList() {
        if (!cc.isValid(this.RC_list_game)) {
            return;
        }

        this.curGameList = HallGameListMgr.getSearchGameList(this.groupList[this.curGroupIndex]);

        // 筛选条件
        let search = HallGameListMgr.formatStr(this.lastSearchStr);
        if (search != '' && this.curGameList.length > 0) {
            this.curGameList = HallGameListMgr.searchGamesByInvertedIndex(search, this.groupList[this.curGroupIndex]);
        }

        // 筛选厂商
        const gameVendor = this.vendorList[this.curVendorIndex];
        if (gameVendor) {
            this.curGameList = this.curGameList.filter((item) => {
                return gameVendor.gameList.includes(item);
            });
        }

        // 生成item
        this.addGameItem();
    }

    private addGameItem(): void {
        this.RC_list_game.setRenderEvent(we.core.Func.create(this.onRenderGameItem, this));
        this.RC_list_game.numItems = this.curGameList.length;
    }

    protected onRenderGameItem(item: cc.Node, i: number): void {
        const gameId = this.curGameList[i] || -1;
        if (!we.core.gameConfig.isSubGame(gameId)) {
            return;
        }

        const gameCfg = HallGameListMgr.getGameEntryConfig(gameId, false, true);
        item.getComponent(HallGameItem_v)?.init(gameCfg);
    }

    private onSaveLastEntryLocation() {
        // 记录当前用户操作数据,用于下次进入时显示
        HallGameListMgr.lastGameEnterLocation.searchParams = {
            groupIndex: this.curGroupIndex,
            searchValue: this.lastSearchStr,
            vendorIndex: this.curVendorIndex,
            scrollOffset: this.RC_list_game?.scrollView?.getScrollOffset().clone(),
        };
    }

    private recoverLastEntryLocation() {
        if (we.core.gameConfig.getSceneFrom() !== we.SceneFrom.Game) {
            return;
        }
        const { groupIndex, vendorIndex, scrollOffset, searchValue } = HallGameListMgr.lastGameEnterLocation.searchParams;
        let time = 0.1;
        if (this.curGroupIndex != groupIndex) {
            this.RC_list_group.selectedId = groupIndex;
        }
        if (this.curVendorIndex != vendorIndex) {
            this.RC_list_vendor.selectedId = vendorIndex;
        }
        if (searchValue) {
            this.RC_edit_searchName.string = searchValue;
            this.onClickSearch();
        }

        if (scrollOffset && scrollOffset.y) {
            this.scheduleOnce(() => {
                this.RC_list_game.scrollView.scrollToOffset(scrollOffset, 0.3);
            }, time);
        }
    }
}
