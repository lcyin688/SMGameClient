import { HallRes } from '../../config/HallRes';
import HallGameIconMgr from '../../manager/HallGameIconMgr';
import { IGameEntryConf } from '../../manager/HallGameListMgr';
import HallJPRollMgr from '../../manager/HallJPRollMgr';
import HallMgr from '../../manager/HallMgr';
import { EnterGameFlow } from '../../task/entergame/EnterGameFlow';
import HallJPRollLabel_v from './HallJPRollLabel_v';

const { ccclass, property } = cc._decorator;

/**
 * 游戏入口标识枚举
 */
enum SwitchTagEnum {
    Null = 0,
    HotSmall = 1,
    HotBig = 2,
    NewSmall = 3,
    NewBig = 4,
    /** 即将到来 小 */
    ComingsoonSmall = 5,
    ComingsoonBig = 6,
    /** 停服维护 小 */
    SafeguardSmall = 7,
    SafeguardBig = 8,
    /** 转圈 */
    Circle = 9,
}

@ccclass
export default class HallGameItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(sp.Skeleton)
    public RC_anim: sp.Skeleton = null;

    @we.ui.ccBind(cc.Node)
    public RC_circle: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_guide: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_jackpot: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_jackpot: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_limitText: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_limit: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_limitIcon: cc.Sprite = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vendor: cc.Sprite = null;

    @we.ui.ccBind(we.ui.WESwitchPage)
    public RC_switch_tag: we.ui.WESwitchPage = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private gameId: number = -1;
    private conf: IGameEntryConf = null;

    @property({
        tooltip: CC_DEV && '大厅游戏 icon 大图标尺寸',
    })
    public GameItemBigSize: cc.Size = new cc.Size(230, 420);

    @property({
        tooltip: CC_DEV && '大厅游戏 icon 小图标尺寸',
    })
    public GameItemSmallSize: cc.Size = new cc.Size(200, 203);

    @property({
        tooltip: CC_DEV && '大图标-字号',
    })
    public fontSizeBig: number = 36;

    @property({
        tooltip: CC_DEV && '小图标-字号',
    })
    public fontSizeSmall: number = 30;

    protected onLoad(): void {
        this.RC_switch_tag.node.active = true;

        this.RC_circle.setContentSize(cc.size(64, 64));
        this.tween(this.RC_circle).repeatForever(cc.rotateBy(1, 360)).start();

        this.onBtnClick(this.node, we.core.Func.create(this.onClickEntryItem, this));

        we.event<we.core.EventMsg>().on('LangChanged', this.setGameName, this);
        cc.director.on(we.core.EventName.ENTER_GAME_LIMIT_UPDATE, this.setVipLimit, this);
    }

    protected onDestroy(): void {
        we.event<we.core.EventMsg>().off('LangChanged', this.setGameName, this);
        cc.director.off(we.core.EventName.ENTER_GAME_LIMIT_UPDATE, this.setVipLimit, this);
    }

    /**
     * 初始化游戏入口
     * @param conf 游戏入口配置
     */
    public init(conf: IGameEntryConf) {
        this.__initRc();

        if (!conf || !conf.gameId) {
            we.warn(`HallGameItem_h init, param is null`, conf);
            this.node.active = false;
            return;
        }

        // 初始化状态
        this.RC_icon.node.opacity = 0;
        this.RC_icon.node.active = true;
        this.RC_anim.node.opacity = 0;
        this.RC_anim.node.active = true;
        this.RC_lab_name.node.active = false;
        this.RC_jackpot.active = false;
        this.RC_limit.active = false;
        this.RC_guide.active = false;
        this.RC_spr_vendor.node.active = false;
        this.RC_switch_tag.index = SwitchTagEnum.Circle;
        this.node.active = true;

        this.conf = conf;
        this.gameId = conf.gameId;

        this.node.setContentSize(conf.isBigIcon ? this.GameItemBigSize : this.GameItemSmallSize);

        // 字体大小
        const fontSize = this.conf.isBigIcon ? this.fontSizeBig : this.fontSizeSmall;
        this.RC_lab_name.fontSize = fontSize;

        HallGameIconMgr.loadIcon({
            gameId: +conf.gameId,
            isBig: conf.isBigIcon,
            anim: this.RC_anim,
            image: this.RC_icon,
            self: this,
            callBack: () => {
                if (!cc.isValid(this.node) || !this.conf || this.conf.gameId !== conf.gameId) {
                    return;
                }

                if (conf.safeguard) {
                    this.RC_switch_tag.index = conf.isBigIcon ? SwitchTagEnum.SafeguardBig : SwitchTagEnum.SafeguardSmall;
                } else if (conf.comingsoonStart) {
                    this.RC_switch_tag.index = conf.isBigIcon ? SwitchTagEnum.ComingsoonBig : SwitchTagEnum.ComingsoonSmall;
                } else if (conf.isNew) {
                    this.RC_switch_tag.index = conf.isBigIcon ? SwitchTagEnum.NewBig : SwitchTagEnum.NewSmall;
                } else if (conf.isHot) {
                    this.RC_switch_tag.index = conf.isBigIcon ? SwitchTagEnum.HotBig : SwitchTagEnum.HotSmall;
                } else {
                    this.RC_switch_tag.index = 0;
                }

                if (this.RC_limit.getComponent(we.ui.WESpriteIndex)) {
                    this.RC_limit.getComponent(we.ui.WESpriteIndex).index = conf.isBigIcon ? 1 : 0;
                }

                this.setVipLimit();
                this.setGameName();
                this.setGameVendor();

                if (conf.safeguard || conf.comingsoonStart) {
                    return;
                }

                this.setGuide(conf.isGuide);
                this.setJackpot();
            },
        });
    }

    /** 设置VIP限制 */
    public setVipLimit(): void {
        if (!cc.isValid(this.RC_limit)) {
            return;
        }
        const gameId = this.conf?.gameId || -1;
        let vipLimitLv = we.common.gameMgr.gameEnterLimitConf?.enterVipLimit?.[this.conf?.gameId] || 0;
        this.RC_limit.active = we.common.userMgr.vipExp.level < vipLimitLv && vipLimitLv > 0;
        // 设置Vip Icon
        if (this.RC_limit.active === true) {
            // 设置文本
            if (cc.isValid(this.RC_limit)) {
                this.RC_lab_limitText.string = 'VIP' + vipLimitLv;
                let path = HallRes.texture.VIP_Logo_icon + vipLimitLv;
                // icon
                this.loadAsset(path, cc.SpriteFrame).then((spf) => {
                    this.addAutoReleaseAsset(spf);
                    if (gameId !== this.conf?.gameId) {
                        return;
                    }
                    if (!spf || !cc.isValid(this.RC_limit)) {
                        return;
                    }
                    this.RC_spr_limitIcon.spriteFrame = spf;
                    this.RC_limit.active = true;
                    this.RC_limit.stopAllActions();
                    this.tween(this.RC_limit).to(0.2, { opacity: 255 }).start();
                });
            }
        }
    }

    /** 设置游戏名称 */
    private setGameName(): void {
        if (!this.conf) {
            return;
        }
        let str = we.common.gameMgr.getGameEntryName(this.conf?.gameId, false);
        if (str) {
            this.RC_lab_name.node.active = true;
            this.RC_lab_name.string = str.toLocaleUpperCase();
        }
    }

    /** 设置引导 */
    private setGuide(isGuide: boolean): void {
        const gameId = this.conf?.gameId || -1;
        this.RC_guide.active = isGuide;
        if (isGuide) {
            let animComp = this.RC_guide.getComponent(sp.Skeleton);
            this.loadAsset(HallRes.animation.finger, sp.SkeletonData).then((asset) => {
                this.addAutoReleaseAsset(asset);
                if (gameId !== this.conf?.gameId) {
                    return;
                }
                if (asset && cc.isValid(animComp)) {
                    animComp.skeletonData = asset;
                    animComp.setAnimation(0, 'animation', true);
                    animComp.timeScale = 0.5;
                }
            });
        }
    }

    private setJackpot(): void {
        const isOpenJackpot = HallJPRollMgr.isOpenJackPot(this.conf?.gameId);
        this.RC_jackpot.active = isOpenJackpot;
        const jackpotRoll = this.RC_lab_jackpot.getComponent(HallJPRollLabel_v);
        if (isOpenJackpot && jackpotRoll) {
            jackpotRoll.init(this.conf.gameId);
        }
    }

    /** 点击进入游戏 */
    private onClickEntryItem(): void {
        // 设置点击游戏ICON的延迟时间
        if (we.core.utils.isQuickClick('hall_enter_game')) {
            return;
        }

        if (!this.conf) {
            return;
        }

        if (!HallMgr.canEnterSubGame(this.conf.gameId)) {
            return;
        }

        EnterGameFlow.Inst.run(this.conf.gameId);
    }

    /** 设置游戏厂商 */
    private setGameVendor() {
        if (!this.conf) {
            return;
        }
        const gameId = this.conf?.gameId || -1;
        const url = this.conf.vendorIcon;
        this.RC_spr_vendor.node.active = Boolean(url);
        if (this.RC_spr_vendor.node.active) {
            this.loadAssetRemote(url, cc.SpriteFrame).then((spriteFrame) => {
                if (gameId !== this.conf?.gameId) {
                    return;
                }
                if (spriteFrame && cc.isValid(this.RC_spr_vendor)) {
                    this.RC_spr_vendor.spriteFrame = spriteFrame;
                }
            });
        }
    }
}
