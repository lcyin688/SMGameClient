import MonthSign from '../../manager/MonthSignMgr';
import { HallRes } from '../../config/HallRes';
import WeekCardMgr from '../../manager/WeekCardMgr';
import SevenDayMgr from '../../manager/SevenDayMgr';
import { HallEvent } from '../../config/HallEvent';
import HallEntryList from '../../extend/hall/HallEntryList';

type EntryConfig = { event: string | symbol; condition: () => boolean; path: string; parent: cc.Node; callback?: Function };

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityMenu_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_more_arrow: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_more_list: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_RedeemCodeEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_BankEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_more: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_CarnivalEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_DailyAwardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_DailyRechargeRewardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_hidden_list: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_IndependentEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_JoinUsEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_MonthSignEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_MonthSign2Entry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_moreBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_NewbieGiftBagEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_QuestionNaireEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_RescueFundsEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_SafeEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_SevenDayEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_TurntableEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_WeekCardEntry: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    /** 是否打开 more 展示块 */
    private isOpenMore: boolean = false;

    private updateCallBack: Function = null;

    private entryConfig: EntryConfig[] = [];

    protected onLoad(): void {
        this.isOpenMore = false;
        this.RC_more_arrow.scaleY = -1;

        this.onBtnClick(this.RCN_btn_more, we.core.Func.create(this.onClickOpenMore, this)).setTransitionNone();

        cc.director.on(we.core.EventName.GAME_SHOW, this.initEntry, this);

        cc.director.on(we.common.EventName.ACTIVITY_DATA_INIT, this.initEntry, this);
        cc.director.on(we.common.EventName.UPDATE_HALL_TOP_MENU, this.refreshEntry, this);

        this.registerEntry();
    }

    protected start(): void {
        this.initEntry();
    }

    protected onDestroy(): void {
        cc.director.off(we.core.EventName.GAME_SHOW, this.initEntry, this);
        cc.director.off(we.common.EventName.ACTIVITY_DATA_INIT, this.initEntry, this);
        cc.director.off(we.common.EventName.UPDATE_HALL_TOP_MENU, this.refreshEntry, this);
        this.entryConfig.forEach((config) => {
            config.event && cc.director.off(config.event, config.callback, this);
        });
        this.entryConfig.length = 0;
    }

    public init(updateCallBack?: Function): void {
        if (updateCallBack) {
            this.updateCallBack = updateCallBack;
        }
    }

    private onClickOpenMore(): void {
        this.isOpenMore = !this.isOpenMore;
        this.refreshEntry();
    }

    /** 注册入口 */
    private registerEntry() {
        // 安全绑定
        this.entryConfig.push({
            event: we.common.EventName.HIDE_BIND_ENTRY,
            condition: () => {
                return !we.common.userMgr.isFormal();
            },
            path: HallRes.prefab.SafeEntry,
            parent: this.RCN_SafeEntry,
        });

        // 银行
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_BANK,
            condition: () => {
                return we.common.bankMgr.getBankIsAct();
            },
            path: HallRes.prefab.BankEntry,
            parent: this.RCN_BankEntry,
        });

        // 问卷调查
        this.entryConfig.push({
            event: we.common.EventName.SHOW_QUESTIONNAIRE,
            condition: () => {
                return we.common.activityMgr.questionNaireConf?.enable;
            },
            path: HallRes.prefab.QuestionNaireEntry,
            parent: this.RCN_QuestionNaireEntry,
        });

        // 新手礼包
        this.entryConfig.push({
            event: we.common.EventName.GIFT_BAG_UPDATE,
            condition: () => {
                return we.common.storeMgr.isNewbieGift;
            },
            path: HallRes.prefab.NewbieGiftBagEntry,
            parent: this.RCN_NewbieGiftBagEntry,
        });

        // 每日充值
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_DAILY_RECHARGE,
            condition: () => {
                return we.common.dailyRechargeMgr.isOpenAct();
            },
            path: HallRes.prefab.DailyRechargeRewardEntry,
            parent: this.RCN_DailyRechargeRewardEntry,
        });

        // 加入我们
        this.entryConfig.push({
            event: null,
            condition: () => {
                return we.core.projectConfig.settingsConfig?.thirdLinkJoinSwitch;
            },
            path: HallRes.prefab.JoinUsEntry,
            parent: this.RCN_JoinUsEntry,
        });

        // 开斋节
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_CARNIVAL,
            condition: () => {
                return we.common.carnivalMgr.isOpenAct();
            },
            path: HallRes.prefab.CarnivalEntry,
            parent: this.RCN_CarnivalEntry,
        });

        // 独立日
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_INDEPENDENT_TASK,
            condition: () => {
                return we.common.independentMgr.isOpenAct();
            },
            path: HallRes.prefab.IndependentEntry,
            parent: this.RCN_IndependentEntry,
        });

        // 转盘
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_TURNTABLE_TASK,
            condition: () => {
                return we.common.turntableMgr.getTurntableIsAct();
            },
            path: HallRes.prefab.TurntableEntry,
            parent: this.RCN_TurntableEntry,
        });

        // 每日金币
        this.entryConfig.push({
            event: null,
            condition: () => {
                return !!we.common.activityMgr.dailySignInInfo;
            },
            path: HallRes.prefab.DailyAwardEntry,
            parent: this.RCN_DailyAwardEntry,
        });

        // 月签到-按天
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_MONTH_MONTH_SIGN,
            condition: () => {
                return MonthSign.month.isActive();
            },
            path: HallRes.prefab.MonthSignEntry,
            parent: this.RCN_MonthSignEntry,
        });

        // 月签到-按次
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_MONTH_MONTH_SIGN,
            condition: () => {
                return MonthSign.month2.isActive();
            },
            path: HallRes.prefab.MonthSign2Entry,
            parent: this.RCN_MonthSign2Entry,
        });

        // 救援金
        this.entryConfig.push({
            event: we.common.EventName.RESCUE_FUNDS_SYNC,
            condition: () => {
                return we.common.rescueFundsMgr.getRescueFundsIsAct();
            },
            path: HallRes.prefab.RescueFundsEntry,
            parent: this.RCN_RescueFundsEntry,
        });

        // 周卡
        this.entryConfig.push({
            event: HallEvent.WEEK_CARD_SHOW_STATUS,
            condition: () => {
                return WeekCardMgr.isOpenAc();
            },
            path: HallRes.prefab.WeekCardEntry,
            parent: this.RCN_WeekCardEntry,
        });

        // 七日福利
        this.entryConfig.push({
            event: HallEvent.SEVEN_DAY_UPDATE_DATA,
            condition: () => {
                return SevenDayMgr.instance.open;
            },
            path: HallRes.prefab.SevenDayEntry,
            parent: this.RCN_SevenDayEntry,
        });

        // 兑换码
        this.entryConfig.push({
            event: null,
            condition: () => {
                return true;
            },
            path: HallRes.prefab.RedeemCodeEntry,
            parent: this.RCN_RedeemCodeEntry,
        });

        this.entryConfig.forEach((config) => {
            if (config.event) {
                config.callback = () => {
                    this.checkEntry(config);
                };
                cc.director.on(config.event, config.callback, this);
            }
        });
    }

    /** 初始化入口 */
    private initEntry() {
        this.entryConfig.forEach((config) => {
            this.checkEntry(config);
        });
    }

    /**
     * 检查入口
     * @param config
     */
    private checkEntry(config: EntryConfig) {
        if (!cc.isValid(config?.parent)) {
            return;
        }
        if (config.condition?.()) {
            this.createEntry(config.path, config.parent);
        } else {
            config.parent.removeAllChildren();
            this.refreshEntry();
        }
    }

    /**
     * 创建入口
     * @param path
     * @param parent
     */
    private async createEntry(path: string, parent: cc.Node) {
        if (parent.childrenCount > 0) {
            return;
        }
        const entry = await we.commonUI.createNode(path, parent);
        entry.setPosition(0, 0);
        parent.setContentSize(entry.getBoundingBox().size);
        this.refreshEntry();
    }

    /** 刷新入口 */
    private async refreshEntry() {
        if (!cc.isValid(this.RC_more_list)) {
            return;
        }
        const overflow = await this.RC_more_list?.getComponent(HallEntryList)?.refresh(this.isOpenMore ? null : this.RCN_hidden_list);
        if (this.isOpenMore && !overflow) {
            this.isOpenMore = false;
        }
        this.RCN_moreBg.active = overflow;
        this.RC_more_arrow.scaleY = this.isOpenMore ? 1 : -1;
        if (!this.isOpenMore) {
            typeof this.updateCallBack == 'function' && this.updateCallBack();
        }
    }
}
