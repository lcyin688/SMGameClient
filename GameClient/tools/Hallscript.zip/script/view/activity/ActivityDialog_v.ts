import { HallRes } from '../../config/HallRes';
import ActivityMenu_v from '../hall/ActivityMenu_v';
import ActivityCommonPreview_v from './ActivityCommonPreview_v';
import ActivityToggleItem_v from './ActivityToggleItem_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityView_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnLeft: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRight: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_content_list: we.ui.List = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_curPage: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_totalPage: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_left_btn: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(cc.Node)
    public RC_pageContent: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_right_btn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_more_root: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public comPre: cc.Prefab = null;

    private curActType: number = 0;
    private curAct = null;
    private totalPage = 0;
    private curPage: number = 0;
    private cancelAction: we.core.CancelAction;

    protected onLoad(): void {
        this.__initRc();

        this.comPre = this._rc.getRes('ActivityCommonPreview', cc.Prefab);
        if (we.core.flavor.getSkinCode() !== we.core.SkinCode.as) {
            this.RC_list.setRenderEvent(we.core.Func.create(this.onToggleRenderEvent, this));
        }

        this.RC_content_list.setRenderEvent(we.core.Func.create(this.onContentRenderEvent, this));

        this.setActivityMenu();
        this.onBtnClick(this.RC_left_btn, we.core.Func.create(this.onClickPreBtn, this)).setSleepTime();
        this.onBtnClick(this.RC_right_btn, we.core.Func.create(this.onClickNextBtn, this)).setSleepTime();

        // ct4皮肤增加的左右切换页面按钮
        if (cc.isValid(this.RC_btnLeft) && cc.isValid(this.RC_btnRight)) {
            this.onBtnClick(this.RC_btnLeft, we.core.Func.create(this.onClickPreBtn, this)).setSleepTime();
            this.onBtnClick(this.RC_btnRight, we.core.Func.create(this.onClickNextBtn, this)).setSleepTime();
            this.RC_btnLeft.active = false;
            this.RC_btnRight.active = false;
        }
    }

    protected start(): void {
        this.cancelAction = we.core.CancelAction.create();
        this.cancelAction.add(() => {
            we.commonUI.hideCircleLoading();
        });

        we.commonUI.showCircleLoading({ delay: 1, cancel: this.cancelAction, debug: 'ActivityView_v start' });
        this.setActivity();
    }

    private async setActivity() {
        if (we.common.activityMgr.activityConf.length == 0) {
            let count = 0;
            // api
            do {
                count++;
                await we.core.timer.scheduleOnce(1);
                if (we.common.activityMgr.activityConf.length != 0) {
                    this.setActivity();
                    break;
                }
            } while (count < 5);

            let defer = we.core.PromiseHelper.defer();

            if (we.common.activityMgr.activityConf.length == 0) {
                we.common.activityMgr.getActivityConf(
                    () => {
                        defer.resolve();
                    },
                    () => {
                        // tip
                        this.cancelAction.cancel();
                    }
                );
            }

            await defer.promise();
        }

        this.cancelAction.cancel();
        this.initMenu();
        this.setContentListEvent();
        this.init();
    }

    /** 通过 RC_more_root 是否存在判断 活动入口在事件中心 */
    private async setActivityMenu() {
        if (!cc.isValid(this.RC_more_root)) {
            return;
        }

        const activityMenu = await this.loadAsset(HallRes.prefab.ActivityMenu, cc.Prefab);
        if (activityMenu) {
            const activityMenuNode = cc.instantiate(activityMenu);
            this.RC_more_root.addChild(activityMenuNode);
            activityMenuNode.getComponent(ActivityMenu_v)?.init(this.updateListHeight.bind(this));
        }
    }

    private async updateListHeight(): Promise<void> {
        if (!cc.isValid(this.RC_more_root) || !cc.isValid(this.RC_content_list)) {
            return;
        }

        await we.core.timer.scheduleOnce(0, this.RC_content_list);

        this.RC_more_root.getComponent(cc.Layout)?.updateLayout();
        const widget = this.RC_content_list.node.getComponent(cc.Widget);
        if (widget?.isAlignTop) {
            widget.top = this.RC_more_root.height;
            widget.updateAlignment();
        }
        this.RC_content_list.node.children.forEach((child) => {
            child.getComponent(cc.Widget)?.updateAlignment();
        });
    }

    public init(): void {
        this.curActType = we.common.activityMgr.SubActivity.NULL;
        const activityConf = this.filterPartActivity();
        this.RC_list.numItems = activityConf.length;
        this.RC_content_list.numItems = activityConf.length;

        if (activityConf.length > 1) {
            if (cc.isValid(this.RC_btnLeft) && cc.isValid(this.RC_btnRight)) {
                this.RC_btnLeft.active = true;
                this.RC_btnRight.active = true;
            }
        }

        // 注册 按钮切换管理组件
        this.scheduleOnce(() => {
            this.RC_menu.node.children.forEach((v, i) => {
                this.RC_menu.addMenuBtn(v, i);
            });
            this.RC_menu.onSwitchMenu(0);
        });
        this.RC_lab_curPage.string = '1';
        this.RC_lab_totalPage.string = '/' + activityConf.length;
        this.curPage = 0;
    }

    private initMenu() {
        this.RC_menu.setMenuStateByNodeName('select', 'unSelect');
        this.RC_menu.onSelected = (node: cc.Node, i: number) => {
            this.onSwitchContent(node, i);
        };

        this.RC_menu.onUnselected = (node: cc.Node, i: number) => {};
    }

    private onClickPreBtn() {
        this.curPage--;
        if (this.curPage < 0) {
            this.curPage = this.totalPage;
        }
        this.RC_lab_curPage.string = this.curPage + 1 + '';
        this.RC_content_list.skipPage(this.curPage, 0.3);
        this.RC_menu.onSwitchMenu(this.curPage);
        this.menuListMove(this.curPage);
    }

    private onClickNextBtn() {
        this.curPage++;
        if (this.curPage >= this.totalPage) {
            this.curPage = 0;
        }
        this.RC_lab_curPage.string = this.curPage + 1 + '';
        this.RC_content_list.skipPage(this.curPage, 0.3);
        this.RC_menu.onSwitchMenu(this.curPage);
        this.menuListMove(this.curPage);
    }

    private setContentListEvent() {
        this.RC_content_list.setPageEvent(we.core.Func.create(this.pageChangedCall, this));
    }

    private pageChangedCall(idx: number) {
        this.curPage = idx;
        this.RC_lab_curPage.string = this.curPage + 1 + '';
        this.RC_menu.onSwitchMenu(this.curPage);
        this.menuListMove(this.curPage);
    }

    private onToggleRenderEvent(node: cc.Node, index: number) {
        const activityConf = this.filterPartActivity();
        let data = activityConf[index];
        if ((index === 0 && this.curActType == we.common.activityMgr.SubActivity.NULL) || this.curAct == null) {
            this.curAct = data;
            this.curActType = data.type;
        }

        node.attr({ activityId: data._id, activityType: data.type });
        node.getComponent(ActivityToggleItem_v)?.init?.(data);
    }

    private onContentRenderEvent(node: cc.Node, index: number) {
        const activityConf = this.filterPartActivity();
        let data = activityConf[index];
        if ((index === 0 && this.curActType == we.common.activityMgr.SubActivity.NULL) || this.curAct == null) {
            this.curAct = data;
            this.curActType = data.type;
        }

        node.attr({ activityId: data._id, activityType: data.type });
        node.getComponent(ActivityCommonPreview_v)?.init?.(data);
    }

    /** 切换 */
    private onSwitchContent(node: cc.Node, index: number): void {
        let conf = this.filterPartActivity();
        if (conf.length < index) {
            return;
        }
        let activityId = node?.['activityId'];
        for (let i = 0; i < conf.length; i++) {
            const element = conf[i];
            if (activityId == element?._id) {
                this.curAct = this.filterPartActivity()[index];
                this.curActType = this.curAct.type;
                let comp = node.getComponent(ActivityToggleItem_v);
                if (comp) {
                    comp.setCheckState();
                }
                if (this.curAct) {
                    this.curPage = index;
                    this.RC_lab_curPage.string = this.curPage + 1 + '';
                    this.RC_content_list.skipPage(this.curPage, 0.3);
                }
                break;
            }
        }
        this.menuListMove(index);
    }

    private filterPartActivity() {
        let conf = we.common.activityMgr.activityConf;
        let activityConf = [];
        for (let i = 0; i < conf.length; i++) {
            if (conf[i].type != we.common.activityMgr.SubActivity.DAILY_SIGN_IN) {
                activityConf.push(conf[i]);
            }
        }
        this.totalPage = activityConf.length;
        return activityConf;
    }

    private menuListMove(index: number = 0) {
        let scrollTo = 0;
        if (index <= 1) {
            scrollTo = 0;
        } else if (index >= 2) {
            scrollTo = index - 1;
        }
        this.RC_list.scrollTo(scrollTo);
    }
}
