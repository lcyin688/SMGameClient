import { HallEvent } from '../../../config/HallEvent';
import { HallLanguage } from '../../../const/HallLanguage';
import HallMgr from '../../../manager/HallMgr';
import { HallViewId } from '../../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityDailyAward_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_awardBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGet: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnReceived: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_awardRang: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_leftDay: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_multiple: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_multipleRang: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_originRang: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_progress: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_received: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ruleLb1: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_maskBig: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_pointerAnim: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_ruleBg: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_progressBar: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_turntableBig: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_turntableSmall: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
    private leftTime: number = -1;
    private isCountdown: boolean = false;
    private awardData: api.GetDailyFreeAwardResp = null;

    private isTurntable: boolean = false;
    private curAngle: number = 0;
    private addSpeed: number = 720;
    private maxSpeed: number = 1440;
    private stopTurntable: boolean = false;
    private curSpeed: number = 0;
    private turnTime: number = 0;
    private maxTurnTime: number = -1;

    private multipleUnlock: boolean = false;
    private scheduleTime: number = 0;

    protected onEnable(): void {
        this.setSignInAward();
    }

    protected start(): void {
        this.onBtnClick(this.RC_btnGet, we.core.Func.create(this.onClickReceive, this)).setSleepTime(4.5);
        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRule, this));

        cc.director.on(we.core.EventName.GAME_SHOW, this.onEventGameShow, this);
        cc.director.on(we.common.EventName.UPDATE_DAILY_FREE_AWARD, this.onUpdateAward, this);
    }

    protected update(dt: number): void {
        this.countdownShow(dt);
        this.turnTableAnim(dt);
    }

    protected onDestroy(): void {
        cc.director.off(we.core.EventName.GAME_SHOW, this.onEventGameShow, this);
        cc.director.off(we.common.EventName.UPDATE_DAILY_FREE_AWARD, this.onUpdateAward, this);
    }

    private onClickRule(): void {
        if (isNaN(we.common.activityMgr.dailyFreeAward?.rateWheelConf?.unlockRechargeAmount)) {
            return;
        }

        this.RC_ruleBg.stopAllActions();

        if (this.RC_ruleBg.active) {
            this.RC_ruleBg.active = false;
            return;
        }

        this.RC_ruleBg.scale = 0.001;
        this.RC_ruleBg.opacity = 0;
        this.RC_ruleBg.active = true;
        this.tween(this.RC_ruleBg)
            .to(0.1, { scale: 1, opacity: 255 }, { easing: 'backIn' })
            .delay(5)
            .call(() => {
                this.RC_ruleBg.active = false;
            })
            .start();
    }

    private onClickReceive(): void {
        if (this.RC_ruleBg.active) {
            this.RC_ruleBg.stopAllActions();
            this.RC_ruleBg.active = false;
        }

        if (we.core.projectConfig.settingsConfig.phoneBindRequired && !we.common.userMgr.isFormal()) {
            this.bindTips();
            return;
        }

        if (!we.common.activityMgr.dailyFreeAward?.rateWheelConf?.unlocked && we.common.activityMgr.dailyFreeAward?.rateWheelConf?.overThanRechargeAmountP90) {
            this.rechargeTips();
            return;
        }

        this.playTurnTable();
    }

    private playTurnTable(): void {
        this.turnTime = 0;
        this.maxTurnTime = 2 + Math.random();
        this.stopTurntable = false;
        this.isTurntable = true;
        this.RC_pointerAnim.active = true;
        let animName = this.multipleUnlock ? 'animation2' : 'animation1';
        this.RC_pointerAnim.getComponent(sp.Skeleton)?.setAnimation(0, animName, true);

        cc.director.emit(HallEvent.ACTIVITY_CENTER_MASK, true);
        we.common.apiMgr.getDailyFreeAward(
            (data: api.GetDailyFreeAwardResp) => {
                if (we.common.activityMgr.dailyFreeAward) {
                    we.common.activityMgr.dailyFreeAward.isGet = true;
                }
                cc.director.emit(we.common.EventName.NOTICE_EVENT_CENTER);

                if (!cc.isValid(this.node)) {
                    this.playAward(data);
                } else {
                    this.awardData = data;
                    this.getSucc(data);
                }
            },
            (code) => {
                cc.director.emit(HallEvent.ACTIVITY_CENTER_MASK, false);
                if (code == 1027 && cc.isValid(this.node)) {
                    this.bindTips();
                    this.stopTurntable = true;
                    this.isTurntable = false;
                    this.RC_turntableSmall.angle = 0;
                    this.RC_turntableBig.angle = 0;
                    this.RC_pointerAnim.active = false;
                }
            }
        );
    }

    private onEventGameShow(): void {
        if (!cc.isValid(this.node) || !we.common.activityMgr.dailyFreeAward) {
            return;
        }

        let isReceive = we.common.activityMgr.dailyFreeAward.isGet;
        let curTime = we.core.TimeInfo.Inst.serverNow() / 1000;
        if (isReceive) {
            this.leftTime = we.common.activityMgr.dailyFreeAward.tomorrowSix - curTime;
            this.RC_lab_received.string = this.leftTime > 0 ? we.common.utils.formatSeconds(Math.ceil(this.leftTime)) : we.core.langMgr.getLangText(we.common.lang.COMMON_RECEIVED);
            this.isCountdown = this.leftTime > 0;
            this.RC_btnGet.active = this.leftTime < 0;
            this.RC_btnReceived.active = this.leftTime > 0;
        }
    }

    private onUpdateAward(): void {
        if (!cc.isValid(this.node)) {
            return;
        }

        this.setSignInAward();
    }

    private bindTips() {
        we.commonUI.showConfirm({
            content: we.core.langMgr.getLangText(HallLanguage.COIN_DAY_BIND),
            yesButtonName: we.core.langMgr.getLangText(HallLanguage.BUTTON_UPDATE),
            yesHandler: we.core.Func.create(() => {
                we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
            }, this),
            noButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CANCEL),
        });
    }

    private rechargeTips() {
        let unlockRechargeAmount = we.common.activityMgr.dailyFreeAward?.rateWheelConf?.unlockRechargeAmount; // 目标金额
        let rechargedAmount = we.common.activityMgr.dailyFreeAward?.rateWheelConf?.rechargedAmount; // 已充值金额
        let rechargeRatio = Math.floor((rechargedAmount / unlockRechargeAmount) * 100); // 充值百分比

        we.commonUI.showConfirm({
            content: we.core.langMgr.getLangText(HallLanguage.DAILY_FREE_COINS_5, `${rechargeRatio}%`),
            yesButtonName: we.core.langMgr.getLangText(HallLanguage.TOP_UP_1),
            yesHandler: we.core.Func.create(() => {
                // 充值
                let targetAmount = 0;
                if (!isNaN(unlockRechargeAmount) && !isNaN(rechargedAmount)) {
                    targetAmount = unlockRechargeAmount - rechargedAmount;
                }
                we.common.payMgr.trackFrom = 'dailyAward';
                HallMgr.openStoreDlg(targetAmount);
                cc.director.emit(HallEvent.ACTIVITY_CENTER_OPEN_OTHER);
            }, this),
            noButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CONFIRM),
            noHandler: we.core.Func.create(() => {
                this.playTurnTable();
            }, this),
        });
    }

    private setSignInAward(): void {
        this.RC_awardBg.active = false;
        this.RC_lab_originRang.node.active = false;
        this.RC_lab_progress.node.active = false;
        this.RC_lab_leftDay.node.active = false;
        this.RC_btnGet.active = false;
        this.RC_btnReceived.active = false;
        this.RC_ruleBg.active = false;
        this.RC_spr_progressBar.fillRange = 0;
        this.RC_turntableSmall.angle = 0;
        this.RC_turntableBig.angle = 0;

        let initSignin = () => {
            if (!we.common.activityMgr.dailyFreeAward) {
                we.warn(`ActivityDailyAward_h setSignInAward, initSignin data is null`);
                return;
            }

            let curTime = we.core.TimeInfo.Inst.serverNow() / 1000;

            // 设置倍数轮盘
            let rateWheelConf = we.common.activityMgr.dailyFreeAward?.rateWheelConf;
            if (rateWheelConf) {
                // 设置倍数区间
                let rateRange = rateWheelConf?.rateRange || [];
                if (rateRange.length > 1) {
                    this.RC_lab_multipleRang.string = `${rateRange[0]}~${rateRange[1]}`;
                }
                let unlockRechargeAmount = rateWheelConf?.unlockRechargeAmount;
                if (!isNaN(unlockRechargeAmount)) {
                    this.RC_lab_ruleLb1.string = we.core.langMgr.getLangText(HallLanguage.DAILY_FREE_COINS_2, we.common.utils.formatPrice(unlockRechargeAmount, false, false));
                }

                // 设置解锁状态
                let isUnlock = rateWheelConf?.unlocked;
                this.multipleUnlock = isUnlock;
                this.RC_lab_leftDay.node.active = isUnlock;
                this.RC_lab_progress.node.active = !isUnlock;
                this.RC_maskBig.active = !isUnlock;
                if (isUnlock) {
                    this.RC_spr_progressBar.fillRange = 1;
                    let leftDay = 0;
                    let expireTime = rateWheelConf?.unlockedExpiredIn;
                    if (expireTime > curTime) {
                        leftDay = Math.ceil((expireTime - curTime) / (24 * 60 * 60));
                        this.RC_lab_leftDay.string = we.core.langMgr.getLangText(HallLanguage.FREECOIN_REMAINDAY, leftDay);
                    }
                } else {
                    let rechargedAmount = rateWheelConf?.rechargedAmount;
                    if (!isNaN(unlockRechargeAmount) && !isNaN(rechargedAmount)) {
                        this.RC_lab_progress.string = `${we.core.langMgr.getLangText(HallLanguage.TOP_UP_1)}:${we.common.utils.formatPrice(rechargedAmount)}/${we.common.utils.formatPrice(unlockRechargeAmount)}`;
                        this.RC_spr_progressBar.fillRange = rechargedAmount / unlockRechargeAmount;
                    }
                }
            }

            // 设置奖励正常显示范围
            let showRange = we.common.activityMgr.dailyFreeAward.showRange || [];
            if (showRange.length > 1) {
                this.RC_lab_awardRang.string = `${we.common.utils.formatAmount(showRange[0], false)}~${we.common.utils.formatAmount(showRange[1], false)}`;
            }

            // 设置奖励划掉显示范围
            let isCrossRange = false;
            let crossRange = we.common.activityMgr.dailyFreeAward.crossRange || [];
            if (crossRange.length > 1) {
                isCrossRange = true;
                this.RC_lab_originRang.string = `${we.common.utils.formatAmount(crossRange[0], false)}~${we.common.utils.formatAmount(crossRange[1], false)}`;
            }
            this.RC_lab_originRang.node.active = isCrossRange;

            // 设置签到领取按钮状态
            let isReceive = we.common.activityMgr.dailyFreeAward.isGet;
            if (isReceive) {
                this.leftTime = we.common.activityMgr.dailyFreeAward.tomorrowSix - curTime;
                this.RC_lab_received.string = this.leftTime > 0 ? we.common.utils.formatSeconds(Math.ceil(this.leftTime)) : we.core.langMgr.getLangText(we.common.lang.COMMON_RECEIVED);
                this.isCountdown = this.leftTime > 0;
            }
            this.RC_btnGet.active = !isReceive;
            this.RC_btnReceived.active = isReceive;
        };

        we.common.activityMgr.getDailyFreeAwardConf().then((res) => {
            if (res) {
                initSignin();
            }
        });
    }

    private async getSucc(data: api.GetDailyFreeAwardResp) {
        we.core.timer.removeById(this.scheduleTime);
        this.RC_lab_award.string = '+' + we.common.utils.formatAmount(data.award, false);
        this.RC_lab_multiple.node.active = data.rateWheelUnlocked;
        if (data.rateWheelUnlocked) {
            this.RC_lab_multiple.string = `${we.common.utils.formatAmount(data.originAward, false)} X ${data.multipleRate}`;
            this.RC_lab_multiple['_forceUpdateRenderData']();
        }

        let curTime = we.core.TimeInfo.Inst.serverNow() / 1000;
        this.leftTime = we.common.activityMgr.dailyFreeAward?.tomorrowSix - curTime;
        this.RC_lab_received.string = this.leftTime > 0 ? we.common.utils.formatSeconds(Math.ceil(this.leftTime)) : we.core.langMgr.getLangText(we.common.lang.COMMON_RECEIVED);
        this.isCountdown = this.leftTime > 0;
        this.RC_btnGet.active = false;
        this.RC_btnReceived.active = true;

        if (this.turnTime < this.maxTurnTime) {
            await we.core.timer.scheduleOnce(this.maxTurnTime - this.turnTime, this);
            this.stopTurntable = true;
            return;
        }
        this.stopTurntable = true;
    }

    private countdownShow(dt: number): void {
        if (this.isCountdown) {
            this.leftTime -= dt;
            if (this.leftTime > 0) {
                this.RC_lab_received.string = we.common.utils.formatSeconds(Math.ceil(this.leftTime));
            } else {
                this.isCountdown = false;
                this.RC_btnReceived.active = false;
                this.RC_btnGet.active = true;
            }
        }
    }

    private turnTableAnim(dt: number): void {
        if (this.isTurntable) {
            this.turnTime += dt;
            if (this.stopTurntable) {
                this.curSpeed -= dt * this.addSpeed;
                if (this.curSpeed <= 0) {
                    this.curSpeed = 0;
                    this.isTurntable = false;
                    this.RC_pointerAnim.getComponent(sp.Skeleton)?.setAnimation(0, 'animation3', false);
                    this.RC_awardBg.active = true;
                    this.RC_awardBg.scale = 0;
                    this.tween(this.RC_awardBg)
                        .to(0.3, { scale: 1 }, { easing: 'backOut' })
                        .call(() => {
                            cc.director.emit(HallEvent.ACTIVITY_CENTER_MASK, false);
                            this.playAward(this.awardData);
                        })
                        .start();
                }
            } else {
                this.curSpeed += dt * this.addSpeed;
                this.curSpeed = this.curSpeed > this.maxSpeed ? this.maxSpeed : this.curSpeed;
            }

            this.curAngle -= this.curSpeed * dt;
            this.RC_turntableSmall.angle = this.curAngle;
            if (this.multipleUnlock) {
                this.RC_turntableBig.angle = this.curAngle;
            }
        }
    }

    private playAward(data: api.GetDailyFreeAwardResp): void {
        if (!data) {
            return;
        }

        let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.award }];
        HallMgr.openGetAwardsDlg(awardMap);
    }
}
