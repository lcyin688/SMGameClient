import { HallLanguage } from '../../../const/HallLanguage';
import { HallViewId } from '../../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('ActivityDailyAwardRuleDlgView_v', we.bundles.hall)
class ActivityDailyAwardRuleDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ruleLb1: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('ActivityDailyAwardRuleDlg_v', we.bundles.hall)
export class ActivityDailyAwardRuleDlg_v extends we.ui.DlgSystem<ActivityDailyAwardRuleDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        // 设置倍数轮盘
        let rateWheelConf = we.common.activityMgr.dailyFreeAward?.rateWheelConf;
        if (rateWheelConf) {
            // 设置规则多语言
            let unlockRechargeAmount = rateWheelConf?.unlockRechargeAmount;
            if (!isNaN(unlockRechargeAmount)) {
                this.view.RC_lab_ruleLb1.string = we.core.langMgr.getLangText(HallLanguage.DAILY_FREE_COINS_2, we.common.utils.formatPrice(unlockRechargeAmount, false, false));
            }
        }
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(ActivityDailyAwardRuleDlg_v, `${HallViewId.ActivityDailyAwardRuleDlg}_v`)
class ActivityDailyAwardRuleDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(ActivityDailyAwardRuleDlg_v, uiBase.addComponent(ActivityDailyAwardRuleDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ActivityDailyAwardRuleDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<ActivityDailyAwardRuleDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(ActivityDailyAwardRuleDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ActivityDailyAwardRuleDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(ActivityDailyAwardRuleDlg_v).beforeUnload();
    }
}
