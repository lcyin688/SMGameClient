const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityAccountSafe_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bind: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.RCN_bind, we.core.Func.create(this.onClickBind, this));

        this.init();
    }

    private init(): void {
        const award = we.core.projectConfig.settingsConfig?.phoneBindReward?.[we.common.userMgr.PropId.CoinId];
        if (award > 0) {
            this.RC_lab_award.string = we.common.utils.formatAmountCurrency(award);
        } else {
            this.RC_lab_award.string = '';
        }
    }

    private onClickBind(): void {
        const phoneEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Phone);
        const emailEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Email);
        if ((phoneEnabled && we.common.userMgr.userInfo.phone.length === 0) || (emailEnabled && we.common.userMgr.userInfo.emailAccount.length === 0)) {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg, 0, null, we.common.userMgr.userInfo.phone.length > 0);
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.SETTING_BOUND_TIPS));
        }
    }
}
