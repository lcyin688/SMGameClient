import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityPenPenDelivery_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_go: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ratio: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_ratio: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.RC_go, we.core.Func.create(this.onClick, this));

        this.init();
    }

    private onClick(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Recharge);
    }

    private init(): void {
        let rechargeTypeCategory = we.common.storeMgr.shopConf?.rechargeTypeCategory;
        if (!rechargeTypeCategory) {
            we.common.storeMgr.getShopConfig(
                (data: api.ShopConfResp) => {
                    if (!data || !cc.isValid(this.RC_lab_ratio)) {
                        return;
                    }
                    this.updateRatio();
                },
                null,
                false
            );
        } else {
            this.updateRatio();
        }
    }

    private updateRatio() {
        let payChannels: api.RechargeTypeCategory[] = we.common.storeMgr?.shopConf?.rechargeTypeCategory || [];
        let ratioNum = 0;
        for (let i = 0; i < payChannels.length; i++) {
            if (payChannels[i].rechargeGiftScale > ratioNum) {
                ratioNum = payChannels[i].rechargeGiftScale;
            }
        }
        this.RC_ratio.active = ratioNum > 0;
        this.RC_lab_ratio.string = `+${ratioNum / 100}%`;
    }
}
