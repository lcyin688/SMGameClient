import { HallEvent } from '../../../config/HallEvent';
import JumpModMgr from '../../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityAgent_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_award: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_awardTips: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_bonus: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_code: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_go: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_invite: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_codeAward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_inviteAward: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.RC_awardTips.active = false;
        this.RC_award.active = false;
        this.RC_invite.active = false;
        this.RC_code.active = false;
        this.RC_bonus.active = false;

        this.onBtnClick(this.RC_go, we.core.Func.create(this.onClick, this));

        we.common.agentMgr.getConfig(() => {
            if (cc.isValid(this.node)) {
                this.init();
            }
        });
    }

    private onClick(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Agent);
        cc.director.emit(HallEvent.ACTIVITY_CENTER_OPEN_OTHER);
    }

    private init(): void {
        let inviteReward = we.common.agentMgr.agentConfig?.inviteReward;
        if (inviteReward) {
            if (inviteReward.rechargeAmount > 0) {
                this.RC_invite.active = true;
                this.RC_lab_inviteAward.string = we.common.utils.formatPrice(inviteReward.rechargeAmount, false);
            }
            if (inviteReward.betAmount > 0) {
                this.RC_code.active = true;
                this.RC_lab_codeAward.string = we.common.utils.formatAmount(inviteReward.betAmount, true);
            }
            if (inviteReward.rewardCoin > 0) {
                this.RC_awardTips.active = true;
                this.RC_award.active = true;
                this.RC_lab_award.string = we.common.utils.formatAmount(inviteReward.rewardCoin, true);
            }
            let active = false;
            switch (we.core.langMgr.getCurLangCode()) {
                case we.core.LangCode.en:
                    active = true;
                    break;
                case we.core.LangCode.pt:
                    active = true;
                    break;
                default:
                    active = false;
                    break;
            }
            this.RC_bonus.active = active;
        }
    }
}
