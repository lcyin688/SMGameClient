import { HallLanguage } from '../../../const/HallLanguage';
import HallMgr from '../../../manager/HallMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityWithdrawal_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_bg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_isBind: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_jumpBind: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_jumpWithdrawal: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bindAward1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bindAward2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_draw: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_withdrawalDesc1: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        const award = we.core.projectConfig.settingsConfig?.phoneBindReward?.[we.common.userMgr.PropId.CoinId];
        if (award && award > 0) {
            this.RC_lab_bindAward1.string = we.common.utils.formatAmount(award, false);
            this.RC_lab_bindAward2.string = we.common.utils.formatAmountCurrency(award);
        }
        if (we.common.withdrawMgr.config) {
            this.RC_lab_draw.getComponent(cc.Label).string = we.common.utils.formatAmount(we.common.withdrawMgr.config?.activityMinWithDraw, false);
            this.RC_lab_withdrawalDesc1.string = we.core.langMgr.getLangText(HallLanguage.EVENT_FIRST_WITHDRAW_1, we.common.withdrawMgr.config?.activityParticipationLimit);
        }

        this.onBtnClick(this.RC_jumpWithdrawal, we.core.Func.create(this.onClickJumpWithdrawal, this));
        this.onBtnClick(this.RC_jumpBind, we.core.Func.create(this.onClickJumpBind, this));

        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateBindBtn, this);
    }

    protected onEnable(): void {
        this.setBindBtn();
    }

    protected onDestroy(): void {
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateBindBtn, this);
    }

    private onClickJumpBind() {
        we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
    }

    private onClickJumpWithdrawal() {
        HallMgr.openWithdraw();
    }

    private onUpdateBindBtn(): void {
        this.setBindBtn();
    }

    private setBindBtn(): void {
        let isFormal = we.common.userMgr.isFormal();
        this.setBindStatus(!isFormal);
    }

    private setBindStatus(value: boolean): void {
        this.RC_jumpBind.active = value;
        this.RC_isBind.active = !value;
    }
}
