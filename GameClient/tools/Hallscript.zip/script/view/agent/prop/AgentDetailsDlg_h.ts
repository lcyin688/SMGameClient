import { HallRes } from '../../../config/HallRes';
import { HallLanguage } from '../../../const/HallLanguage';
import { HallViewId } from '../../HallViewId';
import AgentDetailsList_h from './AgentDetailsList_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentDetailsDlgView_h', we.bundles.hall)
class AgentDetailsDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_content: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_title: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_details: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentDetailsDlg_h', we.bundles.hall)
export class AgentDetailsDlg_h extends we.ui.DlgSystem<AgentDetailsDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(type: number) {
        const itemPrefab = await this.loadAsset(HallRes.prefab.agent.AgentDetailsList, cc.Prefab);
        let node = cc.instantiate(itemPrefab);
        node.getComponent(AgentDetailsList_h)?.setContextData(type);
        this.view.RCN_details.addChild(node);

        let langKey = null;
        switch (type) {
            case we.common.agentMgr.Detail_Type.INVITE_REBATE:
                langKey = HallLanguage.INVITE_DETAILS_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.INVITE_REWARD:
                langKey = HallLanguage.INVITE_REWARDS_RECORD_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.BET_REWARD:
                langKey = HallLanguage.INVITE_BETTING_RECORD_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.RECHARGE_REWARD:
                langKey = HallLanguage.INVITE_REBATE_RECORD_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.VALID_REWARD:
                langKey = HallLanguage.INVITE_DETAILS_Bonus10;
                break;
            default:
                break;
        }

        if (langKey) {
            let titleStr = we.core.langMgr.getLangText(langKey);
            this.view.RC_title.string = titleStr;
            this.view.RC_lab_content && (this.view.RC_lab_content.string = titleStr);
        }
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentDetailsDlg_h, `${HallViewId.AgentDetailsDlg}_h`)
class AgentDetailsDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentDetailsDlg_h, uiBase.addComponent(AgentDetailsDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDetailsDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentDetailsDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentDetailsDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDetailsDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentDetailsDlg_h).beforeUnload();
    }
}
