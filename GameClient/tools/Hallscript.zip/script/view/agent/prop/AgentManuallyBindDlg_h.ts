import { HallLanguage } from '../../../const/HallLanguage';
import { HallViewId } from '../../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentManuallyBindDlgView_h', we.bundles.hall)
class AgentManuallyBindDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnBind: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_id: cc.EditBox = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_gray: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentManuallyBindDlg_h', we.bundles.hall)
export class AgentManuallyBindDlg_h extends we.ui.DlgSystem<AgentManuallyBindDlgView_h> {
    private bindCallBack: Function = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.onEditingChanged();
        this.view.RC_edit_id.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.INVITE_HAll_Bonus17);

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnBind, we.core.Func.create(this.onClickBind, this));

        this.view.cc_onEditBoxEvent(this.view.RC_edit_id.node, 'editingDidBegan', we.core.Func.create(this.onEditingDidBegan, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_id.node, 'textChanged', we.core.Func.create(this.onEditingChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_id.node, 'editingDidEnded', we.core.Func.create(this.onEditingDidEnded, this));
    }

    /** 显示窗口 */
    public async onShow(bindCallBack: Function) {
        this.bindCallBack = bindCallBack;
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onClickBind(): void {
        we.common.agentMgr.bindUpAgent(Number(this.view.RC_edit_id.string), (data: api.BindAgentResp) => {
            let langKey: string = '';
            if (data.code == 0) {
                we.common.storage.setById('common', 'agent_superior', this.view.RC_edit_id.string);
                typeof this.bindCallBack == 'function' && this.bindCallBack(this.view.RC_edit_id.string);
                langKey = HallLanguage.INVITE_Bind_Hint_Bonus1;

                if (cc.isValid(this.view.uiRoot)) {
                    this.closeView();
                }
            } else if (data.code == 1) {
                langKey = HallLanguage.INVITE_Bind_Hint_Bonus2;
            } else if (data.code == 2) {
                langKey = HallLanguage.INVITE_Bind_Hint_Bonus3;
            } else if (data.code == 3) {
                langKey = HallLanguage.INVITE_Bind_Hint_Bonus4;
            } else if (data.code == 4) {
                langKey = HallLanguage.INVITE_Bind_Hint_Bonus5;
            } else if (data.code == 5) {
                langKey = HallLanguage.INVITE_Bind_Hint_Bonus6;
            } else if (data.code == 6) {
                langKey = HallLanguage.INVITE_Bind_Hint_Bonus7;
            }
            we.commonUI.showToast(we.core.langMgr.getLangText(langKey));
        });
    }

    private onEditingDidBegan() {
        this.view.RC_edit_id.placeholderLabel.string = '';
    }

    private onEditingDidEnded() {
        if (this.view.RC_edit_id.string == '') {
            this.view.RC_edit_id.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.INVITE_HAll_Bonus17);
        }
    }

    private onEditingChanged() {
        if (this.view.RC_edit_id.string == '') {
            this.setBindStatus(false);
        } else {
            this.setBindStatus(true);
        }
    }

    private setBindStatus(value: boolean): void {
        this.view.RC_btnBind.active = value;
        this.view.RCN_gray.active = !value;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentManuallyBindDlg_h, `${HallViewId.AgentManuallyBindDlg}_h`)
class AgentManuallyBindDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentManuallyBindDlg_h, uiBase.addComponent(AgentManuallyBindDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentManuallyBindDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentManuallyBindDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentManuallyBindDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentManuallyBindDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentManuallyBindDlg_h).beforeUnload();
    }
}
