import { HallRes } from '../../../config/HallRes';
import { HallViewId } from '../../HallViewId';
import AgentDetailsList_v from './AgentDetailsList_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentDetailsDlgView_v', we.bundles.hall)
class AgentDetailsDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_details: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentDetailsDlg_v', we.bundles.hall)
export class AgentDetailsDlg_v extends we.ui.DlgSystem<AgentDetailsDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        const itemPrefab = await this.loadAsset(HallRes.prefab.agent.AgentDetailsList, cc.Prefab);
        let node = cc.instantiate(itemPrefab);
        node.getComponent(AgentDetailsList_v)?.setContextData(we.common.agentMgr.Detail_Type.INVITE_REBATE);
        this.view.RCN_details.addChild(node);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentDetailsDlg_v, `${HallViewId.AgentDetailsDlg}_v`)
class AgentDetailsDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentDetailsDlg_v, uiBase.addComponent(AgentDetailsDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDetailsDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentDetailsDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentDetailsDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDetailsDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentDetailsDlg_v).beforeUnload();
    }
}
