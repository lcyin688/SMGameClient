import { HallViewId } from '../../HallViewId';
import AgentRewardRecordItem_h from './AgentRewardRecordItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentRewardRecordDlgView_h', we.bundles.hall)
class AgentRewardRecordDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_noData: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentRewardRecordDlg_h', we.bundles.hall)
export class AgentRewardRecordDlg_h extends we.ui.DlgSystem<AgentRewardRecordDlgView_h> {
    private recordList: api.AgentDrawRewardRecordItem[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RCN_noData.active = false;

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.getRewardRecordData();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private getRewardRecordData(): void {
        we.common.agentMgr.getDrawRewardRecord((data: api.AgentDrawRewardRecordResp) => {
            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }

            this.recordList = data?.rewardRecord || [];
            this.view.RCN_noData.active = this.recordList.length <= 0;
            this.addRecordItem();
        });
    }

    private addRecordItem(): void {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list.numItems = this.recordList.length;
    }

    private onRenderEvent(item: cc.Node, i: number): void {
        const record: api.AgentDrawRewardRecordItem = this.recordList[i];
        let recordItem = item.getComponent(AgentRewardRecordItem_h);
        recordItem?.init(record);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentRewardRecordDlg_h, `${HallViewId.AgentRewardRecordDlg}_h`)
class AgentRewardRecordDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentRewardRecordDlg_h, uiBase.addComponent(AgentRewardRecordDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentRewardRecordDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentRewardRecordDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentRewardRecordDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentRewardRecordDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentRewardRecordDlg_h).beforeUnload();
    }
}
