import { HallLanguage } from '../../../const/HallLanguage';
import { CalendarCurrentDate, CalendarDateBetween } from '../../../extend/util/CalendarModel';
import CalendarUtil from '../../../extend/util/CalendarUtil';
import Calendar_v from '../calendar/Calendar_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentDetailsList_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnBack: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnCalendar: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnSearch: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_detailsNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_detailsTitle: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_endTime: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_id: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_num: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_startTime: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_timeTitle: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RCN_head: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_noData: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_thead: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property(cc.Prefab)
    private theadPre: cc.Prefab[] = [];

    @property(cc.Prefab)
    private itemPre: cc.Prefab[] = [];

    @property(cc.Prefab)
    private calendarPrefab: cc.Prefab = null;

    private calendarNode: cc.Node = null;
    private calendarComp: Calendar_v = null;
    private startTime: number = 0;
    private endTime: number = 0;

    /** 是否包括今天 */
    private includeToday: boolean = true;
    /** 每页数据条数 */
    private pageNum: number = 20;
    /** 默认查询天数 */
    private normalDay: number = 3;
    /** 查询代理层级 */
    private detailZIndex: number = 1;
    /** 邀请人头奖励 开始条数 */
    private personStartNum: number = 0;

    /** 当前受益人ID */
    private rewardUserId: number = 0;
    /** 上上级ID */
    private upupId: number = 0;
    private dataIsNoMore: boolean = false;
    private isGetting: boolean = false;
    private type: number = -1;
    private userDataMap = new Map();

    protected onLoad(): void {
        this.type = this._context;

        this.RC_btnBack.active = false;
        this.RCN_noData.active = false;

        this.onBtnClick(this.RC_btnSearch, we.core.Func.create(this.onClickSearchBtn, this));
        this.onBtnClick(this.RC_btnCalendar, we.core.Func.create(this.onClickCalendar, this)).setSleepTime(0.8);
        this.onBtnClick(this.RC_btnBack, we.core.Func.create(this.onClickBackBtn, this));

        this.RC_list.scrollView.node.on('scroll-to-bottom', this.scrollToBottom, this);
        cc.director.on(we.core.EventName.FULL_TOUCH_START, this.onFullTouchStart, this);

        this.init(this.type);
    }

    protected onDestroy(): void {
        cc.director.off(we.core.EventName.FULL_TOUCH_START, this.onFullTouchStart, this);
    }

    private clearList(): void {
        this.RC_list.numItems = 0;
        this.RC_list.scrollTo(0, 0);
    }

    private init(type: number): void {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.rewardUserId = we.common.userMgr.userInfo.userId;
        this.type = type;
        if (type == we.common.agentMgr.Detail_Type.INVITE_REWARD || type == we.common.agentMgr.Detail_Type.VALID_REWARD) {
            this.includeToday = false;
        }
        this.loadHead();
        if (this.calendarPrefab) {
            this.initCalendarHead(this.eventHandel.bind(this));
        }
    }

    private eventHandel(): void {
        switch (this.type) {
            case we.common.agentMgr.Detail_Type.INVITE_REBATE:
                this.initInviteRebateData();
                break;
            case we.common.agentMgr.Detail_Type.INVITE_REWARD:
                this.initInviteRewardData();
                break;
            case we.common.agentMgr.Detail_Type.BET_REWARD:
                this.initCodeRebateData();
                break;
            case we.common.agentMgr.Detail_Type.RECHARGE_REWARD:
                this.initRechargeRewardData();
                break;
            case we.common.agentMgr.Detail_Type.VALID_REWARD:
                this.initQuantityRewardData();
                break;
            default:
                break;
        }
    }

    private loadHead(): void {
        this.RC_lab_detailsTitle.string = we.core.langMgr.getLangText(HallLanguage.INVITE_DETAILS_Bonus2);
        this.RC_lab_timeTitle.string = we.core.langMgr.getLangText(HallLanguage.INVITE_DETAILS_Bonus3);
        this.RCN_thead.removeAllChildren();
        let tHead: cc.Node = cc.instantiate(this.theadPre[0]);
        switch (this.type) {
            case we.common.agentMgr.Detail_Type.INVITE_REBATE:
                if (this.detailZIndex == 4) {
                    tHead = cc.instantiate(this.theadPre[2]);
                }
                tHead.children[2].getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage.INVITE_DETAILS_Bonus6);
                break;
            case we.common.agentMgr.Detail_Type.INVITE_REWARD:
                tHead = cc.instantiate(this.theadPre[1]);
                this.RC_lab_id.node.active = false;
                break;
            case we.common.agentMgr.Detail_Type.BET_REWARD:
                if (this.detailZIndex == 4) {
                    tHead = cc.instantiate(this.theadPre[2]);
                }
                tHead.children[2].getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage.INVITE_BETTING_RECORD_Bonus2);
                break;
            case we.common.agentMgr.Detail_Type.RECHARGE_REWARD:
                if (this.detailZIndex == 4) {
                    tHead = cc.instantiate(this.theadPre[2]);
                }
                tHead.children[2].getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_2);
                break;
            case we.common.agentMgr.Detail_Type.VALID_REWARD:
                tHead = cc.instantiate(this.theadPre[3]);
                this.RC_lab_detailsTitle.string = we.core.langMgr.getLangText(HallLanguage.INVITE_DETAILS_Bonus11);
                this.RC_lab_timeTitle.string = we.core.langMgr.getLangText(HallLanguage.INVITE_DETAILS_Bonus6);
                this.RC_lab_id.node.active = false;
                break;
            default:
                break;
        }
        this.RCN_thead.addChild(tHead);
    }

    /**
     * 邀请总详情
     * @param userId
     * @param startNum
     */
    private initInviteRebateData(userId?: number, startNum: number = 0): void {
        this.isGetting = true;
        // 默认3天
        let param: api.AgentInviteRewardDetailReq = {
            rewardId: we.common.userMgr.userInfo.userId,
            upId: userId ? userId : this.rewardUserId,
            level: this.detailZIndex,
            startNum: startNum,
            startTime: this.startTime / 1000,
            endTime: this.endTime / 1000,
            startTime_64: this.startTime / 1000,
            endTime_64: this.endTime / 1000,
        };
        we.common.agentMgr.getInviteRewardDetail(
            param,
            (data: api.AgentInviteRewardDetailResp) => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
                if (data) {
                    this.setUserInfoMap(data.rewardsList, data.total, data.totalEarn, param.upId, param.startNum);
                }
            },
            () => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
            }
        );
    }

    /**
     * 打码奖励详情
     * @param userId
     * @param startNum
     */
    private initCodeRebateData(userId?: number, startNum: number = 0): void {
        this.isGetting = true;
        // 默认3天
        let param: api.AgentBetAmountRewardsDetailReq = {
            rewardId: we.common.userMgr.userInfo.userId,
            upId: userId ? userId : this.rewardUserId,
            level: this.detailZIndex,
            startNum: startNum,
            startTime: this.startTime / 1000,
            endTime: this.endTime / 1000,
            startTime_64: this.startTime / 1000,
            endTime_64: this.endTime / 1000,
        };
        we.common.agentMgr.getBetAmountRewardsDetail(
            param,
            (data: api.AgentBetAmountRewardsDetailResp) => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
                if (data) {
                    this.setUserInfoMap(data.betAmountList, data.total, data.totalEarn, param.upId, param.startNum);
                }
            },
            () => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
            }
        );
    }

    /**
     * 充值奖励详情
     * @param userId
     * @param startNum
     */
    private initRechargeRewardData(userId?: number, startNum: number = 0): void {
        this.isGetting = true;
        // 默认3天
        let param: api.AgentRechargeRewardsDetailReq = {
            rewardId: we.common.userMgr.userInfo.userId,
            upId: userId ? userId : this.rewardUserId,
            level: this.detailZIndex,
            startNum: startNum,
            startTime: this.startTime / 1000,
            endTime: this.endTime / 1000,
            startTime_64: this.startTime / 1000,
            endTime_64: this.endTime / 1000,
        };
        we.common.agentMgr.getRechargeRewardsDetail(
            param,
            (data: api.AgentRechargeRewardsDetailResp) => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
                if (data) {
                    this.setUserInfoMap(data.rechargeList, data.total, data.totalEarn, param.upId, param.startNum);
                }
            },
            () => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
            }
        );
    }

    private setUserInfoMap(list, total: number, totalEarn: number, upId: number, startNum: number): void {
        if (upId != this.rewardUserId) {
            return;
        }
        this.RC_lab_num.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RECORD_Bonus4, total);
        this.RC_lab_detailsNum.string = we.common.utils.formatAmountCurrency(totalEarn);
        if (list?.length > 0) {
            this.showBodyItem(list, total, totalEarn, upId, startNum);
            let mapData = this.userDataMap.get(this.rewardUserId);
            if (!mapData) {
                let obj = {
                    dataList: list,
                    dataIsNoMore: list.length < 20,
                    upId: this.rewardUserId,
                    upupId: this.upupId,
                    startNum: 0,
                    startTime: this.startTime,
                    endTime: this.endTime,
                    totalPerson: total,
                    totalReward: totalEarn,
                };
                mapData = obj;
            } else {
                if (startNum > 0) {
                    mapData['dataList'] = (mapData['dataList'] || []).concat(list);
                } else {
                    mapData['dataList'] = list;
                }
                mapData['dataIsNoMore'] = list.length < 20;
                mapData['totalPerson'] = total;
                mapData['totalReward'] = totalEarn;
            }
            this.userDataMap.set(this.rewardUserId, mapData);
        } else {
            if (startNum == 0) {
                this.RCN_noData.active = true;
            }
            let mapData = this.userDataMap.get(this.rewardUserId);
            if (mapData) {
                mapData['dataIsNoMore'] = true;
            }
        }
    }

    /**
     * 显示列表数据
     * @param data
     * @param totalPerson
     * @param totalReward
     * @param upId
     */
    private showBodyItem(data, totalPerson: number, totalReward: number, upId: number, startNum: number): void {
        this.RC_lab_num.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RECORD_Bonus4, totalPerson);
        this.RC_lab_detailsNum.string = we.common.utils.formatAmountCurrency(totalReward);
        this.RC_lab_id.string = upId == 0 ? '' : 'ID: ' + upId;
        if (startNum == 0 && data.length == 0) {
            this.RCN_noData.active = true;
            return;
        }

        this.RC_list.setRenderEvent(we.core.Func.create(this.onItemRenderEvent, this, data));
        this.RC_list.numItems = data.length;
    }

    private onItemRenderEvent(data, item: cc.Node, i: number): void {
        item.removeAllChildren();

        let curData = data[i];
        let tBody = cc.instantiate(this.itemPre[0]);
        if (this.detailZIndex == 4) {
            tBody = cc.instantiate(this.itemPre[2]);
        } // 四级后不能在查看下级
        tBody.children[1].getComponent(cc.Label).string = '' + curData?.userId;
        tBody.children[2].getComponent(cc.Label).string = '' + curData?.userName;
        tBody.children[4].getComponent(cc.Label).string = '' + we.common.utils.formatAmountCurrency(curData?.reward);
        if (this.detailZIndex < 4) {
            this.onBtnClick(tBody.children[5], we.core.Func.create(this.clickCheckBelowBtn, this, curData?.userId));
        }
        let str = '';
        switch (this.type) {
            case we.common.agentMgr.Detail_Type.INVITE_REBATE:
                str = we.common.utils.formatDate(new Date(curData?.invitationTime_64 * 1000), we.core.flavor.getCountryDateFormate());
                break;
            case we.common.agentMgr.Detail_Type.BET_REWARD:
                str = we.common.utils.formatAmountCurrency(curData?.betAmount);
                break;
            case we.common.agentMgr.Detail_Type.RECHARGE_REWARD:
                str = we.common.utils.formatPrice(curData?.rechargeAmount, true, false);
                break;
            default:
                break;
        }
        tBody.children[3].getComponent(cc.Label).string = str;
        item.addChild(tBody);
    }

    /**
     * 加载邀请返利列表
     */
    private initInviteRewardData(): void {
        this.isGetting = true;
        // 默认3天，不能选当天
        let param: api.AgentInvitationRewardsDetailReq = {
            rewardId: this.rewardUserId,
            startNum: this.personStartNum,
            startTime: this.startTime / 1000,
            endTime: this.endTime / 1000,
            startTime_64: this.startTime / 1000,
            endTime_64: this.endTime / 1000,
        };
        we.common.agentMgr.getInvitationRewardsDetail(
            param,
            (data: api.AgentInvitationRewardsDetailResp) => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
                if (data) {
                    this.RC_lab_num.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RECORD_Bonus4, data.total);
                    this.RC_lab_detailsNum.string = we.common.utils.formatAmountCurrency(data.totalEarn);
                    if (data.invitationList?.length > 0) {
                        this.RC_list.setRenderEvent(we.core.Func.create(this.onInviteRewardRenderEvent, this, data.invitationList));
                        this.RC_list.numItems = data.invitationList.length;
                    } else {
                        this.RCN_noData.active = true;
                    }
                    this.dataIsNoMore = data.invitationList.length < this.pageNum;
                }
            },
            () => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
            }
        );
    }

    private onInviteRewardRenderEvent(data: api.InvitationInfo[], item: cc.Node, i: number): void {
        item.removeAllChildren();

        let curData = data[i];
        let tBody = cc.instantiate(this.itemPre[1]);
        tBody.children[1].getComponent(cc.Label).string = '' + curData?.userId;
        tBody.children[2].getComponent(cc.Label).string = '' + curData?.userName;
        tBody.children[3].getComponent(cc.Label).string = '' + we.common.utils.formatDate(new Date(curData?.invitationTime_64 * 1000), we.core.flavor.getCountryDateFormate());
        tBody.children[4].getComponent(cc.Label).string = '' + we.common.utils.formatPrice(curData?.rechargeAmount, true, false);
        tBody.children[5].getComponent(cc.Label).string = '' + we.common.utils.formatAmountCurrency(curData?.betAmount);
        tBody.children[6].getComponent(cc.Label).string = '' + we.common.utils.formatAmountCurrency(curData?.reward);

        item.addChild(tBody);
    }

    /**
     * 加载有效邀请人数详情列表
     */
    private initQuantityRewardData(): void {
        this.isGetting = true;
        // 默认3天，不能选当天
        let param: api.ValidAgentRewardsDetailReq = {
            rewardId: this.rewardUserId,
            startNum: this.personStartNum,
            startTime: this.startTime / 1000,
            endTime: this.endTime / 1000,
            startTime_64: this.startTime / 1000,
            endTime_64: this.endTime / 1000,
        };
        we.common.agentMgr.getValidAgentRewardsDetail(
            param,
            (data: api.ValidAgentRewardsDetailResp) => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
                if (data) {
                    this.RC_lab_num.string = we.core.langMgr.getLangText(HallLanguage.INVITE_DETAILS_Bonus16) + data.totalAgentNum;
                    this.RC_lab_detailsNum.string = '' + data.validAgentNum;
                    if (data.validAgent?.length > 0) {
                        this.RC_list.setRenderEvent(we.core.Func.create(this.onQuantityRewardRenderEvent, this, data.validAgent));
                        this.RC_list.numItems = data.validAgent.length;
                    } else {
                        this.RCN_noData.active = true;
                    }
                    this.dataIsNoMore = data.validAgent.length < this.pageNum;
                }
            },
            () => {
                if (!cc.isValid(this.node)) {
                    return;
                }
                this.isGetting = false;
            }
        );
    }

    private onQuantityRewardRenderEvent(data: api.ValidAgentRewardsDetailItem[], item: cc.Node, i: number): void {
        item.removeAllChildren();

        let curData = data[i];
        let tBody = cc.instantiate(this.itemPre[3]);
        tBody.children[1].getComponent(cc.Label).string = '' + curData?.userId;
        tBody.children[2].getComponent(cc.Label).string = '' + we.common.utils.formatDate(new Date(curData?.invitationTime_64 * 1000), we.core.flavor.getCountryDateFormate() + ' hh:mm:ss');
        tBody.children[3].getComponent(cc.Label).string = we.common.utils.formatPrice(curData?.rechargeAmount, true, false);
        tBody.children[4].getComponent(cc.Label).string = we.common.utils.formatAmountCurrency(curData?.betAmount);
        tBody.children[5].getComponent(cc.Label).string = '--';
        if (curData?.attainSillTime) {
            tBody.children[5].getComponent(cc.Label).string = '' + we.common.utils.formatDate(new Date(curData.attainSillTime * 1000), we.core.flavor.getCountryDateFormate() + ' hh:mm:ss');
        }

        item.addChild(tBody);
    }

    /**
     * 点击下级的查看按钮
     * @param userId
     */
    private clickCheckBelowBtn(userId: number): void {
        if (this.isGetting) {
            return;
        }

        this.clearList();
        this.RC_btnBack.active = true;
        this.RC_lab_id.string = 'ID: ' + userId;
        this.upupId = this.rewardUserId;
        this.rewardUserId = userId;
        this.personStartNum = 0;
        this.detailZIndex += 1;
        // 四级后不能在查看下级 需要重新加载表格标题
        if (this.detailZIndex == 4) {
            this.loadHead();
        }
        this.eventHandel();
    }

    private initCalendarHead(callback: Function): void {
        let endDate = new Date(new Date().getTime() - (this.includeToday ? 0 : 24 * 60 * 60 * 1000));
        let endDay = {} as CalendarCurrentDate;
        endDay.year = endDate.getFullYear();
        endDay.month = endDate.getMonth() + 1;
        endDay.day = endDate.getDate();
        endDay.hours = this.includeToday ? endDate.getHours() : 23;
        endDay.minutes = this.includeToday ? endDate.getMinutes() : 59;
        endDay.seconds = this.includeToday ? endDate.getSeconds() : 59;

        // 默认3天
        let startDate = new Date(new Date().getTime() - (this.includeToday ? this.normalDay - 1 : this.normalDay) * 24 * 60 * 60 * 1000);
        let startDay = {} as CalendarCurrentDate;
        startDay.year = startDate.getFullYear();
        startDay.month = startDate.getMonth() + 1;
        startDay.day = startDate.getDate();

        let selectedTime = {
            start: CalendarUtil.copyDate(startDay),
            end: CalendarUtil.copyDate(endDay),
        };
        this.updateCalendar(selectedTime, callback);
    }

    private handelCalendarTime(startTime, endTime): void {
        endTime = new Date(endTime);
        startTime = new Date(startTime);
        let endDay = {} as CalendarCurrentDate;
        endDay.year = endTime.getFullYear();
        endDay.month = endTime.getMonth() + 1;
        endDay.day = endTime.getDate();
        endDay.hours = endTime.getHours();
        endDay.minutes = endTime.getMinutes();
        endDay.seconds = endTime.getSeconds();

        // 默认3天
        let startDay = {} as CalendarCurrentDate;
        startDay.year = startTime.getFullYear();
        startDay.month = startTime.getMonth() + 1;
        startDay.day = startTime.getDate();

        let selectedTime = {
            start: CalendarUtil.copyDate(startDay),
            end: CalendarUtil.copyDate(endDay),
        };
        this.updateCalendar(selectedTime);
        this.calendarComp?.updateStartEndDay(selectedTime);
    }

    // 时间选择框时间
    private updateCalendar(between: CalendarDateBetween, callback?: Function): void {
        let startDate = new Date(between.start.year, between.start.month - 1, between.start.day);
        this.startTime = startDate.getTime();
        let endDate = new Date(between.end.year, between.end.month - 1, between.end.day, between.end.hours, between.end.minutes, between.end.seconds);
        this.endTime = endDate.getTime();

        this.RC_lab_startTime.string = we.common.utils.formatDate(startDate, we.core.flavor.getCountryDateFormate()); // `${between.start.year}-${between.start.month}-${between.start.day}`;
        this.RC_lab_endTime.string = we.common.utils.formatDate(endDate, we.core.flavor.getCountryDateFormate()); // `${between.end.year}-${between.end.month}-${between.end.day}`;
        typeof callback == 'function' && callback();
    }

    private onClickCalendar(): void {
        if (!this.calendarComp) {
            this.calendarNode = cc.instantiate(this.calendarPrefab);
            this.RCN_head.addChild(this.calendarNode);
            this.calendarComp = this.calendarNode.getComponent(Calendar_v);
            this.calendarComp.init(this.includeToday, this.normalDay, this.updateCalendar.bind(this));
        } else {
            this.calendarNode.active = !this.calendarNode.active;
        }
    }

    private onFullTouchStart(e): void {
        const worldPoint = e._point;
        if (this.calendarNode && this.calendarNode.active) {
            const worldBoundingBox = this.calendarNode.getBoundingBoxToWorld();
            if (!(worldPoint instanceof cc.Vec2) || !(worldBoundingBox instanceof cc.Rect)) {
                return;
            }
            if (this.pointInRect(worldPoint, worldBoundingBox)) {
                return;
            }

            const worldPanelBoundBox = this.RC_btnCalendar.getBoundingBoxToWorld();
            if (!(worldPoint instanceof cc.Vec2) || !(worldPanelBoundBox instanceof cc.Rect)) {
                return;
            }
            if (this.pointInRect(worldPoint, worldPanelBoundBox)) {
                return;
            }
            this.calendarNode.active = false;
        }
    }

    /**
     * 点击底部返回按钮
     */
    private onClickBackBtn(): void {
        this.clearList();
        this.RCN_noData.active = false;
        this.detailZIndex -= 1;
        if (this.detailZIndex == 3) {
            this.loadHead();
        }
        let mapData = null;
        mapData = this.userDataMap.get(this.upupId);
        if (mapData) {
            this.showBodyItem(mapData['dataList'], mapData['totalPerson'], mapData['totalReward'], mapData['upId'] || we.common.userMgr.userInfo.userId, mapData['startNum']);
            this.handelCalendarTime(mapData['startTime'], mapData['endTime']);
        }
        let upMapData = null;
        upMapData = this.userDataMap.get(mapData['upupId']);
        this.userDataMap.delete(this.rewardUserId);
        if (upMapData) {
            this.upupId = mapData['upupId'];
            this.rewardUserId = mapData['upId'];
        } else {
            this.upupId = 0;
            this.rewardUserId = we.common.userMgr.userInfo.userId;
        }
        if (this.detailZIndex == 1) {
            this.RC_btnBack.active = false;
        }
    }

    private onClickSearchBtn(): void {
        let mapData = this.userDataMap.get(this.rewardUserId);
        if (mapData) {
            mapData['dataList'] = [];
            mapData['startNum'] = 0;
            mapData['dataIsNoMore'] = false;
            mapData['startTime'] = this.startTime;
            mapData['endTime'] = this.endTime;
            this.userDataMap.set(this.rewardUserId, mapData);
        }
        this.clearList();
        this.RCN_noData.active = false;
        this.eventHandel();
    }

    private scrollToBottom(): void {
        if (this.isGetting) {
            return;
        }
        if (this.type == we.common.agentMgr.Detail_Type.INVITE_REWARD) {
            if (this.dataIsNoMore) {
                return;
            }
            this.personStartNum += 20;
            this.initInviteRewardData();
        } else if (this.type == we.common.agentMgr.Detail_Type.VALID_REWARD) {
            if (this.dataIsNoMore) {
                return;
            }
            this.personStartNum += 20;
            this.initQuantityRewardData();
        } else {
            let mapData = this.userDataMap.get(this.rewardUserId);
            if (!mapData || mapData['dataIsNoMore']) {
                return;
            }
            mapData['startNum'] += 20;
            this.userDataMap.set(this.rewardUserId, mapData);
            if (this.type == we.common.agentMgr.Detail_Type.INVITE_REBATE) {
                this.initInviteRebateData(this.rewardUserId, mapData['startNum']);
            } else if (this.type == we.common.agentMgr.Detail_Type.BET_REWARD) {
                this.initCodeRebateData(this.rewardUserId, mapData['startNum']);
            } else if (this.type == we.common.agentMgr.Detail_Type.RECHARGE_REWARD) {
                this.initRechargeRewardData(this.rewardUserId, mapData['startNum']);
            }
        }
    }

    private pointInRect(point, rect: cc.Rect): boolean {
        const vecs = [cc.v2(rect.x, rect.y), cc.v2(rect.x + rect.width, rect.y), cc.v2(rect.x + rect.width, rect.y + rect.height), cc.v2(rect.x, rect.y + rect.height)];
        return cc.Intersection.pointInPolygon(point, vecs);
    }
}
