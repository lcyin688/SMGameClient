const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentRewardRecordItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_reward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(record: api.AgentDrawRewardRecordItem): void {
        this.__initRc();

        this.RC_lab_time.string = '' + we.common.utils.formatDate(new Date(record?.drawRewardTime * 1000), we.core.flavor.getCountryDateFormate() + ' hh:mm:ss');
        this.RC_lab_reward.string = we.common.utils.formatAmountCurrency(record?.drawRewardNum);
    }
}
