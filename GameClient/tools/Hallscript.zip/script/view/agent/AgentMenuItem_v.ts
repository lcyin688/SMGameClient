import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentMenuItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_offDesc: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_onDesc: cc.Label = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_spr_offIcon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_spr_onIcon: we.ui.WESpriteIndex = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(index: number): void {
        this.__initRc();

        let langKey = null;
        switch (index) {
            case we.common.agentMgr.Detail_Type.INVITE_REBATE:
                langKey = HallLanguage.INVITE_HAll_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.INVITE_REWARD:
                langKey = HallLanguage.INVITE_REWARDS_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.BET_REWARD:
                langKey = HallLanguage.INVITE_BETTING_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.RECHARGE_REWARD:
                langKey = HallLanguage.INVITE_REBATE_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.VALID_REWARD:
                langKey = HallLanguage.INVITE_QUANTITY_Bonus1;
                break;
            default:
                break;
        }
        if (langKey) {
            let descStr = we.core.langMgr.getLangText(langKey);
            this.RC_lab_offDesc.string = descStr;
            this.RC_lab_onDesc.string = descStr;
        }

        this.RC_spr_offIcon.setIndex(index);
        this.RC_spr_onIcon.setIndex(index);
    }
}
