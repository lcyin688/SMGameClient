import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentInviteReward_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnAllPeople: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnDetails: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTodayPeople: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_availableReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_inviteReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_inviteTotal: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_inviteValid: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_receivedReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_todayReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_todayTotal: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_todayValid: cc.Label = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_allTips: cc.RichText = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_todayTips: cc.RichText = null;

    @we.ui.ccBind(cc.Node)
    public RCN_allTips: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_todayTips: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property(cc.Color)
    private tipsColor: cc.Color = null;

    protected onLoad(): void {
        this.onLoadTextLang();

        this.onBtnClick(this.RC_btnDetails, we.core.Func.create(this.onClickDetailsBtn, this));
        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRuleBtn, this));
        this.onBtnClick(this.RC_btnTodayPeople, we.core.Func.create(this.onClickTodayTips, this));
        this.onBtnClick(this.RC_btnAllPeople, we.core.Func.create(this.onClickAllTips, this));

        cc.director.on(we.core.EventName.FULL_TOUCH_END, this.hideTips, this);
    }

    protected onEnable(): void {
        this.getRewardData();
    }

    protected onDestroy(): void {
        cc.director.off(we.core.EventName.FULL_TOUCH_END, this.hideTips, this);
    }

    private getRewardData(): void {
        we.common.agentMgr.getInvitationRewards((data: api.AgentInvitationRewardsResp) => {
            if (data && cc.isValid(this.node)) {
                if (data.todayInvite) {
                    this.RC_lab_todayValid.string = '' + data.todayInvite.valid;
                    this.RC_lab_todayTotal.string = '/' + data.todayInvite.invite;
                    this.RC_lab_todayReward.string = we.common.utils.formatAmountCurrency(data.todayInvite.inviteReward);
                }
                if (data.totalInvite) {
                    this.RC_lab_inviteValid.string = '' + data.totalInvite.valid;
                    this.RC_lab_inviteTotal.string = '/' + data.totalInvite.invite;
                    this.RC_lab_inviteReward.string = we.common.utils.formatAmountCurrency(data.totalInvite.inviteReward);
                }
                this.RC_lab_receivedReward.string = we.common.utils.formatAmountCurrency(data.receivedRewards);
                this.RC_lab_availableReward.string = we.common.utils.formatAmountCurrency(data.rewardsRemaining);
            }
        });
    }

    private onClickDetailsBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentDetailsDlg, we.common.agentMgr.Detail_Type.INVITE_REWARD);
    }

    private onClickRuleBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentInviteRewardRuleDlg);
    }

    private onClickTodayTips(): void {
        this.RCN_todayTips.active = !this.RCN_todayTips.active;
    }

    private onClickAllTips(): void {
        this.RCN_allTips.active = !this.RCN_allTips.active;
    }

    private hideTips(): void {
        this.RCN_todayTips.active = false;
        this.RCN_allTips.active = false;
    }

    private onLoadTextLang(): void {
        const tipsHEX = this.tipsColor.toHEX('#rrggbb');
        this.RC_rich_todayTips.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_Bonus10) + `<color=${tipsHEX}> / ` + we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_Bonus11) + '</color>';
        this.RC_rich_allTips.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_Bonus12) + `<color=${tipsHEX}> / ` + we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_Bonus13) + '</color>';
    }
}
