import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentRechargeRebate_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnDetails: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_availableReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_directReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_otherReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_receivedReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_todayReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_yesterdayReward: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.onBtnClick(this.RC_btnDetails, we.core.Func.create(this.onClickDetailsBtn, this));
        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRuleBtn, this));
    }

    protected onEnable(): void {
        this.getRewardData();
    }

    private getRewardData(): void {
        we.common.agentMgr.getRechargeRewards((data: api.AgentRechargeRewardsResp) => {
            if (data && cc.isValid(this.node)) {
                this.RC_lab_yesterdayReward.string = we.common.utils.formatAmountCurrency(data.yesterdayRechargeRewards);
                this.RC_lab_todayReward.string = we.common.utils.formatAmountCurrency(data.todayRechargeRewards);
                this.RC_lab_directReward.string = we.common.utils.formatAmountCurrency(data.directRechargeRewards);
                this.RC_lab_otherReward.string = we.common.utils.formatAmountCurrency(data.otherRechargeRewards);
                this.RC_lab_receivedReward.string = we.common.utils.formatAmountCurrency(data.receivedRewards);
                this.RC_lab_availableReward.string = we.common.utils.formatAmountCurrency(data.rewardsRemaining);
            }
        });
    }

    private onClickDetailsBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentDetailsDlg, we.common.agentMgr.Detail_Type.RECHARGE_REWARD);
    }

    private onClickRuleBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentRechargeCodeRuleDlg, we.common.agentMgr.Detail_Type.RECHARGE_REWARD);
    }
}
