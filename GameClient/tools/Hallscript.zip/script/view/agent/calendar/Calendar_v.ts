import { CalendarDateBetween, CalendarCurrentDate, CalendarYearMonthData, CalendarDayType, CalendarDayData, CalendarWeekData } from '../../../extend/util/CalendarModel';
import CalendarUtil from '../../../extend/util/CalendarUtil';
import CalendarDayItem_v from './CalendarDayItem_v';
import CalendarWeekItem_v from './CalendarWeekItem_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class Calendar_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Button)
    public RC_btn_next: cc.Button = null;

    @we.ui.ccBind(cc.Button)
    public RC_btn_prev: cc.Button = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_date: cc.Label = null;

    @we.ui.ccBind(cc.Layout)
    public RC_lay_days: cc.Layout = null;

    @we.ui.ccBind(cc.Layout)
    public RC_lay_weekly: cc.Layout = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private dayItem: cc.Prefab = null;
    private weekItem: cc.Prefab = null;

    private selectedTime: CalendarDateBetween = null;
    private selectedTimeTemp1: CalendarCurrentDate = null;
    private selectedTimeTemp2: CalendarCurrentDate = null;
    private selectedTimeClickCount: number = 0;

    private changeTimeCall: Function = null;
    /** 是否包含今天 */
    private includeToday: boolean = true;
    /** 最早日期，90天前，只能选90天内 */
    private earliestDate: CalendarCurrentDate = null;

    private theChangeDate: CalendarCurrentDate = {
        year: 0,
        month: 0,
        day: 0,
        hours: 0,
        minutes: 0,
        seconds: 0,
    };

    private yearMonthData: CalendarYearMonthData = null;

    protected onLoad(): void {
        this.__initRc();

        this.dayItem = this._rc.getRes('CalendarDayItem', cc.Prefab);
        this.weekItem = this._rc.getRes('CalendarWeekItem', cc.Prefab);
    }

    protected onEnable(): void {
        this.onBtnClick(this.RC_btn_prev.node, we.core.Func.create(this.onPrevNodeClick, this)).setSleepTime(0.3);
        this.onBtnClick(this.RC_btn_next.node, we.core.Func.create(this.onNextNodeClick, this)).setSleepTime(0.3);
    }

    protected onDisable(): void {
        this.offBtnClick(this.RC_btn_prev.node);
        this.offBtnClick(this.RC_btn_next.node);
    }

    public init(includeToday: boolean, normalDay: number, callback: Function): void {
        this.__initRc();

        this.includeToday = includeToday;
        if (callback) {
            this.changeTimeCall = callback;
        }

        this.selectedTimeClickCount = 0;

        let endDate = new Date(new Date().getTime() - (this.includeToday ? 0 : 24 * 60 * 60 * 1000));
        let endDay = {} as CalendarCurrentDate;
        endDay.year = endDate.getFullYear();
        endDay.month = endDate.getMonth() + 1;
        endDay.day = endDate.getDate();
        endDay.hours = this.includeToday ? endDate.getHours() : 23;
        endDay.minutes = this.includeToday ? endDate.getMinutes() : 59;
        endDay.seconds = this.includeToday ? endDate.getSeconds() : 59;

        // 默认3天
        let startDate = new Date(new Date().getTime() - (this.includeToday ? normalDay - 1 : normalDay) * 24 * 60 * 60 * 1000);
        let startDay = {} as CalendarCurrentDate;
        startDay.year = startDate.getFullYear();
        startDay.month = startDate.getMonth() + 1;
        startDay.day = startDate.getDate();

        this.earliestDate = CalendarUtil.getYearMonthDayX(endDay, -89); // 加上今天，所以减89

        this.selectedTimeTemp1 = CalendarUtil.copyDate(startDay);
        this.selectedTimeTemp2 = CalendarUtil.copyDate(endDay);
        // 特殊处理，选中当天时需要获取到当天的具体时间戳
        this.selectedTime = {
            start: CalendarUtil.copyDate(startDay),
            end: CalendarUtil.copyDate(endDay),
        };

        this.theChangeDate.year = endDay.year;
        this.theChangeDate.month = endDay.month;
        this.theChangeDate.day = endDay.day;

        let yearMonthDay: CalendarCurrentDate = {
            year: endDay.year,
            month: endDay.month,
            day: endDay.day,
        };

        this.yearMonthData = CalendarUtil.getCalendarYearMonthData(endDay.year, endDay.month);

        this.RC_lab_date.string = CalendarUtil.formatYYMM(endDay.year, endDay.month);
        this.initWeek();
        this.initDay(this.yearMonthData, yearMonthDay);
        this.updateDayItemStatus();

        this.updateSelectedTimeUI();
    }

    /**
     * 查询下级和返回上级日期不一致时刷新选中日期
     * @param selectedTime
     */
    public updateStartEndDay(selectedTime: CalendarDateBetween) {
        this.selectedTimeTemp1 = CalendarUtil.copyDate(selectedTime.start);
        this.selectedTimeTemp2 = CalendarUtil.copyDate(selectedTime.end);
        // 特殊处理，选中当天时需要获取到当天的具体时间戳
        this.selectedTime = selectedTime;

        this.theChangeDate.year = selectedTime.end.year;
        this.theChangeDate.month = selectedTime.end.month;
        this.theChangeDate.day = selectedTime.end.day;

        let yearMonthDay: CalendarCurrentDate = {
            year: selectedTime.end.year,
            month: selectedTime.end.month,
            day: selectedTime.end.day,
        };

        this.yearMonthData = CalendarUtil.getCalendarYearMonthData(selectedTime.end.year, selectedTime.end.month);

        this.RC_lab_date.string = CalendarUtil.formatYYMM(selectedTime.end.year, selectedTime.end.month);
        this.initWeek();
        this.initDay(this.yearMonthData, yearMonthDay);
        this.updateDayItemStatus();

        this.updateSelectedTimeUI();
    }

    /** 上月 */
    private onPrevNodeClick(): void {
        if (this.theChangeDate.month === 1) {
            this.theChangeDate.month = 12;
            this.theChangeDate.year--;
        } else {
            this.theChangeDate.month--;
        }

        let prevDate = new Date(this.theChangeDate.year, this.theChangeDate.month - 1, this.theChangeDate.day);
        this.changeData(prevDate);
    }

    /** 下月 */
    private onNextNodeClick(): void {
        if (this.theChangeDate.month === 12) {
            this.theChangeDate.month = 1;
            this.theChangeDate.year++;
        } else {
            this.theChangeDate.month++;
        }
        let nextDate = new Date(this.theChangeDate.year, this.theChangeDate.month - 1, this.theChangeDate.day);
        this.changeData(nextDate);
    }

    private changeData(date: Date): void {
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let day = date.getDate();
        let hours = date.getHours();
        let minutes = date.getMinutes();
        let seconds = date.getSeconds();

        this.theChangeDate.year = year;
        this.theChangeDate.month = month;
        this.theChangeDate.day = day;
        this.theChangeDate.hours = hours;
        this.theChangeDate.minutes = minutes;
        this.theChangeDate.seconds = seconds;

        let yearMonthDay: CalendarCurrentDate = {
            year: year,
            month: month,
            day: day,
            hours: hours,
            minutes: minutes,
            seconds: seconds,
        };

        let yearMonthData: CalendarYearMonthData = CalendarUtil.getCalendarYearMonthData(year, month);

        this.RC_lab_date.string = CalendarUtil.formatYYMM(year, month);
        this.updateDay(yearMonthData, yearMonthDay);
    }

    private generateDayData(yearMonthData: CalendarYearMonthData, yearMonthDay: CalendarCurrentDate, eachCallback: Function): void {
        let splitor = yearMonthData.splitor;

        for (let i = 0; i < 42; i++) {
            let dayType = CalendarDayType.NULL;
            let year = yearMonthDay.year;
            let month = yearMonthDay.month;
            let day = yearMonthDay.day;

            if (i < splitor[0]) {
                dayType = CalendarDayType.LAST;
                year = 1 === month ? year - 1 : year;
                month = 1 === month ? 12 : month - 1;
            } else if (i >= splitor[0] && i < splitor[1]) {
                dayType = CalendarDayType.CURR;
            } else if (i >= splitor[1]) {
                year = 12 === month ? year + 1 : year;
                month = 12 === month ? 1 : month + 1;
                dayType = CalendarDayType.NEXT;
            }

            let curDate: CalendarCurrentDate = {
                day: yearMonthData.days[i],
                month: month,
                year: year,
            };
            let clickAble = CalendarUtil.isClickDate(curDate, this.earliestDate);
            if (!this.includeToday && CalendarUtil.isToday(year, month, yearMonthData.days[i])) {
                clickAble = false;
            }

            let dayData: CalendarDayData = {
                day: yearMonthData.days[i],
                clickable: clickAble,
                dayType: dayType,
                year: year,
                month: month,
            };
            eachCallback && eachCallback(i, dayData);
        }
    }

    private initWeek(): void {
        this.RC_lay_weekly.node.removeAllChildren();
        for (let i = 0; i < 7; i++) {
            let weekData: CalendarWeekData = {
                week: i,
                clickable: false,
            };
            let node = cc.instantiate(this.weekItem);
            this.RC_lay_weekly.node.addChild(node);
            let item = node.getComponent(CalendarWeekItem_v);
            if (item) {
                item.init(weekData);
            }
        }
    }

    private initDay(yearMonthData: CalendarYearMonthData, yearMonthDay: CalendarCurrentDate): void {
        this.RC_lay_days.node.removeAllChildren();

        this.generateDayData(yearMonthData, yearMonthDay, (i: number, dayData: CalendarDayData) => {
            let node = cc.instantiate(this.dayItem);
            this.RC_lay_days.node.addChild(node);
            let item = node.getComponent(CalendarDayItem_v);
            if (item) {
                item.init(dayData, this.includeToday, [this.selectedTime.start, this.selectedTime.end], this.earliestDate);
                item.setClickCallback(this.onCalendarDayItemClicked.bind(this));
            }
        });
    }

    private updateDay(yearMonthData: CalendarYearMonthData, yearMonthDay: CalendarCurrentDate): void {
        this.generateDayData(yearMonthData, yearMonthDay, (i: number, dayData: CalendarDayData) => {
            let node = this.RC_lay_days.node.children[i];
            let item = node.getComponent(CalendarDayItem_v);
            if (item) {
                item.init(dayData, this.includeToday, [this.selectedTime.start, this.selectedTime.end], this.earliestDate);
            }
        });
    }

    private onCalendarDayItemClicked(data: CalendarCurrentDate): void {
        this.selectedTimeClickCount++;
        if (1 === this.selectedTimeClickCount % 3) {
            this.selectedTimeTemp2 = CalendarUtil.copyDate(data);
            this.selectedTimeTemp1 = CalendarUtil.copyDate(data);
        } else if (2 === this.selectedTimeClickCount % 3) {
            this.selectedTimeTemp2 = CalendarUtil.copyDate(data);

            let date1 = new Date(this.selectedTimeTemp2.year, this.selectedTimeTemp2.month, this.selectedTimeTemp2.day);
            let date2 = new Date(this.selectedTimeTemp1.year, this.selectedTimeTemp1.month, this.selectedTimeTemp1.day);
            let offsetDay = Math.abs((date1.getTime() - date2.getTime()) / (24 * 60 * 60 * 1000));
            if (offsetDay > 90) {
                this.selectedTimeTemp1 = CalendarUtil.copyDate(data);
            }
        } else if (0 == this.selectedTimeClickCount % 3) {
            this.selectedTimeTemp2 = null;
            this.selectedTimeTemp1 = null;
            this.selectedTime.start = null;
            this.selectedTime.end = null;
            this.selectedTimeClickCount = 0;
            this.RC_lay_days.node.children.forEach((child) => {
                if (cc.isValid(child)) {
                    let item = child.getComponent(CalendarDayItem_v);
                    if (item) {
                        item.resetItemStatus();
                    }
                }
            });
            return;
        }

        let sortedData = CalendarUtil.sortDate([this.selectedTimeTemp1, this.selectedTimeTemp2]);

        this.selectedTime.start = CalendarUtil.copyDate(sortedData[0]);
        this.selectedTime.end = CalendarUtil.copyDate(sortedData[1]);

        // 特殊处理，选中当天时需要获取到当天的具体时间戳
        let date = new Date();
        if (date.getDate() == this.selectedTime.end.day && date.getMonth() + 1 == this.selectedTime.end.month) {
            this.selectedTime.end.hours = date.getHours();
            this.selectedTime.end.minutes = date.getMinutes();
            this.selectedTime.end.seconds = date.getSeconds();
        } else {
            this.selectedTime.end.hours = 23;
            this.selectedTime.end.minutes = 59;
            this.selectedTime.end.seconds = 59;
        }

        this.updateDayItemStatus();
        this.updateSelectedTimeUI();
    }

    private updateDayItemStatus(): void {
        this.RC_lay_days.node.children.forEach((child) => {
            if (cc.isValid(child)) {
                let item = child.getComponent(CalendarDayItem_v);
                if (item) {
                    item.updateRedBg([this.selectedTime.start, this.selectedTime.end]);
                }
            }
        });
    }

    private updateSelectedTimeUI(): void {
        if (this.changeTimeCall) {
            this.changeTimeCall(this.selectedTime);
        }
    }
}
