import HallSkin from '../../../config/HallSkin';
import { CalendarCurrentDate, CalendarDayData } from '../../../extend/util/CalendarModel';
import CalendarUtil from '../../../extend/util/CalendarUtil';

const { ccclass, property } = cc._decorator;

@ccclass
export default class CalendarDayItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_day: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bg: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
    @property({
        tooltip: CC_DEV && '今天颜色',
    })
    public todayCol: string = '#FF00FF';

    @property({
        tooltip: CC_DEV && '天',
    })
    public dayCol: string = '#FFFFFF';

    @property({
        type: [cc.String],
        tooltip: CC_DEV && '状态颜色 null last curr next',
    })
    public stCol: string[] = ['#FF0000', '#8C5821', '#8C5821', '#8C5821'];

    private data: CalendarDayData = null;
    private clickCallback: Function = null;
    private dayData: CalendarCurrentDate = null;
    private afterDay: CalendarCurrentDate = null;
    private beforeDay: CalendarCurrentDate = null;
    private includeToday: boolean = true;

    /** 最早日期，90天前，只能选90天内 */
    private earliestDate: CalendarCurrentDate = null;

    /** 今天颜色 */
    private todayColor: cc.Color = null;

    private isClick: boolean = false;

    protected onEnable(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClicked, this)).setTransitionScale();
    }

    protected onDisable(): void {
        this.offBtnClick(this.node);
    }

    private enableClick(enable: boolean): void {
        this.isClick = enable;
    }

    private onClicked(): void {
        if (!this.isClick) {
            return;
        }

        let currDate: CalendarCurrentDate = {
            year: this.data.year,
            month: this.data.month,
            day: this.data.day,
        };
        this.clickCallback && this.clickCallback(currDate);
    }

    public setClickCallback(callback: Function): void {
        this.clickCallback = callback;
    }

    public updateRedBg(reds: CalendarCurrentDate[]): void {
        if (reds?.length < 1) {
            return;
        }

        if (!reds[0] || !reds[1]) {
            return;
        }
        let isRed = false;
        for (let i = 0; i < reds.length; i++) {
            if (!reds[i]) {
                continue;
            }
            let isSame = CalendarUtil.isSameDay(this.dayData, reds[i]);
            if (isSame) {
                isRed = true;
                break;
            }
        }
        let isBetween = CalendarUtil.isBetweenDate(reds[0], reds[1], this.data);
        this.RCN_bg.active = isBetween;

        if (!CalendarUtil.isToday(this.data.year, this.data.month, this.data.day)) {
            if (isBetween) {
                this.RC_lab_day.node.color = cc.color().fromHEX(this.dayCol);
            } else {
                this.RC_lab_day.node.color = CalendarUtil.getColorConfig(1, this.stCol);
            }
        }

        if (reds[0].year == reds[1].year && reds[0].month == reds[1].month && reds[0].day == reds[1].day) {
            this.judeDayStatus(reds[0]);
        }
    }

    public resetItemStatus(): void {
        this.RCN_bg.active = false;
        if (CalendarUtil.isToday(this.data.year, this.data.month, this.data.day)) {
            this.RC_lab_day.node.color = this.todayColor;
        } else {
            this.RC_lab_day.node.color = CalendarUtil.getColorConfig(1, this.stCol);
        }

        if (this.data.clickable) {
            this.onDayEnableColor(true);
            this.enableClick(true);
        } else {
            this.onDayEnableColor(false);
            this.enableClick(false);
        }
    }

    public resetItemOpacity() {
        if (this.data.clickable) {
            this.onDayEnableColor(true);
            this.enableClick(true);
        } else {
            this.onDayEnableColor(false);
            this.enableClick(false);
        }
    }

    public init(data: CalendarDayData, includeToday: boolean, reds: Array<CalendarCurrentDate> = [], earliestDate: CalendarCurrentDate): void {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.data = data;
        this.includeToday = includeToday;
        this.earliestDate = earliestDate;
        this.dayData = {
            year: data.year,
            month: data.month,
            day: data.day,
        };

        this.todayColor = new cc.Color().fromHEX(this.todayCol);

        this.enableClick(false);
        if (this.data.clickable) {
            this.enableClick(this.data.clickable);
        }

        if (this.data.clickable) {
            this.onDayEnableColor(true);
        } else {
            this.onDayEnableColor(false);
        }

        this.RC_lab_day.string = '' + data.day;
        let color = CalendarUtil.getColorConfig(data.dayType, this.stCol);
        this.RC_lab_day.node.color = color;
        if (CalendarUtil.isToday(this.data.year, this.data.month, this.data.day)) {
            this.RC_lab_day.node.color = this.todayColor;
        }
        this.updateRedBg(reds);
    }

    private judeDayStatus(red: CalendarCurrentDate): void {
        this.afterDay = CalendarUtil.getYearMonthDayX(red, 7);
        this.beforeDay = CalendarUtil.getYearMonthDayX(red, -7);
        let isBetween = CalendarUtil.isBetweenDate(this.beforeDay, this.afterDay, this.data);
        let today = new Date();
        let todayYear = today.getFullYear();
        let todayMonth = today.getMonth();
        let todayDay = today.getDate();

        let dateTime = new Date(this.data.year, this.data.month - 1, this.data.day).getTime();
        let todayTime = new Date(todayYear, todayMonth, todayDay).getTime();
        let earliestDate = new Date(this.earliestDate.year, this.earliestDate.month - 1, this.earliestDate.day).getTime();
        if (isBetween) {
            if (dateTime > todayTime) {
                isBetween = false;
            } else if (dateTime == todayTime) {
                isBetween = this.includeToday;
            }
        }
        if (isBetween) {
            if (dateTime < earliestDate) {
                isBetween = false;
            }
        }
        this.enableClick(isBetween);
        if (!isBetween || !this.data.clickable) {
            this.onDayEnableColor(false);
        }
        if (isBetween && this.data.clickable) {
            this.onDayEnableColor(true);
        }
    }

    private onDayEnableColor(bEnable: boolean): void {
        if (bEnable) {
            this.RC_lab_day.node.opacity = 255;
        } else {
            this.RC_lab_day.node.opacity = 125;
        }
    }
}
