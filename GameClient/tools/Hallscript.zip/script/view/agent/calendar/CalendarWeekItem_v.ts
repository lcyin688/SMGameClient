import { CalendarWeekData } from '../../../extend/util/CalendarModel';
import CalendarUtil from '../../../extend/util/CalendarUtil';

const { ccclass, property } = cc._decorator;

@ccclass
export default class CalendarWeekItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_week: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: CalendarWeekData): void {
        this.__initRc();

        let lang = 'en';
        let week = CalendarUtil.getWeek(lang);
        this.RC_lab_week.string = '' + week[data.week];
    }
}
