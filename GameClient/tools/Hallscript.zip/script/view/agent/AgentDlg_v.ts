import { HallRes } from '../../config/HallRes';
import { HallViewId } from '../HallViewId';
import AgentMenuItem_v from './AgentMenuItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentDlgView_v', we.bundles.hall)
class AgentDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(cc.PageView)
    public RC_pageView: cc.PageView = null;

    @we.ui.ccBind(cc.Node)
    public RCN_item: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentDlg_v', we.bundles.hall)
export class AgentDlg_v extends we.ui.DlgSystem<AgentDlgView_v> {
    private pageUrlMap = new Map([
        [we.common.agentMgr.Detail_Type.INVITE_REBATE, HallRes.prefab.agent.AgentInviteRebate],
        [we.common.agentMgr.Detail_Type.INVITE_REWARD, HallRes.prefab.agent.AgentInviteReward],
        [we.common.agentMgr.Detail_Type.BET_REWARD, HallRes.prefab.agent.AgentCodeRebate],
        [we.common.agentMgr.Detail_Type.RECHARGE_REWARD, HallRes.prefab.agent.AgentRechargeRebate],
        [we.common.agentMgr.Detail_Type.VALID_REWARD, HallRes.prefab.agent.AgentQuantityReward],
    ]);

    private pageList: number[] = [];

    private havePageView: number[] = [];

    private curPageIdx: number = 0;

    private switchOffset: number = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.initMenu();
        this.initMainPage();
        we.common.agentMgr.getConfig(() => {
            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }

            this.initOtherPages();
        });

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onScrollViewEvent(this.view.RC_pageView.node, 'scroll-ended', we.core.Func.create(this.pageScrollEnd, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_menu.onSwitchMenu(this.curPageIdx, true);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private initMenu(): void {
        this.view.RC_menu.setMenuStateByNodeName('select', 'unselect');
        this.view.RC_menu.onSelected = (node: cc.Node, i: number) => {
            this.onSelectedIndex(i);
        };
    }

    private initMainPage(): void {
        this.curPageIdx = 0;
        this.havePageView.length = 0;
        this.pageList.length = 0;
        this.pageList.push(we.common.agentMgr.Detail_Type.INVITE_REBATE);

        this.onRefreshUI();
    }

    private initOtherPages(): void {
        let agentConfig = we.common.agentMgr.agentConfig;
        if (agentConfig) {
            if (agentConfig.inviteReward) {
                this.pageList.push(we.common.agentMgr.Detail_Type.INVITE_REWARD);
            }

            if (agentConfig.rebateReward?.length > 0 && agentConfig.rebateSill) {
                this.pageList.push(we.common.agentMgr.Detail_Type.BET_REWARD);
            }

            if (agentConfig.rechargeReward?.length > 0 && agentConfig.rechargeSill) {
                this.pageList.push(we.common.agentMgr.Detail_Type.RECHARGE_REWARD);
            }

            if (agentConfig.validAgentNumRewardConf?.length > 0 && agentConfig.validAgentNumSill) {
                this.pageList.push(we.common.agentMgr.Detail_Type.VALID_REWARD);
            }

            this.onRefreshUI();
        }
    }

    private onRefreshUI(): void {
        this.addPageItem();
        this.addMenuItem();
        this.updateSwitchOffset();
    }

    private async updateSwitchOffset(): Promise<void> {
        await this.scheduleOnce(0);
        let menuItemWidth = this.view.RC_list.content.width / this.pageList.length;
        let showMaxItem = Math.floor(this.view.RC_list.node.width / menuItemWidth);
        this.switchOffset = Math.max(showMaxItem - 1, 0);
    }

    private async addPageItem(): Promise<void> {
        for (let i = 0; i < this.pageList.length; i++) {
            if (this.havePageView.includes(this.pageList[i])) {
                continue;
            }
            this.havePageView.push(this.pageList[i]);
            let node = cc.instantiate(this.view.RCN_item);
            this.view.RC_pageView.addPage(node);

            if (!this.pageUrlMap.has(this.pageList[i])) {
                continue;
            }
            const path = this.pageUrlMap.get(this.pageList[i]);
            const itemPrefab = await this.loadAsset(path, cc.Prefab);
            const itemNode = cc.instantiate(itemPrefab);
            node.addChild(itemNode);
        }
    }

    private pageScrollEnd(): void {
        if (this.curPageIdx != this.view.RC_pageView.getCurrentPageIndex()) {
            this.curPageIdx = this.view.RC_pageView.getCurrentPageIndex();
            this.view.RC_menu.onSwitchMenu(this.curPageIdx);
        }
    }

    private addMenuItem(): void {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onMenuRenderEvent, this));
        this.view.RC_list.numItems = this.pageList.length;
    }

    private onMenuRenderEvent(item: cc.Node, i: number): void {
        let menuItem = item.getComponent(AgentMenuItem_v);
        menuItem?.init(this.pageList[i]);
        this.view.RC_menu.addMenuBtn(item, i);
    }

    private onSelectedIndex(i: number) {
        this.view.RC_list.scrollTo(i - this.switchOffset);
        if (this.curPageIdx != i) {
            this.curPageIdx = i;
            this.view.RC_pageView.scrollToPage(i, 0.5);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentDlg_v, `${HallViewId.AgentDlg}_v`)
class AgentDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
        uiBase.uiConfig.closeTime = 0.36;
        uiBase.uiConfig.openTime = 0.36;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentDlg_v, uiBase.addComponent(AgentDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentDlg_v).beforeUnload();
    }
}
