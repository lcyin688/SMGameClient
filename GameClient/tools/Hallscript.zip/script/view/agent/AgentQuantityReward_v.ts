import { HallRes } from '../../config/HallRes';
import { HallViewId } from '../HallViewId';
import AgentQuantityItem_v from './AgentQuantityItem_v';
import AgentDetailsList_v from './prop/AgentDetailsList_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentQuantityReward_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Widget)
    public RC_wid_detailsBg: cc.Widget = null;

    @we.ui.ccBind(cc.Node)
    public RCN_details: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property({
        tooltip: CC_DEV && 'list行个数',
    })
    private listRowCount: number = 0;

    @property({
        tooltip: CC_DEV && 'item高度',
    })
    private listItemHeight: number = 0;

    @property({
        tooltip: CC_DEV && 'list最大高度',
    })
    private maxHeight: number = 0;

    @property({
        tooltip: CC_DEV && 'center间隔',
    })
    private centerSpaY: number = 0;

    private validAgentNum: number = 0;
    private taskList: api.ValidAgentRewardsItem[] = [];

    protected onLoad(): void {
        this.initDetails();

        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRuleBtn, this));
    }

    protected onEnable(): void {
        this.RC_list.numItems = 0;
        this.RC_list.scrollTo(0, 0);
        this.RC_wid_detailsBg.node.active = false;
        this.getRewardData();
    }

    private getRewardData(): void {
        we.common.agentMgr.getValidAgentRewards((data: api.ValidAgentRewardsResp) => {
            if (data && cc.isValid(this.node)) {
                this.validAgentNum = data.validAgentNum;
                this.taskList = data.validAgentRewardDetail;
                this.addTaskItem();
                this.jumpGoingTask();
                this.initListHeight();
                this.RC_wid_detailsBg.node.active = true;
            }
        });
    }

    private initListHeight(): void {
        const rowNum = this.listRowCount == 0 ? 0 : Math.round(this.taskList.length / this.listRowCount);
        const layout = this.RC_list.content?.getComponent(cc.Layout);
        const listHeight = Math.min(rowNum * this.listItemHeight + (rowNum - 1) * layout?.spacingY, this.maxHeight);
        this.RC_list.node.height = listHeight;
        if (this.RC_wid_detailsBg.isAlignTop) {
            this.RC_wid_detailsBg.top = listHeight + this.centerSpaY;
        }
        this.RC_wid_detailsBg.updateAlignment();
    }

    private async initDetails(): Promise<void> {
        const itemPrefab = await this.loadAsset(HallRes.prefab.agent.AgentDetailsList, cc.Prefab);
        let node = cc.instantiate(itemPrefab);
        node.getComponent(AgentDetailsList_v)?.setContextData(we.common.agentMgr.Detail_Type.VALID_REWARD);
        this.RCN_details.addChild(node);
    }

    private addTaskItem(): void {
        this.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.RC_list.numItems = this.taskList.length;
    }

    private onRenderEvent(item: cc.Node, i: number): void {
        const task: api.ValidAgentRewardsItem = this.taskList[i];
        let taskItem = item.getComponent(AgentQuantityItem_v);
        taskItem?.init(this.validAgentNum, i, this.taskList.length, task);
    }

    /**
     * 跳转到正在进行的下标
     */
    private jumpGoingTask(): void {
        if (this.taskList.length < 1) {
            return;
        }

        let receiveIndex = -1;
        for (let i = 0; i < this.taskList.length; i++) {
            if (this.validAgentNum < this.taskList[i].validNum) {
                receiveIndex = i;
                break;
            }
        }

        if (receiveIndex > -1) {
            this.RC_list.scrollTo(receiveIndex);
        }
    }

    private onClickRuleBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentQuantityRuleDlg);
    }
}
