import { HallViewId } from '../HallViewId';
import AgentQuantityItem_h from './AgentQuantityItem_h';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentQuantityReward_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnDetails: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_valid: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private validAgentNum: number = 0;
    private taskList: api.ValidAgentRewardsItem[] = [];

    protected onLoad(): void {
        this.onBtnClick(this.RC_btnDetails, we.core.Func.create(this.onClickDetailsBtn, this));
        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRuleBtn, this));
    }

    protected onEnable(): void {
        this.RC_list.numItems = 0;
        this.RC_list.scrollTo(0, 0);

        this.getRewardData();
    }

    private getRewardData(): void {
        we.common.agentMgr.getValidAgentRewards((data: api.ValidAgentRewardsResp) => {
            if (data && cc.isValid(this.node)) {
                this.validAgentNum = data.validAgentNum;
                if (this.RC_lab_valid) {
                    this.RC_lab_valid.string = `${data.validAgentNum}`;
                }
                this.taskList = data.validAgentRewardDetail;
                this.addTaskItem();
                this.jumpGoingTask();
            }
        });
    }

    private addTaskItem(): void {
        this.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.RC_list.numItems = this.taskList.length;
    }

    private onRenderEvent(item: cc.Node, i: number): void {
        let taskItem = item.getComponent(AgentQuantityItem_h);
        taskItem?.init(this.validAgentNum, i, this.taskList);
    }

    /**
     * 跳转到正在进行的下标
     */
    private jumpGoingTask(): void {
        if (this.taskList.length < 1) {
            return;
        }

        let receiveIndex = -1;
        for (let i = 0; i < this.taskList.length; i++) {
            if (this.validAgentNum < this.taskList[i].validNum) {
                receiveIndex = i;
                break;
            }
        }

        if (receiveIndex > -1) {
            this.RC_list.scrollTo(receiveIndex);
        }
    }

    private onClickDetailsBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentDetailsDlg, we.common.agentMgr.Detail_Type.VALID_REWARD);
    }

    private onClickRuleBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentQuantityRuleDlg);
    }
}
