import { HallLanguage } from '../../../const/HallLanguage';
import { HallViewId } from '../../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentRechargeCodeRuleDlgView_h', we.bundles.hall)
class AgentRechargeCodeRuleDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_3: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_4: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_5: cc.Label = null;

    @we.ui.ccBind(cc.ScrollView)
    public RC_scrollView: cc.ScrollView = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_layout: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_newNode: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_table: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_table1: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_table2: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentRechargeCodeRuleDlg_h', we.bundles.hall)
export class AgentRechargeCodeRuleDlg_h extends we.ui.DlgSystem<AgentRechargeCodeRuleDlgView_h> {
    /** 2-打码返利 3-充值 */
    private ruleType: number = -1;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(ruleType: number) {
        this.ruleType = ruleType;
        this.onLoadTextLang();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onLoadTextLang(): void {
        if (this.ruleType == we.common.agentMgr.Detail_Type.BET_REWARD) {
            this.loadRebateTextLang();
            this.betRebateData();
        } else if (this.ruleType == we.common.agentMgr.Detail_Type.RECHARGE_REWARD) {
            this.loadRechargeTextLang();
            this.rechargeRebateData();
        }
    }

    /** 打码返利规则 */
    private loadRebateTextLang(): void {
        let config = we.common.agentMgr.agentConfig;
        this.view.RC_lab_1.string = we.core.langMgr.getLangText(HallLanguage.INVITE_BETTING_RULE_Bonus1);
        if (!config) {
            return;
        }
        this.view.RC_lab_4.string = we.core.langMgr.getLangText(HallLanguage.INVITE_BETTING_RULE_Bonus2);
        this.view.RC_lab_5.string = we.core.langMgr.getLangText(HallLanguage.INVITE_BETTING_RULE_Bonus4);
        if (config.rebateSill?.recharge > 0) {
            this.view.RC_lab_2.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RULE_Bonus3) + ' ≥ ' + we.common.utils.formatPrice(config.rebateSill.recharge, true, false);
        } else {
            this.view.RC_lab_2.node.active = false;
        }
        if (config.rebateSill?.betAmount > 0) {
            this.view.RC_lab_3.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RULE_Bonus4) + ' ≥ ' + we.common.utils.formatAmountCurrency(config.rebateSill.betAmount);
        } else {
            this.view.RC_lab_3.node.active = false;
        }
    }

    /** 充值返利规则 */
    private loadRechargeTextLang(): void {
        let config = we.common.agentMgr.agentConfig;
        this.view.RC_lab_1.string = we.core.langMgr.getLangText(HallLanguage.INVITE_BETTING_RULE_Bonus1);
        if (!config) {
            return;
        }
        this.view.RC_lab_4.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REBATE_RULE_Bonus1);
        this.view.RC_lab_5.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REBATE_RULE_Bonus3);
        if (config.rechargeSill?.recharge > 0) {
            this.view.RC_lab_2.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RULE_Bonus3) + ' ≥ ' + we.common.utils.formatPrice(config.rechargeSill.recharge, true, false);
        } else {
            this.view.RC_lab_2.node.active = false;
        }
        if (config.rechargeSill?.betAmount > 0) {
            this.view.RC_lab_3.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RULE_Bonus4) + ' ≥ ' + we.common.utils.formatAmountCurrency(config.rechargeSill.betAmount);
        } else {
            this.view.RC_lab_3.node.active = false;
        }
    }

    /** 打码返利表格显示 */
    private betRebateData(): void {
        let config = we.common.agentMgr.agentConfig;
        if (!config || !config.rebateReward) {
            return;
        }
        let rewardData = config.rebateReward;
        let level = this.getLevelMap(rewardData);
        let keyArr: number[] = this.getKeyArr(level);
        if (keyArr.length < 1) {
            return;
        }

        // 长度是否相同
        let amountName = 'betAmount';
        let titleName = 'INVITE_BETTING_RULE_Bonus3';
        let listLength = level.get(String(keyArr[0])).length;
        let dataALike = this.getLengthType(listLength, keyArr, level, amountName);

        if (dataALike) {
            this.showAlikeTable(keyArr, level, amountName, titleName);
        } else {
            this.showNoAlikeTable(keyArr, level, amountName, titleName);
        }
    }

    /** 充值返利表格显示 */
    private rechargeRebateData(): void {
        let config = we.common.agentMgr.agentConfig;
        if (!config || !config.rechargeReward) {
            return;
        }
        let rewardData = config.rechargeReward;
        let level = this.getLevelMap(rewardData);
        let keyArr: number[] = this.getKeyArr(level);
        if (keyArr.length < 1) {
            return;
        }

        let amountName = 'rechargeAmount';
        let titleName = 'INVITE_REBATE_RULE_Bonus2';
        // 长度是否相同
        let listLength = level.get(String(keyArr[0])).length;
        let dataALike = this.getLengthType(listLength, keyArr, level, amountName);

        if (dataALike) {
            this.showAlikeTable(keyArr, level, amountName, titleName);
        } else {
            this.showNoAlikeTable(keyArr, level, amountName, titleName);
        }
    }

    /** 所有下级充值打码范围一样，显示为一个表格 */
    private showAlikeTable(keyArr: number[], level: Map<string, api.RebateReward[] | api.RechargeReward[]>, amountName: string, titleName: string): void {
        let tableNodeItem: cc.Node = cc.instantiate(this.view.RCN_table);
        const tableLayout = tableNodeItem.getComponent(cc.Layout);
        const left = tableLayout?.paddingLeft || 0;
        const right = tableLayout?.paddingRight || 0;
        const spacingX = tableLayout?.spacingX || 0;
        let table_title: cc.Node = cc.instantiate(this.view.RCN_table1);
        table_title.getChildByName('lab').getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage[titleName]);
        table_title.active = true;
        tableNodeItem.addChild(table_title);
        let tableWidth = table_title.width + left + right;
        for (let i = 0; i < keyArr.length; i++) {
            let grade_item: cc.Node = cc.instantiate(this.view.RCN_table2);
            grade_item.getChildByName('lab').getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage.INVITE_RULE_Bonus6) + keyArr[i];
            grade_item.active = true;
            tableNodeItem.addChild(grade_item);
            tableWidth += grade_item.width + spacingX;
        }
        this.view.RCN_layout.addChild(tableNodeItem);
        if (tableWidth > this.view.RC_scrollView.content.width) {
            this.view.RC_scrollView.content.width = tableWidth;
        }

        let level1 = level.get(String(keyArr[0]));
        for (let k = 0; k < level1?.length; k++) {
            let node: cc.Node = cc.instantiate(this.view.RCN_table);
            let title: cc.Node = cc.instantiate(this.view.RCN_table1);
            let str = '';
            if (k == level1.length - 1) {
                str = this.getRangeTableTd(level1[k]?.[amountName]);
                title.getChildByName('lab').getComponent(cc.Label).string = str;
            } else {
                str = this.getRangeTableTr(level1[k]?.[amountName], level1[k + 1]?.[amountName]);
                title.getChildByName('lab').getComponent(cc.Label).string = we.core.flavor.getCurrencySymbol() + str;
            }
            title.active = true;
            node.addChild(title);
            for (let i = 0; i < keyArr.length; i++) {
                let grade_item: cc.Node = cc.instantiate(this.view.RCN_table2);
                if (level.get(String(keyArr[i]))?.[k]) {
                    grade_item.getChildByName('lab').getComponent(cc.Label).string = level.get(String(keyArr[i]))[k].rewardScale / 100 + '%';
                } else {
                    grade_item.getChildByName('lab').getComponent(cc.Label).string = '-';
                }
                grade_item.active = true;
                node.addChild(grade_item);
            }
            this.view.RCN_layout.addChild(node);
        }
    }

    /** 所有下级充值打码范围不一样，不同下级分表格显示 */
    private showNoAlikeTable(keyArr: number[], level: Map<string, api.RebateReward[] | api.RechargeReward[]>, amountName: string, titleName: string): void {
        for (let i = 0; i < keyArr.length; i++) {
            let levData = level.get(String(keyArr[i]));
            let node: cc.Node = cc.instantiate(this.view.RCN_table);
            let table_title: cc.Node = cc.instantiate(this.view.RCN_table1);
            table_title.getChildByName('lab').getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage[titleName]);
            table_title.active = true;
            node.addChild(table_title);
            let grade_item: cc.Node = cc.instantiate(this.view.RCN_table2);
            grade_item.getChildByName('lab').getComponent(cc.Label).string = we.core.langMgr.getLangText(HallLanguage.INVITE_RULE_Bonus6) + keyArr[i];
            grade_item.active = true;
            node.addChild(grade_item);
            this.view.RCN_layout.addChild(node);
            for (let k = 0; k < levData?.length; k++) {
                let node2: cc.Node = cc.instantiate(this.view.RCN_table);
                let title: cc.Node = cc.instantiate(this.view.RCN_table1);
                let str = '';
                if (k == levData.length - 1) {
                    str = this.getRangeTableTd(levData[k]?.[amountName]);
                    title.getChildByName('lab').getComponent(cc.Label).string = str;
                } else {
                    str = this.getRangeTableTr(levData[k][amountName], levData[k + 1]?.[amountName]);
                    title.getChildByName('lab').getComponent(cc.Label).string = we.core.flavor.getCurrencySymbol() + str;
                }
                title.active = true;
                node2.addChild(title);
                let grade_item: cc.Node = cc.instantiate(this.view.RCN_table2);
                if (level.get(String(keyArr[i]))?.[k]) {
                    grade_item.getChildByName('lab').getComponent(cc.Label).string = level.get(String(keyArr[i]))[k].rewardScale / 100 + '%';
                } else {
                    grade_item.getChildByName('lab').getComponent(cc.Label).string = '-';
                }
                grade_item.active = true;
                node2.addChild(grade_item);
                this.view.RCN_layout.addChild(node2);
            }
            let newNode = cc.instantiate(this.view.RCN_newNode);
            this.view.RCN_layout.addChild(newNode);
        }
    }

    /** 范围文本，最后一行 */
    private getRangeTableTd(amount: number): string {
        let str = '';
        if (this.ruleType == we.common.agentMgr.Detail_Type.BET_REWARD) {
            str = we.common.utils.formatAmountCurrency(amount) + ' +';
        } else if (this.ruleType == we.common.agentMgr.Detail_Type.RECHARGE_REWARD) {
            str = we.common.utils.formatPrice(amount, true, false) + ' +';
        }
        return str;
    }

    /** 区间范围文本 */
    private getRangeTableTr(amount1: number, amount2: number): string {
        let str = '';
        if (this.ruleType == we.common.agentMgr.Detail_Type.BET_REWARD) {
            str = we.common.utils.formatAmount(amount1, false) + ' - ' + we.common.utils.formatAmount(amount2, false);
        } else if (this.ruleType == we.common.agentMgr.Detail_Type.RECHARGE_REWARD) {
            str = we.common.utils.formatPrice(amount1, false, false) + ' - ' + we.common.utils.formatPrice(amount2, false, false);
        }
        return str;
    }

    /** 获取下级Map */
    private getLevelMap(rewardData): Map<string, api.RechargeReward[]> {
        let level = new Map<string, api.RechargeReward[]>();
        rewardData.forEach((item) => {
            let levelArr = level.get(String(item?.level));
            if (levelArr) {
                levelArr.push(item);
            } else {
                levelArr = [];
                levelArr.push(item);
            }
            level.set(String(item.level), levelArr);
        });
        return level;
    }

    /** 获取排序后的key值 */
    private getKeyArr(level): number[] {
        let keyArr: number[] = [];
        level.forEach((value, key) => {
            keyArr.push(parseInt(key));
            if (this.ruleType == we.common.agentMgr.Detail_Type.BET_REWARD) {
                value = this.sortBetLevelArr(value);
            }
            if (this.ruleType == we.common.agentMgr.Detail_Type.RECHARGE_REWARD) {
                value = this.sortRechartLevelArr(value);
            }
        });
        keyArr.sort();
        return keyArr;
    }

    private getLengthType(listLength: number, keyArr: number[], level: Map<string, api.RebateReward[] | api.RechargeReward[]>, amountName): boolean {
        // 长度是否相同
        let lengthAlike = true;
        for (let i = 0; i < keyArr.length; i++) {
            let len = level.get(String(keyArr[i])).length;
            if (len != listLength) {
                lengthAlike = false;
            }
        }
        // 长度相同，充值范围是否相同
        let level1Data = level.get(String(keyArr[0]));
        let dataALike = true;
        if (lengthAlike) {
            for (let i = 0; i < level1Data?.length; i++) {
                for (let k = 0; k < keyArr.length; k++) {
                    if (level1Data[i][amountName] != level.get(String(keyArr[k]))[i][amountName]) {
                        dataALike = false;
                    }
                }
            }
        } else {
            dataALike = false;
        }
        return dataALike;
    }

    /** 打码返利key值排序 */
    private sortBetLevelArr(arr: api.RebateReward[]): api.RebateReward[] {
        let amount: number[] = [];
        arr.forEach((item) => {
            amount.push(item.betAmount);
        });
        amount.sort((a, b) => {
            return a - b;
        });
        let result: api.RebateReward[] = [];
        for (let i = 0; i < amount.length; i++) {
            for (let k = 0; k < arr.length; k++) {
                if (amount[i] == arr[k].betAmount) {
                    result.push(arr[k]);
                }
            }
        }

        return result;
    }

    /** 充值返利key值排序 */
    private sortRechartLevelArr(arr: api.RechargeReward[]): api.RechargeReward[] {
        let amount: number[] = [];
        arr.forEach((item) => {
            amount.push(item.rechargeAmount);
        });
        amount.sort((a, b) => {
            return a - b;
        });
        let result: api.RechargeReward[] = [];
        for (let i = 0; i < amount.length; i++) {
            for (let k = 0; k < arr.length; k++) {
                if (amount[i] == arr[k].rechargeAmount) {
                    result.push(arr[k]);
                }
            }
        }

        return result;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentRechargeCodeRuleDlg_h, `${HallViewId.AgentRechargeCodeRuleDlg}_h`)
class AgentRechargeCodeRuleDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentRechargeCodeRuleDlg_h, uiBase.addComponent(AgentRechargeCodeRuleDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentRechargeCodeRuleDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentRechargeCodeRuleDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentRechargeCodeRuleDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentRechargeCodeRuleDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentRechargeCodeRuleDlg_h).beforeUnload();
    }
}
