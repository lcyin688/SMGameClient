import { HallViewId } from '../../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentInviteRebateRuleDlgView_h', we.bundles.hall)
class AgentInviteRebateRuleDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentInviteRebateRuleDlg_h', we.bundles.hall)
export class AgentInviteRebateRuleDlg_h extends we.ui.DlgSystem<AgentInviteRebateRuleDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {}

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentInviteRebateRuleDlg_h, `${HallViewId.AgentInviteRebateRuleDlg}_h`)
class AgentInviteRebateRuleDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentInviteRebateRuleDlg_h, uiBase.addComponent(AgentInviteRebateRuleDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentInviteRebateRuleDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentInviteRebateRuleDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentInviteRebateRuleDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentInviteRebateRuleDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentInviteRebateRuleDlg_h).beforeUnload();
    }
}
