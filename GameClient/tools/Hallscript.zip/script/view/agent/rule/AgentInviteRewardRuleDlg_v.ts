import { HallLanguage } from '../../../const/HallLanguage';
import { HallViewId } from '../../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentInviteRewardRuleDlgView_v', we.bundles.hall)
class AgentInviteRewardRuleDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_3: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_4: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_5: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentInviteRewardRuleDlg_v', we.bundles.hall)
export class AgentInviteRewardRuleDlg_v extends we.ui.DlgSystem<AgentInviteRewardRuleDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.onLoadTextLang();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onLoadTextLang(): void {
        let config = we.common.agentMgr.agentConfig;
        this.view.RC_lab_2.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_Bonus1) + ' = ' + we.common.utils.formatAmountCurrency(config.inviteReward.rewardCoin);
        if (config && config.inviteReward && config.inviteReward.rechargeAmount <= 0 && config.inviteReward.betAmount <= 0) {
            this.view.RC_lab_3.node.active = false;
        }
        if (config && config.inviteReward && config.inviteReward.rechargeAmount > 0) {
            this.view.RC_lab_4.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RULE_Bonus3) + ' ≥ ' + we.common.utils.formatPrice(config.inviteReward.rechargeAmount, true, false);
        } else {
            this.view.RC_lab_4.node.active = false;
        }
        if (config && config.inviteReward && config.inviteReward.betAmount > 0) {
            this.view.RC_lab_5.string = we.core.langMgr.getLangText(HallLanguage.INVITE_REWARDS_RULE_Bonus4) + ' ≥ ' + we.common.utils.formatAmountCurrency(config.inviteReward.betAmount);
        } else {
            this.view.RC_lab_5.node.active = false;
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentInviteRewardRuleDlg_v, `${HallViewId.AgentInviteRewardRuleDlg}_v`)
class AgentInviteRewardRuleDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentInviteRewardRuleDlg_v, uiBase.addComponent(AgentInviteRewardRuleDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentInviteRewardRuleDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentInviteRewardRuleDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentInviteRewardRuleDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentInviteRewardRuleDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentInviteRewardRuleDlg_v).beforeUnload();
    }
}
