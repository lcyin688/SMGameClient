import { HallRes } from '../../config/HallRes';
import HallSkin from '../../config/HallSkin';
import { HallViewId } from '../HallViewId';
import AgentMenuItem_h from './AgentMenuItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgentDlgView_h', we.bundles.hall)
class AgentDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(we.ui.WESwitchPage)
    public RC_page: we.ui.WESwitchPage = null;

    @we.ui.ccBind(cc.Node)
    public RCN_item: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mainRoot: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgentDlg_h', we.bundles.hall)
export class AgentDlg_h extends we.ui.DlgSystem<AgentDlgView_h> {
    private pageUrlMap = new Map([
        [we.common.agentMgr.Detail_Type.INVITE_REBATE, HallRes.prefab.agent.AgentInviteRebate],
        [we.common.agentMgr.Detail_Type.INVITE_REWARD, HallRes.prefab.agent.AgentInviteReward],
        [we.common.agentMgr.Detail_Type.BET_REWARD, HallRes.prefab.agent.AgentCodeRebate],
        [we.common.agentMgr.Detail_Type.RECHARGE_REWARD, HallRes.prefab.agent.AgentRechargeRebate],
        [we.common.agentMgr.Detail_Type.VALID_REWARD, HallRes.prefab.agent.AgentQuantityReward],
    ]);

    private pageList: number[] = [];

    private havePageView: number[] = [];

    private switchOffset: number = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.havePageView.length = 0;
        this.pageList.length = 0;
        this.initMenu();
        this.initMainPage();
        we.common.agentMgr.getConfig(() => {
            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }

            this.initOtherPages();
        });

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_menu.onSwitchMenu(0, true);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private initMenu(): void {
        this.view.RC_menu.setMenuStateByNodeName('select', 'unselect');
        this.view.RC_menu.onSelected = (node: cc.Node, i: number) => {
            this.onSelectedIndex(i);
        };
    }

    private async initMainPage(): Promise<void> {
        // 代理主界面是否为page，皮肤差异配置
        const agentMainIsPage = HallSkin.config.AgentMainIsPage;
        if (agentMainIsPage) {
            this.pageList.push(we.common.agentMgr.Detail_Type.INVITE_REBATE);
            this.onRefreshUI();
        } else {
            const path = this.pageUrlMap.get(we.common.agentMgr.Detail_Type.INVITE_REBATE);
            const itemPrefab = await this.loadAsset(path, cc.Prefab);
            const itemNode = cc.instantiate(itemPrefab);
            this.view.RCN_mainRoot.addChild(itemNode);
        }
    }

    private initOtherPages(): void {
        let agentConfig = we.common.agentMgr.agentConfig;
        if (agentConfig) {
            if (agentConfig.inviteReward) {
                this.pageList.push(we.common.agentMgr.Detail_Type.INVITE_REWARD);
            }

            if (agentConfig.rebateReward?.length > 0 && agentConfig.rebateSill) {
                this.pageList.push(we.common.agentMgr.Detail_Type.BET_REWARD);
            }

            if (agentConfig.rechargeReward?.length > 0 && agentConfig.rechargeSill) {
                this.pageList.push(we.common.agentMgr.Detail_Type.RECHARGE_REWARD);
            }

            if (agentConfig.validAgentNumRewardConf?.length > 0 && agentConfig.validAgentNumSill) {
                this.pageList.push(we.common.agentMgr.Detail_Type.VALID_REWARD);
            }

            this.onRefreshUI();
        }
    }

    private onRefreshUI(): void {
        this.addPageItem();
        this.addMenuItem();
        this.updateSwitchOffset();
    }

    private async addPageItem(): Promise<void> {
        for (let i = 0; i < this.pageList.length; i++) {
            if (this.havePageView.includes(this.pageList[i])) {
                continue;
            }
            this.havePageView.push(this.pageList[i]);
            let node = cc.instantiate(this.view.RCN_item);
            let bShow = i == 0;
            this.view.RC_page.addChildPage(node, bShow);

            if (!this.pageUrlMap.has(this.pageList[i])) {
                continue;
            }
            const path = this.pageUrlMap.get(this.pageList[i]);
            const itemPrefab = await this.loadAsset(path, cc.Prefab);
            const itemNode = cc.instantiate(itemPrefab);
            node.addChild(itemNode);
        }
    }

    private addMenuItem(): void {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onMenuRenderEvent, this));
        this.view.RC_list.numItems = this.pageList.length;
    }

    private onMenuRenderEvent(item: cc.Node, i: number): void {
        let menuItem = item.getComponent(AgentMenuItem_h);
        menuItem?.init(this.pageList[i], i, this.pageList.length);
        this.view.RC_menu.addMenuBtn(item, i);
    }

    private onSelectedIndex(i: number) {
        this.view.RC_list.scrollTo(i - this.switchOffset);
    }

    private async updateSwitchOffset(): Promise<void> {
        await this.scheduleOnce(0);
        let layoutType = this.view.RC_list.content.getComponent(cc.Layout)?.type;
        if (layoutType == cc.Layout.Type.HORIZONTAL) {
            let menuItemWidth = this.view.RC_list.content.width / this.pageList.length;
            let showMaxItem = Math.floor(this.view.RC_list.node.width / menuItemWidth);
            this.switchOffset = Math.max(showMaxItem - 1, 0);
        } else if (layoutType == cc.Layout.Type.VERTICAL) {
            let menuItemHeight = this.view.RC_list.content.height / this.pageList.length;
            let showMaxItem = Math.floor(this.view.RC_list.node.height / menuItemHeight);
            this.switchOffset = Math.max(showMaxItem - 1, 0);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgentDlg_h, `${HallViewId.AgentDlg}_h`)
class AgentDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgentDlg_h, uiBase.addComponent(AgentDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgentDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AgentDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgentDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgentDlg_h).beforeUnload();
    }
}
