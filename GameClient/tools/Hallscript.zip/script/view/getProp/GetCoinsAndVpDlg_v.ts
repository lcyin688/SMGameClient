import { HallRes } from '../../config/HallRes';
import { HallPageEnum } from '../../const/HallConst';
import { HallDlg_v } from '../hall/HallDlg_v';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('GetCoinsAndVpDlgView_v', we.bundles.hall)
class GetCoinsAndVpDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_awardNum: cc.Label = null;

    @we.ui.ccBind(sp.Skeleton)
    public RC_titleAnim: sp.Skeleton = null;

    @we.ui.ccBind(cc.Node)
    public RCN_awardInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('GetCoinsAndVpDlg_v', we.bundles.hall)
export class GetCoinsAndVpDlg_v extends we.ui.DlgSystem<GetCoinsAndVpDlgView_v> {
    private award: number = 0;

    private bClose: boolean = false;

    /** 注册UI事件 */
    public async registerUIEvent() {
        we.common.apiMgr.getUserCreditReq((data: api.UserCreditResp) => {
            if (data.credit > we.common.userMgr.userInfo.gold) {
                this.bClose = true;
            }
        });
        this.view.cc_onBtnClick(this.view.RCN_receive, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
    }

    /** 显示窗口 */
    public async onShow(coins: number) {
        we.core.audioMgr.playEffect(HallRes.audio.award);
        this.award = coins;

        this.view.RC_titleAnim.setAnimation(0, 'animation1', false);
        this.view.RC_titleAnim.setCompleteListener(() => {
            this.view.RC_titleAnim.clearTracks();
            this.view.RC_titleAnim.setAnimation(0, 'animation2', true);
            this.view.RC_titleAnim.setCompleteListener(null);
        });

        this.scheduleOnce(0.75).then(() => {
            if (!cc.isValid(this.view.RCN_receive)) {
                return;
            }
            this.view.RCN_receive.active = true;
            this.tween(this.view.RCN_receive).to(0.3, { scale: 1.1 }, { easing: 'sineOut' }).to(0.08, { scale: 1 }, { easing: 'sineIn' }).start();
        });

        this.view.RC_lab_awardNum.string = we.common.utils.formatAmount(this.award);
        this.tween(this.view.RCN_awardInfo).set({ scale: 0.5 }).to(0.35, { scale: 1.5 }).to(0.15, { scale: 1 }).start();
    }

    /** 隐藏窗口 */
    public async onHide() {
        if (this.bClose === false) {
            return;
        }
        if (we.currentUI?.getDlg(HallDlg_v)?.getCurPageType() === HallPageEnum.shop) {
            cc.director.emit(we.common.EventName.STORE_COIN_FLY_ANIM, { node: this.view.RCN_awardInfo, award: this.award });
        } else {
            cc.director.emit(we.common.EventName.COIN_FLY_ANIM, { node: this.view.RCN_awardInfo, award: this.award });
        }
    }

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(GetCoinsAndVpDlg_v, `${HallViewId.GetCoinsAndVpDlg}_v`)
class GetCoinsAndVpDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(GetCoinsAndVpDlg_v, uiBase.addComponent(GetCoinsAndVpDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(GetCoinsAndVpDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<GetCoinsAndVpDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(GetCoinsAndVpDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(GetCoinsAndVpDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(GetCoinsAndVpDlg_v).beforeUnload();
    }
}
