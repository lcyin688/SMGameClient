import { HallRes } from '../../config/HallRes';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('GetSingPropDlgView_h', we.bundles.hall)
class GetSingPropDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_awardNum: cc.Label = null;

    @we.ui.ccBind(sp.Skeleton)
    public RC_titleAnim: sp.Skeleton = null;

    @we.ui.ccBind(cc.Node)
    public RCN_awardInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('GetSingPropDlg_h', we.bundles.hall)
export class GetSingPropDlg_h extends we.ui.DlgSystem<GetSingPropDlgView_h> {
    private award: number = 0;
    private callback: Function = null;
    private awardMap: { id: number; num: number }[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RCN_receive, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
    }

    /** 显示窗口 */
    public async onShow(awardMap: { id: number; num: number }[], closeCallback?: Function) {
        this.awardMap = awardMap || [];
        this.callback = closeCallback;

        let awardData = this.awardMap.shift();
        if (!awardData) {
            this.closeView();
            return;
        }

        this.award = awardData.num;
        we.core.audioMgr.playEffect(HallRes.audio.award);
        this.view.RC_titleAnim.setAnimation(0, 'animation1', false);
        this.view.RC_titleAnim.setCompleteListener(() => {
            this.view.RC_titleAnim.clearTracks();
            this.view.RC_titleAnim.setAnimation(0, 'animation2', true);
            this.view.RC_titleAnim.setCompleteListener(null);
        });
        this.tween(this.view.RCN_awardInfo).to(0.3, { scale: 1.5 }, { easing: 'sineOut' }).to(0.1, { scale: 1 }, { easing: 'sineIn' }).start();

        this.tween(this.view.RCN_receive).to(0.3, { scale: 1.1 }, { easing: 'sineOut' }).to(0.08, { scale: 1 }, { easing: 'sineIn' }).start();

        this.view.RC_lab_awardNum.string = we.common.utils.formatAmount(awardData.num);

        switch (awardData.id) {
            case we.common.userMgr.PropId.CoinId:
            case we.common.userMgr.PropId.AgentId:
                {
                    // 获取金币奖励后 及时刷新提现所需打码量
                    we.common.withdrawMgr.getBankWithdrawConf();
                }
                break;
            case we.common.userMgr.PropId.RpId:
                we.common.userMgr.onSyncUserCoinInfo();
                break;
            default:
                break;
        }
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.COIN_FLY_ANIM, { node: this.view.RCN_awardInfo, award: this.award });

        typeof this.callback == 'function' && this.callback();
    }

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(GetSingPropDlg_h, `${HallViewId.GetSingPropDlg}_h`)
class GetSingPropDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(GetSingPropDlg_h, uiBase.addComponent(GetSingPropDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(GetSingPropDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<GetSingPropDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(GetSingPropDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(GetSingPropDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(GetSingPropDlg_h).beforeUnload();
    }
}
