import { HallLanguage } from '../../const/HallLanguage';
import MonthSign from '../../manager/MonthSignMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('MonthSignRuleDlgView_h', we.bundles.hall)
class MonthSignRuleDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.RichText)
    public RC_rich_1: cc.RichText = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_2: cc.RichText = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('MonthSignRuleDlg_h', we.bundles.hall)
export class MonthSignRuleDlg_h extends we.ui.DlgSystem<MonthSignRuleDlgView_h> {
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RCN_close, we.core.Func.create(this.closeView, this));
    }
    /** 注册UI事件 */
    public async onShow(showData?: any) {
        const data = MonthSign.month.getData();

        if (!data) {
            return;
        }

        const value = data.reSignInConf?.rechargeThreshold || 0;
        this.view.RC_rich_1.string = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_RULE_2, we.common.utils.formatPrice(value, false, false));

        const value2 = data.rechargeMultiplierConf?.rechargeThreshold || 0;
        this.view.RC_rich_2.string = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_RULE_3, we.common.utils.formatPrice(value2, false, false));
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(MonthSignRuleDlg_h, `${HallViewId.MonthSignRuleDlg}_h`)
class MonthSignRuleDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(MonthSignRuleDlg_h, uiBase.addComponent(MonthSignRuleDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSignRuleDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<MonthSignRuleDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(MonthSignRuleDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSignRuleDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(MonthSignRuleDlg_h).beforeUnload();
    }
}
