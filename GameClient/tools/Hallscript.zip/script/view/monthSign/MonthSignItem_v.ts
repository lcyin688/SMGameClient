import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import MonthSign from '../../manager/MonthSignMgr';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class MonthSignItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnSign: cc.Node = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_icon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_mask: cc.Node = null;

    /** 再次领取 */
    @we.ui.ccBind(cc.Node)
    public RC_nodeReSign: cc.Node = null;

    /** 补签 */
    @we.ui.ccBind(cc.Node)
    public RC_nodeToSign: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_received: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    data: api.DailySignInAwardConf = null;

    protected onLoad(): void {
        this.onBtnClick(this.RC_btnSign, we.core.Func.create(this.onSign, this)).setTransitionScale();
    }

    public updateData(index: number) {
        if (!this.isInitRc) {
            this.__initRc();
        }

        this.data = MonthSign.month.getDay(index);
        if (!this.data) {
            we.warn('MonthSignItem_v updateData data is null');
            return;
        }

        this.updateUI();
    }

    private updateUI(): void {
        this.updateButtonState();
        this.updateLabels();

        const isClaimed = this.data.awardStatus == MonthSign.m_status.DAILY_CLAIMED;
        const isClaimable = this.data.awardStatus === MonthSign.m_status.DAILY_CAN_CLAIM;
        const isClaimable2 = this.data.awardStatus === MonthSign.m_status.DAILY_CAN_RECLAIM;
        const isExpired = this.data.awardStatus === MonthSign.m_status.DAILY_EXPIRED;

        if (this.RC_lab_title.getComponent(we.ui.WENodeColorIndex)) {
            this.RC_lab_title.getComponent(we.ui.WENodeColorIndex).index = isClaimable || isClaimable2 ? 1 : 0;
        }

        if (this.RC_lab_value.getComponent(we.ui.WENodeColorIndex)) {
            this.RC_lab_value.getComponent(we.ui.WENodeColorIndex).index = isClaimable || isClaimable2 ? 1 : 0;
        }

        this.RC_icon.index = isClaimable || isClaimable2 ? 1 : 0;

        this.RC_received.active = isClaimed ? true : false;
        this.RC_mask.active = isClaimed || isExpired;
        this.RC_nodeReSign.active = !isExpired && isClaimable2;
        this.RC_nodeToSign.active = isExpired;
    }

    private updateButtonState(): void {
        const isClaimable = this.data.awardStatus !== MonthSign.m_status.DAILY_CLAIMED && this.data.awardStatus !== MonthSign.m_status.DAILY_NOT_STARTED;
        this.RC_btnSign.active = isClaimable;
    }

    private updateLabels(): void {
        this.RC_lab_title.string = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_3, this.data.day + 1);
        this.RC_lab_value.string = we.common.utils.formatAmount(this.data.award, false);
    }

    /** 签到 */
    async onSign() {
        const signData = MonthSign.month.getData();
        if (!signData || !signData.switchStatus) {
            return;
        }

        if (this.data.awardStatus == MonthSign.m_status.DAILY_CLAIMED || this.data.awardStatus == MonthSign.m_status.DAILY_NOT_STARTED) {
            return;
        }

        this.RC_btnSign.active = false;

        // 签到请求
        let awards = null;
        if (this.data.awardStatus === MonthSign.m_status.DAILY_EXPIRED) {
            // 补签
            awards = await MonthSign.month.getReSignReward(this.data.day);
        } else if (this.data.awardStatus === MonthSign.m_status.DAILY_CAN_CLAIM && signData.isUnlockMultiplier) {
            // 双签
            awards = await MonthSign.month.sign(this.data.day, MonthSign.m_signCheckInAwardType.BONUS_RANDOM_MULTIPLIER);
        } else if (this.data.awardStatus === MonthSign.m_status.DAILY_CAN_RECLAIM && signData.isUnlockMultiplier) {
            // 再领取
            awards = await MonthSign.month.sign(this.data.day, MonthSign.m_signCheckInAwardType.BONUS_RANDOM_MULTIPLIER);
        } else {
            // 签到
            await we.currentUI.show(HallViewId.MonthSignAwardDlg, this.data.day);
            this.updateData(this.data.day);
            return;
        }

        if (!awards || awards.award <= 0) {
            this.updateData(this.data.day);
            return;
        }

        // 领取奖励
        const awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: awards.award }];
        HallMgr.openGetAwardsDlg(awardMap);
        cc.director.emit(HallEvent.MONTH_SIGN_AWARD_UPDATE_DATA);

        // 刷新
        this.updateData(this.data.day);
    }
}
