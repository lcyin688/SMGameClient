import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import JumpModMgr from '../../manager/JumpModMgr';
import MonthSign from '../../manager/MonthSignMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('MonthSignAwardDlgView_v', we.bundles.hall)
class MonthSignAwardDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_blue: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClaimed: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoToStore: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnReceived: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value2: cc.Label = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_times: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RC_yellow: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnClose: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('MonthSignAwardDlg_v', we.bundles.hall)
export class MonthSignAwardDlg_v extends we.ui.DlgSystem<MonthSignAwardDlgView_v> {
    private day: number = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RCN_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnClaimed, we.core.Func.create(this.onOrdinarySign, this)).setTransitionScale().setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnGoToStore, we.core.Func.create(this.onTimesSign, this)).setTransitionScale().setSleepTime(1.5);
    }

    /** 显示窗口 */
    public async onShow(day: number) {
        this.day = day;
        this.initUI();
    }

    private initUI(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        const data = MonthSign.month.getDay(this.day);
        const signData = MonthSign.month.getData();

        this.view.RC_lab_value1.string = we.common.utils.formatAmountCurrency(data.award);

        const canClaim = data.awardStatus === MonthSign.m_status.DAILY_CAN_CLAIM;
        this.view.RC_btnClaimed.active = canClaim ? true : false;
        this.view.RC_btnReceived.active = !canClaim ? true : false;

        if (signData.rechargeMultiplierConf) {
            this.view.RC_yellow.active = true;
            let twoCoin = data.award * signData.rechargeMultiplierConf.maxMultiplier;
            this.view.RC_lab_value2.string = we.common.utils.formatAmountCurrency(twoCoin);

            let maxMultiplier = Math.round(signData.rechargeMultiplierConf.maxMultiplier * 100) / 100;
            this.view.RC_rich_times.setStringFormat(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_CHOOSE_3), `${maxMultiplier}`);
        } else {
            this.view.RC_yellow.active = false;
        }
    }

    /** 普通签到 */
    async onOrdinarySign() {
        const award = await MonthSign.month.sign(this.day, MonthSign.m_signCheckInAwardType.BONUS_NORMAL);
        this.playAwardAni(award);
        this.initUI();
    }

    /** 倍数签到 */
    async onTimesSign() {
        const signData = MonthSign.month.getData();
        if (signData.isUnlockMultiplier) {
            const award = await MonthSign.month.sign(this.day, MonthSign.m_signCheckInAwardType.BONUS_RANDOM_MULTIPLIER);
            this.playAwardAni(award);
            we.currentUI.close(HallViewId.MonthSignAwardDlg);
        } else {
            // 前往商城
            we.currentUI.close(HallViewId.MonthSignAwardDlg);
            we.currentUI.close(HallViewId.MonthSignDlg);
            JumpModMgr.jumpToModule(we.common.JumpCmd.Recharge);
        }
    }

    private playAwardAni(data: any) {
        if (!data || data.award <= 0) {
            return;
        }
        // 领取奖励
        const awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.award }];
        HallMgr.openGetAwardsDlg(awardMap);
        // 刷新
        cc.director.emit(HallEvent.MONTH_SIGN_AWARD_UPDATE_DATA);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(MonthSignAwardDlg_v, `${HallViewId.MonthSignAwardDlg}_v`)
class MonthSignAwardDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(MonthSignAwardDlg_v, uiBase.addComponent(MonthSignAwardDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSignAwardDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<MonthSignAwardDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(MonthSignAwardDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSignAwardDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(MonthSignAwardDlg_v).beforeUnload();
    }
}
