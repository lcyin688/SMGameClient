import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import MonthSign from '../../manager/MonthSignMgr';
import { HallViewId } from '../HallViewId';
import MonthSignAwardItem_v from './MonthSignAwardItem_h';
import MonthSignItem_v from './MonthSignItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('MonthSignDlgView_h', we.bundles.hall)
class MonthSignDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_bar: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_bottom: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_desc: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_icon: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_bar: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_tip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnHelp: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnWarn: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('MonthSignDlg_h', we.bundles.hall)
export class MonthSignDlg_h extends we.ui.DlgSystem<MonthSignDlgView_h> {
    /** Tip隐藏时间 */
    private hideTipTime: number = 0;

    /** 累计奖励 */
    private nodeAwards: MonthSignAwardItem_v[] = [];

    /** 数据 */
    data: api.SignInConfResp = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.setAutoHideTip();

        this.view.RC_list.updateRate = 0;
        this.view.RC_list.frameByFrameRenderNum = 2;
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));

        this.view.cc_onBtnClick(this.view.RCN_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_btnHelp, we.core.Func.create(this.onClickRule, this));
        this.view.cc_onBtnClick(this.view.RCN_btnWarn, we.core.Func.create(this.onClickWarn, this));

        cc.director.on(HallEvent.MONTH_SIGN_AWARD_UPDATE_DATA, this.updateData, this);
        cc.director.on(we.common.EventName.UPDATE_MONTH_MONTH_SIGN, this.updateData, this);
    }

    protected destroy(): void {
        cc.director.off(HallEvent.MONTH_SIGN_AWARD_UPDATE_DATA, this.updateData, this);
        cc.director.off(we.common.EventName.UPDATE_MONTH_MONTH_SIGN, this.updateData, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        await MonthSign.month.asyncData();
        this.data = MonthSign.month.getData();
    }

    public async onShowAnimation() {
        if (!this.data) {
            return;
        }
        this.view.RC_list.numItems = this.data.dailySignInAwardConf.length || 0;

        await this.scheduleOnce(0.45);
        const newDay = new Date().getDate();
        this.view.RC_list.scrollTo(newDay > 28 ? 27 : newDay - 1);
    }

    /** 刷新数据 */
    private async updateData() {
        const data = MonthSign.month.getData();
        this.data = data;

        if (we.currentUI.isViewVisible(HallViewId.MonthSignRuleDlg)) {
            we.currentUI.close(HallViewId.MonthSignRuleDlg);
        }
        if (we.currentUI.isViewVisible(HallViewId.MonthSignAwardDlg)) {
            we.currentUI.close(HallViewId.MonthSignAwardDlg);
        }
        if (!data || this.data.switchStatus == false) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_2));
            this.closeView();
            return;
        }

        await this.initCumulativeAwardList();

        if (this.view.RC_list.numItems > 0) {
            this.view.RC_list.updateAll();
        }

        // 顶部描述
        let maxMultiplier = 0;
        let rechargeThreshold = 0;
        if (this.data.rechargeMultiplierConf) {
            maxMultiplier = this.data.rechargeMultiplierConf.maxMultiplier;
            rechargeThreshold = this.data.rechargeMultiplierConf.rechargeThreshold;
        }
        maxMultiplier = Math.round(maxMultiplier * 100) / 100;
        this.view.RC_rich_desc.setStringFormat(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_1), we.common.utils.formatPrice(rechargeThreshold, false, false), maxMultiplier);

        // 底部描述
        let availableCount = 0;
        if (this.data.reSignInConf) {
            availableCount = this.data.reSignInConf?.availableCount || 0;
        }
        this.view.RC_rich_bottom.setStringFormat(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_7), availableCount);

        // 累计奖励
        let award = this.data.cumulativeSignInAwardConf[this.data.cumulativeSignInAwardConf.length - 1].award;
        this.view.RC_rich_icon.setStringFormat(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_2), we.common.utils.formatAmount(award, false));

        // 进度值
        const maxSign = MonthSign.month.getCumulativeSignMaxDay();
        const overSign = this.data.cumulativeSignInCount >= maxSign ? maxSign : this.data.cumulativeSignInCount;
        this.view.RC_lab_bar.string = overSign + '/' + maxSign;
        let fillRange = MonthSign.month.calculateProgress(this.data.cumulativeSignInCount, this.data.cumulativeSignInAwardConf);
        this.view.RC_spr_bar.fillRange = fillRange;
    }

    /** 渲染事件 */
    private onRenderEvent(item: cc.Node, i: number): void {
        const com = item.getComponent(MonthSignItem_v);
        com.updateData(i);
    }

    /** 初始化 累计签到 节点 */
    private async initCumulativeAwardList() {
        const total = this.data.cumulativeSignInAwardConf.length;
        if (total <= 0) {
            for (let i = 0; i < this.nodeAwards.length; i++) {
                this.nodeAwards[i].node.active = false;
            }
            return;
        }
        if (total === this.nodeAwards.length) {
            for (let i = 0; i < this.nodeAwards.length; i++) {
                this.nodeAwards[i].node.active = true;
                this.nodeAwards[i]?.updateData(i);
            }
            return;
        }
        this.nodeAwards.length = 0;
        this.view.RC_spr_bar.node.removeAllChildren();
        // init
        const prefab = await this.loadAsset(HallRes.prefab.MonthSignAwardItem, cc.Prefab);
        for (let i = 0; i < this.data.cumulativeSignInAwardConf.length; i++) {
            let item = cc.instantiate(prefab);
            this.view.RC_spr_bar.node.addChild(item);
            const padding = this.view.RC_spr_bar.node.width / total;
            item.setPosition(padding * (i + 1), 0);
            item.active = true;
            const com = item.getComponent(MonthSignAwardItem_v);
            com?.updateData(i);
            this.nodeAwards.push(com);
        }
    }

    private setAutoHideTip() {
        this.view.RC_tip.active = false;
        this.schedule(1, () => {
            if (this.view.RC_tip.active == false) {
                return;
            }
            if (Date.now() - this.hideTipTime > 4000) {
                this.view.RC_tip.active = false;
            }
        });
    }

    private onClickRule(): void {
        we.currentUI.show(HallViewId.MonthSignRuleDlg);
    }

    private onClickWarn(): void {
        this.hideTipTime = Date.now();
        this.view.RC_tip.active = !this.view.RC_tip.active;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(MonthSignDlg_h, `${HallViewId.MonthSignDlg}_h`)
class MonthSignDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(MonthSignDlg_h, uiBase.addComponent(MonthSignDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSignDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<MonthSignDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(MonthSignDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSignDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(MonthSignDlg_h).beforeUnload();
    }

    async onShowAnimation(uiBase: we.ui.UIBase): Promise<void> {
        await we.ui.UIDlgTween.open(uiBase);
        await uiBase.getComponent(MonthSignDlg_h).onShowAnimation();
    }
}
