import { HallRes } from '../../config/HallRes';
import { HallViewId } from '../HallViewId';
import CarnivalMainContent_h from './CarnivalMainContent_h';
import CarnivalTaskItem_h from './CarnivalTaskItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('CarnivalDlgView_h', we.bundles.hall)
class CarnivalDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_betNoticeMark: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_mainNotice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_mainNoticeMark: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_rechargeNoticeMark: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_betNotice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_contentRoot: cc.Node = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RCN_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rechargeNotice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rule: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('CarnivalDlg_h', we.bundles.hall)
export class CarnivalDlg_h extends we.ui.DlgSystem<CarnivalDlgView_h> {
    // 任务分类
    private type: string = null;

    private contentComp: CarnivalMainContent_h = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        let path = HallRes.prefab.carnival.mainItem;
        let mainContentItm = await this.loadAsset(path, cc.Prefab);
        let node = cc.instantiate(mainContentItm);
        node.parent = this.view.RCN_contentRoot;

        this.contentComp = node.getComponent(CarnivalMainContent_h);
        this.contentComp.init((index) => {
            this.view.RCN_menu.onSwitchMenu(index, false);
        });

        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RCN_menu.setMenuStateByNodeName('select', 'unselect');
        this.view.RCN_menu.onSelected = (node: cc.Node, index: number) => {
            switch (index) {
                case 0:
                    this.type = null;
                    break;
                case 1: // 打码
                    this.type = we.common.carnivalMgr.taskType[1];
                    break;
                case 2: // 充值
                    this.type = we.common.carnivalMgr.taskType[0];
                    break;
                default:
                    break;
            }
            this.onRefreshUI();
        };

        this.view.cc_onBtnClick(this.view.RCN_close, we.core.Func.create(this.onCloseDlg, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_rule, we.core.Func.create(this.onClickRule, this));

        cc.director.on(we.common.EventName.CLOSE_CARNIVAL_VIEW, this.onCloseDlg, this);
        cc.director.on(we.common.EventName.UPDATE_CARNIVAL, this.onRefreshUI, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.type = null;
        this.onRefreshUI();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    protected destroy(): void {
        cc.director.off(we.common.EventName.CLOSE_CARNIVAL_VIEW, this.onCloseDlg, this);
        cc.director.off(we.common.EventName.UPDATE_CARNIVAL, this.onRefreshUI, this);
    }

    private onRenderEvent(node: cc.Node, index: number): void {
        if (this.type) {
            let taskData: api.TaskProgressDetail[] = we.common.carnivalMgr.actInfo?.[this.type] || [];
            taskData = we.common.activityMgr.sortTask(taskData);
            let cmp = node.getComponent(CarnivalTaskItem_h);
            if (index < taskData.length && cmp) {
                cmp.init(taskData[index], this.type);
            }
        }
    }

    private onClickRule() {
        we.currentUI.showSafe(HallViewId.CarnivalRuleDlg);
    }

    private onCloseDlg(isCb: boolean = true): void {
        if (isCb) {
            cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Carnival);
        }

        this.closeView();
    }

    private onRefreshUI() {
        if (!we.common.carnivalMgr.isOpenAct()) {
            we.common.carnivalMgr.activityClose();
            return;
        }

        this.contentComp?.updateCarnival();
        this.updateCarnival();
        this.setNotice();
        if (!this.type) {
            this.contentComp.node.active = true;
            this.view.RC_list.node.active = false;
            return;
        }

        this.contentComp.node.active = false;
        this.view.RC_list.node.active = true;
        this.view.RC_list.numItems = 0;
        let taskData: api.TaskProgressDetail[] = we.common.carnivalMgr.actInfo?.[this.type] || [];
        this.view.RC_list.numItems = taskData.length;
    }

    private updateCarnival(): void {
        let data = we.common.carnivalMgr.actInfo;
        if (!data) {
            return;
        }

        // 活动时间
        let startMs = data.startTime * 1000;
        let endMs = data.endTime * 1000;
        let start = we.common.utils.formatDate(new Date(startMs), 'DD/MM hh:mm');
        let end = we.common.utils.formatDate(new Date(endMs), 'DD/MM hh:mm');
        this.view.RC_lab_time.string = start + ' - ' + end;
    }

    private setNotice(): void {
        let taskTypeKey = we.common.carnivalMgr.taskType;
        this.view.RC_mainNotice.active = we.common.carnivalMgr.actInfo?.ultimateTaskStatus === we.common.activityMgr.TaskStatus.COMPLETED;
        this.view.RC_mainNoticeMark.active = we.common.carnivalMgr.actInfo?.ultimateTaskStatus === we.common.activityMgr.TaskStatus.COMPLETED;
        this.view.RCN_rechargeNotice.active = we.common.carnivalMgr.isShowRedPointByType(taskTypeKey[0]);
        this.view.RC_rechargeNoticeMark.active = we.common.carnivalMgr.isShowRedPointByType(taskTypeKey[0]);
        this.view.RCN_betNotice.active = we.common.carnivalMgr.isShowRedPointByType(taskTypeKey[1]);
        this.view.RC_betNoticeMark.active = we.common.carnivalMgr.isShowRedPointByType(taskTypeKey[1]);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(CarnivalDlg_h, `${HallViewId.CarnivalDlg}_h`)
class CarnivalDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(CarnivalDlg_h, uiBase.addComponent(CarnivalDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CarnivalDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<CarnivalDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(CarnivalDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CarnivalDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(CarnivalDlg_h).beforeUnload();
    }
}
