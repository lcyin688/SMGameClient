import HallMgr from '../../manager/HallMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class CarnivalMainContent_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_allOver: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_betGo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_betNotice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_betOver: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGetAward: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_grayAward: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_allAward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bet: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bet_target: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_betRatio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_recharge: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_recharge_target: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_rechargeRatio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_rechargeGo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_rechargeNotice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_rechargeOver: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private callback: Function = null;
    private leftTime: number = 0;
    private isStartCountdown: boolean = false;
    // 领取奖励中
    private receivingAward: boolean = false;

    protected onLoad(): void {
        this.onBtnClick(this.RC_rechargeGo, we.core.Func.create(this.onRechargeBtnClicked, this));
        this.onBtnClick(this.RC_betGo, we.core.Func.create(this.onBetBtnClicked, this));
        this.onBtnClick(this.RC_btnGetAward, we.core.Func.create(this.onBigAwardClicked, this));
    }

    protected update(dt: number): void {
        this.countdownShow(dt);
    }

    public init(callback: Function) {
        this.callback = callback;
    }

    private onRechargeBtnClicked() {
        if (!we.common.carnivalMgr.isOpenAct()) {
            we.common.carnivalMgr.activityClose();
            return;
        }
        this.callback?.(2);
    }

    private onBetBtnClicked() {
        if (!we.common.carnivalMgr.isOpenAct()) {
            we.common.carnivalMgr.activityClose();
            return;
        }
        this.callback?.(1);
    }

    private onBigAwardClicked() {
        if (this.receivingAward) {
            return;
        }
        this.receivingAward = true;
        if (we.common.carnivalMgr.isOpenAct()) {
            let param = {} as api.DrawNewTaskAwardReq;
            param.level = 0; // 总奖励 level 传入 0
            param.taskType = we.common.activityMgr.ActivityType.carnival;
            param.typeEnum = we.common.activityMgr.TaskType.ultimate;
            we.common.apiMgr.drawActivityAward(param, (data: api.DrawNewTaskAwardResp) => {
                if (data.drawAwardStatus == 1) {
                    if (we.common.carnivalMgr.actInfo) {
                        we.common.carnivalMgr.actInfo.ultimateTaskStatus = we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
                    }

                    let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.drawAwardNum }];
                    HallMgr.openGetAwardsDlg(awardMap);

                    we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.carnival, -1);
                    cc.director.emit(we.common.EventName.UPDATE_CARNIVAL);
                } else {
                    this.receivingAward = false;
                    we.common.activityMgr.getTaskAwardErrorHandle(data?.drawAwardStatus);
                }
            });
        } else {
            if (cc.isValid(this.node)) {
                this.receivingAward = false;
            }
            we.common.carnivalMgr.activityClose();
        }
    }

    public updateCarnival(): void {
        let data = we.common.carnivalMgr.actInfo;
        if (!data) {
            return;
        }

        this.isStartCountdown = false;
        this.receivingAward = false;
        this.RC_lab_recharge.string = data.rechargeTaskAttainCount.toString();
        this.RC_lab_recharge_target.string = data.rechargeTaskCount.toString();
        this.RC_rechargeGo.active = data.rechargeTaskAttainCount != data.rechargeTaskCount;
        this.RC_rechargeOver.active = data.rechargeTaskAttainCount == data.rechargeTaskCount;

        this.RC_lab_bet.string = data.betAmountTaskAttainCount.toString();
        this.RC_lab_bet_target.string = data.betAmountTaskCount.toString();
        this.RC_betGo.active = data.betAmountTaskAttainCount != data.betAmountTaskCount;
        this.RC_betOver.active = data.betAmountTaskAttainCount == data.betAmountTaskCount;

        this.RC_rechargeNotice.active = we.common.carnivalMgr.isShowRedPointByType(we.common.activityMgr.TaskType.recharge);
        this.RC_betNotice.active = we.common.carnivalMgr.isShowRedPointByType(we.common.activityMgr.TaskType.betAmount);

        this.RC_lab_allAward.string = we.common.utils.formatAmountCurrency(data.ultimateReward);

        this.leftTime = data.endTime - we.core.TimeInfo.Inst.serverNow() / 1000;
        this.RC_lab_time.string = we.common.utils.formatSeconds(this.leftTime > 0 ? Math.ceil(this.leftTime) : 0);
        this.isStartCountdown = this.leftTime > 0;

        let ratioLabArr: cc.Label[] = [this.RC_lab_rechargeRatio, this.RC_lab_betRatio];
        let taskTypeKey = we.common.carnivalMgr.taskType;
        for (let i = 0; i < taskTypeKey.length; i++) {
            let ratioLab = ratioLabArr[i];
            if (!ratioLab) {
                break;
            }

            let taskArr: api.TaskProgressDetail[] = data[taskTypeKey[i]];
            let maxScore = 0;
            let allAward = 0;
            for (let j = 0; j < taskArr.length; j++) {
                allAward += taskArr[j].reward;
                if (taskArr[j].target > maxScore) {
                    maxScore = taskArr[j].target;
                }
            }
            if (taskTypeKey[i] == we.common.activityMgr.TaskType.recharge) {
                maxScore = we.common.utils.priceToAmount(maxScore);
            }
            let ratioStr = '+' + Math.round((allAward / maxScore) * 100 * 100) / 100 + '%';
            ratioLabArr[i].string = ratioStr;
        }

        this.RC_grayAward.active = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.ONGOING;
        this.RC_btnGetAward.active = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.COMPLETED;
        this.RC_allOver.active = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.REWARD_RECEIVED;

        this.setNotice();
    }

    private countdownShow(dt: number): void {
        if (this.isStartCountdown) {
            this.leftTime -= dt;
            if (this.leftTime > 0) {
                this.RC_lab_time.string = we.common.utils.formatSeconds(Math.ceil(this.leftTime));
            } else {
                this.isStartCountdown = false;
                this.RC_lab_time.string = we.common.utils.formatSeconds(0);
            }
        }
    }

    private setNotice(): void {
        let noticeArr: cc.Node[] = [this.RC_rechargeNotice, this.RC_betNotice];
        let taskTypeKey = we.common.carnivalMgr.taskType;
        for (let i = 0; i < taskTypeKey.length; i++) {
            let notice = noticeArr[i];
            if (!notice) {
                continue;
            }

            noticeArr[i].active = we.common.carnivalMgr.isShowRedPointByType(taskTypeKey[i]);
        }
    }
}
