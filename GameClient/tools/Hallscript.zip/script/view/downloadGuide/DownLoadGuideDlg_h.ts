import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('DownLoadGuideDlgView_h', we.bundles.hall)
class DownLoadGuideDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnCustomer: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnDownload: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnJump: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_url: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_jumpBg: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('DownLoadGuideDlg_h', we.bundles.hall)
export class DownLoadGuideDlg_h extends we.ui.DlgSystem<DownLoadGuideDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnCustomer, we.core.Func.create(this.onClickCustomer, this));
        this.view.cc_onBtnClick(this.view.RC_btnDownload, we.core.Func.create(this.onClickDownload, this));
        this.view.cc_onBtnClick(this.view.RC_btnJump, we.core.Func.create(this.onClickJump, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_btnClose.active = we.core.gameConfig.isSubGame(we.core.gameConfig.curGameId) || !we.common.downloadGuideMgr.isForceGuide();

        this.initUI();
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Download_Guide);
    }

    public beforeUnload() {}

    private initUI(): void {
        let conf = we.common.downloadGuideMgr.forceGuideConf;

        let tipsStr = conf?.downloadLeadContentNew[we.core.langMgr.getCurLangCode()];
        if (tipsStr) {
            this.view.RC_lab_tips.string = tipsStr;
        }

        const jumpUrl = conf?.downloadGuideQuickJumpAddress || '';
        this.view.RC_lab_url.string = jumpUrl;
        const iconUrl = conf?.downloadGuideQuickJumpIcon;
        if (iconUrl.startsWith('http')) {
            this.loadAssetRemote(iconUrl, cc.SpriteFrame).then((spriteFrame) => {
                this.view.RC_spr_icon.spriteFrame = spriteFrame;
            });
        }

        this.view.RCN_jumpBg.active = jumpUrl != '' || iconUrl != '';
    }

    private onClickCustomer(): void {
        we.common.commonMgr.openCustomerDialog();
    }

    private onClickDownload(): void {
        if (we.common.userMgr.isFormal()) {
            we.currentUI.show(HallViewId.DownLoadGuideUserInfoDlg);
        } else {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
        }
    }

    private onClickJump(): void {
        if (we.common.userMgr.isFormal()) {
            we.core.nativeUtil.openUrl(we.common.downloadGuideMgr.forceGuideConf?.downloadGuideQuickJumpAddress);
        } else {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(DownLoadGuideDlg_h, `${HallViewId.DownLoadGuideDlg}_h`)
class DownLoadGuideDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(DownLoadGuideDlg_h, uiBase.addComponent(DownLoadGuideDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DownLoadGuideDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<DownLoadGuideDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(DownLoadGuideDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DownLoadGuideDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(DownLoadGuideDlg_h).beforeUnload();
    }
}
