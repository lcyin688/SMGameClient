import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('ApkDownloadDlgView_v', we.bundles.hall)
class ApkDownloadDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_download: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('ApkDownloadDlg_v', we.bundles.hall)
export class ApkDownloadDlg_v extends we.ui.DlgSystem<ApkDownloadDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RCN_download, we.core.Func.create(this.onClickDownload, this));
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {}

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Download_apk);
    }

    public beforeUnload() {}

    private onClickDownload(): void {
        if (we.common.userMgr.isFormal()) {
            we.currentUI.show(HallViewId.DownLoadGuideUserInfoDlg);
        } else {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(ApkDownloadDlg_v, `${HallViewId.ApkDownloadDlg}_v`)
class ApkDownloadDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(ApkDownloadDlg_v, uiBase.addComponent(ApkDownloadDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ApkDownloadDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<ApkDownloadDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(ApkDownloadDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ApkDownloadDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(ApkDownloadDlg_v).beforeUnload();
    }
}
