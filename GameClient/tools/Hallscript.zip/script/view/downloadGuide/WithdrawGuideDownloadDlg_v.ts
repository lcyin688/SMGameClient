import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawGuideDownloadDlgView_v', we.bundles.hall)
class WithdrawGuideDownloadDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnGiveUp: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGiveUpGray: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_giveUp: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_awardRoot: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_download: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawGuideDownloadDlg_v', we.bundles.hall)
export class WithdrawGuideDownloadDlg_v extends we.ui.DlgSystem<WithdrawGuideDownloadDlgView_v> {
    private leftTime: number = 3;
    private enableClickGiveUp: boolean = false;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnGiveUp, we.core.Func.create(this.onClickGiveUp, this));
        this.view.cc_onBtnClick(this.view.RCN_download, we.core.Func.create(this.onClickDownload, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RCN_download.active = true;
        this.view.RC_btnGiveUpGray.active = true;
        this.view.RC_btnGiveUp.active = false;

        this.view.RC_lab_tips.string = we.core.langMgr.getLangText(HallLanguage.DOWNLOAD_TIPS_1);
        let tipsStr = we.common.withdrawMgr.config?.withdrawDownloadLeadContent[we.core.langMgr.getCurLangCode()];
        if (tipsStr && tipsStr.length > 0) {
            this.view.RC_lab_tips.string = tipsStr;
        }

        let award = we.common.activityMgr.officialPkgAward?.bonus || 0;
        this.view.RC_lab_award.string = we.common.utils.formatAmount(award);
        let _switch = we.common.activityMgr.officialPkgAward?.officialAppBonusSwitch;
        this.view.RCN_awardRoot.active = _switch && award > 0;
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected update(): void {
        if (this.enableClickGiveUp) {
            return;
        }

        if (this.leftTime > 0) {
            this.leftTime -= this.deltaTime;
            this.view.RC_lab_giveUp.string = we.core.langMgr.getLangText(HallLanguage.DOWNLOAD_TIPS_2) + ` (${Math.ceil(this.leftTime)})`;
        } else {
            this.enableClickGiveUp = true;
        }

        this.setGiveUpSt();
    }

    private onClickGiveUp(): void {
        if (this.leftTime > 0) {
            return;
        }

        this.closeView();
    }

    private onClickDownload(): void {
        if (we.common.userMgr.isFormal()) {
            we.currentUI.show(HallViewId.DownLoadGuideUserInfoDlg);
        } else {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
        }
    }

    private setGiveUpSt(): void {
        this.view.RC_btnGiveUpGray.active = this.leftTime > 0;
        this.view.RC_btnGiveUp.active = this.leftTime <= 0;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawGuideDownloadDlg_v, `${HallViewId.WithdrawGuideDownloadDlg}_v`)
class WithdrawGuideDownloadDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawGuideDownloadDlg_v, uiBase.addComponent(WithdrawGuideDownloadDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawGuideDownloadDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawGuideDownloadDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawGuideDownloadDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawGuideDownloadDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawGuideDownloadDlg_v).beforeUnload();
    }
}
