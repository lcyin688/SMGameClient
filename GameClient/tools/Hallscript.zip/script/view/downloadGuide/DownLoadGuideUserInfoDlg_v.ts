import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('DownLoadGuideUserInfoDlgView_v', we.bundles.hall)
class DownLoadGuideUserInfoDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_coin: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_continue: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_email: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_id: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phone: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_pwd: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_logo: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_continue: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_email: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_qrcode: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('DownLoadGuideUserInfoDlg_v', we.bundles.hall)
export class DownLoadGuideUserInfoDlg_v extends we.ui.DlgSystem<DownLoadGuideUserInfoDlgView_v> {
    private clickCount: number = 0;
    private guideInfo: api.OfficialUserDetailResp = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RCN_continue, we.core.Func.create(this.onClickContinueBtn, this));
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.loadAssetRemote(we.core.projectConfig.commonConfig.brandLogoUrl, cc.SpriteFrame).then((spf) => {
            this.view.RC_spr_logo.spriteFrame = spf;
        });

        this.view.RC_lab_continue.string = we.core.langMgr.getLangText(we.common.lang.BTN_NEXT);
        this.view.RC_btnClose.active = we.core.gameConfig.isSubGame(we.core.gameConfig.curGameId) || !we.common.downloadGuideMgr.isForceGuide();

        this.init();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private init() {
        we.common.downloadGuideMgr.getDownloadGuideInfo((data: api.OfficialUserDetailResp) => {
            if (data && cc.isValid(this.view.uiRoot)) {
                this.guideInfo = data;
                this.view.RC_lab_id.string = '' + data.userId;
                this.view.RC_lab_name.string = we.common.utils.formatNickname(data.userName, 8);
                this.view.RC_lab_phone.string = data.phoneNum;
                this.view.RC_lab_email.string = data.emailAccount;
                this.view.RC_lab_coin.string = we.common.utils.formatAmountCurrency(data.balance);

                const phoneEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Phone);
                const emailEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Email);
                this.view.RCN_phone.active = phoneEnabled && this.view.RC_lab_phone.string.length > 0;
                this.view.RCN_email.active = emailEnabled && this.view.RC_lab_email.string.length > 0;

                let pwd = '******';
                let curAccount = we.common.loginMgr.getCurLoginAccount();
                if (curAccount) {
                    pwd = curAccount.password ? curAccount.password : '******';
                }
                this.view.RC_lab_pwd.string = pwd;

                let linkContent = we.common.downloadGuideMgr.getDownloadQRUrl(data);
                if (linkContent) {
                    we.common.utils.generateQrCode(this.view.RCN_qrcode, linkContent);
                }
            }
        });
    }

    private onClickContinueBtn() {
        if (this.clickCount == 0) {
            this.view.RC_lab_continue.string = we.core.langMgr.getLangText(HallLanguage.DOWNLOAD_HALL_Bonus8);
            this.clickCount += 1;
        } else if (this.clickCount == 1) {
            if (we.core.projectConfig.settingsConfig?.isPwa) {
                let pwaTag = we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.pwa);
                if (pwaTag) {
                    if (we.common.downloadGuideMgr.isShowIosCollect()) {
                        HallMgr.clickIosCollectBtn();
                    }

                    if (we.common.downloadGuideMgr.isShowApkDownload()) {
                        HallMgr.clickApkDownloadBtn();
                    }
                } else {
                    let pwaUrl = we.common.downloadGuideMgr.getPWAInstallUrl();
                    if (pwaUrl) {
                        we.core.nativeUtil.openUrlByChrome(pwaUrl);
                        we.log(`DownLoadGuideUserInfoDlg_v onClickContinueBtn, pwaUrl: ${pwaUrl}`);
                    }
                }
            } else {
                we.common.apiMgr.getTempToken((data: api.GetTmpTokenResp) => {
                    if (!data || !cc.isValid(this.view.uiRoot)) {
                        return;
                    }

                    let loginData = {
                        userId: we.common.userMgr.userInfo.userId,
                        tmpToken: data.tmpToken,
                        ts: new Date().getTime() / 1000,
                    };
                    let str = we.core.utils.base64Encode(JSON.stringify(loginData));
                    we.core.nativeUtil.copyText(str);

                    we.kit.storage.setById('sys', 'user_get_tmp_token_login_tag', 1);
                    we.core.nativeUtil.openUrl(this.guideInfo?.downloadUrl);
                });
            }
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(DownLoadGuideUserInfoDlg_v, `${HallViewId.DownLoadGuideUserInfoDlg}_v`)
class DownLoadGuideUserInfoDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(DownLoadGuideUserInfoDlg_v, uiBase.addComponent(DownLoadGuideUserInfoDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DownLoadGuideUserInfoDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<DownLoadGuideUserInfoDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(DownLoadGuideUserInfoDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DownLoadGuideUserInfoDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(DownLoadGuideUserInfoDlg_v).beforeUnload();
    }
}
