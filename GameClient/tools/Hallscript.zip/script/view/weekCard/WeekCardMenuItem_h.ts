const { ccclass, property } = cc._decorator;

@ccclass
export default class WeekCardMenuItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /** 累计赠送金额 */
    @we.ui.ccBind(cc.Label)
    public RC_lab_num_0: cc.Label = null;

    /** 累计赠送金额 */
    @we.ui.ccBind(cc.Label)
    public RC_lab_num_1: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_tag: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private styleCmp: we.ui.WERenderStyleIndex = null;

    protected onLoad(): void {
        this.styleCmp = this.node.getComponent(we.ui.WERenderStyleIndex);
    }

    /**
     * 初始化菜单按钮
     * @param index 数组下标
     * @param amount 数量
     * @param buyTag 购买标识
     */
    public init(index: number, amount: number, buyTag: boolean = false): void {
        if (this.styleCmp) {
            this.styleCmp.index = index;
        }
        this.RCN_tag.active = buyTag;

        let amountStr = we.common.utils.formatAmountCurrency(amount, false);
        this.RC_lab_num_0.string = amountStr;
        this.RC_lab_num_1.string = amountStr;
    }
}
