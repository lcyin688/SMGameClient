import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDayGiftNode_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_icon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bonus: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bonus: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: api.NewBieSevenDayActivityGiftInfo, isAward?: boolean) {
        this.__initRc();
        this.RC_lab_title.string = we.core.langMgr.getLangText(isAward ? HallLanguage.SEVEN_DAY_GIFT_2 : HallLanguage.SEVEN_DAY_GIFT_1);
        this.RC_lab_award.string = we.common.utils.formatAmountCurrency(isAward ? data.award : data.coin);
        this.RC_icon.index = (data.level - 1) * 2 + (isAward ? 1 : 0);
        this.RCN_bonus.active = isAward;
        this.RC_lab_bonus.string = `+${~~((data.award / data.coin) * 100)}%`;
    }
}
