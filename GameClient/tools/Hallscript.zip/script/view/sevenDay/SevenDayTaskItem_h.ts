import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import SevenDayMgr from '../../manager/SevenDayMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDayTaskItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.ProgressBar)
    public RC_bar: cc.ProgressBar = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_icon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bar: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_desc: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_lock: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_get: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_go: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_lock: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mark: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mask: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private data: api.TaskProgressDetailWithLockTime;

    protected onLoad(): void {
        this.onBtnClick(this.RCN_btn_get, we.core.Func.create(this.onClickGet, this)).setTransitionScale();
        this.onBtnClick(this.RCN_btn_go, we.core.Func.create(this.onClickGo, this)).setTransitionScale();
    }

    private onClickGet() {
        SevenDayMgr.instance.requestTaskAward(this.data.level);
    }

    private onClickGo() {
        HallMgr.openRecentGame();
    }

    public async init(data: api.TaskProgressDetailWithLockTime) {
        this.__initRc();

        this.data = data;
        this.RC_lab_title.string = we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_9, data.day);
        this.RC_lab_award.string = we.common.utils.formatAmount(data.reward);
        this.RC_lab_desc.string = we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_10, we.common.utils.formatAmount(data.target, false));
        this.RC_bar.progress = Math.min(data.progress / data.target, 1);
        this.RC_lab_bar.string = `${we.common.utils.formatAmount(Math.min(data.progress, data.target), false)}/${we.common.utils.formatAmount(data.target, false)}`;

        this.RCN_btn_go.active = data.taskStatus === 1;
        this.RCN_btn_get.active = data.taskStatus === 2;
        this.RCN_mark.active = data.taskStatus === 3;

        this.RCN_mask.active = this.RCN_lock.active = false;
        if (data.taskStatus === 0) {
            this.RCN_mask.active = true;
            this.RC_lab_lock.node.active = true;
            // 兼容处理，一些皮肤 RC_lab_lock 没有 we.ui.WENodeColorIndex
            this.RC_lab_lock.getComponent(we.ui.WENodeColorIndex)?.setIndex(SevenDayMgr.instance.condition > 0 ? 0 : 1);
            if (SevenDayMgr.instance.condition > 0) {
                this.RCN_lock.active = true;
                this.RC_lab_lock.string = we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_8, we.common.utils.formatPrice(SevenDayMgr.instance.condition, true, false));
            } else {
                await this.nodeAddComponent(this.RCN_mask, we.ui.WETimeCountDown).countDown(0, data.unlockTime - we.core.TimeHelper.getTimestampS(), '{HH}:{MM}:{SS}', (str, duration, elapsed) => {
                    this.RC_lab_lock.string = we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_13, we.common.utils.formatSeconds(duration - elapsed));
                });
                SevenDayMgr.instance.requestDataSilent();
            }
        }
    }
}
