import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDaySignItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_bg: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_icon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_current: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mark: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mask: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: api.NewBieSevenDayActivityDailyRewardInfo, isLast: boolean) {
        this.__initRc();
        const index = isLast ? 2 : data.state === 1 ? 1 : 0;
        // 兼容处理，一些皮肤没有 RC_bg
        this.RC_bg?.setIndex(index);
        // 兼容处理，一些皮肤 RC_lab_title 没有 we.ui.WENodeColorIndex
        this.RC_lab_title.getComponent(we.ui.WENodeColorIndex)?.setIndex(index);
        // 兼容处理，一些皮肤 RC_lab_award 没有 we.ui.WENodeColorIndex
        this.RC_lab_award.getComponent(we.ui.WENodeColorIndex)?.setIndex(index);
        this.RC_lab_title.string = we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_9, data.day);
        this.RC_lab_award.string = we.common.utils.formatAmountCurrency(data.award);
        this.RC_icon.index = data.day - 1;
        // 兼容处理，一些皮肤没有 RCN_current
        this.RCN_current && (this.RCN_current.active = data.state === 1);
        this.RCN_mask.active = data.state > 1;
        this.RCN_mark.active = data.state === 2;
    }
}
