import { HallViewId } from '../HallViewId';
import RescueFundsRecordItem_h from './RescueFundsRecordItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RescueFundsRecordDlgView_h', we.bundles.hall)
class RescueFundsRecordDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_noRecord: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RescueFundsRecordDlg_h', we.bundles.hall)
export class RescueFundsRecordDlg_h extends we.ui.DlgSystem<RescueFundsRecordDlgView_h> {
    private recordData: api.ReliefRecord[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_noRecord.active = false;

        this.getRecordData();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private getRecordData() {
        we.common.rescueFundsMgr.getRescueFundsRecord((msgData: api.ReliefFundApplyRecordResp) => {
            if (!msgData?.data || !cc.isValid(this.view.uiRoot)) {
                return;
            }

            if (msgData.data?.length > 0) {
                this.recordData = msgData.data;
                this.view.RC_list.numItems = msgData.data.length;
            } else {
                this.view.RC_noRecord.active = true;
            }
        });
    }

    private onRenderEvent(node: cc.Node, index: number): void {
        node.getComponent(RescueFundsRecordItem_h)?.init(this.recordData[index]);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RescueFundsRecordDlg_h, `${HallViewId.RescueFundsRecordDlg}_h`)
class RescueFundsRecordDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RescueFundsRecordDlg_h, uiBase.addComponent(RescueFundsRecordDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RescueFundsRecordDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RescueFundsRecordDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(RescueFundsRecordDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RescueFundsRecordDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RescueFundsRecordDlg_h).beforeUnload();
    }
}
