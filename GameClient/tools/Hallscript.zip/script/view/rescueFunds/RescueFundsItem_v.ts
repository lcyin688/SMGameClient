import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RescueFundsItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnApplied: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnApply: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecord: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_applied: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_lose: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_loseTips: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_loseTitle: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_needLose: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_needRecharge: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_recharge: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_topTips: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_topTitle: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private dataType: number = we.common.RescueFundsDataType.yesterday;

    protected onLoad(): void {
        this.onBtnClick(this.RC_btnRecord, we.core.Func.create(this.onClickRecord, this));
        this.onBtnClick(this.RC_btnApplied, we.core.Func.create(this.onClickApplyed, this));
        this.onBtnClick(this.RC_btnApply, we.core.Func.create(this.onClickApply, this));

        cc.director.on(we.common.EventName.RESCUE_FUNDS_SYNC, this.syncRescueFundsData, this);
    }

    public init(dataType: number): void {
        this.dataType = dataType;

        this.RC_lab_title.string = we.core.langMgr.getLangText(this.dataType == we.common.RescueFundsDataType.yesterday ? HallLanguage.EVENT_RESCUE_FUNDS_3 : HallLanguage.EVENT_RESCUE_FUNDS_6) + ':';
        this.RC_lab_topTitle.string = we.core.langMgr.getLangText(HallLanguage.BTN_BUY) + '：';
        this.RC_lab_loseTitle.string = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_5) + '：';

        const styleIndex = this.dataType == we.common.RescueFundsDataType.today ? 1 : 0;
        if (this.node.getComponent(we.ui.WERenderStyleIndex)) {
            // 使用 WERenderStyleIndex 控制整体样式，昨天和今天的样式不同
            this.node.getComponent(we.ui.WERenderStyleIndex).index = styleIndex;
        }

        this.syncRescueFundsData();
    }

    protected onDestroy(): void {
        cc.director.off(we.common.EventName.RESCUE_FUNDS_SYNC, this.syncRescueFundsData, this);
    }

    private syncRescueFundsData(): void {
        this.RC_btnApply.active = false;
        this.RC_btnApplied.active = false;
        this.RC_btnRecord.active = false;
        if (this.dataType == we.common.RescueFundsDataType.today) {
            this.RC_btnRecord.active = true;
        }

        this.RC_lab_topTips.node.active = true;
        this.RC_lab_loseTips.node.active = true;

        if (!we.common.rescueFundsMgr.getRescueFundsIsAct()) {
            return;
        }

        if (!we.common.rescueFundsMgr.rescueFundsData?.confData?.data) {
            return;
        }

        if (we.common.rescueFundsMgr.rescueFundsData.confData.data.length < this.dataType + 1) {
            return;
        }
        const data = we.common.rescueFundsMgr.rescueFundsData.confData.data[this.dataType];
        if (!data) {
            return;
        }
        if (data.rechargeAmount <= 0 && data.lossAmount <= 0) {
            return;
        }

        this.RC_lab_topTips.node.active = false;
        this.RC_lab_loseTips.node.active = false;

        // 对于单个节点 完成与未完成可能有单独样式，使用 WERenderStyleIndex 挂载与否判断有没有单独样式
        const rechargeStyle = this.RC_lab_recharge.node.getComponent(we.ui.WERenderStyleIndex);
        if (rechargeStyle) {
            rechargeStyle.index = 1;
        }

        const loseStyle = this.RC_lab_lose.node.getComponent(we.ui.WERenderStyleIndex);
        if (loseStyle) {
            loseStyle.index = 1;
        }

        this.RC_lab_recharge.string = we.common.utils.formatPrice(data.rechargeAmount, false);
        this.RC_lab_needRecharge.string = '/' + we.common.utils.formatPrice(data.rechargeStandard, false);
        if (data.lossAmount <= 0) {
            this.RC_lab_lose.string = '';
            this.RC_lab_needLose.string = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_23);
        } else {
            this.RC_lab_lose.string = we.common.utils.formatAmount(data.lossAmount);
            this.RC_lab_needLose.string = '/' + we.common.utils.formatAmount(data.lossStandard);
            if (data.lossAmount >= data.lossStandard && loseStyle) {
                loseStyle.index = 0;
            }
        }
        if (data.rechargeAmount >= data.rechargeStandard && rechargeStyle) {
            rechargeStyle.index = 0;
        }

        if (this.dataType == we.common.RescueFundsDataType.yesterday) {
            switch (data.ableToApply) {
                case we.common.RescueFundsAbleToApply.apply:
                    this.RC_btnApply.active = true;
                    break;
                case we.common.RescueFundsAbleToApply.applied:
                    this.RC_btnApplied.active = true;
                    this.RC_lab_applied.string = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_8);
                    break;
                case we.common.RescueFundsAbleToApply.notApply:
                    this.RC_btnApplied.active = true;
                    this.RC_lab_applied.string = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_7);
                    break;
                default:
                    break;
            }
        }
    }

    private onClickRecord(): void {
        we.currentUI.showSafe(HallViewId.RescueFundsRecordDlg);
    }

    private onClickApply(): void {
        we.common.rescueFundsMgr.userApplyRescueFunds((data: api.ReliefFundApplyResp) => {
            if (!data) {
                return;
            }

            if (data.applyStatus == we.common.RescueFundsApplyStatus.activityClose) {
                return;
            }

            switch (data.applyStatus) {
                case we.common.RescueFundsApplyStatus.success:
                    {
                        we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_9));

                        if (data.autoReview) {
                            const awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.reliefAmount }];
                            HallMgr.openGetAwardsDlg(awardMap);
                        }

                        if (cc.isValid(this.node)) {
                            this.RC_btnApply.active = false;
                            this.RC_btnApplied.active = true;
                            this.RC_lab_applied.string = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_8);
                        }
                    }
                    break;
                default:
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_24));
                    break;
            }
        });
    }

    private onClickApplyed(): void {
        if (we.common.rescueFundsMgr.rescueFundsData?.confData?.data?.length < 1) {
            return;
        }

        let langeKey = '';
        switch (we.common.rescueFundsMgr.rescueFundsData.confData.data[we.common.RescueFundsDataType.yesterday].ableToApply) {
            case we.common.RescueFundsAbleToApply.applied:
                langeKey = HallLanguage.EVENT_RESCUE_FUNDS_10;
                break;
            case we.common.RescueFundsAbleToApply.notApply:
                langeKey = HallLanguage.EVENT_RESCUE_FUNDS_11;
                break;
            default:
                break;
        }
        we.commonUI.showToast(we.core.langMgr.getLangText(langeKey));
    }
}
