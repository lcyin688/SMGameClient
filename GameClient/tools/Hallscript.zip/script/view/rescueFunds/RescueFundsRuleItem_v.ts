import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RescueFundsRuleItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_td0: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_td1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_td2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_td3: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_td4: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(item: api.UserVipLevelConf): void {
        this.RC_lab_td0.string = '' + item.vipLevel;
        this.RC_lab_td1.string = '' + (item.lossScale ? item.lossScale / 10 + '%' : '-');
        this.RC_lab_td2.string = item.lossScale ? we.common.utils.formatPrice(item.rechargeStandard, false) : '-';
        this.RC_lab_td3.string = item.lossScale ? we.common.utils.formatAmount(item.lossStandard) : '-';
        this.RC_lab_td4.string = item.lossScale ? (item.rebateLimit ? we.common.utils.formatAmount(item.rebateLimitNumber) : we.core.langMgr.getLangText(HallLanguage.GIFT_COINS_LIMIT)) : '-';
    }
}
