import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import RescueFundsItem_v from './RescueFundsItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RescueFundsDlgView_v', we.bundles.hall)
class RescueFundsDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_todayRoot: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_yesterdayRoot: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RescueFundsDlg_v', we.bundles.hall)
export class RescueFundsDlg_v extends we.ui.DlgSystem<RescueFundsDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnRule, we.core.Func.create(this.onClickRule, this));

        cc.director.on(we.common.EventName.RESCUE_FUNDS_SYNC, this.onRefreshUI, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        await we.common.rescueFundsMgr.getUserApplyList();

        this.initUI();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(we.common.EventName.RESCUE_FUNDS_SYNC, this.onRefreshUI, this);
    }

    private async initUI(): Promise<void> {
        const prefab = await this.loadAsset(HallRes.prefab.rescueFunds.RescueFundsItem, cc.Prefab);

        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        const todayList = cc.instantiate(prefab);
        this.view.RC_todayRoot.addChild(todayList);
        todayList.getComponent(RescueFundsItem_v)?.init?.(we.common.RescueFundsDataType.today);

        const yesterdayList = cc.instantiate(prefab);
        this.view.RC_yesterdayRoot.addChild(yesterdayList);
        yesterdayList.getComponent(RescueFundsItem_v)?.init?.(we.common.RescueFundsDataType.yesterday);
    }

    private onRefreshUI(): void {
        if (!we.common.rescueFundsMgr.getRescueFundsIsAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_42));
            this.closeView();
        }
    }

    private onClickRule(): void {
        we.currentUI.showSafe(HallViewId.RescueFundsRuleDlg);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RescueFundsDlg_v, `${HallViewId.RescueFundsDlg}_v`)
class RescueFundsDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RescueFundsDlg_v, uiBase.addComponent(RescueFundsDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RescueFundsDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RescueFundsDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(RescueFundsDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RescueFundsDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RescueFundsDlg_v).beforeUnload();
    }
}
