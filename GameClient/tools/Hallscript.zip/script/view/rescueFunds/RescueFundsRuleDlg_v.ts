import { HallRes } from '../../config/HallRes';
import { HallViewId } from '../HallViewId';
import RescueFundsRuleItem_v from './RescueFundsRuleItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RescueFundsRuleDlgView_v', we.bundles.hall)
class RescueFundsRuleDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_scContent: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_vipInfo: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RescueFundsRuleDlg_v', we.bundles.hall)
export class RescueFundsRuleDlg_v extends we.ui.DlgSystem<RescueFundsRuleDlgView_v> {
    private contentScrollViewBox: cc.Rect = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.initUI();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected update(): void {
        this.setChildOpacity(this.view.RC_scContent);
    }

    private initUI(): void {
        we.common.rescueFundsMgr.getRescueFundsVipConfig((msgData: api.UserVipLevelConfResp) => {
            if (msgData?.data?.length < 1 || !cc.isValid(this.view.uiRoot)) {
                return;
            }

            msgData.data.forEach(async (item, index) => {
                if (!item) {
                    return;
                }

                let prefab = await this.loadAsset(HallRes.prefab.rescueFunds.RescueFundsRuleItem, cc.Prefab);
                let node = cc.instantiate(prefab);
                node.zIndex = item.vipLevel;
                this.view.RC_vipInfo.addChild(node);
                node.getComponent(RescueFundsRuleItem_v)?.init(item);
            });
        });
    }

    private setChildOpacity(node: cc.Node): void {
        if (!cc.isValid(node)) {
            return;
        }

        const viewNode = this.view.RC_scContent.parent;
        const viewWorldPos = viewNode.convertToWorldSpaceAR(cc.v2(0, 0));
        this.contentScrollViewBox = new cc.Rect(viewWorldPos.x - viewNode.anchorX * viewNode.width, viewWorldPos.y - viewNode.anchorY * viewNode.height, viewNode.width, viewNode.height);

        for (let i = 0; i < node.childrenCount; i++) {
            let item = node.children[i];
            if (item.getComponent(cc.Layout)) {
                this.setChildOpacity(item);
                continue;
            }

            let box = item.getBoundingBoxToWorld();
            if (this.contentScrollViewBox.intersects(box)) {
                item.opacity = 255;
            } else {
                item.opacity = 0;
            }
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RescueFundsRuleDlg_v, `${HallViewId.RescueFundsRuleDlg}_v`)
class RescueFundsRuleDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RescueFundsRuleDlg_v, uiBase.addComponent(RescueFundsRuleDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RescueFundsRuleDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RescueFundsRuleDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(RescueFundsRuleDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RescueFundsRuleDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RescueFundsRuleDlg_v).beforeUnload();
    }
}
