import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class MemberCenterItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_value1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value3green: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value3red: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value4: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value5: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    init(data: api.CoinTransactionRecord, typeEnums: any) {
        this.RC_lab_value1.string = we.common.utils.formatDate(new Date(data.time * 1000), `${we.core.flavor.getCountryDateFormate()}\nhh:mm:ss`);
        if (data.transactionType == 9) {
            this.RC_lab_value2.string = we.core.langMgr.getLangText(HallLanguage.FLOW_RECOED_TIPS_1);
        } else {
            this.RC_lab_value2.string = typeEnums[data.transactionType];
        }
        this.RC_lab_value3green.node.active = data.isIncome;
        this.RC_lab_value3red.node.active = !data.isIncome;
        if (data.isIncome) {
            this.RC_lab_value3green.string = `+${we.common.utils.formatAmountCurrency(data.amount)}`;
        } else {
            this.RC_lab_value3red.string = `${we.common.utils.formatAmountCurrency(data.amount)}`;
        }
        this.RC_lab_value4.string = we.common.utils.formatAmountCurrency(data.beforeBalance);
        this.RC_lab_value5.string = we.common.utils.formatAmountCurrency(data.afterBalance);
    }
}
