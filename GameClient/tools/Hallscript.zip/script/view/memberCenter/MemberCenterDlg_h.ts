import { HallViewId } from '../HallViewId';
import MemberCenterItem_h from './MemberCenterItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('MemberCenterDlgView_h', we.bundles.hall)
class MemberCenterDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('MemberCenterDlg_h', we.bundles.hall)
export class MemberCenterDlg_h extends we.ui.DlgSystem<MemberCenterDlgView_h> {
    private listTypes: Record<number, any> = {};
    private listData: any[] = [];
    private listParam = {
        isRequest: false,
        isFinish: false,
    };

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderItem, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        if (this.view.RC_list.scrollView.verticalScrollBar) {
            this.view.RC_list.scrollView.verticalScrollBar.enableAutoHide = false;
        }
        this.getTransactionEnum().then(() => {
            this.getListData();
        });
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onRenderItem(node: cc.Node, index: number) {
        const item = node.addComponentUnique(MemberCenterItem_h);
        item.init(this.listData[index], this.listTypes);
        if (!this.listParam.isRequest && !this.listParam.isFinish && index + 1 >= this.listData.length) {
            this.getListData();
        }
    }

    private getListData() {
        if (this.listParam.isRequest) {
            return;
        }
        this.listParam.isRequest = true;
        we.common.apiMgr.getMemberTransactionRecord(
            {
                lastRecordTime: (this.listData[this.listData.length - 1] || {}).time || 0,
            },
            (res: api.CoinTransactionRecordResp) => {
                if (!cc.isValid(this.view.RC_list)) {
                    return;
                }
                const records = res.records || [];
                this.listData.push(...records);
                this.listParam.isRequest = false;
                this.view.RC_list.numItems = this.listData.length;
                if (records.length < 20) {
                    this.listParam.isFinish = true;
                }
            },
            () => {
                this.listParam.isRequest = false;
            }
        );
    }

    private getTransactionEnum() {
        return new Promise((resolve, reject) => {
            this.listTypes = {};
            we.common.apiMgr.getMemberTransactionEnum(null, (res: api.CoinEnumConfigResp) => {
                const coinEnums = res.coinEnums || [];
                const langCode = we.core.langMgr.getCurLangCode();
                coinEnums.forEach((item) => {
                    this.listTypes[item.id] = item.i18n[langCode] || '';
                });
                resolve(true);
            });
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(MemberCenterDlg_h, `${HallViewId.MemberCenterDlg}_h`)
class MemberCenterDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(MemberCenterDlg_h, uiBase.addComponent(MemberCenterDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MemberCenterDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<MemberCenterDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(MemberCenterDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MemberCenterDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(MemberCenterDlg_h).beforeUnload();
    }
}
