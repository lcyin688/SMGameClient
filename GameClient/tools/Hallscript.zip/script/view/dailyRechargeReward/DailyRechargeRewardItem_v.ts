import { HallEvent } from '../../config/HallEvent';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class DailyRechargeRewardItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_rechargeTotal: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_rewardCoin: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_light_anim: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_mask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_selectAnim: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_style: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private data: api.TaskProgressDetail = null;
    private isDisableReceiveClick: boolean = false;

    protected onLoad(): void {
        this.RC_selectAnim.active = false;
        this.RC_mask && (this.RC_mask.active = false);
    }

    public onReceived() {
        if (!this.data || this.isDisableReceiveClick) {
            return;
        }

        if (!we.common.dailyRechargeMgr.isOpenAct()) {
            // 过期 或 未开启
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
            cc.director.emit(HallEvent.CLOSE_DAILY_RECHARGE_VIEW);
            return;
        }

        if (this.data.taskStatus == we.common.activityMgr.TaskStatus.COMPLETED) {
            this.isDisableReceiveClick = true;
            this.getDrawTaskAwardReq();
        } else {
            if (this.data.taskStatus == we.common.activityMgr.TaskStatus.ONGOING) {
                we.common.payMgr.trackFrom = we.common.JumpCmd.Daily_Recharge;
                we.currentUI.close(HallViewId.DailyRechargeRewardDlg);
                HallMgr.openStoreDlg(this.data.target);
            }
        }
    }

    public updateData(data: api.TaskProgressDetail, level: number = 0) {
        if (!this._rc) {
            this.__initRc();
        }
        if (!data) {
            we.warn(`DailyRechargeRewardItem_v updateData, param is null`);
            return;
        }
        this.data = data;

        // 设置主题
        let comp = this.RC_style.getComponent(we.ui.WERenderStyleIndex);
        if (comp) {
            this.RC_style.getComponent(we.ui.WERenderStyleIndex).index = level;
        }

        this.RC_lab_rechargeTotal.string = we.common.utils.formatPrice(data.target, true, false);
        // 设置奖励金额
        this.RC_lab_rewardCoin.string = we.common.utils.formatAmountCurrency(data.reward);
        // 设置是否是待领奖状态
        let isCanGet = data.taskStatus == we.common.activityMgr.TaskStatus.COMPLETED;
        this.RC_selectAnim.active = isCanGet;

        if (data.taskStatus == we.common.activityMgr.TaskStatus.REWARD_RECEIVED) {
            if (this.RC_mask) {
                this.RC_mask.active = true;
            } else {
                this.RC_content.opacity = 255 * 0.3;
            }
            this.RC_light_anim.active = false;
        }
        this.isDisableReceiveClick = false;
    }

    private getDrawTaskAwardReq() {
        if (this.data?.taskStatus != we.common.activityMgr.TaskStatus.COMPLETED) {
            return;
        }

        let data = {} as api.DrawNewTaskAwardReq;
        data.level = this.data.level;
        data.taskType = we.common.activityMgr.ActivityType.recharge;
        data.typeEnum = we.common.activityMgr.TaskType.recharge;
        we.common.apiMgr.drawActivityAward(
            data,
            (data: api.DrawNewTaskAwardResp) => {
                if (data?.drawAwardStatus == 1) {
                    let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.drawAwardNum }];
                    HallMgr.openGetAwardsDlg(awardMap);

                    if (cc.isValid(this.node)) {
                        this.data.taskStatus = we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
                    }
                    we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.dailyRecharge, -1);

                    cc.director.emit(we.common.EventName.UPDATE_DAILY_RECHARGE);
                } else {
                    we.common.activityMgr.getTaskAwardErrorHandle(data?.drawAwardStatus);
                }
            },
            () => {
                if (cc.isValid(this.node)) {
                    this.isDisableReceiveClick = false;
                }
            }
        );
    }
}
