import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import DailyRechargeRewardItem_h from './DailyRechargeRewardItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('DailyRechargeRewardDlgView_h', we.bundles.hall)
class DailyRechargeRewardDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecharge: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_pro_percent: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_total: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_totalTitle: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_awards: we.ui.List = null;

    @we.ui.ccBind(cc.ProgressBar)
    public RC_progressBar: cc.ProgressBar = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('DailyRechargeRewardDlg_h', we.bundles.hall)
export class DailyRechargeRewardDlg_h extends we.ui.DlgSystem<DailyRechargeRewardDlgView_h> {
    /** 当前充值任务目标数 */
    private curTargetNum: number = 0;

    private listData: api.TaskProgressDetail[] = [];
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_lab_totalTitle.string = we.core.langMgr.getLangText(HallLanguage.TASK_TYPE_1, ':');

        this.view.cc_onBtnClick(this.view.RC_btnRecharge, we.core.Func.create(this.openStore, this));
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        cc.director.on(we.core.EventName.GAME_SHOW, this.onGameShow, this);
        cc.director.on(we.common.EventName.UPDATE_DAILY_RECHARGE, this.onRefreshUI, this);
        cc.director.on(HallEvent.CLOSE_DAILY_RECHARGE_VIEW, this.onCloseDlg, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        if (!we.common.activityMgr.todayNoPropDailyRecharge) {
            we.common.activityMgr.todayNoPropDailyRecharge = true;
            we.common.storage.setById('common', 'no_prop_daily_recharge', true);
        }

        await we.common.dailyRechargeMgr.getActivityInfo();
        this.onRefreshUI();
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Daily_Recharge);
    }

    public beforeUnload() {}

    protected destroy(): void {
        cc.director.off(we.common.EventName.UPDATE_DAILY_RECHARGE, this.onRefreshUI, this);
        cc.director.off(we.core.EventName.GAME_SHOW, this.onGameShow, this);
        cc.director.off(HallEvent.CLOSE_DAILY_RECHARGE_VIEW, this.onCloseDlg, this);
    }

    private openStore(): void {
        if (!we.common.dailyRechargeMgr.isOpenAct()) {
            // 过期 或 未开启
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
            this.onCloseDlg();
            return;
        }

        we.common.payMgr.trackFrom = we.common.JumpCmd.Daily_Recharge;
        HallMgr.openStoreDlg(this.curTargetNum);
    }

    private onCloseDlg() {
        this.closeView();
    }

    private onGameShow(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        this.onRefreshUI();
    }

    private onRefreshUI(): void {
        if (!we.common.dailyRechargeMgr.isOpenAct()) {
            we.commonUI.showConfirm({
                content: we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7),
                yesHandler: we.core.Func.create(() => {
                    if (cc.isValid(this.view.uiRoot)) {
                        this.onCloseDlg();
                    }
                }, this),
            });
            return;
        }

        let data = we.common.dailyRechargeMgr.actInfo;
        this.listData = data.recharge || [];
        if (this.listData.length < 1) {
            return;
        }

        let startMs = data.startTime * 1000;
        let endMs = data.endTime * 1000;
        let start = we.common.utils.formatDate(new Date(startMs), 'DD/MM hh:mm');
        let end = we.common.utils.formatDate(new Date(endMs), 'DD/MM hh:mm');
        this.view.RC_lab_time.string = start + ' - ' + end;

        let progress: number = 1; // 当前进度
        this.view.RC_lab_total.string = we.common.utils.formatPrice(this.listData[this.listData.length - 1]?.target, false, false);
        for (const item of this.listData) {
            if (item?.taskStatus == we.common.activityMgr.TaskStatus.ONGOING) {
                this.curTargetNum = item.target;
                progress = item.progress / item.target;
                this.view.RC_lab_total.string = we.common.utils.formatPrice(item.progress, false, false);
                break;
            }
        }
        this.view.RC_progressBar.progress = progress;

        let percent = Math.floor(progress * 100);
        this.view.RC_lab_pro_percent.node.active = percent > 0;
        this.view.RC_lab_pro_percent.string = percent + '%';

        this.showListUi();
    }

    private showListUi() {
        this.view.RC_list_awards.node.on(
            'update-item',
            (item: cc.Node, i: number) => {
                const data = this.listData[i];
                const comp = item.getComponent(DailyRechargeRewardItem_h);
                comp.updateData(data, i);
            },
            this
        );

        this.view.RC_list_awards.node.on(
            'select-item',
            async (item: cc.Node, i: number) => {
                const comp = item.getComponent(DailyRechargeRewardItem_h);
                comp.onReceived();

                await this.scheduleOnce(1);

                const data = this.listData[i];
                if (data.taskStatus != we.common.activityMgr.TaskStatus.COMPLETED) {
                    return;
                }
                // 移动到当前能领奖的位置
                let isCanAwardIndex = this.listData.findIndex((item) => {
                    return item?.taskStatus == we.common.activityMgr.TaskStatus.COMPLETED;
                });
                if (isCanAwardIndex == -1) {
                    return;
                }
                this.view.RC_list_awards.scrollTo(isCanAwardIndex, 1);
            },
            this
        );

        this.view.RC_list_awards.numItems = this.listData.length;

        // 移动到当前能领奖的位置
        let isCanAwardIndex = this.listData.findIndex((item) => {
            return item?.taskStatus == we.common.activityMgr.TaskStatus.COMPLETED;
        });
        this.view.RC_list_awards.scrollTo(isCanAwardIndex, 1);
        // 单元格不足以铺满列表，居中显示
        const scroll = this.view.RC_list_awards.node.getComponent(cc.ScrollView);
        if (scroll.content.width < scroll.node.width) {
            this.view.RC_list_awards.node.opacity = 0;
            this.scheduleOnce(0).then(() => {
                const lay = scroll.content.getComponent(cc.Layout);
                scroll.content.anchorX = 0.5;
                scroll.content.x = -lay.paddingLeft / 2;
                this.view.RC_list_awards.node.opacity = 255;
            });
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(DailyRechargeRewardDlg_h, `${HallViewId.DailyRechargeRewardDlg}_h`)
class DailyRechargeRewardDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(DailyRechargeRewardDlg_h, uiBase.addComponent(DailyRechargeRewardDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DailyRechargeRewardDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<DailyRechargeRewardDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(DailyRechargeRewardDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DailyRechargeRewardDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(DailyRechargeRewardDlg_h).beforeUnload();
    }
}
