import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('UserCenterRealNameDlgView_v', we.bundles.hall)
class UserCenterRealNameDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_ktp: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_name: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_phone: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_way: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ktp: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phoneCode: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_wayTitle: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Toggle)
    public RC_toggle_waySelect: cc.Toggle = null;

    @we.ui.ccBind(cc.Node)
    public RC_WayToggle: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_ruleBtn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_saveBtn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_wayDown: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_wayIcon: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_waySelectMask: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

enum WayType {
    Phone = 1,
    WathsApp = 2,
    Telegram = 3,
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('UserCenterRealNameDlg_v', we.bundles.hall)
export class UserCenterRealNameDlg_v extends we.ui.DlgSystem<UserCenterRealNameDlgView_v> {
    wayList = [
        { title: we.core.langMgr.getLangText(we.common.lang.VER_WHATSAPP), type: WayType.WathsApp },
        { title: 'Telegram', type: WayType.Telegram },
    ];
    wayIndex = 0;
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_toggle_waySelect.node.on('toggle', this.onToggleWaySelect, this);
        // 事件监听
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_ruleBtn, we.core.Func.create(this.onClickRuleBtn, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_waySelectMask, we.core.Func.create(this.onClickWaySelectMask, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_saveBtn, we.core.Func.create(this.onClickSaveBtn, this)).setSleepTime(0.5);

        // 输入框
        // name
        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'editingDidBegan', we.core.Func.create(this.onNameInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'textChanged', we.core.Func.create(this.onNameInputChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_name.node, 'editingDidEnded', we.core.Func.create(this.onNameInputEnd, this));
        // ktp
        this.view.cc_onEditBoxEvent(this.view.RC_edit_ktp.node, 'editingDidBegan', we.core.Func.create(this.onKTPInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_ktp.node, 'textChanged', we.core.Func.create(this.onKTPInputChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_ktp.node, 'editingDidEnded', we.core.Func.create(this.onKTPInputEnd, this));
        // phone
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidBegan', we.core.Func.create(this.onPhoneInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'textChanged', we.core.Func.create(this.onPhoneInputChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidEnded', we.core.Func.create(this.onPhoneInputEnd, this));
        // way
        this.view.cc_onEditBoxEvent(this.view.RC_edit_way.node, 'editingDidBegan', we.core.Func.create(this.onWayInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_way.node, 'textChanged', we.core.Func.create(this.onWayInputChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_way.node, 'editingDidEnded', we.core.Func.create(this.onWayInputEnd, this));

        // 下拉选择框
        this.view.RC_WayToggle.addComponentUnique(we.ui.WEToggleGroup)
            .setGroupMode(we.ui.ToggleGroupMode.SingleOne)
            .onListener(
                we.core.Func.create((_: number, isChecked: boolean, index: number) => {
                    if (isChecked) {
                        this.onToggleWayChange(index);
                    }
                }, this)
            );

        // 初始化
        we.common.userMgr.getRealNameData(we.core.Func.create(this.initUI, this));
        this.initUI();
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lab_ktp.string = this.getLangCountryText(HallLanguage.REAL_INFORMATION_LABEL_16);
        this.view.RC_edit_ktp.placeholderLabel.string = this.getLangCountryText(HallLanguage.REAL_INFORMATION_LABEL_17);
        this.view.RC_lab_phoneCode.string = `+${we.core.flavor.getCountryNum()} `;
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    public initUI() {
        const realNameData = we.common.userMgr.realName;
        if (!realNameData) {
            return;
        }

        this.view.RC_edit_ktp.maxLength = we.common.userMgr.getRealNameKTPLength();

        this.view.RC_edit_name.string = realNameData.name;
        this.view.RC_edit_ktp.string = realNameData.account;

        const userContact = this.getDefaultWay();
        if (userContact) {
            this.wayList.forEach((item, index) => {
                // 设置默认选项
                if (item.type === userContact.type) {
                    this.wayIndex = index;
                }
            });
        }
        this.getPhoneNumber();
        this.view.RC_toggle_waySelect.isChecked = true;
        this.view.RC_WayToggle.addComponentUnique(we.ui.WEToggleGroup).setToggleStatus(this.wayIndex, true);
        this.onToggleWayChange(this.wayIndex);
    }

    public getLangCountryText(langCode: string) {
        const [_, keyName] = (langCode || '').split('/');
        if (!keyName) {
            return '';
        }
        const arr = keyName.split('_');
        const countryCode = we.core.flavor.getCountryCode().toLocaleUpperCase();
        arr.splice(arr.length - 1, 0, countryCode);
        if (HallLanguage[arr.join('_')]) {
            return we.core.langMgr.getLangText(HallLanguage[arr.join('_')]);
        }
        return we.core.langMgr.getLangText(langCode);
    }

    public getPhoneNumber() {
        const contact = (we.common.userMgr.realName.userContacts || []).find((item) => {
            return item.type === WayType.Phone;
        });
        if (contact) {
            this.view.RC_edit_phone.string = contact.value.replace(`+${we.core.flavor.getCountryNum()}`, '');
            return this.view.RC_edit_phone.string;
        }
        return '';
    }

    public getDefaultWay() {
        let userContacts = (we.common.userMgr.realName.userContacts || []).filter((item) => {
            return item.type !== WayType.Phone;
        });
        // 找到最近更新的方式
        userContacts = userContacts.sort((item1, item2) => {
            return item2.updatedAt - item1.updatedAt;
        });

        let userContact = userContacts[0];
        // 相同更新时间，优先选择WathsApp
        if (userContacts[1] && userContacts[0].updatedAt === userContacts[1].updatedAt && userContacts[1].type === WayType.WathsApp) {
            userContact = userContacts[1];
        }
        return userContact || null;
    }

    public onToggleWaySelect() {
        this.view.RCN_wayDown.angle = this.view.RC_toggle_waySelect.isChecked ? 180 : 0;
    }

    public onToggleWayChange(toggle: number | cc.Toggle) {
        let index = 0;
        if (toggle instanceof cc.Toggle) {
            index = Number(toggle.node.name.replace('toggle', ''));
        } else {
            index = Number(toggle);
        }
        this.view.RCN_wayIcon.getComponent(we.ui.WESpriteIndex).index = index;
        this.view.RC_lab_wayTitle.string = this.wayList[index].title;
        this.wayIndex = index;
        this.view.RC_edit_way.maxLength = this.wayList[index].type === WayType.Phone ? 14 : 20;
        const concat = we.common.userMgr.realName.userContacts.find((item) => {
            return item.type === this.wayList[this.wayIndex].type;
        });
        if (concat) {
            this.view.RC_edit_way.string = concat.value.replace(`+${we.core.flavor.getCountryNum()}`, '');
        } else {
            this.view.RC_edit_way.string = '';
        }
        this.onClickWaySelectMask();
    }

    public onClickWaySelectMask() {
        this.view.RC_toggle_waySelect.isChecked = false;
        this.onToggleWaySelect();
    }

    public onClickRuleBtn() {
        we.currentUI.show(HallViewId.UserCenterRealNameRuleDlg);
    }

    public filterName(value: string) {
        return value.replace(/[^A-Za-z0-9\s_]/g, '');
    }

    public onNameInputStart(): void {
        this.view.RC_edit_name.placeholderLabel.string = ``;
    }

    public onNameInputChanged(value: string, editBox: cc.EditBox): void {
        const val = this.filterName(value);
        editBox.string = val;
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = val;
        }
    }

    public onNameInputEnd(): void {
        if (this.view.RC_edit_name.string == '') {
            this.view.RC_edit_name.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.REAL_INFORMATION_LABEL_5);
        }
    }

    public onKTPInputStart(): void {
        this.view.RC_edit_ktp.placeholderLabel.string = ``;
    }

    public onKTPInputChanged(value: string, editBox: cc.EditBox): void {
        const val = value.replace(/[^0-9]/g, '');
        editBox.string = val;
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = val;
        }
    }

    public onKTPInputEnd(): void {
        if (this.view.RC_edit_ktp.string == '') {
            this.view.RC_edit_ktp.placeholderLabel.string = this.getLangCountryText(HallLanguage.REAL_INFORMATION_LABEL_17);
        }
    }

    public onPhoneInputStart(): void {
        this.view.RC_edit_phone.placeholderLabel.string = ``;
    }

    public onPhoneInputChanged(value: string, editBox: cc.EditBox): void {
        let val = value.replace(/[^0-9]/g, '');
        editBox.string = val;
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = val;
        }
    }

    public onPhoneInputEnd(): void {
        if (this.view.RC_edit_phone.string == '') {
            this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(we.common.lang.LOGIN_FORGETFRAME_ENTER1_TIPS);
        }
    }

    public onWayInputStart(): void {
        this.view.RC_edit_way.placeholderLabel.string = ``;
    }

    public onWayInputChanged(value: string, editBox: cc.EditBox): void {
        let val = value.replace(/[^A-Za-z0-9]/g, '');
        editBox.string = val;
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = val;
        }
    }

    public onWayInputEnd(): void {
        if (this.view.RC_edit_way.string == '') {
            this.view.RC_edit_way.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.REAL_INFORMATION_LABEL_8);
        }
    }

    public onClickSaveBtn() {
        const name = this.filterName(this.view.RC_edit_name.string).trim();
        if (!name) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.REAL_INFORMATION_LABEL_5));
            return;
        }
        let phone = this.view.RC_edit_phone.string;
        if (!we.common.utils.isPhoneNumber(phone)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.LOGIN_PHONENM_WRONGNM));
            return;
        }
        phone = `+${we.core.flavor.getCountryNum()}${phone}`;
        const wayNum = this.view.RC_edit_way.string;
        if (!wayNum) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.REAL_INFORMATION_LABEL_8));
            return;
        }
        const ktp = this.view.RC_edit_ktp.string;
        if (!ktp) {
            we.commonUI.showToast(this.getLangCountryText(HallLanguage.REAL_INFORMATION_LABEL_17));
            return;
        }

        if (!we.common.userMgr.isRealNameKTP(ktp)) {
            we.commonUI.showToast(this.getLangCountryText(HallLanguage.REAL_INFORMATION_LABEL_18));
            return;
        }

        const params = {
            account: ktp,
            name,
            userContacts: [
                {
                    type: WayType.Phone,
                    value: phone,
                    updatedAt: 0,
                },
                {
                    type: this.wayList[this.wayIndex].type,
                    value: wayNum,
                    updatedAt: 0,
                },
            ],
        };

        we.common.userMgr.updateRealNameData(
            params,
            we.core.Func.create(() => {
                cc.director.emit(we.common.EventName.UPDATE_USER_INFO_SHOW);
                this.closeView();
            }, this)
        );
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(UserCenterRealNameDlg_v, `${HallViewId.UserCenterRealNameDlg}_v`)
class UserCenterRealNameDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(UserCenterRealNameDlg_v, uiBase.addComponent(UserCenterRealNameDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterRealNameDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<UserCenterRealNameDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(UserCenterRealNameDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterRealNameDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(UserCenterRealNameDlg_v).beforeUnload();
    }
}
