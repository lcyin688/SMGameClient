const { ccclass, property } = cc._decorator;

@ccclass
export default class UserCenterLangSelectItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_text1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_text2: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(key: string) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        const str = we.core.langMgr.getLangText(key);
        this.RC_lab_text1.string = str;
        this.RC_lab_text2.string = str;
    }
}
