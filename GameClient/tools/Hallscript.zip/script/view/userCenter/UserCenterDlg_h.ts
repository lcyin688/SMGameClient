import { HallRes } from '../../config/HallRes';
import HallSkin from '../../config/HallSkin';
import { HallPageEnum } from '../../const/HallConst';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('UserCenterDlgView_h', we.bundles.hall)
class UserCenterDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_balance: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bindEmailAwardLb: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bindPhoneAwardLb: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_email: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phone: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_realName: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_userId: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_version: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vipLv: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_langBox: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_realName: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_head: cc.Sprite = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vipIcon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bindEmail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bindPhone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnAdd: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnBindEmail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnBindPhone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnChange: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnChangePwdEmail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnChangePwdPhone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnCopy: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnLogout: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnVip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_email: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_emailBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_modify_head: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phoneBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_toggleEffect: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_toggleMusic: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_unBindEmail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_unBindPhone: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('UserCenterDlg_h', we.bundles.hall)
export class UserCenterDlg_h extends we.ui.DlgSystem<UserCenterDlgView_h> {
    private isOpenBgMuisc: boolean = true;
    private isOpenSound: boolean = true;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_btnCopy, we.core.Func.create(this.onCopyId, this));
        this.view.cc_onBtnClick(this.view.RCN_btnAdd, we.core.Func.create(this.onClickAdd, this));
        this.view.cc_onBtnClick(this.view.RCN_modify_head, we.core.Func.create(this.onClickChangeUserInfo, this));
        this.view.cc_onBtnClick(this.view.RCN_btnChange, we.core.Func.create(this.onClickChangeUserInfo, this));
        this.view.cc_onBtnClick(this.view.RCN_btnBindPhone, we.core.Func.create(this.onClickBind, this));
        this.view.cc_onBtnClick(this.view.RCN_btnBindEmail, we.core.Func.create(this.onClickBind, this));
        this.view.cc_onBtnClick(this.view.RCN_btnVip, we.core.Func.create(this.onClickVip, this));
        this.view.cc_onBtnClick(this.view.RCN_btnChangePwdPhone, we.core.Func.create(this.onClickChangePwd, this));
        this.view.cc_onBtnClick(this.view.RCN_btnChangePwdEmail, we.core.Func.create(this.onClickChangePwd, this));
        this.view.cc_onBtnClick(this.view.RCN_toggleMusic, we.core.Func.create(this.onClickMusic, this));
        this.view.cc_onBtnClick(this.view.RCN_toggleEffect, we.core.Func.create(this.onClickEffect, this));
        this.view.cc_onBtnClick(this.view.RCN_btnLogout, we.core.Func.create(this.onClickLogout, this));
        this.view.cc_onBtnClick(this.view.RC_realName, we.core.Func.create(this.onClickRealName, this));

        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lab_version.string = we.core.gameConfig.getGameVersion();
        this.isOpenBgMuisc = we.core.audioMgr.isMusicOpen();
        this.isOpenSound = we.core.audioMgr.isEffectOpen();
        this.view.RCN_toggleMusic.getComponent(we.ui.WEToggle).isChecked = this.isOpenBgMuisc;
        this.view.RCN_toggleEffect.getComponent(we.ui.WEToggle).isChecked = this.isOpenSound;

        if (cc.isValid(this.view.RC_langBox)) {
            const langList = we.core.flavor.getLangList();
            this.view.RC_langBox.active = langList.length > 1;
        }

        this.setUserInfo();
    }

    /** 隐藏窗口 */
    public async destroy() {
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);
    }

    public beforeUnload() {}

    /** 复制id */
    private onCopyId(event): void {
        we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.COMMON_COPY_COMPLETE));

        we.core.nativeUtil.copyText('' + we.common.userMgr.userInfo.userId);
    }

    /** 充值 */
    private onClickAdd(event): void {
        this.closeView();
        we.currentUI.getDlg(HallViewId.HallDlg).onShow(HallPageEnum.shop);
    }

    private onClickChangeUserInfo(event) {
        if (we.common.userMgr.isFormal()) {
            we.common.apiMgr.getAvatarHistory((data: api.AvatarHistoryResp) => {
                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }
                this.userCenterSelectAvatar(this.view.uiRoot, data.avatars);
            }, null);
        } else {
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
        }
    }

    private onClickVip(event): void {
        we.currentUI.show(HallViewId.VipViewDlg);
    }

    private onClickBind(event: cc.Event): void {
        we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg, 0, null, event.target === this.view.RCN_btnBindEmail);
    }

    private onClickChangePwd(event) {
        we.currentUI.show(HallViewId.PhoneBindScreenshotPromptDlg, null, false);
    }

    private onUpdateUserInfo(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        this.setUserInfo();
    }

    private setUserInfo(): void {
        // 头像
        const bUseClipCircle = HallSkin.config.headIcon_useClipCircle;
        we.common.utils.setAvatarSprite(this.view.RC_spr_head, we.common.userMgr.userInfo.avatar, we.common.userMgr.userInfo.gender, bUseClipCircle);
        this.view.RC_lab_vipLv.string = 'VIP' + we.common.userMgr.vipExp.level;
        // 设置玩家充值VIP等级图片
        if (we.common.userMgr.vipExp && cc.isValid(this.view.RC_spr_vipIcon)) {
            let path = HallRes.texture.VIP_Logo_icon + we.common.userMgr.vipExp.level;
            we.common.utils.setComponentSprite(this.view.RC_spr_vipIcon, path);
        }

        this.view.RC_lab_balance.string = we.common.utils.formatAmountCurrency(we.common.userMgr.userInfo.gold);
        this.view.RC_lab_userId.string = we.common.userMgr.userInfo.userId + '';

        this.view.RC_lab_name.string = we.common.userMgr.userInfo.userName;
        // 设置手机绑定
        const phoneBound = we.common.userMgr.userInfo.phone.length > 0;
        const emailBound = we.common.userMgr.userInfo.emailAccount.length > 0;
        const phoneEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Phone);
        const emailEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Email);
        this.view.RCN_bindPhone.active = phoneBound;
        this.view.RCN_unBindPhone.active = !phoneBound;
        this.view.RCN_bindEmail.active = emailBound;
        this.view.RCN_unBindEmail.active = !emailBound;
        this.view.RCN_phone.active = phoneEnabled;
        this.view.RCN_email.active = emailEnabled;
        if (phoneBound) {
            this.view.RC_lab_phone.string = we.common.userMgr.userInfo.phone;
            this.view.RCN_phoneBg.active = true;
        } else {
            let award = we.core.projectConfig.settingsConfig.phoneBindReward[0];
            if (award && !emailBound) {
                this.view.RC_lab_bindPhoneAwardLb.node.active = award > 0;
                this.view.RC_lab_bindPhoneAwardLb.string = `+${we.common.utils.formatAmountCurrency(award)}`;
                this.view.RCN_phoneBg.active = true;
            } else {
                this.view.RC_lab_bindPhoneAwardLb.node.active = false;
                this.view.RCN_phoneBg.active = false;
            }
        }
        if (emailBound) {
            this.view.RC_lab_email.string = we.common.userMgr.userInfo.emailAccount;
            this.view.RCN_emailBg.active = true;
        } else {
            let award = we.core.projectConfig.settingsConfig.phoneBindReward[0];
            if (award && !phoneBound) {
                this.view.RC_lab_bindEmailAwardLb.node.active = award > 0;
                this.view.RC_lab_bindEmailAwardLb.string = `+${we.common.utils.formatAmountCurrency(award)}`;
                this.view.RCN_emailBg.active = true;
            } else {
                this.view.RC_lab_bindEmailAwardLb.node.active = false;
                this.view.RCN_emailBg.active = false;
            }
        }

        // 实名验证
        if (we.common.userMgr.realName) {
            this.setRealNameInfo();
        } else {
            we.common.userMgr.getRealNameData(we.core.Func.create(this.setRealNameInfo, this));
        }
    }

    private setRealNameInfo(): void {
        // 实名验证
        const labelLimit = this.view.RC_lab_realName.node.addComponentUnique(we.ui.WELabelLongLimit);
        labelLimit.bUpdate = true;

        this.view.RC_lab_realName.string = we.common.userMgr.realName?.name || we.core.langMgr.getLangText(HallLanguage.REAL_INFORMATION_LABEL_1);
        this.scheduleOnce(0.2).then(() => {
            labelLimit.onMessageSizeChanged();
        });
    }

    /**
     * 个人中心修改头像
     * @param parentNode 父节点
     * @param avatars 数据
     */
    private userCenterSelectAvatar(parentNode: cc.Node, avatars: string[]) {
        we.currentUI.showSafe(HallViewId.UserCenterSelectAvatarDlg, avatars);
    }

    /** 音乐音效 总开关点击 */
    private onClickMusic(): void {
        this.isOpenBgMuisc = !this.isOpenBgMuisc;
        this.view.RCN_toggleMusic.getComponent(we.ui.WEToggle).isChecked = this.isOpenBgMuisc;

        we.core.audioMgr.setMusicOpen(this.isOpenBgMuisc);
    }

    /** 音乐音效 总开关点击 */
    private onClickEffect(): void {
        this.isOpenSound = !this.isOpenSound;
        this.view.RCN_toggleEffect.getComponent(we.ui.WEToggle).isChecked = this.isOpenSound;

        we.core.audioMgr.setEffectOpen(this.isOpenSound);
    }

    private onClickLogout(event): void {
        if (we.common.userMgr.isFormal()) {
            we.currentUI.show(HallViewId.PhoneBindScreenshotPromptDlg, null, false, () => {
                we.common.userMgr.exitLogin(true);
            });
        } else {
            we.common.userMgr.exitLogin(true);
        }
    }

    /**
     * 点击实名认证
     */
    private onClickRealName() {
        we.currentUI.show(HallViewId.UserCenterRealNameDlg);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(UserCenterDlg_h, `${HallViewId.UserCenterDlg}_h`)
class UserCenterDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(UserCenterDlg_h, uiBase.addComponent(UserCenterDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<UserCenterDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(UserCenterDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(UserCenterDlg_h).beforeUnload();
    }
}
