import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('UserCenterSettingDlgView_v', we.bundles.hall)
class UserCenterSettingDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_version: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnLogout: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_effectOff: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_effectOn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_effectSwitchItem: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_languageChoose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_languageCtl: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_languageTitle: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_languageValue: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_musicOff: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_musicOn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_musicSwitchItem: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('UserCenterSettingDlg_v', we.bundles.hall)
export class UserCenterSettingDlg_v extends we.ui.DlgSystem<UserCenterSettingDlgView_v> {
    private isOpenBgMusic: boolean = true;
    private isOpenSound: boolean = true;

    /** 注册UI事件 */
    public async registerUIEvent() {
        // 按钮事件
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_btnLogout, we.core.Func.create(this.onClickLogout, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_musicSwitchItem, we.core.Func.create(this.onClickMusic, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_effectSwitchItem, we.core.Func.create(this.onClickEffect, this)).setSleepTime(0.5);
        // // 下拉选择（未完成、下个版本才正式开发）
        // const dropdown = this.view.RC_languageCtl.addComponentUnique(we.ui.WEDropdown);
        // dropdown.setSelectedEvent(
        //     we.core.Func.create((itemData, itemNode, oldNode) => {
        //         if (oldNode) {
        //             oldNode.children[1].active = false;
        //         }
        //         itemNode.children[1].active = true;
        //         // 直接重新登陆，以切换所有多语言
        //         we.core.langMgr.switchLang(itemData.value);
        //     }, this)
        // );
        // dropdown.setItems([
        //     { desc: 'English', value: we.core.LangCode.en },
        //     { desc: 'IdLanguage', value: we.core.LangCode.id },
        // ]);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lab_version.string = we.core.gameConfig.getGameVersion();
        this.isOpenBgMusic = we.core.audioMgr.isMusicOpen();
        this.isOpenSound = we.core.audioMgr.isEffectOpen();
        this.view.RCN_musicOff.active = !this.isOpenBgMusic;
        this.view.RCN_musicOn.active = this.isOpenBgMusic;
        this.view.RCN_effectOff.active = !this.isOpenSound;
        this.view.RCN_effectOn.active = this.isOpenSound;
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onClickLogout(event): void {
        if (we.common.userMgr.isFormal()) {
            we.currentUI.show(HallViewId.PhoneBindScreenshotPromptDlg, null, false, () => {
                we.common.userMgr.exitLogin(true);
            });
        } else {
            we.common.userMgr.exitLogin(true);
        }
        this.closeView();
    }

    /** 音乐音效 总开关点击 */
    private onClickMusic(): void {
        this.isOpenBgMusic = !this.isOpenBgMusic;
        this.view.RCN_musicOff.active = !this.isOpenBgMusic;
        this.view.RCN_musicOn.active = this.isOpenBgMusic;

        we.core.audioMgr.setMusicOpen(this.isOpenBgMusic);
    }

    /** 音乐音效 总开关点击 */
    private onClickEffect(): void {
        this.isOpenSound = !this.isOpenSound;
        this.view.RCN_effectOff.active = !this.isOpenSound;
        this.view.RCN_effectOn.active = this.isOpenSound;

        we.core.audioMgr.setEffectOpen(this.isOpenSound);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(UserCenterSettingDlg_v, `${HallViewId.UserCenterSettingDlg}_v`)
class UserCenterSettingDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(UserCenterSettingDlg_v, uiBase.addComponent(UserCenterSettingDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterSettingDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<UserCenterSettingDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(UserCenterSettingDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterSettingDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(UserCenterSettingDlg_v).beforeUnload();
    }
}
