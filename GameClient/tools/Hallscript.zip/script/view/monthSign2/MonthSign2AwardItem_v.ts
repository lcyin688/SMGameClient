import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import MonthSign from '../../manager/MonthSignMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class MonthSign2AwardItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_bg: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnArea: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_check: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_effect: cc.Node = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_icon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_days: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_received: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_mask: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property({ type: [cc.Color], tooltip: CC_DEV && '已领取颜色组' })
    colors_received: cc.Color[] = [];

    @property({ type: [cc.Color], tooltip: CC_DEV && '可领取颜色组' })
    colors_can: cc.Color[] = [];

    index: number;

    data: api.CumulativeSignInAwardConf = null;

    protected onLoad(): void {
        this.onBtnClick(this.RC_btnArea, we.core.Func.create(this.onClick, this));
    }

    updateData(index: number) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.index = index;

        const data = MonthSign.month2.getData();
        if (!data) {
            return;
        }

        const info = data.cumulativeSignInAwardConf[index];

        if (!info) {
            return;
        }

        this.data = info;
        this.RC_lab_days.string = info.count + '';
        this.RC_lab_value.string = we.common.utils.formatAmount(info.award, false);

        // 是否已经领取
        const isReceived = info.awardStatus == MonthSign.m_cumulativeStatus.CUMULATIVE_CLAIMED;
        this.RC_received.active = isReceived ? true : false;
        // icon
        const iconIndex = index >= 3 ? 3 : index;
        this.RC_icon.index = isReceived ? iconIndex : iconIndex + 4;
        // value color
        if (this.RC_lab_value.node.getComponent(we.ui.WEColorAssembler)) {
            this.RC_lab_value.node.getComponent(we.ui.WEColorAssembler).colors = isReceived ? this.colors_received : this.colors_can;
        }
        // 是否可领取
        const isCanReceive = info.awardStatus == MonthSign.m_cumulativeStatus.CUMULATIVE_CAN_CLAIM;
        this.RC_effect.active = isCanReceive ? true : false;
        this.RC_check.active = isCanReceive ? true : false;
        this.RC_btnArea.active = isReceived ? false : true;
        if (this.RC_mask) {
            this.RC_mask.active = isReceived ? true : false;
        }
        // 无法领取
        const isNo = info.awardStatus == MonthSign.m_cumulativeStatus.CUMULATIVE_NOT_FINISHED;
        this.RC_bg.index = isNo ? 0 : 1;

        this.breath(this.RC_check, 0.85, 1.15);
    }

    public circleRotation(target: cc.Node, duration: number, clockwise: boolean = true) {
        if (!target) {
            return null;
        }
        const angle = clockwise ? -360 : 360;
        this.tween(target).by(duration, { angle: angle }, { easing: 'linear' }).repeatForever().start();
    }

    /** 呼吸动画 */
    public breath(target: cc.Node, min = 0.9, max = 1.1) {
        if (!target) {
            return null;
        }
        this.tween(target).to(0.6, { scale: max }).to(0.6, { scale: min }).union().repeatForever().start();
    }

    async onClick() {
        const data = MonthSign.month2.getData();
        if (data.userCumulativeSignInRechargeAmount < this.data.needRecharge) {
            let value = we.common.utils.formatPrice(this.data.needRecharge, false, false);
            let text = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_9, value);
            we.commonUI.showToast(text);
            return;
        }

        this.RC_btnArea.active = false;
        const awards = await MonthSign.month2.getAccumulateReward(this.data.count);
        if (!awards || awards.award <= 0) {
            this.updateData(this.index);
            return;
        }
        // 领取奖励
        const awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: awards.award }];
        HallMgr.openGetAwardsDlg(awardMap);
        cc.director.emit(HallEvent.MONTH_SIGN_AWARD_UPDATE_DATA);
    }
}
