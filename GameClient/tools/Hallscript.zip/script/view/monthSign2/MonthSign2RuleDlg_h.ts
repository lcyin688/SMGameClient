import { HallLanguage } from '../../const/HallLanguage';
import MonthSign from '../../manager/MonthSignMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('MonthSign2RuleDlgView_h', we.bundles.hall)
class MonthSign2RuleDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_item: cc.Node = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_1: cc.RichText = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_2: cc.RichText = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_list: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('MonthSign2RuleDlg_h', we.bundles.hall)
export class MonthSign2RuleDlg_h extends we.ui.DlgSystem<MonthSign2RuleDlgView_h> {
    public async registerUIEvent() {
        this.view.RC_item.active = false;
        this.view.cc_onBtnClick(this.view.RCN_close, we.core.Func.create(this.closeView, this));
    }

    /** 注册UI事件 */
    public async onShow(showData?: any) {
        const data = MonthSign.month2.getData();

        if (!data) {
            return;
        }

        const value = data.rechargeMultiplierConf?.rechargeThreshold || 0;
        this.view.RC_rich_1.string = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_RULE_6, we.common.utils.formatPrice(value, false, false));

        const value2 = data.cumulativeSignInAwardConf[0]?.needRecharge || 0;
        this.view.RC_rich_2.string = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_RULE_7, we.common.utils.formatPrice(value2, false, false));

        const arr = data.reSignInConf?.rechargeReplenishmentDetail || [];
        if (!arr || arr.length == 0) {
            this.view.RCN_list.active = false;
            return;
        }

        for (let i = 0; i < arr.length; i++) {
            const db = arr[i];
            const item = cc.instantiate(this.view.RC_item);
            item.x = 0;
            item.name = 'item_' + i;
            item.active = true;
            item.getChildByPath('value/lable').getComponent(cc.Label).string = we.common.utils.formatPrice(db.needRecharge, false, false);
            item.getChildByPath('amount/lable').getComponent(cc.Label).string = db.replenishmentTimes + '';
            this.view.RCN_list.addChild(item);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(MonthSign2RuleDlg_h, `${HallViewId.MonthSign2RuleDlg}_h`)
class MonthSign2RuleDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(MonthSign2RuleDlg_h, uiBase.addComponent(MonthSign2RuleDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSign2RuleDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<MonthSign2RuleDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(MonthSign2RuleDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSign2RuleDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(MonthSign2RuleDlg_h).beforeUnload();
    }
}
