import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import MonthSign from '../../manager/MonthSignMgr';
import { HallViewId } from '../HallViewId';
import MonthSignAwardItem_v from './MonthSign2AwardItem_v';
import MonthSignItem_v from './MonthSign2Item_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('MonthSign2DlgView_v', we.bundles.hall)
class MonthSign2DlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_bar: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_bottom: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_desc: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_bar: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_tip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnHelp: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnWarn: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('MonthSign2Dlg_v', we.bundles.hall)
export class MonthSign2Dlg_v extends we.ui.DlgSystem<MonthSign2DlgView_v> {
    /** Tip隐藏时间 */
    private hideTipTime: number = 0;

    /** 累计奖励 */
    private nodeAwards: MonthSignAwardItem_v[] = [];

    /** 数据 */
    data: api.NewSignInConfResp = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.setAutoHideTip();

        this.view.RC_list.updateRate = 0;
        this.view.RC_list.frameByFrameRenderNum = 4;
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));

        this.view.cc_onBtnClick(this.view.RCN_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_btnHelp, we.core.Func.create(this.onClickRule, this));
        this.view.cc_onBtnClick(this.view.RCN_btnWarn, we.core.Func.create(this.onClickWarn, this));

        cc.director.on(HallEvent.MONTH_SIGN_AWARD_UPDATE_DATA, this.updateData, this);
        cc.director.on(we.common.EventName.UPDATE_MONTH_MONTH_SIGN, this.updateData, this);
    }

    protected destroy(): void {
        cc.director.off(HallEvent.MONTH_SIGN_AWARD_UPDATE_DATA, this.updateData, this);
        cc.director.off(we.common.EventName.UPDATE_MONTH_MONTH_SIGN, this.updateData, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        await MonthSign.month2.asyncData();
        this.data = MonthSign.month2.getData();
    }

    public async onShowAnimation() {
        if (!this.data) {
            return;
        }
        this.view.RC_list.numItems = this.data.dailySignInAwardConf.length || 0;

        await this.scheduleOnce(0.45);

        const data = this.data.dailySignInAwardConf.findLast((v) => {
            return v.awardStatus === MonthSign.m_status.DAILY_CAN_CLAIM;
        });

        if (data) {
            this.view.RC_list.scrollTo(data.day - 1 > 28 ? 27 : data.day - 1);
        }
    }

    /** 刷新数据 */
    private async updateData(isInit: boolean = false) {
        const data = MonthSign.month2.getData();
        this.data = data;

        if (we.currentUI.isViewVisible(HallViewId.MonthSign2RuleDlg)) {
            we.currentUI.close(HallViewId.MonthSign2RuleDlg);
        }
        if (we.currentUI.isViewVisible(HallViewId.MonthSign2AwardDlg)) {
            we.currentUI.close(HallViewId.MonthSign2AwardDlg);
        }
        if (!data || this.data.switchStatus == false) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_2));
            this.closeView();
            return;
        }

        await this.initCumulativeAwardList();

        if (this.view.RC_list.numItems > 0) {
            this.view.RC_list.updateAll();
        }

        // 顶部描述
        let maxMultiplier = 0;
        let rechargeThreshold = 0;
        if (data.rechargeMultiplierConf) {
            maxMultiplier = data.rechargeMultiplierConf.maxMultiplier;
            rechargeThreshold = data.rechargeMultiplierConf.rechargeThreshold;
        }
        maxMultiplier = Math.round(maxMultiplier * 100) / 100;
        this.view.RC_rich_desc.setStringFormat(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_1), we.common.utils.formatPrice(rechargeThreshold, false, false), maxMultiplier);

        // 底部描述
        let availableCount = 0;
        if (data.reSignInConf) {
            availableCount = data.reSignInConf?.availableCount || 0;
        }
        this.view.RC_rich_bottom.setStringFormat(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_7), availableCount);

        // 进度值
        const maxSign = MonthSign.month2.getCumulativeSignMaxDay();
        const overSign = data.cumulativeSignInCount >= maxSign ? maxSign : data.cumulativeSignInCount;
        this.view.RC_lab_bar.string = overSign + '/' + maxSign;
        let fillRange = MonthSign.month2.calculateProgress(data.cumulativeSignInCount, data.cumulativeSignInAwardConf);
        this.view.RC_spr_bar.fillRange = fillRange;
    }

    /** 渲染事件 */
    private onRenderEvent(item: cc.Node, i: number): void {
        const com = item.getComponent(MonthSignItem_v);
        com.updateData(i + 1);
    }

    /** 初始化 累计签到 节点 */
    private async initCumulativeAwardList() {
        const total = this.data.cumulativeSignInAwardConf.length;
        if (total <= 0) {
            for (let i = 0; i < this.nodeAwards.length; i++) {
                this.nodeAwards[i].node.active = false;
            }
            return;
        }
        if (total === this.nodeAwards.length) {
            for (let i = 0; i < this.nodeAwards.length; i++) {
                this.nodeAwards[i].node.active = true;
                this.nodeAwards[i]?.updateData(i);
            }
            return;
        }
        this.nodeAwards.length = 0;
        this.view.RC_spr_bar.node.removeAllChildren();
        // init
        const prefab = await this.loadAsset(HallRes.prefab.MonthSign2AwardItem, cc.Prefab);
        for (let i = 0; i < this.data.cumulativeSignInAwardConf.length; i++) {
            let item = cc.instantiate(prefab);
            this.view.RC_spr_bar.node.addChild(item);
            const padding = this.view.RC_spr_bar.node.width / total;
            item.setPosition(padding * (i + 1), 0);
            item.active = true;
            const com = item.getComponent(MonthSignAwardItem_v);
            com?.updateData(i);
            this.nodeAwards.push(com);
        }
    }

    private setAutoHideTip() {
        this.view.RC_tip.active = false;
        this.schedule(1, () => {
            if (this.view.RC_tip.active == false) {
                return;
            }
            if (Date.now() - this.hideTipTime > 4000) {
                this.view.RC_tip.active = false;
            }
        });
    }

    private onClickRule(): void {
        we.currentUI.show(HallViewId.MonthSign2RuleDlg);
    }

    private onClickWarn(): void {
        this.hideTipTime = Date.now();
        this.view.RC_tip.active = !this.view.RC_tip.active;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(MonthSign2Dlg_v, `${HallViewId.MonthSign2Dlg}_v`)
class MonthSign2DlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(MonthSign2Dlg_v, uiBase.addComponent(MonthSign2DlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSign2Dlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<MonthSign2Dlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(MonthSign2Dlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MonthSign2Dlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(MonthSign2Dlg_v).beforeUnload();
    }

    async onShowAnimation(uiBase: we.ui.UIBase): Promise<void> {
        await we.ui.UIDlgTween.open(uiBase);
        await uiBase.getComponent(MonthSign2Dlg_v).onShowAnimation();
    }
}
