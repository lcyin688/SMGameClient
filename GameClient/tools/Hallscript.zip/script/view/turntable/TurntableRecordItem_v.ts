const { ccclass, property } = cc._decorator;

@ccclass
export default class TurntableRecordItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_money: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_avatar: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    init(params: api.RodaHistory) {
        if (!params) {
            return;
        }
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.RC_lab_name.string = this.formatNickname(params.name);
        this.RC_lab_money.string = we.common.utils.formatAmountCurrency(params.award_64, true);
        this.RC_lab_time.string = we.common.utils.formatDate(new Date(params.time_64 * 1000));
        if (this.RC_spr_avatar && params.avatar) {
            we.common.utils.setAvatarSprite(this.RC_spr_avatar, params.avatar, params.gender, false);
        }
    }

    formatNickname(str: string) {
        if (typeof str !== 'string') {
            return '';
        }
        if (str.length <= 4) {
            return str.slice(0, 2) + '****';
        }
        return str.slice(0, 2) + '****' + str.slice(-2, str.length);
    }
}
