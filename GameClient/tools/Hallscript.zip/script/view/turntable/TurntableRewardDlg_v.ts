import { HallViewId } from '../HallViewId';
import TurntableRewardItem_v from './TurntableRewardItem_v';

enum HistoryType {
    SELF = 'self',
    SERVER = 'server',
}

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('TurntableRewardDlgView_v', we.bundles.hall)
class TurntableRewardDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_scrollView: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_noData: cc.Node = null;

    @we.ui.ccBind(cc.ToggleContainer)
    public RC_toggleContainer: cc.ToggleContainer = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('TurntableRewardDlg_v', we.bundles.hall)
export class TurntableRewardDlg_v extends we.ui.DlgSystem<TurntableRewardDlgView_v> {
    rewardData: api.RodaHistory[] = [];

    rewardPageIndex = 0;

    rewardPageSize = 20;

    rewardPageType = HistoryType.SERVER;

    selfReward = {
        index: 0,
        data: [] as api.RodaHistory[],
    };

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onToggle(this.view.RC_toggleContainer.node, we.core.Func.create(this.onChangeType, this), [HistoryType.SERVER, HistoryType.SELF]);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_toggleContainer.toggleItems[0].check();
        this.getData(HistoryType.SERVER);
        this.view.RC_noData.active = false;
        this.view.RC_list_scrollView.setRenderEvent(we.core.Func.create(this.renderItem, this));
    }

    public renderItem(node: cc.Node, index: number) {
        if (index > 0 && index == this.rewardPageIndex * this.rewardPageSize - 1) {
            this.getData(this.rewardPageType);
        }
        const item = node.addComponentUnique(TurntableRewardItem_v);
        const data = this.rewardData[index];
        if (!data) {
            return;
        }
        item.init({
            name: data.name,
            money: data.award_64,
            time: we.common.utils.formatDate(new Date(data.time_64 * 1000)),
        });
    }

    public getData(type: HistoryType) {
        const callback = (list: api.RodaHistory[] = []) => {
            if (this.rewardPageType === HistoryType.SELF) {
                this.rewardData = this.selfReward.data;
            } else {
                this.rewardData = this.rewardData.concat(list);
            }
            this.view.RC_list_scrollView.numItems = this.rewardData.length;
            this.view.RC_noData.active = this.rewardData.length === 0;
        };
        if (this.rewardData.length < this.rewardPageIndex * this.rewardPageSize) {
            callback();
            return;
        }

        we.common.turntableMgr
            .getRodaUndianUpPage(
                {
                    historyType: type,
                    indexLow: this.rewardPageIndex * this.rewardPageSize,
                    indexHigh: (this.rewardPageIndex + 1) * this.rewardPageSize,
                },
                false
            )
            .then((res) => {
                this.rewardPageIndex += 1;
                let list = [];
                if (type === HistoryType.SELF) {
                    list = res.selfHistory;
                    this.selfReward.data.push(...list);
                    this.selfReward.index = this.rewardPageIndex;
                } else if (type === HistoryType.SERVER) {
                    list = res.serviceHistory;
                }
                callback(list);
            });
        this.rewardPageType = type;
    }

    public onChangeType(e: cc.Event, type: HistoryType) {
        this.view.RC_list_scrollView.numItems = 0;
        this.view.RC_list_scrollView.scrollTo(0);
        this.view.RC_noData.active = false;
        if (type === HistoryType.SERVER) {
            this.rewardPageIndex = 0;
            this.rewardData = [];
            this.getData(type);
        } else if (type === HistoryType.SELF) {
            this.rewardPageIndex = this.selfReward.index;
            this.rewardData = this.selfReward.data;
            this.getData(type);
        }
        this.rewardPageType = type;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(TurntableRewardDlg_v, `${HallViewId.TurntableRewardDlg}_v`)
class TurntableRewardDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(TurntableRewardDlg_v, uiBase.addComponent(TurntableRewardDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableRewardDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<TurntableRewardDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(TurntableRewardDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableRewardDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(TurntableRewardDlg_v).beforeUnload();
    }
}
