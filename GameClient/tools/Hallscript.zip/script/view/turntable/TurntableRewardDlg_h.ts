import { HallViewId } from '../HallViewId';
import { HistoryType } from './TurntableDlg_h';
import TurntableRewardItem_h from './TurntableRewardItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('TurntableRewardDlgView_h', we.bundles.hall)
class TurntableRewardDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_self: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_sever: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_noData_self: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_noData_server: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.ToggleContainer)
    public RC_toggleContainer: cc.ToggleContainer = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

interface pageInfo {
    page: number;
    disableRequest: boolean;
    rewardList: api.RodaHistory[];
    pageSize: number;
}

class TurntableRewardStore {
    pageType: HistoryType = HistoryType.SERVER;

    [HistoryType.SERVER] = {
        page: 0,
        rewardList: <api.RodaHistory[]>[],
        disableRequest: false,
        pageSize: 20,
    };

    [HistoryType.SELF] = {
        page: 0,
        rewardList: <api.RodaHistory[]>[],
        disableRequest: false,
        pageSize: 20,
    };

    getPageInfo(type?: HistoryType) {
        type = type ?? this.pageType;
        return this[type] as pageInfo;
    }
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('TurntableRewardDlg_h', we.bundles.hall)
export class TurntableRewardDlg_h extends we.ui.DlgSystem<TurntableRewardDlgView_h> {
    constructor() {
        super();
        this.store = new TurntableRewardStore();
        we.mobx.makeAutoObservable(this.store);
    }

    private store: TurntableRewardStore = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onToggle(this.view.RC_toggleContainer.node, we.core.Func.create(this.onChangeType, this), [HistoryType.SERVER, HistoryType.SELF]);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_toggleContainer.toggleItems[0].check();

        this.view.RC_list_sever.setRenderEvent(
            we.core.Func.create((node, idx) => {
                this.renderItem(node, idx, HistoryType.SERVER);
            })
        );

        this.view.RC_list_self.setRenderEvent(
            we.core.Func.create((node, idx) => {
                this.renderItem(node, idx, HistoryType.SELF);
            })
        );
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    public onChangeType(e: cc.Event, type: HistoryType) {
        this.store.pageType = type;
    }

    /**
     * 当状态发生变化时
     */
    @we.mobx.render
    private typeChange() {
        we.debug('type change', this.store.pageType);
        const type = this.store.pageType;
        this.store.getPageInfo(type).disableRequest = false;

        // 设置列表显示
        this.view.RC_list_self.node.active = type == HistoryType.SELF;
        this.view.RC_list_sever.node.active = type == HistoryType.SERVER;

        this.requestData(type);
    }

    @we.mobx.render
    private serverListChange() {
        const list = this.store[HistoryType.SERVER].rewardList;
        this.view.RC_list_sever.numItems = list.length;
    }
    @we.mobx.render
    private slefListChange() {
        const list = this.store[HistoryType.SELF].rewardList;
        this.view.RC_list_self.numItems = list.length;
    }

    @we.mobx.render
    private showSeverNoData() {
        const info = this.store[HistoryType.SERVER];
        this.view.RC_noData_server.active = info.page == 0 && info.disableRequest && info.rewardList.length == 0;
    }

    @we.mobx.render
    private showSlefNoData() {
        const info = this.store[HistoryType.SELF];
        this.view.RC_noData_self.active = info.page == 0 && info.disableRequest && info.rewardList.length == 0;
    }

    private async requestData(type: HistoryType) {
        // 因为有 store 数据，需要延迟一帧 避免被mbox标记
        await this.scheduleOnce(0);

        const info = this.store.getPageInfo(type);
        const indexLow = info.page * info.pageSize;
        const indexHigh = (info.page + 1) * info.pageSize;
        we.debug('request...', type);
        if (info.disableRequest) {
            return;
        }

        try {
            const data = await we.common.turntableMgr.getRodaUndianUpPage(
                {
                    historyType: type,
                    indexLow: indexLow,
                    indexHigh: indexHigh,
                },
                false
            );

            // 窗口被销毁，不继续执行
            if (this.IsDisposed) {
                return;
            }

            const list = type == HistoryType.SELF ? data.selfHistory : data.serviceHistory;
            if (list.length <= 0) {
                info.disableRequest = true;
                return;
            }

            info.page += 1;
            info.rewardList = [...info.rewardList, ...list];
        } catch (e) {
            we.error(`TurntableRewardDlg_h requestData, err: ${JSON.stringify(e?.message || e)}`);
        }
    }

    private renderItem(node: cc.Node, index: number, type: HistoryType) {
        const info = this.store.getPageInfo(type);
        if (index > 0 && index == info.rewardList.length - 1 && !info.disableRequest) {
            info.page += 1;
            this.requestData(type);
        }

        const item = node.addComponentUnique(TurntableRewardItem_h);
        const data = info.rewardList[index];
        if (!data) {
            return;
        }

        item.init({
            name: data.name,
            money: data.award_64,
            time: we.common.utils.formatDate(new Date(data.time_64 * 1000)),
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(TurntableRewardDlg_h, `${HallViewId.TurntableRewardDlg}_h`)
class TurntableRewardDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(TurntableRewardDlg_h, uiBase.addComponent(TurntableRewardDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableRewardDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<TurntableRewardDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(TurntableRewardDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableRewardDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(TurntableRewardDlg_h).beforeUnload();
    }
}
