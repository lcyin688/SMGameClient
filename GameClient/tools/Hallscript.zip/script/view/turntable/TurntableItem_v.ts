const { ccclass, property } = cc._decorator;

@ccclass
export default class TurntableItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_border: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_money: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    angle = 0;

    init(award: number, angle?: number, index?: number) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.RC_lab_money.string = `${we.common.utils.formatAmount(award)}`;
        this.RC_border.active = false;
        if (angle) {
            this.angle = angle;
        }

        if (index != null) {
            this.RC_lab_money.node.getComponent(we.ui.WENodeColorIndex)?.setIndex(index % 2);
        }
    }

    showBorder() {
        this.RC_border.active = true;
        this.tween(this.RC_border)
            .repeatForever(new cc.Tween().to(0.5, { opacity: 0 }).delay(0.2).to(0.5, { opacity: 255 }))
            .start();
    }

    hideBorder() {
        this.RC_border.active = false;
        cc.Tween.stopAllByTarget(this.RC_border);
    }
}
