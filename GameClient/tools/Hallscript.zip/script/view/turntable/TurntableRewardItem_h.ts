const { ccclass, property } = cc._decorator;

@ccclass
export default class TurntableRewardItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_money: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {}

    protected start(): void {}

    protected onEnable(): void {}

    protected update(dt: number): void {}

    protected onDestroy(): void {}

    init(params: { name: string; money: number; time: string }) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        if (params.name) {
            this.RC_lab_name.string = this.formatNickname(params.name);
        } else {
            this.RC_lab_name.string = we.common.userMgr.userInfo.userName;
        }
        this.RC_lab_money.string = we.common.utils.formatAmountCurrency(params.money, true);
        this.RC_lab_time.string = params.time;
    }

    formatNickname(str: string) {
        if (typeof str !== 'string') {
            return '';
        }
        if (str.length <= 4) {
            return str.slice(0, 2) + '****';
        }
        return str.slice(0, 2) + '****' + str.slice(-2, str.length);
    }
}
