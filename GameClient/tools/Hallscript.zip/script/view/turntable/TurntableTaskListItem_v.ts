const { ccclass, property } = cc._decorator;

@ccclass
export default class TurntableTaskListItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    init(params: { target: number; value: number; type: string }) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        if (params.type === we.common.activityMgr.TaskType.recharge) {
            this.RC_lab_name.string = we.common.utils.formatPrice(Number(params.target), false);
        } else {
            this.RC_lab_name.string = we.common.utils.formatAmount(Number(params.target));
        }
        this.RC_lab_value.string = `+${params.value}`;
    }
}
