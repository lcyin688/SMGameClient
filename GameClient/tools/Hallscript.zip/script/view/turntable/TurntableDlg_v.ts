import { HallRes } from '../../config/HallRes';
import { HallPageEnum } from '../../const/HallConst';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import TurntableItem_v from './TurntableItem_v';
import TurntableRecordItem_v from './TurntableRecordItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('TurntableDlgView_v', we.bundles.hall)
class TurntableDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_barValueAnim: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnBet: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecharge: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecord: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnSpin: cc.Node = null;

    @we.ui.ccBind(sp.Skeleton)
    public RC_btnSpinAnim: sp.Skeleton = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTaskChange: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTaskRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTimeHelp: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_spinCount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_taskCount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_taskRatio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_taskType: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_timeHelp: cc.Label = null;

    @we.ui.ccBind(we.ui.WEPageView)
    public RC_page_record: we.ui.WEPageView = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_barValue: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_taskSpinLabel: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_timeHelpMask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_timeHelpPrompt: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_turntableInside: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('TurntableDlg_v', we.bundles.hall)
export class TurntableDlg_v extends we.ui.DlgSystem<TurntableDlgView_v> {
    public recordData: api.RodaHistory[] = [];

    public taskType = we.common.activityMgr.TaskType.recharge;

    public isRunning = false;

    public turntableItems: Record<number, TurntableItem_v> = {};

    // 转盘过期时间
    public expireTime = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_page_record.setRender(we.core.Func.create(this.onRenderTurntableRecord, this));
        this.view.RC_page_record.pageChanedCallback = this.onChangeTurntableRecord.bind(this);
        this.view.RC_page_record.autoLoop(4);

        this.view.cc_onBtnClick(this.view.RC_btnRule, we.core.Func.create(this.onClickBtnRule, this));
        this.view.cc_onBtnClick(this.view.RC_btnTimeHelp, we.core.Func.create(this.onClickBtnTimeHelp, this));
        this.view.cc_onBtnClick(this.view.RC_timeHelpMask, we.core.Func.create(this.onClickBtnTimeHelp, this));
        this.view.cc_onBtnClick(this.view.RC_btnRecharge, we.core.Func.create(this.onClickBtnRecharge, this));
        this.view.cc_onBtnClick(this.view.RC_btnBet, we.core.Func.create(this.onClickQuickStart, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.onClickCloseView, this));
        this.view.cc_onBtnClick(this.view.RC_btnRecord, we.core.Func.create(this.onClickBtnReward, this));
        this.view.cc_onBtnClick(this.view.RC_btnTaskChange, we.core.Func.create(this.onChangeTaskType, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnTaskRule, we.core.Func.create(this.onClickTaskList, this));
        this.view.cc_onBtnClick(this.view.RC_btnSpin, we.core.Func.create(this.onClickBtnSpin, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.init();
        // 拉取最新数据
        we.common.turntableMgr.getTurntableData(false).then(() => {
            if (!we.common.turntableMgr.getTurntableIsAct()) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_26));
                this.closeView();
                return;
            }
            this.init();
        });
        this.getTurntableRecords();
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Turntable);
        cc.director.emit(we.common.EventName.UPDATE_TURNTABLE_TASK);
    }

    private init() {
        if (!this.isValid()) {
            return;
        }
        if (!we.common.turntableMgr.getTurntableIsAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_26));
            this.onClickCloseView();
            return;
        }

        if (we.common.turntableMgr.turntableData.recharge.length <= 0) {
            this.taskType = we.common.activityMgr.TaskType.betAmount;
        }

        this.renderExpProgress();
        this.renderCountDown();
        this.renderSpinCount();
        this.renderTurntableItems();

        this.view.RC_btnTaskChange.active = we.common.turntableMgr.turntableData.recharge.length > 0 && we.common.turntableMgr.turntableData.betAmount.length > 0;
    }

    /**
     * 渲染转盘项
     */
    private renderTurntableItems() {
        this.turntableItems = {};
        this.loadAsset(HallRes.prefab.turntable.TurntableItem, cc.Prefab).then((prefab) => {
            this.view.RC_turntableInside.removeAllChildren();
            const rodaConf = we.common.turntableMgr.turntableData.rodaConf;
            if (!rodaConf) {
                return;
            }
            for (let i = 0; i < 12; i++) {
                const node = cc.instantiate(prefab);
                node.angle = i * 30;
                node.active = true;
                const item = node.addComponentUnique(TurntableItem_v);
                const conf = rodaConf[i] || { id: 0, award: 0 };
                item.init(conf.award, node.angle, i);
                this.view.RC_turntableInside.addChild(node);
                conf.id && (this.turntableItems[conf.id] = item);
            }
        });
    }

    private getTurntableRecords() {
        we.common.turntableMgr
            .getRodaUndianUpPage({
                historyType: 'server_big',
                indexLow: 0,
                indexHigh: 20,
            })
            .then((res) => {
                if (!this.isValid()) {
                    return;
                }
                this.recordData = res.serviceBigHistory || [];
                this.view.RC_page_record.totalPage = this.recordData.length;
            });
    }

    private onRenderTurntableRecord(node: cc.Node, index: number) {
        const record = this.recordData[index];
        const item = node.addComponentUnique(TurntableRecordItem_v);
        item.init(record);
    }

    private onClickCloseView() {
        if (this.isRunning) {
            return;
        }
        this.closeView();
    }

    private onChangeTurntableRecord() {
        const curIndex = this.view.RC_page_record.getCurrentPage();
        if (curIndex + 1 === this.recordData.length) {
            this.getTurntableRecords();
        }
    }

    /**
     * 点击充值按钮
     */
    private onClickBtnRecharge() {
        if (this.isRunning) {
            return;
        }
        we.common.payMgr.trackFrom = we.common.JumpCmd.Turntable;
        we.currentUI.getDlg(HallViewId.HallDlg).onShow(HallPageEnum.shop);
        this.closeView();
    }

    /**
     * 点击快速开始
     */
    private onClickQuickStart() {
        if (this.isRunning) {
            return;
        }

        HallMgr.openRecentGame(() => {
            if (cc.isValid(this.view.uiRoot)) {
                this.closeView();
            }
        });
    }

    /**
     * 点击提示文本
     */
    private onClickBtnTimeHelp() {
        this.view.RC_timeHelpPrompt.active = !this.view.RC_timeHelpPrompt.active;
        if (we.common.turntableMgr.turntableData.rodaCntDailyRefresh) {
            this.view.RC_lab_timeHelp.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_13);
        } else {
            this.view.RC_lab_timeHelp.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_27);
        }
    }

    /**
     * 点击规则
     */
    private onClickBtnRule() {
        we.currentUI.showSafe(HallViewId.TurntableRuleDlg);
    }

    /**
     * 点击中奖记录
     */
    private onClickBtnReward() {
        we.currentUI.showSafe(HallViewId.TurntableRewardDlg);
    }

    /**
     * 切换任务
     */
    private onChangeTaskType() {
        let taskType = we.common.activityMgr.TaskType.recharge;
        if (this.taskType === we.common.activityMgr.TaskType.recharge) {
            taskType = we.common.activityMgr.TaskType.betAmount;
        }
        this.taskType = taskType;
        this.renderExpProgress(taskType);
    }

    private renderExpProgress(type?: string) {
        const taskType = type || this.taskType;
        const taskList = we.common.turntableMgr.turntableData[taskType];
        if (!taskList) {
            return;
        }
        let taskData: api.TaskProgressDetail = {} as any;
        let title = '';
        if (taskType === we.common.activityMgr.TaskType.recharge) {
            taskData = taskList[we.common.turntableMgr.turntableData.rechargeTaskAttainCount];
            title = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_9);
        } else if (taskType === we.common.activityMgr.TaskType.betAmount) {
            taskData = taskList[we.common.turntableMgr.turntableData.betAmountTaskAttainCount];
            title = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_10);
        }
        this.view.RC_taskSpinLabel.active = Boolean(taskData);
        this.view.RC_lab_taskRatio.node.active = Boolean(taskData);
        this.view.RC_lab_taskCount.node.active = Boolean(taskData);
        if (!taskData) {
            taskData = { target: 0, progress: 0, reward: 0 } as any;
        }
        const progress = taskData.progress / taskData.target;
        this.view.RC_spr_barValue.fillRange = progress;
        const pos = this.view.RC_barValueAnim.getPosition();
        pos.x = this.view.RC_spr_barValue.node.width * progress;
        this.view.RC_barValueAnim.setPosition(pos);
        this.view.RC_barValueAnim.active = progress > 0 && progress < 1;
        this.view.RC_lab_taskType.string = title;
        this.view.RC_btnBet.active = taskType === we.common.activityMgr.TaskType.betAmount;
        this.view.RC_btnRecharge.active = taskType === we.common.activityMgr.TaskType.recharge;

        let taskRatioStr = '';
        if (taskType === we.common.activityMgr.TaskType.recharge) {
            taskRatioStr = `${we.common.utils.formatPrice(taskData.progress, false)}/${we.common.utils.formatPrice(taskData.target, false)}`;
        } else {
            taskRatioStr = `${we.common.utils.formatAmount(taskData.progress)}/${we.common.utils.formatAmount(taskData.target)}`;
        }
        this.view.RC_lab_taskRatio.string = taskRatioStr;
        this.view.RC_lab_taskCount.string = `+${taskData.reward}`;
        this.taskType = taskType;
    }

    /**
     * 渲染倒计时
     */
    private renderCountDown() {
        // 计算距离下个6点时间差
        const curTime = we.core.TimeInfo.Inst.serverNow();
        let nextTime = new Date(curTime).setHours(6, 0, 0, 0);
        if (curTime >= nextTime) {
            nextTime += 24 * 60 * 60 * 1000;
        }
        if (nextTime > we.common.turntableMgr.turntableData.endTime * 1000) {
            nextTime = we.common.turntableMgr.turntableData.endTime * 1000;
        }
        const duration = Math.floor((nextTime - curTime) / 1000);
        const timeCountDown = this.view.RC_lab_time.node.getComponent(we.ui.WETimeCountDown);
        timeCountDown.countDown(0, duration, `{HH}:{MM}:{SS}`, (str) => {
            this.view.RC_lab_time.string = str;
        });
        this.expireTime = nextTime;
        this.view.RC_timeHelpPrompt.active = false;
    }

    private onClickTaskList() {
        we.currentUI.show(HallViewId.TurntableTaskListDlg);
    }

    /**
     * 渲染旋转次数
     */
    private renderSpinCount() {
        this.view.RC_lab_spinCount.string = `${(we.common.turntableMgr.turntableData.userData && we.common.turntableMgr.turntableData.userData.cnt) || 0}`;
        we.common.turntableMgr.getTurntableRedCount(true);
        we.common.activityMgr.updateEventCenter();
    }

    /**
     * 点击开始旋转按钮
     */
    private onClickBtnSpin() {
        if (we.core.TimeInfo.Inst.serverNow() >= this.expireTime) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_26));
            this.closeView();
            return;
        }
        if (this.isRunning || !we.common.turntableMgr.turntableData.userData) {
            return;
        }
        if (we.common.turntableMgr.turntableData.userData.cnt <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_25));
            return;
        }
        if (!we.common.turntableMgr.getTurntableIsAct()) {
            // 任务活动已到期
            HallMgr.activityStatusTips(we.common.turntableMgr.turntableData.startTime, we.common.turntableMgr.turntableData.endTime);
            return;
        }
        this.isRunning = true;
        this.view.RC_btnSpinAnim.setAnimation(0, 'animation2', true);
        this.view.RC_turntableInside.children.forEach((child) => {
            child.addComponentUnique(TurntableItem_v).hideBorder();
        });
        const tween = this.tween(this.view.RC_turntableInside)
            .repeatForever(new cc.Tween().by(0.8, { angle: -360 }))
            .start();
        const errorCallback = () => {
            tween.stop();
            this.isRunning = false;
            this.view.RC_btnSpinAnim.setAnimation(0, 'animation1', false);
            this.view.RC_turntableInside.angle = this.view.RC_turntableInside.angle % 360;
        };
        we.common.turntableMgr
            .getRodaUndianAward()
            .then((res) => {
                tween.stop();
                const item = this.turntableItems[res.awardId];
                if (!item) {
                    we.common.turntableMgr.turntableData.userData.cnt = 0;
                    this.renderSpinCount();
                    errorCallback();

                    // 弹出提示框，关闭弹框
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_26));
                    this.closeView();
                    return;
                }
                item.init(res.awardNum_64);
                const angle = item.angle - Math.abs(this.view.RC_turntableInside.angle % 360) + 720;
                this.tween(this.view.RC_turntableInside)
                    .by(Math.abs(angle) * 0.001 + 0.8, { angle: -angle }, { easing: 'quadOut' })
                    .call(() => {
                        this.view.RC_btnSpinAnim.setAnimation(0, 'animation3', false);
                        this.view.RC_turntableInside.angle = -item.angle;
                        this.isRunning = false;
                        item.showBorder();

                        // 创建奖励弹框
                        const awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: res.awardNum_64 }];
                        HallMgr.openGetAwardsDlg(awardMap);
                    })
                    .start();

                this.renderSpinCount();
            })
            .catch((err) => {
                errorCallback();
            });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(TurntableDlg_v, `${HallViewId.TurntableDlg}_v`)
class TurntableDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(TurntableDlg_v, uiBase.addComponent(TurntableDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<TurntableDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(TurntableDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(TurntableDlg_v).beforeUnload();
    }
}
