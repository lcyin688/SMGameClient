const { ccclass, property } = cc._decorator;

@ccclass
export default class PropAwardItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_icon: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_num: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_received: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private clickCb: Function = null;

    private isGet: boolean = true;

    public init(num: number, isGet: boolean = false, clickCb?: Function) {
        this.isGet = isGet;
        this.clickCb = clickCb;
        this.offBtnClick(this.node);

        this.RC_lab_num.string = we.common.utils.formatAmountCurrency(num, true);
        this.RCN_received.active = isGet;
        this.RCN_mask.active = isGet;

        if (!isGet && clickCb) {
            this.onBtnClick(this.node, we.core.Func.create(this.onClickGet, this)).setTransitionScale({ zoomScale: 1, duration: 0.9 });
        }
    }

    public updateStatus(isGet: boolean) {
        this.isGet = isGet;

        this.RCN_received.active = isGet;
        this.RCN_mask.active = isGet;
    }

    private onClickGet(): void {
        if (this.isGet) {
            return;
        }

        this.clickCb?.();
    }
}
