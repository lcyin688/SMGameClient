import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class MailItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_new: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_awardRoot: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_getAttachment: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_gray: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_scroll: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private data: api.MailDetailItem = null;
    /** 附件奖励 */
    private award: number = 0;

    protected onLoad(): void {
        this.onBtnClick(this.RCN_getAttachment, we.core.Func.create(this.onGetAttachment, this));
        this.onBtnClick(this.node, we.core.Func.create(this.onClickOpen, this));
    }

    /**
     * 初始化邮件
     * @param data
     * @param isOpen
     */
    public init(data: api.MailDetailItem, isOpen: boolean = false) {
        this.__initRc();

        this.data = data;
        this.award = 0;
        let attachment = data.attachment;
        if (Object.keys(attachment || {}).length > 0) {
            for (let key in attachment) {
                this.award += attachment[key] || 0;
            }
        }

        // 设置邮件标题
        let title = we.npm.lodash.cloneDeep(data.title);
        title = title?.replace(/[\r\n]+/g, ' ');
        this.RC_lab_title.string = title;

        this.RC_lab_time.string = we.common.utils.formatDate(new Date(data.sendTime), 'DD/MM/YYYY hh:mm');

        // 打开状态
        this.RCN_scroll.angle = isOpen ? 180 : 0;
        this.upMailStatus(data.status, isOpen);

        const labelLimit = this.nodeAddComponent(this.RC_lab_title.node, we.ui.WELabelLongLimit);
        we.core.timer.scheduleOnce(0, this.node).then(() => {
            labelLimit.onMessageSizeChanged();
        });
    }

    /**
     * 更新邮件状态
     * @param status
     * @param isOpen
     * @returns
     */
    private upMailStatus(status: number, isOpen: boolean = false) {
        if (!cc.isValid(this.node) || !this.data) {
            return;
        }
        this.data.status = status;

        this.RCN_gray.active = false;
        this.RC_spr_new.node.active = true;
        this.RCN_awardRoot.active = false;
        this.RCN_getAttachment.active = false;

        let hasAttachment = we.common.mailMgr.isExistAttachment(this.data);
        this.RCN_getAttachment.active = hasAttachment;
        this.RCN_scroll.active = !hasAttachment;
        if (hasAttachment && this.data.status != we.common.mailMgr.MailStatus.ReadAndDraw) {
            this.RCN_awardRoot.active = true;
            this.RC_spr_new.node.active = false;
            this.RC_lab_award.string = we.common.utils.formatAmountCurrency(this.award, true);
        }

        let statusIconName = 'icon_letter_read';
        switch (status) {
            case we.common.mailMgr.MailStatus.Unread:
                statusIconName = 'icon_letter_unRead';
                break;
            case we.common.mailMgr.MailStatus.Read:
            case we.common.mailMgr.MailStatus.ReadAndDraw:
                this.RCN_gray.active = true;
                break;
            default:
                break;
        }

        // 设置邮件打开状态 icon
        this.RC_spr_new.spriteFrame = this._rc.getRes(statusIconName, cc.SpriteFrame);

        if (isOpen) {
            // 修正打开已读邮件
            this.RCN_gray.active = false;

            this.RCN_getAttachment.active = false;
            this.RC_spr_new.node.active = true;
            this.RCN_scroll.active = true;
            this.RCN_awardRoot.active = false;
        }
    }

    private onGetAttachment() {
        if (!this.data) {
            return;
        }
        let hasAttachment = we.common.mailMgr.isExistAttachment(this.data);
        if (hasAttachment) {
            const mailId = this.data.mailId;
            we.common.mailMgr.getMailAward([mailId]).then((data: api.ReadAllMailResp) => {
                we.common.mailMgr.updateMailStatus([mailId], we.common.mailMgr.MailStatus.ReadAndDraw);
                cc.director.emit(we.common.EventName.UPDATE_MAIL_LIST, false);

                let awardMap = [];
                for (let key in data.attachment) {
                    awardMap.push({ id: parseInt(key), num: data.attachment[key] });
                }
                HallMgr.openGetAwardsDlg(awardMap);
            });
        } else {
            this.RCN_getAttachment.active = false;
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.COMMON_RECEIVED));
        }
    }

    private onClickOpen() {
        cc.director.emit(HallEvent.EVENT_MAIL_CONTEXT_READ, this.data);
    }
}
