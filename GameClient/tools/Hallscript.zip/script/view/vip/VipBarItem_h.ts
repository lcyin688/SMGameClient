const { ccclass, property } = cc._decorator;

@ccclass
export default class VipBarItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_active: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_level1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_level2: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_normal: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(index: number) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        const userVipInfo = we.common.userMgr.vipExp;
        this.RC_normal.active = !(index <= userVipInfo.level);
        this.RC_active.active = index <= userVipInfo.level;

        this.RC_lab_level1.string = index.toString();
        this.RC_lab_level2.string = index.toString();
    }
}
