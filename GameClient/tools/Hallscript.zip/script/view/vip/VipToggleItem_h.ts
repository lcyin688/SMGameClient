import { HallRes } from '../../config/HallRes';

const { ccclass, property } = cc._decorator;

@ccclass
export default class VipToggleItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_vipLevel: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vipIcon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @we.ui.ccBind(cc.Label)
    private RC_lab_vipLevel2: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    private RC_readPoint: cc.Node = null;

    @property
    private isScaleEffect = true;

    public init(level: number) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        if (this.RC_spr_vipIcon) {
            we.common.utils.setComponentSprite(this.RC_spr_vipIcon, HallRes.texture.VIP_Logo_icon + level);
        }
        const levelStr = `VIP ${level}`;
        this.RC_lab_vipLevel.string = levelStr;
        this.RC_lab_vipLevel2 && (this.RC_lab_vipLevel2.string = levelStr);
        if (we.common.userMgr.vipExp?.level === level) {
            this.setNoticeState();
        }
    }

    protected update(dt: number): void {
        if (!this.isScaleEffect) {
            return;
        }
        let x = Math.abs(this.node.x + this.node.parent.x);
        let scale = 1 - x / (this.node.width * 5);

        this.node.scale = scale;

        const skinCode = we.core.flavor.getSkinCode();
        switch (skinCode) {
            case we.core.SkinCode.bg2:
            case we.core.SkinCode.cm1:
            case we.core.SkinCode.cm3:
            case we.core.SkinCode.cm5:
            case we.core.SkinCode.cm6:
            case we.core.SkinCode.rs: {
                let opacityScale = 1 - x / (this.node.width * 4);
                this.node.opacity = opacityScale * 255;
                break;
            }
            default:
                break;
        }
    }

    public setNoticeState() {
        if (!this.RC_readPoint) {
            return;
        }
        we.common.commonMgr.appendVRedDotNode(this.RC_readPoint).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vipToggleItem, node: notice });
        });
    }
}
