import { HallRes } from '../../config/HallRes';

const { ccclass, property } = cc._decorator;

@ccclass
export default class VipToggleItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_vipLevel: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vipIcon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(level: number) {
        this.__initRc();

        we.common.utils.setComponentSprite(this.RC_spr_vipIcon, HallRes.texture.VIP_Logo_icon + level);
        this.RC_lab_vipLevel.string = 'VIP ' + level;
    }

    public select() {
        if (this.RC_spr_vipIcon.node.scaleX !== 1.2) {
            this.tween(this.RC_spr_vipIcon.node).to(0.2, { scaleX: 1.2, scaleY: 1.2 }).start();
        }
    }

    public unSelect() {
        if (this.RC_spr_vipIcon.node.scaleX !== 1) {
            this.tween(this.RC_spr_vipIcon.node).to(0.2, { scaleX: 1, scaleY: 1 }).start();
        }
    }
}
