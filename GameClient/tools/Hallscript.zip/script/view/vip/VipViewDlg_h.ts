import HallMgr from '../../manager/HallMgr';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import VipRightsItem_h from './VipRightsItem_h';
import VipToggleItem_h from './VipToggleItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('VipViewDlgView_h', we.bundles.hall)
class VipViewDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.ProgressBar)
    public RC_bar_vipProgressBar: cc.ProgressBar = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoGame1: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoGame2: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoRecharge1: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoRecharge2: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnLeft: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRight: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_progress: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_lockMask: cc.Node = null;

    @we.ui.ccBind(cc.PageView)
    public RC_page_vipIcons: cc.PageView = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_lockMask1: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_lockMask2: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_vipUpTip: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RC_rightsLayout: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('VipViewDlg_h', we.bundles.hall)
export class VipViewDlg_h extends we.ui.DlgSystem<VipViewDlgView_h> {
    /** 是否正在切换 */
    private isToggleLock = false;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoGame1, we.core.Func.create(this.onClickGoGame, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoGame2, we.core.Func.create(this.onClickGoGame, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoRecharge1, we.core.Func.create(this.onClickRecharge, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoRecharge2, we.core.Func.create(this.onClickRecharge, this));
        this.view.cc_onBtnClick(this.view.RC_btnLeft, we.core.Func.create(this.onChangeCurrentLevel, this, -1)).setSleepTime(0.1);
        this.view.cc_onBtnClick(this.view.RC_btnRight, we.core.Func.create(this.onChangeCurrentLevel, this, 1)).setSleepTime(0.1);

        // VIP图标切换事件
        this.view.RC_page_vipIcons.node.on('page-turning', this.onPageVipIcon, this);
        this.view.cc_onNodeEvent(this.view.RC_page_vipIcons.node, cc.Node.EventType.TOUCH_END, we.core.Func.create(this.onTouchEndPageView, this));
        this.view.cc_onNodeEvent(this.view.RC_page_vipIcons.node, cc.Node.EventType.TOUCH_CANCEL, we.core.Func.create(this.onTouchEndPageView, this));
        this.view.cc_onNodeEvent(this.view.RC_page_vipIcons.node, cc.Node.EventType.MOUSE_UP, we.core.Func.create(this.onTouchEndPageView, this));

        cc.director.on(we.common.EventName.VIP_EXP_CHANGE, this.renderUI, this);
        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.renderUI, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lockMask.active = false;
        this.initUI();

        // 拉取最新数据
        we.common.VIPConfig.init(() => {
            if (!this.isValid()) {
                return;
            }
            this.initUI();
        });
    }

    /** 隐藏窗口 */
    public destroy() {
        cc.director.off(we.common.EventName.VIP_EXP_CHANGE, this.renderUI, this);
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.renderUI, this);
    }

    public beforeUnload() {}

    private async initUI() {
        if (!we.common.VIPConfig.vipLevelConfig?.length) {
            return;
        }
        await this.renderVipIcons();
        this.renderUI();
    }

    private renderUI() {
        // 设置进度条
        let progress = 0;
        const vipExp = we.common.userMgr.vipExp;
        const totalLevel = we.common.VIPConfig.spe_user_vip_limit;
        let nextVip = we.common.VIPConfig.vipLevelConfig[vipExp.level + 1];
        if (!nextVip) {
            nextVip = we.common.VIPConfig.vipLevelConfig?.[we.common.VIPConfig.vipLevelConfig.length - 1];
        }

        // 设置升级文本
        if (vipExp.level == totalLevel) {
            this.view.RC_rich_vipUpTip.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_002);
            progress = 1;
        } else {
            const amount = nextVip.minBetAmount - vipExp.exp;
            if (amount <= 0) {
                // 后台修改经验值异常情况的特殊处理
                if (we.common.VIPConfig.experienceType === 0) {
                    this.view.RC_rich_vipUpTip.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_049));
                } else if (we.common.VIPConfig.experienceType === 1) {
                    this.view.RC_rich_vipUpTip.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_048));
                }
            } else {
                const amountStr = we.common.utils.formatAmount(amount, false);
                const langText = we.core.langMgr.getLangText(we.common.VIPConfig.experienceType ? HallLanguage.NEW_VIP_DESC_001_2 : HallLanguage.NEW_VIP_DESC_001_1);
                this.view.RC_rich_vipUpTip.setStringFormat(langText, amountStr, ` ${we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_001_3, vipExp.level + 1)}`);
            }

            progress = vipExp.exp / nextVip.minBetAmount;
        }
        // 设置经验
        this.view.RC_lab_progress.string = `${we.common.utils.formatAmount(vipExp.exp, false)}/${we.common.utils.formatAmount(nextVip.minBetAmount, false)}`;
        this.view.RC_bar_vipProgressBar.progress = progress;

        this.view.RC_btnGoGame1.active = we.common.VIPConfig.experienceType === 0;
        this.view.RC_btnGoRecharge1.active = we.common.VIPConfig.experienceType === 1;

        this.setCurrentPageIndex(vipExp.level - 1);
        this.renderLockMask(vipExp.level);
    }

    protected async renderVipIcons() {
        const toggleGroup = this.view.RC_page_vipIcons.content.addComponentUnique(we.ui.WEToggleGroup);
        const prefab = await this.loadAsset(HallRes.prefab.vip.VipToggleItem, cc.Prefab);

        for (let i = 1; i < we.common.VIPConfig.vipLevelConfig.length; i++) {
            if (toggleGroup.toggles[i - 1]) {
                continue;
            }
            const node = cc.instantiate(prefab);
            node.getComponent(VipToggleItem_h).init(i);
            this.view.RC_page_vipIcons.addPage(node);
            toggleGroup.addToggle(node.addComponentUnique(we.ui.WEToggle));
        }

        toggleGroup.setGroupMode(we.ui.ToggleGroupMode.SingleOne);
        toggleGroup.offListener();
        toggleGroup.onListener(
            we.core.Func.create((_: any, _isChecked: boolean, index: number) => {
                this.isToggleLock = true;
                this.setCurrentPageIndex(index);
            }, this)
        );
    }

    protected async renderRightsLayout() {
        const level = this.view.RC_page_vipIcons.getCurrentPageIndex() + 1;
        if (this.view.RC_rightsLayout.children.length) {
            this.view.RC_rightsLayout.children.forEach((child: cc.Node, index: number) => {
                const item = child.addComponentUnique(VipRightsItem_h);
                item.init(index, level, false);
            });
        } else {
            const prefab = await this.loadAsset(HallRes.prefab.vip.VipRightsItem, cc.Prefab);
            this.view.RC_rightsLayout.removeAllChildren();
            for (let i = 0; i < 4; i++) {
                const node = cc.instantiate(prefab);
                const item = node.addComponentUnique(VipRightsItem_h);
                item.init(i, level);
                this.view.RC_rightsLayout.addChild(node);
            }
        }

        this.view.RC_btnLeft.active = !(level == 1);
        this.view.RC_btnRight.active = !(level === we.common.VIPConfig.vipLevelConfig.length - 1);
    }

    protected renderLockMask(level: number) {
        if (level != 0) {
            this.view.RC_lockMask.active = false;
            return;
        }
        this.view.RC_lockMask.active = true;
        let maxSalary = 0;
        const config = we.common.VIPConfig.vipLevelConfig[we.common.VIPConfig.spe_user_vip_limit];
        for (const key in config.vipSalary) {
            maxSalary += config.vipSalary[key] || 0;
        }
        const lockTip1 = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_027);
        this.view.RC_rich_lockMask1.setStringFormat(lockTip1, ` ${we.common.utils.formatAmountCurrency(maxSalary, false)} `);

        if (we.common.VIPConfig.vipLevelConfig?.length > 1) {
            const lockTip2 = we.core.langMgr.getLangText(we.common.VIPConfig.experienceType ? HallLanguage.NEW_VIP_DESC_001_2 : HallLanguage.NEW_VIP_DESC_001_1);
            this.view.RC_rich_lockMask2.setStringFormat(lockTip2, ` ${we.common.utils.formatAmount(we.common.VIPConfig.vipLevelConfig[1].minBetAmount - we.common.userMgr.vipExp?.exp, false)} `, ` VIP1`);
        }

        this.view.RC_btnGoGame2.active = we.common.VIPConfig.experienceType === 0;
        this.view.RC_btnGoRecharge2.active = we.common.VIPConfig.experienceType === 1;
    }

    protected onChangeCurrentLevel(val: 1 | -1) {
        let index = this.view.RC_page_vipIcons.getCurrentPageIndex() + val;
        const len = we.common.VIPConfig.vipLevelConfig.length - 1;
        if (index < 0) {
            index = 0;
        } else if (index >= len) {
            index = len;
        }
        this.setCurrentPageIndex(index);
    }

    protected setCurrentPageIndex(index: number) {
        if (index < 0) {
            index = 0;
        }
        if (this.view.RC_page_vipIcons.getCurrentPageIndex() === index) {
            this.onPageVipIcon();
        } else {
            this.view.RC_page_vipIcons.setCurrentPageIndex(index);
        }
    }

    protected onClickGoGame() {
        HallMgr.openRecentGame(() => {
            if (cc.isValid(this.view.uiRoot)) {
                this.closeView();
            }
        });
    }

    protected onClickRecharge(): void {
        we.common.payMgr.trackFrom = we.common.JumpCmd.Vip;
        HallMgr.openStoreDlg();
    }

    protected onPageVipIcon() {
        this.isToggleLock = false;
        this.renderRightsLayout();
    }

    protected onTouchEndPageView() {
        if (this.isToggleLock) {
            return;
        }
        const index = this.view.RC_page_vipIcons.getCurrentPageIndex();
        const content = this.view.RC_page_vipIcons.content;
        const pageWidth = this.view.RC_page_vipIcons.getPages()[0]?.width;
        const newIndex = Math.abs(Math.floor((content.x + pageWidth / 2) / pageWidth));

        if (index != newIndex) {
            this.setCurrentPageIndex(newIndex);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(VipViewDlg_h, `${HallViewId.VipViewDlg}_h`)
class VipViewDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(VipViewDlg_h, uiBase.addComponent(VipViewDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipViewDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<VipViewDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(VipViewDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipViewDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(VipViewDlg_h).beforeUnload();
    }
}
