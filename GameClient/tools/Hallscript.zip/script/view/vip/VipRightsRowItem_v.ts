const { ccclass, property } = cc._decorator;

@ccclass
export default class VipRightsRowItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(title: string, value: string) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.RC_lab_title.string = title;
        this.RC_lab_value.string = value;
    }
}
