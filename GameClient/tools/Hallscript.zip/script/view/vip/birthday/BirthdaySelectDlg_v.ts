import { HallLanguage } from '../../../const/HallLanguage';
import { HallViewId } from '../../HallViewId';
import BirthdaySelectItem_v, { RenderType } from './BirthdaySelectItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('BirthdaySelectDlgView_v', we.bundles.hall)
class BirthdaySelectDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnConfirm: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_day: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_day: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_month: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_year: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_day: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_month: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_year: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_month: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_select: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_year: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('BirthdaySelectDlg_v', we.bundles.hall)
export class BirthdaySelectDlg_v extends we.ui.DlgSystem<BirthdaySelectDlgView_v> {
    private day: number = 1;
    private month: number = 1;
    private year: number = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_list_day.setRenderEvent(we.core.Func.create(this.onRenderItem, this, RenderType.Day));
        this.view.RC_list_day.setSelectedEvent(we.core.Func.create(this.onSelectItem, this, RenderType.Day));
        this.view.RC_list_month.setRenderEvent(we.core.Func.create(this.onRenderItem, this, RenderType.Month));
        this.view.RC_list_month.setSelectedEvent(we.core.Func.create(this.onSelectItem, this, RenderType.Month));
        this.view.RC_list_year.setRenderEvent(we.core.Func.create(this.onRenderItem, this, RenderType.Year));
        this.view.RC_list_year.setSelectedEvent(we.core.Func.create(this.onSelectItem, this, RenderType.Year));

        this.view.cc_onBtnClick(this.view.RC_select, we.core.Func.create(this.onClickSelect, this, null, false)).setSleepTime(0);
        this.view.cc_onBtnClick(this.view.RC_day, we.core.Func.create(this.onClickSelect, this, RenderType.Day)).setSleepTime(0);
        this.view.cc_onBtnClick(this.view.RC_month, we.core.Func.create(this.onClickSelect, this, RenderType.Month)).setSleepTime(0);
        this.view.cc_onBtnClick(this.view.RC_year, we.core.Func.create(this.onClickSelect, this, RenderType.Year)).setSleepTime(0);
        this.view.cc_onBtnClick(this.view.RC_btnConfirm, we.core.Func.create(this.onClickConfirm, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.initUI();
    }

    private initUI() {
        let curDate = new Date();
        this.year = curDate.getFullYear();
        this.month = curDate.getMonth() + 1;
        this.day = curDate.getDate();

        this.view.RC_lab_day.string = this.day.toString();
        this.view.RC_lab_month.string = we.core.langMgr.getLangText(HallLanguage[`MONTH_FULLNAME_MONTH${this.month}`]);
        this.view.RC_lab_year.string = this.year.toString();

        // 设置下拉选项
        this.view.RC_list_year.numItems = 70;
        this.view.RC_list_month.numItems = 12;
        this.view.RC_list_day.numItems = 31;

        this.view.RC_select.active = false;
        this.view.RC_list_day.node.active = false;
        this.view.RC_list_month.node.active = false;
        this.view.RC_list_year.node.active = false;
    }

    onRenderItem(type: RenderType, node: cc.Node, index: number) {
        let value = index + 1;
        if (type === RenderType.Year) {
            value = new Date().getFullYear() - index;
        }
        node.getComponent(BirthdaySelectItem_v).init(type, value);
    }

    onSelectItem(type: RenderType, node: cc.Node, index: number) {
        if (!node) {
            return;
        }
        const item = node.getComponent(BirthdaySelectItem_v);
        switch (type) {
            case RenderType.Day:
                if (this.day == item.value) {
                    return;
                }
                this.day = item.value;
                this.view.RC_lab_day.string = item.getValueString();
                break;
            case RenderType.Month:
                if (this.month == item.value) {
                    return;
                }
                this.month = item.value;
                this.view.RC_lab_month.string = item.getValueString();
                break;
            case RenderType.Year:
                if (this.year == item.value) {
                    return;
                }
                this.year = item.value;
                this.view.RC_lab_year.string = item.getValueString();
                break;
            default:
                break;
        }

        if (type != RenderType.Day) {
            let maxDayNum = new Date(this.year, this.month, 0).getDate();
            if (this.day > maxDayNum) {
                this.day = maxDayNum;
                this.view.RC_lab_day.string = this.day.toString();
            }
        }

        this.onClickSelect(type, false);
    }

    onClickSelect(type: RenderType, visible?: boolean) {
        const nodes = {
            [RenderType.Day]: this.view.RC_list_day,
            [RenderType.Month]: this.view.RC_list_month,
            [RenderType.Year]: this.view.RC_list_year,
        };
        let index = 0;
        let list: we.ui.List;

        for (const key in nodes) {
            if (Number(key) === type) {
                if (typeof visible !== 'boolean') {
                    visible = !nodes[key].node.active;
                }
                list = nodes[key];
            }
            nodes[key].node.active = false;
        }
        this.view.RC_select.active = visible;
        this.unSelectLable();
        if (!visible) {
            return;
        }
        switch (type) {
            case RenderType.Day:
                if (this.view.RC_lab_day.getComponent(we.ui.WENodeColorIndex)) {
                    this.view.RC_lab_day.getComponent(we.ui.WENodeColorIndex).setIndex(1);
                }
                this.view.RC_list_day.node.active = visible;
                index = this.day - 1;
                break;
            case RenderType.Month:
                if (this.view.RC_lab_month.getComponent(we.ui.WENodeColorIndex)) {
                    this.view.RC_lab_month.getComponent(we.ui.WENodeColorIndex).setIndex(1);
                }
                this.view.RC_list_month.node.active = visible;
                index = this.month - 1;
                break;
            case RenderType.Year:
                if (this.view.RC_lab_year.getComponent(we.ui.WENodeColorIndex)) {
                    this.view.RC_lab_year.getComponent(we.ui.WENodeColorIndex).setIndex(1);
                }
                this.view.RC_list_year.node.active = visible;
                index = new Date().getFullYear() - this.year;
                break;
            default:
                break;
        }

        list.selectedId = index;
        list.scrollTo(index);
    }

    onClickConfirm(): void {
        const changeInfo = {} as api.ModifyUserReq;
        changeInfo.birthday = new Date(this.year, this.month - 1, this.day, 12, 0, 0).getTime() / 1000;
        we.common.userMgr.updateChangeUserInfo(changeInfo, (data: api.ModifyUserResp) => {
            this.view.RC_btnConfirm.active = false;
            this.scheduleOnce(0.5).then(() => {
                we.common.VIPConfig.getVipAwardStatus(
                    () => {
                        we.common.userMgr.refreshUserInfo();
                    },
                    () => {
                        we.common.userMgr.refreshUserInfo();
                    }
                );
                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }
                this.closeView();
            });
        });
    }

    unSelectLable(): void {
        if (this.view.RC_lab_day.getComponent(we.ui.WENodeColorIndex)) {
            this.view.RC_lab_day.getComponent(we.ui.WENodeColorIndex).setIndex(0);
        }
        if (this.view.RC_lab_month.getComponent(we.ui.WENodeColorIndex)) {
            this.view.RC_lab_month.getComponent(we.ui.WENodeColorIndex).setIndex(0);
        }
        if (this.view.RC_lab_year.getComponent(we.ui.WENodeColorIndex)) {
            this.view.RC_lab_year.getComponent(we.ui.WENodeColorIndex).setIndex(0);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(BirthdaySelectDlg_v, `${HallViewId.BirthdaySelectDlg}_v`)
class BirthdaySelectDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(BirthdaySelectDlg_v, uiBase.addComponent(BirthdaySelectDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BirthdaySelectDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<BirthdaySelectDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(BirthdaySelectDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BirthdaySelectDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(BirthdaySelectDlg_v).beforeUnload();
    }
}
