import { HallLanguage } from '../../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

export enum RenderType {
    Year = 1,
    Month = 2,
    Day = 3,
}

@ccclass
export default class BirthdaySelectItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_value1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_value2: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    value = 0;

    type: RenderType;

    init(type: RenderType, value: number) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.value = value;
        this.type = type;

        const str = this.getValueString();
        this.RC_lab_value1.string = str;
        this.RC_lab_value2.string = str;
    }

    getValueString() {
        let str = `${this.value}`;
        if (this.type === RenderType.Month) {
            str = we.core.langMgr.getLangText(HallLanguage[`MONTH_FULLNAME_MONTH${this.value}`]);
        }
        return str;
    }
}
