import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import VipRightsItem_v from './VipRightsItem_v';
import VipToggleItem_v from './VipToggleItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('VipViewDlgView_v', we.bundles.hall)
class VipViewDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_bottomInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnAdd: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoGame1: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoGame2: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoRecharge1: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoRecharge2: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_progress: cc.Label = null;

    @we.ui.ccBind(cc.Layout)
    public RC_layout_rights: cc.Layout = null;

    @we.ui.ccBind(cc.Node)
    public RC_lockMask: cc.Node = null;

    @we.ui.ccBind(cc.PageView)
    public RC_page_vipIcons: cc.PageView = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_lockMask1: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_lockMask2: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_vipUpTip: we.ui.WERichTags = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('VipViewDlg_v', we.bundles.hall)
export class VipViewDlg_v extends we.ui.DlgSystem<VipViewDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_page_vipIcons.node.on('page-turning', this.onPageVipIcon, this);
        this.view.cc_onBtnClick(this.view.RC_btnGoGame1, we.core.Func.create(this.onClickGoGame, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnGoGame2, we.core.Func.create(this.onClickGoGame, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnGoRecharge1, we.core.Func.create(this.onClickRecharge, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnGoRecharge2, we.core.Func.create(this.onClickRecharge, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnAdd, we.core.Func.create(this.onClickRecharge, this));

        cc.director.on(we.common.EventName.VIP_EXP_CHANGE, this.initUI, this);
        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.initUI, this);
        cc.director.on(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
    }

    public async onShow(showData?: any) {
        this.initUI();

        // 拉取最新数据
        we.common.VIPConfig.init(() => {
            if (!this.isValid() || !we.common.VIPConfig.vipLevelConfig?.length) {
                return;
            }
            this.initUI();
        });
    }

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(we.common.EventName.VIP_EXP_CHANGE, this.initUI, this);
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.initUI, this);
        cc.director.off(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
    }

    private async initUI() {
        if (!we.common.VIPConfig.vipLevelConfig?.length) {
            return;
        }
        await this.renderVipIcons();
        const userVipInfo = we.common.userMgr.vipExp;
        this.view.RC_page_vipIcons.setCurrentPageIndex(userVipInfo.level - 1);
        const coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
        this.view.RC_lab_amount.string = we.common.utils.formatAmountCurrency(coin);
        this.onPageVipIcon();
        this.renderCenterInfo();
    }

    private onClickRecharge() {
        this.closeView();
        HallMgr.openStoreDlg();
    }

    private async renderVipIcons() {
        const toggleGroup = this.view.RC_page_vipIcons.content.addComponentUnique(we.ui.WEToggleGroup);
        const prefab = await this.loadAsset(HallRes.prefab.vip.VipToggleItem, cc.Prefab);
        const pages = this.view.RC_page_vipIcons.getPages();
        for (let i = 1; i < we.common.VIPConfig.vipLevelConfig.length; i++) {
            if (pages[i - 1]) {
                continue;
            }
            const node = cc.instantiate(prefab);
            node.getComponent(VipToggleItem_v).init(i);
            this.view.RC_page_vipIcons.addPage(node);
            toggleGroup.addToggle(node.addComponentUnique(we.ui.WEToggle));
        }
        const userVipInfo = we.common.userMgr.vipExp;
        let index = userVipInfo.level - 1;
        if (index < 0) {
            index = 0;
        }

        toggleGroup.setGroupMode(we.ui.ToggleGroupMode.SingleOne);
        toggleGroup.offListener();
        toggleGroup.onListener(
            we.core.Func.create((_: any, _isChecked: boolean, index: number) => {
                this.view.RC_page_vipIcons.setCurrentPageIndex(index);
            }, this)
        );

        this.view.RC_page_vipIcons.setCurrentPageIndex(index);
    }

    private onPageVipIcon() {
        const index = this.view.RC_page_vipIcons.getCurrentPageIndex();
        const pages = this.view.RC_page_vipIcons.getPages();
        pages.forEach((page, i) => {
            if (i === index) {
                page.getComponent(VipToggleItem_v).select();
            } else {
                page.getComponent(VipToggleItem_v).unSelect();
            }
        });
        this.renderRightsLayout();
    }

    private renderCenterInfo() {
        const userVipInfo = we.common.userMgr.vipExp;
        const langText = we.core.langMgr.getLangText(we.common.VIPConfig.experienceType ? HallLanguage.NEW_VIP_DESC_001_2 : HallLanguage.NEW_VIP_DESC_001_1);
        if (userVipInfo.level == 0) {
            if (we.common.VIPConfig.vipLevelConfig?.length > 1) {
                const amount = we.common.VIPConfig.vipLevelConfig[1]?.minBetAmount - userVipInfo.exp;
                this.view.RC_rich_vipUpTip.setStringFormat(langText, we.common.utils.formatAmount(amount, false), ` ${we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_001_3, userVipInfo.level + 1)} `);
            }
        } else {
            if (userVipInfo.level == we.common.VIPConfig.spe_user_vip_limit) {
                this.view.RC_rich_vipUpTip.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_002);
            } else {
                const amount = we.common.VIPConfig.vipLevelConfig?.[userVipInfo.level + 1]?.minBetAmount - userVipInfo.exp;
                if (amount <= 0) {
                    // 后台修改经验值异常情况的特殊处理
                    if (we.common.VIPConfig.experienceType === 0) {
                        this.view.RC_rich_vipUpTip.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_049));
                    } else if (we.common.VIPConfig.experienceType === 1) {
                        this.view.RC_rich_vipUpTip.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_048));
                    }
                } else {
                    const amountStr = we.common.utils.formatAmount(amount, false);
                    this.view.RC_rich_vipUpTip.setStringFormat(langText, amountStr, ` ${we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_001_3, userVipInfo.level + 1)} `);
                }
            }
        }

        // 设置经验
        let nextVip = we.common.VIPConfig.vipLevelConfig?.[userVipInfo.level + 1];
        if (!nextVip) {
            nextVip = we.common.VIPConfig.vipLevelConfig?.[we.common.VIPConfig.vipLevelConfig.length - 1];
        }
        this.view.RC_lab_progress.string = `${we.common.utils.formatAmount(userVipInfo.exp, false)}/${we.common.utils.formatAmount(nextVip.minBetAmount)}`;

        this.view.RC_lockMask.active = false;
        this.view.RC_rich_vipUpTip.node.active = true;

        this.view.RC_btnGoGame1.active = we.common.VIPConfig.experienceType === 0;
        this.view.RC_btnGoRecharge1.active = we.common.VIPConfig.experienceType === 1;

        this.renderLockMask(userVipInfo.level);
    }

    private renderLockMask(level: number) {
        if (level != 0) {
            this.view.RC_bottomInfo.active = true;
            this.view.RC_lockMask.active = false;
            return;
        }
        this.view.RC_lockMask.active = true;
        this.view.RC_bottomInfo.active = false;
        let maxSalary = 0;
        const config = we.common.VIPConfig.vipLevelConfig[we.common.VIPConfig.spe_user_vip_limit];
        for (const key in config.vipSalary) {
            maxSalary += config.vipSalary[key] || 0;
        }
        const lockTips1 = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_027);
        this.view.RC_rich_lockMask1.setStringFormat(lockTips1, ` ${we.common.utils.formatAmountCurrency(maxSalary, false)} `);

        if (we.common.VIPConfig.vipLevelConfig?.length > 1) {
            const lockTips2 = we.core.langMgr.getLangText(we.common.VIPConfig.experienceType ? HallLanguage.NEW_VIP_DESC_001_2 : HallLanguage.NEW_VIP_DESC_001_1);
            this.view.RC_rich_lockMask2.setStringFormat(lockTips2, ` ${we.common.utils.formatAmount(we.common.VIPConfig.vipLevelConfig[1].minBetAmount - we.common.userMgr.vipExp?.exp, false)} `, ` VIP1 `);
        }

        this.view.RC_btnGoGame2.active = we.common.VIPConfig.experienceType === 0;
        this.view.RC_btnGoRecharge2.active = we.common.VIPConfig.experienceType === 1;
    }

    private renderRightsLayout() {
        const level = this.view.RC_page_vipIcons.getCurrentPageIndex() + 1;
        const layout = this.view.RC_layout_rights.node;
        if (layout.children.length === 4) {
            layout.children.forEach((child, index) => {
                child.getComponent(VipRightsItem_v).init(index, level);
            });
        } else {
            this.loadAsset(HallRes.prefab.vip.VipRightsItem, cc.Prefab).then((prefab) => {
                for (let i = 0; i < 4; i++) {
                    const node = layout.children[i] || cc.instantiate(prefab);
                    node.getComponent(VipRightsItem_v).init(i, level);
                    if (!layout.children[i]) {
                        layout.addChild(node);
                    }
                }
            });
        }
    }

    private onClickGoGame() {
        HallMgr.openRecentGame(() => {
            if (cc.isValid(this.view.uiRoot)) {
                this.closeView();
            }
        });
    }

    private coinFlyAnim(params: { node: cc.Node; award: number }) {
        HallMgr.coinFlyAnim(params, this.view.uiRoot, this.view.RC_lab_amount.node, false);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(VipViewDlg_v, `${HallViewId.VipViewDlg}_v`)
class VipViewDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(VipViewDlg_v, uiBase.addComponent(VipViewDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipViewDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<VipViewDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(VipViewDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipViewDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(VipViewDlg_v).beforeUnload();
    }
}
