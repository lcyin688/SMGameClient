import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('VipRightsGetDlgView_h', we.bundles.hall)
class VipRightsGetDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnCancel: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnConfirm: cc.Node = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_need: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_progress: we.ui.WERichTags = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('VipRightsGetDlg_h', we.bundles.hall)
export class VipRightsGetDlg_h extends we.ui.DlgSystem<VipRightsGetDlgView_h> {
    private needAmount = 0;
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnCancel, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnConfirm, we.core.Func.create(this.onClickBtnConfirm, this));
    }

    /** 显示窗口 */
    public async onShow(showData: { salaryRechargeAmount?: number; rechargeAmount?: number }) {
        if (!showData) {
            this.closeView();
            return;
        }
        const need = Math.floor(showData.salaryRechargeAmount - showData.rechargeAmount);
        this.needAmount = need || 0;
        this.view.RC_rich_need.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_039), ` ${we.common.utils.formatPrice(this.needAmount, true, false)}`);

        this.view.RC_rich_progress.setStringFormat('{0}', we.common.utils.formatPrice(showData.rechargeAmount, true, false));
        this.view.RC_rich_progress.setStringFormat(this.view.RC_rich_progress.string + ' / ' + we.common.utils.formatPrice(showData.salaryRechargeAmount, true, false));
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    public onClickBtnConfirm() {
        we.common.payMgr.trackFrom = we.common.JumpCmd.Vip;
        HallMgr.openStoreDlg(this.needAmount);
        this.closeView();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(VipRightsGetDlg_h, `${HallViewId.VipRightsGetDlg}_h`)
class VipRightsGetDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(VipRightsGetDlg_h, uiBase.addComponent(VipRightsGetDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipRightsGetDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<VipRightsGetDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(VipRightsGetDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipRightsGetDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(VipRightsGetDlg_h).beforeUnload();
    }
}
