import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class BankRecordItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnInterest: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bankBalance: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_event: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_interest: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_tipsPos: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private clickCallBack: Function = null;

    private eventType: string = null;

    protected onLoad(): void {
        this.onBtnClick(this.RC_btnInterest, we.core.Func.create(this.onClickInterest, this));
    }

    public init(record: api.BankRecord, clickCallBack: Function): void {
        this.__initRc();

        this.clickCallBack = clickCallBack;

        this.eventType = record.eventType;
        this.RC_lab_event.string = this.getEventTypeLang(record.eventType);

        this.RC_lab_amount.node.active = false;
        this.RC_btnInterest.active = false;
        if (record.eventType == we.common.BankRecordEventType.interest) {
            this.RC_btnInterest.active = true;
            this.RC_lab_interest.string = we.common.utils.formatAmountCurrency(record.amount);
        } else {
            this.RC_lab_amount.node.active = true;
            this.RC_lab_amount.string = we.common.utils.formatAmountCurrency(record.amount);
        }

        this.RC_lab_bankBalance.string = we.common.utils.formatAmountCurrency(record.balance);
        this.RC_lab_time.string = '' + we.common.utils.formatDate(new Date(record.time * 1000), we.core.flavor.getCountryDateFormate() + ' hh:mm:ss');
    }

    private onClickInterest(): void {
        if (this.eventType != we.common.BankRecordEventType.interest) {
            return;
        } 

        typeof this.clickCallBack == 'function' && this.clickCallBack(this.RCN_tipsPos);
    }

    private getEventTypeLang(eventType: string): string {
        let eventStr = '';
        let langKey = null;
        switch (eventType) {
            case we.common.BankRecordEventType.all:
                langKey = HallLanguage.BANK_RECORD_2;
                break;
            case we.common.BankRecordEventType.stockIn:
                langKey = HallLanguage.BANK_RECORD_5;
                break;
            case we.common.BankRecordEventType.stockOut:
                langKey = HallLanguage.BANK_RECORD_4;
                break;
            case we.common.BankRecordEventType.interest:
                langKey = HallLanguage.BANK_RECORD_3;
                break;
            default:
                break;
        }
        if (langKey) {
            eventStr = we.core.langMgr.getLangText(langKey);
        }

        return eventStr;
    }
}
