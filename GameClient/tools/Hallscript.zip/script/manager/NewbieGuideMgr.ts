import { HallRes } from '../config/HallRes';
import { HallViewId } from '../view/HallViewId';

/**
 * 引导数据
 */
interface ModData {
    mod: string;
    step: number;
}

class NewbieGuideMgr {
    public ModGuide = {
        WITHDRAW: 'withdraw',
    };

    private _ModGuideConfig = {
        withdraw_bg: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-397, -310),
                hasArrow: true,
                arrowPos: cc.v2(-370, -290),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-300, -210),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(520, 90),
                visibleCircleRadius: 0,
                pos: cc.v2(136, 141),
                hasArrow: true,
                arrowPos: cc.v2(136, 140),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 240),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_bg2: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-397, -310),
                hasArrow: true,
                arrowPos: cc.v2(-400, -260),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-500, -150),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                id: 2,
                size: cc.size(400, 100),
                visibleCircleRadius: 0,
                pos: cc.v2(130, 175),
                hasArrow: true,
                arrowPos: cc.v2(120, 170),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(150, 290),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_ct: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-368, -318),
                hasArrow: true,
                arrowPos: cc.v2(-329, -300),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-171, -192),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(680, 110),
                visibleCircleRadius: 0,
                pos: cc.v2(120, 170),
                hasArrow: true,
                arrowPos: cc.v2(40, 160),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 250),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_ct2: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-386, -290),
                hasArrow: true,
                arrowPos: cc.v2(-330, -300),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-270, -157),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(680, 110),
                visibleCircleRadius: 0,
                pos: cc.v2(130, 180),
                hasArrow: true,
                arrowPos: cc.v2(80, 160),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 260),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_ct3: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-425, -300),
                hasArrow: true,
                arrowPos: cc.v2(-380, -300),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-270, -165),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(720, 100),
                visibleCircleRadius: 0,
                pos: cc.v2(130, 175),
                hasArrow: true,
                arrowPos: cc.v2(80, 160),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 265),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_ct4: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-165, -578),
                hasArrow: true,
                arrowPos: cc.v2(-150, -550),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(0, -500),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(680, 120),
                visibleCircleRadius: 0,
                pos: cc.v2(0, 219),
                hasArrow: true,
                arrowPos: cc.v2(0, 197),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(0, 273),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_cm1: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-425, -300),
                hasArrow: true,
                arrowPos: cc.v2(-380, -300),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-270, -165),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(400, 100),
                visibleCircleRadius: 0,
                pos: cc.v2(130, 175),
                hasArrow: true,
                arrowPos: cc.v2(80, 160),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 265),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_cm2: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-425, -300),
                hasArrow: true,
                arrowPos: cc.v2(-380, -300),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-270, -165),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(400, 100),
                visibleCircleRadius: 0,
                pos: cc.v2(130, 175),
                hasArrow: true,
                arrowPos: cc.v2(80, 160),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 265),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_cm3: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 90,
                pos: cc.v2(-425, -300),
                hasArrow: true,
                arrowPos: cc.v2(-380, -300),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-320, -165),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(370, 80),
                visibleCircleRadius: 0,
                pos: cc.v2(130, 175),
                hasArrow: true,
                arrowPos: cc.v2(80, 160),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 265),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_cm4: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-165, -578),
                hasArrow: true,
                arrowPos: cc.v2(-158, -556),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(0, -470),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(648, 80),
                visibleCircleRadius: 0,
                pos: cc.v2(0, 166),
                hasArrow: true,
                arrowPos: cc.v2(-60, 197),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(98, 283),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_cm5: [
            {
                // 引导点击提现按钮
                id: 1,
                size: cc.size(230, 80),
                visibleCircleRadius: 0,
                pos: cc.v2(200, 300),
                hasArrow: true,
                arrowPos: cc.v2(193, 290),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(366, 160),
                tips: [],
                textbg: 'text_bg3',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(370, 80),
                visibleCircleRadius: 0,
                pos: cc.v2(-407, -80),
                hasArrow: true,
                arrowPos: cc.v2(-400, -80),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(-340, -200),
                tips: [],
                textbg: 'text_bg3',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_cm6: [
            {
                // 引导点击提现按钮
                id: 1,
                size: cc.size(160, 100),
                visibleCircleRadius: 62,
                pos: cc.v2(-410, -430),
                hasArrow: true,
                arrowPos: cc.v2(-380, -430),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-300, -300),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(400, 100),
                visibleCircleRadius: 0,
                pos: cc.v2(130, 175),
                hasArrow: true,
                arrowPos: cc.v2(80, 160),
                arrowAngle: -90,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(240, 265),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
        withdraw_as: [
            {
                // 引导点击提现按钮
                id: 1,
                size: null,
                visibleCircleRadius: 62,
                pos: cc.v2(-165, -550),
                hasArrow: true,
                arrowPos: cc.v2(-165, -520),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_001',
                arrowTipPos: cc.v2(-165, -450),
                tips: [],
                textbg: 'text_bg2',
                select_frame: '',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
            {
                // 引导绑定
                id: 2,
                size: cc.size(680, 160),
                visibleCircleRadius: 0,
                pos: cc.v2(0, 140),
                hasArrow: true,
                arrowPos: cc.v2(0, 130),
                arrowAngle: 0,
                arrowLangKey: 'WITHDRAW_HALL_GUIDE_002',
                arrowTipPos: cc.v2(0, 255),
                tips: [],
                textbg: 'text_bg2',
                select_frame: 'select_frame1',
                needAdap: false,
                adaptNotch: {
                    enable: false,
                    left: 0,
                    right: 0,
                },
            },
        ],
    };

    public modGuideConfig(type: string) {
        const skin = we.core.flavor.getSkinCode();
        const nameKey = `${type}_${skin}`;
        // eslint-disable-next-line no-prototype-builtins
        if (this._ModGuideConfig.hasOwnProperty(nameKey)) {
            // 如果存在，则返回对应的游戏引导配置
            return this._ModGuideConfig[nameKey];
        } else {
            // eslint-disable-next-line no-prototype-builtins
            if (this._ModGuideConfig.hasOwnProperty(type)) {
                return this._ModGuideConfig[type];
            }
            return [];
        }
    }

    private _diffPos: cc.Vec2 = cc.v2(0, 0);
    public get diffPos(): cc.Vec2 {
        return this._diffPos;
    }
    public modifyDiffPos(pos: cc.Vec2) {
        this._diffPos = pos;
    }

    /** 玩法推荐 */
    public playRecommendData: { [k: string]: number } = null;
    /** 大厅引导步骤数 */
    private modGuideStep: number = 0;
    private curModGuideStep: number = 0;
    private curModGuideName: string = '';

    isFinish: boolean = true;
    isFinishHall: boolean = true;

    isShowPropGuide: boolean = false;

    guideCache = {};
    guideList = [];
    isGuiding: boolean = false; // 正在引导中
    /** 完成初始化 */
    isFinishInit: boolean = false;

    set CurModGuideStep(step: number) {
        this.curModGuideStep = step;

        this.saveGuideData();
        if (this.curModGuideStep > this.modGuideStep) {
            let idx = this.guideList.indexOf(this.curModGuideName);
            this.guideList.splice(idx, 1);

            if (this.guideList.length == 0) {
                this.isFinishHall = true;
            }
            this.modGuideStep = 0;
            this.curModGuideStep = 0;
            this.curModGuideName = '';
        }
    }

    get CurModGuideStep() {
        return this.curModGuideStep;
    }

    get ModGuideStep() {
        return this.modGuideStep;
    }

    public init() {
        if (this.isFinishInit) {
            return;
        }
        this.isFinishInit = true;
        this.isGuiding = false;

        this.guideCache = we.common.storage?.get('common', 'game_guide_modules') || {};
        if (we.common.userMgr.isNewbie) {
            this.isFinish = false;
            this.isFinishHall = false;
        } else {
            this.isFinish = true;
            this.isFinishHall = true;
        }
        we.common.storage.setById('common', 'game_guide_modules', this.guideCache);

        this.guideList = [];

        this.guideList.push(this.ModGuide.WITHDRAW);
        this.isFinishHall = true;
        // eslint-disable-next-line space-in-parens
        for (let i = 0; i < this.guideList.length; ) {
            let name = this.guideList[i];
            let step = this.guideCache[name] ? this.guideCache[name] : 1;

            if (step > this.modGuideConfig(name).length) {
                this.guideList.splice(i, 1);
            } else {
                i++;
            }
        }
        this.isFinishHall = this.guideList.length == 0 ? true : false;
        this.isFinish = this.isFinishHall;

        if (!this.isFinish) {
            // 提前 加载
            we.core.assetMgr.preloadAsset(HallRes.prefab.ForceGuideDlg, cc.Prefab);
        }
    }

    /**
     * 重置初始化状态
     */
    public reset() {
        this.isFinishInit = false;
    }

    public IsInGuide() {
        return !this.isFinish;
    }

    public IsInHallGuide() {
        return !this.isFinishHall && !this.isFinish && this.isGuiding;
    }

    public judgeStartModGuide(modData: ModData[]) {
        if (this.isFinish || this.isFinishHall || !(we.core.gameConfig.curGameId == we.GameId.HALL)) {
            return false;
        }

        // eslint-disable-next-line space-in-parens
        for (let i = 0; i < modData.length; ) {
            let name = modData[i].mod;

            let idx = this.guideList.indexOf(name);
            if (idx < 0) {
                modData.splice(i, 1);
            } else {
                i++;
            }
        }

        let find = false;
        for (let i = 0; i < modData.length; i++) {
            this.curModGuideStep = this.guideCache[modData[i].mod] ? this.guideCache[modData[i].mod] : 1;
            this.curModGuideName = modData[i].mod;

            if (this.curModGuideStep == modData[i].step) {
                if (modData[i].step == 1) {
                    let canGuide = false;
                    switch (modData[i].mod) {
                        case this.ModGuide.WITHDRAW:
                            if (!we.core.projectConfig.settingsConfig?.withdrawGuide) {
                                break;
                            }

                            if (
                                we.common.userMgr.userInfo.gold > we.core.projectConfig.settingsConfig.withdrawGuide.carry &&
                                we.common.withdrawMgr.judgeIsShowWithdraw() &&
                                we.core.gameConfig.getSceneFrom() == we.SceneFrom.Game
                            ) {
                                canGuide = true;
                            }
                            break;
                        default:
                            break;
                    }
                    if (canGuide) {
                        find = true;
                        break;
                    } else {
                        continue;
                    }
                } else if (this.curModGuideStep <= this.modGuideConfig(modData[i].mod).length) {
                    find = true;
                    break;
                }
                break;
            }
        }
        if (find) {
            this.modGuideStep = this.modGuideConfig(this.curModGuideName).length;

            if (this.curModGuideName == this.ModGuide.WITHDRAW && this.curModGuideStep == 2) {
                let showConf = {
                    uiConfig: {
                        viewType: we.ui.type.UIViewType.Top,
                    },
                };

                we.currentUI.showSafe(HallViewId.ForceGuideDlg, this.curModGuideName, showConf);

                return true;
            }

            we.currentUI.showSafe(HallViewId.ForceGuideDlg, this.curModGuideName);

            return true;
        }

        return false;
    }

    public saveGuideData() {
        this.guideCache[this.curModGuideName] = this.curModGuideStep;

        we.common.storage.setById('common', 'game_guide_modules', this.guideCache);
    }

    /**
     * 移除单个引导模块 并完成
     * @param mod
     */
    public removeModGuide(mod: string) {
        let idx = this.guideList.indexOf(mod);
        if (idx >= 0) {
            this.guideList.splice(idx, 1);
        }

        this.guideCache[mod] = this.modGuideConfig(mod).length + 1;
        we.common.storage.setById('common', 'game_guide_modules', this.guideCache);
    }

    /**
     * 获取引导模块
     * @returns
     */
    public getModGuides() {
        let modGuide = [];
        modGuide.push({ mod: this.ModGuide.WITHDRAW, step: 1 });

        return modGuide;
    }
}

export default new NewbieGuideMgr();
