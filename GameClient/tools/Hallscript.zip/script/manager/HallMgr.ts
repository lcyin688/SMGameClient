import { HallRes } from '../config/HallRes';
import { HallPageEnum } from '../const/HallConst';
import { HallLanguage } from '../const/HallLanguage';
import { HallViewId } from '../view/HallViewId';
import HallGameListMgr from './HallGameListMgr';
import NewbieGuideMgr from './NewbieGuideMgr';

/** app 授权类型枚举 */
enum Permission_Type {
    /** 通知权限 */
    NOTIFICATION = 1,
}

class HallMgr {
    private static _ins: HallMgr = null;
    public static ins(): HallMgr {
        if (!this._ins) {
            this._ins = new HallMgr();
        }

        return this._ins;
    }

    public Permission_Type = Permission_Type;

    /**
     * 飞金币动画
     * @param params node金币初始位置节点，award领取金额
     */
    public coinFlyAnim(params: { node: cc.Node; award: number }, node, coin_lab: cc.Node, isPlayEffect: boolean = true): void {
        if (!params || !cc.isValid(node) || !cc.isValid(params.node) || !node.activeInHierarchy) {
            return;
        }

        let topNode = we.ui.UILayer.top;
        if (!topNode) {
            return;
        }

        let coinNodeList = [];
        let startNodeWorldPos = params.node.parent.convertToWorldSpaceAR(params.node.position);
        let targetNodeWorldPos = coin_lab.parent.convertToWorldSpaceAR(coin_lab.position);
        let targetNodePos = topNode.convertToNodeSpaceAR(targetNodeWorldPos);

        // 初始位置随机
        let randPos = () => {
            let randX = Math.random() * 50 * (Math.random() > 0.5 ? 1 : -1) + startNodeWorldPos.x;
            let randY = Math.random() * 50 * (Math.random() > 0.5 ? 1 : -1) + startNodeWorldPos.y;
            return cc.v2(randX, randY);
        };

        // 计算生成金币个数，1-5万3个，5-10万5个，10万以上8个
        let getCoinNum = (award: number) => {
            let coinNum = 0;
            if (award < 50000) {
                coinNum = 3;
            } else if (award < 100000) {
                coinNum = 5;
            } else {
                coinNum = 8;
            }
            return coinNum;
        };

        we.core.assetMgr.loadAsset(HallRes.animation.coinAnim, sp.SkeletonData, (skeletonData) => {
            if (!skeletonData) {
                return;
            }
            for (let i = 0; i < getCoinNum(params.award); i++) {
                let node = new cc.Node();
                let anim = node.addComponent(sp.Skeleton);
                topNode.addChild(node);
                anim.skeletonData = skeletonData;
                anim.defaultSkin = 'default';
                anim.setAnimation(0, 'animation', true);
                let startNodePos = topNode.convertToNodeSpaceAR(randPos());
                node.setPosition(startNodePos);
                coinNodeList.push(node);
            }
            setTimeout(() => {
                coinNodeList.forEach((item, index) => {
                    setTimeout(() => {
                        if (!cc.isValid(node)) {
                            we.common.userMgr.onSyncUserCoinInfo();
                            item.destroy();
                            return;
                        }
                        cc.tween(item)
                            .to(0.2, { position: targetNodePos, scale: 0.2 })
                            .call(() => {
                                item.destroy();
                                if (!cc.isValid(coin_lab)) {
                                    we.common.userMgr.onSyncUserCoinInfo();
                                }
                                if (index == 0) {
                                    // 第一个结束开始滚动
                                    if (isPlayEffect) {
                                        we.core.audioMgr.playEffect(HallRes.audio.ding);
                                        we.core.audioMgr.playEffect(HallRes.audio.addCoinsEfc);
                                    }
                                    let start = we.common.userMgr.userInfo.gold;
                                    let end = start + params.award;
                                    let time = (coinNodeList.length - 1) * 0.05 + 0.2;
                                    if (cc.isValid(coin_lab)) {
                                        we.common.utils.labelNumRoll(
                                            coin_lab.getComponent(cc.Label),
                                            start,
                                            end,
                                            time,
                                            () => {
                                                we.common.userMgr.onSyncUserCoinInfo();
                                            },
                                            true
                                        );
                                    }
                                }
                            })
                            .start();
                    }, 50 * index);
                });
            }, 500);
        });
    }

    /**
     * 充值获取金币弹窗
     * @param coins
     * @param vpChange
     */
    public async openChargeSucceedDlg(coins: number, type?: string) {
        if (!we.common.userMgr.isLogin()) {
            return;
        }

        we.currentUI.showFIFO(HallViewId.GetCoinsAndVpDlg, coins, type);
    }

    /**
     * 领取奖励弹窗
     * @param id
     * @param num
     */
    public async openGetAwardsDlg(award: { id: number; num: number }[] | { [k: string]: number }, closeCallback?: Function) {
        if (!we.common.userMgr.isLogin()) {
            return;
        }

        if (!award || !(award instanceof Array || award instanceof Object)) {
            return;
        }

        let awardArr: { id: number; num: number }[] = [];
        if (award instanceof Array) {
            awardArr = award;
        } else {
            for (let key in award) {
                if (parseInt(key) == 11) {
                    awardArr.push({ id: 0, num: award[key] });
                } else {
                    awardArr.push({ id: parseInt(key), num: award[key] });
                }
            }
        }

        if (awardArr.length < 1) {
            return;
        }

        const dlg = await we.currentUI.show(HallViewId.GetSingPropDlg, awardArr);
        await dlg.waitClose();
        closeCallback?.();
    }

    /**
     * 商城
     * @param preFilledAmount 预填充值金币数
     */
    public openStoreDlg(preFilledAmount: number = 0): Promise<void> {
        we.common.storeMgr.prefillAmount = preFilledAmount;
        return we.currentUI.getDlg(HallViewId.HallDlg)?.onShow(HallPageEnum.shop);
    }

    /**
     * 商城银行弹窗
     * @param data
     * @param rechargeAmount
     */
    public openStoreBankSelectDlg(data: number | api.Banks[], rechargeAmount: number, callback?: (bank?: string) => void) {
        we.currentUI.show(HallViewId.StoreBankDlg, {
            data,
            amount: rechargeAmount,
            callback,
        });
    }

    /**
     * 新手礼包
     * @param showLoading
     */
    public openNewbieGiftBag(showLoading: boolean = true, parent?: cc.Node): Promise<void> {
        return new Promise((resolve) => {
            let cb = async () => {
                if (we.core.gameConfig.curGameId == we.GameId.HALL) {
                    await we.currentUI.show(HallViewId.NewbieGiftBagDlg);
                }
                resolve();
            };

            // 每次打开新手礼包均需获取最新配置
            we.common.storeMgr.initNewbieGiftBag(cb, showLoading);
        });
    }

    /**
     * 活动状态提示
     * @param startTime 开启时间 单位：s
     * @param endTime 结束时间  单位：s
     */
    public activityStatusTips(startTime: number = -1, endTime: number = -1): void {
        if (startTime > 0 || endTime > 0) {
            let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
            if (curTime < startTime) {
                let startStr = we.common.utils.formatDate(new Date(startTime * 1000), 'DD/MM/YYYY hh:mm');
                let endStr = we.common.utils.formatDate(new Date(endTime * 1000), 'DD/MM/YYYY hh:mm');
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_43, startStr, endStr));
            } else if (curTime > endTime) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_44));
            }
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.ACTIVTY_TIPS_1));
        }
    }

    /**
     * 提现
     * @returns
     */
    public openWithdraw(): boolean {
        // 账号类型判定
        if (!we.common.userMgr.isFormal()) {
            if (NewbieGuideMgr.IsInHallGuide()) {
                cc.director.emit(we.common.EventName.UPDATE_GUIDE_STEP);
            }
            we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
            return false;
        }

        // 提现次数判定下载官方包，仅针对马甲包和 h5 苹果相关系统不做处理
        if (we.common.downloadGuideMgr.isOpenGuide(we.common.downloadGuideMgr.Type.Withdraw)) {
            if (NewbieGuideMgr.IsInHallGuide()) {
                cc.director.emit(we.common.EventName.ON_HIDE_GUIDE); // 关闭引导
            }
            we.currentUI.show(HallViewId.WithdrawGuideDownloadDlg);
            return false;
        }

        if (!we.common.withdrawMgr.openNormalChn && !we.common.withdrawMgr.openVipChn) {
            if (NewbieGuideMgr.IsInHallGuide()) {
                cc.director.emit(we.common.EventName.ON_HIDE_GUIDE); // 关闭引导
            }
            // 全部提现通道已关闭
            cc.director.emit(we.common.EventName.HALL_IS_SHOW_WITHDRAW, false);
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20087));
            return false;
        }

        if (NewbieGuideMgr.IsInHallGuide()) {
            cc.director.emit(we.common.EventName.UPDATE_GUIDE_STEP);
        }
        we.currentUI.getDlg(HallViewId.HallDlg)?.onShow(HallPageEnum.withdraw);

        return true;
    }

    /**
     * 打开提现账号信息弹窗
     * @param data 账号信息
     * @param isAdd 新增账号
     * @returns
     */
    public openWithdrawAccountInfoDlg(data: api.UserBankInfo, isAdd: boolean = false): void {
        if (!data) {
            we.warn(`HallMgr openWithdrawAccountInfoDlg, data is null`);
            return;
        }

        let viewId = HallViewId.WithdrawAccountInfoDlg;
        if (we.common.payMgr.isDigitalPay(data.channelType)) {
            viewId = HallViewId.WithdrawAccountInfoDigitalDlg;
        } else {
            let countryCode = we.core.flavor.getCountryCode();
            switch (countryCode) {
                case we.core.CountryCode.br:
                    viewId = HallViewId.WithdrawAccountInfoBRDlg;
                    break;
                case we.core.CountryCode.in:
                    viewId = HallViewId.WithdrawAccountInfoINDlg;
                    break;
                case we.core.CountryCode.ph:
                case we.core.CountryCode.vn:
                    viewId = HallViewId.WithdrawAccountInfoPHDlg;
                    break;
                default:
                    break;
            }
        }

        we.currentUI.show(viewId, data, isAdd);
    }

    /**
     * 打开活动界面
     * @returns
     */
    public openActivity(): Promise<void> {
        if (!we.common.activityMgr.safeBindConfig) {
            we.common.activityMgr.getAccountBindAwardConf();
        }

        if (we.common.activityMgr.activityConf?.length <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.ACTIVTY_TIPS_1));
            we.common.activityMgr.getActivityConf();
            return new Promise((resolve, reject) => {
                resolve();
            });
        }

        return we.currentUI.getDlg(HallViewId.HallDlg)?.onShow(HallPageEnum.event);
    }

    /**
     * 创建通知授权提示弹窗
     * @param type 授权弹窗类型(支持类型扩展)
     * @returns boolean
     */
    public openPermissionDlg(type: number, isShowDlg: boolean = true): boolean {
        if (!(cc.sys.isNative || we.core.nativeUtil.isPlatformLand())) {
            return false;
        }

        let cvc = we.core.nativeUtil.getVersionCode();
        if (cvc < 48) {
            return false;
        } // h5落地页框架 cvc: 47

        let isOpenDialog = false;
        switch (type) {
            case Permission_Type.NOTIFICATION:
                {
                    let localStorage = !!we.kit.storage.get('sys', 'app_permission_notification');
                    if (localStorage) {
                        we.core.nativeUtil.oneSignalRequestPermission();
                        isOpenDialog = true;
                    }
                }
                break;
            default:
                break;
        }

        // 授权弹窗则不需要再弹
        if (isOpenDialog) {
            return false;
        }

        if (isShowDlg) {
            we.currentUI.show(HallViewId.AppPermissionDlg, type);
        }

        return true;
    }

    /**
     * 查询未完成游戏
     * @param completeCallBack
     * @param errorCallBack 接口异常回掉
     * @param isShowLoading
     * @param isDialog  是否弹出未完成对话框
     */
    public getOngoingGame(completeCallBack?: (data: we.IOngoingGameResp) => void, errorCallBack?: Function, isShowLoading: boolean = true, isDialog: boolean = true): void {
        we.common.gameMgr.unfinishedGame.completeCallBack = completeCallBack;
        let offsetTime = new Date().getTime() - we.common.gameMgr.unfinishedGame.timestamp;
        if (offsetTime <= 5000) {
            let ongoingGame = parseInt(we.common.gameMgr.unfinishedGame.ongoingGame);
            if (isDialog && we.core.gameConfig.isSubGame(ongoingGame)) {
                we.common.commonMgr.unfinishedGameDialog(parseInt(we.common.gameMgr.unfinishedGame.ongoingGame), we.common.gameMgr.unfinishedGame.roomIndex);
                return;
            }

            if (typeof we.common.gameMgr.unfinishedGame.completeCallBack === 'function') {
                we.common.gameMgr.unfinishedGame.completeCallBack(we.common.gameMgr.unfinishedGame);
            }
            return;
        }

        if (we.common.gameMgr.unfinishedGame.requesting) {
            return;
        }
        we.common.gameMgr.unfinishedGame.requesting = true;

        we.common.apiMgr.getOngoingGame(
            (data: api.OngoingGameResp) => {
                we.common.gameMgr.unfinishedGame.timestamp = new Date().getTime();
                we.common.gameMgr.unfinishedGame.ongoingGame = data.ongoingGame;
                we.common.gameMgr.unfinishedGame.roomIndex = data.roomIndex;
                we.common.gameMgr.unfinishedGame.requesting = false;

                let ongoingGame = parseInt(we.common.gameMgr.unfinishedGame.ongoingGame);
                if (isDialog && we.core.gameConfig.isSubGame(ongoingGame)) {
                    we.common.commonMgr.unfinishedGameDialog(parseInt(data.ongoingGame), data.roomIndex);
                    return;
                }

                if (typeof we.common.gameMgr.unfinishedGame.completeCallBack === 'function') {
                    we.common.gameMgr.unfinishedGame.completeCallBack(we.common.gameMgr.unfinishedGame);
                }
            },
            (code) => {
                we.common.gameMgr.unfinishedGame.requesting = false;
                typeof errorCallBack == 'function' && errorCallBack(code);
            },
            isShowLoading
        );
    }

    public openRecentGame(callback?: Function) {
        let gameInfo = we.common.gameMgr.getLastGameInfo();

        let extraData = null;
        if (!gameInfo.gameId) {
            extraData = { specialJumpSlots: true };
        }

        let gameId: we.GameId = 0;
        let roomKind = -1;
        if (we.core.gameConfig.isSubGame(gameInfo?.gameId)) {
            gameId = gameInfo.gameId;
            roomKind = gameInfo.roomKind;
            extraData = gameInfo.extraData ?? {};
            extraData['quickStart'] = true;
        }

        if (we.core.gameConfig.isSubGame(gameId)) {
            if (!this.canEnterSubGame(gameId)) {
                return;
            }

            we.common.gameMgr.runGame(
                gameId,
                roomKind,
                () => {
                    callback?.();
                },
                true,
                extraData
            );
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.QUICK_GAME_TIPS));
        }
    }

    /**
     * 点击大厅主界面 apk 下载按钮入口逻辑封装
     */
    public clickApkDownloadBtn(): void {
        let isOpenPWA = we.core.projectConfig.settingsConfig?.isPwa;
        if (isOpenPWA) {
            let pwaInstallSt = we.core.h5PWA.getInstallStatus();
            switch (pwaInstallSt) {
                case we.core.PWAInstallStatus.Installed:
                    break;
                case we.core.PWAInstallStatus.Installable:
                    {
                        let immediatelyInstall = we.common.utils.compareUrlHostname(window.location.href, we.core.projectConfig.settingsConfig.pwaUrl);
                        if (immediatelyInstall) {
                            we.core.h5PWA.install();
                        } else {
                            this.openPWAInstall();
                        }
                    }
                    break;
                case we.core.PWAInstallStatus.NotInstallable:
                    this.openDownloadGuideDlg();
                    break;
                case we.core.PWAInstallStatus.NotInstallableNonChrome:
                    this.openPWAInstall();
                    break;
                case we.core.PWAInstallStatus.NotInstallableIos:
                    this.openDownloadGuideDlg();
                    break;
                default:
                    break;
            }
        } else {
            this.openDownloadGuideDlg();
        }
    }

    /**
     * 点击大厅主界面 ios 收藏按钮入口逻辑封装
     */
    public clickIosCollectBtn(): void {
        let isOpenPWA = we.core.projectConfig.settingsConfig?.isPwa;
        if (isOpenPWA) {
            let pwaInstallSt = we.core.h5PWA.getInstallStatus();
            switch (pwaInstallSt) {
                case we.core.PWAInstallStatus.Installed:
                    break;
                case we.core.PWAInstallStatus.Installable:
                    {
                        let immediatelyInstall = we.common.utils.compareUrlHostname(window.location.href, we.core.projectConfig.settingsConfig.pwaUrl);
                        if (immediatelyInstall) {
                            we.core.h5PWA.install();
                        } else {
                            this.openPWAInstall();
                        }
                    }
                    break;
                case we.core.PWAInstallStatus.NotInstallable:
                    this.openIosCollect();
                    break;
                case we.core.PWAInstallStatus.NotInstallableNonChrome:
                    this.openPWAInstall();
                    break;
                case we.core.PWAInstallStatus.NotInstallableIos:
                    this.openIosCollect();
                    break;

                default:
                    break;
            }
        } else {
            this.openIosCollect();
        }
    }

    public openPWAInstall(): void {
        we.currentUI.show(HallViewId.PWAInstallGuideDlg);
    }

    public openIosCollect(): void {
        we.currentUI.show(HallViewId.AddIconGuideTipDlg);
    }

    public openDownloadGuideDlg(): void {
        we.currentUI.show(HallViewId.DownLoadGuideDlg);
    }

    /**
     * Naming 提示弹窗推送处理
     * 在引导流程中不处理该推送
     * @param data
     * @returns
     */
    public handleNamingAlterPushMsg(data: naming.UserAlertNT): void {
        if (!data) {
            we.warn(`HallMgr handleNamingAlterPushMsg, data is null`);
            return;
        }

        if (NewbieGuideMgr.isGuiding) {
            return;
        }

        if (we.core.gameConfig.curGameId == we.GameId.HALL) {
            let type = data.Type;
            switch (type) {
                case 1:
                    we.commonUI.showConfirm({
                        isHideCloseBtn: false,
                        title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1),
                        content: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_30),
                        yesButtonName: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_31),
                        yesHandler: we.core.Func.create(() => {
                            we.currentUI
                                .getDlg(HallViewId.HallDlg)
                                .onShow(HallPageEnum.shop)
                                .then(() => {
                                    if (we.common.userMgr.isLogin()) {
                                        we.common.storeMgr.getOrderList((data: api.GetOrderListResp) => {
                                            if (we.common.userMgr.isLogin()) {
                                                let orderRecord = data?.orderList || [];
                                                if (orderRecord.length > 0) {
                                                    we.currentUI.show(HallViewId.StorePayOrderDlg, data.orderList);
                                                } else {
                                                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.MAIL_NO));
                                                }
                                            }
                                        });
                                    }
                                });
                        }, this),
                    });
                    break;
                case 2:
                    we.commonUI.showConfirm({
                        isHideCloseBtn: false,
                        title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1),
                        content: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_11),
                        yesButtonName: we.core.langMgr.getLangText(HallLanguage.WITHDRAW_VIP_LABEL_12),
                        yesHandler: we.core.Func.create(() => {
                            we.currentUI
                                .getDlg(HallViewId.HallDlg)
                                .onShow(HallPageEnum.withdraw)
                                .then(() => {
                                    if (we.common.userMgr.isLogin()) {
                                        we.currentUI.show(HallViewId.WithdrawRecordDlg, we.common.withdrawMgr.WithdrawType.Vip);
                                    }
                                });
                        }, this),
                    });
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 判断子游戏是否可以进入
     * @param gameId
     * @returns
     */
    public canEnterSubGame(gameId: we.GameId): boolean {
        const conf = HallGameListMgr.getGameEntryConfig(gameId, false);

        // 游戏未开放
        if (conf.comingsoonStart) {
            we.commonUI.showToastById(HallLanguage.HALL_GAME_STATUS_TIPS1);
            return false;
        }

        // 游戏维护中
        if (conf.safeguard) {
            we.commonUI.showToastById(HallLanguage.HALL_GAME_STATUS_TIPS2);
            return false;
        }

        // 游戏不存在
        const gameListMap = we.core.projectConfig.gameListMap;
        if (!gameListMap.has(gameId)) {
            we.commonUI.showToastById(HallLanguage.GAME_HALL_OFF);
            return false;
        }

        // Vip限制已经在 GameManager runGame 中处理

        return true;
    }
}

export default HallMgr.ins();
