import { HallEvent } from '../config/HallEvent';
import { HallLanguage } from '../const/HallLanguage';
import { HallViewId } from '../view/HallViewId';
import HallMgr from './HallMgr';
import JumpModMgr from './JumpModMgr';

class SevenDay {
    private static _instance: SevenDay;
    public static get instance() {
        return this._instance ?? (this._instance = new SevenDay());
    }

    private _clicked: boolean;

    private _data: api.NewBieSevenDayActivityInfoResp;
    public get data() {
        return this._data;
    }

    private _menu: { active: boolean; title: string; tips?: string; bonus?: string; red?: number }[] = [];
    public get menu() {
        return this._menu;
    }

    public get availableMenu() {
        return this._menu.filter((menu) => {
            return menu.active;
        });
    }

    public get open() {
        const now = we.core.TimeHelper.getTimestampS();
        return (
            now >= this._data?.startTime &&
            now < this._data?.endTime &&
            this._menu.some((menu) => {
                return menu.active;
            })
        );
    }

    public get condition() {
        return Math.max((this._data?.rechargeCondition ?? 0) - (this._data?.rechargeAmount ?? 0), 0);
    }

    public init() {
        cc.director.off(we.common.EventName.SEVEN_DAY_BUY_SUCCESS, this.requestDataSilent, this);
        cc.director.off(we.common.EventName.NOTICE_EVENT_CENTER, this.syncData, this);
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.syncData, this);
        cc.director.on(we.common.EventName.SEVEN_DAY_BUY_SUCCESS, this.requestDataSilent, this);
        cc.director.on(we.common.EventName.NOTICE_EVENT_CENTER, this.syncData, this);
        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.syncData, this);
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.sevenDay, this._clicked ? 0 : 1, true);
        this.syncData();
    }

    public requestData(showLoading?: boolean) {
        return new Promise<void>((resolve, reject) => {
            we.common.apiMgr.getNewBieSevenDayActivityInfo(
                (resp: api.NewBieSevenDayActivityInfoResp) => {
                    we.common.activityMgr.sevenDayInfo = resp;
                    this.syncData();
                    resolve();
                },
                reject,
                showLoading
            );
        });
    }

    public async requestDataSilent() {
        try {
            await this.requestData(false);
        } catch {}
    }

    private syncData() {
        if (!we.common.activityMgr.sevenDayInfo) {
            return;
        }
        this._data = we.common.activityMgr.sevenDayInfo;
        this._menu.length = 0;
        const task = this.initTask();
        const sign = this.initSign();
        this.initGift();
        this.initBind();
        this._menu.unshift({
            active: this._menu.some((menu) => {
                return menu.active;
            }),
            title: we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_INTRODUCTION_4),
        });
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.sevenDay, task + sign + (this._clicked ? 0 : 1), true);
        cc.director.emit(HallEvent.SEVEN_DAY_UPDATE_DATA);
    }

    private initTask() {
        const red = this._data.betAmount?.filter((task) => {
            return task.taskStatus === 2;
        }).length;
        this._menu.push({
            active: this._data.betAmount?.length > 0,
            title: we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_3),
            tips: we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_2, SevenDayMgr.multiple),
            red,
        });
        this._data.betAmount?.sort((a, b) => {
            if (a.taskStatus === b.taskStatus) {
                return a.day - b.day;
            }
            // 已领取奖励排最后
            if (a.taskStatus === 3 || b.taskStatus === 3) {
                return a.taskStatus - b.taskStatus;
            }
            return b.taskStatus - a.taskStatus;
        });
        return red ?? 0;
    }

    private initSign() {
        const red = this._data.dayReward?.filter((sign) => {
            return sign.state === 1;
        }).length;
        this._menu.push({
            active: this._data.dayReward?.length > 0,
            title: we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_4),
            red,
        });
        return red ?? 0;
    }

    private initGift() {
        const gift = this._data.giftState?.find((gift) => {
            return gift.state === 1;
        });
        this._menu.push({
            active: this._data.giftState?.length > 0,
            title: we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_5),
            bonus: gift ? `+${~~((gift.award / gift.coin) * 100)}%` : null,
        });
    }

    private initBind() {
        this._menu.push({
            active: !we.common.userMgr.isFormal(),
            title: we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_6),
            tips: we.common.utils.formatAmountCurrency(we.core.projectConfig.settingsConfig?.phoneBindReward[0] ?? 0),
        });
    }

    public jump() {
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.sevenDay, this._clicked ? 0 : -1);
        JumpModMgr.jumpToModule(we.common.JumpCmd.Seven_Day);
        this._clicked = true;
    }

    public requestTaskAward(level: number, showLoading = true) {
        we.common.apiMgr.drawActivityAward(
            {
                taskType: this._data.taskType,
                typeEnum: we.common.activityMgr.TaskType.betAmount,
                level,
            },
            (resp: api.DrawNewTaskAwardResp) => {
                if (resp.drawAwardStatus === 1) {
                    HallMgr.openGetAwardsDlg([{ id: we.common.userMgr.PropId.CoinId, num: resp.drawAwardNum }]);
                }
                this.requestDataSilent();
            },
            null,
            showLoading
        );
    }

    public requestSignAward(showLoading = true) {
        we.common.apiMgr.getNewBieSevenDayGetDailyAward(
            (resp: api.NewBieSevenDayGetDailyAwardResp) => {
                if (resp.awardStatus === 1) {
                    HallMgr.openGetAwardsDlg([{ id: we.common.userMgr.PropId.CoinId, num: resp.awardNum }]);
                }
                this.requestDataSilent();
            },
            null,
            showLoading
        );
    }

    public buyGift(index: number, view: we.ui.UIView, showLoading = true) {
        const gift = this._data.giftState[index];
        we.common.payMgr.trackFrom = we.common.JumpCmd.Seven_Day;
        we.common.apiMgr.getActiveRechargeType(
            gift.productId,
            (ptData: api.payTypeResp) => {
                if (cc.isValid(view.uiRoot)) {
                    const payChnList = ptData.rechargeTypeCategory ?? [];
                    const payType = payChnList[0].payType;
                    if (payChnList.length === 1 && (we.common.payMgr.isStorePay(payType) || we.common.payMgr.isIntegrationPay(payType))) {
                        we.common.payMgr.getOrderInfo(gift.productId, payType);
                    } else {
                        we.currentUI.show(HallViewId.StorePayTypeDlg, { productData: { id: gift.productId }, payTypeDataList: payChnList, price: gift.price });
                    }
                }
            },
            null,
            showLoading
        );
    }

    public btnAutoGray(btn: cc.Button, interactable: boolean) {
        btn.enableAutoGrayEffect = true;
        btn.interactable = interactable;
        const material = interactable ? btn.normalMaterial : btn.grayMaterial;
        btn.getComponentsInChildren(cc.RenderComponent).forEach((render) => {
            render.setMaterial(0, material);
        });
    }
}

namespace SevenDayMgr {
    export const instance = SevenDay.instance;
    export const multiple = 100;
    export const enum Page {
        /** 活动介绍 */
        Intro,
        /** 福利任务 */
        Task,
        /** 登录奖励 */
        Sign,
        /** 特惠礼包 */
        Gift,
        /** 绑定手机 */
        Bind,
    }
}
export default SevenDayMgr;
