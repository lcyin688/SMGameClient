import { HallViewId } from '../view/HallViewId';
import HallMgr from './HallMgr';
import JumpModMgr from './JumpModMgr';
import NewbieGuideMgr from './NewbieGuideMgr';

/** 弹窗类型 */
enum PopupType {
    /** 功能弹窗 */
    System = 1,
    /** 自定义弹窗 */
    Custom = 2,
}

/** 弹窗时机 */
enum PopupTiming {
    /** 登录进入大厅 */
    Login = 1,
    /** 停留大厅 */
    StayIn = 2,
    /** 返回大厅 */
    Back = 3,
}

/** 弹窗队列信息 */
interface IPopupInfo {
    /** 排序 */
    sort: number;
    /** 触发状态 */
    triggerState: boolean;
    /** 弹窗枚举 JUMP_TYPES */
    moduleType: string;
    /** 遍历计数 */
    count: number;
    /** 是否开启功能 */
    isOpen: boolean;
    /** 弹窗 prefab 资源 */
    res: string;
}

/** 登录进入大厅，必弹顺序 */
const LOGIN_POPUP_ORDER = [
    we.common.JumpCmd.Download_Guide,
    we.common.JumpCmd.Notice_Permission,
    we.common.JumpCmd.System_Maintain,
    we.common.JumpCmd.Naming_Token_Error,
    we.common.JumpCmd.Newbie_Give,
    we.common.JumpCmd.App_Launcher_Jump,
];

/** 游戏返回大厅，必弹队列 */
const BACK_POPUP_ORDER = [we.common.JumpCmd.System_Maintain, we.common.JumpCmd.Download_Guide];

@we.decorator.typeSingleton('HallPopupMgr')
export class HallPopupMgr extends we.core.Entity {
    static Inst: HallPopupMgr;

    private readonly timeTag = 'HallPopupMgr_onFullClickEvent';
    /** 取消弹窗 */
    private cancelAppLauncherPop: boolean = false;
    /** 服务器弹窗配置 */
    public popupConf: Map<PopupTiming, api.AutoPopupConf[]> = new Map<PopupTiming, api.AutoPopupConf[]>();

    /** app 启动弹窗队列 */
    private appLauncherPopList: IPopupInfo[] = [];
    /** 返回大厅弹窗队列 */
    private backHallPopList: IPopupInfo[] = [];

    /** 当前弹出的弹窗 */
    private curOpenPopup: IPopupInfo = null;
    /** 启动弹窗队列弹窗正在展示 */
    private appLauncherPopIng: boolean = false;

    /** 自动弹出窗数据 */
    private autoPopConf: api.AutoPopupConf[] = [];

    protected awake() {
        cc.director.on(we.common.EventName.HALL_POPUP_QUEUE_UPDATE, this.onAppLauncherPopup, this);
        cc.director.on(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, this.onClosePopup, this);
        cc.director.on(we.core.EventName.FULL_TOUCH_END, this.onFullClickEvent, this);

        this.formatPopConf();

        // 需要完成监听事件注册后再开启弹窗队列初始化
        let sceneFrom = we.core.gameConfig.getSceneFrom();
        if (sceneFrom == we.SceneFrom.Launcher) {
            this.cancelAppLauncherPop = we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.nopop) == '1';
            if (this.cancelAppLauncherPop) {
                this.appLauncherPopList = [];
                we.common.userMgr.isShowGiveDialog = false;
            } else {
                this.initAppLauncherPopup();
            }
        }
    }

    protected destroy(): void {
        cc.director.off(we.common.EventName.HALL_POPUP_QUEUE_UPDATE, this.onAppLauncherPopup, this);
        cc.director.off(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, this.onClosePopup, this);
        cc.director.off(we.core.EventName.FULL_TOUCH_END, this.onFullClickEvent, this);

        // 退出大厅都需要清理必弹窗队列,放在末尾清除防止清除后又触发事件
        this.clearPopup();
    }

    public dispose(): void {
        HallPopupMgr.Inst = null;
    }

    /**
     * 进入大厅触发弹窗
     */
    public async showPopup() {
        if (this.cancelAppLauncherPop) {
            return;
        }
        this.initBackHallPopup();

        const task = we.clientScene.getComponent(we.common.GameEventTask);
        await task.startTask();

        if (this.appLauncherPopList.length > 0) {
            this.appLauncherPopup();
        } else {
            this.backHallPopup();
        }
    }

    /**
     * 清理弹窗队列
     */
    public clearPopup(): void {
        this.appLauncherPopList = [];
        this.backHallPopList = [];

        // 清理定时器
        we.core.timer.removeByTag(this.timeTag);
    }

    /**
     * 处理关闭弹窗队列弹窗后 继续弹窗处理
     * @param moduleType
     */
    public onClosePopup(moduleType?: string) {
        if (!we.common.userMgr.isLogin()) {
            return;
        }

        if (this.appLauncherPopList.length > 0) {
            this.appLauncherPopup(moduleType);
        } else {
            this.backHallPopup();
        }
    }

    /**
     * 监听全屏点击事件
     * 用于处理玩家长时间在大厅停留未操作界面时，弹出配置的停留弹窗
     * 停留弹窗规则，根据配置随机配置中的一个弹窗
     */
    public async onFullClickEvent() {
        // 停留弹窗数据判空
        if (this.autoPopConf.length < 1) {
            return;
        }

        // 判断是否在停留在大厅
        if (we.core.gameConfig.curGameId != we.GameId.HALL) {
            return;
        }

        // 清理定时器
        we.core.timer.removeByTag(this.timeTag);

        let index = Math.min(Math.floor(Math.random() * this.autoPopConf.length), this.autoPopConf.length - 1);
        let dlgData = this.autoPopConf[index];
        if (dlgData) {
            we.core.timer.scheduleOnce(dlgData.popTime, this, this.timeTag).then(() => {
                // 不在大厅的时候不弹出
                if (we.core.gameConfig.curGameId != we.GameId.HALL) {
                    return;
                }
                // 获取 Popup / Top 节点是否存在节点，如果存在则不弹，不存在则弹出
                let popupNode = we.ui.UILayer.popUp?.children || [];
                let topNode = we.ui.UILayer.top?.children || [];
                if (popupNode.length != 0 || topNode.length != 0) {
                    return;
                }

                JumpModMgr.jumpToModule(dlgData.jumpPosition, dlgData.popupOrder);
            });
        }
    }

    /**
     * 获取自定义弹窗数据
     * @returns
     */
    public getCustomPopConf(): api.AutoPopupConf[] {
        let conf = we.core.projectConfig.settingsConfig.autoPopupConf || [];
        let map = new Map<number, api.AutoPopupConf[]>();
        conf.forEach((v) => {
            let popupList = map.get(v.popupType) || [];
            popupList.push(v);
            map.set(v.popupType, popupList);
        });

        conf = map.get(PopupType.Custom) || [];
        conf.sort((a, b) => {
            return a.popupOrder - b.popupOrder;
        });
        return conf;
    }

    /**
     * 格式化弹窗配置
     */
    private formatPopConf(): void {
        this.popupConf.clear();

        let conf = we.core.projectConfig.settingsConfig.autoPopupConf || [];
        conf.sort((a, b) => {
            return a.popupOrder - b.popupOrder;
        });

        let startSort = LOGIN_POPUP_ORDER.length;
        conf.forEach((v) => {
            // 默认弹窗队列计入排序，更新配置排序规则
            v.popupOrder += startSort;

            // 补全远端自定义弹窗图片资源地址
            if (v.popupType == PopupType.Custom) {
                // 自定义弹窗，由客户端设置弹窗跳转地址（服务器和web不好做映射）
                v.jumpPosition = we.common.JumpCmd.Custom_Dlg;

                let popRes = v.popupResource || [];
                popRes.forEach((k) => {
                    let keys = Object.keys(k.urls);
                    keys.forEach((j) => {
                        let url = k.urls[j];
                        // 防止重复补全
                        if (url && !url.startsWith('http')) {
                            k.urls[j] = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, url);
                        }
                    });
                });
            }

            let popupList = this.popupConf.get(v.autoPopTiming) || [];
            popupList.push(v);
            this.popupConf.set(v.autoPopTiming, popupList);
        });

        // 初始化 停留大厅弹窗
        this.autoPopConf = this.popupConf.get(PopupTiming.StayIn) || [];
    }

    /**
     * 启动弹窗队列只需要初始化一次
     */
    private initAppLauncherPopup(): void {
        this.appLauncherPopIng = false;
        let mustPopQueue = we.npm.lodash.cloneDeep(LOGIN_POPUP_ORDER);
        const foxPopQueueLen = mustPopQueue.length;

        // 自定义弹窗队列
        let conf = this.popupConf.get(PopupTiming.Login) || [];
        conf.forEach((v) => {
            mustPopQueue.push(v.jumpPosition);
        });

        this.appLauncherPopList = [];
        mustPopQueue.forEach((v, i) => {
            let data = {} as IPopupInfo;

            // 确保弹窗顺序可索引到 原始配置
            if (i < foxPopQueueLen) {
                data.sort = i;
            } else {
                data.sort = conf[i - foxPopQueueLen].popupOrder;
            }

            data.moduleType = v;
            data.count = 0;
            data.triggerState = false;
            data.isOpen = false;
            data.res = '';
            this.appLauncherPopList.push(data);
        });

        this.appLauncherPopList.sort((a, b) => {
            return a.sort - b.sort;
        });

        // 提前遍历哪些弹窗是需要开启的
        this.appLauncherPopList.forEach((v) => {
            this.initModuleOpenState(v);
        });
    }

    public getAppLauncherPopList() {
        return this.appLauncherPopList;
    }

    /**
     * 更新弹窗队列
     * 适用于数据延迟导致必弹队列未正常弹出
     */
    public onAppLauncherPopup() {
        if (!we.common.userMgr.isLogin()) {
            return;
        }

        // 重置弹窗计数
        this.appLauncherPopList.forEach((v) => {
            v.count = 0;
        });

        // 如果必弹队列已完成弹窗，直接调用弹窗队列进行弹窗触发
        if (!this.appLauncherPopIng) {
            this.appLauncherPopup();
        }
    }

    /**
     * 登录界面 -> 大厅时
     * @param modeType
     */
    private async appLauncherPopup(modeType?: string) {
        // 1.登录成功；2.队列存在数据；3.当前游戏为大厅
        if (!we.common.userMgr.isLogin() || this.appLauncherPopList.length <= 0 || we.core.gameConfig.curGameId != we.GameId.HALL) {
            return;
        }

        // 更新已弹弹窗状态
        if (typeof modeType == 'string') {
            for (let i = 0; i < this.appLauncherPopList.length; i++) {
                let data = this.appLauncherPopList[i];
                if (data.moduleType == modeType && data.sort == this.curOpenPopup?.sort) {
                    data.triggerState = true;
                    this.appLauncherPopIng = false;
                    break;
                }
            }

            // 没有关闭当前顺序的自动弹窗，忽略后续
            if (modeType !== this.curOpenPopup?.moduleType) {
                return;
            }
        }
        if (this.appLauncherPopIng) {
            return;
        }

        // 获取当前弹窗
        this.curOpenPopup = null;
        let curCount = 1;
        for (let i = 0; i < this.appLauncherPopList.length; i++) {
            let data = this.appLauncherPopList[i];
            if (!data.triggerState) {
                if (curCount <= data.count) {
                    // 遍历到最后一个弹窗，并且当前弹窗的次数小于等于当前次数，则表示所有弹窗已完成
                    i == this.appLauncherPopList.length - 1 && (curCount = data.count);
                } else {
                    this.curOpenPopup = data;
                    data.count++;
                    break;
                }
            }
        }
        if (!this.curOpenPopup) {
            return;
        }

        let conf = JumpModMgr.conf[this.curOpenPopup.moduleType];
        let condition = conf?.condition(true);
        if (conf) {
            this.appLauncherPopIng = condition;
            if (condition) {
                // 特殊处理自定义弹窗，因为自定弹窗打开时的数据需要 sort 来索引
                if (this.curOpenPopup.moduleType == we.common.JumpCmd.Custom_Dlg) {
                    await conf.func(this.curOpenPopup.sort);
                } else {
                    await conf.func();
                }
                return;
            }
        }

        this.appLauncherPopup();
    }

    /**
     * 返回大厅弹窗队列 插入一个最高优先级的事件
     * @param event 事件名称
     */
    public async insertBackHallPopup(event: string) {
        if (event) {
            let data = {} as IPopupInfo;
            data.sort = 0;
            data.moduleType = event;
            this.backHallPopList.unshift(data);
        }
    }

    /**
     * 初始化回到大厅弹窗队列数据，即：子游戏 -> 大厅
     * 每次进入大厅均需要初始化
     */
    private async initBackHallPopup() {
        let mustPopQueue = we.npm.lodash.cloneDeep(BACK_POPUP_ORDER);
        let sceneFrom = we.core.gameConfig.getSceneFrom();
        if (sceneFrom == we.SceneFrom.Game) {
            // 在线热更弹窗
            mustPopQueue.push(we.common.JumpCmd.Game_Back_Hall);
        }
        const fixedPopQueueLen = mustPopQueue.length;

        // 自定义弹窗队列
        let conf = this.popupConf.get(PopupTiming.Back) || [];
        conf.forEach((v) => {
            mustPopQueue.push(v.jumpPosition);
        });

        this.backHallPopList = [];
        mustPopQueue.forEach((v, i) => {
            let data = {} as IPopupInfo;

            // 确保弹窗顺序可索引到 原始配置
            if (i < fixedPopQueueLen) {
                data.sort = i;
            } else {
                data.sort = conf[i - fixedPopQueueLen].popupOrder;
            }

            data.moduleType = v;
            this.backHallPopList.push(data);
        });

        this.backHallPopList.sort((a, b) => {
            return a.sort - b.sort;
        });
    }

    /**
     * 子游戏 -> 大厅
     * @returns
     */
    private async backHallPopup() {
        if (!we.common.userMgr.isLogin()) {
            return;
        }

        // 引导弹窗仅在所有弹窗完成后触发
        if (this.backHallPopList.length <= 0) {
            NewbieGuideMgr.judgeStartModGuide(NewbieGuideMgr.getModGuides());
            return;
        }

        let data = this.backHallPopList.shift();
        let conf = JumpModMgr.conf[data.moduleType];
        if (conf) {
            let condition = conf?.condition(true);
            this.appLauncherPopIng = condition;
            if (condition) {
                // 特殊处理自定义弹窗，因为自定弹窗打开时的数据需要 sort 来索引
                if (data.moduleType == we.common.JumpCmd.Custom_Dlg) {
                    await conf.func(data.sort);
                } else {
                    await conf.func();
                }
                return;
            }
        }

        this.backHallPopup();
    }

    /** 初始化各个功能模块开启状态 */
    private initModuleOpenState(data: IPopupInfo): void {
        const moduleType = data.moduleType;
        switch (moduleType) {
            case we.common.JumpCmd.Notice_Permission:
                if (HallMgr.openPermissionDlg(HallMgr.Permission_Type.NOTIFICATION, false)) {
                    data.isOpen = true;
                    data.res = HallViewId.AppPermissionDlg;
                }
                break;
            case we.common.JumpCmd.Newbie_Give:
                if (we.common.userMgr.isShowGiveDialog && we.common.userMgr.userInfo.gold > 0) {
                    data.isOpen = true;
                    data.res = HallViewId.NewbieGiveDlg;
                }
                break;
            case we.common.JumpCmd.Official_Award:
                if ((cc.sys.isNative || we.core.nativeUtil.isPlatformLand()) && we.common.userMgr.isFormal()) {
                    data.isOpen = true;
                    data.res = HallViewId.OfficialPkgAwardDlg;
                }
                break;
            case we.common.JumpCmd.Bind_Phone:
                if (!we.common.userMgr.isFormal()) {
                    data.isOpen = true;
                    data.res = we.common.CommonViewId.PhoneBindHighDlg;
                }
                break;
            case we.common.JumpCmd.Newbie_Gift_Bag:
                if (we.common.storeMgr.isNewbieGift) {
                    data.isOpen = true;
                    data.res = HallViewId.NewbieGiftBagDlg;
                }
                break;
            case we.common.JumpCmd.Activity:
                if (we.core.flavor.isSkinVertical()) {
                    break;
                }
                if (we.common.storage.getDay('common', 'no_prop_activity') === true) {
                    break;
                }
                data.isOpen = true;
                data.res = HallViewId.ActivityDlg;
                break;
            case we.common.JumpCmd.Download_apk:
                if (we.common.downloadGuideMgr?.isVestAndroid() && we.core.projectConfig.settingsConfig?.h5HallDownloadTooltipSwitch) {
                    data.isOpen = true;
                    data.res = HallViewId.ApkDownloadDlg;
                }
                break;
            case we.common.JumpCmd.Download_Guide:
                if (we.common.downloadGuideMgr?.isOpenGuide() && we.common.downloadGuideMgr.forceGuideConf?.forceLeadSwitch) {
                    data.isOpen = true;
                    data.res = HallViewId.DownLoadGuideDlg;
                }
                break;
            case we.common.JumpCmd.Join_Us:
                if (we.core.projectConfig.settingsConfig?.thirdLinkJoinSwitch && !we.common.activityMgr.isClickJoinUs) {
                    if (!we.common.activityMgr.todayNoPropJoinUs && we.core.projectConfig.settingsConfig.thirdLinkConf?.length > 0) {
                        data.isOpen = true;
                        data.res = HallViewId.JoinUsDlg;
                    }
                }
                break;
            case we.common.JumpCmd.Carnival:
                if (!we.common.activityMgr.todayNoPropCarnival) {
                    if (we.common.carnivalMgr?.isOpenAct()) {
                        data.isOpen = true;
                        data.res = HallViewId.CarnivalDlg;
                    }
                }
                break;
            case we.common.JumpCmd.Daily_Recharge:
                if (!we.common.activityMgr.todayNoPropDailyRecharge) {
                    if (we.common.dailyRechargeMgr.isOpenAct()) {
                        data.isOpen = true;
                        data.res = HallViewId.DailyRechargeRewardDlg;
                    }
                }
                break;
            case we.common.JumpCmd.Recharge:
                data.isOpen = true;
                data.res = HallViewId.StoreDlg;
                break;
            case we.common.JumpCmd.Turntable:
                if (we.common.turntableMgr?.getTurntableIsAct()) {
                    data.isOpen = true;
                    data.res = HallViewId.TurntableDlg;
                }
                break;
            default:
                break;
        }
    }
}
