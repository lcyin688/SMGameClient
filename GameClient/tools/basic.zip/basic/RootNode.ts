import { SysLanguage } from './config/SysLanguage';
import BasicEventName from './const/BasicEventName';
import LangManager from './manager/LangManager';
import NetworkManager from './manager/NetworkManager';
import { TimeInfo } from './module/time/TimeInfo';

const { ccclass } = cc._decorator;

@ccclass
export default class RootNode extends cc.Component {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    /** 退出状态 */
    private exitState: number = 0;

    onLoad() {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyboardUp, this);
        cc.director.on(BasicEventName.NETWORK_ONLINE, this.onEventNetworkOnline, this);
        cc.director.on(BasicEventName.NETWORK_OFFLINE, this.onEventNetworkOffline, this);
        cc.director.on(BasicEventName.GAME_SHOW, this.onEventGameShow, this);
        cc.director.on(BasicEventName.GAME_HIDE, this.onEventGameHide, this);
    }

    protected update(dt: number): void {}

    protected onEnable(): void {
        this.unscheduleAllCallbacks();
    }

    onDestroy() {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyboardUp, this);
        cc.director.off(BasicEventName.NETWORK_ONLINE, this.onEventNetworkOnline, this);
        cc.director.off(BasicEventName.NETWORK_OFFLINE, this.onEventNetworkOffline, this);
        cc.director.off(BasicEventName.GAME_SHOW, this.onEventGameShow, this);
        cc.director.off(BasicEventName.GAME_HIDE, this.onEventGameHide, this);
    }

    private onKeyboardUp(event: cc.Event.EventKeyboard) {
        we.log(`RootNode onKeyboardUp, keyCode: ${event.keyCode}`);

        switch (event.keyCode) {
            case cc.macro.KEY.back:
            case cc.macro.KEY.escape:
                if (this.exitState == 0) {
                    this.exitState = 1;
                    we.commonUI.showToast(LangManager.getLangText(SysLanguage.COMMON_TIPS_EXIT));
                } else {
                    cc.game.end();
                }

                setTimeout(() => {
                    this.exitState = 0;
                }, 1500);
                break;
            default:
                break;
        }
    }

    private onEventNetworkOnline() {}

    private onEventNetworkOffline() {}

    private onEventGameShow() {
        NetworkManager.flushNetworkState();

        // 怀疑切后台回来后影响 http 请求，增加下一帧执行逻辑用于排查
        we.core.timer.scheduleOnce(0).then(() => {
            TimeInfo.Inst.syncServerTime(we.launcher?.maintainMgr?.getServerTimestamp);
        });
    }

    private onEventGameHide() {}
}
