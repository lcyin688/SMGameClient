import { FuncAsync } from '../module/func/FuncAsync';
import { PipelineType } from '../module/pipeline/PipelineType';
import { BasicType } from '../type/BasicType';

declare global {
    interface ICore {
        AssetPreloadTask: typeof AssetPreloadTask;
    }

    namespace we {
        namespace core {
            type AssetPreloadTask = InstanceType<typeof AssetPreloadTask>;
        }
    }
}

type ConfigContext = { res: BasicType.AssetPreloadConfig };
type UrlItem = { bundle: cc.AssetManager.Bundle; path: string; type?: typeof cc.Asset };
type LoadContext = { urls: UrlItem[] };
type AssetPreloadConfigItem = BasicType.AssetPreloadConfig[number];

/**
 * 资源预加载任务管线组件
 */
@we.decorator.typeRegister('AssetPreloadTask')
export class AssetPreloadTask extends we.core.Entity {
    /**
     * 预加载配置处理管线
     */
    configPipeline: we.core.TaskPipeline<ConfigContext>;

    /**
     * 资源加载管线
     */
    loadPipeline: we.core.TaskPipeline<LoadContext>;

    /**
     * 带加载资源的配置
     */
    private urls: UrlItem[];

    protected awake(config: BasicType.AssetPreloadConfig) {
        this.urls = [];
        this.configPipeline = new we.core.TaskPipeline({ concurrency: 24, mode: PipelineType.PipelineMode.Task });
        this.configPipeline.setCtx({ res: config });
        config.map((item) => {
            this.configPipeline.addTask(FuncAsync.create(this.processCfgTask, this), { ctx: item, priority: item.priority ?? 0 });
        });

        this.configPipeline.start().finally(() => {
            if (this.urls.length > 0) {
                this.startLoadPipeline();
            } else {
                this.dispose();
            }
        });
    }

    protected destroy(): void {
        this.configPipeline?.abort();
        this.loadPipeline?.abort();
    }

    /**
     * 中断未完成的任务
     */
    public async broken() {
        await this.configPipeline?.stop(2);
        await this.loadPipeline?.stop(2);
        this.dispose();
    }

    private startLoadPipeline() {
        this.loadPipeline = new we.core.TaskPipeline({ concurrency: 16, mode: PipelineType.PipelineMode.Continue });
        this.loadPipeline.setCtx({ urls: this.urls });
        for (let item of this.urls) {
            this.loadPipeline.addTask(FuncAsync.create(this.processLoadTask, this), { ctx: item });
        }

        this.loadPipeline.start().finally(() => {
            this.dispose();
        });
    }

    /**
     * 处理预加载配置
     * @param ctx 管线上下文
     * @param signal 中断 signal
     * @returns
     */
    private async processCfgTask(ctx: ConfigContext, signal: AbortSignal, taskCtx: AssetPreloadConfigItem): Promise<void> {
        if (signal.aborted) {
            return;
        }

        try {
            if (taskCtx.path.endsWith('/')) {
                taskCtx.path = taskCtx.path.slice(0, -1);
            }

            let assetInfos = await we.core.assetMgr.queryAssetInfos(taskCtx.path);
            if (!taskCtx.noLog && !assetInfos?.urls?.length) {
                we.warn(`AssetPreloadTask processCfgTask, resource path: ${taskCtx.path} error, please check it`);
                return;
            }

            for (const res of assetInfos.urls) {
                this.urls.push({ path: res.path, type: taskCtx.type, bundle: assetInfos.bundle });
            }
        } catch (err) {
            we.log(`AssetPreloadTask processCfgTask, err: ${JSON.stringify(err.message || err)}`);
            // 忽略预加载配置错误的资源
        }
    }

    /**
     * 处理预加载任务
     * @param ctx 管线上下文
     * @param signal 中断 signal
     * @param taskCtx 任务私有上下文
     * @returns
     */
    private async processLoadTask(ctx: LoadContext, signal: AbortSignal, taskCtx: UrlItem): Promise<void> {
        if (signal.aborted) {
            return;
        }

        try {
            await new Promise((resolve) => {
                taskCtx.bundle.preload(taskCtx.path, taskCtx.type, (err) => {
                    resolve(null);
                });
            });
        } catch (err) {
            // 忽略预加载失败的资源
            we.log(`AssetPreloadTask processLoadTask, asset path: ${taskCtx.path}, err: ${JSON.stringify(err.message || err)}`);
        }
    }
}

we.core.AssetPreloadTask = AssetPreloadTask;
