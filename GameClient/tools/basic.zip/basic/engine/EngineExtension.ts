import ProjectConfig, { ScreenOrientation } from '../config/ProjectConfig';
import BasicEventName from '../const/BasicEventName';
import AssetManager from '../manager/AssetManager';
import AudioManager from '../manager/AudioManager';
import AutoReleaseAssets from './AutoReleaseAssets';

/**
 * 引擎扩展
 */
export default class EngineExtension {}

/**
 * 引擎升级适配 2.2.2 -> 2.4.11
 */
(function () {
    if (cc.ENGINE_VERSION.startsWith('2.4.11')) {
        // @ts-ignore
        cc.RotateTo._reverse = true;
        cc.macro.ENABLE_MULTI_TOUCH = false;
    }
})();

/**
 * 扩展 cc.assetManager.downloader, 支持多域名下载
 */
(function () {
    /* eslint-disable prefer-arrow-callback */
    /* eslint-disable prefer-rest-params */

    if (CC_EDITOR || CC_DEV || CC_JSB) {
        return;
    }

    const cc = <any>window.cc;

    /**
     * h5 多域名
     * @type {string[]}
     */
    cc.assetManager.downloader.multiDomains = null;

    /**
     * h5 多域名标签
     */
    const h5DomainTag = 'h5';

    /**
     * h5 多域名是否启用
     * @type {boolean}
     */
    cc.assetManager.downloader.h5mdEnabled = false;

    /**
     * h5game 多域名标签
     */
    const h5gameDomainTag = 'h5game';

    /**
     * h5game 多域名是否启用
     * @type {boolean}
     */
    cc.assetManager.downloader.h5gamemdEnabled = false;

    /**
     * 初始化多域名
     */
    function initMultiDomain() {
        if (CC_EDITOR || CC_DEV || CC_JSB) {
            return;
        }

        if (cc.assetManager.downloader.multiDomains) {
            return;
        }

        const hostnames = window.location.hostname.split('.');
        if (hostnames.length != 3) {
            return;
        }

        if (hostnames[0] !== h5DomainTag) {
            // 默认子域名为标签时多域名才生效
            return;
        }

        const domainMain = `${hostnames[1]}.${hostnames[2]}`;
        const port = window.location.port ? `:${window.location.port}` : '';

        // url 带上 index.html 时直接使用 pathname 路径错误
        let pathname = window.location.pathname;
        pathname = pathname.slice(0, pathname.lastIndexOf('/') + 1);

        // 文件md5首位[0-9,a-f]共16个字符，分配8个域名，h5([1-7])?, h5/h51/h52...h56/h57
        const domainNum = 8;
        const domains = [];
        for (let i = 0; i < domainNum; i++) {
            let domainSub = i == 0 ? h5DomainTag : h5DomainTag + i;
            domains[i] = `${window.location.protocol}//${domainSub}.${domainMain}${port}${pathname}`;
        }

        cc.assetManager.downloader.multiDomains = domains;
        cc.assetManager.downloader.maxConcurrency *= domainNum;
        cc.assetManager.presets.preload.maxConcurrency *= domainNum;
        cc.assetManager.presets.scene.maxConcurrency *= domainNum;
        cc.assetManager.presets.bundle.maxConcurrency *= domainNum;

        let h5md = <any>window.location.search.substring(1).match(/(^|&)h5md=([^&]*)(&|$)/);
        h5md = h5md ? decodeURIComponent(h5md[2]) : '';
        cc.assetManager.downloader.h5mdEnabled = h5md == '0' ? false : true;

        let h5gamemd = <any>window.location.search.substring(1).match(/(^|&)h5gamemd=([^&]*)(&|$)/);
        h5gamemd = h5gamemd ? decodeURIComponent(h5gamemd[2]) : '';
        cc.assetManager.downloader.h5gamemdEnabled = h5gamemd == '0' ? false : true;
    }
    initMultiDomain();

    /**
     * 获取多域名 url
     * @param {string} url
     * @returns {string}
     */
    function getMultiDomainUrl(url) {
        if (CC_EDITOR || CC_DEV || CC_JSB) {
            return url;
        }

        if (!cc.assetManager.downloader.multiDomains) {
            return url;
        }

        let isRemoteBundle = false;
        if (url.startsWith('http')) {
            if (url.match(new RegExp(`^http(s)?:\\/\\/${h5gameDomainTag}\\.`))) {
                // 远程分包
                isRemoteBundle = true;
            } else {
                // 云端资源不处理
                return url;
            }
        }

        const basename = cc.path.basename(url);
        const basenames = basename.split('.');
        if (basenames.length < 3) {
            // 没有 md5 不处理
            return url;
        }

        const md5Name = basenames[basenames.length - 2];
        const md5First = md5Name[0];
        const md5Keys = '0123456789abcdef';
        if (!md5Keys.includes(md5First)) {
            // md5 首位不在列表时不处理
            return url;
        }

        // md5 首位转成十六进制和8取余作为域名序号
        const md5Num = parseInt(md5First, 16);
        const domainIndex = md5Num % 8;

        if (isRemoteBundle) {
            if (!cc.assetManager.downloader.h5gamemdEnabled) {
                return url;
            }

            const domainSub = `${h5gameDomainTag}${domainIndex == 0 ? '' : domainIndex}`;
            url = url.replace(new RegExp(`:\\/\\/${h5gameDomainTag}\\.`), `://${domainSub}.`);
            return url;
        } else {
            if (!cc.assetManager.downloader.h5mdEnabled) {
                return url;
            }

            const domain = cc.assetManager.downloader.multiDomains[domainIndex] || '';
            if (!domain) {
                return url;
            }

            url = domain + url;
            return url;
        }
    }

    // ----------------------- getMultiDomainUrl start -----------------------
    const downloadDomAudioRaw = cc.assetManager.downloader.downloadDomAudio;
    cc.assetManager.downloader.downloadDomAudio = function downloadDomAudio(url, options, onComplete) {
        url = getMultiDomainUrl(url);
        downloadDomAudioRaw(url, options, onComplete);
    };

    const downloadDomImageRaw = cc.assetManager.downloader.downloadDomImage;
    cc.assetManager.downloader.downloadDomImage = function downloadDomImage(url, options, onComplete) {
        url = getMultiDomainUrl(url);
        downloadDomImageRaw(url, options, onComplete);
    };

    const downloadFileRaw = cc.assetManager.downloader.downloadFile;
    cc.assetManager.downloader.downloadFile = function downloadFile(url, options, onProgress, onComplete) {
        url = getMultiDomainUrl(url);
        downloadFileRaw(url, options, onProgress, onComplete);
    };

    const downloadScriptRaw = cc.assetManager.downloader.downloadScript;
    cc.assetManager.downloader.downloadScript = function downloadScript(url, options, onComplete) {
        url = getMultiDomainUrl(url);
        downloadScriptRaw(url, options, onComplete);
    };
    // ----------------------- getMultiDomainUrl end -----------------------

    // ----------------------- audio start -----------------------
    const formatSupport = cc.sys.__audioSupport.format || [];

    const unsupported = function (url, options, onComplete) {
        onComplete(new Error(cc.debug.getError(4927)));
    };

    const downloadAudioByLoadMode = function (url, options, onComplete) {
        // web audio need to download file as arrayBuffer
        if (options.audioLoadMode !== cc.AudioClip.LoadMode.DOM_AUDIO) {
            downloadArrayBuffer(url, options, onComplete);
        } else {
            cc.assetManager.downloader.downloadDomAudio(url, options, onComplete);
        }
    };

    const downloadAudio = !CC_EDITOR || !Editor.isMainProcess ? (formatSupport.length === 0 ? unsupported : cc.sys.__audioSupport.WEB_AUDIO ? downloadAudioByLoadMode : cc.assetManager.downloader.downloadDomAudio) : null;
    // ----------------------- audio end -----------------------

    // ----------------------- image start -----------------------
    const downloadImage = function (url, options, onComplete) {
        // if createImageBitmap is valid, we can transform blob to ImageBitmap. Otherwise, just use HTMLImageElement to load
        let func = cc.sys.capabilities.imageBitmap && cc.macro.ALLOW_IMAGE_BITMAP ? downloadBlob : cc.assetManager.downloader.downloadDomImage;
        func.apply(this, arguments);
    };
    // ----------------------- image end -----------------------

    // ----------------------- downloadFile start -----------------------
    const downloadBlob = function (url, options, onComplete) {
        options.responseType = 'blob';
        cc.assetManager.downloader.downloadFile(url, options, options.onFileProgress, onComplete);
    };

    const downloadJson = function (url, options, onComplete) {
        options.responseType = 'json';
        cc.assetManager.downloader.downloadFile(url, options, options.onFileProgress, function (err, data) {
            if (!err && typeof data === 'string') {
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    err = e;
                }
            }
            onComplete && onComplete(err, data);
        });
    };

    const downloadArrayBuffer = function (url, options, onComplete) {
        options.responseType = 'arraybuffer';
        cc.assetManager.downloader.downloadFile(url, options, options.onFileProgress, onComplete);
    };

    const downloadText = function (url, options, onComplete) {
        options.responseType = 'text';
        cc.assetManager.downloader.downloadFile(url, options, options.onFileProgress, onComplete);
    };
    // ----------------------- downloadFile end -----------------------

    // ----------------------- bundle start -----------------------
    const REGEX = /^(?:\w+:\/\/|\.+\/).+/;

    const downloadBundle = function (nameOrUrl, options, onComplete) {
        let bundleName = cc.path.basename(nameOrUrl);
        let url = nameOrUrl;
        if (!REGEX.test(url)) {
            url = 'assets/' + bundleName;
        }
        let version = options.version || cc.assetManager.downloader.bundleVers[bundleName];
        let count = 0;
        let config = `${url}/config.${version ? version + '.' : ''}json`;
        let out = null,
            error = null;
        downloadJson(config, options, function (err, response) {
            if (err) {
                error = err;
            }
            out = response;
            out && (out.base = url + '/');
            count++;
            if (count === 2) {
                onComplete(error, out);
            }
        });

        let js = `${url}/index.${version ? version + '.' : ''}js`;
        cc.assetManager.downloader.downloadScript(js, options, function (err) {
            if (err) {
                error = err;
            }
            count++;
            if (count === 2) {
                onComplete(error, out);
            }
        });
    };
    // ----------------------- bundle start -----------------------

    // dafault handler map
    const downloaders = {
        // Images
        '.png': downloadImage,
        '.jpg': downloadImage,
        '.bmp': downloadImage,
        '.jpeg': downloadImage,
        '.gif': downloadImage,
        '.ico': downloadImage,
        '.tiff': downloadImage,
        '.webp': downloadImage,
        '.image': downloadImage,
        '.pvr': downloadArrayBuffer,
        '.pkm': downloadArrayBuffer,
        '.astc': downloadArrayBuffer,

        // Audio
        '.mp3': downloadAudio,
        '.ogg': downloadAudio,
        '.wav': downloadAudio,
        '.m4a': downloadAudio,

        // Txt
        '.txt': downloadText,
        '.xml': downloadText,
        '.vsh': downloadText,
        '.fsh': downloadText,
        '.atlas': downloadText,

        '.tmx': downloadText,
        '.tsx': downloadText,

        '.json': downloadJson,
        '.ExportJson': downloadJson,
        '.plist': downloadText,

        '.fnt': downloadText,

        // Binary
        '.binary': downloadArrayBuffer,
        '.bin': downloadArrayBuffer,
        '.dbbin': downloadArrayBuffer,
        '.skel': downloadArrayBuffer,

        '.js': cc.assetManager.downloader.downloadScript,

        bundle: downloadBundle,

        default: downloadText,
    };

    // register
    cc.js.mixin(cc.assetManager.downloader._downloaders, downloaders);
})();

/**
 * 扩展 cc.js 支持同名类重复注册，用于远程分包不重启更新
 * 参考：
 * https://forum.cocos.org/t/topic/127593
 * https://store.cocos.com/app/detail/3841
 */
(function () {
    /**
     * 移除同名类 id
     * @param classId
     * @param constructor
     */
    function removeSameClassId(classId: string, constructor: Function) {
        let _idToClass = cc.js._registeredClassIds;
        let registered = _idToClass[classId];
        if (registered && registered !== constructor) {
            delete _idToClass[classId];
            cc.js._registeredClassIds = _idToClass;
        }
    }

    /**
     * 移除同名类名称
     * @param className
     * @param constructor
     */
    function removeSameClassName(className: string, constructor: Function) {
        let _nameToClass = cc.js._registeredClassNames;
        let registered = _nameToClass[className];
        if (registered && registered !== constructor) {
            delete _nameToClass[className];
            cc.js._registeredClassNames = _nameToClass;
        }
    }

    // @ts-ignore
    const _setClassIdEngine = cc.js._setClassId;
    // @ts-ignore
    cc.js._setClassId = function (classId, constructor) {
        removeSameClassId(classId, constructor);
        _setClassIdEngine(classId, constructor);
    };

    const setClassNameEngine = cc.js.setClassName;
    cc.js.setClassName = function (className: string, constructor: Function) {
        removeSameClassId(className, constructor);
        removeSameClassName(className, constructor);
        setClassNameEngine(className, constructor);
    };
})();

/**
 * 扩展 cc.game
 */
(function () {
    // @ts-ignore
    cc.game.restartRaw = cc.game.restart;
    cc.game.restart = function () {
        we?.core?.audioMgr?.uncacheAll();
        if (cc.sys.isNative) {
            if ([ScreenOrientation.PORTRAIT, ScreenOrientation.PORTRAIT_UPSIDE_DOWN].includes(we.core.projectConfig.orientation)) {
                // 当前是竖屏时先恢复到app壳默认方向再重启
                we.core.nativeUtil.setScreenOrientation(ScreenOrientation.LANDSCAPE_RIGHT);
            }

            // @ts-ignore
            cc.game.restartRaw();
        } else {
            window.location.reload();
        }
    };

    cc.game.off(cc.game.EVENT_RESTART, onEventGameRestart);
    cc.game.on(cc.game.EVENT_RESTART, onEventGameRestart);

    /**
     * 游戏重启
     */
    function onEventGameRestart() {
        we.log(`cc.game.onEventGameRestart`);
        AssetManager.clear();
    }

    let showFlag: number = 0;
    let hideFlag: number = 0;

    cc.game.off(cc.game.EVENT_SHOW, onEventGameShow);
    cc.game.on(cc.game.EVENT_SHOW, onEventGameShow);
    cc.game.off(cc.game.EVENT_HIDE, onEventGameHide);
    cc.game.on(cc.game.EVENT_HIDE, onEventGameHide);

    /**
     * 游戏切前台
     */
    function onEventGameShow() {
        we.log(`cc.game.onEventGameShow`);

        hideFlag = 0;
        showFlag += 1;
        if (showFlag != 1) {
            return;
        }
        // Web Audio 在 iOS 的浏览器上播放时，如果切换前后台，大概率会出现无法正常暂停和恢复播放的问题
        // 参考文档：https://docs.cocos.com/creator/2.4/manual/zh/getting-started/faq.html
        if (cc.sys.isBrowser && cc.sys.os === cc.sys.OS_IOS) {
            // 这里需要延迟一定时间，秒恢复播放，避免切前台时，音频状态还未设置完，出现无法播放的问题
            setTimeout(() => {
                if (cc.sys['__audioSupport']) {
                    cc.sys['__audioSupport'].context.resume();
                }
                AudioManager.resumeAll();
            }, 1000);
        } else {
            AudioManager.resumeAll();
        }
        cc.director.emit(BasicEventName.GAME_SHOW);
    }

    /**
     * 游戏切后台
     */
    function onEventGameHide() {
        we.log(`cc.game.onEventGameHide`);

        showFlag = 0;
        hideFlag += 1;
        if (hideFlag != 1) {
            return;
        }
        // Web Audio 在 iOS 的浏览器上播放时，如果切换前后台，大概率会出现无法正常暂停和恢复播放的问题
        // 参考文档：https://docs.cocos.com/creator/2.4/manual/zh/getting-started/faq.html
        if (cc.sys.isBrowser && cc.sys.os === cc.sys.OS_IOS) {
            if (cc.sys['__audioSupport']) {
                cc.sys['__audioSupport'].context.suspend();
            }
        }
        AudioManager.pauseAll();
        cc.director.emit(BasicEventName.GAME_HIDE);
    }
})();

/**
 * 扩展 cc.internal.eventManager
 */
(function () {
    /**
     * 全屏事件注册
     */
    // @ts-ignore
    let touchListener = cc.EventListener.create({
        // @ts-ignore
        event: cc.EventListener.TOUCH_ONE_BY_ONE,
        swallowTouches: false,
        onTouchBegan: (event: cc.Touch) => {
            cc.director.emit(BasicEventName.FULL_TOUCH_START, event);
            return true;
        },
        onTouchMoved: (event: cc.Touch) => {
            cc.director.emit(BasicEventName.FULL_TOUCH_MOVE, event);
        },
        onTouchEnded: (event: cc.Touch) => {
            cc.director.emit(BasicEventName.FULL_TOUCH_END, event);
        },
        onTouchCancelled: (event: cc.Touch) => {
            cc.director.emit(BasicEventName.FULL_TOUCH_CANCEL, event);
        },
    });

    // @ts-ignore
    cc.internal.eventManager.addListener(touchListener, -1);
})();

/**
 * 扩展 cc.textUtils
 */
(function () {
    /* eslint-disable no-misleading-character-class */

    const cc = <any>window.cc;

    /**
     * 多语言换行问题
     * 参考: https://github.com/cocos/cocos-engine/issues/6992
     * 修改 engine/cocos2d/core/utils/text-utils.js
     * - 印地语: \u0900-\u097F\uA8E0-\uA8FF
     * - 乌尔都语: \u0600-\u06FF\u0750-\u077F\u08A0-\u08FF
     */
    cc.textUtils.label_wordRex = /([a-zA-Z0-9ÄÖÜäöüßéèçàùêâîôûа-яА-ЯЁё\u0900-\u097F\uA8E0-\uA8FF\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+|\S)/;
    cc.textUtils.label_symbolRex = /^[!,.:;'}\]%\?>、‘“》？。，！]/;
    cc.textUtils.label_lastWordRex =
        /([a-zA-Z0-9ÄÖÜäöüßéèçàùêâîôûаíìÍÌïÁÀáàÉÈÒÓòóŐőÙÚŰúűñÑæÆœŒÃÂãÔõěščřžýáíéóúůťďňĚŠČŘŽÁÍÉÓÚŤżźśóńłęćąŻŹŚÓŃŁĘĆĄ-яА-ЯЁё\u0900-\u097F\uA8E0-\uA8FF\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+|\S)$/;
    cc.textUtils.label_lastEnglish = /[a-zA-Z0-9ÄÖÜäöüßéèçàùêâîôûаíìÍÌïÁÀáàÉÈÒÓòóŐőÙÚŰúűñÑæÆœŒÃÂãÔõěščřžýáíéóúůťďňĚŠČŘŽÁÍÉÓÚŤżźśóńłęćąŻŹŚÓŃŁĘĆĄ-яА-ЯЁё\u0900-\u097F\uA8E0-\uA8FF\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+$/;
    cc.textUtils.label_firstEnglish = /^[a-zA-Z0-9ÄÖÜäöüßéèçàùêâîôûаíìÍÌïÁÀáàÉÈÒÓòóŐőÙÚŰúűñÑæÆœŒÃÂãÔõěščřžýáíéóúůťďňĚŠČŘŽÁÍÉÓÚŤżźśóńłęćąŻŹŚÓŃŁĘĆĄ-яА-ЯЁё\u0900-\u097F\uA8E0-\uA8FF\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/;
})();

/**
 * 扩展 cc.Node
 */
(function () {
    /**
     * 添加节点 touchstart touchend 广播
     */
    // @ts-ignore
    cc.Node.prototype.dispatchEventRaw = cc.Node.prototype.dispatchEvent;
    cc.Node.prototype.dispatchEvent = function (event) {
        // @ts-ignore
        cc.Node.prototype.dispatchEventRaw.call(this, event);

        if (event) {
            switch (event.type) {
                case 'touchstart':
                    cc.director.emit(BasicEventName.NODE_TOUCH_START, event);
                    break;
                case 'touchend':
                    cc.director.emit(BasicEventName.NODE_TOUCH_END, event);
                    break;
                default:
                    break;
            }
        }
    };

    cc.Node.prototype.addComponentUnique = function (type) {
        return this.getComponent(type) || this.addComponent(type);
    };

    /**
     * 通过路径获取节点的子节点
     */
    cc.Node.prototype.getChildByPath = function (path: string) {
        const parts = path.split('/');

        function findChild(currentNode, pathParts) {
            if (pathParts.length === 0) {
                return currentNode;
            }

            const childName = pathParts.shift();
            for (const child of currentNode.children) {
                if (child.name === childName) {
                    return findChild(child, pathParts);
                }
            }

            return null;
        }

        return findChild(this, parts);
    };
})();

/**
 * 扩展 cc.WebView
 */
(function () {
    // @ts-ignore
    if (!cc.WebView.prototype.canGoBack) {
        // @ts-ignore
        cc.WebView.prototype.canGoBack = function () {
            if (this._impl) {
                return this._impl.canGoBack();
            }
        };
    }

    // @ts-ignore
    if (!cc.WebView.prototype.canGoForward) {
        // @ts-ignore
        cc.WebView.prototype.canGoForward = function () {
            if (this._impl) {
                return this._impl.canGoForward();
            }
        };
    }

    // @ts-ignore
    if (!cc.WebView.prototype.goBack) {
        // @ts-ignore
        cc.WebView.prototype.goBack = function () {
            if (this._impl) {
                this._impl.goBack();
            }
        };
    }

    // @ts-ignore
    if (!cc.WebView.prototype.goForward) {
        // @ts-ignore
        cc.WebView.prototype.goForward = function () {
            if (this._impl) {
                this._impl.goForward();
            }
        };
    }

    // @ts-ignore
    if (!cc.WebView.prototype.reload) {
        // @ts-ignore
        cc.WebView.prototype.reload = function () {
            if (this._impl) {
                this._impl.reload();
            }
        };
    }

    if (!cc.WebView.prototype.setBackgroundTransparent) {
        cc.WebView.prototype.setBackgroundTransparent = function (isTransparent) {
            if (this._impl) {
                this._impl.setBackgroundTransparent(isTransparent);
            }
        };
    }

    // @ts-ignore
    if (!cc.WebView.Impl.prototype.setBackgroundTransparent) {
        // @ts-ignore
        cc.WebView.Impl.prototype.setBackgroundTransparent = function (isTransparent) {
            let iframe = this._iframe;
            if (iframe && iframe.setBackgroundTransparent) {
                iframe.setBackgroundTransparent(isTransparent);
            }
        };
    }

    if (!cc.WebView.prototype.setOpacity) {
        cc.WebView.prototype.setOpacity = function (opacity) {
            if (this._impl) {
                this._impl.setOpacity(opacity);
            }
        };
    }

    // @ts-ignore
    if (!cc.WebView.Impl.prototype.setOpacity) {
        // @ts-ignore
        cc.WebView.Impl.prototype.setOpacity = function (opacity) {
            let iframe = this._iframe;
            if (iframe && iframe.setOpacity) {
                iframe.setOpacity(opacity);
            }
        };
    }

    // 修复 web平台 webview 缩小网页内容的问题
    // @ts-ignore
    cc.WebView.Impl.prototype._updateSizeBk = cc.WebView.Impl.prototype._updateSize;
    // @ts-ignore
    cc.WebView.Impl.prototype._updateSize = function (w, h) {
        if (cc.sys.isNative) {
            // @ts-ignore
            cc.WebView.Impl.prototype._updateSizeBk.call(this, w, h);
            return;
        }

        // size / 2
        let div = this._div;
        if (div) {
            div.style.width = w / 2 + 'px';
            div.style.height = h / 2 + 'px';
        }
    };

    // 修复 web平台 webview 缩小网页内容的问题
    // @ts-ignore
    cc.WebView.Impl.prototype.updateMatrixBk = cc.WebView.Impl.prototype.updateMatrix;
    // @ts-ignore
    cc.WebView.Impl.prototype.updateMatrix = function (node) {
        if (cc.sys.isNative) {
            // @ts-ignore
            cc.WebView.Impl.prototype.updateMatrixBk.call(this, node);
            return;
        }

        // scale * 2
        if (!this._div || !this._visible) {
            return;
        }

        // init _mat4_temp
        if (this._mat4_temp == null) {
            this._mat4_temp = cc.mat4();
        }
        let _mat4_temp = this._mat4_temp;

        node.getWorldMatrix(_mat4_temp);

        // @ts-ignore
        let renderCamera = cc.Camera._findRendererCamera(node);
        if (renderCamera) {
            renderCamera.worldMatrixToScreen(_mat4_temp, _mat4_temp, cc.game.canvas.width, cc.game.canvas.height);
        }

        let _mat4_tempm = _mat4_temp.m;
        if (
            !this._forceUpdate &&
            this._m00 === _mat4_tempm[0] &&
            this._m01 === _mat4_tempm[1] &&
            this._m04 === _mat4_tempm[4] &&
            this._m05 === _mat4_tempm[5] &&
            this._m12 === _mat4_tempm[12] &&
            this._m13 === _mat4_tempm[13] &&
            this._w === node._contentSize.width &&
            this._h === node._contentSize.height
        ) {
            return;
        }

        // update matrix cache
        this._m00 = _mat4_tempm[0];
        this._m01 = _mat4_tempm[1];
        this._m04 = _mat4_tempm[4];
        this._m05 = _mat4_tempm[5];
        this._m12 = _mat4_tempm[12];
        this._m13 = _mat4_tempm[13];
        this._w = node._contentSize.width;
        this._h = node._contentSize.height;

        // @ts-ignore
        let dpr = cc.view._devicePixelRatio;
        let scaleX = 1 / dpr;
        let scaleY = 1 / dpr;

        // scale * 2
        scaleX *= 2;
        scaleY *= 2;

        let container = cc.game.container;
        let a = _mat4_tempm[0] * scaleX,
            b = _mat4_tempm[1],
            c = _mat4_tempm[4],
            d = _mat4_tempm[5] * scaleY;

        let offsetX = container && container.style.paddingLeft ? parseInt(container.style.paddingLeft) : 0;
        let offsetY = container && container.style.paddingBottom ? parseInt(container.style.paddingBottom) : 0;
        this._updateSize(this._w, this._h);
        let w = this._w * scaleX;
        let h = this._h * scaleY;

        let appx = w * _mat4_tempm[0] * node._anchorPoint.x;
        let appy = h * _mat4_tempm[5] * node._anchorPoint.y;

        let tx = _mat4_tempm[12] * scaleX - appx + offsetX,
            ty = _mat4_tempm[13] * scaleY - appy + offsetY;

        // scale / 2
        tx /= 2;
        ty /= 2;

        let matrix = 'matrix(' + a + ',' + -b + ',' + -c + ',' + d + ',' + tx + ',' + -ty + ')';
        this._div.style['transform'] = matrix;
        this._div.style['-webkit-transform'] = matrix;
        this._div.style['transform-origin'] = '0px 100% 0px';
        this._div.style['-webkit-transform-origin'] = '0px 100% 0px';

        // chagned iframe opacity
        this._setOpacity(node.opacity);
        this._forceUpdate = false;
    };
})();

/**
 * 扩展 cc.EditBox
 */
(function () {
    if (CC_EDITOR || CC_JSB) {
        return;
    }

    // @ts-ignore
    cc.EditBox.prototype.backupOriginalProperty = function () {
        if (this.backuped) {
            return;
        }
        this.backuped = true;

        // node
        if (this.node.original === undefined) {
            this.node.original = {
                parent: this.node.parent,
                zIndex: this.node.zIndex,
                siblingIndex: this.node.getSiblingIndex(),
                anchorX: this.node.anchorX,
                anchorY: this.node.anchorY,
                position: this.node.position,
                width: this.node.width,
                height: this.node.height,
            };
        }

        // textLabel
        if (this.textLabel.original === undefined) {
            this.textLabel.original = {
                anchorX: this.textLabel.node.anchorX,
                anchorY: this.textLabel.node.anchorY,
                color: this.textLabel.node.color,
                horizontalAlign: this.textLabel.horizontalAlign,
                verticalAlign: this.textLabel.verticalAlign,
                fontSize: this.textLabel.fontSize,
                lineHeight: this.textLabel.lineHeight,
            };

            let widget: cc.Widget = this.textLabel.node.getComponent(cc.Widget);
            if (widget) {
                this.textLabel.original.widget = {
                    enabled: widget.enabled,
                    isAlignTop: widget.isAlignTop,
                    top: widget.top,
                    isAlignBottom: widget.isAlignBottom,
                    bottom: widget.bottom,
                    isAlignLeft: widget.isAlignLeft,
                    left: widget.left,
                    isAlignRight: widget.isAlignRight,
                    right: widget.right,
                };
            } else {
                widget = this.textLabel.node.addComponent(cc.Widget);
                widget.enabled = false;
            }
            this.textLabel.nodeWidget = widget;
        }

        // background
        if (this.background_original === undefined) {
            this.background_original = this.background;
        }
        if (this.background_temp === undefined) {
            let background_temp = new cc.Node('background_temp').addComponent(cc.Sprite);
            background_temp.node.parent = this.node;
            background_temp.node.opacity = 0;

            let texture = new cc.Texture2D();
            texture.initWithData(<any>new Uint8Array([255, 255, 255]), cc.Texture2D.PixelFormat.RGB888, 1, 1);
            background_temp.spriteFrame = new cc.SpriteFrame();
            background_temp.spriteFrame.setTexture(texture);

            let widget = background_temp.node.addComponent(cc.Widget);
            widget.isAlignTop = true;
            widget.top = 0;
            widget.isAlignBottom = true;
            widget.bottom = 0;
            widget.isAlignLeft = true;
            widget.left = -100;
            widget.isAlignRight = true;
            widget.right = -100;

            this.background_temp = background_temp;
        }
    };

    // @ts-ignore
    cc.EditBox.prototype.restoreOriginalProperty = function () {
        if (!this.changed) {
            return;
        }
        this.changed = false;
        this.backupOriginalProperty();

        if (this.node.parent !== this.node.original.parent) {
            this.node.parent = this.node.original.parent;
            this.node.zIndex = this.node.original.zIndex;
            this.node.setSiblingIndex(this.node.original.siblingIndex);
        }
        this.node.anchorX = this.node.original.anchorX;
        this.node.anchorY = this.node.original.anchorY;
        this.node.position = this.node.original.position;
        this.node.width = this.node.original.width;
        this.node.height = this.node.original.height;

        this.textLabel.node.anchorX = this.textLabel.original.anchorX;
        this.textLabel.node.anchorY = this.textLabel.original.anchorY;
        this.textLabel.node.color = this.textLabel.original.color;
        this.textLabel.horizontalAlign = this.textLabel.original.horizontalAlign;
        this.textLabel.verticalAlign = this.textLabel.original.verticalAlign;
        this.textLabel.fontSize = this.textLabel.original.fontSize;
        this.textLabel.lineHeight = this.textLabel.original.lineHeight;
        if (this.textLabel.original.widget) {
            this.textLabel.nodeWidget.enabled = this.textLabel.original.widget.enabled;
            this.textLabel.nodeWidget.isAlignTop = this.textLabel.original.widget.isAlignTop;
            this.textLabel.nodeWidget.top = this.textLabel.original.widget.top;
            this.textLabel.nodeWidget.isAlignBottom = this.textLabel.original.widget.isAlignBottom;
            this.textLabel.nodeWidget.bottom = this.textLabel.original.widget.bottom;
            this.textLabel.nodeWidget.isAlignLeft = this.textLabel.original.widget.isAlignLeft;
            this.textLabel.nodeWidget.left = this.textLabel.original.widget.left;
            this.textLabel.nodeWidget.isAlignRight = this.textLabel.original.widget.isAlignRight;
            this.textLabel.nodeWidget.right = this.textLabel.original.widget.right;
        } else {
            this.textLabel.nodeWidget.enabled = false;
        }

        // 切换了父节点通过对焦刷新文本
        this.blur();

        this.background.node.opacity = 0;
        this.background = this.background_original;
        if (this.background) {
            this.background.node.opacity = 255;
        }

        let widgets = this.node.getComponentsInChildren(cc.Widget);
        for (let i = 0; i < widgets.length; i++) {
            widgets[i].updateAlignment();
        }
    };

    // @ts-ignore
    cc.EditBox.prototype.onKeyboardHeightChanged = function (keyboardHeight: number, screenHeight: number) {
        if (!(keyboardHeight > 0 && keyboardHeight * 3 > screenHeight)) {
            return;
        }

        if (!this.editActive) {
            return;
        }

        if (this.changed) {
            return;
        }
        this.changed = true;

        let rootNode = we.ui.UILayer.rootNode;
        if (!cc.isValid(rootNode)) {
            return;
        }

        this.backupOriginalProperty();

        if (this.node.parent !== rootNode) {
            this.node.parent = rootNode;
            this.node.zIndex = cc.macro.MAX_ZINDEX;
        }
        this.node.anchorX = 0.5;
        this.node.anchorY = 0.5;
        let nodeHeight = 70;
        let posWorld = cc.v2(cc.winSize.width / 2, (cc.winSize.height * keyboardHeight) / screenHeight + nodeHeight / 2);
        this.node.position = this.node.parent.convertToNodeSpaceAR(posWorld);
        let notchHeight = ProjectConfig.isNotch && ProjectConfig.orientation == we.core.ScreenOrientation.LANDSCAPE_RIGHT ? 60 : 0;
        this.node.width = cc.winSize.width - notchHeight * 2;
        this.node.height = nodeHeight;

        this.textLabel.node.anchorX = 0;
        this.textLabel.node.anchorY = 1;
        this.textLabel.node.color = new cc.Color(0, 0, 0, 255);
        this.textLabel.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        this.textLabel.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.textLabel.fontSize = 36;
        this.textLabel.lineHeight = 38;
        this.textLabel.nodeWidget.enabled = true;
        this.textLabel.nodeWidget.isAlignTop = true;
        this.textLabel.nodeWidget.top = 0;
        this.textLabel.nodeWidget.isAlignBottom = true;
        this.textLabel.nodeWidget.bottom = 0;
        this.textLabel.nodeWidget.isAlignLeft = true;
        this.textLabel.nodeWidget.left = 2;
        this.textLabel.nodeWidget.isAlignRight = true;
        this.textLabel.nodeWidget.right = 2;

        // 切换了父节点通过对焦刷新文本
        this.focus();

        if (this.background) {
            this.background.node.opacity = 0;
        }
        this.background = this.background_temp;
        this.background.node.opacity = 255;

        let widgets = this.node.getComponentsInChildren(cc.Widget);
        for (let i = 0; i < widgets.length; i++) {
            widgets[i].updateAlignment();
        }
    };

    // TODO 适配马甲包
    let h5v = false;

    // @ts-ignore
    cc.EditBox.prototype.onLoadBk = cc.EditBox.prototype.onLoad;
    // @ts-ignore
    cc.EditBox.prototype.onLoad = function () {
        // @ts-ignore
        if (typeof cc.EditBox.prototype.onLoadBk == 'function') {
            // @ts-ignore
            cc.EditBox.prototype.onLoadBk.call(this);
        }

        if (h5v) {
            cc.director.on(BasicEventName.KEYBOARD_HEIGHT_CHANGED, this.onKeyboardHeightChanged, this);
        }
    };

    // @ts-ignore
    cc.EditBox.prototype.onDestroyBk = cc.EditBox.prototype.onDestroy;
    // @ts-ignore
    cc.EditBox.prototype.onDestroy = function () {
        if (h5v) {
            cc.director.off(BasicEventName.KEYBOARD_HEIGHT_CHANGED, this.onKeyboardHeightChanged, this);
        }

        // @ts-ignore
        cc.EditBox.prototype.onDestroyBk.call(this);
    };

    // @ts-ignore
    cc.EditBox.prototype.editBoxEditingDidBeganBk = cc.EditBox.prototype.editBoxEditingDidBegan;
    // @ts-ignore
    cc.EditBox.prototype.editBoxEditingDidBegan = function () {
        if (h5v) {
            this.editActive = true;
        }

        // @ts-ignore
        cc.EditBox.prototype.editBoxEditingDidBeganBk.call(this);
    };

    // @ts-ignore
    cc.EditBox.prototype.editBoxEditingDidEndedBk = cc.EditBox.prototype.editBoxEditingDidEnded;
    // @ts-ignore
    cc.EditBox.prototype.editBoxEditingDidEnded = function () {
        if (h5v) {
            this.editActive = false;
            this.restoreOriginalProperty();
        }

        // @ts-ignore
        cc.EditBox.prototype.editBoxEditingDidEndedBk.call(this);
    };

    // @ts-ignore
    cc.EditBox.prototype.editBoxEditingReturnBk = cc.EditBox.prototype.editBoxEditingReturn;
    // @ts-ignore
    cc.EditBox.prototype.editBoxEditingReturn = function () {
        if (h5v) {
            this.editActive = false;
            this.restoreOriginalProperty();
        }

        // @ts-ignore
        cc.EditBox.prototype.editBoxEditingReturnBk.call(this);
    };
})();

/**
 * 修复 skeleton setCompleteListener 在原生上的报错问题
 */
(function () {
    // h5 不用管
    if (!cc.sys.isNative) {
        return;
    }

    /**
     * 由于 jsb-engine.js 中对 setCompleteListener 重定义的导入是在 cc.game.EVENT_GAME_INITE 后，
     * 所以此处也需要在 cc.game.EVENT_GAME_INITED 后，否则会覆盖不到
     */
    cc.game.on(cc.game.EVENT_GAME_INITED, () => {
        // 原生重写
        sp.Skeleton.prototype.setCompleteListener = function (listener: Function) {
            this._completeListener = listener;

            if (this._nativeSkeleton) {
                if (this.isAnimationCached()) {
                    this._nativeSkeleton.setCompleteListener(function (animationName) {
                        const self = this._comp;
                        self?._endEntry?.animation && // 这一行增加一个前置条件，修复报错
                            (self._endEntry.animation.name = animationName);
                        self._completeListener && self._completeListener(self?._endEntry); // 增加一个访问操作符 提高容错率
                    });
                } else {
                    this._nativeSkeleton.setCompleteListener(listener);
                }
            }
        };
    });
})();

/**
 * 编辑器模式下运行spine，跳过修改源码的步骤
 */
if (CC_EDITOR) {
    // 重写update方法 达到在编辑模式下 自动播放动画的功能
    sp.Skeleton.prototype['update'] = function (dt) {
        if (CC_EDITOR) {
            cc['engine']._animatingInEditMode = 1;
            cc['engine'].animatingInEditMode = 1;
        }
        if (this.paused) {
            return;
        }
        dt *= this.timeScale * sp['timeScale'];
        if (this.isAnimationCached()) {
            // Cache mode and has animation queue.
            if (this._isAniComplete) {
                if (this._animationQueue.length === 0 && !this._headAniInfo) {
                    let frameCache = this._frameCache;
                    if (frameCache && frameCache.isInvalid()) {
                        frameCache.updateToFrame();
                        let frames = frameCache.frames;
                        this._curFrame = frames[frames.length - 1];
                    }
                    return;
                }
                if (!this._headAniInfo) {
                    this._headAniInfo = this._animationQueue.shift();
                }
                this._accTime += dt;
                if (this._accTime > this._headAniInfo.delay) {
                    let aniInfo = this._headAniInfo;
                    this._headAniInfo = null;
                    this.setAnimation(0, aniInfo.animationName, aniInfo.loop);
                }
                return;
            }

            this._updateCache(dt);
        } else {
            this._updateRealtime(dt);
        }
    };
}

// 自动释放资源
cc.Component.prototype.addAutoReleaseAsset = function (_asset: cc.Asset) {
    if (!cc.isValid(this.node)) {
        return;
    }
    let oneTempAuto = this.node.getComponent(AutoReleaseAssets) as AutoReleaseAssets;
    if (!cc.isValid(oneTempAuto)) {
        oneTempAuto = this.node.addComponent(AutoReleaseAssets);
    }
    oneTempAuto.addAutoReleaseAsset(_asset);
};

// 自动释放资源组
cc.Component.prototype.addAutoReleaseAssets = function (_assets: cc.Asset[]) {
    if (!cc.isValid(this.node)) {
        return;
    }
    let moreTempAuto = this.node.getComponent(AutoReleaseAssets) as AutoReleaseAssets;
    if (!cc.isValid(moreTempAuto)) {
        moreTempAuto = this.node.addComponent(AutoReleaseAssets);
    }
    for (const _assetSelf of _assets) {
        moreTempAuto.addAutoReleaseAsset(_assetSelf);
    }
};

/**
 * CC_DEBUG 模式 查看 label 缓存纹理
 * 控制台调用：cc.Label.prototype.showDebug(true)
 * 关闭：cc.Label.prototype.showDebug(false)
 */
if (CC_DEBUG) {
    (() => {
        // @ts-ignore
        cc.Label.prototype.showDebug = function (show) {
            if (show) {
                if (!this._debugNode || !this._debugNode.isValid) {
                    let width = cc.visibleRect.width;
                    let height = cc.visibleRect.height;

                    this._debugNode = new cc.Node('SHAREATLAS_DEBUG_NODE');
                    this._debugNode.width = width;
                    this._debugNode.height = height;
                    this._debugNode.x = width / 2;
                    this._debugNode.y = height / 2;
                    this._debugNode.zIndex = cc.macro.MAX_ZINDEX;
                    this._debugNode.parent = cc.director.getScene();

                    // @ts-ignore
                    this._debugNode.groupIndex = cc.Node.BuiltinGroupIndex.DEBUG;
                    // @ts-ignore
                    cc.Camera._setupDebugCamera();

                    let scroll = this._debugNode.addComponent(cc.ScrollView);

                    let content = new cc.Node('CONTENT');
                    let layout = content.addComponent(cc.Layout);
                    layout.type = cc.Layout.Type.VERTICAL;
                    layout.resizeMode = cc.Layout.ResizeMode.CONTAINER;
                    content.parent = this._debugNode;
                    content.width = 2048;
                    content.anchorY = 1;
                    content.x = 2048;

                    scroll.content = content;

                    let node = new cc.Node('ATLAS');
                    // @ts-ignore
                    let texture = cc.Label._shareAtlas.getTexture();
                    let spriteFrame = new cc.SpriteFrame();
                    spriteFrame.setTexture(texture);

                    let sprite = node.addComponent(cc.Sprite);
                    sprite.spriteFrame = spriteFrame;

                    node.parent = content;
                }
                return this._debugNode;
            } else {
                if (this._debugNode) {
                    this._debugNode.parent = null;
                    this._debugNode = null;
                }
            }
        };
    })();
}
