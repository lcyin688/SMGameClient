const { ccclass, disallowMultiple } = cc._decorator;

@ccclass
@disallowMultiple
export default class AutoReleaseAssets extends cc.Component {
    private _dynamicsAssets: cc.Asset[] = [];

    public addAutoReleaseAsset(_asset: cc.Asset) {
        if (cc.isValid(_asset)) {
            _asset.addRef();
            this._dynamicsAssets.push(_asset);
        }
    }

    onDestroy(): void {
        for (let index = 0; index < this._dynamicsAssets.length; index++) {
            if (cc.isValid(this._dynamicsAssets[index])) {
                this._dynamicsAssets[index].decRef();
            }
        }
        this._dynamicsAssets.length = 0;
    }
}
