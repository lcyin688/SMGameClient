/**
 * 引擎定制代码提示
 */
declare namespace cc {
    /**
     * type 支持 symbol 格式
     */
    interface EventTarget {
        on<T extends Function>(type: string | symbol, callback: T, target?: any, useCapture?: boolean): T;
        once<T extends Function>(type: string | symbol, callback: T, target?: any, useCapture?: boolean): T;
        off(type: string | symbol, callback?: Function, target?: any, useCapture?: boolean): void;
        emit(type: string | symbol, arg1?: any, arg2?: any, arg3?: any, arg4?: any, arg5?: any): void;
    }

    interface Node {
        /**
         * 节点和 Entity 组件关联 ID
         */
        __entityId__?: number;

        /**
         * 添加唯一组件
         * @param type
         */
        addComponentUnique<T extends cc.Component>(type: { new (): T }): T;

        /**
         * 通过路径获取节点的子节点
         * @param path
         */
        getChildByPath(path: string): cc.Node | null;
    }

    interface Component {
        /**
         * 自动释放资源
         * @param asset 
         */
        public addAutoReleaseAsset(asset: cc.Asset): void;

        /**
         * 自动释放资源列表
         * @param asset 
         */
        public addAutoReleaseAssets(asset: cc.Asset[]): void;
    }

    type TweenEasing = ((k: number) => number) | 'linear' | 'quadIn' | 'quadOut' | 'quadInOut' | 'cubicIn' | 'cubicOut' | 'cubicInOut' | 'quartIn' | 'quartOut' | 'quartInOut' | 'quintIn' | 'quintOut' | 'quintInOut' | 'sineIn' | 'sineOut' | 'sineInOut' | 'expoIn' | 'expoOut' | 'expoInOut' | 'circIn' | 'circOut' | 'circInOut' | 'elasticIn' | 'elasticOut' | 'elasticInOut' | 'backIn' | 'backOut' | 'backInOut' | 'bounceIn' | 'bounceOut' | 'bounceInOut' | 'smooth' | 'fade'
    /** !#en
	Tween provide a simple and flexible way to create action. Tween's api is more flexible than `cc.Action`:
	 - Support creating an action sequence in chained api.
	 - Support animate any objects' any properties, not limited to node's properties. By contrast, `cc.Action` needs to create a new action class to support new node property.
	 - Support working with `cc.Action`.
	 - Support easing and progress function.
	!#zh
	Tween 提供了一个简单灵活的方法来创建 action。相对于 Cocos 传统的 `cc.Action`，`cc.Tween` 在创建动画上要灵活非常多：
	 - 支持以链式结构的方式创建一个动画序列。
	 - 支持对任意对象的任意属性进行缓动，不再局限于节点上的属性，而 `cc.Action` 添加一个属性的支持时还需要添加一个新的 action 类型。
	 - 支持与 `cc.Action` 混用。
	 - 支持设置 {{#crossLink "Easing"}}{{/crossLink}} 或者 progress 函数。 */
	interface Tween<T = any> {		
		/**
		!#en Blinks target by set target's opacity property
		!#zh 通过设置目标的 opacity 属性达到闪烁效果
		@param duration duration
		@param times times
		@param opts opts 
		*/
		blink(duration: number, times: number, opts?: {progress?: Function; easing?: TweenEasing; }): Tween<T>;		
		/**
		!#en
		Add an action which calculate with absolute value
		!#zh
		添加一个对属性进行绝对值计算的 action
		@param duration duration
		@param props {scale: 2, position: cc.v3(100, 100, 100)}
		@param opts opts 
		*/
		to <OPTS extends Partial<{progress: Function, easing: TweenEasing}>> (duration: number, props: ConstructorType<T>, opts?: OPTS): Tween<T>;		
		/**
		!#en
		Add an action which calculate with relative value
		!#zh
		添加一个对属性进行相对值计算的 action
		@param duration duration
		@param props {scale: 2, position: cc.v3(100, 100, 100)}
		@param opts opts 
		*/
		by <OPTS extends Partial<{progress: Function, easing: TweenEasing}>> (duration: number, props: ConstructorType<T>, opts?: OPTS): Tween<T>;		
	}

    /**
	@param target the target to animate 
	*/
	export function tween<T> (target?: T): Tween<T>;
	
	interface WebView {
        /**
         * 设置背景是否透明
         * @param isTransparent 
         */
        setBackgroundTransparent(isTransparent: boolean): void;
        /**
         * 设置透明度
         * @param opacity 透明度
         */
        setOpacity(opacity: number): void;
    }
}
