import WeGame from './WeGame';
import BasicEventName from './const/BasicEventName';

const { ccclass, property } = cc._decorator;

@ccclass
export default class Main extends cc.Component {
    @property({ type: cc.Prefab })
    traceNode: cc.Prefab = null;

    protected onLoad(): void {
        WeGame.init();

        cc.game.on(BasicEventName.RUN_LAUNCHER_SCENE_ENTER, () => {
            // 等待渲染合批初始化完成后再创建调试节点
            this.scheduleOnce(() => {
                this.node.addChild(cc.instantiate(this.traceNode), 999, 'TraceNode');
            }, 0.5);
        });
    }

    protected update(): void {
        WeGame.update();
    }

    protected lateUpdate(): void {
        WeGame.lateUpdate();
    }
}
