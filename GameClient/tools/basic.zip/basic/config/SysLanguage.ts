export class SysLanguage {
    static get lang() {
        return we.clientScene?.getComponent(we.ui.I18nData)?.lang;
    }

    static get COMMON_TIPS_EXIT() {
        return this.lang['COMMON_TIPS_EXIT'];
    }

    static get TIPS_NET_DISCONNECT() {
        return this.lang['TIPS_NET_DISCONNECT'];
    }

    static get LOAD_STATUS_LOCAL_ING() {
        return this.lang['LOAD_STATUS_LOCAL_ING'];
    }

    static get LOAD_STATUS_LOCAL_FAIL() {
        return this.lang['LOAD_STATUS_LOCAL_FAIL'];
    }

    static get TIPS_LOAD_ASSET_TIMEOUT() {
        return this.lang['TIPS_LOAD_ASSET_TIMEOUT'];
    }

    static get LOAD_STATUS_REMOTE_ING() {
        return this.lang['LOAD_STATUS_REMOTE_ING'];
    }

    static get LOAD_STATUS_REMOTE_FAIL() {
        return this.lang['LOAD_STATUS_REMOTE_FAIL'];
    }

    static get TIPS_NET_RECONNECT_FAIL() {
        return this.lang['TIPS_NET_RECONNECT_FAIL'];
    }
}
