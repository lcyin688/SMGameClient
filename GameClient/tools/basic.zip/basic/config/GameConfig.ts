import Flavor from '../flavor/Flavor';
import { ArrayHelper } from '../helper/ArrayHelper';
import NativeUtil from '../platform/NativeUtil';
import { BasicType } from '../type/BasicType';
import Utils from '../utils/Utils';
import { ScreenOrientation } from './ProjectConfig';
import { BrowserParamKey } from './ToolsConfig';

declare global {
    interface ICore {
        gameConfig: typeof GameConfig;
    }
    interface IWe {
        GameType: typeof GameType;
        SceneFrom: typeof SceneFrom;
    }
    interface TWe {
        GameType: GameType;
        SceneFrom: SceneFrom;
        IGameConfig: IGameConfig;
    }
    namespace we {
        /** 游戏厂商 Id */
        type GameVendor = number;
        /**
         * 游戏 Id, 遵循如下编码规则:
         * 自研内嵌游戏: [100-9999]
         * A 厂商: [10000-19999]
         * B 厂商: [20000-29999]
         * ...
         */
        type GameId = number;
        type GameType = TWe['GameType'];
        type IGameConfig = TWe['IGameConfig'];
    }
}

/** 游戏配置 */
interface IGameConfig {
    /** 游戏id */
    gameId: we.GameId;
    /** 游戏厂商Id, 默认自研: BasicType.SDGameVendorId */
    vendorId?: we.GameVendor;
    /**
     * TODO api 待删除 bundle 名称
     * @deprecated
     */
    bundleName: string;
    /** 依赖 bundle */
    dependBundles: string[];
    /** 游戏分类 */
    gameType: GameType;
    /** 屏幕方向,默认横屏 */
    screenOrientation?: ScreenOrientation;

    /** 游戏名称, 多语言版 */
    nameText?: { [k: string]: string };

    /** GameDetail icon. */
    icon?: api.GameIcon | null;
}

/** 分包配置 */
interface IBundleConfig {
    /** 版本号 */
    version: string;
    /** 下载链接 */
    url: string;
}

/** 房间信息 */
interface IRoomInfo extends api.RoomInfoResp {
    timestamp: number;
}

/** 大厅 bundle 名 */
export const BundleNames = {
    main: 'main',
    launcher: 'launcher',
    common: 'common',
    hall: 'hall',
    comwbg: 'comwbg',
};

we.bundles = BundleNames as any;

/**
 * 场景来源
 */
export enum SceneFrom {
    Self = 0,
    Launcher = 1,
    Game = 2,

    Other = 100,
}

we.SceneFrom = SceneFrom;

/** 是否使用原生本地开发测试 */
const nativeLpt = false;

/** 框架 bundle 列表 */
export const FrameBundles = ['internal', BundleNames.main];

/** 主包 bundle 列表 */
export const MainBundles = FrameBundles.concat(BundleNames.launcher).concat(nativeLpt && cc.sys.isNative ? [BundleNames.common, BundleNames.hall] : []);

/** 公共 bundle 列表 */
export const CommonBundles = FrameBundles.concat([BundleNames.launcher, BundleNames.common]);

/** 大厅 bundle 列表 */
export const LobbyBundles = CommonBundles.concat([BundleNames.hall]);

const GameId = {
    /** 无效 */
    UNDEFINED: -1,
    /** 接入服 */
    NAMING: 0,
    /** 启动 */
    LAUNCHER: 1,
    /** 大厅 */
    HALL: 3,
    /** 过渡场景 */
    TRANSITION: 4,
    /** api 游戏场景 */
    COMWBG: 5,
    /** <100 非子游戏 */
    TAG_SUB_GAME: 100,

    /** >1000 为视讯游戏 */
    TAG_LIVE_GAME: 1000,
    /** DG 游戏 */
    DG_GAME: 1001,
    /** AWC 性感平台 */
    AWC_SEXYBCRT: 2001,
    /** AWC 金星平台 */
    AWC_VENUS: 2002,

    /** slot 合集 */
    SLOT_GROUP: 10001,
    /** 百人场 合集 */
    MULTI_GROUP: 10002,
};

Object.entries(GameId).forEach(([k, v]) => {
    GameId[v] = k;
});

we.GameId = GameId as any;

/** 游戏类型 */
export enum GameType {
    NULL = -1,
    /** slot */
    SLOT = 1,
    /** 捕鱼 */
    FISH = 2,
    /** 对战 */
    FIGHT = 3,
    /** 百人 */
    MULTI = 4,
    /** 街机 */
    ARCADE = 5,
    /** 视讯 */
    VIDEO = 6,
    /** 单机、单人 */
    SINGLE = 7,
}

we.GameType = GameType;

export class GameConfig {
    /** 分包本地版本 */
    private static bundleLocalVersions: Map<string, string> = new Map<string, string>();
    /** 分包远程信息 */
    private static bundleRemoteInfo: Map<string, api.BundleConfig> = new Map<string, api.BundleConfig>();

    /** 当前游戏id */
    private static _curGameId: we.GameId = GameId.LAUNCHER;
    /** 上一个游戏id */
    private static _preGameId: we.GameId = GameId.LAUNCHER;
    /** 房间信息Map */
    private static _roomInfoMap: Map<we.GameId, IRoomInfo> = new Map<we.GameId, IRoomInfo>();

    /** 是否使用原生本地开发测试 */
    public static nativeLpt = nativeLpt;
    /**
     * 原生测试，资源下载地址，http://x.x.x.x
     * 自动替换包的外网地址为本地测试地址，本地资源路径和外网资源路径保持一致
     */
    public static nativeLptUrl = '';
    /** 原生测试，资源版本 */
    public static nativeLptVer = '5.5.5';

    public static gameId = GameId;

    public static toGameId(bundleName: string): we.GameId {
        return we.GameId[bundleName.toUpperCase()];
    }

    public static toBundleName(gameId: we.GameId): string {
        return we.GameId[gameId]?.toLowerCase();
    }

    // 子游戏配置
    private static GameList: IGameConfig[] = [
        {
            gameId: GameId.NAMING,
            bundleName: BundleNames.main,
            dependBundles: [],
            gameType: GameType.NULL,
        },
        {
            gameId: GameId.LAUNCHER,
            bundleName: BundleNames.launcher,
            dependBundles: [],
            gameType: GameType.NULL,
        },
        {
            gameId: we.GameId.HALL,
            bundleName: BundleNames.hall,
            dependBundles: [BundleNames.common],
            gameType: we.GameType.NULL,
        },
        {
            gameId: GameId.TRANSITION,
            bundleName: BundleNames.common,
            dependBundles: [],
            gameType: GameType.NULL,
        },
        {
            gameId: GameId.COMWBG,
            bundleName: BundleNames.comwbg,
            dependBundles: [],
            gameType: GameType.NULL,
        },
    ];

    /**
     * 获取模块版本
     * @param bundleName
     * @returns
     */
    public static getModuleVersion(bundleName: string): string {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`GameConfig getModuleVersion, params err`);
            return '';
        }

        let version = BasicType.VersionDefault;
        if (LobbyBundles.includes(bundleName)) {
            version = Flavor.getVersion();
        } else {
            if (this.bundleLocalVersions.has(bundleName)) {
                version = this.bundleLocalVersions.get(bundleName);
            }
        }

        return version;
    }

    /**
     * 获取分包本地版本
     * @param bundleName
     * @returns
     */
    public static getLocalVersion(bundleName: string): string {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`GameConfig getLocalVersion, params err`);
            return '';
        }

        let version = BasicType.VersionDefault;
        if (MainBundles.includes(bundleName)) {
            version = Flavor.getVersion();
        } else {
            if (this.bundleLocalVersions.has(bundleName)) {
                version = this.bundleLocalVersions.get(bundleName);
            }
        }

        return version;
    }

    /**
     * 设置分包本地版本
     * @param bundleName
     * @param version
     * @returns
     */
    public static setLocalVersion(bundleName: string, version: string): void {
        if (!(bundleName && version)) {
            return;
        }

        this.bundleLocalVersions.set(bundleName, version);
    }

    /**
     * 获取分包远程版本
     * @param bundleName
     * @returns
     */
    public static getRemoteVersion(bundleName: string): string {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`GameConfig getRemoteVersion, params err`);
            return '';
        }

        if (MainBundles.includes(bundleName)) {
            bundleName = BundleNames.main;
        }

        let version = this.bundleRemoteInfo.get(bundleName)?.version || BasicType.VersionDefault;
        if (cc.sys.isBrowser) {
            // h5 灰度测试分包, 通过参数修改版本号
            const bv = Utils.getLocationUrlParam(BrowserParamKey.bv);
            const bvObj = Utils.convertToKeyValue(bv);
            if (bvObj[bundleName]) {
                version = bvObj[bundleName];
            }
        }

        return version;
    }

    /**
     * 更新分包信息
     * @param data
     * @returns
     */
    public static updateBundleInfo(data: { [key: string]: api.BundleConfig }): void {
        if (!data) {
            we.warn(`GameConfig updateBundleInfo, data err`);
            return;
        }

        for (let bundleName in data) {
            let bundleConfig = data[bundleName];
            if (bundleConfig && bundleConfig.version && bundleConfig.urlH5 && bundleConfig.urlNative) {
                this.bundleRemoteInfo.set(bundleName, bundleConfig);
            } else {
                we.error(`GameConfig updateBundleInfo, bundleConfig err, bundleName: ${bundleName}, data: ${JSON.stringify(data)}`);
            }
        }
    }

    /**
     * 获取分包配置
     * @param bundleName
     * @returns
     */
    public static getBundleConfig(bundleName: string): IBundleConfig {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`GameConfig getBundleConfig, params err`);
            return null;
        }

        let url = bundleName;
        let version = '';

        // 原生 / h5(非开发版) 使用远端 bundle
        if (cc.sys.isNative || (cc.sys.isBrowser && !CC_DEV)) {
            if (!MainBundles.includes(bundleName)) {
                let gameId = this.toGameId(bundleName);
                if (GameConfig.isSDSubGame(gameId)) {
                    let versionInfo = GameConfig.getVersionInfo(gameId);
                    if (!versionInfo) {
                        we.error(`GameConfig getBundleConfig, versionInfo err, bundleName: ${bundleName}`);
                        return null;
                    }

                    url = cc.sys.isNative ? versionInfo.packageUrl : versionInfo.packageUrlH5;
                    version = versionInfo.version;
                } else {
                    let bundleConfig = this.bundleRemoteInfo.get(bundleName);
                    if (!bundleConfig) {
                        we.error(`GameConfig getBundleConfig, bundleConfig err, bundleName: ${bundleName}, bundleRemoteInfo: ${JSON.stringify(this.bundleRemoteInfo)}`);
                        return null;
                    }

                    url = cc.sys.isNative ? bundleConfig.urlNative : bundleConfig.urlH5;
                    version = bundleConfig.version;
                }

                if (cc.sys.isBrowser) {
                    // h5 灰度测试分包, 通过参数修改版本号
                    const bv = Utils.getLocationUrlParam(BrowserParamKey.bv);
                    const bvObj = Utils.convertToKeyValue(bv);
                    if (bvObj[bundleName]) {
                        version = bvObj[bundleName];
                    }
                }

                if (url.endsWith('/')) {
                    url = url.slice(0, -1);
                }

                if (cc.sys.isNative && GameConfig.nativeLpt) {
                    // native 测试,替换资源下载地址到测试地址
                    url = url.replace(/(^https?:\/\/[^\/]+)/, GameConfig.nativeLptUrl);
                    version = GameConfig.nativeLptVer;
                }
            }
        }

        if (cc.sys.isBrowser && !CC_DEV) {
            const lpt = Utils.getLocationUrlParam(BrowserParamKey.lpt);
            let reg = /(^https?:\/\/[^\/]+)/;
            if (!we.core.StringHelper.isNullOrEmpty(lpt) && reg.test(url)) {
                const lptObj = Utils.convertToKeyValue(lpt);
                if (bundleName == lptObj.hot) {
                    // 优先读取控制台全局版本号，若没有则使用后天配置的版本号
                    let ver = we['__hotver__'];
                    if (ver) {
                        version = ver;
                    }
                } else {
                    // 使用默认版本
                    version = lptObj.ver;
                }

                url = url.replace(/(^https?:\/\/[^\/]+)/, lptObj.url);
            }
        }

        this.checkSkinMatch(bundleName, url);

        return {
            url: url,
            version: version,
        };
    }

    /**
     * 检查 other 资源配置是否与 main 皮肤一致
     * 1.不符合当前皮肤配置，给出提示弹窗
     * 2.不影响实际加载流程
     * @param bundleName
     * @param url 资源地址
     */
    private static checkSkinMatch(bundleName: string, url: string): void {
        let isLobbyBundles = LobbyBundles.includes(bundleName);
        if (!isLobbyBundles) {
            return;
        }

        // 存在 url = 'launcher' 情况
        if (url?.indexOf('http') == -1) {
            return;
        }

        let remoteSkin = '';
        let strArr = url.split('/');
        if (strArr.length > 1) {
            strArr = strArr[strArr.length - 1].split('_');
            remoteSkin = strArr[strArr.length - 1].replace('/', '');
        }

        // 检查远端皮肤与本地皮肤是否一致，不一致则提示
        if (remoteSkin && remoteSkin != Flavor.getSkinCode()) {
            we.commonUI.showConfirm({
                priority: we.ui.type.PopupPriority.Asset,
                content: we.core.langMgr.getLangText(we.launcher.lang.LOAD_SKINS_INCORRECT),
                isHideCloseBtn: false,
                yesButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CONFIRM),
            });
        }
    }

    /**
     * 追加本地自研游戏列表
     * @param gameConfigs 游戏列表配置
     */
    public static appendGameList(gameConfigs: IGameConfig[]) {
        const list: IGameConfig[] = [];

        for (let item of gameConfigs) {
            item.vendorId = BasicType.SDGameVendorId;
            item.screenOrientation = item.screenOrientation ?? ScreenOrientation.LANDSCAPE_RIGHT;

            const gameLocalCfg = this.queryGameConfig(item.gameId);
            if (gameLocalCfg) {
                // 同步自研游戏本地配置
                this.updateGameConfig(item.gameId, {
                    dependBundles: item.dependBundles,
                    bundleName: item.bundleName,
                    gameType: item.gameType,
                    screenOrientation: item.screenOrientation,
                });
                continue;
            }
            // 新增游戏配置
            list.push(item);
        }

        this.GameList = ArrayHelper.deduplicateByProperty(this.GameList.concat(list), 'gameId');
    }

    /**
     * 追加服务器游戏列表
     * @param gameConfigs 游戏列表配置
     */
    public static appendServerGameList(gameConfigs: { [k: string]: api.GameDetail }) {
        const list: IGameConfig[] = [];
        for (let [gameId, item] of Object.entries(gameConfigs)) {
            let orientation = ScreenOrientation.LANDSCAPE_RIGHT;
            // 协议屏幕方向转化到客户端
            switch (item.orientation) {
                case 1: // 横屏
                    orientation = ScreenOrientation.LANDSCAPE_RIGHT;
                    break;
                case 2: // 竖屏
                    orientation = ScreenOrientation.PORTRAIT;
                    break;
                default:
                    break;
            }
            // 自研游戏
            const gameLocalCfg = this.queryGameConfig(item.gameId);
            if (gameLocalCfg) {
                // 同步服务器配置到存在的配置上
                this.updateGameConfig(item.gameId, {
                    icon: item.icon ?? gameLocalCfg.icon,
                    nameText: item.nameText ?? gameLocalCfg.nameText,
                    screenOrientation: orientation ?? gameLocalCfg.screenOrientation,
                });
                continue;
            }

            // 新增游戏配置
            list.push({
                gameId: item.gameId,
                bundleName: '',
                dependBundles: [],
                gameType: GameType.NULL,
                screenOrientation: orientation,
                vendorId: Math.floor(+gameId / 10000),
            });
        }

        this.GameList = ArrayHelper.deduplicateByProperty(this.GameList.concat(list), 'gameId');
    }

    /**
     * 获取分包名称
     * @param gameId
     */
    public static getBundleName(gameId: we.GameId): string {
        for (let i = 0; i < this.GameList.length; i++) {
            if (this.GameList[i].gameId === gameId) {
                if (this.isApiSubGame(gameId)) {
                    return we.bundles.comwbg;
                }
                return this.toBundleName(gameId);
            }
        }

        we.warn(`GameConfig getBundleName, params err, gameId: ${gameId}`);
        return '';
    }

    /**
     * 获取依赖 bundle 列表
     * @param gameId 游戏Id, 加载api游戏时，传入的是comwbg的id,自研游戏则是自研游戏的id
     * @returns
     */
    public static getDependBundles(gameId: we.GameId): string[] {
        let bundles = [];
        for (let i = 0; i < this.GameList.length; i++) {
            const e = this.GameList[i];
            if (e.gameId === gameId) {
                bundles = e.dependBundles;
                break;
            }
        }

        if (this.isSubGame(gameId)) {
            bundles = [BundleNames.main, BundleNames.common].concat(bundles);
        }

        return bundles;
    }

    /**
     * 根据分包名称获取游戏id
     * @param bundleName
     */
    public static getGameIdByBundleName(bundleName: string): we.GameId {
        for (let i = 0; i < this.GameList.length; i++) {
            if (this.GameList[i].bundleName === bundleName) {
                return this.GameList[i].gameId;
            }
        }

        return GameId.UNDEFINED;
    }

    /**
     * 根据游戏Id获取游戏group
     * @param gameId
     */
    public static getGameTypeByGameId(gameId: we.GameId): GameType {
        for (let i = 0; i < this.GameList.length; i++) {
            if (this.GameList[i].gameId === gameId) {
                return this.GameList[i].gameType;
            }
        }

        we.warn(`GameConfig getGameTypeByGameId, params err, gameId: ${gameId}`);
        return -1;
    }

    /**
     * 是否是子游戏
     * # ⚠️ 包含自研游戏、api 游戏
     * @param gameId
     */
    public static isSubGame(gameId: we.GameId): boolean {
        return this.isSDSubGame(gameId) || this.isApiSubGame(gameId);
    }

    /**
     * 是否自研游戏
     * @param gameId
     * @returns
     */
    public static isSDSubGame(gameId: we.GameId) {
        if (!gameId) {
            return false;
        }

        return gameId <= BasicType.SDGameMaxGameId && this.gameId[gameId] && gameId > GameId.TAG_SUB_GAME;
    }

    /**
     * 是否 api 游戏
     * @param gameId
     * @returns
     */
    public static isApiSubGame(gameId: we.GameId) {
        if (!gameId) {
            return false;
        }

        return gameId > BasicType.SDGameMaxGameId;
    }

    /**
     * 获取游戏配置
     * @param gameId
     * @returns
     */
    public static getGameConfig(gameId: we.GameId): IGameConfig {
        let conf: IGameConfig = null;
        for (let i = 0; i < this.GameList.length; i++) {
            if (this.GameList[i].gameId === gameId) {
                conf = this.GameList[i];
                return conf;
            }
        }

        we.warn(`GameConfig getGameConfig, params err, gameId: ${gameId}`);
        return null;
    }

    /**
     * 查询游戏配置
     * @param gameId
     * @returns
     */
    public static queryGameConfig(gameId: we.GameId): IGameConfig {
        return this.GameList.find((v) => {
            return v.gameId === gameId;
        });
    }

    /**
     * 更新游戏配置
     * @param gameId
     * @param conf
     * @returns
     */
    public static updateGameConfig(gameId: we.GameId, conf: Partial<IGameConfig>) {
        let cfgIndex = this.GameList.findIndex((v) => {
            return v.gameId === gameId;
        });

        if (!this.GameList[cfgIndex]) {
            return false;
        }

        this.GameList[cfgIndex] = {
            ...this.GameList[cfgIndex],
            ...conf,
        };
    }

    /**
     * 获取游戏版本号
     * @param gameId 默认当前游戏id
     * @returns
     */
    public static getGameVersion(gameId: we.GameId = GameConfig.curGameId): string {
        let env = Flavor.getEnvName();
        env = env ? `${env} ` : '';
        let cvn = NativeUtil.getVersionName();
        cvn = cc.sys.isNative ? `${cvn}-` : '';
        let crv = this.getModuleVersion(GameConfig.getBundleName(gameId));
        let ver = env + 'v' + cvn + crv;
        return ver;
    }

    public static get curGameId() {
        return this._curGameId;
    }

    public static set curGameId(gameId: we.GameId) {
        this._curGameId = gameId;
    }

    public static get preGameId() {
        return this._preGameId;
    }

    public static set preGameId(v) {
        this._preGameId = v;
    }

    public static getSceneFrom(): SceneFrom {
        if (this.isSubGame(this._preGameId)) {
            return SceneFrom.Game;
        } else if (this._preGameId === we.GameId.LAUNCHER) {
            return SceneFrom.Launcher;
        } else if (this._preGameId === this._curGameId) {
            return SceneFrom.Self;
        } else {
            return SceneFrom.Other;
        }
    }

    public static get roomInfoMap() {
        return this._roomInfoMap;
    }

    public static set roomInfoMap(map: Map<we.GameId, IRoomInfo>) {
        this._roomInfoMap = null;
    }

    public static getVersionInfo(gameId: we.GameId): api.SubGameVersion {
        const roomInfo = this.roomInfoMap.get(gameId) ?? this.roomInfoMap.get(gameId);
        return roomInfo ? roomInfo.versionInfo : null;
    }

    /**
     * 生成场景跳转 inoketype
     * @param gameId 游戏 Id
     * @param vendorId  厂商 Id
     * @param customized 是否定制厂商
     * @returns
     */
    public static genSceneInvokeType(gameId: we.GameId, vendorId: we.GameVendor, customized: boolean) {
        const vendorEventKey = `${BasicType.GameVendorEventPrefix}-${vendorId}`;
        // 是否自研场景
        const isSDScene = gameId <= BasicType.SDGameMaxGameId;
        return isSDScene ? gameId : customized ? vendorEventKey : null;
    }
}

we.core.gameConfig = GameConfig;
