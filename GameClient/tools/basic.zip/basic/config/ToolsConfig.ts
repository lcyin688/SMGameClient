declare global {
    interface ICore {
        BrowserParamKey: typeof BrowserParamKey;
        HideBrowserParamKey: typeof HideBrowserParamKey;
    }
}

/** 浏览器地址参数 */
export const BrowserParamKey = {
    // ////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////// project ////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////

    /** ProductFlavor 简写 value: {SkinCode}_{CountryCode}_{EnvType} */
    pf: 'pf',
    /** 皮肤 */
    skin: 'skin',
    /** 国家 */
    ctry: 'ctry',
    /** 环境 */
    env: 'env',
    /** 语言 */
    lang: 'lang',
    /** CountryRegionClient 简写，客户端国家 code，用于前端显示控制 */
    crc: 'crc',
    /** 游戏id */
    gameid: 'gameid',
    /** 游戏房间等级 */
    roomkind: 'roomkind',
    /** 控制台打印日志开关 value: op */
    log: 'log',
    /** 开发控制日志打印等级 */
    logger: 'logger',
    /** bundle version, 用于灰度测试指定分包版本, 用法 bv=hall{1.2.3},common{1.2.4} */
    bv: 'bv',
    /** 屏蔽大厅强弹, 用于开发测试 */
    nopop: 'nopop',
    /** 屏蔽手机浏览器全屏, 用于开发测试 */
    nofull: 'nofull',
    /** 点击，大厅隐藏功能区域，用于测试开发,1==开启 */
    hallHideArea: 'hallHideArea',

    /** 本地发布测试，用法 lpt=ver{5.5.5},url{http://h5game.wec.com} */
    lpt: 'lpt',

    // ////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////// 平台相关 ////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////

    /** 运行平台, 用在 h5 马甲包 */
    runplt: 'runplt',
    /** 平台版本, 用在 h5 马甲包版本兼容 */
    pltvc: 'pltvc',
    /** 设备平台, platform, 该值为动态生成, 生产环境不能用参数方式, 参数方式仅用于调试  */
    plt: 'plt',
    /** 渠道, 不加密, 用于调试 */
    rchn: 'rchn',
    /** 渠道, 加密, 用于生产 */
    chn: 'chn',
    /** 设备 id */
    aid: 'aid',
    /** adjust 广告 id */
    adid: 'adid',
    /** 谷歌广告 id */
    gaid: 'gaid',
    /** 苹果广告 id */
    idfa: 'idfa',
    /** 设备号, device model  */
    dmo: 'dmo',
    /** 设备品牌, device brand */
    dbr: 'dbr',
    /** 传感器类型, device sensor type */
    dst: 'dst',
    /** 设备内存 */
    ram: 'ram',
    /** 负载信息, 用于推广引荐相关 */
    payload: 'payload',
    /** 安装引荐 */
    referrer: 'referrer',
    /** 引荐 id */
    referid: 'referid',
    /** 可进行 pwa 安装标识 */
    pwa: 'pwa',

    // ////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////// 版本相关 ////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////

    /** 版本名称, client version name */
    cvn: 'cvn',
    /** 版本代码, client version code */
    cvc: 'cvc',
    /** 资源版本, client res version */
    crv: 'crv',

    // ////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////// 用户相关 ////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////

    /** userid: base64 处理后值 */
    id: 'id',
    /** 登陆账号 token */
    token: 'token',
    /** 用于免密登录信息，包含 user_id token device_id，该数据通过 base64 */
    auth: 'auth',

    // ////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////// server 参数 /////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////

    /** maintain server，具体使用查看 ServerManager.ts */
    svum: 'svum',
    /** track server，具体使用查看 ServerManager.ts */
    svut: 'svut',
    /** hall server，具体使用查看 ServerManager.ts */
    svuh: 'svuh',
    /** naming server，具体使用查看 ServerManager.ts */
    svun: 'svun',
    /** subgame server，具体使用查看 ServerManager.ts */
    svug: 'svug',

    // ////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////// sdk 参数 ////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////

    /** adjust web id */
    adjid: 'adjid',
    adjdt: 'adjdt',
    /** adjust web referrer 传递使用，只能是 adjust_referrer 不可修改 */
    adjust_referrer: 'adjust_referrer',
    adjlog: 'adjlog',
    adjenv: 'adjenv',
    /** fb 账号, 用于测试 */
    fbaccount: 'fbaccount',
    /** fb 像素 id */
    fbpxid: 'fbpxid',
    /** tt 像素 id */
    ttpxid: 'ttpxid',
    /** kw 像素 id */
    kwpxid: 'kwpxid',
} as const;

we.core.BrowserParamKey = BrowserParamKey;

/** 隐藏浏览器url参数列表 */
export const HideBrowserParamKey = [
    BrowserParamKey.runplt,
    BrowserParamKey.chn,
    BrowserParamKey.fbpxid,
    BrowserParamKey.kwpxid,
    BrowserParamKey.ttpxid,
    BrowserParamKey.adjid,
    BrowserParamKey.adjust_referrer,
    BrowserParamKey.referid,
    BrowserParamKey.auth,
    BrowserParamKey.pwa,
];

we.core.HideBrowserParamKey = HideBrowserParamKey;
