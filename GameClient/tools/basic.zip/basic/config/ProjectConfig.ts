import { StorageKey } from '../module/storage/StorageUtil';
import { StorageRW } from '../module/storage/StorageRW';
import BasicEventName from '../const/BasicEventName';
import { SceneHelper } from '../module/scene/SceneHelper';
import Utils from '../utils/Utils';
import Flavor from '../flavor/Flavor';

declare global {
    interface ICore {
        /** 项目配置 */
        projectConfig: typeof ProjectConfig;
        /** 屏幕方向 */
        ScreenOrientation: typeof ScreenOrientation;
        /** 加载类型 */
        LoadType: typeof LOAD_TYPE;
    }
    interface TCore {
        ScreenOrientation: ScreenOrientation;
    }
    namespace we {
        namespace core {
            /** 屏幕方向 */
            type ScreenOrientation = TCore['ScreenOrientation'];
        }
    }
}

/** 屏幕方向 */
export enum ScreenOrientation {
    /** 竖屏 home在下  */
    PORTRAIT = 0,
    /** 横屏 home在右  */
    LANDSCAPE_RIGHT = 1,
    /** 竖屏 home在上  */
    PORTRAIT_UPSIDE_DOWN = 2,
    /** 横屏 home在左  */
    LANDSCAPE_LEFT = 3,
}

we.core.ScreenOrientation = ScreenOrientation;

/** 加载类型 */
export enum LOAD_TYPE {
    /** 热更 */
    HOT_UPDATE = 0,
    /** 预加载 */
    PRELOAD = 1,
    /** 加载 */
    LOAD = 2,
    /** 连接服务器 */
    CONNECT = 3,
}

we.core.LoadType = LOAD_TYPE;

export interface AudioResConfig {
    /** 通用按钮点击音效 */
    click?: string;
    /** 背景音乐 */
    bgm?: string;
}

export default class ProjectConfig {
    /** 屏幕方向 */
    public static orientation: ScreenOrientation = cc.sys.isNative ? jsb.device.getDeviceRotation() : null;

    /** 客户端设计分辨率 */
    public static designResolution = cc.size(1280, 720);
    /** 是否刘海屏 */
    public static isNotch = false;
    /** app 启动携带跳转参数 */
    public static appLauncherJump: string = null;

    /**
     * 本地时间戳与服务器时间戳差值 单位:ms, TODO 4.2 版本后移除
     * @deprecated 请使用 TimeInfo.Inst.serverNow() 获取服务器时间戳
     */
    public static timeOffset = 0;

    /** 是否登录完成 */
    public static isLoginComplete = false;
    /** 是否自动登录 */
    public static autoLogin = true;
    /** 功能开关配置 */
    public static settingsConfig: api.SettingsResp = null;
    /** 设备账号状态 */
    public static deviceAccSt: api.DeviceAccountStatusResp = null;
    /** 音效配置 */
    public static audioCfg: AudioResConfig = {};

    /** 游戏列表 */
    public static gameListMap: Set<number> = new Set();

    /** 公共配置 */
    public static commonConfig = {
        /** whatsapp客服 */
        whatsappNumber: '',
        /** H5客服Url */
        customerUrl: '',
        /** 官网地址 */
        officialWebUrl: '',
        /** 官网下载地址 */
        officialWebsiteDownAddress: '',
        /** 分享fbUrl */
        shareFbUrl: '',
        /** instagram 粉丝页 */
        instagramFansUrl: '',
        /** twitter 粉丝页 */
        twitterFansUrl: '',
        /** facebook 粉丝页 */
        fbFansUrl: '',
        /** 日志上报开关, 0关 1开 */
        logReportSwitch: {
            /** 总开关 */
            all: 1,
            verbose: 0,
            debug: 0,
            info: 1,
            warn: 1,
            error: 1,
            fatal: 1,
        },
        /** 日志打印开关, 0关 1开 */
        logPrintSwitch: {
            /** 总开关 */
            all: 1,
            verbose: 1,
            debug: 0,
            info: 1,
            warn: 1,
            error: 1,
            fatal: 1,
        },
        /** 隐私政策 */
        privacyPolicyUrl: '',
        /** 用户协议 */
        userAgreementUrl: '',
        /** 注册/绑定需要验证开关 */
        needPhoneVerify: false,
        /** 是否需要邮箱验证 */
        needEmailVerify: false,
        /** 绑定手机支持方式 0 短信 1 语音 2 whatsapp 3 email */
        bindPhoneVerifyType: [] as number[],
        /** 绑定手机推荐方式 0 短信 1 语音 2 whatsapp 3 email */
        bindPhoneRecommendType: [] as number[],
        /** 重置密码支持验证方式 0 短信 1 语音 2 whatsapp 3 email */
        passwordRecoveryVerifyType: [] as number[],
        /** 重置密码推荐验证方式 0 短信 1 语音 2 whatsapp 3 email */
        passwordRecoveryRecommendType: [] as number[],
        /** 升级正式账号验证方式 */
        upNormalUserSwitch: [] as string[],
        /** 下载url */
        downloadUrl: '',
        /** 客服配置 */
        customerConfig: [
            {
                link: '',
                icon: {},
            },
        ],
        /** 品牌 logo url */
        brandLogoUrl: '',
        /** 品牌 bgm url */
        brandBgmUrl: '',
        /** 客服类型 platform：平台，third-party：第三方 */
        customerType: 'platform',
    };

    public static init(): void {
        this.initNotchPhone();
    }

    /**
     * 刘海屏手机
     */
    private static initNotchPhone() {
        let setNotch = () => {
            let frameSize = cc.view.getFrameSize();
            let width = frameSize.width > frameSize.height ? frameSize.width : frameSize.height;
            let height = frameSize.width > frameSize.height ? frameSize.height : frameSize.width;
            this.isNotch = width / height > (1280 + 60 * 2) / 720;

            we.log(`ProjectConfig initNotchPhone, setNotch, isNotch: ${this.isNotch}, frameSize.width: ${frameSize.width}, frameSize.height: ${frameSize.height}`);
        };

        setNotch();
        cc.view.on('canvas-resize', setNotch, this);
    }

    /**
     * 生成设备id
     * @returns
     */
    public static generateDeviceId(): string {
        let deviceId = we.kit.storage.get('sys', 'app_device_id') || StorageRW.get(StorageKey.DEVICE_ID);
        if (!deviceId) {
            let ms = new Date().getTime().toString();
            deviceId = 'w-' + ms.substring(ms.length - 6, ms.length);
            while (deviceId.length < 32) {
                let field = Math.random().toString();
                field = field.substring(2, 7);
                deviceId += '-' + field;
            }
        }
        we.kit.storage.setById('sys', 'app_device_id', deviceId);

        return deviceId;
    }

    /**
     * 初始化公共配置
     * @param data
     */
    public static initCommonConfig(data: object): void {
        if (typeof data != 'object') {
            we.error(`ProjectConfig initCommonConfig, data err: ${data}`);
            return;
        }

        let parseStringArray = (key: string) => {
            let value = data[key];
            if (typeof value == 'string') {
                if (value.length > 0) {
                    return value;
                }
            } else {
                if (value instanceof Array) {
                    if (value.length == 2) {
                        return value[1];
                    }
                }
            }

            return '';
        };

        this.commonConfig.officialWebUrl = parseStringArray('official_website_address');
        this.commonConfig.officialWebsiteDownAddress = parseStringArray('official_website_down_address');
        this.commonConfig.shareFbUrl = parseStringArray('share_fb_url');
        this.commonConfig.instagramFansUrl = parseStringArray('instagram_fans_url');
        this.commonConfig.twitterFansUrl = parseStringArray('twitter_fans_url');
        this.commonConfig.fbFansUrl = parseStringArray('fb_fans_url');

        this.commonConfig.whatsappNumber = data['whatsapp_number'];
        this.commonConfig.customerUrl = data['customer_url'];
        this.commonConfig.privacyPolicyUrl = data['privacy_policy_url'];
        this.commonConfig.userAgreementUrl = data['user_agreement_url'];
        this.commonConfig.downloadUrl = data['download_url'];
        this.commonConfig.needPhoneVerify = !!data['need_phone_verify'];
        this.commonConfig.needEmailVerify = !!data['need_email_verify'];
        this.commonConfig.bindPhoneVerifyType = data['bind_phone_verify_type'] || [];
        this.commonConfig.bindPhoneRecommendType = data['bind_phone_recommend_type'] ?? [];
        this.commonConfig.passwordRecoveryVerifyType = data['password_recovery_verify_type'] ?? [];
        this.commonConfig.passwordRecoveryRecommendType = data['password_recovery_recommend_type'] ?? [];
        this.commonConfig.upNormalUserSwitch = data['up_normal_user_switch'] ?? [];
        this.commonConfig.customerConfig = data['customer_left_logo'] || [];

        this.commonConfig.brandLogoUrl = data['brand_logo_url'] || '';
        this.commonConfig.brandBgmUrl = data['brand_bgm_url'] || '';

        // 品牌自定义启动背景图片
        const brandLoadingBgUrl = data['brand_loading_bg_url'] || '';
        if (Utils.isValidUrl(brandLoadingBgUrl)) {
            if (Flavor.getSkinOrientation() === ScreenOrientation.PORTRAIT) {
                we.kit.storage.setById('sys', 'brand_loading_bg_url_v', brandLoadingBgUrl);
                we.kit.storage.setById('sys', 'brand_loading_bg_url', '');
            } else {
                we.kit.storage.setById('sys', 'brand_loading_bg_url', brandLoadingBgUrl);
                we.kit.storage.setById('sys', 'brand_loading_bg_url_v', '');
            }
        }

        cc.director.emit(BasicEventName.BRAND_LOGO_LOAD);

        let logReportSwitch = data['log_report_switch'];
        if (logReportSwitch && typeof logReportSwitch == 'object') {
            this.commonConfig.logReportSwitch = logReportSwitch;
        }

        let logPrintSwitch = data['log_print_switch'];
        if (logPrintSwitch && typeof logPrintSwitch == 'object') {
            this.commonConfig.logPrintSwitch = logPrintSwitch;
        }

        // 无配置时，默认是平台非第三方
        this.commonConfig.customerType = data['customer_type'] || 'platform';
    }

    /**
     * 设置 可见游戏入口id配置
     * @returns
     */
    public static setVisibleGame(): void {
        try {
            if (!this.settingsConfig?.funcSwitch?.layout) {
                return;
            }

            const config = JSON.parse(this.settingsConfig.funcSwitch.layout);
            Object.values(config)
                .filter(Array.isArray)
                .flatMap((data) => {
                    return data.flat();
                })
                .forEach((gameId) => {
                    gameId = +gameId;
                    if (gameId > 0) {
                        return this.gameListMap.add(gameId);
                    }
                });
        } catch (error) {
            we.error(`ProjectConfig setVisibleGame error: ${error}`);
        }
    }

    /**
     * 获取 可见游戏入口id配置
     * @returns
     */
    public static getVisibleGame(): number[] {
        return [...this.gameListMap];
    }

    /**
     * 设置全局音效配置
     * @param options
     */
    public static setAudios(options: AudioResConfig) {
        this.audioCfg = {
            ...this.audioCfg,
            ...options,
        };

        SceneHelper.setSceneInfo({ clickUrl: this.audioCfg.click, clickSleepTime: 1 }, we.clientScene);
    }

    /**
     * 是平台客服
     * @returns
     */
    public static isPlatformCustomer(): boolean {
        if (this.commonConfig.customerType == 'platform') {
            return true;
        }

        return false;
    }
}

we.core.projectConfig = ProjectConfig;
