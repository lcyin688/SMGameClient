import StorageUtil from '../module/storage/StorageUtil';

declare global {
    interface ICore {
        trackConfig: typeof TrackConfig;
    }
}

interface ITrackEvent {
    /** 游戏 */
    game?: IGame;
    /** 账号 */
    account?: IAccount;
    /** 充值 */
    purchase?: IPurchase;
}

interface IGame {
    /** 自定义数据 */
    customdata?: string;
    /** 热更：vest首次启动 */
    updated?: string;
    updatedEx?: object;
}

interface IAccount {
    /** 新增：游客首次登录成功 */
    activate?: string;
    activateEx?: object;
    /** 注册：账号升级成功 */
    register?: string;
    registerEx?: object;
}

interface IPurchase {
    /** 总充值 */
    total?: string;
    totalEx?: object;
    /** 新增充值 */
    new?: string;
    newEx?: object;
    /** 首充充值 */
    first?: string;
    firstEx?: object;
    /** 重复充值 */
    repeat?: string;
    repeatEX?: object;
    /** 连续充值2次 */
    second?: string;
    secondEx?: object;
    /** 连续充值5次 */
    fifth?: string;
    fifthEx?: object;
}

/**
 * 跟踪事件
 */
export default class TrackConfig {
    /** 当前埋点数据 */
    private static eventConfig: ITrackEvent = null;

    /** 游戏 */
    public static game: IGame = null;
    /** 账号 */
    public static account: IAccount = null;
    /** 充值 */
    public static purchase: IPurchase = null;

    /**
     * 初始化
     */
    public static init(): void {
        this.eventConfig = {} as ITrackEvent;
        this.game = {} as IGame;
        this.account = {} as IAccount;
        this.purchase = {} as IPurchase;

        let localAdjCfg = StorageUtil.readAdjustConfig();
        if (localAdjCfg?.eventList?.length > 0) {
            this.updateAdjCfg(localAdjCfg);
        }

        this.setExValue(this.game, this.nameEventConf.game);
        this.setExValue(this.account, this.nameEventConf.account);
        this.setExValue(this.purchase, this.nameEventConf.purchase);

        this.syncConf();
    }

    /**
     * 更新Adjust配置
     * @param data
     * @returns
     */
    public static updateAdjCfg(data: we.IAdjustConf): void {
        if (!data) {
            return;
        }

        let eventList = data.eventList || [];
        eventList.forEach((v) => {
            let eventName = v.eventName;
            if (['start', 'updated'].includes(eventName)) {
                this.game[eventName] = v.eventToken;
            } else if (['activate', 'register'].includes(eventName)) {
                this.account[eventName] = v.eventToken;
            } else if (['total', 'new', 'first', 'repeat', 'second', 'fifth'].includes(eventName)) {
                this.purchase[eventName] = v.eventToken;
            }
        });

        this.syncConf();
    }

    /**
     * 获取 name
     * @param event 事件
     */
    public static getName(event: string): string {
        if (!(typeof event == 'string' && event.length > 0)) {
            return '';
        }

        let name = '';
        let conf = this.eventConfig;
        let isExist = false;

        let getKeyPathByValue = (obj: Object, str: string) => {
            let keys = Object.keys(obj);
            let strTemp = str;
            for (let i = 0; i < keys.length; i++) {
                strTemp = str;
                strTemp = strTemp == '' ? keys[i] : (strTemp = strTemp + '_' + keys[i]);

                let dataTemp = obj[keys[i]];
                if (dataTemp instanceof Object) {
                    getKeyPathByValue(dataTemp, strTemp);
                } else {
                    if (event === dataTemp) {
                        !isExist && (name = strTemp);
                        isExist = true;
                    }
                }
            }
        };
        getKeyPathByValue(conf, name);

        return name;
    }

    /**
     * 设置扩展数据
     * @param raw
     * @param ex
     */
    private static setExValue(raw: Object, ex: Object): void {
        if (!(typeof raw == 'object' && typeof ex == 'object')) {
            return;
        }

        let keys = Object.keys(ex);
        for (let i = 0; i < keys.length; i++) {
            raw[keys[i]] = ex[keys[i]];
        }
    }

    /**
     * 同步配置至 adjustEventToken
     */
    private static syncConf(): void {
        this.eventConfig.game = this.game;
        this.eventConfig.account = this.account;
        this.eventConfig.purchase = this.purchase;
    }

    /**
     * 名称型事件配置
     */
    private static nameEventConf = {
        game: {
            updatedEx: {
                firebase: 'updated',
                appsflyer: 'af_update',
            },
        },
        account: {
            activateEx: {
                firebase: 'activate',
                appsflyer: 'af_content_view',
                fbq: 'ViewContent',
                ttq: 'ViewContent',
                kwaiq: 'contentView',
            },
            registerEx: {
                firebase: 'register',
                appsflyer: 'af_complete_registration',
                fbq: 'CompleteRegistration',
                ttq: 'CompleteRegistration',
                kwaiq: 'completeRegistration',
            },
        },
        purchase: {
            firstEx: {
                firebase: 'first_purchase',
                appsflyer: 'af_purchase',
                fbq: 'Purchase',
                ttq: 'CompletePayment',
                kwaiq: 'purchase',
            },
            newEx: {
                firebase: 'new_purchase',
                appsflyer: 'af_new_purchase',
                fbq: 'custom.New_Purchase',
                ttq: 'custom.New_Purchase',
                kwaiq: 'custom.New_Purchase',
            },
            totalEx: {
                fbq: 'custom.Total_Purchase',
                ttq: 'custom.Total_Purchase',
                kwaiq: 'custom.Total_Purchase',
            },
            repeatEX: {
                fbq: 'custom.Repeat_Purchase',
                ttq: 'custom.Repeat_Purchase',
                kwaiq: 'custom.Repeat_Purchase',
            },
            secondEx: {
                fbq: 'custom.2th_Purchase',
                ttq: 'custom.2th_Purchase',
                kwaiq: 'custom.2th_Purchase',
            },
            fifthEx: {
                fbq: 'custom.5th_Purchase',
                ttq: 'custom.5th_Purchase',
                kwaiq: 'custom.5th_Purchase',
            },
        },
    };
}

we.core.trackConfig = TrackConfig;
