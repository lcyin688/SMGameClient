declare global {
    interface ICore {
        userStatusInfo: typeof UserStatusInfo;
    }
}

interface UserStatusProvider {
    tokenV2: string;
    userInfo: {
        userId: number;
    };
    isLogin(): boolean;
}

export class UserStatusInfo {
    private static _provider: UserStatusProvider;

    static setProvider(provider: UserStatusProvider) {
        this._provider = provider;
    }

    static get tokenV2() {
        return this._provider?.tokenV2;
    }

    static get userId() {
        return this._provider?.userInfo?.userId;
    }

    static isLogin() {
        return this._provider.isLogin();
    }
}

we.core.userStatusInfo = UserStatusInfo;
