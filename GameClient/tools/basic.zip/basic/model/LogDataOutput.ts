import { GameConfig } from '../config/GameConfig';
import ProjectConfig from '../config/ProjectConfig';
import { BrowserParamKey } from '../config/ToolsConfig';
import Flavor from '../flavor/Flavor';
import { ILogDataOutput, LogFormatType, LogLevel } from '../module/logger/ILogger';
import StorageUtil from '../module/storage/StorageUtil';
import NativeUtil from '../platform/NativeUtil';
import Utils from '../utils/Utils';
import ServerManager from '../manager/ServerManager';
import { TrackApi } from '../manager/TrackManager';

export class LogDataOutput extends ILogDataOutput {
    /** 日志 id 列表, 用于上报去重 */
    private logIds = new Set<string>();

    /**
     * 数据格式化接口
     * @param type
     * @param level
     * @param data
     * @returns
     */
    public format(type: LogFormatType, level: LogLevel, data: any[]): string {
        let result = null;
        switch (type) {
            case LogFormatType.print:
                result = this.formatPrint(level, data);
                break;
            case LogFormatType.report:
                result = this.formatReport(level, data);
                break;
            default:
                break;
        }

        return result;
    }

    /**
     * 数据上报接口
     * @param data
     * @returns
     */
    public report(data: string): void {
        if (!data) {
            return;
        }

        let url = this.joinUrl(ServerManager.getTrackHost(), TrackApi.upData.logUp);
        if (!url) {
            return;
        }

        let xhr = new XMLHttpRequest();
        xhr.responseType = 'text';
        xhr.timeout = 10000;
        xhr.onload = () => {
            let msg = `LogDataOutput report, onload, status: ${xhr.status}`;
            if (xhr.status == 200) {
                we.log(msg, we.noup);
            } else {
                we.error(msg, we.noup);
            }
        };
        xhr.ontimeout = () => {
            we.error(`LogDataOutput report, ontimeout`, we.noup);
        };
        xhr.onerror = () => {
            we.error(`LogDataOutput report, onerror`, we.noup);
        };
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(data);
    }

    /**
     * 格式化打印
     * @param level
     * @param data
     * @returns
     */
    private formatPrint(level: LogLevel, data: any[]): string {
        let logPrintSwitch = ProjectConfig.commonConfig.logPrintSwitch;
        if (cc.sys.isBrowser) {
            if (!(Utils.getLocationUrlParam(BrowserParamKey.log) == 'op' || window.location.hostname == 'localhost')) {
                if (cc.sys.isMobile) {
                    if (logPrintSwitch.all == 0 || logPrintSwitch[LogLevel[level]] == 0) {
                        return null;
                    }
                } else {
                    return null;
                }
            }
        } else {
            if (logPrintSwitch.all == 0 || logPrintSwitch[LogLevel[level]] == 0) {
                return null;
            }
        }

        if (data.length == 0) {
            return null;
        }

        let dataObj = this.formatData(data);
        let message = dataObj.message;
        let custom = dataObj.custom;
        if (custom) {
            // 自定义字段放到外层
            let temp = Object.assign({}, custom);
            // 删除自定义字段标识
            delete temp['custom'];

            let msg = '';
            try {
                msg = JSON.stringify(temp);
            } catch (err) {
                msg = `custom stringify err: ${JSON.stringify(err?.message || err)}`;
            }
            message += '\n' + msg;
        }

        return message;
    }

    /**
     * 格式化上报
     * @param level
     * @param data
     * @returns
     */
    private formatReport(level: LogLevel, data: any[]): string {
        let logReportSwitch = ProjectConfig.commonConfig.logReportSwitch;
        if (logReportSwitch.all == 0) {
            return null;
        }

        if (logReportSwitch[LogLevel[level]] == 0) {
            return null;
        }

        if (data.includes(we.noup)) {
            // 有 we.noup 不上报
            return null;
        }

        let dataObj = this.formatData(data);
        let message = dataObj.message;
        let custom = dataObj.custom;
        let logId = Utils.md5hex(message);
        if (this.logIds.has(logId)) {
            return null;
        }
        this.logIds.add(logId);

        let platform = NativeUtil.getPlatform();
        let device = NativeUtil.getDeviceBrand() + '-' + NativeUtil.getDeviceModel();
        let memory = NativeUtil.getMemory();
        let appChannel = NativeUtil.getChannel();
        let appVer = NativeUtil.getVersionName();
        let mainVer = GameConfig.getLocalVersion(we.bundles.main);
        let commonVer = GameConfig.getLocalVersion(we.bundles.common);
        let hallVer = GameConfig.getLocalVersion(we.bundles.hall);
        let skin = Flavor.getSkinCode();
        let aid = NativeUtil.getDeviceId();
        let userId = StorageUtil.readUserId();
        let tsLocal = new Date().getTime();

        let params = {
            level: LogLevel[level],
            message: message,
            platform: platform,
            device: device,
            memory: memory,
            app_channel: appChannel,
            app_ver: appVer,
            main_ver: mainVer,
            common_ver: commonVer,
            hall_ver: hallVer,
            skin: skin,
            aid: aid,
            user_id: userId,
            ts_local: tsLocal,
        };

        if (cc.sys.isBrowser) {
            params['h5url'] = window.location.href;
            params['user_agent'] = window.navigator.userAgent;
        }

        let gameId = GameConfig.curGameId;
        if (GameConfig.isSubGame(gameId)) {
            let gameVer = GameConfig.getLocalVersion(GameConfig.getBundleName(gameId));
            params['game_id'] = gameId.toString();
            params['game_ver'] = gameVer;
        }

        if (custom) {
            // 自定义字段放到外层
            for (const key in custom) {
                if (key != 'custom' && ['string', 'number', 'boolean', 'undefined'].includes(typeof custom[key])) {
                    params[key] = custom[key];
                }
            }
        }

        try {
            return JSON.stringify(params);
        } catch (err) {
            we.error(`LogDataOutput formatReport, stringify err: ${JSON.stringify(err?.message || err)}`, we.noup);
        }

        return null;
    }

    /**
     * 格式化数据
     * @param data
     * @returns
     */
    private formatData(data: any[]): { message: string; custom: object } {
        let message = '';
        let custom = null;
        for (let i = 0; i < data.length; i++) {
            let msg = '';
            let value = data[i];
            let type = typeof value;
            if (['string', 'number', 'boolean', 'undefined'].includes(type)) {
                if (value !== we.noup) {
                    // 不打印 we.noup
                    msg = value + '';
                }
            } else if (type == 'object') {
                // null 也是 object
                if (value?.custom) {
                    custom = Object.assign(custom || {}, value);
                } else {
                    try {
                        msg = JSON.stringify(value);
                    } catch (err) {
                        // 防止循环引用
                        msg = `data stringify err: ${JSON.stringify(err?.message || err)}`;
                    }
                }
            } else {
                msg = `data type err: ${type}`;
            }

            if (msg) {
                message = message + (i == 0 ? '' : ', ') + msg;
            }
        }

        return {
            message: message,
            custom: custom,
        };
    }

    /**
     * 专用拼接 url, 相比 Utils.joinUrl 区别在不上传日志
     * @param host
     * @param path
     * @returns
     */
    private joinUrl(host: string, path: string): string {
        if (!(typeof host == 'string' && host.length > 0 && typeof path == 'string' && path.length > 0)) {
            we.error(`LogDataOutput joinUrl, params is err`, we.noup);
            return '';
        }

        if (!host.startsWith('http')) {
            host = 'http://' + host;
        }

        if (!host.endsWith('/')) {
            host = host + '/';
        }

        if (path.startsWith('/')) {
            path = path.substring(1, path.length);
        }

        if (path.endsWith('/')) {
            path = path.substring(0, path.length - 1);
        }

        return host + path;
    }
}
