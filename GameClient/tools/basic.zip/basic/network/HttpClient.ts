import { BaseHttpClient, BaseHttpClientOptions, defaultBaseHttpClientOptions } from './base/BaseHttpClient';
import { NetType } from './base/type/NetType';
import { RpcError } from './base/type/RpcError';
import { HttpProxy } from './HttpProxy';

/**
 * Http请求客户端
 * 使用XMLHttpRequest发起请求
 */
export class HttpClient<ServiceType extends NetType.BaseServiceType> extends BaseHttpClient<ServiceType> {
    readonly options!: Readonly<HttpClientOptions>;

    constructor(options?: Partial<HttpClientOptions>) {
        let httpProxy = new HttpProxy();
        super(httpProxy, {
            ...defaultHttpClientOptions,
            ...options,
        });
    }

    callApi<T extends string & keyof ServiceType['api']>(apiName: T, req: ServiceType['api'][T]['req'], options: HttpClientTransportOptions = {}): Promise<NetType.ApiReturn<ServiceType['api'][T]['res']>> {
        return super.callApi(apiName, req, options);
    }

    sendMsg<T extends string & keyof ServiceType['msg']>(msgName: T, msg: ServiceType['msg'][T], options: HttpClientTransportOptions = {}): Promise<{ isSucc: true } | { isSucc: false; err: RpcError }> {
        return super.sendMsg(msgName, msg, options);
    }
}

export interface HttpClientTransportOptions extends NetType.TransportOptions {
    /**
     * Event when progress of data sent is changed
     * @param ratio - 0~1
     */
    onProgress?: (ratio: number) => void;
}

const defaultHttpClientOptions: HttpClientOptions = {
    ...defaultBaseHttpClientOptions,
};

export interface HttpClientOptions extends BaseHttpClientOptions {}
