import { NetType } from './base/type/NetType';
import { WebSocketProxy } from './WebsocketProxy';
import { BaseWsClient, BaseWsClientOptions, defaultBaseWsClientOptions } from './base/BaseWsClient';

/**
 * WS客户端.
 */
export class WsClient<ServiceType extends NetType.BaseServiceType> extends BaseWsClient<ServiceType> {
    readonly options!: Readonly<WsClientOptions>;

    constructor(options?: Partial<WsClientOptions>) {
        let wsp = new WebSocketProxy(options?.caUrl);
        super(wsp, {
            ...defaultWsClientOptions,
            ...options,
        });
    }
}

const defaultWsClientOptions: WsClientOptions = {
    ...defaultBaseWsClientOptions,
};

export interface WsClientOptions extends BaseWsClientOptions {
    /** As the 3rd parameter for `new WebSocket()` */
    caUrl?: string;
}
