import { ILogger } from '../../module/logger/ILogger';
import { DecodeOutput, IProtoDataParser } from '../IProtoDataParser';
import { ApiReturnFlowData, CallApiFlowData, RecvMsgFlowData, SendMsgFlowData } from './type/ClientFlowData';
import { Counter } from './model/Counter';
import { Flow } from './model/Flow';
import { MsgHandler } from './model/MsgHandler';
import { RcpErrorType, RpcError } from './type/RpcError';
import { EnumHelper } from '../../helper/EnumHelper';
import { NetType } from './type/NetType';

export const defaultBaseClientOptions: BaseClientOptions = {
    logApi: true,
    logMsg: true,
    timeout: 15000,
    debugBuf: false,
    protoMsgId: {},
    req2Res: {},
    parser: null,
};

export interface BaseClientOptions {
    /**
     * 协议解析器
     */
    parser: IProtoDataParser;

    /**
     * 协议消息ID, 枚举定义
     */
    protoMsgId: any;

    /**
     * 请求(ID/Name)、响应(Id/Name)关联
     */
    req2Res: any;

    /**
     * 日志打印库
     * @defaultValue `console`
     */
    logger?: ILogger;

    /**
     * 是否输出api日志
     * @defaultValue `true`
     */
    logApi?: boolean;

    /**
     * 是否输出msg日志
     * @defaultValue `true`
     */
    logMsg?: boolean;

    /**
     * api请求超时时间
     * `undefined` or `0` 无限制
     * @defaultValue `15000`
     */
    timeout?: number;
    /**
     * 是否打印二进制数据
     * @defaultValue `false`
     */
    debugBuf?: boolean;
}

export interface PendingApiItem {
    sn: number;
    abortKey: string | undefined;
    msgId: NetType.MsgId;
    type: 'api' | 'msg';
    isAborted?: boolean;
    onAbort?: () => void;
    onReturn?: (ret: NetType.ApiReturn<any>) => void;
}

export type ClientMsgHandler<ServiceType extends NetType.BaseServiceType, MsgName extends keyof ServiceType['msg']> = (msg: ServiceType['msg'][MsgName], msgName: MsgName) => void | Promise<void>;

/**
 * 通信客户端基类抽象
 */
export abstract class BaseClient<ServiceType extends NetType.BaseServiceType> {
    /**
     * 短连接：SHORT
     * 长连接：LONG
     */
    abstract readonly type: 'SHORT' | 'LONG';

    /**
     * 数据类型
     */
    readonly dataType: 'json' | 'text' | 'buffer';

    /**
     * 选项配置
     */
    readonly options: Readonly<BaseClientOptions>;

    /**
     * 日志器
     * @defaultValue `console`
     */
    readonly logger?: ILogger;

    /**
     * 接收消息管理器
     */
    protected _msgHandlers = new MsgHandler();

    /**
     * 协议data parser
     */
    protected parser: IProtoDataParser;

    /**
     * 消息拦截器
     */
    readonly flows = {
        // callApi
        preCallApiFlow: new Flow<CallApiFlowData<ServiceType>>(),
        preApiReturnFlow: new Flow<ApiReturnFlowData<ServiceType>>(),
        postApiReturnFlow: new Flow<ApiReturnFlowData<ServiceType>>(),

        // sendMsg
        preSendMsgFlow: new Flow<SendMsgFlowData<ServiceType>>(),
        postSendMsgFlow: new Flow<SendMsgFlowData<ServiceType>>(),
        preRecvMsgFlow: new Flow<RecvMsgFlowData<ServiceType>>(),
        postRecvMsgFlow: new Flow<RecvMsgFlowData<ServiceType>>(),

        // buffer
        preSendDataFlow: new Flow<{ data: Uint8Array | string | object; sn?: number }>(),
        preRecvDataFlow: new Flow<{ data: Uint8Array | string | object; sn?: number }>(),

        // Connection Flows (Only for WebSocket)
        /** 连接websocket服务器之前 */
        preConnectFlow: new Flow<{
            /** Return `res` to `client.connect()`, without latter connect procedure */
            return?: { isSucc: true; errMsg?: undefined } | { isSucc: false; errMsg: string };
        }>(),
        /** 连接websocket服务器成功之后 */
        postConnectFlow: new Flow<{}>(),
        /** WebSocket连接断开之后 */
        postDisconnectFlow: new Flow<{
            /** 断开原因 `conn.close(reason)` */
            reason?: string;
            /**
             * 是否手动断开 `client.disconnect()`,
             */
            isManual?: boolean;
        }>(),
    } as const;

    protected _apiSnCounter = new Counter(1);

    get lastSN() {
        return this._apiSnCounter.last;
    }

    get nextSN() {
        return this._apiSnCounter.getNext(true);
    }

    /**
     * 挂起等待响应的api请求
     */
    protected _pendingApis: PendingApiItem[] = [];

    constructor(options: BaseClientOptions) {
        this.options = options;
        this.dataType = this.options.parser ? 'text' : 'buffer';
        this.parser = this.options.parser;
        this.logger = this.options.logger;
    }

    protected getMsgId(msgName: string): NetType.MsgId {
        return this.options.protoMsgId[msgName];
    }

    /**
     * Send request and wait for the return
     * @param apiName
     * @param req - Request body
     * @param options - Transport options
     * @returns return a `ApiReturn`, all error (network error, business error, code exception...) is unified as `RpcError`.
     * The promise is never rejected, so you just need to process all error in one place.
     */
    async callApi<T extends string & keyof ServiceType['api']>(apiName: T, req: ServiceType['api'][T]['req'], options: NetType.TransportOptions = {}): Promise<NetType.ApiReturn<ServiceType['api'][T]['res']>> {
        // Add pendings
        let sn = this._apiSnCounter.getNext();
        let pendingItem: PendingApiItem = {
            sn: sn,
            abortKey: options.abortKey,
            msgId: null,
            type: 'api',
        };
        this._pendingApis.push(pendingItem);

        // eslint-disable-next-line no-async-promise-executor
        let promise = new Promise<NetType.ApiReturn<ServiceType['api'][T]['res']>>(async (rs) => {
            // Pre Call Flow
            let pre = await this.flows.preCallApiFlow.exec(
                {
                    apiName: apiName,
                    // 设置自定义Header
                    setHeader: (k, v) => {
                        options.headers = options.headers ?? {};
                        options.headers[k.toLowerCase()] = v;
                    },
                    req: req,
                    options: options,
                },
                this.logger
            );
            if (!pre || pendingItem.isAborted) {
                this.abort(pendingItem.sn);
                return;
            }

            // Do call (send -> wait -> recv -> return)
            let ret: NetType.ApiReturn<ServiceType['api'][T]['res']>;
            // return by pre flow
            if (pre.return) {
                ret = pre.return;
            } else {
                // do call means it will send buffer via network
                ret = await this._doCallApi(pre.apiName, pre.req, pre.options, pendingItem);
            }
            if (pendingItem.isAborted) {
                return;
            }

            // 打印api请求日志
            if (ret.isSucc) {
                this.options.logApi && this.logger?.log(`[ApiRes] #${pendingItem.sn} ${apiName}`, ret.res);
            } else {
                this.options.logApi && this.logger?.error(`[ApiErr] #${pendingItem.sn} ${apiName}`, ret.err);
            }

            // 执行返回结果之前执行拦截器
            let preReturn = await this.flows.preApiReturnFlow.exec(
                {
                    ...pre,
                    return: ret,
                },
                this.logger
            );
            if (!preReturn) {
                this.abort(pendingItem.sn);
                return;
            }

            rs(preReturn.return!);

            // 执行返回结果之后的拦截器
            this.flows.postApiReturnFlow.exec(preReturn, this.logger);
        });

        // 移除等待请求
        promise.catch().then(() => {
            this._pendingApis.removeOne((v) => {
                return v.sn === pendingItem.sn;
            });
        });

        return promise;
    }

    protected async _doCallApi<T extends string & keyof ServiceType['api']>(
        apiName: T,
        req: ServiceType['api'][T]['req'],
        options: NetType.TransportOptions = {},
        pendingItem: PendingApiItem
    ): Promise<NetType.ApiReturn<ServiceType['api'][T]['res']>> {
        this.options.logApi && this.logger?.log(`[ApiReq] #${pendingItem.sn}`, `${apiName}=${this.getMsgId(apiName)}`, req);

        // eslint-disable-next-line no-async-promise-executor
        let promise = new Promise<NetType.ApiReturn<ServiceType['api'][T]['res']>>(async (rs) => {
            // 获取msgId
            let msgId: NetType.MsgId = this.getMsgId(apiName);
            if (null == msgId) {
                rs({
                    isSucc: false,
                    err: new RpcError('Invalid api name: ' + apiName, {
                        code: 'INVALID_API_NAME',
                        type: RcpErrorType.ClientError,
                    }),
                });
                return;
            }
            pendingItem.msgId = msgId;

            // Encode
            let opEncode = this.parser.encode(msgId, apiName, req, this.type === 'LONG' ? pendingItem.sn : undefined);
            if (!opEncode.isSucc) {
                rs({
                    isSucc: false,
                    err: new RpcError(opEncode.errMsg, {
                        type: RcpErrorType.ClientError,
                        code: 'INPUT_DATA_ERR',
                    }),
                });
                return;
            }
            options.sign = opEncode.sign;

            // Send Buf...
            let promiseReturn = this._waitApiReturn(pendingItem, options.timeout ?? this.options.timeout);
            let promiseSend = this.sendData(opEncode.output, options, msgId, pendingItem);
            let opSend = await promiseSend;
            if (opSend.err) {
                rs({
                    isSucc: false,
                    err: opSend.err,
                });
                return;
            }

            // And wait Return...
            let ret = await promiseReturn;
            if (pendingItem.isAborted) {
                return;
            }

            rs(ret);
        });

        return promise;
    }

    /**
     * 发送消息，无需响应，不保证服务器正确接收并处理。
     * 此方法发送消息后不会等待服务器响应，也不确保服务器是否正确接收到消息及处理。
     *
     * @param msgName - 消息名称，用于标识消息类型。
     * @param msg - 消息体，携带实际要发送的数据。
     * @param options - 传输选项，可配置发送过程中的额外参数。
     *
     * @returns 返回一个Promise，当Promise解析完成时，仅表示请求已成功发送至系统内核。
     *          注意，这并不意味着服务器已经正确接收并处理了消息。
     */
    sendMsg<T extends string & keyof ServiceType['msg']>(msgName: T, msg: ServiceType['msg'][T], options: NetType.TransportOptions = {}): Promise<NetType.MsgReturn> {
        // eslint-disable-next-line no-async-promise-executor
        let promise = new Promise<{ isSucc: true } | { isSucc: false; err: RpcError }>(async (rs) => {
            // Pre Flow
            let pre = await this.flows.preSendMsgFlow.exec(
                {
                    msgName: msgName,
                    setHeader: (k, v) => {
                        options.headers = options.headers ?? {};
                        options.headers[k.toLowerCase()] = v;
                    },
                    msg: msg,
                    options: options,
                },
                this.logger
            );
            if (!pre) {
                return;
            }

            // The msg is not prevented by pre flow
            this.options.logMsg && this.logger?.log(`[SendMsg]`, msgName, msg);

            // 获取service
            let msgId = this.getMsgId(msgName);
            if (null == msgId) {
                rs({
                    isSucc: false,
                    err: new RpcError('Invalid msg name: ' + msgName, {
                        code: 'INVALID_MSG_NAME',
                        type: RcpErrorType.ClientError,
                    }),
                });
                return;
            }

            // Encode
            let opEncode = this.parser.encode(msgId, msgName, msg);
            if (!opEncode.isSucc) {
                rs({
                    isSucc: false,
                    err: new RpcError(opEncode.errMsg, {
                        code: 'ENCODE_MSG_ERR',
                    }),
                });
                return;
            }

            // Send Buf...
            let promiseSend = this.sendData(opEncode.output, options, msgId);
            let opSend = await promiseSend;
            if (opSend.err) {
                rs({
                    isSucc: false,
                    err: opSend.err,
                });
                return;
            }

            rs({ isSucc: true });

            // Post Flow
            this.flows.postSendMsgFlow.exec(pre, this.logger);
        });

        promise.then((v) => {
            if (!v.isSucc) {
                (this.logger ?? console).error('[SendMsgErr]', (v as any).err);
            }
        });

        return promise;
    }

    /**
     * Add a message handler,
     * duplicate handlers to the same `msgName` would be ignored.
     * @param msgName
     * @param handler
     * @returns
     */
    // listenMsg<T extends keyof ServiceType['msg']>(msgName: T, handler: ClientMsgHandler<ServiceType, T, this>): ClientMsgHandler<ServiceType, T, this>;
    // listenMsg(msgName: RegExp, handler: ClientMsgHandler<ServiceType, keyof ServiceType['msg'], this>): ClientMsgHandler<ServiceType, keyof ServiceType['msg'], this>;
    // listenMsg(msgName: string | RegExp, handler: ClientMsgHandler<ServiceType, string, this>): ClientMsgHandler<ServiceType, string, this> {
    listenMsg<T extends keyof ServiceType['msg']>(msgName: T | RegExp, handler: ClientMsgHandler<ServiceType, T>): ClientMsgHandler<ServiceType, T> {
        if (msgName instanceof RegExp) {
            Object.keys(this.options.protoMsgId)
                .filter((k) => {
                    return msgName.test(k);
                })
                .forEach((k) => {
                    this._msgHandlers.addHandler(k, handler);
                });
        } else {
            this._msgHandlers.addHandler(msgName as string, handler);
        }

        return handler;
    }
    /**
     * Remove a message handler
     */
    unlistenMsg<T extends keyof ServiceType['msg']>(msgName: T | RegExp, handler: Function) {
        if (msgName instanceof RegExp) {
            Object.keys(this.options.protoMsgId)
                .filter((k) => {
                    return msgName.test(k);
                })
                .forEach((k) => {
                    this._msgHandlers.removeHandler(k, handler);
                });
        } else {
            this._msgHandlers.removeHandler(msgName as string, handler);
        }
    }
    /**
     * Remove all handlers from a message
     */
    unlistenMsgAll<T extends keyof ServiceType['msg']>(msgName: T | RegExp) {
        if (msgName instanceof RegExp) {
            Object.keys(this.options.protoMsgId)
                .filter((k) => {
                    return msgName.test(k);
                })
                .forEach((k) => {
                    this._msgHandlers.removeAllHandlers(k);
                });
        } else {
            this._msgHandlers.removeAllHandlers(msgName as string);
        }
    }

    /**
     * Abort a pending API request, it makes the promise returned by `callApi()` neither resolved nor rejected forever.
     * @param sn - Every api request has a unique `sn` number, you can get it by `this.lastSN`
     */
    abort(sn: number): void {
        // Find
        let index = this._pendingApis.findIndex((v) => {
            return v.sn === sn;
        });
        if (index === -1) {
            return;
        }
        let pendingItem = this._pendingApis[index];
        // Clear
        this._pendingApis.splice(index, 1);
        pendingItem.onReturn = undefined;
        pendingItem.isAborted = true;

        // Log
        this.logger?.log(`[ApiAbort] #${pendingItem.sn} ${this.options.protoMsgId[pendingItem.msgId]}=${pendingItem.msgId}`);
        // onAbort
        pendingItem.onAbort?.();
    }
    /**
     * 中断abortKey请求
     * ```ts
     * // Send API request many times
     * client.callApi('SendData', { data: 'AAA' }, { abortKey: 'Session#123' });
     * client.callApi('SendData', { data: 'BBB' }, { abortKey: 'Session#123' });
     * client.callApi('SendData', { data: 'CCC' }, { abortKey: 'Session#123' });
     *
     * // And abort the at once
     * client.abortByKey('Session#123');
     * ```
     */
    abortByKey(abortKey: string) {
        this._pendingApis
            .filter((v) => {
                return v.abortKey === abortKey;
            })
            .forEach((v) => {
                this.abort(v.sn);
            });
    }
    /**
     * 中断所有请求
     */
    abortAll() {
        this._pendingApis.slice().forEach((v) => {
            return this.abort(v.sn);
        });
    }

    /**
     * 发送数据
     * @param data
     * @param options
     * @param sn
     */
    async sendData(data: Uint8Array | string | object, options: NetType.TransportOptions, msgId: NetType.MsgId, pendingApiItem?: PendingApiItem): Promise<{ err?: RpcError }> {
        // Pre Flow
        let pre = await this.flows.preSendDataFlow.exec({ data: data, sn: pendingApiItem?.sn }, this.logger);
        if (!pre) {
            return new Promise((rs) => {});
        }
        data = pre.data;

        // debugBuf log
        if (this.options.debugBuf) {
            if (typeof data === 'string') {
                this.logger?.debug('[SendText]' + (pendingApiItem ? ' #' + pendingApiItem.sn : '') + ` length=${data.length}`, data);
            } else if (data instanceof Uint8Array) {
                this.logger?.debug('[SendBuf]' + (pendingApiItem ? ' #' + pendingApiItem.sn : '') + ` length=${data.length}`, data);
            } else {
                this.logger?.debug('[SendJSON]' + (pendingApiItem ? ' #' + pendingApiItem.sn : ''), data);
            }
        }

        return this._sendData(data, options, msgId, pendingApiItem);
    }
    protected abstract _sendData(data: Uint8Array | string | object, options: NetType.TransportOptions, msgId: NetType.MsgId, pendingApiItem?: PendingApiItem): Promise<{ err?: RpcError }>;

    protected abstract _handleHeartbeat(opParsed: DecodeOutput): boolean;
    /**
     * 信道可传输二进制或字符串
     * @param data
     * @param pendingApiItem
     * @returns
     */
    protected async _onRecvData(data: Uint8Array | string | object, pendingApiItem?: PendingApiItem) {
        let sn = pendingApiItem?.sn;

        // Pre Flow
        let pre = await this.flows.preRecvDataFlow.exec({ data: data, sn: sn }, this.logger);
        if (!pre) {
            return;
        }
        data = pre.data;

        if (typeof data === 'string') {
            this.options.debugBuf && this.logger?.debug('[RecvText]' + (sn ? ' #' + sn : ''), data);
        } else if (data instanceof Uint8Array) {
            this.options.debugBuf && this.logger?.debug('[RecvBuf]' + (sn ? ' #' + sn : ''), 'length=' + data.length, data);
        } else {
            this.options.debugBuf && this.logger?.debug('[RecvJSON]' + (sn ? ' #' + sn : ''), data);
        }

        let reqName = EnumHelper.getKeyFromValue(this.options.protoMsgId, pendingApiItem?.msgId);
        let resName = this.options.req2Res[reqName];

        // Parse
        let opParsed = this.parser.decode(resName, data as Uint8Array, sn);
        if (!opParsed.isSucc) {
            this.logger?.error('ParseServerOutputError: ' + (opParsed as any).errMsg);
            if (data instanceof Uint8Array) {
                this.logger?.error('Please check the version of serviceProto between server and client');
            }
            if (pendingApiItem) {
                pendingApiItem.onReturn?.({
                    isSucc: false,
                    err: new RpcError('Parse server output error'),
                });
            }
            return;
        }

        if (this._handleHeartbeat(opParsed)) {
            return;
        }

        // opParsed.msgId

        let reqMsgId = this.options.req2Res[opParsed.msgId];
        if (pendingApiItem) {
            sn = sn ?? opParsed.sn;

            // ApiReturn<any>
            // call ApiReturn listeners
            this._pendingApis
                .find((v) => {
                    return v.sn === sn;
                })
                ?.onReturn?.({
                    isSucc: true,
                    res: opParsed.output,
                });
        } else if (null != reqMsgId) {
            this._pendingApis
                .find((v) => {
                    return v.msgId === reqMsgId;
                })
                ?.onReturn?.({
                    isSucc: true,
                    res: opParsed.output,
                });
        } else {
            this.options.logMsg && this.logger?.log(`[RecvMsg] ${this.options.protoMsgId[opParsed.msgId]}`, opParsed.output);

            // Pre Flow
            let pre = await this.flows.preRecvMsgFlow.exec({ msgName: this.options.protoMsgId[opParsed.msgId] as any, msg: opParsed.output as any }, this.logger);
            if (!pre) {
                return;
            }

            this._msgHandlers.forEachHandler(pre.msgName, this.logger, pre.msg, pre.msgName);

            // Post Flow
            await this.flows.postRecvMsgFlow.exec(pre, this.logger);
        }
    }

    /** @deprecated Please use `_onRecvData` instead */
    protected _onRecvBuf: (buf: Uint8Array, pendingApiItem?: PendingApiItem) => Promise<void> = this._onRecvData;

    /**
     * @param sn
     * @param timeout
     * @returns `undefined` 代表 canceled
     */
    protected async _waitApiReturn(pendingItem: PendingApiItem, timeout?: number): Promise<NetType.ApiReturn<any>> {
        return new Promise<any>((rs) => {
            // Timeout
            let timer: ReturnType<typeof setTimeout> | undefined;

            if (timeout) {
                timer = setTimeout(() => {
                    timer = undefined;
                    this._pendingApis.removeOne((v) => {
                        return v.sn === pendingItem.sn;
                    });
                    rs({
                        isSucc: false,
                        err: new RpcError('Request Timeout', {
                            code: 'TIMEOUT',
                        }),
                    });
                }, timeout);
            }

            // Listener (trigger by `this._onRecvBuf`)
            pendingItem.onReturn = (ret) => {
                if (timer) {
                    clearTimeout(timer);
                    timer = undefined;
                }
                this._pendingApis.removeOne((v) => {
                    return v.sn === pendingItem.sn;
                });
                rs(ret);
            };
        });
    }
}
