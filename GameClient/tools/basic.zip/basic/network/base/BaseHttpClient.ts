import { BaseClient, BaseClientOptions, defaultBaseClientOptions, PendingApiItem } from './BaseClient';
import { RpcError } from './type/RpcError';
import { DecodeOutput } from '../IProtoDataParser';
import { NetType } from './type/NetType';

/**
 * Base HTTP Client
 */
export class BaseHttpClient<ServiceType extends NetType.BaseServiceType> extends BaseClient<ServiceType> {
    readonly type = 'SHORT';

    private _http: IHttpProxy;

    readonly options!: Readonly<BaseHttpClientOptions>;

    constructor(http: IHttpProxy, options?: Partial<BaseHttpClientOptions>) {
        super({
            ...defaultBaseHttpClientOptions,
            ...options,
        });
        this._http = http;
        this.logger?.log('WE HTTP Client :', this.options.server);
    }

    protected _handleHeartbeat(opParsed: DecodeOutput): boolean {
        return false;
    }

    protected async _sendData(
        data: Uint8Array | string,
        options: NetType.TransportOptions,
        msgId: NetType.MsgId,
        pendingApiItem?: PendingApiItem
    ): Promise<{
        err?: RpcError | undefined;
    }> {
        let promise = (async (): Promise<
            | { err: RpcError | undefined; res?: undefined }
            | {
                  res: string | Uint8Array;
                  err?: undefined;
              }
        > => {
            // Send to this URL
            let url = this.options.server + msgId;

            if (options.sign) {
                url += '?sign=' + options.sign;
            }

            // let headers = !options.headers
            //     ? { 'Content-Type': typeof data === 'string' ? 'application/json' : 'application/octet-stream' }
            //     : { 'Content-Type': typeof data === 'string' ? 'application/json' : 'application/octet-stream', ...options.headers };

            // Do Send
            let { promise: fetchPromise, abort } = this._http.fetch({
                url: url,
                data: data,
                method: 'POST',
                timeout: options.timeout || this.options.timeout,
                headers: options.headers,
                transportOptions: options,
                responseType: typeof data === 'string' ? 'text' : 'arraybuffer',
            });

            if (pendingApiItem) {
                pendingApiItem.onAbort = () => {
                    abort();
                };
            }

            // Aborted
            if (pendingApiItem?.isAborted) {
                return new Promise((rs) => {});
            }

            let fetchRes = await fetchPromise;
            if (!fetchRes.isSucc) {
                return { err: (fetchRes as any).err };
            }
            return { res: fetchRes.res };
        })();

        promise.then((v) => {
            // Msg 不需要 onRecvData
            if (pendingApiItem && v.res) {
                this._onRecvData(v.res, pendingApiItem);
            }
        });

        // Finally
        promise
            .catch((e) => {})
            .then(() => {
                if (pendingApiItem) {
                    pendingApiItem.onAbort = undefined;
                }
            });

        return promise;
    }
}

export const defaultBaseHttpClientOptions: BaseHttpClientOptions = {
    ...defaultBaseClientOptions,
    server: 'http://localhost:3000',
    // we.logger. new TerminalColorLogger(),
};

export interface BaseHttpClientOptions extends BaseClientOptions {
    /** Server URL, starts with `http://` or `https://`. */
    server: string;
}

export interface IHttpProxy {
    fetch(options: {
        url: string;
        data: string | Uint8Array;
        method: string;
        /** ms */
        timeout?: number;
        headers?: { [key: string]: string };
        transportOptions: NetType.TransportOptions;
        responseType: 'text' | 'arraybuffer';
    }): {
        abort: () => void;
        promise: Promise<{ isSucc: true; res: string | Uint8Array } | { isSucc: false; err: RpcError }>;
    };
}
