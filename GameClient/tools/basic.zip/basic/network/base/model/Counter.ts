/**
 * 计数器
 */
export class Counter {
    private _min: number;
    private _max: number;
    private _last: number;

    constructor(min: number = 1, max: number = Number.MAX_SAFE_INTEGER) {
        this._min = min;
        this._max = max;
        this._last = max;
    }

    /**
     * 重置计数器
     */
    reset() {
        this._last = this._max;
    }

    /**
     * Get next counter value, and auto increment `1`
     * @param notInc - Just get the next possible value, not actually increasing the sequence
     */
    getNext(notInc?: boolean) {
        return this._last >= this._max ? (this._last = this._min) : notInc ? this._last : ++this._last;
    }

    /**
     * 最后一次的计数器值
     */
    get last() {
        return this._last;
    }
}
