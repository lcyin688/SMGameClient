import { NetType } from './NetType';

export type CallApiFlowData<ServiceType extends NetType.BaseServiceType> = {
    [K in keyof ServiceType['api']]: {
        apiName: K & string;
        req: ServiceType['api'][K]['req'];
        setHeader: (k: string, v: number | string) => void;
        options?: NetType.TransportOptions;
        // promise: SuperPromise<ServiceType['api'][K]['res']>,
        return?: NetType.ApiReturn<ServiceType['api'][K]['res']>;
    };
}[keyof ServiceType['api']];
export type ApiReturnFlowData<ServiceType extends NetType.BaseServiceType> = {
    [K in keyof ServiceType['api']]: {
        apiName: K & string;
        req: ServiceType['api'][K]['req'];
        options?: NetType.TransportOptions;
        // promise: SuperPromise<ServiceType['api'][K]['res']>,
        return: NetType.ApiReturn<ServiceType['api'][K]['res']>;
    };
}[keyof ServiceType['api']];

export type SendMsgFlowData<ServiceType extends NetType.BaseServiceType> = {
    [K in keyof ServiceType['msg']]: {
        msgName: K & string;
        setHeader: (k: string, v: number | string) => void;
        msg: ServiceType['msg'][K];
        options?: NetType.TransportOptions;
    };
}[keyof ServiceType['msg']];
export type RecvMsgFlowData<ServiceType extends NetType.BaseServiceType> = {
    [K in keyof ServiceType['msg']]: {
        msgName: K & string;
        msg: ServiceType['msg'][K];
    };
}[keyof ServiceType['msg']];
