import { lodash } from '../../../utils/NpmExport';

declare global {
    interface ICore {
        RpcError: typeof RpcError;
        RcpErrorType: typeof RcpErrorType;
    }
    interface TCore {
        RcpErrorType: RcpErrorType;
    }
    namespace we {
        namespace core {
            type RpcError = InstanceType<typeof RpcError>;
            type RcpErrorType = TCore['RcpErrorType'];
        }
    }
}

/**
 * RPC服务中可能出现的不同类型的错误。
 */
export enum RcpErrorType {
    /**
     * 网络错误，例如连接断开、网络超时等。
     */
    NetworkError = 'NetworkError',
    /**
     * 服务器异常，例如“请求格式错误”、“数据库异常”等。
     *
     * @remarks
     * 这些错误信息可能不适合直接展示给用户，
     * 但是错误信息对于工程师查找某些bug非常有用。
     * 因此，你可以向用户显示一个友好的消息（如“系统错误，请联系XXX”），
     * 同时报告一些调试信息。
     */
    ServerError = 'ServerError',
    /**
     * 客户端异常，例如解析服务器输出错误。
     * （可能是因为服务器和客户端之间的proto文件不一致）
     */
    ClientError = 'ClientError',
    /**
     * 由`call.error`返回的业务错误。
     * 它总是与业务相关，例如`call.error('密码不正确')`、`call.error('信用不足')`等。
     */
    ApiError = 'ApiError',
}

we.core.RcpErrorType = RcpErrorType;

export interface RpcErrorData {
    /**
     * 错误信息
     */
    message: string;
    /**
     * 错误码
     */
    code?: string | number;

    /**
     * 错误类型
     */
    type: RcpErrorType;

    /**
     * 扩展错误
     */
    [key: string]: any;
}

export class RpcError implements RpcErrorData {
    message!: string;
    code?: string | number;
    type: RcpErrorType;
    [key: string]: any;

    constructor(data: RpcErrorData);
    constructor(message: string, data?: Partial<RpcErrorData>);
    constructor(dataOrMessage: RpcErrorData | string, data?: Partial<RpcErrorData>) {
        if (typeof dataOrMessage === 'string') {
            this.message = dataOrMessage;
            lodash.assign(this, data);
        } else {
            lodash.assign(this, dataOrMessage);
        }
    }

    toString() {
        return `[WE ${this.type ? this.type : RcpErrorType.NetworkError}]: ${this.message}`;
    }
}

we.core.RpcError = RpcError;
