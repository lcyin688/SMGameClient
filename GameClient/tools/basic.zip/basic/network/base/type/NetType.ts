import { AsyncTask } from '../../../module/async/AsyncTask';
import { RpcError } from './RpcError';

declare global {
    namespace we {
        namespace core {
            namespace netType {
                type BaseMsgType = NetType.BaseMsgType;
                type MsgClientOptions = NetType.MsgClientOptions;
                type TransportOptions = NetType.TransportOptions;
                type MsgReturn = NetType.MsgReturn;
                type ReqMsgItem<MSGTYPE extends BaseMsgType> = NetType.ReqMsgItem<MSGTYPE>;
                type ApiReturn<Res> = NetType.ApiReturn<Res>;
                type ReqID = NetType.ReqID;
                type ResID = NetType.ResID;
            }
        }
    }
}

export namespace NetType {
    /** 请求ID */
    export type ReqID = number;
    /** 响应ID */
    export type ResID = number;

    /** Msg Client 配置参数 */
    export interface MsgClientOptions {
        /**
         * 协议消息ID, 枚举定义
         */
        protoMsgId: object;
        /**
         * Proto协议, 供pb库加载
         */
        proto: string | string[];
        /**
         * 游戏Id
         */
        gameId: number;
        /**
         * 请求响应ID关联
         */
        req2res: Record<ReqID, ResID>;
    }

    /**
     * 基础消息结构定义
     */
    export interface BaseMsgType {
        api: {
            [apiName: string]: {
                /** Request type */
                req: any;
                /** Response type */
                res: any;
            };
        };
        msg: {
            /** Msg type */
            [msgName: string]: any;
        };
    }

    export interface ReqMsgItem<MSGTYPE extends BaseMsgType> {
        /**
         * 是否已发送
         */
        isSended: boolean;
        /**
         * 发送消息体
         */
        msg: any;
        /**
         * 请求消息Id
         */
        msgId: number;
        /**
         * 消息Key
         */
        msgKey: string & keyof MSGTYPE['api'];
        /**
         * 请求消息数据
         */
        msgData: MSGTYPE['api'][string & keyof MSGTYPE['api']]['req'];
        /**
         * 请求透出参数
         */
        options?: TransportOptions;
        /**
         * 请求时间戳
         */
        timestamp: number;
        /**
         * 消息超时时间，单位【ms】
         */
        timeout: number;
        /**
         * 异步任务
         */
        asyncTask: AsyncTask<ApiReturn<MSGTYPE['api'][string & keyof MSGTYPE['api']]['res']>>;
    }

    /**
     * 请求响应-成功返回
     */
    export interface ApiReturnSucc<Res> {
        isSucc: true;
        /** 响应消息 */
        res: Res;
        err?: undefined;
    }
    /**
     * 请求响应-失败返回
     */
    export interface ApiReturnError {
        isSucc: false;
        /** 响应消息 */
        res?: undefined;
        /** 错误码 */
        err: RpcError;
    }

    /**
     * client.callApi() 返回
     */
    export type ApiReturn<Res> = ApiReturnSucc<Res> | ApiReturnError;

    /**
     * client.sendMsg-返回
     */
    export type MsgReturn =
        | {
              isSucc: true;
          }
        | {
              isSucc: false;
              err: RpcError;
              msg?: string;
          };
    /**
     * 服务器消息类型定义
     */
    export interface BaseServiceType {
        api: {
            [apiName: string]: {
                /** Request type */
                req: any;
                /** Response type */
                res: any;
            };
        };
        msg: {
            /** Msg type */
            [msgName: string]: any;
        };
    }

    export type MsgId = number | string;

    /**
     * 接口请求透传参数
     */
    export interface TransportOptions {
        /**
         * 超时时间，单位【ms】
         * @defaultValue 30000
         */
        timeout?: number;
        /**
         * 主动中断请求的key
         * // Send API request many times
         * client.callApi('SendData', { data: 'AAA' }, { abortKey: 'Session#123' });
         * client.callApi('SendData', { data: 'BBB' }, { abortKey: 'Session#123' });
         * client.callApi('SendData', { data: 'CCC' }, { abortKey: 'Session#123' });
         *
         * // And abort the at once
         * client.abortByKey('Session#123');
         */
        abortKey?: string;
        /**
         * 自定义请求头
         */
        headers?: { [key: string]: any };
        /**
         * 签名
         */
        sign?: string;
    }
}
