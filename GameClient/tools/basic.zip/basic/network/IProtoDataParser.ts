import { NetType } from './base/type/NetType';

export declare type EncodeOutput<T> =
    | {
          isSucc: true;
          /** 二进制Buffer */
          output: T;
          /**
           * 签名
           */
          sign?: string;
          errMsg?: undefined;
      }
    | {
          isSucc: false;
          /** 错误信息 */
          errMsg: string;
          output?: undefined;
      };

export declare type DecodeOutput = { isSucc: true; msgId: NetType.MsgId; sn: number; output: object; isHeartbeat: boolean } | { isSucc: false; errMsg: string };

/**
 * 协议数据解析器接口抽象
 */
export abstract class IProtoDataParser {
    deviceInfo: string;
    heartbeat: Uint8Array;
    abstract getHeartbeat(): Uint8Array;
    abstract decode(msgName: string, arrayBuffer: Uint8Array, sn?: number): DecodeOutput;
    abstract encode(msgId: NetType.MsgId, msgName: string, msgData: object, sn?: number): EncodeOutput<Uint8Array> | EncodeOutput<string> | EncodeOutput<object>;
}
