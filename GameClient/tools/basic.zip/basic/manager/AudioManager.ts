import BasicEventName from '../const/BasicEventName';
import AssetManager from './AssetManager';

declare global {
    interface ICore {
        audioMgr: typeof AudioManager;
    }
    interface TCore {
        IAudio: IAudio;
    }
    namespace we {
        namespace core {
            type IAudio = TCore['IAudio'];
        }
    }
}

export interface IAudio {
    url: string;
    id: number;
    loop: boolean;
    volume: number;
    /** 持续时间，单位 秒 */
    duration?: number;
    /** 标签 */
    tag?: string;
    /** 停止播放 */
    stop?: () => void;
    /** 是否已停止播放 */
    isStop?: boolean;
}

/** 背景音乐基础音量倍数 */
const MUSIC_VOLUME_RATIO = 0.5;
/** 音效基础音量倍数 */
const EFFECT_VOLUME_RATIO = 0.6;

export default class AudioManager {
    public static MUSIC_VOLUME_RATIO = MUSIC_VOLUME_RATIO;
    public static EFFECT_VOLUME_RATIO = EFFECT_VOLUME_RATIO;

    private static _musicVolumeRatio: number = 1; // 音乐音量比例，不缓存，切换场景应重置为1
    public static get musicVolumeRatio() {
        return this._musicVolumeRatio;
    }

    private static _musicVolume: number = 0;
    public static get musicVolume() {
        return this._musicVolume;
    }

    private static musics: IAudio[] = [];

    private static _effectVolumeRatio: number = 1; // 音效音量比例，不缓存，切换场景应重置为1
    public static get effectVolumeRatio() {
        return this._effectVolumeRatio;
    }

    private static _effectVolume: number = 0;
    public static get effectVolume() {
        return this._effectVolume;
    }

    private static effects: IAudio[] = [];

    /** 是否可恢复 */
    private static resumeEnabled: boolean = true;

    public static init(): void {
        let _musicVolume = we.kit.storage.get('sys', 'app_music_volume');
        if (_musicVolume == null) {
            _musicVolume = 1;
        } else {
            _musicVolume = Number(_musicVolume);
            if (!(_musicVolume >= 0 && _musicVolume <= 1)) {
                _musicVolume = 1;
            }
        }
        this._musicVolume = _musicVolume;
        we.kit.storage.setById('sys', 'app_music_volume', this._musicVolume);

        let _effectVolume = we.kit.storage.get('sys', 'app_effect_volume');
        if (_effectVolume == null) {
            _effectVolume = 1;
        } else {
            _effectVolume = Number(_effectVolume);
            if (!(_effectVolume >= 0 && _effectVolume <= 1)) {
                _effectVolume = 1;
            }
        }
        this._effectVolume = _effectVolume;
        we.kit.storage.setById('sys', 'app_effect_volume', this._effectVolume);
    }

    /** -------------------------------- 背景音乐 -------------------------------- */

    /**
     * 播放背景音乐
     * @param url
     * @param loop 是否循环，默认 true
     * @param volume 音量，0-1，默认 系统音量
     * @param onEnd 结束回调
     */
    public static playMusic(url: string, loop: boolean = true, volume: number = 1, onEnd: (audio: IAudio) => void = null): void {
        if (!(url && typeof url == 'string')) {
            // 日志不上报: bgm 走后台配置，允许不配置，为空是正常情况，不兜底
            we.warn(`AudioManager playMusic, url err`, we.noup);
            return;
        }

        volume = Math.max(0, Math.min(1, volume));

        if (this.musics.length > 0 && this.musics[this.musics.length - 1].url === url && this.musics[this.musics.length - 1].id !== null) {
            return;
        }

        this.stopMusic();

        let audio: IAudio = { url: url, id: null, loop: loop, volume: volume };
        this.musics.push(audio);

        const onPlayMusic = (clip: cc.AudioClip) => {
            if (!clip) {
                this.removeAudio(audio);
                return;
            }

            let index = this.musics.indexOf(audio);
            if (index != this.musics.length - 1) {
                // 后面又播放了其他bgm
                return;
            }

            // 实际音量应该是 系统调整音量 * 用户设置总音量 * 模块单独设置音效 * 用户当前播放音乐设置的音量
            const currVolume = this._musicVolume * MUSIC_VOLUME_RATIO * this._musicVolumeRatio * volume;

            audio.id = cc.audioEngine.play(clip, loop, currVolume);

            cc.audioEngine.setFinishCallback(audio.id, () => {
                audio.id = null;
                if (typeof onEnd == 'function') {
                    onEnd(audio);
                }
            });
        };

        if (url.startsWith('http')) {
            AssetManager.loadAssetRemote(url, cc.AudioClip, (clip) => {
                if (!clip) {
                    we.warn(`AudioManager playMusic, loadRemote err: ${url}`);
                    this.removeAudio(audio);
                    return;
                }
                onPlayMusic(clip);
            });
        } else {
            AssetManager.loadAsset(url, cc.AudioClip, (clip) => {
                onPlayMusic(clip);
            });
        }
    }

    /** 移除audio对象的方法 */
    private static removeAudio(audio: IAudio) {
        const index = this.musics.indexOf(audio);
        if (index !== -1) {
            this.musics.splice(index, 1);
        }
    }

    /**
     * 停止背景音乐
     */
    public static stopMusic(): void {
        for (let i = 0; i < this.musics.length; i++) {
            let audio = this.musics[i];
            if (audio.id != null) {
                cc.audioEngine.stop(audio.id);
                audio.id = null;
            }
        }
    }

    /**
     * 暂停背景音乐
     */
    public static pauseMusic(): void {
        if (this.musics.length > 0) {
            cc.audioEngine.pause(this.musics[this.musics.length - 1].id);
        }
    }

    /**
     * 恢复背景音乐
     */
    public static resumeMusic(): void {
        if (this.musics.length > 0) {
            cc.audioEngine.resume(this.musics[this.musics.length - 1].id);
        }
    }

    /**
     * 设置背景音乐开关
     * @param open
     */
    public static setMusicOpen(open: boolean): void {
        this.setMusicVolumeValue(open ? 1 : 0);
    }

    /**
     * 设置背景音乐音量-数值
     * @param volume 音量，0-1
     */
    public static setMusicVolumeValue(volume: number): void {
        if (!(volume >= 0 && volume <= 1)) {
            we.warn(`AudioManager setMusicVolumeValue, volume err: ${volume}`);
            volume = 1;
        }

        if (this._musicVolume == volume) {
            return;
        }

        this._musicVolume = volume;
        cc.director.emit(BasicEventName.AUDIO_MUSIC_VOLUME_VALUE_CHANGE, volume);
        we.kit.storage.setById('sys', 'app_music_volume', this._musicVolume);

        this.setMusicVolume(this._musicVolume * this._musicVolumeRatio);
    }

    /**
     * 设置背景音乐音量-比例
     * @param ratio 比例，0-1
     * @param resetTime 重置时间，[0-60]，单位 秒，默认 0（不重置）
     */
    public static setMusicVolumeRatio(ratio: number, resetTime: number = 0): void {
        if (!(ratio >= 0 && ratio <= 1)) {
            we.warn(`AudioManager setMusicVolumeRatio, ratio err: ${ratio}`);
            ratio = 1;
        }

        if (!(resetTime >= 0 && resetTime <= 60)) {
            we.warn(`AudioManager setMusicVolumeRatio, resetTime err: ${resetTime}`);
            return;
        }

        this._musicVolumeRatio = ratio;
        cc.director.emit(BasicEventName.AUDIO_MUSIC_VOLUME_RATIO_CHANGE, ratio);

        this.setMusicVolume(this._musicVolume * ratio);

        if (resetTime > 0) {
            setTimeout(() => {
                this.setMusicVolume(this._musicVolume);
            }, resetTime * 1000);
        }
    }

    /**
     * 设置背景音乐音量
     * @param volume 音量，0-1
     */
    private static setMusicVolume(volume: number): void {
        if (!(volume >= 0 && volume <= 1)) {
            we.warn(`AudioManager setMusicVolume, volume err: ${volume}`);
            volume = 1;
        }

        if (!this.isMusicOpen()) {
            volume = 0;
        }

        if (this.musics.length > 0) {
            const music = this.musics[this.musics.length - 1];
            cc.audioEngine.setVolume(music.id, MUSIC_VOLUME_RATIO * volume * music.volume);
        }
    }

    /**
     * 背景音乐是否打开
     * @returns
     */
    public static isMusicOpen(): boolean {
        return this._musicVolume > 0;
    }

    /** -------------------------------- 音效 -------------------------------- */

    /**
     * 播放音效
     * @param url
     * @param loop 是否循环，默认 false
     * @param volume 音量，0-1，默认 系统音量
     * @param time 从什么时间开始播放，单位秒，0-duration，默认 0
     * @param tag 标签，默认 空
     * @param onPlay 播放回调
     * @param onEnd 结束回调
     * @returns IAudio
     */
    public static playEffect(url: string, loop: boolean = null, volume: number = null, time: number = null, tag: string = null, onPlay: (audio: IAudio) => void = null, onEnd: (audio: IAudio) => void = null): IAudio {
        if (!url || typeof url !== 'string') {
            we.warn(`AudioManager playEffect, url err`);
        }

        if (loop == null) {
            loop = false;
        }

        volume = volume ?? 1;

        if (!(volume >= 0 && volume <= 1)) {
            we.warn(`AudioManager playEffect, volume err: ${volume}`);
            volume = 1;
        }

        if (this.effects.length >= cc.audioEngine.getMaxAudioInstance() - 1) {
            let audio = this.effects.shift();
            cc.audioEngine.stop(audio.id);
            this.clearAudio(audio);
        }

        let audio: IAudio = {
            url: url,
            id: null,
            loop: loop,
            volume: volume,
            duration: null,
            tag: tag,
            stop: null,
            isStop: false,
        };

        let remove = () => {
            let index = this.effects.indexOf(audio);
            if (index > -1) {
                this.effects.splice(index, 1);
            }
            this.clearAudio(audio);
        };

        let stop = () => {
            we.warn(`AudioManager playEffect, stop, uninit, url: ${url}`, we.noup);
            remove();
            this.stopEffect(url);
        };

        audio.stop = stop;

        this.effects.push(audio);

        AssetManager.loadAsset(url, cc.AudioClip, (clip) => {
            if (audio.isStop) {
                return;
            }
            if (clip) {
                // 实际音量，系统默认音量 * 用户设置总音量 * 模块单独设置总音效 * 播放时的音效设置音量
                const currVolume = EFFECT_VOLUME_RATIO * this._effectVolume * this._effectVolumeRatio * volume;
                audio.id = cc.audioEngine.play(clip, loop, currVolume);
                audio.duration = cc.audioEngine.getDuration(audio.id);

                if (time > 0 && time < audio.duration) {
                    cc.audioEngine.setCurrentTime(audio.id, time);
                }

                audio.stop = () => {
                    cc.audioEngine.stop(audio.id);
                    remove();
                };

                cc.audioEngine.setFinishCallback(audio.id, () => {
                    remove();

                    if (typeof onEnd == 'function') {
                        onEnd(audio);
                    }
                });

                if (typeof onPlay == 'function') {
                    onPlay(audio);
                }
            } else {
                we.warn(`AudioManager playEffect, faild, url: ${url}`);
                remove();
            }
        });

        return audio;
    }

    /**
     * 停止音效
     * @param url
     * @param all 相同url是否全部停止，默认 true
     */
    public static stopEffect(url: string, all: boolean = true): void {
        if (!(url && typeof url == 'string')) {
            we.warn(`AudioManager stopEffect, url err`);
        }

        for (let i = 0; i < this.effects.length; i++) {
            const audio = this.effects[i];
            if (url == audio.url) {
                cc.audioEngine.stop(audio.id);
                this.clearAudio(audio);
                this.effects.splice(i, 1);
                i--;

                if (!all) {
                    break;
                }
            }
        }
    }

    /**
     * 播放标签音效
     * @param tag 标签
     * @param url
     * @param loop 是否循环，默认 false
     * @param volume 音量，0-1，默认 系统音量
     * @returns IAudio
     */
    public static playTagEffect(tag: string, url: string, loop: boolean = null, volume: number = null): IAudio {
        return this.playEffect(url, loop, volume, null, tag);
    }

    /**
     * 停止标签音效
     * @param tag 标签，默认空（停止所有标签）
     */
    public static stopTagEffect(tag: string = null): void {
        for (let i = 0; i < this.effects.length; i++) {
            const audio = this.effects[i];
            if ((tag && tag == audio.tag) || (!tag && audio.tag)) {
                cc.audioEngine.stop(audio.id);
                this.clearAudio(audio);
                this.effects.splice(i, 1);
                i--;
            }
        }
    }

    /**
     * 停止所有音效
     */
    public static stopAllEffects(): void {
        for (let i = 0; i < this.effects.length; i++) {
            const audio = this.effects[i];
            cc.audioEngine.stop(audio.id);
            this.clearAudio(audio);
        }

        this.effects = [];
    }

    /**
     * 暂停音效
     * @param url
     * @param all 相同url是否全部暂停，默认 true
     */
    public static pauseEffect(url: string, all: boolean = true): void {
        if (!(url && typeof url == 'string')) {
            we.warn(`AudioManager pauseEffect, url err`);
        }

        for (let i = 0; i < this.effects.length; i++) {
            if (url == this.effects[i].url) {
                cc.audioEngine.pause(this.effects[i].id);
                if (!all) {
                    break;
                }
            }
        }
    }

    /**
     * 暂停所有音效
     */
    public static pauseAllEffects(): void {
        for (let i = 0; i < this.effects.length; i++) {
            cc.audioEngine.pause(this.effects[i].id);
        }
    }

    /**
     * 恢复音效
     * @param url
     * @param all 相同url是否全部恢复，默认 true
     */
    public static resumeEffect(url: string, all: boolean = true): void {
        if (!(url && typeof url == 'string')) {
            we.warn(`AudioManager resumeEffect, url err`);
        }

        for (let i = 0; i < this.effects.length; i++) {
            if (url == this.effects[i].url) {
                cc.audioEngine.resume(this.effects[i].id);
                if (!all) {
                    break;
                }
            }
        }
    }

    /**
     * 恢复所有音效
     */
    public static resumeAllEffects(): void {
        for (let i = 0; i < this.effects.length; i++) {
            cc.audioEngine.resume(this.effects[i].id);
        }
    }

    /**
     * 设置音效开关
     * @param open
     */
    public static setEffectOpen(open: boolean): void {
        this.setEffectsVolumeValue(open ? 1 : 0);
    }

    /**
     * 设置音效音量-数值
     * @param volume 音量，0-1
     */
    public static setEffectsVolumeValue(volume: number): void {
        if (!(volume >= 0 && volume <= 1)) {
            we.warn(`AudioManager setEffectsVolumeValue, volume err: ${volume}`);
            volume = 1;
        }

        if (this._effectVolume == volume) {
            return;
        }

        this._effectVolume = volume;
        cc.director.emit(BasicEventName.AUDIO_EFFECT_VOLUME_VALUE_CHANGE, volume);
        we.kit.storage.setById('sys', 'app_effect_volume', this._effectVolume);

        this.setEffectsVolume(this._effectVolume * this._effectVolumeRatio);
    }

    /**
     * 设置音效音量-比例
     * @param ratio 比例，0-1
     * @param resetTime 重置时间，[0-30]，单位 秒，默认 0（不重置）
     */
    public static setEffectsVolumeRatio(ratio: number, resetTime: number = 0): void {
        if (!(ratio >= 0 && ratio <= 1)) {
            we.warn(`AudioManager setEffectsVolumeRatio, ratio err: ${ratio}`);
            ratio = 1;
        }

        if (!(resetTime >= 0 && resetTime <= 30)) {
            we.warn(`AudioManager setEffectsVolumeRatio, resetTime err: ${resetTime}`);
            return;
        }
        this._effectVolumeRatio = ratio;
        cc.director.emit(BasicEventName.AUDIO_EFFECT_VOLUME_RATIO_CHANGE, ratio);

        this.setEffectsVolume(this._effectVolume * ratio);

        if (resetTime > 0) {
            setTimeout(() => {
                this.setEffectsVolume(this._effectVolume);
            }, resetTime * 1000);
        }
    }

    /**
     * 设置音效音量
     * @param volume 音量，0-1
     */
    private static setEffectsVolume(volume: number): void {
        if (!(volume >= 0 && volume <= 1)) {
            we.warn(`AudioManager setEffectsVolume, volume err: ${volume}`);
            volume = 1;
        }

        if (!this.isEffectOpen()) {
            volume = 0;
        }

        for (let i = 0; i < this.effects.length; i++) {
            const effect = this.effects[i];
            cc.audioEngine.setVolume(effect.id, EFFECT_VOLUME_RATIO * volume * effect.volume);
        }
    }

    /**
     * 音效是否打开
     * @returns
     */
    public static isEffectOpen(): boolean {
        return this._effectVolume > 0;
    }

    /** -------------------------------- all -------------------------------- */

    public static stopAll(): void {
        cc.audioEngine.stopAll();

        for (let i = 0; i < this.musics.length; i++) {
            this.musics[i].id = null;
        }

        this.effects = [];
    }

    public static pauseAll(): void {
        cc.audioEngine.pauseAll();
    }

    public static setResumeEnabled(enabled: boolean): void {
        this.resumeEnabled = enabled;
    }

    public static resumeAll(): void {
        if (!this.resumeEnabled) {
            return;
        }

        cc.audioEngine.resumeAll();
    }

    public static uncacheAll(): void {
        this.stopAll();
        cc.audioEngine.uncacheAll();
    }

    /**
     * 清理音效
     * @param audio
     */
    private static clearAudio(audio: IAudio) {
        audio.id = null;
        audio.isStop = true;
        audio.stop = () => {};
    }
}

we.core.audioMgr = AudioManager;
