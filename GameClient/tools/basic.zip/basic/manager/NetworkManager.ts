import { SysLanguage } from '../config/SysLanguage';

declare global {
    interface ICore {
        networkMgr: typeof NetworkManager;
    }
}

/** 网络状态  */
enum NetworkState {
    /** 未连接 */
    OFFLINE = 0,
    /** 已连接 */
    ONLINE = 1,
}

const _defaultAvailableHandler = () => {
    const option: we.ui.type.CircleLoadingInfo = {
        text: we.core.langMgr.getLangText(SysLanguage?.TIPS_NET_DISCONNECT),
        debug: 'NetworkManager _defaultAvailableHandler',
    };
    we.commonUI.showCircleLoading(option);
};

export default class NetworkManager {
    /** 网络状态  */
    private static networkState: NetworkState;
    /** 自定义断网提示 */
    private static availableHandler = null;

    public static init(): void {
        this.networkState = we.core.nativeUtil.getNetworkState();
        this.availableHandler = _defaultAvailableHandler.bind(this);

        if (cc.sys.isBrowser) {
            window.removeEventListener('online', this.onWindowOnline);
            window.removeEventListener('offline', this.onWindowOffline);

            window.addEventListener('online', this.onWindowOnline);
            window.addEventListener('offline', this.onWindowOffline);
        }

        cc.director.off(we.core.EventName.NETWORK_STATE_CHANGED, this.onNetworkStateChanged, this);
        cc.director.on(we.core.EventName.NETWORK_STATE_CHANGED, this.onNetworkStateChanged, this);

        setTimeout(() => {
            // 延迟时间用于加载多语言
            if (!this.isNetworkAvailable()) {
                this.availableHandler();
            }
        }, 1000);
    }

    /**
     * 设自定义置断网提示
     * @param handler 提示函数
     * @param target 绑定对象，绑定对象为组件，当组件销毁时会自动回复成默认提示
     */
    public static setAvailableHandler<T extends cc.Component>(handler: () => void, target: T) {
        const onDestroy = target['onDestroy'];
        target['onDestroy'] = () => {
            if (onDestroy) {
                onDestroy.bind(target)();
            }
            this.availableHandler = _defaultAvailableHandler.bind(this);
        };

        const custom = () => {
            handler.bind(target)();
        };

        // 启用自定义提示
        this.availableHandler = custom.bind(this);
    }

    /**
     * 网络是否可用
     */
    public static isNetworkAvailable(): boolean {
        return this.networkState == NetworkState.ONLINE ? true : false;
    }

    /**
     * 刷新网络状态
     */
    public static flushNetworkState(): void {
        this.onNetworkStateChanged(we.core.nativeUtil.getNetworkState());
    }

    /**
     * h5 网络在线
     * @param event
     */
    private static onWindowOnline(event: Event) {
        we.log(`NetworkManager onWindowOnline, event.type: ${event.type}`);
        cc.director.emit(we.core.EventName.NETWORK_STATE_CHANGED, NetworkState.ONLINE);
    }

    /**
     * h5 网络离线
     * @param event
     */
    private static onWindowOffline(event: Event) {
        we.log(`NetworkManager onWindowOffline, event.type: ${event.type}`);
        cc.director.emit(we.core.EventName.NETWORK_STATE_CHANGED, NetworkState.OFFLINE);
    }

    /**
     * 网络状态改变
     * @param netWorkState
     */
    private static onNetworkStateChanged(netWorkState: number) {
        we.log(`NetworkManager onNetworkStateChanged, netWorkState: ${netWorkState}`);

        if (this.networkState === netWorkState) {
            return;
        }

        this.networkState = netWorkState;

        if (this.isNetworkAvailable()) {
            we.commonUI.hideCircleLoading();

            cc.director.emit(we.core.EventName.NETWORK_ONLINE);
        } else {
            this.availableHandler();
            cc.director.emit(we.core.EventName.NETWORK_OFFLINE);
        }
    }
}

we.core.networkMgr = NetworkManager;
