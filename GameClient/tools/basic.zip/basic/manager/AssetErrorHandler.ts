import { GameConfig } from '../config/GameConfig';
import { SysLanguage } from '../config/SysLanguage';
import BasicEventName from '../const/BasicEventName';
import { ClientError } from '../module/error/ClientError';
import { Func } from '../module/func/Func';
import { UICommon } from '../ui/item/UICommon';
import AssetManager from './AssetManager';
import HotUpdateManager from './HotUpdateManager';
import LangManager from './LangManager';

declare global {
    interface ICore {
        AssetErrorHandler: typeof AssetErrorHandler;
    }
}

export class AssetErrorHandler {
    /**
     * 模块加载错误处理
     * # ⚠️ 加载任务是并发的,可能会触发多次异常, 确保只处理一次错误
     * @param module
     * @param err
     * @param onComplete
     */
    public static onLoadModuleError(gameId: we.GameId, bundleName: string, err: ClientError, onComplete?: (success?: boolean) => void): Error {
        const errMsg = `${err.detail}, err: ${JSON.stringify(err?.message || err)}`;
        we.error(errMsg);

        if (bundleName == we.bundles.launcher) {
            // launcher 加载失败时弹不了框, 直接重启
            if (cc.sys.isNative) {
                // native launcher 加载失败时认为热更缓存目录资源已被写脏, 移除缓存后杀掉进程手动重启
                HotUpdateManager.removeBundleCache(bundleName);
                cc.game.end();
            } else {
                // h5 launcher 加载失败自动重启
                cc.game.restart();
            }
        } else {
            UICommon.showConfirm({
                content: `${LangManager.getLangText(SysLanguage.LOAD_STATUS_LOCAL_FAIL)}: ${err.code}.${gameId ?? bundleName}`,
                isHideCloseBtn: true,
                yesHandler: Func.create(() => {
                    AssetManager.removeModule(bundleName);
                    if (GameConfig.isSubGame(gameId)) {
                        we.event<we.core.EventMsg>().emit('LaunchScene', we.GameId.HALL);
                    } else if (gameId == we.GameId.HALL) {
                        cc.game.restart();
                    }
                }),
            });
        }

        cc.director.emit(BasicEventName.LOAD_VIRTUAL_PROGRESS_END);
        onComplete?.(false);

        throw new Error(errMsg);
    }
}

we.core.AssetErrorHandler = AssetErrorHandler;
