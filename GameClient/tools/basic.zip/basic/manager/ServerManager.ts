import { BrowserParamKey } from '../config/ToolsConfig';
import Flavor from '../flavor/Flavor';
import StorageUtil from '../module/storage/StorageUtil';
import Utils from '../utils/Utils';
import { UserStatusInfo } from '../model/UserStatusInfo';

declare global {
    interface ICore {
        serverMgr: typeof ServerManager;
    }
}

export default class ServerManager {
    /** 域名列表 */
    private static domains: string[] = [];
    /** 域名切换记录 */
    private static domainSwitchRecord: string[] = [];
    /** 携带 pf 参数 */
    private static get hasParamPF(): boolean {
        // 会修改 国家/环境 的参数都会影响到域名
        if (Utils.getLocationUrlParam(BrowserParamKey.pf)) {
            return true;
        }
        if (CC_DEV) {
            if (Utils.getLocationUrlParam(BrowserParamKey.ctry) || Utils.getLocationUrlParam(BrowserParamKey.env)) {
                return true;
            }
        }
        return false;
    }

    public static init(): void {
        let presetDomains = Flavor.getDomains();
        let localDomains = StorageUtil.readDomainList();
        localDomains = localDomains.concat(presetDomains);
        localDomains = this.filterDomains(localDomains);

        if (!this.hasParamPF) {
            we.kit.storage.setById('sys', 'app_domain_list', localDomains);
        } else {
            // 携带 pf 参数时使用预埋域名并清空缓存
            localDomains = presetDomains;
            we.kit.storage.setById('sys', 'app_domain_list', []);
        }

        this.domains = localDomains;
    }

    /**
     * 更新域名
     * - 可用域名列表包含 当前连接域名 + 远程下发域名 + 当前版本预埋域名
     * - 废弃预埋域名时不需要特殊处理废弃域名，更新机制会自动清理
     * @param domains
     * @returns
     */
    public static updateDomains(domains: string[]): void {
        if (!(domains instanceof Array)) {
            // 数组长度为 0 时也需要继续执行, 可能预埋域名有更新需要更新缓存
            return;
        }

        // 差量更新，当前域名加到最前，预埋域名补到最后
        let presetDomains = Flavor.getDomains();
        let remoteDomains = [].concat(domains);
        remoteDomains.unshift(this.getDomain());
        remoteDomains = remoteDomains.concat(presetDomains);
        remoteDomains = this.filterDomains(remoteDomains);
        this.domains = remoteDomains;

        if (!this.hasParamPF) {
            we.kit.storage.setById('sys', 'app_domain_list', this.domains);
        }
    }

    /**
     * 切换域名
     * @param url
     * @returns
     */
    public static switchDomain(url: string): boolean {
        we.warn(`ServerManager switchDomain, url: ${url}`, we.noup);

        for (let i = 0; i < this.domainSwitchRecord.length; i++) {
            if (url?.includes(this.domainSwitchRecord[i])) {
                return false;
            }
        }

        let currentDomain = this.getDomain();

        // 并发限制
        this.domainSwitchRecord.push(currentDomain);
        if (this.domainSwitchRecord.length >= this.domains.length) {
            this.domainSwitchRecord = [];
        }

        // 当前域名移到最后
        this.domains.push(currentDomain);
        this.domains.shift();

        if (!this.hasParamPF) {
            we.kit.storage.setById('sys', 'app_domain_list', this.domains);
        }

        return true;
    }

    /**
     * 获取域名数量
     * @returns
     */
    public static getDomainCount(): number {
        return this.domains.length;
    }

    /**
     * maintain server
     * @returns
     */
    public static getMaintainHost(): string {
        let protocol = 'https';
        let subdomain = 'api';
        let path = 'maintain';
        let url = `${protocol}://${subdomain}.${this.getDomain()}/${path}`;

        // 调试
        let svum = Utils.getLocationUrlParam(BrowserParamKey.svum);
        if (svum) {
            url = svum;
        }
        return url;
    }

    /**
     * track server
     * @returns
     */
    public static getTrackHost(): string {
        let protocol = 'https';
        let subdomain = 'track';
        let path = 'track';
        let url = `${protocol}://${subdomain}.${this.getDomain()}/${path}`;

        // 调试
        let svut = Utils.getLocationUrlParam(BrowserParamKey.svut);
        if (svut) {
            url = svut;
        }
        return url;
    }

    /**
     * 大厅服
     * @returns
     */
    public static getHallHost(): string {
        let protocol = 'https';
        let subdomain = 'api';
        let path = 'hall';
        let url = `${protocol}://${subdomain}.${this.getDomain()}/${path}`;

        // 调试
        let svuh = Utils.getLocationUrlParam(BrowserParamKey.svuh);
        if (svuh) {
            url = svuh;
        }
        return url;
    }

    /**
     * 游戏 http
     * @param gameId
     * @returns
     */
    public static getGameHttp(gameId: number): string {
        // 目前游戏没有使用 http 服务
        return '';
    }

    /**
     * naming ws
     * @returns
     */
    public static getNamingWs(): string {
        let protocol = 'wss';
        let subdomain = 'api';
        let path = 'naming/v2/ws/login';
        let url = `${protocol}://${subdomain}.${this.getDomain()}/${path}`;

        // 调试
        let svun = Utils.getLocationUrlParam(BrowserParamKey.svun);
        if (svun) {
            url = svun;
        }

        if (UserStatusInfo.tokenV2) {
            url += `?token=${UserStatusInfo.tokenV2}`;
        } else {
            url = '';
            we.warn(`ServerManager getNamingWs, tokenV2 err`);
        }

        return url;
    }

    /**
     * 获取当前域名
     * @returns
     */
    private static getDomain(): string {
        return this.domains[0];
    }

    /**
     * 过滤域名
     * @param domains
     * @returns
     */
    private static filterDomains(domains: string[]): string[] {
        if (!(domains instanceof Array)) {
            return [];
        }

        // 校验
        domains = domains.filter((value) => {
            if (/[\w-]+(\.[\w-]+){1,3}/.test(value)) {
                return true;
            }
        });

        // 去重
        domains = domains.filter((value, index) => {
            if (domains.indexOf(value) == index) {
                return true;
            }
        });

        return domains;
    }
}

we.core.serverMgr = ServerManager;
