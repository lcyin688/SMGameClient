import StorageUtil, { StorageKey } from '../module/storage/StorageUtil';
import { StorageRW } from '../module/storage/StorageRW';
import NativeUtil from '../platform/NativeUtil';
import { BrowserParamKey } from '../config/ToolsConfig';
import Utils from '../utils/Utils';
import ServerManager from '../manager/ServerManager';
import TrackConfig from '../config/TrackConfig';
import BasicEventName from '../const/BasicEventName';

declare global {
    interface ICore {
        trackMgr: typeof TrackManager;
    }
}

export const TrackApi = {
    upData: {
        trackUp: '/upData/trackUp',
        logUp: '/upData/logUp',
        payAuthUp: '/upData/payAuthUp',
        clickTimeUp: '/upData/clickTimeUp',
        gameFeedbackUp: '/upData/gameFeedbackUp',
    },
};

export default class TrackManager {
    private static retryCountInstall: number = 0;

    private static adjustAppTokens: string[] = [];

    /** 是否客户端上报 充值相关数据 */
    public static isClientReport: boolean = false;

    public static init(): void {
        this.retryCountInstall = 0;
        this.adjustAppTokens = [];

        TrackConfig.init();

        this.initAdjustWeb();
        this.trackInstall();
        this.trackGameUpdated();

        cc.director.off(BasicEventName.NETWORK_ONLINE, this.onNetworkOnline, this);
        cc.director.off(BasicEventName.GAME_SHOW, this.onGameShow, this);

        cc.director.on(BasicEventName.NETWORK_ONLINE, this.onNetworkOnline, this);
        cc.director.on(BasicEventName.GAME_SHOW, this.onGameShow, this);
    }

    /**
     * adjust web
     * @param appToken
     */
    private static initAdjustWeb(appToken?: string): void {
        if (!window.Adjust) {
            return;
        }

        let adjid = Utils.getLocationUrlParam(BrowserParamKey.adjid);
        appToken = appToken || adjid;
        if (!appToken) {
            return;
        }

        // 初始化去重
        if (this.adjustAppTokens.includes(appToken)) {
            return;
        }
        this.adjustAppTokens.push(appToken);

        let config: Adjust.InitOptions = {
            appToken: appToken,
            environment: 'production',
        };

        let adjdt = Utils.getLocationUrlParam(BrowserParamKey.adjdt);
        if (adjdt) {
            config.defaultTracker = adjdt;
        }

        let adjlog = Utils.getLocationUrlParam(BrowserParamKey.adjlog);
        if (adjlog) {
            config.logLevel = 'verbose';
        }

        let adjenv = Utils.getLocationUrlParam(BrowserParamKey.adjenv);
        if (adjenv) {
            config.environment = 'sandbox';
        }

        Adjust.initSdk(config);

        let adjrf = Utils.getLocationUrlParam(BrowserParamKey.adjust_referrer);
        if (adjrf) {
            Adjust.setReferrer(encodeURIComponent(adjrf));
        }
    }

    /**
     * 更新Adjust配置
     * @param adjustConf
     * @returns
     */
    public static updateAdjCfg(adjustConf: any): void {
        if (!adjustConf) {
            return;
        }

        let getTokenFun = (eventName: string, data: any) => {
            let token = '';
            if (!data || data.length < 1) {
                return token;
            }

            for (let i = 0; i < data.length; i++) {
                if (data[i].eventName == eventName) {
                    token = data[i].eventToken;
                    break;
                }
            }

            return token;
        };

        let isUpdate = false;
        let localAdjCfg = StorageUtil.readAdjustConfig();
        let caheEventList = localAdjCfg?.eventList || [];
        let eventList = adjustConf.eventList || [];
        if (caheEventList.length == eventList.length) {
            for (let i = 0; i < eventList.length; i++) {
                if (getTokenFun(eventList[i].eventName, caheEventList) != eventList[i].eventToken) {
                    isUpdate = true;
                    break;
                }
            }
        } else {
            isUpdate = true;
        }

        // this.initAdjustWeb(adjustConf.appToken);

        if (isUpdate) {
            we.kit.storage.setById('sys', 'app_adjust_config', adjustConf);
            TrackConfig.updateAdjCfg(adjustConf);
            this.trackGameUpdated();
        }

        this.isClientReport = !!adjustConf.isClientReport;
    }

    /**
     * 安装跟踪
     */
    private static trackInstall(): void {
        // 自推广安装暂时没用屏蔽
        return;

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_IOS) {
                return;
            }
        }

        let referrer: string = we.kit.storage.get('sys', 'app_install_referrer');
        if (referrer && typeof referrer == 'string') {
            we.kit.storage.setById('sys', 'app_install_referrer', referrer);
            return;
        }

        let retry = (tag: string) => {
            we.warn(`TrackManager trackInstall, retry, tag: ${tag}, count: ${this.retryCountInstall}`);

            if (this.retryCountInstall >= 5) {
                return;
            }

            this.retryCountInstall++;
            this.trackInstall();
        };

        referrer = NativeUtil.getInstallReferrer();
        if (!(referrer && typeof referrer == 'string')) {
            setTimeout(() => {
                retry('uninit');
            }, 1000);
            return;
        }

        if (referrer == 'null') {
            return;
        }

        if (referrer.startsWith('code:')) {
            we.warn(`TrackManager trackInstall, code err, referrer: ${referrer}`);
            return;
        }

        let referrerObj = {};
        let referrers = referrer.split('&');
        for (let i = 0; i < referrers.length; i++) {
            let kvs = referrers[i].split('=');
            if (kvs && kvs.length == 2) {
                referrerObj[kvs[0]] = kvs[1];
            }
        }

        let utm_source: string = referrerObj['utm_source'];
        if (utm_source != 'custom') {
            return;
        }

        let utm_medium: string = referrerObj['utm_medium'];
        if (!(typeof utm_medium == 'string' && utm_medium.length > 0)) {
            we.warn(`TrackManager trackInstall, utm_medium err, referrer: ${referrer}`);
            utm_medium = 'null';
        }

        let utm_campaign: string = referrerObj['utm_campaign'];
        if (!(typeof utm_campaign == 'string' && utm_campaign.length > 0)) {
            we.warn(`TrackManager trackInstall, utm_campaign err, referrer: ${referrer}`);
            utm_campaign = 'null';
        }

        let aid = NativeUtil.getDeviceId();
        let adid = NativeUtil.getAdjustId();
        let app_channel = NativeUtil.getChannel();
        let activity_kind = 'install';

        let url = Utils.joinUrl(ServerManager.getTrackHost(), TrackApi.upData.trackUp);
        if (!url) {
            we.warn(`TrackManager trackInstall, url err`);
            return;
        }

        let params = [
            `aid=${aid}`,
            `adid=${adid}`,
            `app_channel=${app_channel}`,
            `activity_kind=${activity_kind}`,
            `referrer=${encodeURIComponent(referrer)}`,
            `source=${utm_source}`,
            `network_name=${utm_medium}`,
            `campaign_name=${utm_campaign}`,
        ];

        for (let i = 0; i < params.length; i++) {
            url = url + (i == 0 ? '?' : '&') + params[i];
        }

        we.log(`TrackManager trackInstall, params: ${JSON.stringify(params)}`);

        let xhr = new XMLHttpRequest();
        xhr.responseType = 'text';
        xhr.timeout = 10000;
        xhr.onload = () => {
            let msg = `TrackManager trackInstall, onload, status: ${xhr.status}`;
            if (xhr.status == 200) {
                we.log(msg);
                we.kit.storage.setById('sys', 'app_install_referrer', referrer);
            } else {
                we.warn(msg);
            }
        };
        xhr.ontimeout = () => {
            retry('ontimeout');
        };
        xhr.onerror = () => {
            retry('onerror');
        };
        xhr.open('GET', url, true);
        xhr.send();
    }

    private static onNetworkOnline(): void {
        this.trackInstall();
    }

    private static onGameShow(): void {
        this.trackInstall();
    }

    /**
     * 事件跟踪
     * @param eventToken
     * @param cbParams 回传参数, { k1: 'v1', k2: 'v2' }
     * @param revenues 收入信息, { revenue: '0.99', currency: 'USD' }
     */
    public static trackEvent(eventToken: string, cbParams?: object, revenues?: { revenue: string; currency: string }): void {
        if (!(typeof eventToken == 'string' && eventToken.length > 0)) {
            return;
        }

        cbParams = cbParams || {};
        cbParams['aid'] = NativeUtil.getDeviceId();
        cbParams['chn'] = NativeUtil.getChannel();
        cbParams['user_id'] = StorageUtil.readUserId() + '';

        let nativeSdk = NativeUtil.trackEvent(eventToken, cbParams, revenues);

        // adjust web sdk
        if (!nativeSdk && window.Adjust && this.adjustAppTokens.length > 0) {
            let eventParams = {
                eventToken: eventToken,
                callbackParams: [],
            } as Adjust.EventParams;

            for (const key in cbParams) {
                eventParams.callbackParams.push({
                    key: key,
                    value: cbParams[key],
                });
            }

            if (revenues) {
                eventParams.revenue = Number(revenues.revenue);
                eventParams.currency = revenues.currency;
            }

            Adjust.trackEvent(eventParams);
        }
    }

    /**
     * 游戏热更
     */
    private static trackGameUpdated(): void {
        let updatedObj = we.kit.storage.get('sys', 'app_track_game_updated') || {};
        let value: string = updatedObj[`track_vest_${TrackConfig.game.updated}`] || StorageRW.get(StorageKey.TRACK_GAME_UPDATED + `_${TrackConfig.game.updated}`);
        updatedObj[`track_vest_${TrackConfig.game.updated}`] = '1';
        if (value == '1') {
            // 适配 热更: vest 首次启动, 更新缓存状态至 sys table
            we.kit.storage.setById('sys', 'app_track_game_updated', updatedObj);
            return;
        }

        this.trackEvent(TrackConfig.game.updated);
        this.trackEventEx(TrackConfig.game.updatedEx);
        we.kit.storage.setById('sys', 'app_track_game_updated', updatedObj);
    }

    /**
     * 事件跟踪
     * @param event
     * @param data 上报数据 {currency: "USD", value: 30.00}
     */
    public static trackEventEx(event: Object, data?: { currency?: string; value?: number }): void {
        if (!(typeof event == 'object')) {
            return;
        }

        we.log(`TrackManager trackEventEx, event: ${JSON.stringify(event)}`);

        let eventFirebase: string = event['firebase'];
        if (eventFirebase) {
            NativeUtil.trackEventFirebase(eventFirebase);
        }

        const eventAppsflyer = event['appsflyer'];
        if (eventAppsflyer) {
            we.log(`TrackManager trackEventAppsFlyer, af: ${JSON.stringify(eventAppsflyer)}`);
            const eventValues = data ? { af_currency: data.currency, af_revenue: data.value } : {};
            NativeUtil.trackAppsFlyerEvent(eventAppsflyer, eventValues);
        }

        // window['fbq'] = (...data: any[]) => {
        //     we.log(`pixel fbq(${JSON.stringify(data)})`);
        // };
        // window['ttq'] = {
        //     track: (...data: any[]) => {
        //         we.log(`pixel ttq.track(${JSON.stringify(data)})`);
        //     },
        // };
        // window['kwaiq'] = {
        //     instance: () => {
        //         return {
        //             track: (...data: any[]) => {
        //                 we.log(`pixel kwaiq.instance.track(${JSON.stringify(data)})`);
        //             },
        //         };
        //     },
        // };

        // fbpx
        let fbq = window['fbq'];
        if (fbq) {
            let eventConf: string = event['fbq'];
            if (eventConf) {
                let eventType = 'track';
                let eventName = eventConf;
                let eventNames = eventConf.split('.');
                if (eventNames && eventNames[0] === 'custom' && eventNames[1]) {
                    eventType = 'trackCustom';
                    eventName = eventNames[1];
                }
                fbq(eventType, eventName, data);
            }
        }

        // ttpx
        let ttq = window['ttq'];
        if (ttq) {
            let eventConf: string = event['ttq'];
            if (eventConf) {
                let eventName = eventConf;
                let eventNames = eventConf.split('.');
                if (eventNames && eventNames[0] === 'custom' && eventNames[1]) {
                    eventName = eventNames[1];
                }
                ttq.track(eventName, data);
            }
        }

        // kwpx
        let kwaiq = window['kwaiq'];
        if (kwaiq) {
            let eventConf: string = event['kwaiq'];
            if (eventConf) {
                let eventName = eventConf;
                let eventNames = eventConf.split('.');
                if (eventNames && eventNames[0] === 'custom' && eventNames[1]) {
                    eventName = eventNames[1];
                }
                let kwpxid = Utils.getLocationUrlParam(BrowserParamKey.kwpxid);
                kwaiq.instance(kwpxid).track(eventName, data);
            }
        }
    }

    /**
     * 获取追踪上报数据
     * @returns
     */
    public static getTrackReportData(): api.TrackReportData {
        let data: api.TrackReportData = {} as api.TrackReportData;

        if (cc.sys.isBrowser) {
            data.referId = Utils.getLocationUrlParam(BrowserParamKey.referid);
            data.adjustWebUuid = window.Adjust?.getWebUUID() || '';

            // PWA 模式新用户需要收集广告信息上报服务器
            if (we.isH5PWA) {
                let userId = we.kit.storageUtil.readUserId();
                let adjrf = Utils.getLocationUrlParam(BrowserParamKey.adjust_referrer);
                // userId == -1 表示设备没有用户
                // h5 游戏目前仅在 PWA 模式下才会透传 adjust_referrer，可用于唯一标识判定
                if (adjrf && userId == -1) {
                    we.kit.storage.setById('sys', 'app_adjust_campaign_tag', true);
                }
            }
        }

        let payload = NativeUtil.getPayload();
        try {
            payload = JSON.parse(payload);
            if (typeof payload == 'object') {
                // @ts-ignore
                data.referId = payload['referId'] || '';
            }
        } catch (error) {}

        return data;
    }

    /**
     * 获取 adjust web 归因信息中 campaign 数据
     * @returns
     */
    public static getAdjustCampaign(): string {
        let campaign = '';
        if (!we.isH5PWA || !window.Adjust) {
            return campaign;
        }

        let appAdjustCampaignTag = we.kit.storage.get('sys', 'app_adjust_campaign_tag');
        if (!appAdjustCampaignTag) {
            return campaign;
        }

        let attribution = Adjust.getAttribution();
        campaign = attribution?.campaign || '';

        return campaign;
    }
}

we.core.trackMgr = TrackManager;
