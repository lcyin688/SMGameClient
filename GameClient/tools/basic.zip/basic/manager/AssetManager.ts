import { BundleNames, CommonBundles, LobbyBundles, GameConfig } from '../config/GameConfig';
import { LOAD_TYPE } from '../config/ProjectConfig';
import { SysLanguage } from '../config/SysLanguage';
import BasicEventName from '../const/BasicEventName';
import Flavor from '../flavor/Flavor';
import { CountryCode } from '../flavor/FlavorConf';
import TrackManager from '../manager/TrackManager';
import LangManager from './LangManager';
import HotUpdateManager from './HotUpdateManager';
import TrackConfig from '../config/TrackConfig';
import { Func } from '../module/func/Func';
import { Entity } from '../module/entity/Entity';
import { UICommon } from '../ui/item/UICommon';
import { CancelAction } from '../module/async/CancelAction';
import Utils from '../utils/Utils';
import { ClientError, ClientErrorType } from '../module/error/ClientError';

declare global {
    interface ICore {
        assetMgr: typeof AssetManager;
    }
}

/**
 * 错误码
 */
enum ErrorCode {
    /** 加载 bundles 错误 */
    LoadBundlesError = 220,
    /** 加载分组超时 */
    LoadGroupTimeout = 221,
    /** 加载分组错误 */
    LoadGroupError = 222,
    /** 加载多语言错误 */
    LoadLangError = 223,
}

/**
 * 加载超时处理
 */
interface ILoad {
    /** 超时时间 s */
    timeout: number;
    /** 加载百分比 */
    percent: number;

    /** 加载超时 */
    timerTimeoutLoad: any;
    /** 是否延迟加载超时 */
    delayTimeoutLoad: boolean;
    /** 取消 timeout 计时器回调 */
    clearTimeoutLoad: () => void;
    /** 加载超时回调 */
    onTimeoutLoad: () => void;
}

/**
 * 资源加载生命周期处理器
 * 使用回调时, 生命周期为 Func 绑定的 target
 * 使用异步时, 生命周期为传入的 target
 * TODO (asset: T) => void 统一后废弃, 避免存在生命周期限制的回调
 */
type AssetLifecycleHandler<T> = (asset: T) => void | Func<(asset: T) => void> | cc.Node | cc.Component | Entity;

export default class AssetManager {
    /**
     * loadModule v2版本是否发布
     * 兼容子游戏发布，待大厅和子游戏所有环境更新完后续删除
     */
    public static readonly LOADMODULEV2 = true;

    /**
     * 加载 bundle 模块
     * @param bundleName bundle 名称
     * @param group 资源组名
     * @param onComplete 加载完成回调
     */
    public static async loadModule(
        bundleName: string,
        group: 'sta' | 'entry',
        onError: Func<(gameId: we.GameId, bundleName: string, err: ClientError, onComplete?: (success?: boolean) => void) => Error>,
        onComplete?: (success?: boolean) => void
    ): Promise<void> {
        if (!(bundleName && typeof bundleName == 'string')) {
            const errMsg = `AssetManager loadModule, params err, bundleName: ${bundleName}`;
            we.warn(errMsg);
            onComplete?.(false);
            throw new Error(errMsg);
        }

        // 记录加载开始时间
        const startTime = Date.now();

        // 处理进度
        if (bundleName != BundleNames.launcher) {
            // 系统多语言在 launcher
            cc.director.emit(BasicEventName.LOAD_STATUS, LangManager.getLangText(SysLanguage.LOAD_STATUS_LOCAL_ING));
        }
        cc.director.emit(BasicEventName.LOAD_PROGRESS_ACTIVE, true);
        cc.director.emit(BasicEventName.LOAD_PROGRESS, { percent: 0, loadType: LOAD_TYPE.LOAD, bundleName: bundleName });

        // 加载 bundles
        const bundles = await this.loadBundles(bundleName).catch((err: Error) => {
            return onError.execOnce(bundleName, new ClientError(err, { code: ErrorCode.LoadBundlesError, detail: `AssetManager loadModule, loadBundles, bundleName: ${bundleName}` }), onComplete);
        });

        // 加载分组超时处理
        const load = {} as ILoad;
        load.timeout = 30;
        load.percent = 0;
        load.timerTimeoutLoad = null;
        load.clearTimeoutLoad = () => {
            if (load.timerTimeoutLoad != null) {
                clearTimeout(load.timerTimeoutLoad);
                load.timerTimeoutLoad = null;
            }
        };

        load.onTimeoutLoad = () => {
            load.timerTimeoutLoad = null;
            onError.execOnce(bundleName, new ClientError({ code: ErrorCode.LoadGroupTimeout, detail: `AssetManager loadModule, onTimeoutLoad, bundleName: ${bundleName}, percent: ${load.percent}` }), onComplete);
        };

        // 加载分组资源
        const loadGroup = (bundle: cc.AssetManager.Bundle): Promise<void> => {
            return new Promise((resolve, reject) => {
                const path = this.getRelativePath(`${bundle.name}/${group}`);
                bundle.loadDir(
                    path,
                    (finish: number, total: number, item: cc.AssetManager.RequestItem) => {
                        if (bundle.name !== bundleName) {
                            // 加载进度只处理当前模块 group, 这是加载耗时最多的部分
                            return;
                        }

                        let percent = finish / total;
                        if (isNaN(percent) || percent < 0) {
                            percent = 0;
                        } else if (percent > 1) {
                            percent = 1;
                        }

                        load.percent = percent;
                        cc.director.emit(BasicEventName.LOAD_PROGRESS, { percent: percent, loadType: LOAD_TYPE.LOAD, bundleName: bundleName });

                        // 进度更新时重置超时计时器
                        load.clearTimeoutLoad();
                        if (percent < 1) {
                            load.timerTimeoutLoad = setTimeout(load.onTimeoutLoad, load.timeout * 1000);
                        }
                    },
                    (err: Error, assets: cc.Asset[]) => {
                        if (bundle.name === bundleName) {
                            load.clearTimeoutLoad();
                        }
                        err ? reject(err) : resolve();
                    }
                );
            });
        };

        // 执行加载任务
        const loadTasks: Promise<void>[] = [];
        for (const bundle of bundles) {
            loadTasks.push(
                // 分组资源
                loadGroup(bundle).catch((err: Error) => {
                    return onError.execOnce(bundleName, new ClientError(err, { code: ErrorCode.LoadGroupError, detail: `AssetManager loadModule, loadGroup, bundle: ${bundle.name}` }), onComplete);
                })
            );

            loadTasks.push(
                // 多语言
                LangManager.loadModule(bundle.name).catch((err: Error) => {
                    return onError.execOnce(bundleName, new ClientError(err, { code: ErrorCode.LoadLangError, detail: `AssetManager loadModule, LangManager.loadModule, bundle: ${bundle.name}` }), onComplete);
                })
            );
        }

        await Promise.all(loadTasks);

        // 全部加载成功
        onComplete?.(true);
        cc.director.emit(BasicEventName.LOAD_PROGRESS, { percent: 1, loadType: LOAD_TYPE.LOAD, bundleName: bundleName });

        // TODO 加载信息上报
        // if (!cc.assetManager.getBundle(bundleName)) {
        //     const loadTime = Date.now() - startTime;
        //     // TODO 这个上报，game_id 无法拿到三方api游戏gameId
        //     TrackManager.trackEvent(TrackConfig.game.customdata, {
        //         game_id: GameConfig.toGameId(bundleName) ?? 0,
        //         load_type: LOAD_TYPE.LOAD,
        //         load_time: loadTime,
        //     });
        // }
    }

    /**
     * 加载公共分包
     * - 公共分包无场景, 可以直接加载使用
     * @param bundleName bundle 名称
     */
    public static loadCommonBundle(bundleName: string): Promise<cc.AssetManager.Bundle> {
        return this.loadBundle(bundleName).catch((err: Error) => {
            we.error(`AssetManager loadCommonBundle, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`);
            throw err;
        });
    }

    /**
     * 加载资源
     * - 回调模式返回 handler(asset | null), 异步模式返回 resolve(asset | null), 是否加载成功业务层判断 asset 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 资源 url
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     * @param loading 加载 prefab 时是否延迟显示 loading, 默认 true
     */
    public static loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: cc.Node | cc.Component | Entity, loading?: boolean): Promise<T | null>;
    public static loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: Func<(asset?: T | null) => void>, loading?: boolean): Promise<T | null>;
    public static loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: (asset?: T | null) => void, loading?: boolean): Promise<T | null>;
    public static loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, ...args: any[]): Promise<T | null> {
        return new Promise<T | null>((resolve) => {
            const handler: AssetLifecycleHandler<T> = args[0] ?? (we.currentScene || we.clientScene);
            const instanceId = handler instanceof Entity ? handler.InstanceId : (we.currentScene || we.clientScene).InstanceId;

            if (!(url && typeof url == 'string' && cc.js.isChildClassOf(<any>type, cc.Asset))) {
                we.warn(`AssetManager loadAsset, params err, url: ${url}`);
                this.processAssetComplete(handler, resolve, null, instanceId);
                return;
            }

            const loading: boolean = args[1] ?? true;
            const bundleName = this.getBundleName(url);
            const path = this.getRelativePath(url);

            // 先去缓存找, 没有再去加载
            const bundle = cc.assetManager.getBundle(bundleName);
            if (bundle) {
                const asset: T = bundle.get(path, <any>type);
                if (cc.isValid(asset)) {
                    this.processAssetComplete(handler, resolve, asset, instanceId);
                    return;
                }
            }

            // 防止触发超时后加载完成多次回调, 统一封装处理
            let finished = false;
            const done = (asset: T) => {
                if (finished) {
                    return;
                }
                finished = true;
                this.processAssetComplete(handler, resolve, asset ?? null, instanceId);
            };

            // 超时处理
            let cancelAction: CancelAction = null;
            const load = {} as ILoad;
            load.timeout = 30;
            load.percent = 0;
            load.timerTimeoutLoad = null;
            load.delayTimeoutLoad = false;
            load.clearTimeoutLoad = () => {
                if (load.timerTimeoutLoad != null) {
                    clearTimeout(load.timerTimeoutLoad);
                    load.timerTimeoutLoad = null;
                }
            };
            load.onTimeoutLoad = () => {
                load.timerTimeoutLoad = null;

                if (load.percent >= 0.8) {
                    // 加载进度超过 80% 时, 加载超时延迟
                    if (!load.delayTimeoutLoad) {
                        load.delayTimeoutLoad = true;
                        load.timerTimeoutLoad = setTimeout(load.onTimeoutLoad, load.timeout * 1000);
                        return;
                    }
                }

                // 超时提示
                if (loading && <any>type == cc.Prefab) {
                    UICommon.showToast(LangManager.getLangText(SysLanguage.TIPS_LOAD_ASSET_TIMEOUT));
                }

                cancelAction?.cancel();
                we.warn(`AssetManager loadAsset, onTimeoutLoad url: ${url} percent: ${load.percent}`);
                done(null);
            };

            // 加载 prefab 时延迟显示 loading
            if (loading && <any>type == cc.Prefab) {
                cancelAction = CancelAction.create();
                cancelAction.add(() => {
                    UICommon.hideCircleLoading();
                });
                // 触发加载超时延迟时 timeout 加倍
                UICommon.showCircleLoading({ cancel: cancelAction, timeout: load.timeout * 2, delay: 1, debug: 'AssetManager loadAsset' });
            }
            load.timerTimeoutLoad = setTimeout(load.onTimeoutLoad, load.timeout * 1000);

            this.loadBundle(bundleName)
                .then((bundle) => {
                    bundle.load(
                        path,
                        <any>type,
                        (finish: number, total: number, item: cc.AssetManager.RequestItem) => {
                            let percent = finish / total;
                            if (typeof percent != 'number' || isNaN(percent) || percent < 0) {
                                percent = 0;
                            } else if (percent > 1) {
                                percent = 1;
                            }

                            if (percent <= load.percent) {
                                return;
                            }

                            load.percent = percent;
                            cc.director.emit(BasicEventName.LOAD_ASSET_PROGRESS, percent);
                        },
                        (err: Error, asset: T) => {
                            load.clearTimeoutLoad();
                            cancelAction?.cancel();

                            if (err) {
                                we.error(`AssetManager loadAsset, load bundleName: ${bundleName} url: ${url}, err: ${JSON.stringify(err.message || err)}`);
                            }
                            done(err ? null : asset);
                        }
                    );
                })
                .catch((err: Error) => {
                    load.clearTimeoutLoad();
                    cancelAction?.cancel();
                    we.error(`AssetManager loadAsset, loadBundle bundleName: ${bundleName} url: ${url}, err: ${JSON.stringify(err.message || err)}`);
                    done(null);
                });
        });
    }

    /**
     * 加载同类型的多个资源
     * - 回调模式返回 handler(assets[] | null), 异步模式返回 resolve(assets[] | null), 是否加载成功业务层判断 assets 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * - assets 和 urls 的顺序一致
     * @param urls 资源 url 数组
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     */
    public static loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, handler?: cc.Node | cc.Component | Entity): Promise<T[] | null>;
    public static loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, handler?: Func<(assets?: T[] | null) => void>): Promise<T[] | null>;
    public static loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, handler?: (assets?: T[] | null) => void): Promise<T[] | null>;
    public static loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, ...args: any[]): Promise<T[] | null> {
        return new Promise<T[] | null>((resolve) => {
            const handler: AssetLifecycleHandler<T> = args[0] ?? (we.currentScene || we.clientScene);
            const instanceId = handler instanceof Entity ? handler.InstanceId : (we.currentScene || we.clientScene).InstanceId;

            if (!(Array.isArray(urls) && urls.length > 0 && cc.js.isChildClassOf(<any>type, cc.Asset))) {
                we.warn(`AssetManager loadAssetArray, params err, urls: ${urls}`);
                this.processAssetComplete(handler, resolve, null, instanceId);
                return;
            }

            const bundleName = this.getBundleName(urls[0]);
            const paths: string[] = [];
            for (let i = 0; i < urls.length; i++) {
                paths[i] = this.getRelativePath(urls[i]);
            }

            // 先去缓存找, 没有再去加载
            const bundle = cc.assetManager.getBundle(bundleName);
            if (bundle) {
                const assets: T[] = [];
                for (let i = 0; i < paths.length; i++) {
                    const asset = bundle.get(paths[i], <any>type);
                    if (cc.isValid(asset)) {
                        assets.push(<T>asset);
                    }
                }

                if (assets.length == paths.length) {
                    this.processAssetComplete(handler, resolve, assets, instanceId);
                    return;
                }
            }

            this.loadBundle(bundleName)
                .then((bundle) => {
                    bundle.load(paths, <any>type, (err: Error, assets: T[]) => {
                        if (err) {
                            we.error(`AssetManager loadAssetArray, load, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`);
                        }
                        this.processAssetComplete(handler, resolve, err ? null : assets, instanceId);
                    });
                })
                .catch((err: Error) => {
                    we.error(`AssetManager loadAssetArray, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`);
                    this.processAssetComplete(handler, resolve, null, instanceId);
                });
        });
    }

    /**
     * 加载目录下所有资源
     * - 回调模式返回 handler(assets[] | null), 异步模式返回 resolve(assets[] | null), 是否加载成功业务层判断 assets 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 目录 url
     * @param handler 资源加载生命周期处理器
     */
    public static loadAssetDir(url: string, handler?: cc.Node | cc.Component | Entity): Promise<cc.Asset[] | null>;
    public static loadAssetDir(url: string, handler?: Func<(assets?: cc.Asset[] | null) => void>): Promise<cc.Asset[] | null>;
    public static loadAssetDir(url: string, handler?: (assets?: cc.Asset[] | null) => void): Promise<cc.Asset[] | null>;
    public static loadAssetDir(url: string, ...args: any[]): Promise<cc.Asset[] | null> {
        return new Promise<cc.Asset[] | null>((resolve) => {
            const handler: AssetLifecycleHandler<cc.Asset> = args[0] ?? (we.currentScene || we.clientScene);
            const instanceId = handler instanceof Entity ? handler.InstanceId : (we.currentScene || we.clientScene).InstanceId;

            if (!(url && typeof url == 'string')) {
                we.warn(`AssetManager loadAssetDir, params err, url: ${url}`);
                this.processAssetComplete(handler, resolve, null, instanceId);
                return;
            }

            const bundleName = this.getBundleName(url);
            const path = this.getRelativePath(url);

            this.loadBundle(bundleName)
                .then((bundle) => {
                    bundle.loadDir(path, (err: Error, assets: cc.Asset[]) => {
                        if (err) {
                            we.error(`AssetManager loadAssetDir, loadDir, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`);
                        }
                        this.processAssetComplete(handler, resolve, err ? null : assets, instanceId);
                    });
                })
                .catch((err: Error) => {
                    we.error(`AssetManager loadAssetDir, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`);
                    this.processAssetComplete(handler, resolve, null, instanceId);
                });
        });
    }

    /**
     * 加载远程资源
     * - 回调模式返回 handler(asset | null), 异步模式返回 resolve(asset | null), 是否加载成功业务层判断 asset 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 远程资源 http url
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     * @param loadingParent 局部 loading 父节点(size > 0)
     * @param extname 资源扩展名 如 .png .txt 等, 优先使用传入值, 为空时从 url 解析
     */
    public static loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: cc.Node | cc.Component | Entity, loadingParent?: cc.Node, extname?: string): Promise<T | null>;
    public static loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: Func<(asset?: T | null) => void>, loadingParent?: cc.Node, extname?: string): Promise<T | null>;
    public static loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: (asset?: T | null) => void, loadingParent?: cc.Node, extname?: string): Promise<T | null>;
    public static loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, ...args: any[]): Promise<T | null> {
        return new Promise<T | null>((resolve) => {
            const handler: AssetLifecycleHandler<T> = args[0] ?? (we.currentScene || we.clientScene);
            const instanceId = handler instanceof Entity ? handler.InstanceId : (we.currentScene || we.clientScene).InstanceId;

            if (!(typeof url == 'string' && url.startsWith('http') && cc.js.isChildClassOf(<any>type, cc.Asset))) {
                we.warn(`AssetManager loadAssetRemote, params err, url: ${url}`);
                this.processAssetComplete(handler, resolve, null, instanceId);
                return;
            }

            const loadingParent: cc.Node = args[1];
            let loading = cc.isValid(loadingParent);
            if (loading) {
                if (loadingParent.width > 0 && loadingParent.height > 0) {
                    UICommon.showCircleLoading({ parent: loadingParent, debug: 'AssetManager loadAssetRemote' });
                } else {
                    loading = false;
                    we.warn(`AssetManager loadAssetRemote, loadingParent err, url: ${url}`);
                }
            }

            const options: Record<string, any> = {};
            let extname: string = args[2];
            if (typeof extname == 'string' && extname.startsWith('.')) {
                options['ext'] = extname;
            } else {
                extname = cc.path.extname(url);
                if (extname) {
                    // 强制转为小写, 兼容 .PNG -> .png .JPG -> .jpg 等情况
                    options['ext'] = extname.toLowerCase();
                }
            }

            cc.assetManager.loadRemote(url, options, (err: Error, asset: cc.Asset) => {
                if (loading) {
                    UICommon.hideCircleLoading(loadingParent);
                }

                if (err) {
                    we.error(`AssetManager loadAssetRemote, loadRemote, url: ${url}, err: ${JSON.stringify(err.message || err)}`);
                    this.processAssetComplete(handler, resolve, null, instanceId);
                    return;
                }

                let assetEx = asset;
                if (assetEx instanceof cc.Texture2D && <any>type == cc.SpriteFrame) {
                    // 图片类型加载成功默认为 Texture2D, 上层使用 SpriteFrame
                    assetEx = new cc.SpriteFrame(assetEx);
                }

                if (!(assetEx instanceof <any>type)) {
                    // 返回类型和传入类型不匹配时返回空
                    assetEx = null;
                    we.error(`AssetManager loadAssetRemote, loadRemote, instanceof, url: ${url}, type: ${type?.['name']}`);
                }

                this.processAssetComplete(handler, resolve, assetEx, instanceId);
            });
        });
    }

    /**
     * 预加载模块 sta
     * @param bundleName bundle 名称
     * @param progress 是否显示进度
     */
    public static preloadModuleSta(bundleName: string, progress: boolean = true): void {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`AssetManager preloadModuleSta, params err, bundleName: ${bundleName}`);
            return;
        }

        if (progress) {
            cc.director.emit(BasicEventName.LOAD_PROGRESS_ACTIVE, true);
        }

        this.loadBundles(bundleName)
            .then((bundles) => {
                for (let i = 0; i < bundles.length; i++) {
                    const bundle = bundles[i];
                    const path = this.getRelativePath(`${bundle.name}/sta`);
                    bundle.preloadDir(
                        path,
                        (finish: number, total: number, item: cc.AssetManager.RequestItem) => {
                            if (progress && bundle.name === bundleName) {
                                // 加载进度只处理当前模块 group, 这是加载耗时最多的部分
                                let percent = finish / total;
                                if (isNaN(percent) || percent < 0) {
                                    percent = 0;
                                } else if (percent > 1) {
                                    percent = 1;
                                }
                                cc.director.emit(BasicEventName.LOAD_PROGRESS, { percent: percent, loadType: LOAD_TYPE.PRELOAD, bundleName: bundleName });
                            }
                        },
                        (err: Error, items: cc.AssetManager.RequestItem[]) => {
                            if (err) {
                                we.warn(`AssetManager preloadModuleSta, preloadDir, bundle: ${bundle.name}, err: ${JSON.stringify(err.message || err)}`);
                            } else {
                                if (progress && bundle.name === bundleName) {
                                    cc.director.emit(BasicEventName.LOAD_PROGRESS, { percent: 1, loadType: LOAD_TYPE.PRELOAD, bundleName: bundleName });
                                }
                            }
                        }
                    );
                }
            })
            .catch((err: Error) => {
                we.warn(`AssetManager preloadModuleSta, loadBundles, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`);
            });
    }

    /**
     * 预加载资源
     * @param url 资源 url
     * @param type 资源类型
     * @param onComplete 预加载完成回调
     */
    public static preloadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, onComplete?: (asset?: T | null) => void): Promise<T> {
        return new Promise((resolve, reject) => {
            if (!(url && typeof url == 'string' && cc.js.isChildClassOf(<any>type, cc.Asset))) {
                const errMsg = `AssetManager preloadAsset, params err, url: ${url}`;
                we.warn(errMsg);
                onComplete?.(null);
                reject(new Error(errMsg));
                return;
            }

            const bundleName = this.getBundleName(url);
            const path = this.getRelativePath(url);

            // 先去缓存找, 没有再去加载
            const bundle = cc.assetManager.getBundle(bundleName);
            if (bundle) {
                const asset = bundle.get(path, <any>type);
                if (cc.isValid(asset)) {
                    onComplete?.(<T>asset);
                    resolve(<T>asset);
                    return;
                }
            }

            this.loadBundle(bundleName)
                .then((bundle) => {
                    bundle.preload(path, <any>type, (err: Error, asset: any) => {
                        if (err) {
                            const errMsg = `AssetManager preloadAsset, preload, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`;
                            we.warn(errMsg);
                            onComplete?.(null);
                            reject(new Error(errMsg));
                        } else {
                            onComplete?.(<T>asset);
                            resolve(<T>asset);
                        }
                    });
                })
                .catch((err) => {
                    const errMsg = `AssetManager preloadAsset, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`;
                    we.warn(errMsg);
                    onComplete?.(null);
                    reject(new Error(errMsg));
                });
        });
    }

    /**
     * 预加载资源队列
     * - assets 和 urls 的顺序一致
     * @param urls 资源 url 数组
     * @param type 资源类型
     * @param onComplete 预加载完成回调
     */
    public static preloadAssetQueue<T extends cc.Asset>(urls: string[], type: { prototype: T }, onComplete?: (assets?: T[] | null) => void): Promise<T[]> {
        return new Promise((resolve, reject) => {
            if (!(Array.isArray(urls) && urls.length > 0 && cc.js.isChildClassOf(<any>type, cc.Asset))) {
                const errMsg = `AssetManager preloadAssetQueue, params err, urls: ${urls}`;
                we.warn(errMsg);
                onComplete?.(null);
                reject(new Error(errMsg));
                return;
            }

            let index = 0;
            const assets: T[] = [];
            const preloadNext = () => {
                // 需要停止预加载的 bundle
                let bundleNameStop = '';
                let onStop = (bundleName: string) => {
                    bundleNameStop = bundleName;
                };
                cc.director.on(BasicEventName.PRELOAD_ASSET_STOP, onStop, this);

                const url = urls[index];
                this.preloadAsset(url, type)
                    .then((asset) => {
                        cc.director.off(BasicEventName.PRELOAD_ASSET_STOP, onStop, this);

                        const bundleName = this.getBundleName(url);
                        const bundle = cc.assetManager.getBundle(bundleName);
                        if (!bundle || bundleName == bundleNameStop) {
                            // 如果分包已经被移除或者收到停止广播就停止预加载队列
                            const errMsg = `AssetManager preloadAssetQueue, bundle stop, url: ${url}`;
                            // 预期情况, 不上报日志
                            // we.warn(errMsg);
                            onComplete?.(null);
                            reject(new Error(errMsg));
                            return;
                        }

                        assets.push(asset);
                        index++;
                        if (index >= urls.length) {
                            // 加载完成
                            onComplete?.(assets);
                            resolve(assets);
                            return;
                        }

                        preloadNext();
                    })
                    .catch((err) => {
                        cc.director.off(BasicEventName.PRELOAD_ASSET_STOP, onStop, this);
                        onComplete?.(null);
                        reject(err);
                    });
            };

            preloadNext();
        });
    }

    /**
     * 获取资源
     * @param url 资源 url
     * @param type 资源类型
     */
    public static getAsset<T extends cc.Asset>(url: string, type: { prototype: T }): T {
        if (!(url && typeof url == 'string' && cc.js.isChildClassOf(<any>type, cc.Asset))) {
            we.warn(`AssetManager getAsset, params err, url: ${url}`);
            return null;
        }

        const bundleName = this.getBundleName(url);
        const bundle = cc.assetManager.getBundle(bundleName);
        if (!bundle) {
            we.warn(`AssetManager getAsset, bundle err, url: ${url}`);
            return null;
        }

        const path = this.getRelativePath(url);
        const asset = <T>bundle.get(path, <any>type);
        if (!cc.isValid(asset)) {
            we.warn(`AssetManager getAsset, asset err, url: ${url}`);
            return null;
        }

        return asset;
    }

    /**
     * 移除资源
     * @param url 资源 url
     * @param type 资源类型
     */
    public static removeAsset(url: string, type?: typeof cc.Asset): void {
        if (!(url && typeof url == 'string')) {
            we.warn(`AssetManager removeAsset, params err, url: ${url}`);
            return;
        }

        const bundleName = this.getBundleName(url);
        const bundle = cc.assetManager.getBundle(bundleName);
        if (!bundle) {
            return;
        }

        const path = this.getRelativePath(url);
        const asset = bundle.get(path, type);
        if (!asset) {
            return;
        }

        this.releaseAsset(asset);
        cc.sys.garbageCollect();
    }

    /**
     * 移除模块
     * @param bundleName bundle 名称
     * @param isSceneBundle 是否场景 bundle
     */
    public static removeModule(bundleName: string, isSceneBundle?: boolean): void {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`AssetManager removeModule, params err, bundleName: ${bundleName}`);
            return;
        }

        if (CommonBundles.includes(bundleName)) {
            return;
        }

        const bundle = cc.assetManager.getBundle(bundleName);
        if (!bundle) {
            return;
        }

        // releaseAll 会释放 internal 依赖资源
        bundle.releaseUnusedAssets();

        if (isSceneBundle) {
            // 场景 bundle 移除, 交给热数据组件处理, 不在这里直接销毁, 避免 bundle 还有未完成的加载, 触发 url undefined 错误
            we.kit.hotCache.set('bundle', bundleName, null);
        } else {
            // 移除 bundle
            cc.assetManager.removeBundle(bundle);
        }

        setTimeout(() => {
            // 延迟执行垃圾回收, 避免大量资源被释放时导致卡顿
            cc.sys.garbageCollect();
        }, 5);
    }

    /**
     * 移除所有资源
     */
    public static clear(): void {
        cc.assetManager.releaseAll();
        cc.sys.garbageCollect();
    }

    /**
     * 通过 uuid 获取 url
     * @param uuid 资源 uuid
     */
    public static getUrlByUuid(uuid: string): string {
        if (!(uuid && typeof uuid == 'string')) {
            we.warn(`AssetManager getUrlByUuid, params err, uuid: ${uuid}`);
            return '';
        }

        const options: Record<string, any> = { bundle: '' };
        cc.assetManager.utils.getUrlWithUuid(uuid, options);

        const info = cc.assetManager.getBundle(options.bundle)?.getAssetInfo(uuid);
        const url = `${options.bundle}/` + info?.path;

        return url;
    }

    /**
     * 获取原生资源路径
     * @param url 资源 url
     */
    public static getAssetNativeUrl(url: string): string {
        if (!(url && typeof url == 'string')) {
            we.warn(`AssetManager getAssetNativeUrl, params err, url: ${url}`);
            return '';
        }

        const bundleName = this.getBundleName(url);
        const bundle = cc.assetManager.getBundle(bundleName);
        if (!bundle) {
            we.warn(`AssetManager getAssetNativeUrl, bundle err, url: ${url}`);
            return '';
        }

        const path = url.split('/').slice(1).join('/');
        const nativeUrl = cc.assetManager['_transform']({
            path: cc.path.changeExtname(path),
            bundle: bundleName,
            __isNative__: true,
            ext: cc.path.extname(url),
        });

        return nativeUrl || '';
    }

    /**
     * 资源是否存在
     * @param url 资源 url
     * @param type 资源类型
     */
    public static isAssetExist(url: string, type?: typeof cc.Asset): boolean {
        if (!(url && typeof url == 'string')) {
            we.warn(`AssetManager isAssetExist, params err, url: ${url}`);
            return false;
        }

        const bundleName = this.getBundleName(url);
        const path = this.getRelativePath(url);
        const info = cc.assetManager.getBundle(bundleName)?.getInfoWithPath?.(path, type);

        return info != null;
    }

    /**
     * 查询资源信息
     * - url 为资源时, 返回该资源信息
     * - url 为目录时, 返回该路径下所有资源信息
     * @param url 查询 url
     */
    public static queryAssetInfos(url: string): Promise<{ urls: Array<Record<string, any>>; bundle: cc.AssetManager.Bundle }> {
        return new Promise((resolve, reject) => {
            if (!(url && typeof url == 'string')) {
                const errMsg = `AssetManager queryAssetInfos, params err, url: ${url}`;
                we.warn(errMsg);
                reject(new Error(errMsg));
                return;
            }

            const bundleName = this.getBundleName(url);
            const path = this.getRelativePath(url);
            this.loadBundle(bundleName)
                .then((bundle) => {
                    const urls = bundle.getDirWithPath(path);
                    resolve({ urls, bundle });
                })
                .catch((err) => {
                    const errMsg = `AssetManager queryAssetInfos, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`;
                    we.warn(errMsg);
                    reject(new Error(errMsg));
                });
        });
    }

    /**
     * 获取包内指定场景信息
     * @param bundleName 包名
     * @param sceneName 场景名
     * @returns 场景信息, 场景不存在时返回 null
     */
    public static async querySceneInfo(bundleName: string, sceneName: string): Promise<{ url: string; uuid: string } | null> {
        return new Promise((resolve, reject) => {
            this.loadBundle(bundleName)
                .then((bundle) => {
                    resolve(bundle.getSceneInfo(sceneName) as { url: string; uuid: string });
                })
                .catch((err) => {
                    const errMsg = `AssetManager querySceneInfo, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`;
                    we.warn(errMsg);
                    reject(new Error(errMsg));
                });
        });
    }

    /**
     * 获取多国家资源路径
     * @param url 多国家资源 url
     */
    public static getCountryAssetUrl(url: string): string {
        if (!(url && typeof url == 'string')) {
            we.warn(`AssetManager getCountryAssetUrl, params err, url: ${url}`);
            return '';
        }

        let ctryUrl = Utils.replacePathSegmentAfter(url, Flavor.getCountryCode(), '/ctryres/');
        if (!this.isAssetExist(ctryUrl)) {
            // 对应国家资源不存在, 使用默认资源
            ctryUrl = Utils.replacePathSegmentAfter(url, CountryCode.id, '/ctryres/');
        }

        return ctryUrl;
    }

    /**
     * 加载多国家图片
     * @param url 多国家资源 url
     * @param handler 资源加载生命周期处理器
     */
    public static loadCountrySprite(url: string, handler?: cc.Node | cc.Component | Entity): Promise<cc.SpriteFrame> {
        if (!(url && typeof url == 'string')) {
            const errMsg = `AssetManager loadCountrySprite, params err, url: ${url}`;
            we.warn(errMsg);
            return Promise.reject(new Error(errMsg));
        }

        const ctryUrl = this.getCountryAssetUrl(url);
        return this.loadAsset(ctryUrl, cc.SpriteFrame, handler, false);
    }

    /**
     * 获取分包名称
     * @param url 资源 url
     */
    private static getBundleName(url: string): string {
        if (!(url && typeof url == 'string')) {
            we.warn(`AssetManager getBundleName, params err, url: ${url}`);
            return '';
        }

        const bundleName = url.split('/')[0];
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`AssetManager getBundleName, bundleName err, url: ${url}`);
            return '';
        }

        return bundleName;
    }

    /**
     * 获取皮肤路径
     * @param bundleName bundle 名称
     */
    private static getSkinPath(bundleName: string): string {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`AssetManager getSkinPath, params err, bundleName: ${bundleName}`);
            return '';
        }

        const skinCode = LobbyBundles.includes(bundleName) ? Flavor.getSkinCode() : 'default';
        const skinPath = `skin/${skinCode}`;

        return skinPath;
    }

    /**
     * 获取相对路径
     * @param url 资源定义路径 bundleName/sta/xxx
     * @returns 完整相对路径 skin/${skinCode}/sta/xxx
     */
    private static getRelativePath(url: string): string {
        if (!(url && typeof url == 'string')) {
            we.warn(`AssetManager getRelativePath, params err, url: ${url}`);
            return '';
        }

        // url 以 bundleName 开头不能带 /
        if (url.startsWith('/')) {
            url = url.slice(1);
            we.warn(`AssetManager getRelativePath, startsWith / err, url: ${url}`);
        }

        /**
         * 1、文件路径结尾不能带 /
         * 2、bundle 目录结尾不能带 /
         * 3、普通目录结尾带不带 / 都可以, 统一规范结尾都不带 /
         */
        if (url.endsWith('/')) {
            url = url.slice(0, -1);
            we.warn(`AssetManager getRelativePath, endsWith / err, url: ${url}`);
        }

        let relativePath = url.slice(url.indexOf('/') + 1);
        const bundleName = this.getBundleName(url);

        // 通用目录: 配置文件、皮肤共享资源
        const commonDir = ['config', 'share'].some((dir) => {
            return url.startsWith(`${bundleName}/${dir}/`);
        });

        if (!commonDir) {
            let skinPath = this.getSkinPath(bundleName);
            if (!relativePath.includes(skinPath)) {
                relativePath = skinPath + '/' + relativePath;
            }
        }

        return relativePath;
    }

    /**
     * 加载分包列表
     * @param bundleName bundle 名称
     * @param onComplete 加载完成回调
     */
    private static async loadBundles(bundleName: string, onComplete?: (bundles: cc.AssetManager.Bundle[]) => void): Promise<cc.AssetManager.Bundle[]> {
        if (!(bundleName && typeof bundleName == 'string')) {
            const errMsg = `AssetManager loadBundles, params err, bundleName: ${bundleName}`;
            // we.warn(errMsg); 内部封装不打印日志, 上层捕获异常统一打印, 避免重复日志
            onComplete?.([]);
            throw new Error(errMsg);
        }

        const bundles: cc.AssetManager.Bundle[] = [];
        const bundleNames = GameConfig.getDependBundles(GameConfig.toGameId(bundleName));
        bundleNames.push(bundleName);

        for (let i = 0; i < bundleNames.length; i++) {
            // 这里必须按照依赖顺序串行加载, 否则会导致有前置依赖的 bundle 加载失败
            const bundle = await this.loadBundle(bundleNames[i]).catch((err) => {
                const errMsg = `AssetManager loadBundles, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`;
                // we.error(errMsg); 内部封装不打印日志, 上层捕获异常统一打印, 避免重复日志
                onComplete?.([]);
                throw new Error(errMsg);
            });
            bundles.push(bundle);
        }

        onComplete?.(bundles);
        return bundles;
    }

    /**
     * 加载分包
     * @param bundleName bundle 名称
     * @param onComplete 加载完成回调
     */
    private static loadBundle(bundleName: string, onComplete?: (bundle: cc.AssetManager.Bundle | null) => void): Promise<cc.AssetManager.Bundle> {
        return new Promise((resolve, reject) => {
            if (!(bundleName && typeof bundleName == 'string')) {
                const errMsg = `AssetManager loadBundle, params err, bundleName: ${bundleName}`;
                // we.warn(errMsg); 内部封装不打印日志, 上层捕获异常统一打印, 避免重复日志
                onComplete?.(null);
                reject(new Error(errMsg));
                return;
            }

            const bundleConfig = GameConfig.getBundleConfig(bundleName);
            if (!bundleConfig) {
                const errMsg = `AssetManager loadBundle, bundleConfig err, bundleName: ${bundleName}`;
                // we.error(errMsg); 内部封装不打印日志, 上层捕获异常统一打印, 避免重复日志
                onComplete?.(null);
                reject(new Error(errMsg));
                return;
            }

            let localVersion = GameConfig.getLocalVersion(bundleName);
            if (bundleConfig.version && localVersion !== bundleConfig.version) {
                // 有版本更新时，淘汰hotcache中存在的当前bundleName, 移除assetManager中存在的bundle包, 重新加载新版本
                we.kit.hotCache.evictTypeValue('bundle', bundleName);
            }

            const bundle = cc.assetManager.getBundle(bundleName);
            if (bundle) {
                onComplete?.(bundle);
                resolve(bundle);
                return;
            }

            const nameOrUrl = bundleConfig.url;
            const options = { version: bundleConfig.version };
            cc.assetManager.loadBundle(nameOrUrl, options, (err: Error, bundle: cc.AssetManager.Bundle) => {
                if (err) {
                    const errMsg = `AssetManager loadBundle, loadBundle, bundleName: ${bundleName}, err: ${JSON.stringify(err.message || err)}`;
                    // we.error(errMsg); 内部封装不打印日志, 上层捕获异常统一打印, 避免重复日志
                    onComplete?.(null);
                    reject(new Error(errMsg));
                } else {
                    if (bundleConfig.version) {
                        GameConfig.setLocalVersion(bundleName, bundleConfig.version);
                    }
                    onComplete?.(bundle);
                    resolve(bundle);
                }
            });
        });
    }

    /**
     * 释放资源
     * @param asset 资源实例
     */
    private static releaseAsset(asset: cc.Asset): void {
        if (!(asset instanceof cc.Asset)) {
            we.warn(`AssetManager releaseAsset, params err`);
            return;
        }

        if (!cc.isValid(asset, true)) {
            // 已经释放
            return;
        }

        if (asset instanceof cc.SpriteAtlas) {
            // 先释放碎图
            const assets = asset.getSpriteFrames();
            for (let i = 0; i < assets.length; i++) {
                cc.assetManager.releaseAsset(assets[i]);
            }
        }

        cc.assetManager.releaseAsset(asset);
    }

    /**
     * 处理资源加载完成
     * @param handler 负责资源生命周期的处理器或回调
     * @param resolve Promise.resolve 方法, 用于返回加载的资源
     * @param asset 加载完成的资源实例
     * @param instanceId 组件实例 id
     */
    private static processAssetComplete<T>(handler: AssetLifecycleHandler<T | T[]>, resolve: (value: T | T[] | PromiseLike<T | T[]>) => void, asset: T | T[], instanceId: number): void {
        if (!handler) {
            return;
        }

        if (handler instanceof cc.Node || handler instanceof cc.Component) {
            if (handler.isValid) {
                resolve(asset);
            }
        } else if (handler instanceof Entity) {
            // 确保当前资源一定是目标对象发起的, 当 Entity 使用对象池时 InstanceId 会变化, 所以可以用它判定当前加载的资源是否是目标对象发起的
            if (handler.isValid() && handler.InstanceId === instanceId) {
                resolve(asset);
            }
        } else if (handler instanceof Func) {
            if (handler.isValidFunc()) {
                handler.exec(asset);
                resolve(asset);
            }
        } else if (typeof handler === 'function') {
            // 普通回调方式默认和场景生命周期绑定
            let currentScene = we.currentScene || we.clientScene;
            if (currentScene.isValid() && currentScene.InstanceId === instanceId) {
                handler(asset);
                resolve(asset);
            }
        }
    }
}

we.core.assetMgr = AssetManager;
