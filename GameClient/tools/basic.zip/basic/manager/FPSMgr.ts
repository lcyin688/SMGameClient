export default class FPSMgr {
    private static _instance: FPSMgr = new FPSMgr(); // 类加载时自动创建

    private time = 1; // 统计的时间间隔,单位s 值最好设置1s以上，太小了回调太频繁，影响性能
    private renderCount = 0; // 指定时间内渲染的次数,时间指的是上面的time
    private totalTime = 60; // 设置的统计时间，单位s
    private lowFPSCount = 0; // 出现低帧率的次数
    private curFPS: number = 0; // 当前fps
    private lowFPS = 24; // 定义为低帧率时的帧数
    private descLowFPSCount = Math.floor((this.totalTime / this.time) * 0.6); // 统计时间以内，出现低帧率次数的目标值，如果达到, 则认为当前处于低帧率模式
    private isBackground: boolean = false; // 是否是处于后台
    private minDeltaFPS: number = 15; // 统计时间内，下降的帧率
    private checkCd: number = 5; // 切换场景时，开启掉帧检测的cd，单位s
    private isCheckDropFPS: boolean = true; // 是否检测掉帧

    private constructor() {
        if (CC_EDITOR) {
            return;
        }
        cc.director.on(cc.Director.EVENT_AFTER_DRAW, this.update, this);
        cc.director.on(cc.game.EVENT_SHOW, this.onEventGameShow, this);
        cc.director.on(cc.game.EVENT_HIDE, this.onEventGameHide, this);
        cc.director.on(cc.Director.EVENT_AFTER_SCENE_LAUNCH, this.onSceneChanged, this);
        setInterval(this.checkIsLowFPS.bind(this), this.time * 1000);
        setInterval(this.checkIsLowFPSMode.bind(this), this.totalTime * 1000);
    }

    /**
     * 切换到前台
     */
    private onEventGameShow(): void {
        this.isBackground = false;
    }

    /**
     * 切换到后台
     */
    private onEventGameHide(): void {
        this.isBackground = true;
    }

    /**
     * 切换场景，重新计算帧率，因为这个时候掉帧是属于正常现象
     */
    private onSceneChanged(): void {
        this.lowFPSCount = 0;
        this.renderCount = 0;
        this.isCheckDropFPS = false;
        setTimeout(() => {
            this.isCheckDropFPS = true;
        }, this.checkCd * 1000);
    }

    /**
     * cocos渲染回调
     */
    private update(): void {
        this.renderCount++;
    }

    /**
     * 检测当前是否是低帧率
     */
    private checkIsLowFPS(): void {
        // 游戏暂停或者处于后台则不检测低帧率
        if (cc.game.isPaused() || this.isBackground) {
            return;
        }
        const fps = this.renderCount / this.time;
        if (fps < this.lowFPS) {
            this.lowFPSCount++;
        }
        const deltaFps = this.curFPS - fps;
        if (deltaFps > this.minDeltaFPS && this.isCheckDropFPS) {
            this.reportDropFPS(this.curFPS, fps);
        }
        this.curFPS = fps;
        this.renderCount = 0;
    }

    /**
     * 检测是否处于低帧率模式
     */
    private checkIsLowFPSMode(): void {
        // 当前处于低帧率模式，上报日志
        if (this.lowFPSCount > this.descLowFPSCount) {
            this.reportLowFPS();
        }
        this.lowFPSCount = 0;
    }

    /**
     * 上报低帧率
     */
    private reportLowFPS(): void {
        const curScene = cc.director.getScene();
        if (!curScene || curScene.name == 'Transition') {
            return;
        }
        // we.info(`FPSMgr reportLowFPS fps: ${this.curFPS}, scene:${cc.director.getScene().name}, device:${NativeUtil.getDeviceModel()}`);
    }

    /**
     * 上报卡顿
     */
    private reportDropFPS(lastFPS: number, curFPS: number): void {
        const curScene = cc.director.getScene();
        // 如果不在游戏里面，不需要上报
        if (!curScene || curScene.name.indexOf('Game') == -1) {
            return;
        }
        // we.info(`FPSMgr reportDropFPS lastfps:${lastFPS}, curfps: ${curFPS}, scene:${cc.director.getScene().name}, device:${NativeUtil.getDeviceModel()}`);
    }
}
