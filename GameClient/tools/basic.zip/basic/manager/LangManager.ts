import { BundleNames } from '../config/GameConfig';
import { BrowserParamKey } from '../config/ToolsConfig';
import Flavor from '../flavor/Flavor';
import { LangCode } from '../flavor/FlavorConf';
import Utils from '../utils/Utils';
import AssetManager from './AssetManager';

declare global {
    interface ICore {
        /** 多语言管理类 */
        langMgr: typeof LangManager;
    }
}

export default class LangManager {
    private static langMaps: Map<string, Map<string, string>> = new Map<string, Map<string, string>>();
    private static curLangCode: LangCode = null;
    /** 没有多语言配置的模块 */
    private static readonly noLangModules: string[] = [BundleNames.main, BundleNames.comwbg];

    public static init(): void {
        this.setLangCode();
    }

    /**
     * 加载模块
     * @param moduleName 模块名称
     */
    public static async loadModule(moduleName: string): Promise<void> {
        if (!(moduleName && typeof moduleName == 'string')) {
            const errMsg = `LangManager loadModule, params err, moduleName: ${moduleName}`;
            we.error(errMsg);
            throw new Error(errMsg);
        }

        if (this.noLangModules.includes(moduleName)) {
            return;
        }

        let url = moduleName + '/config/lang/' + this.getCurLangCode() + '/lang';
        const isExist = AssetManager.isAssetExist(url);
        if (!isExist) {
            // 指定语言不存在, 则使用默认语言
            url = moduleName + '/config/lang/' + this.getDefaultLangCode() + '/lang';
        }

        const asset = await AssetManager.loadAsset(url, cc.JsonAsset);
        if (asset && asset.json) {
            const langJson: Object = asset.json;
            const langMap = new Map<string, string>();
            for (const key in langJson) {
                langMap.set(key, langJson[key]);
            }

            this.langMaps.set(moduleName, langMap);
        } else {
            const errMsg = `LangManager loadModule, loadAsset err, url: ${url}`;
            we.error(errMsg);
            throw new Error(errMsg);
        }
    }

    /**
     * 切换语言
     * @param langCode 语言代码
     */
    public static async switchLang(langCode: LangCode): Promise<void> {
        if (!this.isValidLangCode(langCode)) {
            we.warn(`LangManager switchLang, params err, langCode: ${langCode}`);
            return;
        }

        if (this.curLangCode == langCode) {
            return;
        }

        this.setLangCode(langCode);

        // 重新加载所有语言模块
        let tasks: Promise<void>[] = [];
        for (let module of this.langMaps.keys()) {
            tasks.push(this.loadModule(module));
        }
        await Promise.all(tasks);

        we.event<we.core.EventMsg>().emit('LangChanged', langCode);

        we.core.eventSystem.invoke(new we.core.eventInvoke.ReportLanguage(this.curLangCode));
    }

    /**
     * 获取当前语言代码
     */
    public static getCurLangCode(): LangCode {
        return this.curLangCode;
    }

    /**
     * 获取多语言文本
     * @param key 多语言 key
     * @param args 格式化参数列表
     */
    public static getLangText(key: string, ...args: any[]): string {
        if (!(key && typeof key == 'string')) {
            we.warn(`LangManager getLangText, params err, key: ${key}`);
            return '';
        }

        const moduleName = this.getModuleName(key);
        const module = this.langMaps.get(moduleName);
        if (!module) {
            we.warn(`LangManager getLangText, module err, moduleName: ${moduleName}`);
            return `module: ${moduleName}`;
        }

        const langKey = this.getLangKey(key);
        const langValue = module.get(langKey);
        if (!langValue) {
            we.warn(`LangManager getLangText, langValue err, moduleName: ${moduleName} langKey: ${langKey}`);
            return `module: ${moduleName} key: ${langKey}`;
        }

        if (args.length == 0) {
            return langValue;
        }

        return Utils.stringFormat(langValue, ...args);
    }

    /**
     * 设置多语言文本
     * @param comp 设置文本组件, 不管是引擎组件还是第三方组件或者自己的组件, 都必须支持 string set 接口
     * @param key 多语言key
     * @param strFormatFn 多语言文本处理函数, 如果对多语言有其他处理传入处理函数即可
     * @param args 格式化参数
     */
    public static setLangText<T extends cc.Component & { string: string }>(comp: T, key: string, strFormatFn: (langText: string) => string, ...args: any[]): void;
    public static setLangText<T extends cc.Component & { string: string }>(comp: T, key: string, ...args: any[]): void;
    public static setLangText<T extends cc.Component & { string: string }>(...args: any[]): void {
        const isStrFromat = typeof args[2] == 'function';
        const argsList = [...args];
        const comp: T = argsList.shift();
        const key: string = argsList.shift();
        const strFormatFn: (langText: string) => string = isStrFromat ? argsList.shift() : null;

        if (!cc.isValid(comp)) {
            return;
        }

        let text = this.getLangText(key, ...argsList);

        // 如果对字符串还有其他需要处理的地方则直接通过处理函数来处理
        if (strFormatFn) {
            text = strFormatFn(text);
        }

        comp.string = text;
    }

    /**
     * 获取多语言图片
     * @param url 多语言资源 url
     * @deprecated loadLangSpriteFrame 代替
     */
    public static getLangSpriteFrame(url: string): cc.SpriteFrame {
        if (!(url && typeof url == 'string')) {
            we.warn(`LangManager getLangSpriteFrame, params err, url: ${url}`);
            return null;
        }

        const langTextureUrl = this.getLangTextureUrl(url);
        const spriteFrame = AssetManager.getAsset(langTextureUrl, cc.SpriteFrame);
        return spriteFrame;
    }

    /**
     * 加载多语言图片
     * @param url 多语言资源 url
     * @param onComplete 加载完成回调
     */
    public static loadLangSpriteFrame(url: string, onComplete: (spriteFrame: cc.SpriteFrame) => void): void {
        if (!(url && typeof url == 'string')) {
            we.warn(`LangManager loadLangSpriteFrame, params err, url: ${url}`);
            return;
        }

        const langTextureUrl = this.getLangTextureUrl(url);
        AssetManager.loadAsset(langTextureUrl, cc.SpriteFrame, (spriteFrame) => {
            onComplete(spriteFrame);
        });
    }

    /**
     * 设置多语言图片
     * @param sprite cc.Sprite 或带有 cc.Sprite 的节点
     * @param url 多语言资源 url
     * @param onComplete 设置完成回调
     */
    public static setLangSpriteFrame(sprite: cc.Sprite | cc.Node, url: string, onComplete?: (spriteFrame: cc.SpriteFrame) => void): void;
    public static setLangSpriteFrame(...args: any[]): void {
        let sprite: cc.Sprite = null;
        if (args[0] instanceof cc.Sprite) {
            sprite = args[0];
        } else if (args[0] instanceof cc.Node) {
            sprite = args[0].getComponent(cc.Sprite);
        }

        if (!sprite) {
            return;
        }

        const url: string = args[1];
        const onComplete = args[2];

        this.loadLangSpriteFrame(url, (spriteFrame: cc.SpriteFrame) => {
            if (!cc.isValid(sprite) || !spriteFrame) {
                return;
            }

            sprite.spriteFrame = spriteFrame;
            onComplete?.(spriteFrame);
        });
    }

    /**
     * 获取多语言图片 url
     * @param url 多语言资源 url
     */
    private static getLangTextureUrl(url: string): string {
        if (!(url && typeof url == 'string')) {
            we.warn(`LangManager getLangTextureUrl, params err, url: ${url}`);
            return '';
        }

        let langTextureUrl = Utils.stringFormat(url, this.getCurLangCode());
        if (!AssetManager.isAssetExist(langTextureUrl)) {
            langTextureUrl = Utils.stringFormat(url, this.getDefaultLangCode());
        }

        return langTextureUrl;
    }

    /**
     * 设置语言代码
     * @param langCode 不传则使用上次缓存或预设语言
     */
    private static setLangCode(langCode?: LangCode): void {
        we.log(`LangManager setLangCode, cc.sys.languageCode: ${cc.sys.languageCode}, langCode: ${langCode}`);

        if (langCode) {
            this.curLangCode = langCode;
        } else {
            const cacheLangCode = <LangCode>we.kit.storage.get('sys', 'app_language_code');
            if (cacheLangCode) {
                this.curLangCode = cacheLangCode;
            } else {
                const sysLangCode = this.getSystemLangCode();
                this.curLangCode = sysLangCode;
            }
        }

        // 对浏览器参数修改 lang 例外
        if (!this.isCurCountryLangCode(this.curLangCode)) {
            this.curLangCode = this.getDefaultLangCode();
        }

        // 指定 langCode 优先级高于浏览器参数
        if (!langCode && cc.sys.isBrowser) {
            const code = <LangCode>Utils.getLocationUrlParam(BrowserParamKey.lang);
            if (code) {
                this.curLangCode = code;
            }
        }

        if (!this.isValidLangCode(this.curLangCode)) {
            this.curLangCode = this.getDefaultLangCode();
        }

        we.kit.storage.setById('sys', 'app_language_code', this.curLangCode);
    }

    /**
     * 是否有效语言代码
     * @param langCode
     */
    private static isValidLangCode(langCode: LangCode): boolean {
        const keys = Object.keys(LangCode);
        for (let i = 0; i < keys.length; i++) {
            if (LangCode[keys[i]] == langCode) {
                return true;
            }
        }
        return false;
    }

    /**
     * 是否当前国家语言代码
     * @param code
     */
    private static isCurCountryLangCode(code: LangCode): boolean {
        return Flavor.getLangList().includes(code);
    }

    /**
     * 获取系统语言代码
     * - 多个语言时优先使用系统语言
     * - 单个语言时使用默认语言
     */
    private static getSystemLangCode(): LangCode {
        let langList = Flavor.getLangList();
        if (langList.length > 1) {
            let code = cc.sys.languageCode.slice(0, 2).toLowerCase();
            switch (code) {
                case 'in':
                    // 印尼语 id in-id
                    code = LangCode.id;
                    break;
                default:
                    break;
            }

            if (!this.isValidLangCode(<LangCode>code)) {
                code = this.getDefaultLangCode();
            }

            return <LangCode>code;
        } else {
            return this.getDefaultLangCode();
        }
    }

    /**
     * 获取默认语言代码
     */
    private static getDefaultLangCode(): LangCode {
        return <LangCode>Flavor.getLangList()[0];
    }

    /**
     * 获取模块名称
     * @param key
     */
    private static getModuleName(key: string): string {
        if (!(key && typeof key == 'string')) {
            we.warn(`LangManager getModuleName, params err, key: ${key}`);
            return '';
        }

        const keys = key.split('/');
        const moduleName = keys[0];
        if (!(moduleName && typeof moduleName == 'string')) {
            we.warn(`LangManager getModuleName, moduleName err, key: ${key}`);
            return '';
        }

        return moduleName;
    }

    /**
     * 获取语言 key
     * @param key
     */
    private static getLangKey(key: string): string {
        if (!(key && typeof key == 'string')) {
            we.warn(`LangManager getLangKey, params err, key: ${key}`);
            return '';
        }

        const keys = key.split('/');
        const langKey = keys[1];
        if (!(langKey && typeof langKey == 'string')) {
            we.warn(`LangManager getLangKey, langKey err, key: ${key}`);
            return '';
        }

        return langKey;
    }
}

we.core.langMgr = LangManager;
