import { GameConfig, MainBundles } from '../config/GameConfig';
import { LOAD_TYPE } from '../config/ProjectConfig';
import { SysLanguage } from '../config/SysLanguage';
import TrackConfig from '../config/TrackConfig';
import BasicEventName from '../const/BasicEventName';
import Flavor from '../flavor/Flavor';
import TrackManager from '../manager/TrackManager';
import { BasicType } from '../type/BasicType';
import Utils from '../utils/Utils';
import LangManager from './LangManager';

declare global {
    interface ICore {
        hotUpdateMgr: typeof HotUpdateManager;
    }
}

const VERSION_FILENAME = 'version.manifest';
const MANIFEST_FILENAME = 'project.manifest';
const KEY_CACHE_SEARCH_PATHS = 'cache_search_paths';

enum State {
    UNINITED,
    UNCHECKED,
    PREDOWNLOAD_VERSION,
    DOWNLOADING_VERSION,
    VERSION_LOADED,
    PREDOWNLOAD_MANIFEST,
    DOWNLOADING_MANIFEST,
    MANIFEST_LOADED,
    NEED_UPDATE,
    READY_TO_UPDATE,
    UPDATING,
    UNZIPPING,
    UP_TO_DATE,
    FAIL_TO_UPDATE,
}

enum EventCode {
    ERROR_NO_LOCAL_MANIFEST,
    ERROR_DOWNLOAD_MANIFEST,
    ERROR_PARSE_MANIFEST,
    NEW_VERSION_FOUND,
    ALREADY_UP_TO_DATE,
    UPDATE_PROGRESSION,
    ASSET_UPDATED,
    ERROR_UPDATING,
    UPDATE_FINISHED,
    UPDATE_FAILED,
    ERROR_DECOMPRESS,
}

export default class HotUpdateManager {
    /** 分包名称 */
    private static bundleName: string = '';
    /** 远端版本号 */
    private static remoteVersion: string = '';
    /** 远端皮肤 */
    private static remoteSkin: string = '';
    /** 更新包下载路径 */
    private static packageUrl: string = '';
    /**
     * 完成回调
     * @param success 是否成功
     * @param updated 是否更新
     */
    private static onComplete: (success: boolean, updated: boolean) => void = null;
    /** 后台下载 */
    private static background: boolean = false;
    /** 搜索路径 */
    private static searchPaths: string[] = [];
    /** AssetsManager */
    private static am: any = null;
    /** 是否正在更新 */
    private static updating: boolean = false;
    /** 重试下载次数 */
    private static retryDownloadCount: number = 0;
    /** 已经异常 */
    private static hasError: boolean = false;
    /** 百分比实际 */
    private static percentReal: number = 0;
    /** 百分比开始 */
    private static percentStart: number = 0;
    /** 开始时间 */
    private static startTime: number = 0;

    /**
     * 加载分包
     * @param bundleName 分包名称
     * @param remoteVersion 远端版本号
     * @param packageUrl 更新包下载路径
     * @param onComplete 完成回调
     * @param background 后台下载, 默认 false
     */
    public static loadBundle(bundleName: string, remoteVersion: string, packageUrl: string, onComplete: (success: boolean, updated: boolean) => void = null, background: boolean = false): void {
        if (!(bundleName && remoteVersion && packageUrl)) {
            we.warn(`HotUpdateManager loadBundle, params err`);
            return;
        }

        we.log(`HotUpdateManager loadBundle, bundleName: ${bundleName}, remoteVersion: ${remoteVersion}, packageUrl: ${packageUrl}, background: ${background}`);

        if (this.bundleName == bundleName) {
            if (this.background == true && background == false) {
                this.onComplete = onComplete;
                this.background = background;
                this.percentStart = this.percentReal;
                this.notifyVersion();
            }
            return;
        }

        if (!packageUrl.endsWith('/')) {
            packageUrl += '/';
        }

        // 支持 url 不带版本号
        if (!packageUrl.includes(remoteVersion)) {
            packageUrl = packageUrl.slice(0, -1);
            packageUrl = `${packageUrl}_${remoteVersion}/`;
        }

        // 通过 url 格式获取远端皮肤 'https://download.xxx.com/native/hall/main_ct_5.5.5/'
        let remoteSkin = '';
        let urlParts = packageUrl.split('/');
        if (urlParts.length > 2) {
            let bundleDir = urlParts[urlParts.length - 2];
            let dirParts = bundleDir.split('_');
            if (dirParts.length == 3) {
                remoteSkin = dirParts[1];
            }
        }

        this.reset();

        this.bundleName = bundleName;
        this.remoteVersion = remoteVersion;
        this.remoteSkin = remoteSkin;
        this.packageUrl = packageUrl;
        this.onComplete = onComplete;
        this.background = background;

        cc.director.on(BasicEventName.HOT_UPDATE_STOP, this.onEventUpdateStop, this);
        cc.director.on(BasicEventName.NETWORK_ONLINE, this.onEventNetworkOnline, this);

        if (!cc.sys.isNative) {
            this.finalize(true, false);
            return;
        }

        this.searchPaths = jsb.fileUtils.getSearchPaths();
        this.setSearchPaths();

        let localVersion = this.getLocalVersion(this.bundleName);
        if (this.compareVersionHot(localVersion, this.remoteVersion) < 0) {
            this.notifyVersion();
            this.initAm();

            cc.director.emit(BasicEventName.HOT_UPDATE_START);
            cc.director.emit(BasicEventName.LOAD_STATUS, LangManager.getLangText(SysLanguage.LOAD_STATUS_REMOTE_ING));
            cc.director.emit(BasicEventName.LOAD_PROGRESS_ACTIVE, true);

            let msg = {
                percent: 0,
                loadType: LOAD_TYPE.HOT_UPDATE,
                bundleName: this.bundleName,
            };
            cc.director.emit(BasicEventName.LOAD_PROGRESS, msg);
        } else {
            this.finalize(true, false);
        }
    }

    /**
     * 移除分包缓存
     * @param bundleName
     * @param cleanup
     */
    public static removeBundleCache(bundleName: string, cleanup: boolean = true): void {
        if (!bundleName) {
            we.warn(`HotUpdateManager removeBundleCache, params err`);
            return;
        }

        we.log(`HotUpdateManager removeBundleCache, bundleName: ${bundleName}, cleanup: ${cleanup}`);

        if (!cc.sys.isNative) {
            return;
        }

        if (bundleName == this.bundleName && this.am && this.am.getState() != State.FAIL_TO_UPDATE) {
            we.log(`HotUpdateManager removeBundleCache, ${bundleName} is updating`);
            return;
        }

        let dir = this.getStoragePath(bundleName);

        if (cleanup) {
            jsb.fileUtils.removeDirectory(dir);
        }
        jsb.fileUtils.removeDirectory(dir.substring(0, dir.length - 1) + '_temp/');
    }

    /**
     * 完成
     * @param success
     * @param updated
     */
    private static finalize(success: boolean, updated: boolean) {
        we.log(`HotUpdateManager finalize, success: ${success}, updated: ${updated}`);

        cc.director.emit(BasicEventName.HOT_UPDATE_END);

        cc.director.off(BasicEventName.HOT_UPDATE_STOP, this.onEventUpdateStop, this);
        cc.director.off(BasicEventName.NETWORK_ONLINE, this.onEventNetworkOnline, this);

        if (success && updated && this.startTime > 0) {
            let endTime = new Date().getTime();
            let loadTime = endTime - this.startTime;
            TrackManager.trackEvent(TrackConfig.game.customdata, {
                game_id: GameConfig.toGameId(this.bundleName),
                load_type: LOAD_TYPE.HOT_UPDATE,
                load_time: loadTime,
            });
        }

        if (cc.sys.isNative) {
            this.setSearchPaths();
        }

        if (typeof this.onComplete == 'function') {
            this.onComplete(success, updated);
        }

        this.reset();
    }

    /**
     * 重置
     */
    private static reset() {
        this.bundleName = '';
        this.remoteVersion = '';
        this.remoteSkin = '';
        this.packageUrl = '';
        this.onComplete = null;
        this.background = false;
        this.searchPaths = [];

        if (this.am) {
            this.am.setEventCallback(null);
            this.am.setVerifyCallback(null);
            this.am = null;
        }

        this.updating = false;
        this.retryDownloadCount = 0;
        this.hasError = false;
        this.percentReal = 0;
        this.percentStart = 0;
        this.startTime = 0;
    }

    /**
     * 获取本地版本号
     * @param bundleName
     */
    public static getLocalVersion(bundleName: string): string {
        if (!(bundleName && typeof bundleName == 'string')) {
            we.warn(`HotUpdateManager getLocalVersion, params err`);
            return '';
        }

        if (!cc.sys.isNative) {
            return '';
        }

        let version = BasicType.VersionDefault;
        let manifest = new jsb.Manifest(this.getModuleDir(bundleName) + VERSION_FILENAME);
        if (manifest && manifest.isLoaded()) {
            version = manifest.getVersion();
        }

        return version;
    }

    /**
     * 通知版本
     */
    private static notifyVersion() {
        if (!this.background) {
            let gameId = GameConfig.toGameId(this.bundleName);
            let ver = GameConfig.getGameVersion(gameId) + `/${this.remoteVersion}`;
            cc.director.emit(BasicEventName.LOAD_BUNDLE_VERSION, ver);
        }
    }

    /**
     * 设置搜索路径
     */
    private static setSearchPaths() {
        let writablePath = jsb.fileUtils.getWritablePath();
        let searchPaths = [writablePath + 'assets/assets/', writablePath + 'assets/', writablePath].concat(this.searchPaths);

        let temp: string[] = [];
        for (let i = 0; i < searchPaths.length; i++) {
            if (searchPaths[i] && temp.indexOf(searchPaths[i]) == -1) {
                temp.push(searchPaths[i]);
            }
        }
        searchPaths = temp;

        jsb.fileUtils.setSearchPaths(searchPaths);
        localStorage.setItem(KEY_CACHE_SEARCH_PATHS, JSON.stringify(searchPaths));
        we.log(`HotUpdateManager setSearchPaths, searchPaths: ${JSON.stringify(searchPaths)}`);
    }

    /**
     * 比较版本 [local !== remote] < 0 有更新, >= 0 无更新
     * @param localVersion 1.0.1
     * @param remoteVersion 1.0.2
     */
    private static compareVersionHot(localVersion: string, remoteVersion: string): number {
        let ret = Utils.compareVersion(localVersion, remoteVersion);
        if (ret >= 0 && this.remoteSkin) {
            if (this.remoteSkin != Flavor.getSkinCode()) {
                // 同版本不同皮肤可以直接触发热更
                ret = -1;
            }
        }

        return ret;
    }

    /**
     * 初始化 AssetsManager
     */
    private static initAm() {
        this.am = new jsb.AssetsManager('', this.getStoragePath(this.bundleName), this.compareVersionHot.bind(this));
        this.am.setPackageUrl(this.packageUrl);
        this.am.setEventCallback(this.onEventCallback.bind(this));
        this.am.setVerifyCallback(this.onVerifyCallback.bind(this));

        if (cc.sys.os === cc.sys.OS_ANDROID) {
            // Some Android device may slow down the download process when concurrent tasks is too much.
            // The value may not be accurate, please do more test and find what's most suitable for your game.
            // this.am.setMaxConcurrentTask(2);
        }

        this.loadLocalManifest();
        this.startCheck();

        this.startTime = new Date().getTime();
    }

    /**
     * 加载资源清单
     */
    private static loadLocalManifest() {
        let localManifestExist = jsb.fileUtils.isFileExist(this.getModuleDir(this.bundleName) + MANIFEST_FILENAME);
        if (!localManifestExist) {
            let version = BasicType.VersionDefault;
            let packageUrl = `http://localhost/`;
            const defaultManifest = {
                packageUrl: packageUrl,
                remoteVersionUrl: packageUrl + VERSION_FILENAME,
                remoteManifestUrl: packageUrl + MANIFEST_FILENAME,
                version: version,
                assets: {},
                searchPaths: [],
            };
            jsb.fileUtils.writeStringToFile(JSON.stringify(defaultManifest, null, 4), this.getStoragePath(this.bundleName) + MANIFEST_FILENAME);
        }

        this.am.loadLocalManifest(this.getModuleDir(this.bundleName) + MANIFEST_FILENAME);
    }

    /**
     * 开始检查
     */
    private static startCheck() {
        if (!(this.am.getLocalManifest() && this.am.getLocalManifest().isLoaded())) {
            we.error(`HotUpdateManager startCheck, local manifest not loaded`);
            return;
        }

        this.am.checkUpdate();
    }

    /**
     * 开始更新
     */
    private static startUpdate() {
        if (this.updating) {
            we.log(`HotUpdateManager startUpdate, updating`);
            return;
        }

        this.updating = true;
        this.am.update();
    }

    /**
     * 更新回调
     * @param event
     */
    private static onEventCallback(event) {
        if (!this.am) {
            we.error(`HotUpdateManager onEventCallback, am is invalid`);
            return;
        }

        if (event.getEventCode() != jsb.EventAssetsManager.UPDATE_PROGRESSION) {
            we.log(`HotUpdateManager onEventCallback, state: ${State[this.am.getState()]}, eventCode: ${EventCode[event.getEventCode()]}, message: ${event.getMessage()}, assetId: ${event.getAssetId()}`);
        }

        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.processError(event.getEventCode());
                break;
            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                this.startUpdate();
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                this.finalize(true, false);
                break;
            case jsb.EventAssetsManager.UPDATE_PROGRESSION: {
                let percent = event.getPercent();
                if (percent != null) {
                    this.percentReal = percent;
                    let percentTransition = (percent - this.percentStart) / (1 - this.percentStart);
                    percentTransition = percentTransition >= 1 ? 0.99 : percentTransition;
                    let downloadedBytes = event.getDownloadedBytes();
                    let totalBytes = event.getTotalBytes();
                    let percentByFile = event.getPercentByFile();
                    let downloadedFiles = event.getDownloadedFiles();
                    let totalFiles = event.getTotalFiles();
                    let message = event.getMessage();
                    let msg = {
                        percent: percentTransition,
                        percentReal: percent,
                        downloadedBytes: downloadedBytes,
                        totalBytes: totalBytes,
                        percentByFile: percentByFile,
                        downloadedFiles: downloadedFiles,
                        totalFiles: totalFiles,
                        message: message,
                        loadType: LOAD_TYPE.HOT_UPDATE,
                        bundleName: this.bundleName,
                    };
                    we.log(
                        `HotUpdateManager onEventCallback, state: ${State[this.am.getState()]}, eventCode: ${EventCode[event.getEventCode()]}, message: ${event.getMessage()}, assetId: ${event.getAssetId()}, msg: ${JSON.stringify(msg, null, 4)}`
                    );
                    cc.director.emit(BasicEventName.LOAD_PROGRESS, msg);
                }
                break;
            }
            case jsb.EventAssetsManager.ASSET_UPDATED:
                break;
            case jsb.EventAssetsManager.ERROR_UPDATING:
                // this.processError(event.getEventCode());
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED: {
                let msg = {
                    percent: 1,
                    loadType: LOAD_TYPE.HOT_UPDATE,
                    bundleName: this.bundleName,
                };
                cc.director.emit(BasicEventName.LOAD_PROGRESS, msg);
                this.finalize(true, true);
                break;
            }
            case jsb.EventAssetsManager.UPDATE_FAILED:
                // this.processError(event.getEventCode());
                this.retryDownload(event.getEventCode());
                break;
            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                this.processError(event.getEventCode());
                break;
            default:
                break;
        }
    }

    /**
     * 验证回调
     * @param path
     * @param asset
     */
    private static onVerifyCallback(path, asset) {
        // we.log(`HotUpdateManager onVerifyCallback, path: ${path}, asset: ${JSON.stringify(asset)}`);

        // When asset is compressed, we don't need to check its md5, because zip file have been deleted.
        let compressed = asset.compressed;
        // Retrieve the correct md5 value.
        let expectedMD5 = asset.md5;
        // asset.path is relative path and path is absolute.
        let relativePath = asset.path;
        // The size of asset file, but this value could be absent.
        let size = asset.size;

        return true;
    }

    /**
     * 热更中止
     */
    private static onEventUpdateStop() {
        this.finalize(false, false);
    }

    /**
     * 网络已连接
     */
    private static onEventNetworkOnline() {
        if (!this.hasError) {
            this.retry();
        }
    }

    /**
     * 重试
     */
    private static retry() {
        if (this.am) {
            if (this.am.getState() > State.MANIFEST_LOADED) {
                this.retryDownloadCount = 0;
                this.am.update();
                this.am.downloadFailedAssets();
            } else {
                let bundleName = this.bundleName;
                let remoteVersion = this.remoteVersion;
                let packageUrl = this.packageUrl;
                let onComplete = this.onComplete;
                let background = this.background;
                this.reset();
                this.loadBundle(bundleName, remoteVersion, packageUrl, onComplete, background);
            }
        } else {
            we.warn(`HotUpdateManager retry, am is invalid`);
        }

        this.startTime = 0;
    }

    /**
     * 重试下载
     * @param code
     */
    private static retryDownload(code: EventCode) {
        we.log(`HotUpdateManager retryDownload, retryDownloadCount: ${this.retryDownloadCount}`);

        if (this.retryDownloadCount >= 3) {
            this.processError(code);
            return;
        }

        this.retryDownloadCount++;
        this.am.downloadFailedAssets();
    }

    /**
     * 处理异常
     * @param code
     */
    private static processError(code: EventCode) {
        if (this.hasError) {
            return;
        }

        this.hasError = true;
        this.startTime = 0;

        cc.director.emit(BasicEventName.LOAD_STATUS, LangManager.getLangText(SysLanguage.LOAD_STATUS_REMOTE_FAIL) + `: 200.${code}`);

        if (this.background) {
            this.finalize(false, false);
        } else {
            setTimeout(() => {
                we.commonUI.showConfirm({
                    content: LangManager.getLangText(SysLanguage.TIPS_NET_RECONNECT_FAIL) + ': ' + code,
                    isHideCloseBtn: true,
                    yesHandler: we.core.Func.create(() => {
                        this.hasError = false;
                        this.retry();
                    }),
                    noHandler: we.core.Func.create(() => {
                        this.removeBundleCache(this.bundleName, false);
                        this.finalize(false, false);
                    }),
                });
            });
        }
    }

    /**
     * 获取模块目录
     */
    private static getModuleDir(bundleName: string): string {
        if (MainBundles.includes(bundleName)) {
            return 'assets/';
        }
        return `${bundleName}/`;
    }

    /**
     * 获取存储路径
     */
    private static getStoragePath(bundleName: string): string {
        let writablePath = jsb.fileUtils.getWritablePath();
        if (MainBundles.includes(bundleName)) {
            return `${writablePath}assets/assets/`;
        }
        return `${writablePath}assets/${bundleName}/`;
    }
}

we.core.hotUpdateMgr = HotUpdateManager;
