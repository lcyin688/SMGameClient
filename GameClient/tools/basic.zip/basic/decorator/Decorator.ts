import 'reflect-metadata';
import { Entity } from '../module/entity/Entity';
import { DecoratorSymbol, KeySymbol } from './DecoratorSymbol';
import { UIType } from '../ui/core/UIType';
import { ISingletonInstance } from '../module/singleton/Singleton';

declare global {
    interface IWe {
        decorator: typeof Decorator;
    }

    namespace we {
        type Decorator = typeof Decorator;
    }
}

/**
 * 项目装饰器
 */
export class Decorator {
    /** 静态接口约束 */
    static staticImplement<T>(classname?: string) {
        return <U extends T>(constructor: U) => {
            if (classname) {
                this.cName(classname)(constructor);
            }
            return constructor;
        };
    }

    /** 类名标记（代码压缩编译后，无法取到类名） */
    static cName(classname: string) {
        return (target: any) => {
            Object.defineProperty(target, 'name', {
                writable: true,
            });
            target.name = classname;
        };
    }

    /**
     * Ecs类型注册
     * @param type 类型名，一般使用类名
     * @param isSingleton 是否单件类
     * @param packageName 类所属包名
     * @returns
     */
    static typeRegister(type: string, packageName?: string) {
        return (target: any) => {
            type = packageName ? `${packageName}_${type}` : type;
            this.cName(type)(target);
            Reflect.defineMetadata(KeySymbol.Type, type, target);
        };
    }

    /** Entity单例接口约束 */
    static typeSingleton<T = ISingletonInstance>(classname: string, packageName?: string) {
        return <U extends T>(constructor: U) => {
            this.typeRegister(classname, packageName)(constructor);
            Reflect.defineMetadata(KeySymbol.Singleton, true, constructor);
            return constructor;
        };
    }

    /**
     * 注册ui生命周期事件函数
     * @param viewId
     */
    static eventUI<T>(uiclass: new () => Entity, viewId: UIType.ViewId): ClassDecorator {
        return function (target: any) {
            // 调用BaseAttribute装饰器

            Object.defineProperty(target, 'name', {
                writable: true,
            });
            target.name = 'UIEventHandler';
            // 设置元数据
            Reflect.defineMetadata(UIType.UIAttributeSymbol.ViewId, viewId, target);
            Reflect.defineMetadata(UIType.UIAttributeSymbol.ViewUIClass, uiclass, target);

            we.ui.addUIEventType(target);
        };
    }

    /**
     * EventSystem事件监听
     * @param CLASS 事件类型
     * @param sceneType 场景类型
     * @param gameId 游戏Id
     * @param singleton 事件场景唯一性
     * @returns
     */
    static eventSystem<T>(CLASS: new (...args) => T, sceneType: number, gameId?: we.GameId, singleton?: boolean): ClassDecorator {
        return function (target: any) {
            Reflect.defineMetadata(DecoratorSymbol.Attribute, DecoratorSymbol.EventAttribute, target);
            Reflect.defineMetadata(DecoratorSymbol.EventAttribute, CLASS, target);
            // 设置元数据
            Reflect.defineMetadata(KeySymbol.SceneType, sceneType, target);
            Reflect.defineMetadata(KeySymbol.GameId, `${gameId}`, target);
            Reflect.defineMetadata(KeySymbol.Singleton, singleton, target);

            we.core.addEventSystemType(target);
        };
    }

    /**
     * 方法调用事件
     * @param CLASS
     * @param type
     * @returns
     */
    static eventInvoke<T>(CLASS: new (...args) => T, type?: string | number): ClassDecorator {
        return function (target: any) {
            Reflect.defineMetadata(DecoratorSymbol.Attribute, DecoratorSymbol.InvokeAttribute, target);
            Reflect.defineMetadata(DecoratorSymbol.InvokeAttribute, CLASS, target);
            // 设置元数据
            Reflect.defineMetadata(KeySymbol.InvokeType, `${type ?? '0'}`, target);

            we.core.addEventSystemType(target);
        };
    }
}

we.decorator = Decorator;
