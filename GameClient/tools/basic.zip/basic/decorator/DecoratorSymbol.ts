export const KeySymbol = {
    Type: Symbol('Type'),
    InvokeType: Symbol('InvokeType'),
    Singleton: Symbol('Singleton'),
    SceneType: Symbol('SceneType'),
    GameId: Symbol('GameId'),
};

export const DecoratorSymbol = {
    Attribute: Symbol('Attribute'),
    BaseAttribute: Symbol('BaseAttribute'),
    EventAttribute: Symbol('EventAttribute'),
    InvokeAttribute: Symbol('InvokeAttribute'),
};
