import BasicEventName from '../const/BasicEventName';

declare global {
    interface ICore {
        h5PWA: typeof H5PWA;
        PWAInstallStatus: typeof PWAInstallStatus;
    }
    interface TCore {
        PWAInstallStatus: PWAInstallStatus;
    }
    namespace we {
        namespace core {
            type PWAInstallStatus = TCore['PWAInstallStatus'];
        }
    }
}

/** PWA 安装事件 */
interface BeforeInstallPromptEvent extends Event {
    /** 弹出安装提示框 */
    prompt(): Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

/** PWA 安装状态 */
enum PWAInstallStatus {
    /** 已安装 */
    Installed = 0,
    /** 可安装 */
    Installable = 1,
    /** 不可安装 */
    NotInstallable = 2,
    /** 不可安装-非Chrome不支持 */
    NotInstallableNonChrome = 3,
    /** 不可安装-ios不支持 */
    NotInstallableIos = 4,
}

we.core.PWAInstallStatus = PWAInstallStatus;

export default class H5PWA {
    private static installPrompt: BeforeInstallPromptEvent = null;

    public static init(): void {
        if (!cc.sys.isBrowser) {
            return;
        }

        window.addEventListener('beforeinstallprompt', (event: Event) => {
            we.log(`H5PWA beforeinstallprompt`);

            event.preventDefault();
            this.installPrompt = <any>event;

            // 安装拒绝时会重新触发事件
            cc.director.emit(BasicEventName.PWA_INSTALL_UPDATE);
        });
    }

    /**
     * 获取安装状态
     * @returns
     */
    public static getInstallStatus(): PWAInstallStatus {
        let status = PWAInstallStatus.NotInstallable;
        if (cc.sys.isBrowser) {
            if (window.matchMedia('(display-mode: standalone)').matches) {
                status = PWAInstallStatus.Installed;
            } else if (this.installPrompt) {
                status = PWAInstallStatus.Installable;
            } else if (cc.sys.os == cc.sys.OS_ANDROID && cc.sys.browserType != cc.sys.BROWSER_TYPE_CHROME) {
                status = PWAInstallStatus.NotInstallableNonChrome;
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                status = PWAInstallStatus.NotInstallableIos;
            }
        }

        we.log(`H5PWA getInstallStatus, status: ${status}`);
        return status;
    }

    /**
     * 安装
     * @returns 成功 true, 失败 false
     */
    public static async install(): Promise<boolean> {
        if (!this.installPrompt) {
            return false;
        }

        let result = await this.installPrompt.prompt();
        we.log(`H5PWA install, outcome: ${result?.outcome}`);
        return result?.outcome == 'accepted';
    }
}

H5PWA.init();
we.core.h5PWA = H5PWA;
