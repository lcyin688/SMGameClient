declare global {
    namespace h5am {
        function postMessage(message: string);
    }
}

const METHOD_NAME = {
    TRACK_ADJUST_EVENT: 'trackAdjustEvent',
    OPEN_URL_BY_BROWSER: 'openUrlByBrowser',
    TRACK_APPSFLYER_EVENT: 'trackAppsFlyerEvent',
    SET_SCREEN_ORIENTATION: 'setScreenOrientation',
};

export default class H5AndroidM {
    private static postMessage(method: string, params: object = {}) {
        we.log(`H5AndroidM postMessage, method: ${method}, params: ${JSON.stringify(params)}`);
        window?.h5am?.postMessage(
            JSON.stringify({
                method: method,
                params: params,
            })
        );
    }

    public static trackAdjustEvent(eventToken: string, cbParams: object, revenues: object): void {
        this.postMessage(METHOD_NAME.TRACK_ADJUST_EVENT, {
            eventToken: eventToken,
            cbParams: cbParams,
            revenues: revenues,
        });
    }

    public static trackAppsFlyerEvent(eventName: string, eventValues: { [key: string]: any } = {}): void {
        this.postMessage(METHOD_NAME.TRACK_APPSFLYER_EVENT, {
            eventName: eventName,
            eventValues: eventValues,
        });
    }

    public static openUrlByBrowser(url: string): void {
        this.postMessage(METHOD_NAME.OPEN_URL_BY_BROWSER, {
            url: url,
        });
    }

    public static setScreenOrientation(orientation: we.core.ScreenOrientation): void {
        this.postMessage(METHOD_NAME.SET_SCREEN_ORIENTATION, {
            orientation: orientation,
        });
    }
}
