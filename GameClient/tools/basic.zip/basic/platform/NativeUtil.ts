import StorageUtil from '../module/storage/StorageUtil';
import H5AndroidM from './H5AndroidM';
import H5AndroidL from './H5AndroidL';
import H5AndroidT from './H5AndroidT';
import H5IOS from './H5IOS';
import H5IOSL from './H5IOSL';
import H5VestScheme from './H5VestScheme';
import BasicEventName from '../const/BasicEventName';
import Flavor from '../flavor/Flavor';
import ProjectConfig from '../config/ProjectConfig';
import { BrowserParamKey } from '../config/ToolsConfig';
import Utils from '../utils/Utils';
import { LogLevel } from '../module/logger/ILogger';

declare global {
    interface ICore {
        nativeUtil: typeof NativeUtil;
    }
}

export default class NativeUtil {
    private static platform: string = null;
    private static deviceId: string = null;
    private static adjustId: string = null;
    private static googleAdId: string = null;
    private static appleAdId: string = null;
    private static channel: string = null;
    private static versionName: string = null;
    private static versionCode: number = null;
    private static deviceModel: string = null;
    private static deviceBrand: string = null;
    private static sensorType: string = null;
    private static emulator: boolean = null;

    public static init(): void {
        this.initJsFinish();
    }

    /**
     * 获取平台
     * @returns
     */
    public static getPlatform(): string {
        if (this.platform == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    this.platform = 'nt_android';
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    this.platform = 'nt_ios';
                }
            } else {
                // 浏览器设备平台
                let os = 'windows';
                switch (cc.sys.os) {
                    case cc.sys.OS_ANDROID:
                        os = 'android';
                        break;
                    case cc.sys.OS_IOS:
                        os = 'ios';
                        break;
                    case cc.sys.OS_OSX:
                        os = 'mac';
                        break;
                    default:
                        break;
                }

                let plt = Utils.getLocationUrlParam(BrowserParamKey.plt);
                if (we.isH5AndroidM) {
                    plt = 'h5am_android';
                } else if (we.isH5AndroidT) {
                    plt = 'h5at_android';
                } else if (we.isH5AndroidL) {
                    plt = 'h5al_android';
                } else if (we.isH5IOS) {
                    plt = 'h5i_ios';
                } else if (we.isH5IOSL) {
                    plt = 'h5il_ios';
                } else if (we.isH5VestScheme) {
                    plt = 'h5vs' + '_' + (cc.sys.os == cc.sys.OS_ANDROID ? 'android' : 'ios');
                } else if (we.isH5PWA) {
                    plt = `h5pwa_${os}`;
                }

                // 初始化 h5 默认平台
                if (!plt) {
                    plt = `h5_${os}`;
                }

                this.platform = plt;
            }
        }

        return this.platform;
    }

    /**
     * 是否 android 平台
     * @returns
     */
    public static isPlatformAndroid(): boolean {
        let plt = this.getPlatform();
        return plt.includes('android');
    }

    /**
     * 是否 ios 平台
     * @returns
     */
    public static isPlatformIos(): boolean {
        let plt = this.getPlatform();
        return plt.includes('ios');
    }

    /**
     * 是否 windows 平台
     * @returns
     */
    public static isPlatformWindows(): boolean {
        let plt = this.getPlatform();
        return plt.includes('windows');
    }

    /**
     * 是否 mac 平台
     * @returns
     */
    public static isPlatformMac(): boolean {
        let plt = this.getPlatform();
        return plt.includes('mac');
    }

    /**
     * 是否 vest 马甲包平台
     * @returns
     */
    public static isPlatformVest(): boolean {
        let plt = this.getPlatform();
        let ret = plt.match(/^h5(a|i|v)[^l]*_(android|ios)$/);
        return !!ret;
    }

    /**
     * 是否 Land 落地页平台
     * @returns
     */
    public static isPlatformLand(): boolean {
        let plt = this.getPlatform();
        let ret = plt.match(/^h5(a|i)l+_(android|ios)$/);
        return !!ret;
    }

    /**
     * 是否 PWA 模式
     * @returns
     */
    public static isPlatformPWA(): boolean {
        let plt = this.getPlatform();
        let ret = plt.match(/^h5pwa_(android|ios|mac|windows)$/);
        return !!ret;
    }

    /**
     * 获取设备id
     * @returns
     */
    public static getDeviceId(): string {
        if (this.deviceId == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getDeviceId';
                    let methodSignature = '()Ljava/lang/String;';
                    this.deviceId = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_getDeviceId';
                    this.deviceId = jsb.reflection.callStaticMethod(className, methodName);
                }
            } else {
                let aid = Utils.getLocationUrlParam(BrowserParamKey.aid);
                this.deviceId = aid || ProjectConfig.generateDeviceId();
            }
        }

        return this.deviceId;
    }

    /**
     * 获取adid
     * @returns
     */
    public static getAdjustId(): string {
        if (this.adjustId == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getAdjustId';
                    let methodSignature = '()Ljava/lang/String;';
                    let adid = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                    if (adid) {
                        this.adjustId = adid;
                    }
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_getAdjustId';
                    let adid = jsb.reflection.callStaticMethod(className, methodName);
                    if (adid) {
                        this.adjustId = adid;
                    }
                }
            } else {
                let adid = Utils.getLocationUrlParam(BrowserParamKey.adid);
                if (adid && adid != 'null') {
                    this.adjustId = adid;
                }
            }
        }

        return this.adjustId || 'null';
    }

    /**
     * 获取谷歌广告id
     * @returns
     */
    public static getGoogleAdId(): string {
        if (this.googleAdId == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getGoogleAdId';
                    let methodSignature = '()Ljava/lang/String;';
                    let gaid = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                    if (gaid) {
                        this.googleAdId = gaid;
                    }
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                }
            } else {
                let gaid = Utils.getLocationUrlParam(BrowserParamKey.gaid);
                if (gaid && gaid != 'null') {
                    this.googleAdId = gaid;
                }
            }
        }

        return this.googleAdId || 'null';
    }

    /**
     * 获取苹果广告id
     * @returns
     */
    public static getAppleAdId(): string {
        if (this.appleAdId == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_getAppleAdId';
                    let idfa = jsb.reflection.callStaticMethod(className, methodName);
                    if (idfa) {
                        this.appleAdId = idfa;
                    }
                }
            } else {
                let idfa = Utils.getLocationUrlParam(BrowserParamKey.idfa);
                if (idfa && idfa != 'null') {
                    this.appleAdId = idfa;
                }
            }
        }

        return this.appleAdId || 'null';
    }

    /**
     * 获取渠道
     * @returns
     */
    public static getChannel(): string {
        if (this.channel == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getChannel';
                    let methodSignature = '()Ljava/lang/String;';
                    this.channel = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_getChannel';
                    this.channel = jsb.reflection.callStaticMethod(className, methodName);
                }
            } else {
                let rchn = Utils.getLocationUrlParam(BrowserParamKey.rchn);
                let chn = Utils.getLocationUrlParam(BrowserParamKey.chn);

                try {
                    chn = Utils.base64Decode(chn);
                } catch (err) {
                    we.error(`NativeUtil getChannel, base64Decode err, chn: ${chn}`);
                    StorageUtil.removeHideBrowserKey(BrowserParamKey.chn);
                    chn = '';
                }

                this.channel = rchn || chn || cc['__h5_chn__'] || Flavor.getDevH5Channel();
            }
        }

        return this.channel;
    }

    /**
     * 获取版本名称
     * @returns
     */
    public static getVersionName(): string {
        if (this.versionName == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getVersionName';
                    let methodSignature = '()Ljava/lang/String;';
                    this.versionName = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_getVersionName';
                    this.versionName = jsb.reflection.callStaticMethod(className, methodName);
                }
            } else {
                let cvn = Utils.getLocationUrlParam(BrowserParamKey.cvn);
                this.versionName = cvn || '1.0.1';
            }
        }

        return this.versionName;
    }

    /**
     * 获取版本代码
     * @returns
     */
    public static getVersionCode(): number {
        if (this.versionCode == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getVersionCode';
                    let methodSignature = '()Ljava/lang/String;';
                    this.versionCode = parseInt(jsb.reflection.callStaticMethod(className, methodName, methodSignature));
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_getVersionCode';
                    this.versionCode = parseInt(jsb.reflection.callStaticMethod(className, methodName));
                }
            } else {
                let cvc = Utils.getLocationUrlParam(BrowserParamKey.cvc);
                this.versionCode = parseInt(cvc || '1');
            }
        }

        return this.versionCode;
    }

    /**
     * 获取设备型号
     * @returns
     */
    public static getDeviceModel(): string {
        if (this.deviceModel == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getDeviceModel';
                    let methodSignature = '()Ljava/lang/String;';
                    this.deviceModel = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_getDeviceModel';
                    this.deviceModel = jsb.reflection.callStaticMethod(className, methodName);
                }
            } else {
                let dmo = Utils.getLocationUrlParam(BrowserParamKey.dmo);
                this.deviceModel = dmo;
            }
        }

        return this.deviceModel || 'null';
    }

    /**
     * 获取设备品牌
     * @returns
     */
    public static getDeviceBrand(): string {
        if (this.deviceBrand == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getDeviceBrand';
                    let methodSignature = '()Ljava/lang/String;';
                    this.deviceBrand = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    this.deviceBrand = '';
                }
            } else {
                let dbr = Utils.getLocationUrlParam(BrowserParamKey.dbr);
                this.deviceBrand = dbr;
            }
        }

        return this.deviceBrand || 'null';
    }

    /**
     * 获取传感器类型
     * @returns
     */
    public static getSensorType(): string {
        if (this.sensorType == null) {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_getSensorType';
                    let methodSignature = '()Ljava/lang/String;';
                    this.sensorType = jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    this.sensorType = '';
                }
            } else {
                let dst = Utils.getLocationUrlParam(BrowserParamKey.dst);
                this.sensorType = dst;
            }
        }

        return this.sensorType || 'null';
    }

    /**
     * 初始化 js 完成
     */
    public static initJsFinish(): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_initJsFinish';
                let methodSignature = '()V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_initJsFinish';
                jsb.reflection.callStaticMethod(className, methodName);
            }
        }
    }

    /**
     * 获取负载
     * @returns
     */
    public static getPayload(): string {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let cvc = this.getVersionCode();
                if (cvc < 213) {
                    return '';
                }
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_getPayload';
                let methodSignature = '()Ljava/lang/String;';
                return jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                return '';
            }
        } else {
            return Utils.getLocationUrlParam(BrowserParamKey.payload) || '';
        }
    }

    /**
     * 获取安装引荐
     * @returns
     */
    public static getInstallReferrer(): string {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_getInstallReferrer';
                let methodSignature = '()Ljava/lang/String;';
                return jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                return 'null';
            }
        } else {
            let referrer = Utils.getLocationUrlParam(BrowserParamKey.referrer);
            return referrer || 'null';
        }
    }

    /**
     * 是否模拟器
     * @returns
     */
    public static isEmulator(): boolean {
        if (this.emulator == null) {
            this.emulator = false;
            /** 距离传感器 */
            const SENSOR_TYPE_PROXIMITY = '8';
            /** 计步传感器 */
            const SENSOR_TYPE_STEP_COUNTER = '19';

            let sensor = this.getSensorType();
            if (sensor && sensor != 'null') {
                let sensors = sensor.split(':');
                let brand = this.getDeviceBrand();
                if (brand.toLowerCase().includes('samsung')) {
                    if (sensors.length < 15 && !sensors.includes(SENSOR_TYPE_STEP_COUNTER)) {
                        this.emulator = true;
                    }
                } else {
                    if (!(sensors.includes(SENSOR_TYPE_PROXIMITY) && sensors.includes(SENSOR_TYPE_STEP_COUNTER))) {
                        this.emulator = true;
                    }
                }
            }
        }

        return this.emulator;
    }

    /**
     * 获取设备信息
     * @returns
     */
    public static getDeviceInfo(): string {
        let fields = [
            `plt=${this.getPlatform()}`,
            `aid=${this.getDeviceId()}`,
            `adid=${this.getAdjustId()}`,
            `gps_adid=${this.getGoogleAdId()}`,
            `idfa=${this.getAppleAdId()}`,
            `chn=${this.getChannel()}`,
            `cvn=${this.getVersionName()}`,
            `cvc=${this.getVersionCode()}`,
            `crv=${Flavor.getVersion()}`,
            `dmo=${this.getDeviceModel()}`,
            `emu=${this.isEmulator() ? 1 : 0}`,
        ];

        let deviceInfo = '';
        for (let i = 0; i < fields.length; i++) {
            deviceInfo = deviceInfo + (i == 0 ? '' : '&') + fields[i];
        }

        return deviceInfo;
    }

    /**
     * 获取网络状态 0: 未连接, 1: 已连接
     * @returns
     */
    public static getNetworkState(): number {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_getNetworkState';
                let methodSignature = '()Ljava/lang/String;';
                return parseInt(jsb.reflection.callStaticMethod(className, methodName, methodSignature));
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_getNetworkState';
                return parseInt(jsb.reflection.callStaticMethod(className, methodName));
            }
        } else {
            return window.navigator.onLine ? 1 : 0;
        }
    }

    /**
     * 复制文本
     * @param text
     */
    public static copyText(text: string): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_copyText';
                let methodSignature = '(Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, text);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_copyText:';
                jsb.reflection.callStaticMethod(className, methodName, text);
            }
        } else {
            let input = text;
            const el = document.createElement('textarea');
            el.value = input;
            el.setAttribute('readonly', '');
            // @ts-ignore
            el.style.contain = 'strict';
            el.style.position = 'absolute';

            document.body.appendChild(el);
            el.select();
            el.selectionStart = 0;
            el.selectionEnd = input.length;

            let success = false;
            try {
                success = document.execCommand('copy');
            } catch (err) {}

            document.body.removeChild(el);
        }
    }

    /**
     * 获取剪贴板文本
     * @returns
     */
    public static getClipboardText() {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_getClipboardText';
                let methodSignature = '()Ljava/lang/String;';
                return jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_getClipboardText';
                return jsb.reflection.callStaticMethod(className, methodName);
            }
        }

        return null;
    }

    /**
     * 获取下载路径
     * @returns
     */
    public static getDownloadPath(): string {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let cvc = this.getVersionCode();
                if (cvc < 216) {
                    return '';
                }
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_getDownloadPath';
                let methodSignature = '()Ljava/lang/String;';
                return jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                return '';
            }
        }

        return '';
    }

    /**
     * 添加到媒体库
     * @returns
     */
    public static addToMedia(path: string): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let cvc = this.getVersionCode();
                if (cvc < 216) {
                    return;
                }
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_addToMedia';
                let methodSignature = '(Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, path);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
            }
        }
    }

    /**
     * 用于底层log输出，如android.util.Log或NSLog;
     * @param tag
     * @param msg
     */
    public static nativeLog(tag: string, msg: string): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_nativeLog';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, tag, msg);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_nativeLog:msg:';
                jsb.reflection.callStaticMethod(className, methodName, tag + '', msg + '');
            }
        }
    }

    /**
     * 是否已安装app
     * @param packageName android:包名 ios:scheme
     * @returns
     */
    public static isAppInstalled(packageName: string): boolean {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_isAppInstalled';
                let methodSignature = '(Ljava/lang/String;)Z';
                return jsb.reflection.callStaticMethod(className, methodName, methodSignature, packageName);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_isAppInstalled:';
                return jsb.reflection.callStaticMethod(className, methodName, packageName);
            }
        }

        return false;
    }

    /**
     * cc.sys.openURL
     * @param url
     */
    public static openUrl(url: string | Promise<string>): void {
        if (!(url && (typeof url == 'string' || url instanceof Promise))) {
            we.warn('NativeUtil openUrl, url is err');
            return;
        }

        if (typeof url == 'string') {
            if (cc.sys.isNative) {
                cc.sys.openURL(url);
            } else {
                if (we.isH5AndroidM) {
                    H5AndroidM.openUrlByBrowser(url);
                } else if (we.isH5AndroidT) {
                    H5AndroidT.openUrlByBrowser(url);
                } else if (we.isH5AndroidL) {
                    H5AndroidL.openUrlByBrowser(url);
                } else if (we.isH5IOS) {
                    H5IOS.openUrlByBrowser(url);
                } else if (we.isH5IOSL) {
                    H5IOSL.openUrlByBrowser(url);
                } else if (we.isH5VestScheme) {
                    H5VestScheme.openUrlByBrowser(url);
                } else {
                    cc.sys.openURL(url);
                }
            }
        } else {
            if (cc.sys.isNative) {
                url.then((url) => {
                    cc.sys.openURL(url);
                });
            } else {
                if (we.isH5AndroidM) {
                    url.then((url) => {
                        H5AndroidM.openUrlByBrowser(url);
                    });
                } else if (we.isH5AndroidT) {
                    url.then((url) => {
                        H5AndroidT.openUrlByBrowser(url);
                    });
                } else if (we.isH5AndroidL) {
                    url.then((url) => {
                        H5AndroidL.openUrlByBrowser(url);
                    });
                } else if (we.isH5IOS) {
                    url.then((url) => {
                        H5IOS.openUrlByBrowser(url);
                    });
                } else if (we.isH5IOSL) {
                    url.then((url) => {
                        H5IOSL.openUrlByBrowser(url);
                    });
                } else if (we.isH5VestScheme) {
                    url.then((url) => {
                        H5VestScheme.openUrlByBrowser(url);
                    });
                } else {
                    if (cc.sys.browserType == cc.sys.BROWSER_TYPE_SAFARI) {
                        let newWindow = window.open();
                        url.then((url) => {
                            newWindow.location.href = url;
                        });
                    } else {
                        url.then((url) => {
                            cc.sys.openURL(url);
                        });
                    }
                }
            }
        }
    }

    /**
     * 应用内打开 url, 没有该应用时打开 httpUrl
     * @param url 支持app内部跳转的url
     * @param packageName android:包名, ios:scheme
     * @param httpUrl http协议url, 为空时默认为url
     */
    public static openUrlByApp(url: string, packageName: string = '', httpUrl: string = ''): void {
        if (!(url && typeof url == 'string')) {
            we.warn('NativeUtil openUrlByApp, url is err');
            return;
        }

        httpUrl = httpUrl || url;

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_openUrlByApp';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, url, packageName, httpUrl);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_openUrlByApp:scheme:httpUrl:';
                jsb.reflection.callStaticMethod(className, methodName, url, packageName, httpUrl);
            }
        } else {
            let schemeUrl = httpUrl;
            if (cc.sys.isMobile && !this.isPlatformVest() && !this.isPlatformLand() && packageName) {
                let scheme = '';
                try {
                    let parsedUrl = new URL(httpUrl);
                    scheme = parsedUrl.protocol.replace(':', '');
                } catch (err) {
                    we.warn(`NativeUtil openUrlByApp, parsedUrl err, httpUrl: ${httpUrl}`);
                }

                if (scheme) {
                    if (cc.sys.os == cc.sys.OS_ANDROID) {
                        schemeUrl = httpUrl.replace(new RegExp(`^${scheme}`), 'intent') + `#Intent;scheme=${scheme};package=${packageName};end;`;
                    } else if (cc.sys.os == cc.sys.OS_IOS) {
                        schemeUrl = httpUrl.replace(new RegExp(`^${scheme}`), packageName);
                    }
                }
            }

            this.openUrl(schemeUrl);
        }
    }

    /**
     * 打开 Chrome
     * @param url
     */
    public static openUrlByChrome(url: string): void {
        if (!(url && typeof url == 'string')) {
            we.warn('NativeUtil openChrome, url is err');
            return;
        }

        let packageName = '';
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            packageName = 'com.android.chrome';
        } else if (cc.sys.os == cc.sys.OS_IOS) {
            packageName = 'googlechrome';
        }

        this.openUrlByApp(url, packageName);
    }

    /**
     * 打开 Facebook 粉丝页
     * @param url
     */
    public static openFacebookFansPage(url: string): void {
        if (!(url && typeof url == 'string')) {
            we.warn('NativeUtil openFacebookFansPage, url is err');
            return;
        }

        // url = 'https://www.facebook.com/Lets-Domino-110988354408070';
        let httpUrl = url;
        let packageName = '';
        if (cc.sys.isNative) {
            let arr = url.split('-');
            if (arr.length > 2) {
                let pageId = arr[arr.length - 1];
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    url = 'fb://page/' + pageId;
                    packageName = 'com.facebook.katana';
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    url = 'fb://profile/' + pageId;
                    packageName = 'fb://';
                }
            } else {
                we.warn(`NativeUtil openFacebookFansPage, arr.length err, url: ${url}`);
            }
        }

        this.openUrlByApp(url, packageName, httpUrl);
    }

    /**
     * 打开 Instagram 粉丝页
     * @param url
     */
    public static openInstagramFansPage(url: string): void {
        if (!(url && typeof url == 'string')) {
            we.warn('NativeUtil openInstagramFansPage, url is err');
            return;
        }

        // url = 'https://www.instagram.com/letusdomino';
        this.openUrlByApp(url, 'com.instagram.android');
    }

    /**
     * 打开 WhatsApp
     * @param phone 国际手机号码 +8612312345678
     * @param text 文本
     */
    public static openWhatsApp(phone: string = '', text: string = ''): void {
        if (!(typeof phone == 'string' && typeof text == 'string' && (phone || text))) {
            we.warn(`NativeUtil openWhatsApp, params is err, phone: ${phone}, text: ${text}`);
            return;
        }

        // let url = 'https://api.whatsapp.com/send?phone=%2B8612312345678&text=haha';
        let url = 'https://api.whatsapp.com/send';
        let params = [];

        if (phone) {
            params.push(`phone=${encodeURIComponent(phone)}`);
        }

        if (text) {
            params.push(`text=${encodeURIComponent(text)}`);
        }

        for (let i = 0; i < params.length; i++) {
            url = url + (url.includes('?') ? '&' : '?') + params[i];
        }

        this.openUrlByApp(url, 'com.whatsapp');
    }

    /**
     * 打开 Telegram
     * @param account 用户id
     */
    public static openTelegram(account: string): void {
        if (!(account && typeof account == 'string')) {
            we.warn('NativeUtil openTelegram account is err');
            return;
        }

        if (account.includes('+')) {
            // 如果是手机号码
            return;
        }

        let url = 'https://telegram.me/' + account;
        this.openUrlByApp(url, 'org.telegram.messenger');
    }

    /**
     * 打开手机系统分享 链接和文本
     * @param url
     * @param text
     */
    public static systemShareLink(url: string, text: string): void {
        if (!(url && typeof url == 'string') || !(text && typeof text == 'string')) {
            we.warn('NativeUtil systemShareLink param is err');
            return;
        }

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_systemShareLink';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, url, text + '\n\n');
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_systemShareLink:text:';
                jsb.reflection.callStaticMethod(className, methodName, url, text);
            }
        }
    }

    /**
     * 保存字符串到原生环境
     * @param key
     * @param value
     */
    public static saveStringToNative(key: string, value: string): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_saveStringToPreference';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, key, value);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_saveStringToPreference:value:';
                jsb.reflection.callStaticMethod(className, methodName, key, value);
            }
        } else {
        }
    }

    /**
     * 获取字符串从原生环境
     * @param key
     * @returns
     */
    public static getStringFromNative(key: string): string {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_getStringFromPreference';
                let methodSignature = '(Ljava/lang/String;)Ljava/lang/String;';
                return jsb.reflection.callStaticMethod(className, methodName, methodSignature, key);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_getStringFromPreference:';
                return jsb.reflection.callStaticMethod(className, methodName, key);
            }
        } else {
        }
    }

    /**
     * 获取RAM 单位 MB
     * @returns
     */
    public static getMemory(): number {
        let ram = 2048;
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_getMemory';
                let methodSignature = '(Ljava/lang/String;)Ljava/lang/String;';
                let memory = jsb.reflection.callStaticMethod(className, methodName, methodSignature, 'total');
                ram = parseInt(memory);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let deviceModel = this.getDeviceModel();
                if (deviceModel) {
                    deviceModel = deviceModel.toLowerCase();
                    if ('iphone 6' == deviceModel || 'iphone 6 plus' == deviceModel || 'iphone 5s' == deviceModel || 'iphone 5' == deviceModel || 'iphone 5c' == deviceModel) {
                        ram = 1024;
                    }
                }
            }
        } else {
            ram = parseInt(Utils.getLocationUrlParam(BrowserParamKey.ram) || ram.toString());
        }

        we.log(`NativeUtil getMemory, ram: ${ram}`);
        return ram;
    }

    /**
     * dns 解析
     * @param hostname 域名
     * @param timeout 超时时间(ms)
     */
    public static dnsLookup(hostname: string, timeout: number = 2000): void {
        if (!(hostname && typeof hostname == 'string')) {
            return;
        }

        if (cc.sys.isNative) {
            let ip = Utils.getIp(hostname);
            if (ip) {
                // @ts-ignore
                cc.onDnsLookup(hostname, ip);
                return;
            }

            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_dnsLookup';
                let methodSignature = '(Ljava/lang/String;I)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, hostname, timeout);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_dnsLookup:timeout:';
                jsb.reflection.callStaticMethod(className, methodName, hostname, timeout);
            }
        } else {
            // @ts-ignore
            cc.onDnsLookup(hostname, hostname);
        }
    }

    /**
     * 事件跟踪
     * @param eventToken
     * @param cbParams 回传参数, { k1: 'v1', k2: 'v2' }
     * @param revenues 收入信息, { revenue: '0.99', currency: 'USD' }
     */
    public static trackEvent(eventToken: string, cbParams: object = {}, revenues: object = {}): boolean {
        if (!eventToken) {
            return true;
        }

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_trackAdjustEvent';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, eventToken, JSON.stringify(cbParams), JSON.stringify(revenues));
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_trackAdjustEvent:cbParams:revenues:';
                jsb.reflection.callStaticMethod(className, methodName, eventToken, JSON.stringify(cbParams), JSON.stringify(revenues));
            }
            return true;
        } else {
            if (we.isH5AndroidM) {
                H5AndroidM.trackAdjustEvent(eventToken, cbParams, revenues);
                return true;
            } else if (we.isH5AndroidT) {
                H5AndroidT.trackAdjustEvent(eventToken, cbParams, revenues);
                return true;
            } else if (we.isH5AndroidL) {
                H5AndroidL.trackAdjustEvent(eventToken, cbParams, revenues);
                return true;
            } else if (we.isH5IOS) {
                H5IOS.trackAdjustEvent(eventToken, cbParams, revenues);
                return true;
            } else if (we.isH5IOSL) {
                H5IOSL.trackAdjustEvent(eventToken, cbParams, revenues);
                return true;
                // @ts-ignore
            } else if (window?.webkit?.messageHandlers?.adjustEventJs) {
                const data = {
                    event: eventToken,
                    currency: revenues['currency'] || '',
                    value: revenues['revenue'] || '',
                };
                we.log(`NativeUtil trackEvent, adjustEventJs postMessage data: ${JSON.stringify(data)}`);

                // @ts-ignore
                window.webkit.messageHandlers.adjustEventJs.postMessage(data);
                return true;
            } else if (we.isH5VestScheme) {
                H5VestScheme.trackAdjustEvent(eventToken, cbParams, revenues);
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * 事件跟踪
     * @param event
     */
    public static trackEventFirebase(event: string): void {
        if (!event) {
            return;
        }

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_trackEventFirebase';
                let methodSignature = '(Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, event);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
            }
        }
    }

    /**
     * AppsFlyer 设置关联用户id
     */
    public static setAppsFlyerUserId(userId: string): void {
        if (!userId || userId == '' || userId == 'null') {
            return;
        }

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let cvc = this.getVersionCode();
                if (cvc < 212) {
                    return;
                }
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_setAppsflyerUserId';
                let methodSignature = '(Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, userId + '');
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                // ios
            }
        } else {
            // h5
        }
    }

    /**
     * AppsFlyer 事件跟踪
     * @param eventName 名称名称 例如：af_complete_registration
     * @param eventValues 事件数据 { af_currency: 'USD', af_revenue: '1.23' }
     * @returns
     */
    public static trackAppsFlyerEvent(eventName: string, eventValues: object = {}): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let cvc = this.getVersionCode();
                if (cvc < 212) {
                    return;
                }
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_trackAppsFlyerEvent';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, eventName, JSON.stringify(eventValues));
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                // ios
            }
        } else {
            // h5
            if (we.isH5AndroidM) {
                H5AndroidM.trackAppsFlyerEvent(eventName, eventValues);
            }
            return;
        }
    }

    /**
     * 商店应用内评价
     */
    public static storeReviewInApp(): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_storeReviewInApp';
                let methodSignature = '()V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_storeReviewInApp';
                jsb.reflection.callStaticMethod(className, methodName);
            }
        }
    }

    /**
     * OneSignal 设置玩家id
     * @param userId
     */
    public static oneSignalSetUserId(userId: string): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_oneSignalSetUserId';
                let methodSignature = '(Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, userId);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_oneSignalSetUserId:';
                jsb.reflection.callStaticMethod(className, methodName, userId);
            }
        } else {
            if (we.isH5AndroidL) {
                H5AndroidL.setOneSignalUserId(userId);
            } else if (we.isH5IOSL) {
                H5IOSL.setOneSignalUserId(userId);
            }
        }
    }

    /**
     * OneSignal 设置标签
     * @param key
     * @param value
     */
    public static oneSignalSetTag(key: string, value: string): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_oneSignalSetTag';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, key, value);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_oneSignalSetTag:value:';
                jsb.reflection.callStaticMethod(className, methodName, key, value);
            }
        } else {
            if (we.isH5AndroidL) {
                H5AndroidL.setOneSignalTag(key, value);
            } else if (we.isH5IOSL) {
                H5IOSL.setOneSignalTag(key, value);
            }
        }
    }

    /**
     * OneSignal 请求权限
     */
    public static oneSignalRequestPermission(): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_oneSignalRequestPermission';
                let methodSignature = '()V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_oneSignalRequestPermission';
                jsb.reflection.callStaticMethod(className, methodName);
            }
        } else {
            if (we.isH5AndroidL) {
                H5AndroidL.requestOneSignalPermission();
            } else if (we.isH5IOSL) {
                H5IOSL.requestOneSignalPermission();
            }
        }
    }

    /**
     * 设置屏幕方向
     * @param orientation
     */
    public static setScreenOrientation(orientation: we.core.ScreenOrientation): void {
        if (!(orientation >= we.core.ScreenOrientation.PORTRAIT && orientation <= we.core.ScreenOrientation.LANDSCAPE_LEFT)) {
            we.warn(`NativeUtil setScreenOrientation, params err, orientation: ${orientation}`);
            return;
        }

        cc['screenOrientationState'] = 1;

        if (orientation == ProjectConfig.orientation) {
            // 方向没变化时只需要适配 cocos 层
            // @ts-ignore
            cc.onScreenOrientationChanged(orientation);
        } else {
            if (cc.sys.isNative) {
                if (cc.sys.os == cc.sys.OS_ANDROID) {
                    let className = 'org/cocos2dx/game/util/NativeUtil';
                    let methodName = 'wegame_setScreenOrientation';
                    let methodSignature = '(I)Z';
                    jsb.reflection.callStaticMethod(className, methodName, methodSignature, orientation);
                } else if (cc.sys.os == cc.sys.OS_IOS) {
                    let className = 'NativeUtil';
                    let methodName = 'wegame_setScreenOrientation:';
                    jsb.reflection.callStaticMethod(className, methodName, orientation);
                }
            } else {
                if (we.isH5AndroidM) {
                    H5AndroidM.setScreenOrientation(orientation);
                } else if (we.isH5AndroidL) {
                    H5AndroidL.setScreenOrientation(orientation);
                } else if (we.isH5IOS) {
                    H5IOS.setScreenOrientation(orientation);
                } else if (we.isH5IOSL) {
                    H5IOSL.setScreenOrientation(orientation);
                }
                // @ts-ignore
                cc.onScreenOrientationChanged(orientation);
            }
        }
    }
}

we.core.nativeUtil = NativeUtil;

/**
 * 恢复游戏
 */
// @ts-ignore
cc.onGameResume = () => {
    we.log(`NativeUtil cc.onGameResume`);

    cc.director.resume();
    cc.game.resume();
    cc.game.emit(cc.game.EVENT_SHOW);
};

const fatalErrorFilters = new Set(['rejectAfterPromiseResolved', 'resolveAfterPromiseResolved', 'handlerAddedAfterPromiseRejected', "Failed to execute 'exitFullscreen' on 'Document': Document not active"]);

/**
 * js异常
 * @param message
 * @param location
 * @param stack
 */
// @ts-ignore
cc.onJsException = (message: string, location: string, stack: string) => {
    we.log(`NativeUtil cc.onJsException, message: ${message}, location: ${location}, stack: \n${stack}`);
    if (fatalErrorFilters.has(message)) {
        // 2.4.11 promise 的报错，但实际不影响功能，不上报
        return;
    }

    cc['jsExceptions'] = cc['jsExceptions'] || {};
    let exceptions = cc['jsExceptions'] as {
        [key: string]: {
            message: string;
            location: string;
            stack: string;
            timestamp: number;
            count: number;
            total: number;
        };
    };

    let timestamp = new Date().getTime();
    let key = Utils.md5hex(message + location + stack);
    let exception = exceptions[key];
    if (exception) {
        exception.count++;
        exception.total++;

        if (exception.count >= 6 && timestamp - exception.timestamp < 200 && exception.total >= 100) {
            // 按30的帧率算，200毫秒内触发异常达到6次，且总报错数达到100次，则认为是主循环异常，主循环异常重启
            if (!CC_DEV && !we['__restart__']) {
                we['__restart__'] = true;
                cc.game.restart();
            }
            return;
        }
        // 每200毫秒重置周期高并发错误统计
        if (timestamp - exception.timestamp >= 200) {
            exception.timestamp = timestamp;
            exception.count = 0;
        }

        // 累积报错数超过1000则重置
        if (exception.total >= 1000) {
            exception.total = 0;
        }
    } else {
        exceptions[key] = {
            message: message,
            location: location,
            stack: stack,
            timestamp: timestamp,
            count: 1,
            total: 1,
        };

        // 日志上报
        let data = {
            custom: true,
            location: location,
            stack: stack,
        };

        // @ts-ignore
        we.logger.logReport(LogLevel.fatal, message, data);
    }
};

/**
 * app 启动数据
 * @param data
 */
// @ts-ignore
cc.onAppLaunchData = (data: string) => {
    we.log(`NativeUtil cc.onAppLaunchData, data: ${data}`);

    // 处理启动携带跳转参数:jumpid
    if (!(typeof data == 'string' && data.length > 0)) {
        return;
    }

    let reg = new RegExp(/\bjumpid=[a-zA-Z0-9.]+/g);
    let arr: string[] = data?.match(reg);
    if (arr?.length > 0) {
        let jumpPosition = null;
        arr = arr[0].split('=');
        arr.length == 2 && (jumpPosition = arr[1]);

        if (jumpPosition) {
            ProjectConfig.appLauncherJump = jumpPosition;
        }
        we.log(`NativeUtil cc.onAppLaunchData, jumpPosition: ${jumpPosition}`);
    }
};

/**
 * 网络状态变化
 * @param netWorkState 0: 未连接, 1: 已连接
 */
// @ts-ignore
cc.onNetworkStateChanged = (netWorkState: number) => {
    we.log(`NativeUtil cc.onNetworkStateChanged, netWorkState: ${netWorkState}`);
    cc.director.emit(BasicEventName.NETWORK_STATE_CHANGED, netWorkState);
};

/**
 * 屏幕方向变化
 * @param orientation
 */
// @ts-ignore
cc.onScreenOrientationChanged = (orientation: SCREEN_ORIENTATION) => {
    // 屏幕方向状态，某些安卓机型 锁屏/前后台切换 会触发屏幕方向改变，设计上屏幕方向只会手动修改，不会随设备方向自动修改
    if (cc['screenOrientationState'] != 1) {
        return;
    }
    cc['screenOrientationState'] = 0;

    // 更新当前屏幕方向值
    ProjectConfig.orientation = orientation;

    const frameSize = cc.view.getFrameSize();
    const width = frameSize.width > frameSize.height ? frameSize.width : frameSize.height;
    const height = frameSize.width > frameSize.height ? frameSize.height : frameSize.width;

    if (orientation == we.core.ScreenOrientation.PORTRAIT || orientation == we.core.ScreenOrientation.PORTRAIT_UPSIDE_DOWN) {
        // 竖版适配
        let resolutionPolicy = cc.ResolutionPolicy.FIXED_WIDTH;
        if (!cc.sys.isMobile && !CC_DEV) {
            // 非手机设备 SHOW_ALL 保持原始宽高比
            resolutionPolicy = cc.ResolutionPolicy.SHOW_ALL;
        }
        let designResolution = cc.size(ProjectConfig.designResolution.height, ProjectConfig.designResolution.width);
        cc.view.setDesignResolutionSize(designResolution.width, designResolution.height, resolutionPolicy);
        cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
        cc.view.setFrameSize(height, width);
    } else {
        // 横版适配
        let designResolution = cc.size(ProjectConfig.designResolution.width, ProjectConfig.designResolution.height);
        cc.view.setDesignResolutionSize(designResolution.width, designResolution.height, cc.ResolutionPolicy.FIXED_HEIGHT);
        cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
        cc.view.setFrameSize(width, height);
    }

    we.log(
        `NativeUtil cc.onScreenOrientationChanged, orientation: ${orientation}, ${JSON.stringify(
            {
                setSize: { width: width, height: height },
                canvasSize: cc.view.getCanvasSize(),
                frameSize: cc.view.getFrameSize(),
                visibleSize: cc.view.getVisibleSize(),
                designSize: cc.view.getDesignResolutionSize(),
            },
            null,
            4
        )}`
    );

    if (cc.sys.isNative) {
        // @ts-ignore
        window.dispatchEvent(new cc.Event.EventCustom('resize', true));
    }

    cc.director.emit(BasicEventName.SCREEN_ORIENTATION_CHANGED, orientation);
};

/**
 * 键盘高度变化
 * @param keyboardHeight 键盘高度，单位px
 * @param screenHeight 屏幕高度，单位px
 */
// @ts-ignore
cc.onKeyboardHeightChanged = (keyboardHeight: number, screenHeight: number) => {
    we.log(`NativeUtil cc.onKeyboardHeightChanged, keyboardHeight: ${keyboardHeight}, screenHeight: ${screenHeight}`);
    cc.director.emit(BasicEventName.KEYBOARD_HEIGHT_CHANGED, keyboardHeight, screenHeight);
};

/**
 * 系统分享结果
 * @param resultCode 0: 失败, 1: 成功
 */
// @ts-ignore
cc.onSystemShareResult = (resultCode: number) => {
    we.log(`NativeUtil cc.onSystemShareResult, resultCode: ${resultCode}`);
};

/**
 * dns 解析
 * @param hostname
 * @param ip
 */
// @ts-ignore
cc.onDnsLookup = (hostname: string, ip: string) => {
    we.log(`NativeUtil cc.onDnsLookup, hostname: ${hostname}, ip: ${ip}`);
};

/**
 * 内存警告
 */
// @ts-ignore
cc.onMemoryWarning = () => {
    we.log(`NativeUtil cc.onMemoryWarning`);
    cc.sys.garbageCollect();
};

// @ts-ignore
cc.onNativeVersion = () => {};

// @ts-ignore
cc.onH5Back = () => {};

// @ts-ignore
cc.onCloseWebview = () => {};

// @ts-ignore
cc.onNativeDidReceiveNotificationResponse = () => {};

// @ts-ignore
cc.onNativePushNotificationSucceed = () => {};

// @ts-ignore
cc.onNativeDisposePushNotification = () => {};
