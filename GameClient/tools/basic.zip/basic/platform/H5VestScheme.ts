const METHOD_NAME = {
    TRACK_ADJUST_EVENT: 'trackAdjustEvent',
    OPEN_URL_BY_BROWSER: 'openUrlByBrowser',
};

export default class H5VestScheme {
    private static msgList: string[] = [];
    private static msgTimer: any = null;

    private static postMessage(method: string, params: object = {}) {
        we.log(`H5VestScheme postMessage, method: ${method}, params: ${JSON.stringify(params)}`);
        let url =
            'h5vs://' +
            encodeURIComponent(
                JSON.stringify({
                    method: method,
                    params: params,
                })
            );

        if (cc.sys.os == cc.sys.OS_IOS) {
            // ios webview 对连续跳转的限制, 所以用延迟队列
            this.msgList.push(url);
            this.dispatch();
        } else {
            we.log(`H5VestScheme postMessage, url: ${url}`);
            document.location = url;
        }
    }

    private static dispatch() {
        if (this.msgTimer != null) {
            return;
        }

        this.msgTimer = setTimeout(() => {
            this.msgTimer = null;
            if (this.msgList.length > 0) {
                this.dispatch();
            }
        }, 500);

        let url = this.msgList.shift();
        if (url) {
            we.log(`H5VestScheme postMessage dispatch, url: ${url}`);
            document.location = url;
        }
    }

    public static trackAdjustEvent(eventToken: string, cbParams: object, revenues: object): void {
        this.postMessage(METHOD_NAME.TRACK_ADJUST_EVENT, {
            eventToken: eventToken,
            cbParams: cbParams,
            revenues: revenues,
        });
    }

    public static openUrlByBrowser(url: string): void {
        this.postMessage(METHOD_NAME.OPEN_URL_BY_BROWSER, {
            url: url,
        });
    }
}
