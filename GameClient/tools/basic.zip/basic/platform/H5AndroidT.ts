declare global {
    namespace h5at {
        function postMessage(message: string);
    }
}

const METHOD_NAME = {
    TRACK_ADJUST_EVENT: 'trackAdjustEvent',
    OPEN_URL_BY_BROWSER: 'openUrlByBrowser',
};

export default class H5AndroidT {
    private static postMessage(method: string, params: object = {}) {
        we.log(`H5AndroidT postMessage, method: ${method}, params: ${JSON.stringify(params)}`);
        window?.h5at?.postMessage(
            JSON.stringify({
                method: method,
                params: params,
            })
        );
    }

    public static trackAdjustEvent(eventToken: string, cbParams: object, revenues: object): void {
        this.postMessage(METHOD_NAME.TRACK_ADJUST_EVENT, {
            eventToken: eventToken,
            cbParams: cbParams,
            revenues: revenues,
        });
    }

    public static openUrlByBrowser(url: string): void {
        // this.postMessage(METHOD_NAME.OPEN_URL_BY_BROWSER, {
        //     url: url,
        // });
        window.open(url, '_blank');
    }
}
