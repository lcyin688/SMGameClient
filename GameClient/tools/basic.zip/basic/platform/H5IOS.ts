declare global {
    namespace webkit {
        namespace messageHandlers {
            namespace h5i {
                function postMessage(message: string);
            }
        }
    }
}

const METHOD_NAME = {
    TRACK_ADJUST_EVENT: 'trackAdjustEvent',
    OPEN_URL_BY_BROWSER: 'openUrlByBrowser',
    SET_SCREEN_ORIENTATION: 'setScreenOrientation',
};

export default class H5IOS {
    private static postMessage(method: string, params: object = {}) {
        we.log(`H5IOS postMessage, method: ${method}, params: ${JSON.stringify(params)}`);
        window?.webkit?.messageHandlers?.h5i?.postMessage(
            JSON.stringify({
                method: method,
                params: params,
            })
        );
    }

    public static trackAdjustEvent(eventToken: string, cbParams: object, revenues: object): void {
        this.postMessage(METHOD_NAME.TRACK_ADJUST_EVENT, {
            eventToken: eventToken,
            cbParams: cbParams,
            revenues: revenues,
        });
    }

    public static openUrlByBrowser(url: string): void {
        this.postMessage(METHOD_NAME.OPEN_URL_BY_BROWSER, {
            url: url,
        });
    }

    public static setScreenOrientation(orientation: we.core.ScreenOrientation): void {
        this.postMessage(METHOD_NAME.SET_SCREEN_ORIENTATION, {
            orientation: orientation,
        });
    }
}
