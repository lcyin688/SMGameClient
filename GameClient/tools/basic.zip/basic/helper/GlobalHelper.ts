declare global {
    interface ICore {
        GlobalHelper: typeof GlobalHelper;
    }
}

type singleRunType<T extends (...args: any[]) => any> = { run: (...args: Parameters<T>) => ReturnType<T>; ok: () => singleRunType<T> };

export class GlobalHelper {
    /**
     * 设置一个可调用一次的函数
     * @param runFunc 需要调用的函数
     * @returns `{ run: (...args: Parameters<T>) => ReturnType<T>; ok: () => void }`
     * ```
     * const test = EtxHelper.singleRun(() => {
     *     console.log("运行一次")
     * })
     *
     * test.ok?.(); // 调用ok 让run函数生效
     * test.run?.(); // 必须先调用一次OK
     * // 打印 运行一次
     */
    static singleRun<T extends (...args: any[]) => any>(runFunc: T) {
        let single: singleRunType<T> = {
            run: null,
            ok: null,
        };

        const run = (...args: Parameters<T>) => {
            const result = runFunc(...args);
            single.run = null;
            single.ok = null;
            return result;
        };

        // @ts-ignore
        single.run = () => {
            // 如果调用OK之前调用了run则会直接清除所有调用
            single.ok = null;
            single.run = null;
        };

        single.ok = () => {
            single.ok = null;
            single.run = run;
            return single;
        };

        return single;
    }
}

we.core.GlobalHelper = GlobalHelper;
