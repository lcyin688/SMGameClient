import { URLHelper } from './URLHelper';

declare global {
    interface ICore {
        BrowserHelper: typeof BrowserHelper;
    }
}

export class BrowserHelper {
    /**
     * 关闭html页面定制的引擎之前显示的loading效果
     * @param duration 渐隐时长【秒】
     * @param immediateHide
     * @param elementId
     */
    public static hideLoadingDiv(duration: number = 0.1, immediateHide: boolean = false, elementId: string = 'loadingDiv') {
        if (!cc.sys.isBrowser) {
            return;
        }

        const loadDiv = document.getElementById(elementId) ?? document.getElementById('splash');
        if (loadDiv) {
            if (immediateHide) {
                loadDiv.style.display = 'none';
            } else {
                loadDiv.style.opacity = '0';
                loadDiv.style.transition = `opacity ${duration}s`;
                setTimeout(() => {
                    loadDiv.style.display = 'none';
                    loadDiv.remove();
                }, duration);
            }
        }
    }

    /**
     * 查询url参数
     * @param key
     */
    public static getParam(key: string): string {
        if (window == null || window.location == null) {
            return;
        }
        return URLHelper.getParam(key, window.location.search);
    }

    /**
     * 设置当前 URL 的参数（修改历史记录，不会刷新当前网页）
     * @param param 参数
     */
    public static setParam(param: string): void {
        if (window == null || window.history == null) {
            return;
        }
        window?.history?.replaceState?.({}, null, `?${param}`);
    }

    /**
     * 清除当前 URL 的参数（修改历史记录，不会刷新当前网页）
     */
    public static clearParam(): void {
        window?.history?.replaceState?.({}, null, '.');
    }

    /** 页面内跳转 */
    public static openURL(url: string, mode: 'Current' | 'Parent' | 'Top' = 'Top') {
        switch (mode) {
            case 'Current':
                window?.location?.assign?.(url);
                break;
            case 'Parent':
                parent?.location?.assign?.(url);
                break;
            case 'Top':
                top?.location?.assign?.(url);
                break;
            default:
                break;
        }
    }

    /** 刷新页面 */
    public static refreshURL() {
        window?.location?.reload?.();
    }
}

we.core.BrowserHelper = BrowserHelper;
