import { StringHelper } from './StringHelper';
import { RandomHelper, RandomStrType } from '../module/random/RandomHelper';

const UrlPattern = /(ht|f)tp(s?):\/\/[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*(:(0-9)*)*(\/?)([a-zA-Z0-9\-.?,'/\\+&%$#_]*)?/;
const IpPattern = /^((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3}$/;

/**
 * URL处理
 */
export class URLHelper {
    static check(url: string) {
        return UrlPattern.test(url);
    }

    static isIp(ip: string) {
        return IpPattern.test(ip);
    }

    /**
     * 查询url参数
     * @param key
     * @param url
     */
    static getParam(key: string, url: string): string {
        const reg = new RegExp('(^|&)' + key + '=([^&]*)(&|$)', 'i');
        const r = url.substring(1).match(reg);
        if (r !== null) {
            return decodeURIComponent(r[2]);
        }
        return null;
    }

    static getParamObject<T>(url: string): T {
        const keyValues = url.split('&');
        const retObj: any = {};
        for (let i = 0; i < keyValues.length; i++) {
            const strings = keyValues[i].split('=');
            if (strings[1] === 'undefined') {
                continue;
            }
            retObj[decodeURIComponent(strings[0])] = decodeURIComponent(strings[1]);
        }
        return retObj;
    }

    /**
     * 设置当前 URL 的参数（修改历史记录，不会刷新当前网页）
     * @param param 参数
     */
    public static addLParam(key: string, value: string): void {}

    /**
     * 设置当前 URL 的参数（修改历史记录，不会刷新当前网页）
     * @param param 参数
     */
    public static delParam(key: string): void {}

    /**
     * 对gameToken进行编码
     * @param token gameToken
     */
    public static encodeGameToken(token: string) {
        if (token.length < 96) {
            throw 'Game Token Error';
        }
        const secretKey = RandomHelper.randomString(4, RandomStrType.string);
        for (let i = 0; i < secretKey.length; i++) {
            token = StringHelper.insertStr(token, 23 * (i + 1) + 3, secretKey[i]);
        }
        return token;
    }

    /**
     * 对gameToken进行解码
     * @param token gameToken
     */
    public static decodeGameToken(token: string) {
        if (token.length < 96) {
            throw 'Game Token Error';
        }
        for (let i = 0; i < 4; i++) {
            token = StringHelper.removeStr(token, 23 * (i + 1) + 3 - i);
        }
        return token;
    }
}
