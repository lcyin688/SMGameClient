declare global {
    interface ICore {
        ViewHelper: typeof ViewHelper;
    }
}

/**
 * view 工具函数
 */
export class ViewHelper {
    /** 等待 */
    /**
     * 等待一定时间后执行回调函数
     *
     * @param com cc.Component 组件对象
     * @param time 等待时间（单位：秒）
     * @returns 返回一个 Promise 对象
     */
    public static wait(com: cc.Component, time: number) {
        return new Promise((t) => {
            com.scheduleOnce(() => {
                t(null);
            }, time);
        });
    }

    /**
     * 如果条件满足，则等待一定时间后执行回调
     *
     * @param com 组件对象
     * @param time 等待时间（单位：秒）
     * @param iffunc 条件判断函数
     * @returns 返回一个 Promise 对象，等待时间结束后 resolve
     */
    public static waitIf(com: cc.Component, time: number, iffunc: Function) {
        return new Promise((a) => {
            let o = 0;
            com.schedule(function i(r) {
                iffunc() ? (o += r) >= time && (com.unschedule(i), a(null)) : (com.unschedule(i), a(null));
            }, 0);
        });
    }

    /** 范围检测，polygon是多边形顶点数组，格式是[x0,y0,x1,y1,x2,y2,x3,y3……] 支持任意形状多边形，只要填对顶点数据就行了 */
    public static isCollidePointPolygon(px: number, py: number, polygon: number[]): boolean {
        let flag = false;
        for (let i = 0, len = polygon.length, j = len - 2; i < len; j = i, i += 2) {
            const ax = polygon[i];
            const ay = polygon[i + 1];
            const bx = polygon[j];
            const by = polygon[j + 1];
            if ((px === ax && py === ay) || (px === bx && py === by)) {
                return true;
            } // 点与多边形顶点重合
            if (ay === by && py === ay && ((ax < px && px < bx) || (bx < px && px < ax))) {
                return true;
            } // 点的射线和多边形的一条边重合，并且点在边上
            if ((ay < py && py <= by) || (by < py && py <= ay)) {
                // 判断线段两端点是否在射线两侧
                const x = ax + ((py - ay) * (bx - ax)) / (by - ay); // 求射线和线段的交点x坐标，交点y坐标当然是py
                if (x === px) {
                    return true;
                } // 点在多边形的边上
                if (x > px) {
                    flag = !flag;
                } // x大于px来保证射线朝右
            }
        }
        return flag;
    }

    /**
     * 节点之间坐标互转
     * @param a         A节点
     * @param b         B节点
     * @param aPos      A节点空间中的相对位置
     */
    static calculateASpaceToBSpacePos(a: cc.Node, b: cc.Node, aPos: cc.Vec3): cc.Vec3 {
        let world: cc.Vec3 = a.convertToWorldSpaceAR(aPos);
        let space: cc.Vec3 = b.convertToNodeSpaceAR(world);
        return space;
    }

    /**
     * 显示对象等比缩放
     * @param targetWidth       目标宽
     * @param targetHeight      目标高
     * @param defaultWidth      默认宽
     * @param defaultHeight     默认高
     */
    static uniformScale(targetWidth: number, targetHeight: number, defaultWidth: number, defaultHeight: number) {
        let widthRatio = defaultWidth / targetWidth;
        let heightRatio = defaultHeight / targetHeight;
        let ratio;
        widthRatio < heightRatio ? (ratio = widthRatio) : (ratio = heightRatio);
        let size = new cc.Size(Math.floor(targetWidth * ratio), Math.floor(targetHeight * ratio));
        return size;
    }

    /** 给目标节点添加一个点击任意位置关闭的节点 */
    public static addClickCloseNode(target: cc.Node, rootUi: cc.Node) {
        if (!target) {
            return;
        }
        /** 阻塞目标节点，防止点击穿透 */
        target.addComponentUnique(cc.BlockInputEvents);
        const node = new cc.Node(`__close_${target.name}_on_clicked__`);
        node.parent = target.parent;
        node.setSiblingIndex(target.getSiblingIndex());
        /** 对齐到UI顶层画布 */
        const widget = node.addComponentUnique(cc.Widget);
        widget.target = rootUi;
        /** 目标节点已销毁 */
        const onDestroyed = () => {
            node.destroy();
        };
        // 在对象被销毁之前调用。
        target['_onPreDestroy'] = onDestroyed;
        /** 目标节点可见性改变 */
        const onActiveChanged = () => {
            if (!target.activeInHierarchy) {
                // 此节点激活时，此事件仅从最顶部的节点发出。
                target.off('active-in-hierarchy-changed', onActiveChanged, node);
                node.destroy();
            }
        };
        target.on('active-in-hierarchy-changed', onActiveChanged, node);
        /** 点击时关闭目标节点 */
        node.on(cc.Node.EventType.TOUCH_END, () => {
            if (target.isValid) {
                target.active = false;
                target.off('active-in-hierarchy-changed', onActiveChanged, node);
            }
            node.destroy();
        });
    }
}

we.core.ViewHelper = ViewHelper;
