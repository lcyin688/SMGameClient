import Decimal from 'decimal.js';

/** 默认小数精度 */
let defaultDecimalPlace = 2;

// 默认配置
export let defaultConfig: Decimal.Config = {
    /**
     * 有效位数
     * 运算结果的最大有效位数.
     * 默认值: 20
     */
    precision: 20,
    /**
     * 默认舍去最大小数位后面的数字
     */
    rounding: Decimal.ROUND_DOWN,
    /**
     * 负指数值
     * 在负指数值及其以下的，toString 返回指数表示法
     * new Decimal(0.00000123)            // '0.00000123'
     * new Decimal(0.000000123)           // '1.23e-7'
     * 始终返回指数表示法 Decimal.set({ toExpNeg: 0 })
     */
    toExpNeg: -7,

    /**
     * 正指数值
     * 大于等于正指数值时 toString 返回指数表示法
     * Decimal.set({ toExpPos: 2 })
     * new Decimal(12.3)                  // '12.3'
     * new Decimal(123)                   // '1.23e+2'
     * 始终返回指数表示法 Decimal.set({ toExpPos: 0 })
     */
    toExpPos: 20,

    /**
     * 负指数值极限，低于该值会发生下溢至零
     */
    minE: -9e15,

    /**
     * 正指数值极限，超过该极限值会发生 Infinity 溢出。
     */
    maxE: 9e15,

    /**
     * 确定该值是否使用加密安全的伪随机数生成。
     * // Node.js
     * global.crypto = require('crypto')
     * Decimal.crypto                     // false
     * Decimal.set({ crypto: true })
     * Decimal.crypto                     // true
     */
    crypto: false,
};

export class NumberHelper {
    /**
     * 配置Decimal库
     * @param config Decimal库配置
     * @param decimalPlace 小数保留最大位数,默认2位
     */
    static init(config: Decimal.Config, decimalPlace: number = defaultDecimalPlace) {
        defaultConfig = {
            ...defaultConfig,
            ...config,
        };

        defaultDecimalPlace = decimalPlace != null ? decimalPlace : defaultDecimalPlace;

        Decimal.set(defaultConfig);

        // console.info('Decimal default config:', defaultConfig);
        // console.info('Decimal decimalPlace:', decimalPlace);

        /**
         * 数字转Decimal
         *
         * @param precision 小数点位数
         */
        Number.prototype.toDP = function (precision: number = defaultDecimalPlace): Decimal {
            return new Decimal(this.valueOf()).toDP(precision);
        };

        /**
         * 数字转指定精度的数字
         * @param precision 小数点位数
         */
        Number.prototype.toFixedNumber = function (precision: number = defaultDecimalPlace): number {
            return new Decimal(this.valueOf()).toDP(precision).toNumber();
        };

        /**
         * 数字转字符串
         *
         * @param precision 小数点位数
         */
        Number.prototype.toFixed = function (precision: number = defaultDecimalPlace): string {
            return new Decimal(this.valueOf()).toFixed(precision);
        };

        /**
         * 加法
         *
         * @param n 加数
         */
        Number.prototype.add = function (n: Decimal.Value): number {
            return new Decimal(this.valueOf()).plus(n).toNumber();
        };

        /**
         * 减法
         *
         * @param n 减数
         */
        Number.prototype.sub = function (n: Decimal.Value): number {
            return new Decimal(this.valueOf()).minus(n).toNumber();
        };

        /**
         * 乘法
         *
         * @param n 乘数
         */
        Number.prototype.mul = function (n: Decimal.Value): number {
            return new Decimal(this.valueOf()).mul(n).toNumber();
        };

        /**
         * 除法
         *
         * @param n 除数
         */
        Number.prototype.div = function (n: Decimal.Value): number {
            return new Decimal(this.valueOf()).dividedBy(n).toNumber();
        };

        /**
         * 取反
         */
        Number.prototype.neg = function (): number {
            return new Decimal(this.valueOf()).neg().toNumber();
        };

        /**
         * 加法
         *
         * @param n 加数
         */
        Number.prototype.addD = function (n: Decimal.Value): Decimal {
            return new Decimal(this.valueOf()).plus(n);
        };

        /**
         * 减法
         *
         * @param n 减数
         */
        Number.prototype.subD = function (n: Decimal.Value): Decimal {
            return new Decimal(this.valueOf()).minus(n);
        };

        /**
         * 乘法
         *
         * @param n 乘数
         */
        Number.prototype.mulD = function (n: Decimal.Value): Decimal {
            return new Decimal(this.valueOf()).mul(n);
        };

        /**
         * 除法
         *
         * @param n 除数
         */
        Number.prototype.divD = function (n: Decimal.Value): Decimal {
            return new Decimal(this.valueOf()).dividedBy(n);
        };

        /**
         * 取反
         */
        Number.prototype.negD = function (): Decimal {
            return new Decimal(this.valueOf()).neg();
        };
    }

    /**
     * 科学计数法转小数
     */
    static getFullNumber(val: number): string {
        let m = val.toExponential().match(/\d(?:\.(\d*))?e([+-]\d+)/);
        return val.toFixed(Math.max(0, (m[1] || '').length - Number(m[2])));
    }
}
