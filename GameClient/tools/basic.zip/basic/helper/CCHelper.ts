import AssetManager from '../manager/AssetManager';

declare global {
    interface ICore {
        CCHelper: typeof CCHelper;
    }
}

export namespace CCHelper {
    export class Node {
        /** 相对父节点最大化等比显示目标节点 */
        public static maxScaleNode(target: cc.Node) {
            const parentTransform = target.parent;
            const targetTransform = target;
            if (targetTransform.width < parentTransform.width && targetTransform.height < parentTransform.height) {
                // 无需缩放
                return;
            }
            const scale = Math.min(parentTransform.width / targetTransform.width, parentTransform.height / targetTransform.height);
            target.scale = scale;
        }

        /**
         * 屏幕拉满显示指定节点
         * @param target 目标节点
         */
        public static maxSizeFullScreenNode(target: cc.Node) {
            let canvasSize = cc.view.getCanvasSize();
            const w = canvasSize.width / cc.view.getScaleX();
            const h = canvasSize.height / cc.view.getScaleY();
            target.setContentSize(w, h);
        }

        /**
         * 最大化等比全屏显示指定节点
         * @param target 目标节点
         */
        public static maxScaleFullScreenNode(target: cc.Node) {
            let canvasSize = cc.view.getCanvasSize();
            let wScale = canvasSize.width / target.width / cc.view.getScaleX();
            let hScale = canvasSize.height / target.height / cc.view.getScaleY();
            target.scale = Math.max(wScale, hScale);
        }
    }
    export class Asset {
        static async loadImage2Node(node: cc.Node, resUrl: string) {
            if (node == null || !node.isValid || !resUrl) {
                we.warn('Asset loadImage2Node, param (!node || !node.isValid || !resUrl) is true');
                return;
            }

            const sp = await AssetManager.loadAsset(resUrl, cc.SpriteFrame);
            if (!sp) {
                return;
            }

            const sprite = node.getComponent(cc.Sprite);
            if (!sprite) {
                we.warn(`Asset loadImage2Node, ${node.name} not exist cc.Sprite`);
                return;
            }

            sprite.spriteFrame = sp;
        }
    }

    export enum ScreenWidget {
        TOP,
        RIGHT,
        BOTTOM,
        LEFT,
    }
    export class Device {
        public static get deviceInfo(): string {
            if (cc.sys.isBrowser) {
                return `${cc.sys.os}-${cc.sys.browserType}-V${cc.sys.browserVersion}`;
            }

            return `${cc.sys.os}-${cc.sys.osVersion}-V${cc.sys.osMainVersion}`;
        }

        /**
         * 适配节点超出屏幕外时吸附到指定对齐位置
         * @param node 需要适配的节点
         * @param opts
         * @param opts.offset: cc.Vec2 偏移值
         * @param opts.widget: ScreenWidget 适配对齐方向
         * @returns
         */
        static adapterScreenWidget(node: cc.Node, opts: { offset?: cc.Vec2; widget: ScreenWidget }) {
            if (!cc.isValid(node)) {
                return;
            }

            // 初始化默认配置
            opts.offset = opts.offset ?? cc.v2(0, 0);
            // 保留 原始位置
            const originPos = node.getPosition();
            // 新建一个输出v2
            let outPos = cc.v2(0, 0);
            // 防抖timer记录
            let timerId = null;

            const canvas = we.core.utils.getSceneCanvas();

            /** 适配纵向 */
            const adapterV = (isTop: boolean) => {
                outPos = node.parent.convertToWorldSpaceAR(originPos, outPos);
                outPos = canvas.convertToNodeSpaceAR(outPos, outPos);
                if (isTop) {
                    const topY = canvas.height * (1 - canvas.anchorY) - node.height * (1 - node.anchorY) + opts.offset.y;
                    if (outPos.y >= topY) {
                        node.setPosition(originPos);
                        return;
                    }

                    outPos.y = topY;
                } else {
                    const bottomY = -canvas.height * canvas.anchorY + node.height * node.anchorY + opts.offset.y;
                    if (outPos.y <= bottomY) {
                        node.setPosition(originPos);
                        return;
                    }
                    outPos.y = bottomY;
                }

                outPos = canvas.convertToWorldSpaceAR(outPos, outPos);
                outPos = node.parent.convertToNodeSpaceAR(outPos, outPos);
                node.setPosition(outPos);
            };

            /** 适配横向 */
            const adapterH = (isLeft: boolean) => {
                outPos = node.parent.convertToWorldSpaceAR(originPos, outPos);
                outPos = canvas.convertToNodeSpaceAR(outPos, outPos);

                if (isLeft) {
                    const leftX = -canvas.width * canvas.anchorX + node.width * node.anchorX + opts.offset.x;
                    if (outPos.x >= leftX) {
                        node.setPosition(originPos);
                        return;
                    }
                    outPos.x = leftX;
                } else {
                    const rightX = canvas.width * (1 - canvas.anchorX) - node.width * node.anchorX + opts.offset.x;
                    if (outPos.x <= rightX) {
                        node.setPosition(originPos);
                        return;
                    }
                    outPos.x = rightX;
                }

                outPos = canvas.convertToWorldSpaceAR(outPos, outPos);
                outPos = node.parent.convertToNodeSpaceAR(outPos, outPos);
                node.setPosition(outPos);
            };

            /**
             * 建立运行索引
             */
            const runAdapterMap: { [key in ScreenWidget]: () => void } = {
                [ScreenWidget.TOP]: () => {
                    adapterV(true);
                },
                [ScreenWidget.RIGHT]: () => {
                    adapterH(false);
                },
                [ScreenWidget.BOTTOM]: () => {
                    adapterV(false);
                },
                [ScreenWidget.LEFT]: () => {
                    adapterH(true);
                },
            };

            const adapter = () => {
                // 防抖处理
                clearTimeout(timerId);
                timerId = setTimeout(() => {
                    // 如果节点或者canvas不存在则放弃适配
                    if (!cc.isValid(node) || !cc.isValid(canvas)) {
                        cc.view.off('canvas-resize', adapter);
                        return;
                    }

                    runAdapterMap[opts.widget]?.();
                }, 200);
            };

            cc.view.on('canvas-resize', adapter);
            adapter();
        }

        /**
         * 适配屏幕右边
         * @param node 节点
         * @param opts {offsetX: 偏移}
         * @deprecated 即将废弃
         * ```javascript
         * // 此接口即将废弃，请使用
         * we.core.CCHelper.Device.adapterScreenWidget(node: opts: {offset: cc.v2(0, 0), widget: we.core.CCHelper.ScreenWidget.RIGHT})
         * ```
         */
        static adapterScreenRight(node: cc.Node, opts?: { offsetX?: number }) {
            this.adapterScreenWidget(node, { offset: opts.offsetX ? cc.v2(opts.offsetX, 0) : null, widget: ScreenWidget.RIGHT });
            return null;
        }
    }
}

we.core.CCHelper = CCHelper;
