/**
 * 【we】框架挂载
 */
(function () {
    const _global = typeof window === 'undefined' ? global : window;
    // @ts-ignore
    _global.we = {
        core: {},
        ui: {},
        kit: {},
        npm: {},
        launcher: {},
        common: {},
        combase: {},
        comfight: {},
        comslot: {},
        comslotv2: {},
        comfish: {},
        commulti: {},
        comsingle: {},
    };
})();

import './module/async/AbortController';
import './module/async/PromiseHelper';
import './decorator/Decorator';
import './module/coroutinelock/CoroutineLock';
import './helper/ArrayHelper';
import './module/mobx/WEMobx';
import './ui/core/ItmSystem';
import './ui/core/UIBase';
import './ui/core/DlgSystem';
import './ui/core/UIView';
import './helper/NumberHelper';
import { Game } from './module/singleton/Game';
import { CoroutineLockComponent } from './module/coroutinelock/CoroutineLockComponent';
import { SceneFactory } from './module/scene/SceneFactory';
import { TimerComponent } from './module/timer/TimerComponent';
import { defaultConfig, NumberHelper } from './helper/NumberHelper';
import { EventSystem } from './module/event/EventSystem';
import { ObjectPool } from './module/objectpool/ObjectPool';
import { UIEventManager } from './ui/core/UIEventManager';
import { UIResConfig } from './ui/core/UIResConfig';
import { UIToast } from './ui/item/UIToast';
import { UIConfirm } from './ui/item/UIConfirm';
import { UICircleLoading } from './ui/item/UICircleLoading';
import { UIOrientationGuide } from './ui/item/UIOrientationGuide';
import { I18nData } from './ui/i18n/I18nData';
import Flavor from './flavor/Flavor';
import ProjectConfig from './config/ProjectConfig';
import BasicEventName from './const/BasicEventName';
import { BrowserParamKey, HideBrowserParamKey } from './config/ToolsConfig';
import LangManager from './manager/LangManager';
import AudioManager from './manager/AudioManager';
import ServerManager from './manager/ServerManager';
import NativeUtil from './platform/NativeUtil';
import TrackManager from './manager/TrackManager';
import Utils from './utils/Utils';
import { StorageKit } from './module/storage/StorageKit';
import { BasicType } from './type/BasicType';
import StorageUtil from './module/storage/StorageUtil';
import { UICommon } from './ui/item/UICommon';
import { GameConfig } from './config/GameConfig';
import AssetManager from './manager/AssetManager';
import NetworkManager from './manager/NetworkManager';
import { EntityEvent } from './module/entity/EntityEvent';
import { WELogger } from './module/logger/WELogger';
import { LogDataOutput } from './model/LogDataOutput';
import { ClientOfflineMode } from './module/ClientOfflineMode';
import { SceneHelper } from './module/scene/SceneHelper';
import { HotCache } from './module/algorithms/HotCache';
import { TimeInfo } from './module/time/TimeInfo';
import { Func } from './module/func/Func';
import { AssetErrorHandler } from './manager/AssetErrorHandler';

declare global {
    /** core 框架模块 */
    interface ICore {}

    /** ui 模块 */
    interface IUI {}

    /** 工具套件 */
    interface IKit {
        /** 系统存储 */
        storage: we.kit.Storage<BasicType.StorageTable>;
        hotCache: HotCache<BasicType.HotCacheData>;
    }

    /** npm 模块 (分包直接引用 npm 会报错) */
    interface INpm {}

    interface IWe {
        /** core 框架模块 */
        core: ICore;

        /** ui 模块 */
        ui: IUI;

        /** 工具套件 */
        kit: IKit;

        /** npm 模块 (分包直接引用 npm 会报错) */
        npm: INpm;

        /**
         * 全局事件
         */
        event<T extends we.core.EventMsg = we.core.EventMsg>(): we.core.EventGroup<T>;

        /**
         * 客户端场景，同客户端程序生命周期一致
         */
        clientScene: we.core.Scene;
        /**
         * 场景客户端事件
         */
        clientEvent<T>(): we.core.EntityEvent<T>;
        /**
         * 当前场景，和游戏组件生命周期一致
         * 当前不在子游戏，则currentScene不存在
         */
        currentScene: we.core.Scene;
        /**
         * 当前场景事件
         */
        currentEvent<T>(): we.core.EntityEvent<T>;
        /**
         * Client场景UI控制器,UI存在于Client Scene
         */
        clientUI: we.ui.UIComponent;
        /**
         * 当前场景UI控制器，UI存在于当前游戏场景
         */
        currentUI: we.ui.UIComponent;
        /**
         * 公共UI
         */
        commonUI: typeof UICommon;

        /** 是否 h5 android M */
        isH5AndroidM: boolean;

        /** 是否 h5 android T */
        isH5AndroidT: boolean;

        /** 是否 h5 android L 落地页包 */
        isH5AndroidL: boolean;

        /** 是否 h5 ios */
        isH5IOS: boolean;

        /** 是否 h5 ios 落地页包 */
        isH5IOSL: boolean;

        /** 是否 h5 马甲 scheme */
        isH5VestScheme: boolean;

        /** 是否 PWA */
        isH5PWA: boolean;

        /** log 模块 */
        logger: WELogger;

        /** console.log 详细: 只打印不上报 */
        log(...data: any[]): void;

        /** console.debug 调试: 只在 dev 打印不上报 */
        debug(...data: any[]): void;

        /** console.info 信息: 一般用来重要数据上报 */
        info(...data: any[]): void;

        /** console.warn 警告: 代码运行不符合预期, 不会阻塞流程 */
        warn(...data: any[]): void;

        /** console.error 错误: 代码运行不符合预期, 可能会阻塞流程 */
        error(...data: any[]): void;

        /** 不上传日志标签, 激活方式: 作为独立参数加在日志中, 一般加在最后一位 */
        noup: string;
    }

    const we: IWe;

    namespace we {
        type Runnablel<T> = (param: T) => any;
    }
}

/**
 * 隐藏浏览器url参数
 */
function onHideBrowserParam() {
    if (cc.sys.isBrowser) {
        const queryParams = new URLSearchParams(window.location.search);
        const originalUrl = window.location.href;

        const keysToRemoves = HideBrowserParamKey;

        keysToRemoves.forEach((key) => {
            const value = queryParams.get(key);
            if (value) {
                StorageUtil.saveHideBrowserKey(key, decodeURIComponent(value));
                queryParams.delete(key);
            }
        });

        if (queryParams.toString() !== window.location.search.slice(1)) {
            const params = queryParams.toString();
            const newUrl = originalUrl.split('?')[0] + (params == '' ? '' : '?' + params);
            Utils.hideBrowserParam(newUrl);
        }
    }
}

/**
 * 初始化全局变量 we
 */
function initWe() {
    /* eslint-disable no-console */

    // @ts-ignore
    window.we = window.we || {};

    // 提前初始化日志预防运行报错
    we.log = we.debug = we.info = console.log;
    we.warn = console.warn;
    we.error = console.error;

    // 初始化系统存储
    we.kit.storage = new StorageKit<BasicType.StorageTable>('sys');

    // 运行平台标识
    let runplt = Utils.getLocationUrlParam(BrowserParamKey.runplt);
    we.isH5AndroidM = window.h5am != undefined;
    we.isH5AndroidT = window.h5at != undefined;
    we.isH5AndroidL = window.h5al != undefined;
    we.isH5IOS = window?.webkit?.messageHandlers?.h5i != undefined;
    we.isH5IOSL = window?.webkit?.messageHandlers?.h5il != undefined;
    we.isH5VestScheme = runplt == 'h5vs';
    we.isH5PWA = runplt == 'h5pwa';

    // 日志模块
    we.logger = new WELogger();
    we.logger.setDataOutput(new LogDataOutput());
    we.log = we.logger.log.bind(we.logger);
    we.debug = we.logger.debug.bind(we.logger);
    we.info = we.logger.info.bind(we.logger);
    we.warn = we.logger.warn.bind(we.logger);
    we.error = we.logger.error.bind(we.logger);
    we.noup = 'we.noup';

    we.event = function <T extends we.core.EventMsg = we.core.EventMsg>(): we.core.EventGroup<T> {
        return we.core.EventGlobal.sender<T>();
    };

    cc.view.on(
        'canvas-resize',
        () => {
            we.event<we.core.EventMsg>().emit('WindowResize', true);
        },
        this
    );

    we.clientEvent = function <T>() {
        return we.clientScene?.getComponent(EntityEvent) as T;
    };
    we.currentEvent = function <T>() {
        return we.currentScene?.getComponent(EntityEvent) as T;
    };

    onHideBrowserParam();
}
initWe();

export default class WeGame {
    private static initLock: boolean = false;

    public static init() {
        if (this.initLock) {
            return;
        }

        this.initLock = true;
        we.log(`WeGame init`);

        this.addWindowEventListener();

        Flavor.init();
        ProjectConfig.init();
        NativeUtil.init();
        NetworkManager.init();
        AudioManager.init();
        TrackManager.init();
        LangManager.init();
        ServerManager.init();
        NumberHelper.init(defaultConfig);

        Game.addSingleton(we.core.Root);
        Game.addSingleton(ObjectPool);
        we.core.timer = Game.addSingleton(TimerComponent);
        Game.addSingleton(TimeInfo);
        Game.addSingleton(CoroutineLockComponent);

        // 启动ecs事件模块
        Game.addSingleton(EventSystem).enableSystem();

        // 创建ClientScene
        SceneFactory.createClientScene(1, 'Game');
        we.clientScene.addComponent(I18nData);
        // 游戏离线模式组件
        we.clientScene.addComponent(ClientOfflineMode);

        // 创建UI事件管理器
        Game.addSingleton(UIEventManager);

        we.clientScene.addComponent(UIResConfig);
        Game.addSingleton(UIToast);
        Game.addSingleton(UIConfirm);
        Game.addSingleton(UICircleLoading);
        Game.addSingleton(UIOrientationGuide);

        we.commonUI = UICommon;

        if (cc.sys.isNative) {
            jsb.device.setKeepScreenOn(true);
        }

        // 监听bundle过期淘汰时, 移除 bundle
        we.kit.hotCache.on(
            'bundle',
            we.core.Func.create((bundleName) => {
                we.core.assetMgr.removeModule(bundleName);
            })
        );

        this.runLauncher();
    }

    static update() {
        we.core.Game.update();
    }

    static lateUpdate() {
        we.core.Game.lateUpdate();
    }

    /**
     * 运行启动场景
     */
    static runLauncher() {
        const gameId = we.GameId.LAUNCHER;
        const bundleName = GameConfig.getBundleName(gameId);
        AssetManager.loadModule(bundleName, 'sta', Func.create(AssetErrorHandler.onLoadModuleError, AssetErrorHandler, gameId)).then(async () => {
            cc.game.emit(BasicEventName.RUN_LAUNCHER_SCENE_ENTER);

            const currentScene = await we.core.SceneFactory.createCurrentScene(bundleName, gameId);
            await we.core.eventSystem.invokeAsync(new we.core.eventInvoke.SceneEnter(currentScene, async () => {}), gameId);

            SceneHelper.setSceneUI(we.currentScene);
        });
    }

    /**
     * 添加全局事件监听
     */
    private static addWindowEventListener() {
        if (cc.sys.isBrowser) {
            window.addEventListener('message', (event: MessageEvent) => {
                we.log(`WeGame addWindowEventListener, message, data: ${JSON.stringify(event.data)}`);

                cc.director.emit(BasicEventName.WINDOW_MESSAGE, event.data);
            });

            // 监听 Uncaught TypeError
            window.addEventListener('error', (event: ErrorEvent) => {
                let location = event.filename ? `${event.filename}:${event.lineno}:${event.colno}` : '';
                let stack = (event?.error && event.error.stack) || '';
                if (stack) {
                    location = 'see stack Uncaught Error';
                }

                // @ts-ignore
                cc.onJsException(event.message, location, stack);
            });

            // 监听 unhandledrejection异常
            window.addEventListener('unhandledrejection', (event) => {
                const { reason } = event;
                let location = 'unhandledrejection unknown';
                let stack = reason?.stack;
                if (stack) {
                    location = 'see stack Unhandled Rejection';
                }

                // @ts-ignore
                cc.onJsException(reason.message, location, stack);
            });
        }
    }
}
