import { GameConfig } from './config/GameConfig';
import BasicEventName from './const/BasicEventName';
import Flavor from './flavor/Flavor';
import { ccBind, WEReferenceCollector } from './module/resCollector/WEReferenceCollector';

const { ccclass } = cc._decorator;

@ccclass
export default class TraceNode extends cc.Component {
    /* =========================== AUTO CODE START =========================== */

    @ccBind(cc.Node)
    private RC_debug_info: cc.Node = null;

    @ccBind(cc.Node)
    private RC_version: cc.Node = null;

    @ccBind(cc.Node)
    private RC_update: cc.Node = null;

    @ccBind(cc.Node)
    private RC_node: cc.Node = null;

    @ccBind(cc.Node)
    private RC_texture: cc.Node = null;

    @ccBind(cc.Node)
    private RC_debug_ctrl: cc.Node = null;

    @ccBind(cc.Node)
    private RC_left_top: cc.Node = null;

    @ccBind(cc.Node)
    private RC_left_middle: cc.Node = null;

    @ccBind(cc.Node)
    private RC_left_bottom: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected _rc: WEReferenceCollector = null;

    /** 调试是否启用 */
    private debugEnabled: boolean = false;
    /** 调试开关 */
    private debugLeftBottom: boolean = false;
    private debugLeftTop: boolean = false;
    /** 刷新延迟时间 */
    private updateDelayTime = 0;

    onLoad() {
        if (this._rc !== null || !cc.isValid(this.node)) {
            return;
        }

        this._rc = this.node.addComponentUnique(WEReferenceCollector);
        if (this._rc) {
            this._rc.bindTo(this);
        }

        this.RC_debug_info.active = this.debugEnabled;
        this.showFormatVersion(GameConfig.getGameVersion(GameConfig.curGameId));

        this.RC_update.active = false;
        this.RC_node.active = Flavor.isTestEnv();
        this.RC_texture.active = Flavor.isTestEnv();
        this.RC_debug_ctrl.zIndex = 10000;

        cc.director.on(BasicEventName.FULL_TOUCH_START, this.onEventFullTouchStart, this);
        cc.director.on(BasicEventName.FULL_TOUCH_MOVE, this.onEventFullTouchMove, this);
        cc.director.on(BasicEventName.FULL_TOUCH_END, this.onEventFullTouchEnd, this);
        cc.director.on(BasicEventName.FULL_TOUCH_CANCEL, this.onEventFullTouchEnd, this);
        cc.director.on(BasicEventName.LOAD_BUNDLE_VERSION, this.onNotifyVersion, this);
        cc.director.on(BasicEventName.LOAD_PROGRESS, this.onLoadProgress, this);
    }

    protected update(dt: number): void {
        if (this.RC_debug_info.active === false) {
            return;
        }

        if (this.updateDelayTime >= 60) {
            this.updateDelayTime = 0;
            this.getTextureCache();
            this.getSceneNodeCount();
        }
        this.updateDelayTime++;
    }

    protected onEnable(): void {
        this.unscheduleAllCallbacks();
    }

    onDestroy() {
        cc.director.off(BasicEventName.FULL_TOUCH_START, this.onEventFullTouchStart, this);
        cc.director.off(BasicEventName.FULL_TOUCH_MOVE, this.onEventFullTouchMove, this);
        cc.director.off(BasicEventName.FULL_TOUCH_END, this.onEventFullTouchEnd, this);
        cc.director.off(BasicEventName.FULL_TOUCH_CANCEL, this.onEventFullTouchEnd, this);
        cc.director.off(BasicEventName.LOAD_BUNDLE_VERSION, this.onNotifyVersion, this);
        cc.director.off(BasicEventName.LOAD_PROGRESS, this.onLoadProgress, this);
    }

    private onEventFullTouchStart(event: cc.Touch): void {
        if (!this.debugLeftBottom) {
            this.debugLeftBottom = this.RC_left_bottom.getBoundingBoxToWorld().contains(event.getLocation());
        }
    }

    private onEventFullTouchMove(event: cc.Touch): void {
        if (!this.debugLeftTop) {
            this.debugLeftTop = this.RC_left_top.getBoundingBoxToWorld().contains(event.getLocation());
        }
    }

    private onEventFullTouchEnd(event: cc.Touch): void {
        if (this.debugLeftBottom && this.debugLeftTop) {
            let leftMiddle = this.RC_left_middle.getBoundingBoxToWorld().contains(event.getLocation());
            if (leftMiddle) {
                this.debugEnabled = !this.debugEnabled;
                this.RC_debug_info.active = this.debugEnabled;

                // FPS
                cc.debug.setDisplayStats(this.debugEnabled);

                cc.director.emit(BasicEventName.FPS_STATUS_UPDATE, this.debugEnabled);

                // vConsole
                if (cc.sys.isBrowser && !CC_DEV) {
                    if (window['vConsole']) {
                        if (this.debugEnabled) {
                            window['vConsole']['showSwitch']();
                        } else {
                            window['vConsole']['hideSwitch']();
                        }
                    } else {
                        cc.assetManager.loadScript('vconsole.min.bac6b.js', (err: Error) => {
                            if (!err) {
                                if (typeof window['VConsole'] !== 'undefined') {
                                    window['vConsole'] = new window['VConsole']();
                                }
                            }
                        });
                    }
                }
            }
        }

        this.debugLeftBottom = false;
        this.debugLeftTop = false;
    }

    /**
     * 包版本号
     * @param msg
     */
    private onNotifyVersion(msg) {
        if (!(typeof msg == 'string')) {
            return;
        }

        this.showFormatVersion(msg);
    }

    /**
     * 热更文件大小和数量进度
     * @param msg
     */
    private onLoadProgress(msg) {
        if (!(typeof msg == 'object')) {
            return;
        }

        let update = '';
        if (msg.downloadedBytes != null && msg.totalBytes != null && msg.downloadedFiles != null && msg.totalFiles != null) {
            let fileCount = `UC:${msg.downloadedFiles}/${msg.totalFiles}`;
            let fileSize = `UM:${(msg.downloadedBytes / 1024 / 1024).toFixed(2)}/${(msg.totalBytes / 1024 / 1024).toFixed(2)}`;
            update = `${fileCount}-${fileSize}`;
        }

        this.RC_update.active = !!update;
        this.RC_update.getComponent(cc.Label).string = update;
    }

    /**
     * 当前场景节点总数
     */
    private getSceneNodeCount(): void {
        if (!Flavor.isTestEnv()) {
            return;
        }

        let count = function () {
            const root = cc.director.getScene();
            let nodeCount = 0;
            function countNodes(node: cc.Node) {
                if (node.name === 'RootNode' || node.name === 'PROFILER-NODE') {
                    return;
                }

                for (let i = 0, len = node.childrenCount; i < len; ++i) {
                    countNodes(node.children[i]);
                }
                nodeCount++;
            }

            countNodes(root);
            return `NC:${nodeCount}`;
        };

        this.RC_node.getComponent(cc.Label).string = count();
    }

    /**
     * 获取纹理缓存
     */
    private getTextureCache(): void {
        if (!Flavor.isTestEnv()) {
            return;
        }

        let cache = function () {
            let rawCacheData = cc.assetManager.assets['_map'];
            let totalTextureSize = 0;
            for (let k in rawCacheData) {
                let item = rawCacheData[k];
                let content = item['__classname__'];
                if (item.type !== 'js' && item.type !== 'json' && content === 'cc.Texture2D') {
                    let textureSize = item.width * item.height * ((item._native === '.jpg' ? 3 : 4) / 1024 / 1024);
                    totalTextureSize += textureSize;
                }
            }
            return `TC:${cc.assetManager.assets['_count']}-TM:${totalTextureSize.toFixed(2)}`;
        };

        this.RC_texture.getComponent(cc.Label).string = cache();
    }

    /**
     * 显示格式化后的 version 字段
     */
    private showFormatVersion(msg: string) {
        let common = GameConfig.getRemoteVersion('common');
        let hall = GameConfig.getRemoteVersion('hall');
        this.RC_version.getComponent(cc.Label).string = msg + `  c${common}  h${hall}`;
    }
}
