import { ScreenOrientation } from '../config/ProjectConfig';

declare global {
    interface ICore {
        CountryCode: typeof CountryCode;
        LangCode: typeof LangCode;
        SkinCode: typeof SkinCode;
        CurrencyCode: typeof CurrencyCode;
        CurrencySymbol: typeof CurrencySymbol;
    }
}

/** 产品风味 */
export type ProductFlavor = string;

/** 皮肤编码 */
export enum SkinCode {
    /** cartoon 卡通 */
    ct = 'ct',
    /** 红色卡通 */
    ct2 = 'ct2',
    /** 蓝色卡通 */
    ct3 = 'ct3',
    /** 蓝色竖版卡通 */
    ct4 = 'ct4',
    /** black gold 黑金 */
    bg = 'bg',
    /** 黑金 2 */
    bg2 = 'bg2',
    /** custom 定制皮肤 1 */
    cm1 = 'cm1',
    /** 定制皮肤 2 */
    cm2 = 'cm2',
    /** 定制皮肤 3 */
    cm3 = 'cm3',
    /** 定制皮肤 4 */
    cm4 = 'cm4',
    /** 定制皮肤 5 */
    cm5 = 'cm5',
    /** 定制皮肤 6 */
    cm6 = 'cm6',
    /** app simple app 简约 */
    as = 'as',
    /** realistic 写实 */
    rs = 'rs',
}

we.core.SkinCode = SkinCode;

/** 皮肤屏幕方向配置 */
export const SkinOrientation: { [key in keyof typeof SkinCode]: ScreenOrientation } = {
    /** 横屏 */
    ct: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 横屏 */
    ct2: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 横屏 */
    ct3: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 竖屏 */
    ct4: ScreenOrientation.PORTRAIT,
    /** 横屏 */
    bg: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 横屏 */
    bg2: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 横屏 */
    cm1: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 横屏 */
    cm2: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 横屏 */
    cm3: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 竖屏 */
    cm4: ScreenOrientation.PORTRAIT,
    /** 横屏 */
    cm5: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 横屏 */
    cm6: ScreenOrientation.LANDSCAPE_RIGHT,
    /** 竖屏 */
    as: ScreenOrientation.PORTRAIT,
    /** 横屏 */
    rs: ScreenOrientation.LANDSCAPE_RIGHT,
};

/** 国家代码 */
export enum CountryCode {
    /** 印尼 */
    id = 'id',
    /** 墨西哥 */
    mx = 'mx',
    /** 泰国 */
    th = 'th',
    /** 尼日利亚 */
    ng = 'ng',
    /** 巴西 */
    br = 'br',
    /** 印度 */
    in = 'in',
    /** 菲律宾 */
    ph = 'ph',
    /** 越南 */
    vn = 'vn',
    /** 巴基斯坦 */
    pk = 'pk',
    /** 孟加拉国 */
    bd = 'bd',
}

we.core.CountryCode = CountryCode;

/** 国家编号 */
export enum CountryNum {
    id = 62,
    mx = 52,
    th = 66,
    ng = 234,
    br = 55,
    in = 91,
    ph = 63,
    vn = 84,
    pk = 92,
    bd = 880,
}

/** 金额精度 */
export enum AmountPrecision {
    id = 1,
    mx = 1000,
    th = 1000,
    ng = 1000,
    br = 1000,
    in = 1000,
    ph = 1000,
    vn = 1000,
    pk = 1000,
    bd = 1000,
}

/** 价格精度 */
export enum PricePrecision {
    id = 1000,
    mx = 1000,
    th = 1000,
    ng = 1000,
    br = 1000,
    in = 1000,
    ph = 1000,
    vn = 1000,
    pk = 1000,
    bd = 1000,
}

/** 保留小数位数 */
export enum DecimalPlace {
    id = 0,
    mx = 3,
    th = 3,
    ng = 3,
    br = 3,
    in = 3,
    ph = 3,
    vn = 0,
    pk = 3,
    bd = 3,
}

/** 货币代码 */
export enum CurrencyCode {
    /** 印尼盾 */
    id = 'IDR',
    /** 墨西哥比索 */
    mx = 'MXN',
    /** 泰铢 */
    th = 'THB',
    /** 尼日利亚奈拉 */
    ng = 'NGN',
    /** 巴西雷亚尔 */
    br = 'BRL',
    /** 印度卢比 */
    in = 'INR',
    /** 比索 */
    ph = 'PHP',
    /** 越南盾 */
    vn = 'VND',
    /** 卢比 */
    pk = 'PKR',
    /** 塔卡 */
    bd = 'BDT',
}

we.core.CurrencyCode = CurrencyCode;

/** 货币符号 */
export enum CurrencySymbol {
    /** 印尼盾 */
    id = 'Rp ',
    /** 墨西哥比索 */
    mx = '$ ',
    /** 泰铢 */
    th = '฿ ',
    /** 尼日利亚奈拉 */
    ng = '₦ ',
    /** 巴西雷亚尔 */
    br = 'R$ ',
    /** 印度卢比 */
    in = '₹ ',
    /** 比索 */
    ph = '₱ ',
    /** 越南盾 */
    vn = '₫ ',
    /** 卢比 */
    pk = 'Rs ',
    /** 塔卡 */
    bd = '৳ ',
}

we.core.CurrencySymbol = CurrencySymbol;

/** 语言代码 */
export enum LangCode {
    /** 英语 */
    en = 'en',
    /** 印尼语 */
    id = 'id',
    /** 西班牙语-墨西哥 */
    es = 'es-mx',
    /** 泰语 */
    th = 'th',
    /** 葡萄牙语-巴西 */
    pt = 'pt-BR',
    /** 印地语 */
    hi = 'hi',
    /** 越南语 */
    vi = 'vi',
    /** 乌尔都语 */
    ur = 'ur',
    /** 孟加拉语 */
    bn = 'bn',
}

we.core.LangCode = LangCode;

/** 多语言列表 */
export const LangList = {
    id: [LangCode.id],
    mx: [LangCode.es],
    th: [LangCode.th],
    ng: [LangCode.en],
    br: [LangCode.pt],
    in: [LangCode.en],
    ph: [LangCode.en],
    vn: [LangCode.vi],
    pk: [LangCode.en, LangCode.ur],
    bd: [LangCode.bn],
} as { [key: string]: string[] };

/** 语言支持皮肤 默认 all */
export const LangSupportSkin = {
    ur: [SkinCode.rs, SkinCode.ct2],
} as { [key: string]: string[] };

/** 日期格式 */
export enum DateFormatConf {
    id = 'DD/MM/YYYY',
    mx = 'DD/MM/YYYY',
    th = 'DD/MM/YYYY',
    ng = 'DD/MM/YYYY',
    br = 'DD/MM/YYYY',
    in = 'DD/MM/YYYY',
    ph = 'DD/MM/YYYY',
    vn = 'DD/MM/YYYY',
    pk = 'DD/MM/YYYY',
    bd = 'DD/MM/YYYY',
}

/** 环境类型 */
export enum EnvType {
    test = 'test', // 测试服
    prev = 'prev', // 预发布
    demo = 'demo', // 体验服
    prod = 'prod', // 生产服
}

/** 域名列表 */
export const Domains = {
    id: {
        test: {
            id: ['idn-test.com'],
            id2: ['idn2-test.com'],
        },
        prev: {
            id: ['idn-prev.com'],
            id2: ['idn2-prev.com'],
        },
        demo: ['demo1-id.com'],
        prod: {
            id: ['online365d.com', 'keep999.com', 'greedtaotie.com', 'inhundun.com'],
            id2: ['daduola.com', 'xiaohope.com', 'doyourich.com', 'inafafa.com'],
            id3: ['yuanball.com', 'rednana.com', 'pangtiger.com', 'kissmeng.com'],
            id4: ['redbao88.com', 'basepang.com', 'ctmunger.com', 'chenggold.com'],
            id5: ['gclhuo.com', 'wawasha.com', 'haopangda.com', 'pengmong.com'],
            id6: ['goufar.com', 'raindodo.com', 'sunsunw.com', 'blueyong.com'],
            id7: ['askdgwoh7.com', 'niihaokb7.com', 'qiunis7.com', 'gvdfdd7.com'],
            id8: ['sdds8d.com', 'nihaohd8.com', 'niihkvhg8.com', 'ijgfvbjj8cv.com', 's8dkjh8jd.com'],
        },
    },
    mx: {
        test: ['hiwin-test-mx.com'],
        prev: ['hiwin-pre-mx.com'],
        prod: ['mexicogogogo.com', 'dadarich.com', 'gorichland.com', 'nuthope.com'],
    },
    th: {
        test: ['idn-test.com'],
        prev: ['idn-prev.com'],
        prod: ['hiwin.win', 'online365d.com', 'lasting10000y.com', 'keep999.com'],
    },
    ng: {
        test: ['hiwin-test-ng.com'],
        prev: ['hiwin-pre-ng.com'],
        prod: ['nghappy.com', 'ngmoon.com', 'ngfast.com', 'lagosrich.com'],
    },
    br: {
        test: ['hiwin-test-br.com'],
        prev: ['hiwin-pre-br.com'],
        prod: ['jinaclrwu.com', 'yu3ryd55.com', 'manrg2ggb.com', 'tangzb8kz.com'],
    },
    in: {
        test: ['in1-test.com'],
        prev: ['in1-prev.com'],
        demo: ['demo-in.com'],
        prod: ['leisame.com', 'potbao.com', 'hangko.com', 'muhayo.com'],
    },
    ph: {
        test: ['phl-test.com'],
        prev: ['phl-prev.com'],
        demo: ['demo-ph.com'],
        prod: ['berbem.com', 'fanpee.com', 'kungsky.com', 'kneman.com'],
    },
    vn: {
        test: ['vnm-test.com'],
        prev: ['vnm-prev.com'],
        demo: ['demo-vn.com'],
        prod: ['codsese.com', 'catfafa.com', 'dadpapa.com', 'kumhuhu.com'],
    },
    pk: {
        test: ['pk1-test.com'],
        prev: [],
        demo: ['pk1-demo.com'],
        prod: ['corngon.com', 'capanal.com', 'nathbow.com', 'rendfa.com'],
    },
    bd: {
        test: ['bd1-test.com'],
        prev: [],
        prod: ['bord1kog.com', 'bord3rog.com', 'bord2fog.com', 'bord7tog.com'],
    },
};
