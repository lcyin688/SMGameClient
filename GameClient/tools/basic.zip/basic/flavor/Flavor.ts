import { ScreenOrientation } from '../config/ProjectConfig';
import { BrowserParamKey } from '../config/ToolsConfig';
import NativeUtil from '../platform/NativeUtil';
import Utils from '../utils/Utils';
import { ProductFlavor, SkinCode, SkinOrientation, CountryCode, CountryNum, AmountPrecision, PricePrecision, DecimalPlace } from './FlavorConf';
import { CurrencyCode, CurrencySymbol, LangList, LangSupportSkin, DateFormatConf, EnvType, Domains } from './FlavorConf';

declare global {
    interface ICore {
        flavor: typeof Flavor;
    }
}

export default class Flavor {
    /** 开发调试时可以通过 pf 参数指定目标值, 这里代码不要改动 ----------------- */
    private static productFlavor: ProductFlavor = CC_DEV ? `${SkinCode.ct}_${CountryCode.id}2_${EnvType.test}` : '';
    private static resVersion: string = '1.0.1';
    private static skinCode: SkinCode = null;
    private static countryRegion: CountryCode = null;
    private static countryRegionClient: CountryCode = null;
    private static envType: EnvType = null;

    public static init(): void {
        if (cc.sys.isNative) {
            try {
                // countryRegion envType 使用包体内嵌
                let rootPath = jsb.fileUtils.getDefaultResourceRootPath();
                let versionManifestBuiltinPath = jsb.fileUtils.fullPathForFilename(rootPath + 'assets/assets/version.manifest');
                let versionManifestBuiltinStr = jsb.fileUtils.getStringFromFile(versionManifestBuiltinPath);
                let versionManifestBuiltinObj = JSON.parse(versionManifestBuiltinStr);
                let productFlavorBuiltin = versionManifestBuiltinObj.productFlavor;
                let flavorsBuiltin = productFlavorBuiltin.split('_');
                let skinCodeBuiltin = flavorsBuiltin[0];
                let countryRegion = flavorsBuiltin[1];
                let envType = flavorsBuiltin[2];

                // skinCode resVersion 使用搜索路径
                let versionManifestSearchPath = jsb.fileUtils.fullPathForFilename('assets/version.manifest');
                let versionManifestSearchStr = jsb.fileUtils.getStringFromFile(versionManifestSearchPath);
                let versionManifestSearchObj = JSON.parse(versionManifestSearchStr);
                let productFlavorSearch = versionManifestSearchObj.productFlavor;
                let flavorSearch = productFlavorSearch.split('_');
                let skinCode = flavorSearch[0];
                let resVersion = versionManifestSearchObj.version;

                // 切换皮肤后更新基础包覆盖安装时可能会出现
                // 包体内嵌版本号 > 缓存版本号 且 皮肤编码不一致时, 清理缓存使用包体内嵌资源
                if (Utils.compareVersionStrict(versionManifestBuiltinObj.version, versionManifestSearchObj.version) > 0 && skinCodeBuiltin !== skinCode) {
                    jsb.fileUtils.removeDirectory(jsb.fileUtils.getWritablePath() + 'assets/assets/');
                    skinCode = skinCodeBuiltin;
                    resVersion = versionManifestBuiltinObj.version;
                }

                this.productFlavor = `${skinCode}_${countryRegion}_${envType}`;
                this.resVersion = resVersion;
            } catch (err) {
                // io 异常，概率很低，出现则重启
                we.error(`Flavor init, versionManifest err: ${JSON.stringify(err.message || err)}`);
                setTimeout(() => {
                    cc.game.restart();
                });
            }
        } else {
            // @ts-ignore
            this.productFlavor = cc.__h5_pf__ || this.productFlavor;
            let productFlavor = Utils.getLocationUrlParam(BrowserParamKey.pf);
            if (productFlavor) {
                this.productFlavor = productFlavor;
            }

            // @ts-ignore
            this.resVersion = cc.__h5_crv__ || this.resVersion;
            let resVersion = Utils.getLocationUrlParam(BrowserParamKey.crv);
            if (resVersion) {
                this.resVersion = resVersion;
            }

            if (CC_DEV) {
                // 只有开发环境允许通过参数指定单个 flavor 值
                let defaultFlavors = this.productFlavor.split('_');
                let skin = Utils.getLocationUrlParam(BrowserParamKey.skin) || defaultFlavors[0];
                let ctry = Utils.getLocationUrlParam(BrowserParamKey.ctry) || defaultFlavors[1];
                let env = Utils.getLocationUrlParam(BrowserParamKey.env) || defaultFlavors[2];
                this.productFlavor = `${skin}_${ctry}_${env}`;
            }
        }

        let flavors = this.productFlavor.split('_');
        this.skinCode = <SkinCode>flavors[0];
        this.countryRegion = <CountryCode>flavors[1];
        this.countryRegionClient = <CountryCode>flavors[1];
        this.envType = <EnvType>flavors[2];

        if (cc.sys.isBrowser && this.isTestEnv()) {
            let clientCountryCode = Utils.getLocationUrlParam(BrowserParamKey.crc);
            if (clientCountryCode) {
                this.countryRegionClient = <CountryCode>clientCountryCode;
            }
        }

        we.log(`Flavor init, chn: ${NativeUtil.getChannel()}, productFlavor: ${this.productFlavor}, resVersion: ${this.resVersion}`);
    }

    /** ---------------------------- skin ---------------------------- */

    /**
     * 皮肤编码
     * @returns
     */
    public static getSkinCode(): SkinCode {
        return this.skinCode;
    }

    /**
     * 是否是竖版的皮肤
     * @returns
     */
    public static isSkinVertical(): boolean {
        return SkinOrientation[this.skinCode] === ScreenOrientation.PORTRAIT;
    }

    /**
     * 获取皮肤方向
     * @returns
     */
    public static getSkinOrientation(): ScreenOrientation {
        return SkinOrientation[this.skinCode];
    }

    /**
     * 皮肤方向 tag
     * @returns
     */
    public static getSkinOrientationTag(): 'v' | 'h' {
        return SkinOrientation[this.skinCode] === ScreenOrientation.PORTRAIT ? 'v' : 'h';
    }

    /** ---------------------------- country ---------------------------- */

    /**
     * 国家 code, 两位字母, 不带序号, 比如 id mx ng
     * @returns
     */
    public static getCountryCode(): CountryCode {
        return <CountryCode>this.countryRegion.substring(0, 2);
    }

    /**
     * 客户端国家 code，用于前端显示控制
     * @returns
     */
    public static getClientCountryCode(): CountryCode {
        return <CountryCode>this.countryRegionClient.substring(0, 2);
    }

    /**
     * 国家地区, 带序号, 序号1缺省, 比如 id id2 id3
     * @returns
     */
    public static getCountryRegion(): string {
        return this.countryRegion;
    }

    /**
     * 国家编号
     * @returns
     */
    public static getCountryNum(): number {
        return CountryNum[this.getCountryCode()];
    }

    /**
     * 金额精度 修饰金币
     * @returns
     */
    public static getAmountPrecision(): number {
        return AmountPrecision[this.getClientCountryCode()];
    }

    /**
     * 价格精度 修饰货币
     * @returns
     */
    public static getPricePrecision(): number {
        return PricePrecision[this.getClientCountryCode()];
    }

    /**
     * 保留小数位数
     * @returns
     */
    public static getDecimalPlace(): number {
        return DecimalPlace[this.getClientCountryCode()];
    }

    /**
     * 货币代码
     * @returns
     */
    public static getCurrencyCode(): string {
        return CurrencyCode[this.getClientCountryCode()];
    }

    /**
     * 货币符号
     * @returns
     */
    public static getCurrencySymbol(): string {
        return CurrencySymbol[this.getClientCountryCode()];
    }

    /**
     * 多语言列表
     * @returns
     */
    public static getLangList(): string[] {
        // 根据国家和皮肤过滤
        let langListFinal: string[] = [];
        let langListDefault = LangList[this.getClientCountryCode()];
        for (let i = 0; i < langListDefault.length; i++) {
            let langCode = langListDefault[i];
            let supportSkins = LangSupportSkin[langCode];
            let skinCode = this.getSkinCode();
            if (!supportSkins || supportSkins?.includes(skinCode)) {
                langListFinal.push(langCode);
            }
        }

        return langListFinal;
    }

    /**
     * 日期格式
     * @returns
     */
    public static getCountryDateFormate(): string {
        return DateFormatConf[this.getClientCountryCode()];
    }

    /** ---------------------------- env ---------------------------- */

    /**
     * 环境类型
     * @returns
     */
    public static getEnvType(): string {
        return this.envType;
    }

    /**
     * 环境名称 生产环境为空
     * @returns
     */
    public static getEnvName(): string {
        if (this.envType == EnvType.prod) {
            return '';
        }
        return this.envType.toString();
    }

    /**
     * 大厅域名列表
     * @returns
     */
    public static getDomains(): string[] {
        let domains = Domains[this.getCountryCode()][this.getEnvType()];
        if (!Array.isArray(domains)) {
            domains = domains[this.getCountryRegion()];
        }
        return domains;
    }

    /**
     * 是否测试环境
     * @returns boolean
     */
    public static isTestEnv(): boolean {
        return this.envType === EnvType.test;
    }

    /**
     * 是否预发布环境
     * @returns boolean
     */
    public static isPrevEnv(): boolean {
        return this.envType === EnvType.prev;
    }

    /**
     * 是否生产环境
     * @returns boolean
     */
    public static isProdEnv(): boolean {
        return this.envType === EnvType.prod;
    }

    /**
     * 主包版本号
     * @returns
     */
    public static getVersion(): string {
        return this.resVersion;
    }

    /**
     * 开发环境 h5 渠道号
     * @returns
     */
    public static getDevH5Channel(): string {
        if (!CC_DEV) {
            return '';
        }

        return 'h5_lobby_' + this.skinCode;
    }
}

we.core.flavor = Flavor;
