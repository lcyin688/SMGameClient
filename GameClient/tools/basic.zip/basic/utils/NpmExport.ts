import { Buffer } from 'buffer';
import * as crypto from 'crypto';
import * as lodash from 'lodash';

let qrcode = require('qrcode');

declare global {
    interface INpm {
        Buffer: typeof Buffer;
        crypto: typeof crypto;
        lodash: typeof lodash;
        qrcode: typeof qrcode;
    }

    namespace we {
        namespace npm {
            type Buffer = InstanceType<typeof Buffer>;
        }
    }
}

we.npm.Buffer = Buffer;
we.npm.crypto = crypto;
we.npm.lodash = lodash;
we.npm.qrcode = qrcode;

export { Buffer, crypto, lodash };
