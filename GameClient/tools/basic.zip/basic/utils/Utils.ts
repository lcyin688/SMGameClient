import { GameConfig } from '../config/GameConfig';
import { BrowserParamKey, HideBrowserParamKey } from '../config/ToolsConfig';
import { Base64 } from '../module/base64/Base64';
import { Md5 } from '../module/md5/Md5';
import StorageUtil from '../module/storage/StorageUtil';

declare global {
    interface ICore {
        /** 工具集 */
        utils: typeof Utils;
    }
}

/**
 * 工具集
 */
export default class Utils {
    // 记录点击时间
    private static tagClickTime = new Map<string, number>();

    /**
     * @description 是否频繁点击
     * @param 判断重复点的一个id，用于区分不同时机
     * @duration 少于该时长即认为发生了重复点击（毫秒）
     * @returns {boolean} true 重复点击 false 非重复点击
     **/
    public static isQuickClick(tag: string = 'normal', duration: number = 1000): boolean {
        if (!Utils.tagClickTime) {
            Utils.tagClickTime = new Map<string, number>();
        }

        const now = Date.now();
        const lastClickTime = Utils.tagClickTime.get(tag) || 0;

        // 判断是否为重复点击
        if (now - lastClickTime < duration) {
            return true;
        }

        // 如果记录数超过30，清理数据只保留当前tag
        if (Utils.tagClickTime.size > 30) {
            Utils.tagClickTime.clear();
        }

        // 更新点击时间
        Utils.tagClickTime.set(tag, now);

        return false;
    }

    /**
     * base64 编码
     * @param str
     */
    public static base64Encode(str: string): string {
        if (typeof str != 'string') {
            we.warn('Utility base64Encode, params is invalid');
            return '';
        }
        return Base64.encode(str);
    }

    /**
     * base64 解码
     * @param str
     */
    public static base64Decode(str: string): string {
        if (typeof str != 'string') {
            we.warn('Utility base64Decode, params is invalid');
            return '';
        }
        return Base64.decode(str);
    }

    /**
     * md5 加密
     * @param str
     */
    public static md5hex(str: string): string {
        if (typeof str != 'string') {
            we.warn('Utility md5hex, params is invalid');
            return '';
        }

        return Md5.digest(str);
    }

    /**
     * 格式化时间为时分秒
     * @param timeStamp
     * @param format {HH}:{MM}:{SS} = 05:03:02类型时间格式,这种格式会补0, {H}:{M}:{S} = 24:4:1 不补0，可灵活组装使用, 例如 剩余时间({Ss}S)
     * @returns
     */
    public static formatTime(timeStamp: number, format = '{HH}:{MM}:{SS}'): string {
        let h = Math.floor(timeStamp / 60 / 60);
        let m = Math.floor((timeStamp - h * 3600) / 60);
        let s = timeStamp - h * 3600 - m * 60;

        const fn = (d: number) => {
            return (0 + '' + d).slice(-2);
        };

        const formats = {
            '{HH}': fn(h),
            '{MM}': fn(m),
            '{SS}': fn(s),
            '{H}': h.toString(),
            '{M}': m.toString(),
            '{S}': s.toString(),
        };

        const ret = format.replace(/\{([a-z]+)\}/gi, (a) => {
            return formats[a] || a;
        });

        return ret;
    }

    /**
     * 比较版本 [local !== remote] < 0 有更新, >= 0 无更新
     * @param localVersion 1.0.1
     * @param remoteVersion 1.0.2
     */
    public static compareVersion(localVersion: string, remoteVersion: string, isSubGame: boolean = false): number {
        if (cc.sys.isNative && GameConfig.nativeLpt && !isSubGame) {
            // 非子游戏，使用固定版本
            return 0;
        }

        if (!(localVersion && remoteVersion)) {
            we.warn(`Utility compareVersion, params err`);
            return 0;
        }

        // 测试服主包版本号会带构建号, 格式 version-build 5.5.5-555, 版本号对比忽略构建号
        localVersion = localVersion.split('-')[0];
        if (localVersion !== remoteVersion) {
            return -1;
        }

        return 0;
    }

    /**
     * 比较版本
     * @param leftVersion 1.0.1
     * @param rightVersion 1.0.2
     * @returns left - right <=> 0
     */
    public static compareVersionStrict(leftVersion: string, rightVersion: string): number {
        if (!(leftVersion && rightVersion)) {
            we.warn(`Utility compareVersionStrict, params err`);
            return 0;
        }

        let leftVersions = leftVersion.split('.');
        let rightVersions = rightVersion.split('.');
        let versionsLength = Math.max(leftVersions.length, rightVersions.length);
        for (let i = 0; i < versionsLength; ++i) {
            let vL = parseInt(leftVersions[i] || '0');
            let vR = parseInt(rightVersions[i] || '0');
            if (vL === vR) {
                continue;
            } else {
                return vL - vR;
            }
        }

        return 0;
    }

    /**
     * 字符串格式化
     * @param format 要格式化的字符串
     * @param args 参数
     * @example
     * //我叫美男子,性别男,今年20岁
     * stringFormat('我叫{0},性别{1},今年{2}岁', '美男子', '男', 20);
     * stringFormat('我叫{name},性别{sex},今年{age}岁', { name: '美男子', sex: '男', age: 20 });
     */
    public static stringFormat(format: string, ...args: any[]): string {
        if (typeof format != 'string') {
            we.warn('Utility stringFormat format is invalid');
            return '';
        }

        if (args.length == 0) {
            return format;
        }

        let result = format;
        if (args.length == 1 && typeof args[0] == 'object') {
            let params: Object = args[0];
            for (let key in params) {
                let value = params[key];
                const reg = new RegExp(`\\{${key}\\}`, 'g');
                if (typeof value == 'string' || (typeof value == 'number' && !isNaN(value))) {
                    result = result.replace(reg, value.toString());
                }
            }
        } else {
            for (let i = 0; i < args.length; i++) {
                let value = args[i];
                if (typeof value == 'string' || (typeof value == 'number' && !isNaN(value))) {
                    result = result.replace('{' + i + '}', value.toString());
                }
            }
        }

        return result;
    }

    /**
     * 获取ip
     * @param str
     */
    public static getIp(str: string): string {
        if (!(str && typeof str == 'string')) {
            return '';
        }

        let reg = /(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)/;
        let array = reg.exec(str);
        let ret = array ? array[0] : '';
        return ret;
    }

    /**
     * 拼接url
     * @param host
     * @param path
     */
    public static joinUrl(host: string, path: string): string {
        if (!(typeof host == 'string' && host.length > 0 && typeof path == 'string' && path.length > 0)) {
            we.warn('Utility joinUrl, params is err');
            return '';
        }

        if (!host.startsWith('http')) {
            host = 'http://' + host;
        }

        if (!host.endsWith('/')) {
            host = host + '/';
        }

        if (path.startsWith('/')) {
            path = path.substring(1, path.length);
        }

        if (path.endsWith('/')) {
            path = path.substring(0, path.length - 1);
        }

        return host + path;
    }

    /**
     * 获取地址url参数
     * @param key
     */
    public static getLocationUrlParam<K extends keyof typeof BrowserParamKey>(key: K): string {
        if (cc.sys.isBrowser) {
            const query = new URLSearchParams(window.location.search);
            let value = query.get(key) ?? '';
            value = decodeURIComponent(value);
            let urlKey = we.kit.storage.get('sys', 'url_key') || {};
            // 浏览器隐藏参数
            if (HideBrowserParamKey) {
                const arr: string[] = HideBrowserParamKey;
                if (arr.includes(key) === true) {
                    // @ts-ignore
                    const storedValue = urlKey[`url_key_${key}`] || StorageUtil.readHideBrowserKey(key);
                    if (storedValue) {
                        value = storedValue;
                    }
                }
            }
            return value;
        }
        return '';
    }

    /** 处理url 多参数解析，例如 fish{url1},slot{url2},aztec{url3} => {fish: 'url1', slot: 'url2', aztec: 'url3'} */
    public static convertToKeyValue(inputString: string): Record<string, string> {
        const result: Record<string, string> = {};
        const items = inputString.split(',');
        items.forEach((item) => {
            const keyValueParts = item.split('{');
            if (keyValueParts.length === 2) {
                const key = keyValueParts[0].trim();
                const value = keyValueParts[1].replace('}', '').trim();
                result[key] = value;
            }
        });
        return result;
    }

    /**
     * 文本点点跳动, …/... 只能在文本末端
     * @param label
     * @param text
     */
    public static labelPointBounce(label: cc.Label | cc.RichText, text: string): void {
        if (!cc.isValid(label)) {
            we.warn(`Utility labelPointBounce, label is invalid`);
            return;
        }

        if (!(typeof text == 'string')) {
            we.warn(`Utility labelPointBounce, text err: ${text}, node: ${this.getNodePath(label.node)}`);
            return;
        }

        if (label.node['anchorX_original'] == undefined) {
            label.node['anchorX_original'] = label.node.anchorX;
        }

        if (label.node['posX_original'] == undefined) {
            label.node['posX_original'] = label.node.x;
        }

        let reset = () => {
            label.unscheduleAllCallbacks();
            label.node.anchorX = label.node['anchorX_original'];
            label.node.x = label.node['posX_original'];
        };

        if (text.endsWith('…') || text.endsWith('...')) {
            if (text.endsWith('…')) {
                text = text.substring(0, text.lastIndexOf('…'));
            } else if (text.endsWith('...')) {
                text = text.substring(0, text.lastIndexOf('...'));
            }
        } else {
            reset();
            label.string = text;
            return;
        }

        reset();

        let point = '.';
        label.string = text + point;
        label.scheduleOnce(() => {
            label.node.anchorX = 0;
            label.node.x = label.node['posX_original'] - label.node.width / 2;
            label.schedule(() => {
                if (point.length >= 3) {
                    point = '';
                } else {
                    point += '.';
                }
                label.string = text + point;
            }, 0.5);
        }, 0.5);
    }

    /**
     * 对象转查询参数
     * @param obj
     * @returns
     */
    public static objectToQuery(obj: object): string {
        if (typeof obj != 'object') {
            return '';
        }

        let str = '';
        let index = 0;
        for (const key in obj) {
            str = str + (index == 0 ? '' : '&') + key + '=' + obj[key];
            index++;
        }
        return str;
    }

    /**
     * 获取场景画布
     * @returns
     */
    public static getSceneCanvas(): cc.Node {
        if (cc.Canvas.instance && cc.isValid(cc.Canvas.instance.node)) {
            return cc.Canvas.instance.node;
        }

        we.warn(`Utility getSceneCanvas, canvas is null`);
        return null;
    }

    // 获取弹窗等比缩放比例
    public static getPopDialogRealScale(scalingSize: cc.Size) {
        let realContentScale = 1.0;
        let scaleX = 1;
        let scaleY = 1;
        let canvas = this.getSceneCanvas();
        let offsetWidth = canvas.width - scalingSize.width;
        if (offsetWidth < 0) {
            scaleX = canvas.width / scalingSize.width;
        }
        let offsetHeight = canvas.height - scalingSize.height;
        if (offsetHeight < 0) {
            scaleY == canvas.height / scalingSize.height;
        }

        if (offsetHeight < 0 || offsetWidth < 0) {
            realContentScale = Math.min(scaleX, scaleY);
        }

        return realContentScale;
    }

    /**
     * 运行回调
     * @param call
     * @param target
     * @param args
     * @returns
     */
    public static runCall<T extends (...args: any[]) => any>(call: T, target?: any, ...args: Parameters<T>): ReturnType<T> {
        call = target ? call.bind(target) : call;
        const res = call(...args);
        return res;
    }

    /**
     * 隐藏浏览器url参数
     * @param url 新的url地址
     * @returns
     */
    public static hideBrowserParam(url: string) {
        if (!cc.sys.isBrowser) {
            return;
        }

        const areUrlsSameOrigin = function (url1: string, url2: string): boolean {
            try {
                const urlA = new URL(url1);
                const urlB = new URL(url2);
                return urlA.protocol === urlB.protocol && urlA.hostname === urlB.hostname && urlA.port === urlB.port;
            } catch (e) {
                we.error('Utility hideUrlParameters, Invalid URL:', e);
                return false;
            }
        };

        let bSameOrigin = areUrlsSameOrigin(window.location.href, url);
        if (bSameOrigin === false) {
            we.warn('Utility hideUrlParameters, The two URL addresses have different origins.', window.location.href, url);
            return;
        }

        // 确保在浏览器环境中，window.history对象包含replaceState方法
        if (window.history && 'replaceState' in window.history) {
            window.history.replaceState({}, '', url);
        } else {
            we.warn('Utility hideUrlParameters, history.replaceState is not supported in this browser.');
            window.location.replace(url);
        }
    }

    /**
     * 获取节点路径
     * @param node
     * @returns
     */
    public static getNodePath(node: cc.Node): string {
        if (!cc.isValid(node)) {
            return '';
        }

        let name = node.name;

        if (cc.isValid(node.parent)) {
            return this.getNodePath(node.parent) + '/' + name;
        }

        return name;
    }

    /**
     * 替换路径中指定位置后面的一个路径段
     * @param path 原始路径
     * @param newSegment 要替换的新路径段
     * @param marker 要替换的路径段标记
     * @returns 替换后的新路径
     */
    public static replacePathSegmentAfter(path: string, newSegment: string, marker: string): string {
        const markerIndex = path.indexOf(marker);
        if (markerIndex === -1) {
            return path;
        }

        const prefix = path.slice(0, markerIndex + marker.length);
        const suffix = path.slice(markerIndex + marker.length);
        const remainingPath = suffix.indexOf('/') !== -1 ? '/' + suffix.slice(suffix.indexOf('/') + 1) : '';

        return `${prefix}${newSegment}${remainingPath}`;
    }

    /**
     * 生成 uuid
     * @returns
     */
    public static generateUUID(): string {
        const hexDigits = '0123456789abcdef';
        let uuid = '';

        // 生成8位的第一段
        for (let i = 0; i < 8; i++) {
            uuid += we.npm.lodash.sampleSize(hexDigits, 1)[0];
        }
        uuid += '-';

        // 生成4位的第二段
        for (let i = 0; i < 4; i++) {
            uuid += we.npm.lodash.sampleSize(hexDigits, 1)[0];
        }
        uuid += '-';

        // 生成4位的第三段
        for (let i = 0; i < 4; i++) {
            uuid += we.npm.lodash.sampleSize(hexDigits, 1)[0];
        }
        uuid += '-';

        // 生成4位的第四段
        for (let i = 0; i < 4; i++) {
            uuid += we.npm.lodash.sampleSize(hexDigits, 1)[0];
        }
        uuid += '-';

        // 生成12位的第五段
        for (let i = 0; i < 12; i++) {
            uuid += we.npm.lodash.sampleSize(hexDigits, 1)[0];
        }

        return uuid;
    }

    /**
     * 验证URL格式的可靠性
     * @param url 待验证的URL
     * @returns
     */
    public static isValidUrl(url: string) {
        if (typeof url !== 'string') {
            return false;
        }

        // 检查是否以 http:// 或 https:// 开头，不区分大小写
        if (!/^https?:\/\//i.test(url)) {
            return false;
        }

        return true;
    }

    /**
     * 检查节点是否有效
     * @param {cc.Node} node
     * @returns {boolean} 节点是否有效
     */
    public static isValidNode(node: cc.Node): boolean {
        if (!cc.isValid(node, true)) {
            return false;
        }
        return node.children.every((child) => {
            return this.isValidNode(child);
        });
    }
}

we.core.utils = Utils;
