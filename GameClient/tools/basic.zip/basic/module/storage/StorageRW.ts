import Utils from '../../utils/Utils';

export class StorageRW {
    public static get(key: string) {
        return cc.sys.localStorage.getItem(key);
    }

    public static set(key: string, value: any) {
        cc.sys.localStorage.setItem(key, value);
    }

    public static clear() {
        cc.sys.localStorage.clear();
    }

    public static remove(key: string) {
        cc.sys.localStorage.removeItem(key);
    }

    public static getInt(key: string) {
        const value = cc.sys.localStorage.getItem(key);
        if (value != null) {
            return parseInt(value);
        }
    }

    public static setInt(key: string, value: number) {
        cc.sys.localStorage.setItem(key, value.toString());
    }

    public static getBool(key: string) {
        const value = cc.sys.localStorage.getItem(key);
        if (value != null) {
            return parseInt(value) === 1;
        }
    }

    public static setBool(key: string, value: boolean) {
        cc.sys.localStorage.setItem(key, value ? '1' : '0');
    }

    public static getFloat(key: string) {
        const value = cc.sys.localStorage.getItem(key);
        if (value != null) {
            return parseFloat(value);
        }
    }

    public static setFloat(key: string, value: number) {
        cc.sys.localStorage.setItem(key, value.toString());
    }

    public static setJson(key: string, value: any) {
        this.set(key, JSON.stringify(value));
    }

    public static getJson(key: string) {
        const value = this.get(key);
        if (!value) {
            return null;
        }
        try {
            return JSON.parse(value);
        } catch (err) {
            we.warn('StorageRW getJson, JSON.parse error ', err);
            return null;
        }
    }

    public static getJsonBase64(key: string) {
        const localValue = this.get(key);
        if (!localValue) {
            return null;
        }

        const string = Utils.base64Decode(localValue);
        if (string) {
            try {
                const value = JSON.parse(string);
                return value;
            } catch (err) {
                we.warn('StorageRW getJsonBase64, JSON.parse error ', err);
                return null;
            }
        }

        return null;
    }

    public static setJsonBase64(key: string, value: any) {
        value = JSON.stringify(value);
        value = Utils.base64Encode(value);
        this.set(key, value);
    }

    public static setBase64(key: string, value: any) {
        this.set(key, Utils.base64Encode(value));
    }

    public static getBase64(key: string) {
        const localValue = this.get(key);
        if (!localValue) {
            return null;
        }

        const value = Utils.base64Decode(localValue);
        return value;
    }
}
