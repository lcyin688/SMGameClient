/**
 * Created by Alibaba on 2018/11/22.
 * * Update list 如下：
 * 1、改为 ES6的写法来实现
 * 2、去掉了一些多余的，未使用的LS key
 */

import { HideBrowserParamKey } from '../../config/ToolsConfig';
import { StorageRW } from './StorageRW';

declare global {
    interface IKit {
        /** sys 缓存，用于获取或保存常用数据 */
        storageUtil: typeof StorageUtil;

        /**
         * 该 key 保留用于兼容线上<=4.0 版本,后续会移除不建议继续使用
         * @deprecated 请使用最新 we.kit.storage.XXX 方式
         */
        StorageKey: typeof StorageKey;
    }
}

/**
 * 该 key 保留用于兼容线上<=4.0 版本,后续会移除不建议继续使用
 * @deprecated 请使用最新 we.kit.storage.XXX 方式
 */
export const StorageKey = {
    /** 设备 id */
    DEVICE_ID: 'device_id',
    /** 域名缓存 */
    APP_DOMAIN_LIST: 'app_domain_list',
    /** adjust 配置 */
    APP_ADJUST_CONFIG: 'app_adjust_config',
    /** 浏览器隐藏参数 */
    URL_HIDE_KEY: 'url_key',
    /** 游戏更新状态 */
    TRACK_GAME_UPDATED: 'track_game_updated',

    /** userId */
    USER_ID: 'user_id',
    /** token */
    USER_TOKEN: 'user_token',
};

we.kit.StorageKey = StorageKey;

export default class StorageUtil {
    /**
     * 读取用户 id
     */
    public static readUserId(): number {
        let userId = we.kit.storage.get('sys', 'user_id') || null;
        if (userId != null) {
            return userId;
        }

        userId = StorageRW.get(StorageKey.USER_ID);
        if (userId == null) {
            userId = Number('-1');
        }
        we.kit.storage.setById('sys', 'user_id', userId);

        return Number(userId);
    }

    /**
     * 读取用户 token
     */
    public static readUserToken(): string {
        let token = we.kit.storage.get('sys', 'user_token');
        if (token) {
            return token;
        }

        token = StorageRW.get(StorageKey.USER_TOKEN);
        if (token == null) {
            token = '';
        }
        we.kit.storage.setById('sys', 'user_token', token);

        return token;
    }

    /**
     * 清空用户 token
     */
    public static clearUserToken() {
        StorageRW.remove(StorageKey.USER_TOKEN);
        we.kit.storage.del('sys', 'user_token');
    }

    /**
     * 是否已经登录
     * @returns
     */
    public static isLogin(): boolean {
        let userId = this.readUserId();
        let userToken = this.readUserToken();
        return userId > -1 && userToken.length > 0;
    }

    /**
     * 读取域名列表
     */
    public static readDomainList(): string[] {
        let list: string[] = we.kit.storage.get('sys', 'app_domain_list') || [];
        if (list.length > 0) {
            return list;
        }

        let data = StorageRW.get(StorageKey.APP_DOMAIN_LIST);
        if (data) {
            try {
                list = JSON.parse(data);
            } catch (err) {
                we.error(`StorageUtil readDomainList, err: ${JSON.stringify(err.message || err)}`);
            }
        }
        we.kit.storage.setById('sys', 'app_domain_list', list);

        return list || [];
    }

    /**
     * 读取Adjust配置
     */
    public static readAdjustConfig(): we.IAdjustConf {
        let data = null;
        data = we.kit.storage.get('sys', 'app_adjust_config');
        if (data) {
            return data;
        }

        data = StorageRW.get(StorageKey.APP_ADJUST_CONFIG);
        if (!data) {
            data = {};
        } else {
            try {
                data = JSON.parse(data);
            } catch (error) {
                data = {};
            }
        }
        we.kit.storage.setById('sys', 'app_adjust_config', data);

        return data;
    }

    /**
     * set 浏览器url隐藏参数
     * @param key
     * @param value
     * @returns
     */
    public static saveHideBrowserKey(key: string, value: string) {
        const arr: string[] = HideBrowserParamKey;
        if (!arr.includes(key)) {
            return;
        }

        // 注意！注意！注意！不可删除
        // 缓存不使用 sys table，确保 h5 index.html 能使用浏览器隐藏参数值
        StorageRW.set(`url_key_${key}`, value);

        let urlKey = we.kit.storage.get('sys', 'url_key') || {};
        urlKey[`url_key_${key}`] = value;
        we.kit.storage.setById('sys', 'url_key', urlKey);
    }

    /**
     * get 浏览器url隐藏参数
     * @param key
     * @returns
     */
    public static readHideBrowserKey(key: string): string {
        const arr: string[] = HideBrowserParamKey;
        if (!arr.includes(key)) {
            return '';
        }

        let value = '';
        let urlKey = we.kit.storage.get('sys', 'url_key') || {};
        value = urlKey?.[`url_key_${key}`];
        if (value) {
            return value;
        }

        value = StorageRW.get(StorageKey.URL_HIDE_KEY + `_${key}`);
        if (value) {
            urlKey[`url_key_${key}`] = value;
            we.kit.storage.setById('sys', 'url_key', urlKey);
        }

        return value || '';
    }

    static removeHideBrowserKey(key: string) {
        const arr: string[] = HideBrowserParamKey;
        if (!arr.includes(key)) {
            return;
        }
        StorageRW.remove(StorageKey.URL_HIDE_KEY + `_${key}`);
    }
}

we.kit.storageUtil = StorageUtil;
