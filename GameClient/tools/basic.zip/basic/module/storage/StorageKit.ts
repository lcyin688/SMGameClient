import { lodash } from '../../utils/NpmExport';
import { StorageRW } from './StorageRW';

declare global {
    interface IKit {
        Storage: typeof StorageKit;
    }

    namespace we {
        namespace kit {
            type Storage<T> = InstanceType<typeof StorageKit<T>>;
        }
    }
}

export class StorageKit<T> {
    /** storage 读写器 */
    public rw: typeof StorageRW;
    /**
     * 输出当前日期的本地格式字符串，例如 "2024/10/21" 或 "10/21/2024"
     */
    static getDayUpdateTime(curDate?: Date): string {
        curDate = curDate || new Date();
        return curDate.toLocaleDateString();
    }

    /** 数据库名 */
    private dbname: string;
    /** 数据 */
    private datas: any = {};
    /** 标记需要保存 */
    private markSave = false;
    /** 是否定时保存 */
    private isTickSave = false;

    constructor(dbname: string) {
        this.rw = StorageRW;
        this.dbname = `we:${dbname}`;
        let content = StorageRW.get(this.dbname);
        if (content?.length) {
            try {
                // 初始化操作
                this.datas = JSON.parse(content);
            } catch (err) {
                we.error('StorageKit constructor, storage get err:', err);
            }
        }
    }

    /**
     * 刷新数据到文件
     */
    public flush() {
        // 写入文件
        const str = JSON.stringify(this.datas);
        StorageRW.set(this.dbname, str);
    }

    /**
     * 获取table数据或者获取表的一个字段的值
     * @param table
     */
    public get<K extends keyof T>(table: K): T[K];
    public get<K extends keyof T, ID extends keyof T[K]>(table: K, id: ID): T[K][ID];
    public get<K extends keyof T>(table: K, ...args) {
        const tdata = this.datas[table];
        if (tdata == null) {
            return null;
        }

        let result = null;
        let id = args[0];
        if (id) {
            result = tdata[id];
        } else {
            result = tdata;
        }

        if (result && lodash.isObject(result)) {
            result = lodash.cloneDeep(result);
        }

        return result;
    }

    /**
     * 设置表数据
     * @param table
     * @param data
     */
    public set<K extends keyof T>(table: K, data: Partial<T[K]>) {
        if (data == null) {
            we.warn('StorageKit set, data is null');
            return;
        }

        let tdata = this.datas[table];
        if (lodash.isArray(data)) {
            tdata = lodash.cloneDeep(data);
        } else if (lodash.isObject(data)) {
            tdata = lodash.mergeWith(tdata ?? {}, lodash.cloneDeep(data), this.customizer);
        } else {
            tdata = data;
        }
        // 更新表数据
        this.datas[table] = tdata;
        this.markModified();
    }

    /**
     * 设置表的一个字段的值
     * @param table
     * @param id
     * @param data
     */
    public setById<K extends keyof T, ID extends keyof T[K]>(table: K, id: ID, data: Partial<T[K][ID]>) {
        if (data == null || id == null) {
            we.warn('StorageKit setById, data or id is null');
            return;
        }

        let tdata = this.datas[table] ?? {};
        // 更新表字段值
        if (lodash.isArray(data)) {
            tdata[id] = lodash.cloneDeep(data);
        } else if (lodash.isObject(data)) {
            tdata[id] = lodash.mergeWith(tdata[id] ?? {}, lodash.cloneDeep(data), this.customizer);
        } else {
            tdata[id] = data;
        }
        // 更新表数据
        this.datas[table] = tdata;
        this.markModified();
    }

    /**
     * 设置本天数据
     */
    public setDay<K extends keyof T, ID extends keyof T[K]>(table: K, id: ID, data: Partial<T[K][ID]>) {
        const updateTime = StorageKit.getDayUpdateTime();
        if (data == null || id == null) {
            we.warn('StorageKit setDay, data or id is null');
            return;
        }
        let tdata = this.datas[table] ?? {};
        let store = {
            data: data,
            update_time: updateTime,
        };
        tdata[id] = lodash.mergeWith(tdata[id] ?? {}, lodash.cloneDeep(store), this.customizer);
        // 更新表数据
        this.datas[table] = tdata;
        this.markModified();
    }

    /**
     * 获取本天数据
     */
    getDay<K extends keyof T, ID extends keyof T[K]>(table: K, id: ID): T[K][ID] | null {
        const store = this.get(table);
        let result = null;
        result = store[id];
        if (result && result?.update_time == StorageKit.getDayUpdateTime()) {
            result = lodash.cloneDeep(result);
            return result?.data || null;
        }
        return null;
    }

    public del<K extends keyof T>(table: K);
    public del<K extends keyof T>(table: K, id: keyof T[K]);
    public del<K extends keyof T>(table: K, ...args) {
        let id = args[0];
        if (!id) {
            delete this.datas[table];
        } else {
            const tdata = this.datas[table];
            if (!tdata) {
                return;
            }
            delete tdata[id];
        }
        this.markModified();
    }

    /**
     * 设置为定时保存，内部则不会保存
     * 等待外部的定时器主动调用save保存
     * @param isSave
     */
    setTickSave(isSave: boolean) {
        this.isTickSave = isSave;
    }

    /**
     * 标记为已修改
     */
    private markModified() {
        this.markSave = true;

        if (this.isTickSave) {
            return;
        }

        this.save();
    }

    private save() {
        if (!this.markSave) {
            return;
        }

        // 写入文件
        const str = JSON.stringify(this.datas);
        this.markSave = false;

        StorageRW.set(this.dbname, str);
    }

    /**
     * 定制mergeWith方法，合并策略
     * @param objValue
     * @param srcValue
     * @returns
     */
    private customizer(objValue: any, srcValue: any) {
        if (lodash.isArray(objValue)) {
            return srcValue;
        }
    }
}

we.kit.Storage = StorageKit;
