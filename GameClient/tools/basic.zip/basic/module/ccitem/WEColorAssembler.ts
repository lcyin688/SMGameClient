const { ccclass, property, menu, disallowMultiple, executeInEditMode } = cc._decorator;

declare global {
    interface IUI {
        WEColorAssembler: typeof WEColorAssembler;
    }
    namespace we {
        namespace ui {
            type WEColorAssembler = InstanceType<typeof WEColorAssembler>;
        }
    }
}

/**
 * Label，Sprite 双色渐变渲染组件
 *
 * cc.RenderComponent
 * 更新 uintVerts 顶点颜色
 *
 * 所有支持渲染的组件 都应该可以实现这个简单的颜色渐变
 *
 * _updateColor() {
 *     if (this._assembler.updateColor) {
 *         let premultiply = this.srcBlendFactor === cc.macro.BlendFactor.ONE;
 *         premultiply && Color.premultiplyAlpha(_temp_color, this.node._color);
 *         let color = premultiply ? _temp_color._val : null;
 *         this._assembler.updateColor(this, color);
 *    }
 * },
 *
 * https://github.com/cocos/cocos-engine/blob/a2f4b48f64e8117cf0d5a93229bfe31932c42384/cocos2d/core/components/CCRenderComponent.js
 *
 * https://github.com/cocos/cocos-engine/blob/a2f4b48f64e8117cf0d5a93229bfe31932c42384/cocos2d/core/renderer/assembler-2d.js
 *
 */

@ccclass
@menu('we/render/WEColorAssembler(渐变渲染)')
@disallowMultiple()
@executeInEditMode()
export class WEColorAssembler extends cc.Component {
    @property
    private _colors: cc.Color[] = [];
    @property({
        type: [cc.Color],
        tooltip: CC_DEV && '颜色列表',
    })
    get colors() {
        return this._colors;
    }
    set colors(value) {
        this._colors = value;
        this._updateColors();
    }

    private finalColor = new cc.Color();

    protected onLoad() {
        const cmp = this.getComponent(cc.RenderComponent);
        if (!cmp) {
            return;
        }

        // 劫持顶点生成方法
        const assembler = cmp['_assembler'];
        if (assembler && assembler.updateRenderData) {
            const originalUpdateRenderData = assembler.updateRenderData.bind(assembler);
            assembler.updateRenderData = () => {
                originalUpdateRenderData?.(cmp);
                if (!this.enabled) {
                    // 禁用状态，不要注入颜色，其他效果组件在生效，避免覆盖其他组件效果颜色
                    return;
                }

                // 同步注入颜色
                this._updateColors();
            };
        }

        if (assembler && assembler.updateColor) {
            const originalUpdateColor = assembler.updateColor.bind(assembler);
            assembler.updateColor = (_, c) => {
                if (!this.enabled) {
                    originalUpdateColor?.(cmp, c);
                    // 禁用状态，不要注入颜色，其他效果组件在生效，避免覆盖其他组件效果颜色
                    return;
                }

                // 同步注入颜色
                this._updateColors();
            };
        }
        this._updateColors();
    }

    protected onEnable() {
        // 初始化颜色，防止颜色相互叠加x
        if (CC_DEV) {
            if (!this.node.color.equals(cc.Color.WHITE)) {
                // 使用 WEColorAssembler 组件，已经将节点自身 node 颜色转变为纯白色，防止颜色叠加
                this.node.color = cc.Color.WHITE;
            }
        }
        this._updateColors();
    }

    protected onDisable() {
        // 还原之前的渲染色彩
        this.node['_renderFlag'] |= cc['RenderFlow'].FLAG_COLOR;
    }

    protected onFocusInEditor() {
        this._updateColors();
    }

    protected onLostFocusInEditor() {
        this._updateColors();
    }

    private getEffectiveOpacity(): number {
        let opacity = this.node.opacity;
        let parent = this.node.parent;
        while (parent) {
            opacity *= parent.opacity / 255;
            parent = parent.parent;
        }
        return Math.round(opacity);
    }

    private _updateColors() {
        const cmp = this.getComponent(cc.RenderComponent);
        if (!cmp || !cmp['_assembler'] || !(cmp['_assembler'] instanceof cc['Assembler2D'])) {
            return;
        }

        // @ts-ignore
        const assembler = cmp['_assembler'] as cc.Assembler2D;
        const uintVerts = assembler._renderData?.uintVDatas?.[0];
        if (!uintVerts) {
            return;
        }
        const color = this.node.color;
        const floatsPerVert = assembler.floatsPerVert;
        const colorOffset = assembler.colorOffset;
        let colorIndex = 0;

        // 获取实际生效的透明度
        const effectiveOpacity = this.getEffectiveOpacity();

        for (let i = colorOffset; i < uintVerts.length; i += floatsPerVert) {
            let targetColor: cc.Color;
            if (this._colors.length === 2) {
                targetColor = colorIndex % 4 < 2 ? this._colors[0] ?? color : this._colors[1] ?? color;
                colorIndex++;
            } else if (this._colors.length > 0) {
                targetColor = this.colors[colorIndex++] || color;
            } else {
                targetColor = cc.Color.WHITE;
            }

            // 合并节点透明度到目标颜色
            this.finalColor.setR(targetColor.r);
            this.finalColor.setG(targetColor.g);
            this.finalColor.setB(targetColor.b);
            this.finalColor.setA(Math.round(targetColor.a * (effectiveOpacity / 255)));

            uintVerts[i] = this.finalColor['_val'];
        }
    }
}

we.ui.WEColorAssembler = WEColorAssembler;
