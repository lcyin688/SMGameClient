declare global {
    interface IUI {
        WELabelShadow: typeof WELabelShadow;
    }
    namespace we {
        namespace ui {
            type WELabelShadow = InstanceType<typeof WELabelShadow>;
        }
    }
}

const { ccclass, property, menu, requireComponent, executeInEditMode } = cc._decorator;

/**
 * 双层 label 投影
 * @warning 一般只在 prefab 编辑模式下使用，不会挂载全局，一般少用
 *
 */
@ccclass()
@requireComponent(cc.Label)
@executeInEditMode()
@menu('we/label/WELabelShadow(文字投影，减少使用)')
export default class WELabelShadow extends cc.Component {
    // 投影 label
    private curLabel: cc.Label = null;

    // 内容 label
    private contentLabel: cc.Label = null;

    onLoad() {
        // 编辑器每次打开该 prefab 都会主动调用一次，并且在 resetInEditor 之前调用 onLoad

        this.curLabel = this.node.getComponent(cc.Label);

        this.contentLabel = this.node.getComponentInChildren(cc.Label);

        if (this.contentLabel) {
            this.contentLabel.string = this.curLabel.string;
        }

        // 节点请检：缺少 Label 子节点，为你自动创建，只在编辑器中生效
        if (CC_DEV && !this.contentLabel) {
            this.init();
        }
    }

    protected start(): void {
        if (!this.contentLabel) {
            return;
        }

        // 警告用户 label 模式不同
        if (CC_DEV && this.curLabel.overflow !== this.contentLabel.overflow) {
            cc.warn('WELabelShadow: label overflow mode must be the same');
        }

        // 同步 string 内容
        this.contentLabel.string = this.curLabel.string;
        const oldCheckStringEmpty = this.curLabel['_checkStringEmpty'];
        this.curLabel['_checkStringEmpty'] = () => {
            oldCheckStringEmpty.call(this.curLabel);
            if (this.contentLabel) {
                this.contentLabel.string = this.curLabel.string;
            }
        };
    }

    init() {
        // add label
        let content = new cc.Node('content');
        content.addComponent(cc.Label);
        this.node.addChild(content);

        this.contentLabel = content.getComponent(cc.Label);

        content.width = this.node.width;
        content.height = this.node.height;

        // 默认偏移值
        content.setPosition(0, 5);

        // 防止被裁剪
        if (this.curLabel.lineHeight < this.curLabel.fontSize) {
            this.curLabel.lineHeight = this.curLabel.fontSize + 4;
        }

        const comAtts = ['string', 'verticalAlign', 'horizontalAlign', 'fontSize', 'overflow', 'font', 'fontFamily', 'enableBold', 'enableItalic', 'cacheMode', 'useSystemFont', 'enableWrapText', 'lineHeight'];

        // 同步属性
        comAtts.forEach((item) => {
            this.contentLabel[item] = this.curLabel[item];
        });

        // 默认投影颜色
        const defShadowColor = new cc.Color().fromHEX('#000000');

        this.node.color = defShadowColor;

        // 默认描边充当阴影
        const outLine = this.node.getComponent(cc.LabelOutline) ?? this.node.addComponent(cc.LabelOutline);
        outLine.color = defShadowColor;
        outLine.width = 2;
    }
}

we.ui.WELabelShadow = WELabelShadow;
