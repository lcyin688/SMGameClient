import { SceneAnimCloseType, SceneAnimOpenType } from '../../ui/helper/SceneAnimHelper';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('we/anim/WEDlgAnimType(view动画类型设置)')
export default class WEDlgAnimType extends cc.Component {
    @property({ displayName: CC_DEV && '打开动画', type: cc.Enum(SceneAnimOpenType) })
    openType = SceneAnimOpenType.SYS;

    @property({ displayName: CC_DEV && '关闭动画', type: cc.Enum(SceneAnimCloseType) })
    closeType = SceneAnimCloseType.SYS;

    /** 打开动画类型 */
    get open() {
        return this.openType;
    }

    /** 关闭动画类型 */
    get close() {
        return this.closeType;
    }
}
