import { StringHelper } from '../../helper/StringHelper';
import { Func } from '../func/Func';
import { FuncAsync } from '../func/FuncAsync';
import Utils from '../../utils/Utils';
import AudioManager from '../../manager/AudioManager';

const { ccclass, menu, requireComponent, disallowMultiple } = cc._decorator;

type EnumButtonPressType = ButtonPressType;
type EnumButtonEventType = ButtonEventType;
declare global {
    interface IUI {
        /** 按钮组件 */
        WEButton: typeof WEButton;
    }

    namespace we {
        namespace ui {
            type WEButton = InstanceType<typeof WEButton>;
            type ButtonPressType = EnumButtonPressType;
            type ButtonEventType = EnumButtonEventType;
        }
    }
}
enum ButtonPressType {
    START = 1,
    END,
}
/**
 * 事件类型枚举
 */
enum ButtonEventType {
    /** 单击 */
    CLICK = 1,
    /** 触摸开始 */
    TOUCH_START,
    /** 触摸移动 */
    TOUCH_MOVE,
    /** 触摸结束 */
    TOUCH_END,
    /** 触摸取消 */
    TOUCH_CANCEL,
    /** 长按事件 */
    PRESS,
    /** 长按循环响应 */
    PRESS_FOR,
}

/** 按钮过渡类型 */
export enum ButtonTransition {
    /**
     * 不做任何过渡。
     */
    NONE = 0,
    /**
     * 颜色过渡。
     */
    COLOR = 1,
    /**
     * 精灵过渡。
     */
    SPRITE = 2,
    /**
     * 缩放过渡。
     */
    SCALE = 3,
}

interface EventArgs {
    [ButtonEventType.CLICK]: [handler: Func<(event: any) => void>, sleepTime?: number];
    [ButtonEventType.TOUCH_START]: [handler: Func<(event: any) => void>];
    [ButtonEventType.TOUCH_END]: [handler: Func<(event: any, touchTs: number) => void>];
    [ButtonEventType.TOUCH_CANCEL]: [handler: Func<(event: any) => void>];
    [ButtonEventType.TOUCH_MOVE]: [handler: Func<(event: any) => void>];
    [ButtonEventType.PRESS]: [handler: Func<(event: any, touchTs: number, pressType: ButtonPressType) => void>, time: number];
    [ButtonEventType.PRESS_FOR]: [handler: Func<(event: any, touchTs: number, count: number) => boolean>, time: number];
}

interface EventItem {
    func: Func<any>;
    /** 是否响应一次 */
    once: boolean;

    // 针对长按事件
    /** 响应时间 */
    time?: number;

    /** 循环响应次数 */
    press_count?: number;
    /** 触摸是否已经开始 */
    press_start?: boolean;
    /** 触摸计数是否已经停止 */
    press_count_stop?: boolean;

    // 针对休眠
    /** 休眠时长 */
    sleepTime?: number;
    /** 休眠定时器 */
    wait?: Promise<any>[];
    /** 定时器取消函数 */
    timerCancel?: () => void;
}

@ccclass
@requireComponent(cc.Button)
@disallowMultiple
@menu('we/button/WEButton(超级按钮组件)')
@we.decorator.typeRegister('WEButton')
export class WEButton extends cc.Component {
    static EventType = ButtonEventType;
    static PressType = ButtonPressType;
    /** 事件存储 */
    private _eventMap: Map<ButtonEventType, EventItem[]> = new Map();

    /** 需要移除的事件map */
    private _rmEventMap: Map<ButtonEventType, EventItem[]> = new Map();

    /** 是否进行排序 */
    private isSort = false;

    /** 需要排序的列表 */
    private _sortList: EventItem[][] = [];

    /** 是否处于触摸状态 */
    private isTouch = false;

    /** 是否触发了长按 */
    private isPress = false;

    /** 是否处于移动中 */
    private isMove = false;

    /** 触摸时长 */
    private touchTs = 0;

    /** 触摸事件 */
    private touchEvent: any = null;

    /** 是否打开音频 */
    private isOpenAudio = true;

    /** 点击音频资源URL */
    private clickAudioUrl: string;

    /** 点击休眠时长 s，防止连续点击，多次触发 */
    private sleepTime: number = -1;

    /** 按钮 */
    private _button: cc.Button;

    get button() {
        this._button = this._button ?? this.node.addComponentUnique(cc.Button);
        return this._button;
    }

    /** 如果当前节点下有一个名字叫做title的Node，则默认上面会有一个Label作为当前按钮的title */
    private _title: cc.Label | null = null;

    get title(): cc.Label | null {
        return this._title;
    }

    /** 是否只响应一次点击事件 ?? */
    private isOnce = false;

    /** 同步处理函数 ??  */
    private syncHandler: Func<() => void>;

    /** 异步，记录是否已经点击 */
    private isAsyncClicked: boolean = false;

    /** 异步处理函数 ?? */
    private asyncHandler: FuncAsync<() => Promise<void>>;

    protected onLoad(): void {
        if (this.sleepTime == -1) {
            this.sleepTime = we.core.SceneHelper.getSceneInfoItem('clickSleepTime') || 0;
        }

        // 按钮音效
        this.clickAudioUrl ??= we.core.SceneHelper.getSceneInfoItem('clickUrl');

        const child = this.node.getChildByName('title');
        if (child) {
            this._title = child.getComponent(cc.Label);
        }
    }

    protected onEnable(): void {
        this.node.on(cc.Node.EventType.TOUCH_START, this.touchStart, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.touchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.touchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.touchCancel, this);
    }

    protected onDisable(): void {
        /** 当不可见时，默认为操作取消 */
        this.isTouch && this.touchCancel(this.touchEvent);

        this.node.off(cc.Node.EventType.TOUCH_START, this.touchStart, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this.touchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this.touchEnd, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.touchCancel, this);
    }

    protected onDestroy(): void {
        this.clearAllEvent();
    }

    /**
     * 连续点击防抖时间
     * @param v 单位 s
     */
    setSleepTime(v: number = 0) {
        this.sleepTime = v;
        return this;
    }

    setContextData(data: any) {
        this.node['__etx_context__'] = data;
    }

    getContextData() {
        return this.node['__etx_context__'];
    }

    /**
     * 注册点击事件
     * @param handler 事件处理函数
     * @param isOnce 是否只执行一次点击事件,默认：false
     * @returns
     */
    onListener(handler: Func<any>, isOnce: boolean = false) {
        this.isOnce = isOnce;
        this.button.clickEvents = [];

        const clickEvent = new cc.Component.EventHandler();
        clickEvent.target = this.node;
        clickEvent.component = WEButton.name;
        clickEvent.handler = 'onClick';

        this.button.clickEvents.push(clickEvent);
        this.syncHandler = handler;

        return this;
    }

    /**
     * 注册异步点击事件
     * @param handler 事件处理函数
     * @param isOnce 是否只执行一次点击事件,默认：false
     * @returns
     */
    onListenerAsync(handler: FuncAsync<(...args) => Promise<void>>, isOnce: boolean = false) {
        this.isOnce = isOnce;
        this.button.clickEvents = [];

        const clickEvent = new cc.Component.EventHandler();
        clickEvent.target = this.node;
        clickEvent.component = WEButton.name;
        clickEvent.handler = 'onClickAsync';

        this.button.clickEvents.push(clickEvent);
        this.asyncHandler = handler;

        return this;
    }

    offListener() {
        this.button.clickEvents = [];
        this.syncHandler = null;
        this.asyncHandler = null;
    }

    /**
     * 触发点击事件
     */
    emitClick() {
        this.button.clickEvents.forEach((event) => {
            event.emit([]);
        });
    }

    setEnableAudio(v: boolean, audioUrl?: string) {
        if (audioUrl && !StringHelper.isNullOrEmpty(audioUrl)) {
            this.clickAudioUrl = audioUrl;
        }
        this.isOpenAudio = v;
        return this;
    }

    /** 设置按钮启用，禁用 */
    setEnableClick(v: boolean, bUseGrayScale: boolean = true) {
        this.button.interactable = v;
        if (!bUseGrayScale) {
            return this;
        }
        this.button.enableAutoGrayEffect = !v;
        return this;
    }

    /**
     * 无效果交互模式
     */
    setTransitionNone() {
        this.button.transition = Number(ButtonTransition.NONE);
        return this;
    }

    /**
     * 图片模式
     * @param conf
     * @returns
     */
    setTransitionSprite(conf: { normal: cc.SpriteFrame; pressed?: cc.SpriteFrame; hover?: cc.SpriteFrame; disabled?: cc.SpriteFrame }) {
        this.button.transition = Number(ButtonTransition.SPRITE);

        this.button.normalSprite = conf.normal;
        if (conf.pressed) {
            this.button.pressedSprite = conf.pressed;
        }

        if (conf.hover) {
            this.button.hoverSprite = conf.hover;
        }

        if (conf.disabled) {
            this.button.disabledSprite = conf.disabled;
        }

        return this;
    }

    /**
     * 颜色变化模式
     * @param conf
     * @returns
     */
    setTransitionColor(conf: { normal: cc.Color; pressed?: cc.Color; hover?: cc.Color; disabled?: cc.Color }) {
        this.button.transition = Number(ButtonTransition.COLOR);

        this.button.normalColor = conf.normal;
        if (conf.pressed) {
            this.button.pressedColor = conf.pressed;
        }

        if (conf.hover) {
            this.button.hoverColor = conf.hover;
        }

        if (conf.disabled) {
            this.button.disabledColor = conf.disabled;
        }

        return this;
    }

    /**
     * 缩放模式
     * @param conf
     * @returns
     */
    setTransitionScale(conf?: { zoomScale: number; duration?: number }) {
        this.button.transition = Number(ButtonTransition.SCALE);

        conf = conf ?? {
            zoomScale: 1.1,
            duration: 0.1,
        };

        conf.duration = conf.duration ?? 0.1;

        this.button.zoomScale = conf.zoomScale;

        return this;
    }

    private playClickAudio() {
        if (this.isOpenAudio && this.clickAudioUrl) {
            AudioManager.playEffect(this.clickAudioUrl);
        }
    }

    protected onClick(e) {
        // 休眠点击，防止按钮多次点击
        if (this.sleepTime > 0 && Utils.isQuickClick(this.node.uuid, this.sleepTime * 1000)) {
            return;
        }

        // 是否处于长按状态
        if (this.isPress) {
            return;
        }

        this.playClickAudio();
        if (this.isOnce) {
            this.cleanClick();
        }
        this.syncHandler.exec(e);
    }

    protected onClickAsync(e) {
        // 防止重复点击，和其余功能冲突
        if (this.isAsyncClicked || this.isPress) {
            return;
        }
        if (this.isOnce) {
            this.cleanClick();
        }
        this.clickActionAsync(e).catch(() => {});
    }

    private async clickActionAsync(e) {
        this.isAsyncClicked = true;
        try {
            this.playClickAudio();
            await this.asyncHandler.exec(e);
        } finally {
            this.isAsyncClicked = false;
        }
    }

    private cleanClick() {
        this.button.clickEvents = [];
    }

    /**
     * 清理所有的事件
     */
    private clearAllEvent() {
        // 清理所有注册的事件
        this._eventMap.forEach((v, k) => {
            if (k == ButtonEventType.CLICK) {
                v.forEach((item) => {
                    item?.timerCancel?.();
                });
            }
            v.length = 0;
        });
        this._eventMap.clear();

        this._rmEventMap.forEach((v, k) => {
            if (k == ButtonEventType.CLICK) {
                v.forEach((item) => {
                    item?.timerCancel?.();
                });
            }
            v.length = 0;
        });
        this._rmEventMap.clear();

        this.button.clickEvents = [];
    }

    /**
     * 监听一个事件
     * @param type
     * @param args
     * @returns
     */
    on<T extends ButtonEventType>(type: T, ...args: EventArgs[T]): WEButton {
        const item: EventItem = {
            func: args[0],
            once: false,
        };

        switch (type) {
            case ButtonEventType.PRESS:
                item.time = args[1];
                item.time = item.time < 0.5 ? 0.5 : item.time;
                break;
            case ButtonEventType.PRESS_FOR:
                item.time = args[1];
                item.time = item.time < 0.5 ? 0.5 : item.time;
                item.press_count = 0;
                break;
            case ButtonEventType.CLICK:
                if (typeof args[1] == 'number') {
                    item.sleepTime = args[1];
                } else {
                    item.sleepTime = this.sleepTime || 0;
                }
                item.wait = [];
                break;
            default:
                break;
        }

        this.addEvent(type, item);

        return this;
    }

    /**
     * 监听一个只执行一次的事件 PRESS_FOR 和 PRESS 会一直执行，直到本次触摸结束,
     * @param type
     * @param args
     * @returns
     */
    once<T extends ButtonEventType>(type: T, ...args: EventArgs[T]): WEButton {
        const item: EventItem = {
            func: args[0],
            once: true,
        };

        switch (type) {
            case ButtonEventType.PRESS:
                item.time = args[1];
                item.time = item.time < 0.5 ? 0.5 : item.time;
                break;
            case ButtonEventType.PRESS_FOR:
                item.time = args[1];
                item.time = item.time < 0.5 ? 0.5 : item.time;
                item.press_count = 0;
                break;
            case ButtonEventType.CLICK:
                item.sleepTime = args[1] || 0;
                item.wait = [];
                break;
            default:
                break;
        }

        this.addEvent(type, item);

        return this;
    }

    /**
     * 移除事件
     * @param type
     * @param handler
     * @param target
     * @returns
     */
    off<T extends ButtonEventType>(type?: T, handler?: (...args: any[]) => any, target?: any): WEButton {
        // 移除所有的事件
        if (!type && !handler && !target) {
            this.clearAllEvent();
            return this;
        }

        const removeHandler = (list: EventItem[]) => {
            let len = list.length;
            if (len <= 0) {
                return;
            }
            for (let i = 0; i < len; i++) {
                const item = list[i];
                if (item.func.equal(handler, target)) {
                    list.splice(i, 1);
                    i--;
                    len--;
                }
            }
        };

        if (!type) {
            this._eventMap.forEach((list, k) => {
                removeHandler(list);
            });

            this._rmEventMap.forEach((list, k) => {
                removeHandler(list);
            });
            return this;
        }

        const elist = this._eventMap.get(type) || [];
        removeHandler(elist);

        const rlist = this._rmEventMap.get(type) || [];
        removeHandler(rlist);

        return this;
    }

    /**
     * 添加一个事件
     * @param type
     * @param handler
     * @param target
     * @param opts
     */
    private addEvent<T extends ButtonEventType>(type: T, item: EventItem) {
        let list = this._eventMap.get(type);
        if (!list) {
            list = [];
            this._eventMap.set(type, list);
        }

        list.push(item);

        let rmList = this._rmEventMap.get(type);
        if (!rmList) {
            this._rmEventMap.set(type, []);
        }

        if ([ButtonEventType.PRESS, ButtonEventType.PRESS_FOR].includes(type)) {
            this.setPressSort(list);
        }
    }

    /**
     * 长按事件排序
     * @param list
     */
    private setPressSort(list: EventItem[]) {
        this.isSort = true;
        this._sortList.push(list);
        Promise.resolve().then(() => {
            this.pressEventSort();
        });
    }

    /** 针对事件进行排序 */
    private pressEventSort() {
        if (!this.isSort) {
            return;
        }
        this.isSort = false;

        // 开始排序
        for (const list of this._sortList) {
            list.sort((a, b) => {
                return a.time - b.time;
            });
        }

        this._sortList.length = 0;
    }

    protected update(dt: number): void {
        if (!this.isTouch) {
            return;
        }

        this.touchTs += dt;

        this.runTouchPress(ButtonPressType.START);
        this.runTouchPressFor();
    }

    /**
     * 触摸事件开始
     * @param event
     */
    private touchStart(event) {
        if (!this.button.interactable) {
            return;
        }

        this.touchEvent = event;
        this.runTouchStart(event);
        // 标记触摸已经开始
        this.touchTs = 0;
        this.isTouch = true;
    }

    /**
     * 处理移动事件
     * @param event
     */
    private touchMove(event: any) {
        if (!this.button.interactable) {
            return;
        }

        this.touchEvent = event;
        this.updateMoveDistance(event);

        this.isMove && this.runTouchMove(event);
    }

    /**
     * 触摸事件结束
     * @param event
     */
    private touchEnd(event) {
        if (!this.button.interactable) {
            this.isTouch && this.touchOver();
            return;
        }

        this.touchEvent = event;
        this.isPress ? this.runTouchPress(ButtonPressType.END) : this.runTouchClick(event);
        this.runTouchEnd(event);
        this.rmOnceEvent();
        this.touchOver();
    }

    /**
     * 触摸取消
     * @param event
     */
    private touchCancel(event) {
        if (!this.button.interactable) {
            this.isTouch && this.touchOver();
            return;
        }

        this.touchEvent = event;
        this.runTouchCancel(event);

        // 如果是取消功能则不移除一次性长按事件
        this._rmEventMap.forEach((list, k) => {
            if (k == ButtonEventType.PRESS) {
                return;
            }
        });

        this.rmOnceEvent();

        this.touchOver();
    }

    private updateMoveDistance(event: any) {
        if (this.isMove) {
            return;
        }

        const startPoint: cc.Vec2 = event.touch._startPoint;
        const point: cc.Vec2 = event.touch._point;

        const _distanceX = Math.abs(point.x - startPoint.x);
        const _distanceY = Math.abs(point.y - startPoint.y);

        (_distanceX > 5 || _distanceY > 5) && (this.isMove = true);
    }

    private runTouchStart(event: any) {
        const list = this._eventMap.get(ButtonEventType.TOUCH_START);
        if (!list || list.length <= 0) {
            return;
        }

        const runHandler = (i = 0) => {
            const item = list[i];

            if (!item) {
                return;
            }

            try {
                item.func.exec(event);
            } finally {
                item.once && // once类型则将时间添加到删除map
                    this._rmEventMap.get(ButtonEventType.TOUCH_START).push(item);

                runHandler(i + 1);
            }
        };

        runHandler();
    }

    private runTouchMove(event: any) {
        const list = this._eventMap.get(ButtonEventType.TOUCH_MOVE);

        if (!list || list.length <= 0) {
            return;
        }

        const runHandler = (i = 0) => {
            const item = list[i];

            if (!item) {
                return;
            }

            try {
                item.func.exec(event);
            } finally {
                item.once && list.splice(i, 1) && runHandler(i);
                !item.once && runHandler(i + 1);
            }
        };

        runHandler();
    }

    /**
     * 处理结束事件
     * @param event
     * @returns
     */
    private runTouchEnd(event: any) {
        const list = this._eventMap.get(ButtonEventType.TOUCH_END);
        if (!list || list.length <= 0) {
            return;
        }

        const runHandler = (i = 0) => {
            const item = list[i];

            if (!item) {
                return;
            }

            try {
                item.func.exec(event, this.touchTs);
            } finally {
                // move事件执行一次后就应该删除
                item.once && // once类型则将时间添加到删除map
                    list.splice(i, 1) &&
                    runHandler(i);

                !item.once && runHandler(i + 1);
            }
        };

        runHandler();
    }

    private runTouchCancel(event: any) {
        const list = this._eventMap.get(ButtonEventType.TOUCH_CANCEL);
        if (!list || list.length <= 0) {
            return;
        }

        const runHandler = (i = 0) => {
            const item = list[i];

            if (!item) {
                return;
            }

            try {
                item.func.exec(event);
            } finally {
                // 移除事件
                item.once && // once类型则将时间添加到删除map
                    this._rmEventMap.get(ButtonEventType.TOUCH_CANCEL).push(item);
                runHandler(i + 1);
            }
        };

        runHandler();
    }

    /**
     * 处理点击事件
     * @param event
     * @returns
     */
    private runTouchClick(event: any) {
        const list = this._eventMap.get(ButtonEventType.CLICK);
        if (!list || list.length <= 0) {
            return;
        }

        // 所有事件只播放一个音效
        this.playClickAudio();

        const runTimerHandler = async (item: EventItem, time: number) => {
            if (time <= 0 || item.once) {
                return;
            }

            const wait = new Promise((resolve, reject) => {
                const timer = setTimeout(() => {
                    item.timerCancel = null;
                    const cpResolve = resolve;
                    resolve = null;
                    cpResolve(0);
                }, time * 1000);

                item.timerCancel = () => {
                    clearTimeout(timer);
                    resolve?.(0);
                };
            });

            item.wait.push(wait);
            await wait;
            const idx = item.wait.indexOf(wait);
            idx >= 0 && item.wait.splice(idx, 1);
        };

        const runEventnHandler = async (item: EventItem) => {
            const result = Promise.resolve().then(() => {
                return item.func.exec(event);
            });

            !item.once && item.wait.push(result);

            // 如果按钮报错也是需要解锁
            try {
                await result;
            } finally {
                if (!item.once) {
                    const idx = item.wait.indexOf(result);
                    idx >= 0 && item.wait.splice(idx, 1);
                }
            }
        };

        const runHandler = (i = 0) => {
            const item = list[i];

            if (!item) {
                return;
            }

            const waitLenth = item.wait.length;

            waitLenth == 0 && //
                runEventnHandler(item) &&
                runTimerHandler(item, item.sleepTime);

            item.once && // once类型则将时间添加到删除map
                this._rmEventMap.get(ButtonEventType.CLICK).push(item);

            runHandler(i + 1);
        };

        runHandler();
    }

    /**
     * 处理长按开始
     */
    private runTouchPress(type: ButtonPressType) {
        const list = this._eventMap.get(ButtonEventType.PRESS);
        if (!list || list.length <= 0) {
            return;
        }

        const ts = this.touchTs;

        const runEventHandler = (item: EventItem, type: ButtonPressType) => {
            try {
                item.func.exec(this.touchEvent, this.touchTs, type);
            } finally {
            }
            return true;
        };

        const runHandler = (i = 0) => {
            const item = list[i];

            // 处理完了或者时间未到则不处理，长按事件是按照时间进行了排序
            if (!item || ts < item.time) {
                return;
            }

            // 长按开始
            ts >= item.time && //
                !item.press_start &&
                (this.isPress = true) &&
                (item.press_start = true) &&
                runEventHandler(item, ButtonPressType.START);

            // 长按结束
            type == ButtonPressType.END && //
                ts >= item.time &&
                runEventHandler(item, ButtonPressType.END);

            // 根据条件移除事件
            type == ButtonPressType.END && //
                item.once &&
                this._rmEventMap.get(ButtonEventType.PRESS).push(item);

            runHandler(i + 1);
        };

        runHandler();
    }

    /**
     * 处理长安事件
     * @returns
     */
    private runTouchPressFor() {
        const list = this._eventMap.get(ButtonEventType.PRESS_FOR);
        if (!list || list.length <= 0) {
            return;
        }

        const ts = this.touchTs;

        const runEventHandler = (item: EventItem, count: number) => {
            let result;
            try {
                result = item.func.exec(this.touchEvent, this.touchTs, count);
            } finally {
            }
            return result;
        };

        const runHandler = (i = 0) => {
            const item = list[i];

            // 处理完了或者时间未到则不处理，长按事件是按照时间进行了排序
            if (!item || ts < item.time) {
                return;
            }

            // 执行回调处理函数
            const count = Math.floor(ts / item.time);
            !item.press_count_stop && //
                count > item.press_count &&
                (this.isPress = true) &&
                (item.press_count = count) &&
                (item.press_count_stop = runEventHandler(item, count));

            // 记录是否只执行一次
            item.once && //
                this._rmEventMap.get(ButtonEventType.PRESS_FOR).push(item);

            runHandler(i + 1);
        };

        runHandler();
    }

    /**
     * 移除需要删除的一次性事件
     */
    private rmOnceEvent() {
        this._rmEventMap.forEach((list, type) => {
            const originList = this._eventMap.get(type) || [];
            for (const itm of list) {
                // 取消定时任务
                type == ButtonEventType.CLICK && itm?.timerCancel?.();

                const idx = originList.indexOf(itm);
                idx >= 0 && originList.splice(idx, 1);
            }
            list.length = 0;
        });
    }

    private touchOver() {
        this.touchEvent = null;
        this.touchTs = 0;
        this.isTouch = false;
        this.isMove = false;
        this.isPress = false;

        // 重置部分属性
        this._eventMap.get(ButtonEventType.PRESS)?.forEach((item) => {
            item.press_start = false;
        });

        // 重置部分属性
        this._eventMap.get(ButtonEventType.PRESS_FOR)?.forEach((item) => {
            item.press_count = 0;
            item.press_count_stop = false;
        });
    }
}

we.ui.WEButton = WEButton;
