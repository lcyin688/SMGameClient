import Utils from '../../utils/Utils';

declare global {
    interface IUI {
        WETimeCountDown: typeof WETimeCountDown;
    }

    namespace we {
        namespace ui {
            type WETimeCountDown = InstanceType<typeof WETimeCountDown>;
        }
    }
}

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('we/feat/TimeCountDown(倒计时)')
export class WETimeCountDown extends cc.Component {
    /** 时长 */
    // private _duration: number = 0;
    // private _elapsed: number = 0;

    // private _fromat = '{HH}:{MM}:{SS}';

    // private _update_call = (formatStr: string, duration: number, elapsed: number) => { };

    // private _resolve = null;

    private _countDownOb = {
        /** 计时开始时间 */
        _startTs: 0,
        _duration: 0,
        _elapsed: 0,
        _fromat: '{HH}:{MM}:{SS}',
        _update_call: (formatStr: string, duration: number, elapsed: number) => {},
        _resolve: null,
        _is_pause: false,
        /** 是否每帧更新回调 */
        _is_updatedt: false,
    };

    private _timeingOb = {
        /** 开始计时的时间戳 */
        _startTs: 0,
        /** 开始计时时间 */
        _startTime: 0,
        /** 当前计时时间 */
        _currTime: 0,
        /** 计时格式化 */
        _format: '{HH}:{MM}:{SS}',
        /** 计时更新函数 */
        _update_call: (formatStr: string, start: number, curr: number) => {},
        /** 是否正在更新 */
        _is_update: false,
        /** 计时是否暂停 */
        _is_pause: false,
        /** 是否每帧更新回调 */
        _is_updatedt: false,
    };

    /**
     * 开始倒计时
     * @param elapsed 已过时长 (s)
     * @param duration 剩余时长 (s)
     * @param format 格式化函数
     * @param update(value: 格式化后的字符串, duration: 设置的时长, elapsed: 已过时长)
     * @param isUpdateDt 是否每帧更新
     */
    public countDown(elapsed: number, duration: number, format = '{HH}:{MM}:{SS}', update?: (formatStr: string, duration: number, elapsed: number) => void, isUpdateDt: boolean = false) {
        this._countDownOb._startTs = Date.now();
        this._countDownOb._duration = duration;
        this._countDownOb._elapsed = elapsed;
        this._countDownOb._fromat = format;
        this._countDownOb._update_call = update;
        this._countDownOb._is_updatedt = isUpdateDt;
        this.updateRemain();

        return new Promise((resolve) => {
            this._countDownOb._resolve = resolve;
        });
    }

    /**
     * 暂停倒计时
     */
    public pauseCountDown() {
        this._countDownOb._is_pause = true;
    }

    /**
     * 恢复计时
     */
    public resumeCountDown() {
        this._countDownOb._is_pause = false;
    }

    /**
     * 清理倒计时
     */
    public clearCountDown() {
        const ob = this._countDownOb;
        ob._duration = 0;
        ob._elapsed = 0;
        ob._update_call?.('', 0, 0);
    }

    /**
     * 计时
     * @param startTime 开始时间
     * @param update 计时更新函数
     */
    public timeing(startTime: number, update: (formatStr: string, start: number, curr: number) => void, isUpdateDt?: boolean);
    /**
     * 计时
     * @param format 时间格式化模板
     * @param update 计时更新函数
     */
    public timeing(format: string, update: (formatStr: string, start: number, curr: number) => void, isUpdateDt?: boolean);
    /**
     * 计时
     * @param startTime 开始时间
     * @param format 时间格式化模板
     * @param update 计时更新函数
     */
    public timeing(startTime: number, format: string, update: (formatStr: string, start: number, curr: number, isUpdateDt?: boolean) => void);
    public timeing(...args: any[]) {
        let startTime = 0;
        let format = '{HH}:{MM}:{SS}';
        let updateFn: any = (formatStr: string, start: number, curr: number) => {};
        let isUpdateDt = false;

        if (typeof args[0] == 'number') {
            startTime = args[0];
        } else if (typeof args[0] == 'string') {
            format = args[0];
        }

        if (typeof args[1] == 'string') {
            format = args[1];
        } else if (typeof args[1] == 'function') {
            updateFn = args[1];
        }

        if (typeof args[2] == 'boolean') {
            isUpdateDt = args[2];
        } else if (typeof args[2] == 'function') {
            updateFn = args[2];
        }

        if (typeof args[3] == 'boolean') {
            isUpdateDt = args[3];
        }

        this._timeingOb._startTs = Date.now();
        this._timeingOb._currTime = startTime;
        this._timeingOb._startTime = startTime;
        this._timeingOb._format = format;
        this._timeingOb._update_call = updateFn;
        this._timeingOb._is_update = true;
        this._timeingOb._is_pause = false;
        this._timeingOb._is_updatedt = isUpdateDt;
    }

    /**
     * 暂停计时
     */
    public pauseTimeing() {
        this._timeingOb._is_pause = true;
    }

    /**
     * 恢复计时
     */
    public resumeTimeing() {
        this._timeingOb._is_pause = false;
    }

    /**
     * 停止计时
     */
    public stopTimeing() {
        this._timeingOb._is_update = false;
    }

    /**
     * 清理计时，会调用一次update函数，会默认将 formatStr 置空
     */
    public clearTimeing() {
        this._timeingOb._currTime = 0;
        this._timeingOb._startTime = 0;
        this._timeingOb._format = '{HH}:{MM}:{SS}';
        this._timeingOb._is_update = false;
        this._timeingOb?._update_call('', 0, 0);
    }

    /**
     * 更新剩余倒计时时间
     * @param time
     */
    public updateDwon(time: number) {
        if (this._countDownOb._duration == 0) {
            return;
        }
        if (time > this._countDownOb._duration) {
            return;
        }

        this._countDownOb._elapsed = this._countDownOb._duration - time;

        this.updateRemain();
    }

    /**
     * 更新一次数据
     */
    private updateRemain() {
        const ob = this._countDownOb;
        const time = Math.ceil(ob._duration - ob._elapsed);
        const timeStr = Utils.formatTime(time, ob._fromat);

        try {
            ob._update_call?.(timeStr, ob._duration, ob._elapsed);
        } catch (err) {
            we.error(`WETimeCountDown updateRemain, err: ${JSON.stringify(err.message || err)}`);
            ob._update_call = null;
        }

        // 倒计时结束
        if (ob._duration == ob._elapsed) {
            ob._resolve?.();
            ob._resolve = null;
        }
    }

    private countDownUpdate(dt: number) {
        const ob = this._countDownOb;
        if (ob._duration == ob._elapsed || ob._is_pause) {
            return;
        }

        const prevElapsed = ob._elapsed;
        const curTs = Date.now();
        ob._elapsed = (curTs - ob._startTs) / 1000;

        if (!ob._is_updatedt && Math.floor(prevElapsed) == Math.floor(ob._elapsed)) {
            return;
        }

        if (ob._elapsed >= ob._duration) {
            ob._elapsed = ob._duration;
            this.updateRemain();
            return;
        }

        this.updateRemain();
    }

    private updateTimeingFormat() {
        const ob = this._timeingOb;
        const time = Math.ceil(ob._currTime);
        const timeStr = Utils.formatTime(time, ob._format);

        try {
            ob._update_call?.(timeStr, ob._startTime, ob._currTime);
        } catch (err) {
            we.error(`WETimeCountDown updateTimeingFormat, err: ${JSON.stringify(err.message || err)}`);
            ob._update_call = null;
        }
    }

    private updateTimeing(dt: number) {
        const ob = this._timeingOb;
        if (!ob._is_update || ob._is_pause) {
            return;
        }
        const prevCurrTime = ob._currTime;
        const curTs = Date.now();
        ob._currTime = (curTs - ob._startTs) / 1000;

        if (!ob._is_updatedt && Math.floor(prevCurrTime) == Math.floor(ob._currTime)) {
            return;
        }

        this.updateTimeingFormat();
    }

    protected update(dt: number): void {
        this.countDownUpdate(dt);
        this.updateTimeing(dt);
    }
}

we.ui.WETimeCountDown = WETimeCountDown;
