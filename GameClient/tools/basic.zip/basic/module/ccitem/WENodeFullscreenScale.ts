import { CCHelper } from '../../helper/CCHelper';

const { ccclass, menu, disallowMultiple } = cc._decorator;

declare global {
    interface IUI {
        WENodeFullscreenScale: typeof WENodeFullscreenScale;
    }

    namespace we {
        namespace ui {
            type WENodeFullscreenScale = InstanceType<typeof WENodeFullscreenScale>;
        }
    }
}

/**
 * 节点等比缩放铺满全屏
 */
@ccclass
@disallowMultiple
@menu('we/adapt/WENodeFullscreenScale(节点等比缩放铺满全屏)')
export class WENodeFullscreenScale extends cc.Component {
    protected onLoad(): void {
        this.adapt();
        cc.view.on('canvas-resize', this.adapt, this);
    }

    protected onDestroy(): void {
        cc.view.off('canvas-resize', this.adapt, this);
    }

    private adapt() {
        CCHelper.Node.maxScaleFullScreenNode(this.node);
    }
}

we.ui.WENodeFullscreenScale = WENodeFullscreenScale;
