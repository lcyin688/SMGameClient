const { ccclass, property, menu } = cc._decorator;

/**
 * 适配全屏
 * node上不能挂载cc.Widget，父节点必须为全屏节点，背景默认编辑器全屏展示
 */
@ccclass
@menu('we/adapt/WEAdaptFullScreen(全屏背景适配)')
export default class WEAdaptFullScreen extends cc.Component {
    // 原始高度
    heightOriginal: number = 0;

    // 原始宽度
    widthOriginal: number = 0;

    protected onLoad() {
        const sp = this.node.getComponent(cc.Sprite);
        if (!sp) {
            return;
        }

        if (!sp.spriteFrame) {
            this.heightOriginal = this.node.height;
            this.widthOriginal = this.node.width;
        } else {
            this.heightOriginal = sp.spriteFrame.getOriginalSize().height;
            this.widthOriginal = sp.spriteFrame.getOriginalSize().width;
        }

        const oldApplySpriteSize = sp['_applySpriteSize'];
        sp['_applySpriteSize'] = () => {
            oldApplySpriteSize.call(sp);
            if (sp.spriteFrame) {
                this.heightOriginal = sp.spriteFrame.getOriginalSize().height;
                this.widthOriginal = sp.spriteFrame.getOriginalSize().width;
            }
            this.onAdapt();
        };

        cc.view.on('canvas-resize', this.onAdapt, this);
    }

    protected onDestroy(): void {
        cc.view.off('canvas-resize', this.onAdapt, this);
    }

    protected onEnable(): void {
        this.onAdapt();
    }

    onAdapt() {
        const sp = this.node.getComponent(cc.Sprite);
        if (!sp) {
            return;
        }
        if (this.heightOriginal < cc.winSize.height) {
            this.node.height = cc.winSize.height;
        } else {
            this.node.height = this.heightOriginal;
        }

        if (this.widthOriginal < cc.winSize.width) {
            this.node.width = cc.winSize.width;
        } else {
            this.node.width = this.widthOriginal;
        }
    }
}
