import { AsyncTask } from '../async/AsyncTask';
import { Func } from '../func/Func';
import { ObjectPool } from '../objectpool/ObjectPool';
import { ISingletonInstance, ISingletonUpdate, Singleton } from '../singleton/Singleton';

declare global {
    interface ICore {
        timer: TimerComponent;
    }
}

/**
 * 定时器类型
 */
enum TimerType {
    None,
    /**
     * 重复执行
     */
    RepeatedTimer,

    /**
     * 等待定时器开位置
     */
    WaitTimer_Start = 1000,
    /**
     * 按时间等待，执行一次
     */
    TimeOnceTimer,
    /**
     * 按帧等待
     */
    FrameWaitTimer,
}

/**
 * 定时器Tag类型
 */
export type TimerTag = number | string | object | symbol;
/**
 * Timer绑定对象
 */
export type TimerTarget = { isValid: () => boolean } | { isValid: boolean };

/**
 * 定时器Action
 */
class TimerAction {
    /**
     * 创建基于时间的定时器
     * @param id 定时器Id
     * @param type 定时器类型
     * @param startTime 开始时间
     * @param time 定时器时长
     * @param handler 定时处理函数
     * @param tag 标记
     * @returns
     */
    public static createTime(id: number, type: TimerType, startTime: number, time: number, handler: Func<() => void>, tag: TimerTag): TimerAction {
        const timerAction = ObjectPool.Inst.fetch(TimerAction);
        timerAction.id = id;
        timerAction.type = type;
        timerAction.startTime = startTime;
        timerAction.handler = handler;
        timerAction.interval = time;
        timerAction.tag = tag;
        return timerAction;
    }

    /**
     * 创建基于帧的定时器
     * @param id 定时器Id
     * @param type 定时器类型
     * @param frame 帧数
     * @param handler 定时处理函数
     * @param tag 标记
     * @returns
     */

    public static createFrame(id: number, type: TimerType, frame: number, handler: Func<() => void>, tag: TimerTag) {
        const timerAction = ObjectPool.Inst.fetch(TimerAction);
        timerAction.id = id;
        timerAction.type = type;
        timerAction.frame = frame;
        timerAction.handler = handler;
        timerAction.tag = tag;
        return timerAction;
    }

    /**
     * 定时器Id
     */
    public id: number;
    /**
     * 定时器类型
     */
    public type: TimerType;
    /**
     * 定时器响应函数
     */
    public handler: Func<() => void>;
    /**
     * 开始计时时间，单位【毫秒】
     */
    public startTime: number;
    /**
     * 执行周期，单位【毫秒】
     */
    public interval: number;
    /**
     * 帧数
     */
    public frame: number;
    /**
     * 定时器tag
     */
    public tag: TimerTag;

    /**
     * 是否中断定时任务
     * 是：则后续逻辑不再执行
     * 否：等待定时任务继续执行
     */
    public isBroken: boolean;

    public recycle(): void {
        if (!this.handler) {
            // 避免重复回收
            return;
        }
        this.id = 0;
        this.handler = null;
        this.startTime = null;
        this.interval = null;
        this.frame = null;
        this.tag = null;
        this.isBroken = null;
        this.type = TimerType.None;
        ObjectPool.Inst.recycle(this); // 需要实现对象池的相关逻辑
    }
}

/**
 * 定时器组件
 */
@we.decorator.typeSingleton<ISingletonInstance>('TimerComponent')
export class TimerComponent extends Singleton implements ISingletonUpdate {
    /**
     * key： 执行时间戳
     * value： timeId集合
     */
    private readonly timeIds = new Map<number, number[]>();
    private readonly frameTimeIds = new Set<number>();

    /**
     * 已经到达执行时间的timer时间列表
     */
    private readonly timeOutTime: number[] = [];
    /**
     * 已经到达执行时间的TimerId集合
     */
    private readonly timeOutTimerIds: number[] = [];
    /**
     * 定时器action列表
     */
    private readonly timerActions = new Map<number, TimerAction>();
    /**
     * Timer id生成器
     */
    private idGenerator = 0;

    /**
     * 记录最小时间，不用每帧都去Map检查超时定时器
     */
    private minTime: number = Number.MAX_VALUE;

    static get Inst() {
        return this.getInstance();
    }

    update(): void {
        if (this.frameTimeIds.size > 0) {
            this.updateFrame();
        }

        if (this.timeIds.size === 0) {
            return;
        }

        const timeNow = this.getNow();
        if (timeNow < this.minTime) {
            return;
        }

        let minTime = null;
        for (const [time] of this.timeIds.entries()) {
            if (time > timeNow) {
                if (minTime === null) {
                    minTime = time;
                    continue;
                }
                // 取继续等待队列中的最小时间
                minTime = time < minTime ? time : minTime;
            } else {
                this.timeOutTime.push(time);
            }
        }
        this.minTime = minTime ?? timeNow;

        while (this.timeOutTime.length > 0) {
            const time = this.timeOutTime.shift();
            const list = this.timeIds.get(time);
            if (list) {
                for (let i = 0; i < list.length; ++i) {
                    const timerId = list[i];
                    this.timeOutTimerIds.push(timerId);
                }
                this.timeIds.delete(time);
            }
        }

        while (this.timeOutTimerIds.length > 0) {
            const timerId = this.timeOutTimerIds.shift();

            const timerAction = this.timerActions.get(timerId);
            if (!timerAction) {
                continue;
            }
            this.timerActions.delete(timerAction.id);
            this.run(timerAction);
        }
    }

    /**
     * 按帧更新timer
     */
    private updateFrame() {
        for (let timerId of this.frameTimeIds) {
            const timerAction = this.timerActions.get(timerId);
            if (!timerAction) {
                this.frameTimeIds.delete(timerId);
                continue;
            }

            --timerAction.frame;

            if (timerAction.frame > 0) {
                continue;
            }

            this.timerActions.delete(timerAction.id);
            this.frameTimeIds.delete(timerAction.id);
            this.run(timerAction);
        }
    }

    /**
     * 等待x帧数后返回,可用于分帧加载等业务场景
     * @param frame 帧数，默认:1
     * @param target 定时器生命周期绑定对象（Entity/cc.Node/cc.Component等）,存在isValid()或者isValid, 为null时，默认绑定到当前场景
     * @param cancleAction 提前结束等待
     */
    public async waitFrame(frame?: number, target?: TimerTarget, tag?: TimerTag): Promise<void> {
        // 定时器默认生命周期保底绑定到当前场景
        target ??= we.currentScene;
        frame = frame ?? 1;
        frame = Math.max(frame, 1);

        const asyncTask = new AsyncTask<boolean>();

        let func = Func.create(() => {
            asyncTask.setResult(null);
        }, target);

        const timer = TimerAction.createFrame(this.getId(), TimerType.FrameWaitTimer, frame, func, tag);
        this.addFrameTimer(timer);

        await asyncTask.wait();
    }

    /**
     * 执行一次的定时器
     * @param time 时长，单位【秒】,为0时，下帧执行
     * @param target 定时器生命周期绑定对象（Entity/cc.Node/cc.Component等）,存在isValid()或者isValid, 为null时，默认绑定到当前场景
     * @param tag 定时器Tag
     * @returns
     */
    public async scheduleOnce(time: number, target?: TimerTarget, tag?: TimerTag): Promise<void> {
        // 定时器默认生命周期保底绑定到当前场景
        target ??= we.currentScene;
        if (time <= 0) {
            await this.waitFrame(1, target, tag);
        } else {
            let asyncTask = AsyncTask.create();
            let func = Func.create(() => {
                asyncTask.setResult(null);
            }, target);

            let timer = TimerAction.createTime(this.getId(), TimerType.TimeOnceTimer, this.getNow(), time * 1000, func, tag);
            this.addTimer(timer);
            await asyncTask.wait();
        }
    }

    /**
     * 周期执行的定时器
     * @param time 间隔时间，单位【秒】
     * @param func 定时器处理函数对象
     * @param target func所属对象Entity/cc.Node/cc.Component等）, 为null时，默认绑定到当前场景
     * @returns
     */
    public schedule(time: number, func: () => void, target?: TimerTarget, tag?: TimerTag): number;
    /**
     * 周期执行的定时器
     * @param time 间隔时间，单位【秒】
     * @param func 定时器处理函数对象
     * @returns
     */
    public schedule(time: number, func: Func<any>, tag?: TimerTag): number;
    public schedule(time: number, ...args): number {
        if (time <= 0) {
            we.error(`TimerComponent schedule time too small: ${time} s`);
            return 0;
        }

        const timeNow = this.getNow();
        let tag: TimerTag;

        let func = args[0];
        if (!(func instanceof Func) && args.length >= 2) {
            func = Func.create(func, args[1] ?? we.currentScene);
            tag = args[2];
        } else {
            tag = args[1];
        }

        const timer = TimerAction.createTime(this.getId(), TimerType.RepeatedTimer, timeNow, time * 1000, func, tag);
        this.addTimer(timer);

        return timer.id;
    }

    /**
     * 移除定时器
     * @param id 定时器Id
     * @param isBroken 默认：true，是否中断定时任务，后面逻辑不再执行
     * @returns
     */
    public removeById(id: number, isBroken: boolean = true) {
        if (id === 0) {
            return;
        }

        const timerAction = this.timerActions.get(id);
        if (!timerAction) {
            return;
        }

        if (timerAction.type > TimerType.WaitTimer_Start) {
            timerAction.isBroken = isBroken;
            this.run(timerAction);
        } else {
            if (!isBroken) {
                this.run(timerAction);
            }
        }

        timerAction.recycle();
        this.timerActions.delete(id);
    }

    /**
     * 移除定时器
     * @param tag 定时器Tag
     * @param isBroken 默认:true, 是否中断定时任务，后面逻辑不再执行
     * @returns
     */
    public removeByTag(tag: TimerTag, isBroken: boolean = true) {
        for (let timerAction of this.timerActions.values()) {
            if (timerAction.tag != null && timerAction.tag === tag) {
                this.removeById(timerAction.id, isBroken);
            }
        }
    }

    private getId(): number {
        return ++this.idGenerator;
    }

    private getNow(): number {
        return Date.now();
    }

    private run(timerAction: TimerAction): void {
        switch (timerAction.type) {
            case TimerType.RepeatedTimer: {
                const timeNow = this.getNow();
                timerAction.startTime = timeNow;
                this.addTimer(timerAction);
                timerAction.handler.exec();
                break;
            }
            case TimerType.TimeOnceTimer:
            case TimerType.FrameWaitTimer: {
                if (!timerAction.isBroken) {
                    timerAction.handler.exec();
                }
                timerAction.recycle();
                break;
            }
            default:
                break;
        }
    }

    private addTimer(timer: TimerAction): void {
        if (!timer.handler.isValidFunc()) {
            return;
        }

        const tillTime = timer.startTime + timer.interval;
        if (!this.timeIds.has(tillTime)) {
            this.timeIds.set(tillTime, []);
        }
        const list = this.timeIds.get(tillTime);
        if (list) {
            list.push(timer.id);
        }
        this.timerActions.set(timer.id, timer);
        if (tillTime < this.minTime) {
            this.minTime = tillTime;
        }
    }

    private addFrameTimer(timer: TimerAction) {
        this.timerActions.set(timer.id, timer);
        this.frameTimeIds.add(timer.id);
    }
}
