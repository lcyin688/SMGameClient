import { FuncAsync } from '../func/FuncAsync';
import { TaskPipeline } from './TaskPipeline';

declare global {
    interface ICore {
        pipeline: typeof PipelineType;
    }

    namespace we {
        namespace core {
            namespace pipeline {
                type PipelineMode = PipelineType.PipelineMode;
                type TaskMode = PipelineType.TaskMode;
                type PipelineOptions = PipelineType.PipelineOptions;
                type TaskConfig<T = any, R = any> = PipelineType.TaskConfig<T, R>;
                type PipelineEventType = PipelineType.PipelineEventType;
                type IExecutor<T = any, R = any> = InstanceType<typeof PipelineType.IExecutor<T, R>>;
            }
        }
    }
}

export namespace PipelineType {
    /**
     * 管线模式
     */
    export enum PipelineMode {
        /** 中断模式: 任意任务失败后，中断整个管线 */
        Abort = 1,
        /** 继续模式: 某任务失败后，继续执行后续任务 */
        Continue = 2,
        /** 任务模式: 由任务配置决定当前任务失败后，是否继续执行后续任务. 不配置, 默认则当前任务同 Continue 模式一致 */
        Task = 3,
    }

    /**
     * 任务模式
     */
    export enum TaskMode {
        /** 中断模式: 任务失败后，中断整个管线 */
        Abort = 1,
        /** 继续模式: 任务失败后，继续执行后续任务 */
        Continue = 2,
    }

    /**
     * 任务配置
     * @template T 管线上下文类型
     * @template R 任务上下文类型
     */
    export interface TaskConfig<T = any, R = any> {
        /**
         * 任务上下文
         */
        ctx?: R;
        /**
         * 任务模式, 默认 Continue 模式
         */
        mode?: TaskMode;
        /**
         * 优先级 (默认0, 越大越优先)
         */
        priority?: number;
        /**
         * 重试次数 (默认0)
         */
        retry?: number;
        /**
         * 重试间隔 秒(s)
         */
        retryInterval?: number;
        /**
         * 执行超时时间 秒(s)
         */
        timeout?: number;
        /**
         * 依赖的任务列表
         */
        dependsOn?: PipelineType.TaskFunc<T>[];
        /**
         * 执行条件判断函数
         * @param ctx 管线上下文
         * @param taskCtx 任务上下文
         */
        condition?: (ctx: T, taskCtx?: R) => boolean | Promise<boolean>;
        /**
         * 任务异常恢复函数
         * @param ctx 管线上下文
         * @param err 错误信息
         * @param taskCtx 任务上下文
         */
        fallback?: (ctx: T, err: Error, taskCtx?: R) => Promise<void>;
        /**
         * 任务开始
         * @param ctx 管线上下文
         * @param taskCtx 任务上下文
         */
        start?: (ctx: T, taskCtx?: R) => Promise<void>;
        /**
         * 任务成功
         * @param ctx 管线上下文
         * @param taskCtx 任务上下文
         */
        success?: (ctx: T, taskCtx?: R) => Promise<void>;
        /**
         * 任务执行失败
         * @param ctx 管线上下文
         * @param err 错误信息
         * @param taskCtx 任务上下文
         */
        taskError?: (ctx: T, err: Error, taskCtx?: R) => Promise<void>;
        /**
         * 任务重试前处理函数
         * @param ctx 管线上下文
         * @param retryCount 重试次数
         * @param taskCtx 任务上下文
         */
        retryBefore?: (ctx: T, retryCount: number, taskCtx?: R) => Promise<void>;
        /**
         * 任务被跳过
         * @param ctx 管线上下文
         * @param taskCtx 任务上下文
         */
        skipped?: (ctx: T, taskCtx?: R) => Promise<void>;
    }

    /**
     * 任务函数类型
     * @template T 任务上下文类型
     * @param ctx 共享任务上下文
     * @param signal 中断信号
     * @param taskCtx 任务上下文
     */
    export type Task<T, R = any> = (ctx: T, signal: AbortSignal, taskCtx?: R) => Promise<void>;

    export type TaskFunc<T, R = any> = FuncAsync<Task<T, R>>;

    /**
     * 管线事件类型
     */
    export type PipelineEventType =
        | 'start' // 管线开始执行
        | 'abort' // 管线被中断
        | 'finish'; // 管线完成

    /**
     * 管线事件对象
     * @template T 上下文类型
     */
    export interface PipelineEvent<T> {
        type: PipelineEventType;
        ctx?: T;
        err?: Error;
    }

    /**
     * 管线配置选项
     */
    export interface PipelineOptions {
        /** 任务并发数, 默认 1 */
        concurrency?: number;
        /** 管线模式， 默认为中断模式 */
        mode?: PipelineMode;
    }

    export abstract class IExecutor<T, R> {
        constructor(protected pipeline: TaskPipeline<T>) {}
        abstract execute(ctx: T, signal: AbortSignal, taskCtx?: R): Promise<void>;
        abstract config(): TaskConfig<T, R>;
    }
}

we.core.pipeline = PipelineType;
