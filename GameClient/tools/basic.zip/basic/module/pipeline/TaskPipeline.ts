import { AsyncTask } from '../async/AsyncTask';
import { CancelAction } from '../async/CancelAction';
import { PromiseHelper } from '../async/PromiseHelper';
import { FuncAsync } from '../func/FuncAsync';
import { PipelineType } from './PipelineType';

declare global {
    interface ICore {
        TaskPipeline: typeof TaskPipeline;
    }

    namespace we {
        namespace core {
            type TaskPipeline<T = any> = InstanceType<typeof TaskPipeline<T>>;
        }
    }
}

/**
 * 任务执行统计信息
 */
interface TaskMetrics {
    startTime: number;
    endTime?: number;
    retries: number;
    success: boolean;
    config: PipelineType.TaskConfig;
}

// 新增插入位置类型
type InsertPosition<T, R> = 'HEAD' | 'TAIL' | { afterTask: PipelineType.TaskFunc<T, R> } | { beforeTask: PipelineType.TaskFunc<T, R> };

export class TaskPipeline<T = any> {
    private pipelineCtx: T;
    // 记录任务添加顺序
    private taskCounter = 0;
    /** 任务队列 */
    private tasks: Array<{ task: PipelineType.TaskFunc<T>; config: PipelineType.TaskConfig<T>; order?: number }> = [];
    /** 中断控制器 */
    private abortController: AbortController | null = null;
    /** 事件回调映射 */
    private eventCallbacks = new Map<PipelineType.PipelineEventType, Function[]>();
    /** 最大并行任务数 */
    private concurrency: number;
    /** 管线模式 */
    private mode: PipelineType.PipelineMode;
    /** 当前运行中的任务集合 */
    private runningTasks = new Set<Promise<void>>();
    /** 是否暂停状态 */
    private isPaused: boolean = false;
    /** 任务性能指标收集 */
    private metrics = new Map<PipelineType.TaskFunc<T>, TaskMetrics>();
    /** 停止任务 */
    private stopAsync: AsyncTask<any>;
    /** 暂停中断 */
    private pauseCancelAction: CancelAction = null;

    /**
     * 构造函数
     * @param pipelineCtx 管道上下文
     * @param options 配置选项
     * @param options.concurrency 任务并发数
     * @param options.mode 管线模式， 默认为中断模式
     */
    constructor(options: PipelineType.PipelineOptions = {}) {
        this.pipelineCtx = {} as T;
        this.concurrency = Math.max(options.concurrency || 1, 1);
        this.mode = options.mode ?? PipelineType.PipelineMode.Abort;
    }

    /**
     * 设置管道上下文
     * @param ctx
     */
    setCtx(ctx: T) {
        this.pipelineCtx = ctx;
    }

    /**
     * 任务是否运行中
     * @returns
     */
    isRunning(): boolean {
        return this.runningTasks.size > 0;
    }

    /**
     * 添加任务到管线
     * @param task 任务函数
     * @param config 任务配置
     * @returns 当前管线实例 (支持链式调用)
     */
    addTask<R>(task: PipelineType.TaskFunc<T, R> | PipelineType.IExecutor<T, R>, config?: PipelineType.TaskConfig<T, R>): this {
        if (task instanceof PipelineType.IExecutor) {
            this.tasks.push({ task: FuncAsync.create(task.execute, task), config: task.config() });
        } else {
            config ??= {};
            this.tasks.push({ task, config, order: this.taskCounter++ });
        }
        return this;
    }

    /**
     * 动态插入任务
     * @param task
     * @param config
     * @param position
     * @returns
     */
    insertTask<R>(task: PipelineType.TaskFunc<T, R>, config?: PipelineType.TaskConfig, position: InsertPosition<T, R> = 'TAIL'): this {
        config ??= {};
        const newTask = { task, config, order: this.taskCounter++ };

        if (position === 'HEAD') {
            this.tasks.unshift(newTask);
        } else if (position === 'TAIL') {
            this.tasks.push(newTask);
        } else if ('afterTask' in position) {
            const index = this.tasks.findIndex((t) => {
                return t.task === position.afterTask;
            });
            if (index === -1) {
                throw new Error('Pipeline insertTask, Target task for afterTask not found');
            }
            if (index !== -1) {
                this.tasks.splice(index + 1, 0, newTask);
            }
        } else if ('beforeTask' in position) {
            const index = this.tasks.findIndex((t) => {
                return t.task === position.beforeTask;
            });
            if (index === -1) {
                throw new Error('Pipeline insertTask, Target task for beforeTask not found');
            }
            if (index !== -1) {
                this.tasks.splice(index, 0, newTask);
            }
        }

        return this;
    }

    /**
     * 启动管线任务
     */
    async start(): Promise<void> {
        this.abortController = new AbortController();
        this.stopAsync = AsyncTask.create();
        this.pauseCancelAction = CancelAction.create();
        this.metrics.clear();
        this.runningTasks.clear();

        this.emit({ type: 'start', ctx: this.pipelineCtx });

        // 解析任务依赖关系
        this.resolveDependencies();

        let asyncTask: AsyncTask = null;
        const taskQueue = [...this.tasks];

        // 主任务循环
        while (taskQueue.length > 0 && !this.isAborted()) {
            // 重置暂停中断控制器
            this.pauseCancelAction?.reset();
            asyncTask = null;

            // 处理暂停状态
            if (this.isPaused) {
                // 暂停时，支持及时中断
                await PromiseHelper.sleep(0.1, this.pauseCancelAction);
                continue;
            }

            // 控制并发数量
            if (this.runningTasks.size >= this.concurrency) {
                // 替代 Promise.race, 避免触发 resolveAfterPromiseResolved 报错
                asyncTask = AsyncTask.create();
                await asyncTask.wait();
                continue;
            }
            const { task, config } = taskQueue.shift();
            const taskPromise = this.executeTaskWithRetry(task, config);
            this.runningTasks.add(taskPromise);
            taskPromise.finally(() => {
                asyncTask?.setResult(true);
                return this.runningTasks.delete(taskPromise);
            });
        }

        // 等待所有剩余任务完成
        await Promise.allSettled(this.runningTasks);
        if (!this.isAborted()) {
            this.emit({ type: 'finish', ctx: this.pipelineCtx });
        }

        this.abortController = null;
        this.stopAsync.setResult(true);
    }

    /**
     * 停止管线任务
     * @param timeout 停止等待超时时间，单位【秒】
     * @returns
     */
    async stop(timeout?: number): Promise<void> {
        if (!this.abortController) {
            return;
        }
        this.abortController.abort();
        this.pauseCancelAction?.cancel();
        await this.stopAsync?.wait(timeout);
    }

    /**
     * 重置任务
     */
    reset() {
        this.tasks.length = 0;
        this.runningTasks.clear();
        this.pipelineCtx = null;
    }

    /**
     * 事件订阅
     * @param event
     * @param callback
     * @returns
     */
    on(event: PipelineType.PipelineEventType, callback: (e: PipelineType.PipelineEvent<T>) => void): this {
        const callbacks = this.eventCallbacks.get(event) || [];
        callbacks.push(callback);
        this.eventCallbacks.set(event, callbacks);
        return this;
    }

    /**
     * 触发事件
     * @param event
     */
    private emit(event: PipelineType.PipelineEvent<T>): void {
        const callbacks = this.eventCallbacks.get(event.type) || [];
        callbacks.forEach((cb) => {
            try {
                cb(event);
            } catch (err) {
                we.error(`Pipeline insertTask, Event callback err: ${JSON.stringify(err.message || err)}`);
            }
        });
    }

    /**
     * 执行带重试机制的任务
     * @param task 任务函数
     * @param config 任务配置
     */
    private async executeTaskWithRetry(task: PipelineType.TaskFunc<T>, config: PipelineType.TaskConfig): Promise<void> {
        // 初始化性能指标
        const metrics: TaskMetrics = {
            startTime: Date.now(),
            retries: 0,
            success: false,
            config,
        };
        this.metrics.set(task, metrics);

        try {
            // 检查执行条件
            const shouldRun = await this.checkCondition(config);
            if (!shouldRun) {
                config?.skipped?.(this.pipelineCtx, config.ctx);
                return;
            }

            // 重试循环
            let attempt = 0;
            const maxAttempts = (config.retry || 0) + 1;

            while (attempt < maxAttempts && !this.isAborted()) {
                attempt++;
                metrics.retries = attempt - 1;

                try {
                    if (metrics.retries > 0) {
                        config.retryBefore?.(this.pipelineCtx, metrics.retries, config.ctx);
                    }
                    // 执行任务（带超时控制）
                    await this.executeSingleTask(task, config);
                    metrics.success = true;
                    return;
                } catch (err) {
                    if (attempt >= maxAttempts) {
                        await config.fallback?.(this.pipelineCtx, config.ctx);
                        throw err;
                    }

                    // 重试等待期间支持及时中断
                    await new Promise((resolve, reject) => {
                        const delayTimeout = setTimeout(() => {
                            resolve(null);
                            this.abortController?.signal.removeEventListener('abort', abort);
                        }, config.retryInterval * 1000);

                        const abort = () => {
                            clearTimeout(delayTimeout);
                            reject(new Error('Pipeline insertTask, Task aborted during retry'));
                        };
                        this.abortController?.signal.addEventListener('abort', abort);
                    });
                }
            }
        } catch (err) {
            this.handlePipelineError(err, config);
        } finally {
            metrics.endTime = Date.now();
        }
    }

    /**
     * 获取任务性能报告
     * @param task
     * @returns
     */
    getTaskReport(task: PipelineType.TaskFunc<T>): TaskMetrics | undefined {
        return this.metrics.get(task);
    }

    /**
     * 生成全局统计报告
     * @returns
     */
    generateSummary(): {
        totalTasks: number;
        succeeded: number;
        avgDuration: number;
    } {
        const tasks = Array.from(this.metrics.values());
        return {
            totalTasks: tasks.length,
            succeeded: tasks.filter((t) => {
                return t.success;
            }).length,
            avgDuration:
                tasks.reduce((sum, t) => {
                    return sum + ((t.endTime || Date.now()) - t.startTime);
                }, 0) / tasks.length,
        };
    }

    /**
     * 中断管线
     */
    abort(err?: Error): void {
        if (this.isAborted()) {
            return;
        }

        this.abortController.abort();
        this.emit({ type: 'abort', err });
    }

    /**
     * 暂停/恢复（需要外部轮询控制）
     */
    pause(): void {
        this.isPaused = true;
    }

    resume(): void {
        this.isPaused = false;
    }

    private async checkCondition(config: PipelineType.TaskConfig): Promise<boolean> {
        if (!config.condition) {
            return true;
        }
        try {
            return await config.condition(this.pipelineCtx, config.ctx);
        } catch (err) {
            return false;
        }
    }

    /**
     * 重写任务队列排序逻辑
     */
    private resolveDependencies() {
        // 构建依赖图
        const taskGraph = new Map<PipelineType.TaskFunc<T>, Set<PipelineType.TaskFunc<T>>>();
        const inverseGraph = new Map<PipelineType.TaskFunc<T>, Set<PipelineType.TaskFunc<T>>>();
        const inDegree = new Map<PipelineType.TaskFunc<T>, number>();
        const allTasks = new Set<PipelineType.TaskFunc<T>>();

        // 初始化数据结构
        this.tasks.forEach(({ task, config }) => {
            allTasks.add(task);
            const dependencies = config.dependsOn || [];

            // 初始化入度表
            inDegree.set(task, dependencies.length);

            // 构建正向图（任务 -> 依赖的任务）
            taskGraph.set(task, new Set(dependencies));

            // 构建逆向图（被依赖的任务 -> 依赖它的任务）
            dependencies.forEach((depTask) => {
                if (!inverseGraph.has(depTask)) {
                    inverseGraph.set(depTask, new Set());
                }
                inverseGraph.get(depTask).add(task);
            });
        });

        // 检测循环依赖
        if (this.hasCyclicDependencies(taskGraph)) {
            throw new Error('Pipeline insertTask, Pipeline contains cyclic dependencies!');
        }

        // Kahn 算法实现拓扑排序
        const queue: PipelineType.TaskFunc<T>[] = [];
        const sortedTasks: Array<{ task: PipelineType.TaskFunc<T>; config: PipelineType.TaskConfig<T> }> = [];

        // 初始化队列（入度为0的节点）
        inDegree.forEach((degree, task) => {
            if (degree === 0) {
                queue.push(task);
            }
        });

        // 处理队列
        while (queue.length > 0) {
            // 同一层级的任务按优先级排序
            queue.sort((a, b) => {
                const aTask = this.tasks.find((t) => {
                    return t.task === a;
                });
                const aPriority = aTask.config.priority || 0;
                const aOrder = aTask.order || 0;

                const bTask = this.tasks.find((t) => {
                    return t.task === b;
                });
                const bPriority = bTask.config.priority || 0;
                const bOrder = aTask.order || 0;

                return bPriority - aPriority || aOrder - bOrder;
            });

            const currentTask = queue.shift();
            const taskConfig = this.tasks.find((t) => {
                return t.task === currentTask;
            });

            // 添加到排序结果
            sortedTasks.push(taskConfig);

            // 更新后续节点的入度
            inverseGraph.get(currentTask)?.forEach((dependentTask) => {
                const currentInDegree = inDegree.get(dependentTask) - 1;
                inDegree.set(dependentTask, currentInDegree);

                if (currentInDegree === 0) {
                    queue.push(dependentTask);
                }
            });
        }

        // 检查是否处理了所有任务
        if (sortedTasks.length !== allTasks.size) {
            throw new Error('Pipeline insertTask, Unresolved dependencies, possible cycle');
        }

        this.tasks = sortedTasks;
    }

    /**
     * 检测循环依赖（深度优先搜索实现）
     */
    private hasCyclicDependencies(graph: Map<PipelineType.TaskFunc<T>, Set<PipelineType.TaskFunc<T>>>): boolean {
        const visited = new Set<PipelineType.TaskFunc<T>>();
        const recursionStack = new Set<PipelineType.TaskFunc<T>>();

        const isCyclic = (task: PipelineType.TaskFunc<T>): boolean => {
            if (recursionStack.has(task)) {
                return true;
            }
            if (visited.has(task)) {
                return false;
            }

            visited.add(task);
            recursionStack.add(task);

            const dependencies = graph.get(task) || [];
            for (const dep of dependencies) {
                if (isCyclic(dep)) {
                    return true;
                }
            }

            recursionStack.delete(task);
            return false;
        };

        for (const task of graph.keys()) {
            if (isCyclic(task)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 执行单个任务实例
     */
    private async executeSingleTask(task: PipelineType.TaskFunc<T>, config: PipelineType.TaskConfig<T>): Promise<void> {
        const abortSignal = this.abortController.signal;

        const asyncTask = AsyncTask.create();

        try {
            config.start?.(this.pipelineCtx, config.ctx);
            task.exec(this.pipelineCtx, abortSignal, config.ctx)
                .then(() => {
                    asyncTask.setResult(true);
                })
                .catch((err) => {
                    asyncTask.setException(err);
                });
            await asyncTask.wait(config.timeout, null, new Error(`Pipeline executeSingleTask, Task timed out after ${config.timeout}s`));
            config.success?.(this.pipelineCtx, config.ctx);
        } catch (err) {
            config.taskError?.(this.pipelineCtx, err as Error, config.ctx);
            throw err;
        }
    }

    private handlePipelineError(err: Error, taskCfg: PipelineType.TaskConfig<T>): void {
        switch (this.mode) {
            case PipelineType.PipelineMode.Abort:
                this.abort(err);
                break;
            case PipelineType.PipelineMode.Continue:
                break;
            case PipelineType.PipelineMode.Task:
                this.handlePipelineTaskError(err, taskCfg);
                break;

            default:
                break;
        }
    }

    private handlePipelineTaskError(err: Error, taskCfg: PipelineType.TaskConfig<T>): void {
        switch (taskCfg.mode) {
            case PipelineType.TaskMode.Abort:
                this.abort(err);
                break;
            case PipelineType.TaskMode.Continue:
                break;

            default:
                break;
        }
    }

    /**
     * 管线是否已中断
     */
    private isAborted() {
        return !this.abortController || this.abortController.signal.aborted;
    }
}

we.core.TaskPipeline = TaskPipeline;
