import { EventGroup } from './EventGroup';

declare global {
    interface ICore {
        EventGlobal: typeof EventGlobal;
    }

    namespace we {
        namespace core {
            type EventGlobal = InstanceType<typeof EventGlobal>;
        }
    }
}

export class EventGlobal {
    private static eventGroup = new EventGroup<any>();

    public static sender<T>(): EventGroup<T> {
        if (!this.eventGroup) {
            this.eventGroup = new EventGroup<T>();
        }
        return this.eventGroup;
    }
}

we.core.EventGlobal = EventGlobal;
