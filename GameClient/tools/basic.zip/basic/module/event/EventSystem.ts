import { DecoratorSymbol, KeySymbol } from '../../decorator/DecoratorSymbol';
import { Scene } from '../scene/Scene';
import { Singleton } from '../singleton/Singleton';
import { IEvent } from './IEvent';
import { IInvoke } from './IInvoke';

declare global {
    interface ICore {
        /** 系统事件类型缓存 */
        eventSystemTypeCache: any[];

        /**
         * 注册 EventSystem 事件类型
         * @param type
         */
        addEventSystemType(type: any): void;

        /** 事件系统 */
        eventSystem: EventSystem;
    }

    namespace we {
        namespace core {
            type EventSystem = InstanceType<typeof EventSystem>;
        }
    }
}

class EventInfo {
    private readonly iEvent: IEvent;
    private readonly _sceneType: number;

    get event() {
        return this.iEvent;
    }

    get sceneType() {
        return this._sceneType;
    }

    public gameId: string;

    constructor(iEvent: IEvent, sceneType: number, gameId: we.GameId) {
        this.iEvent = iEvent;
        this._sceneType = sceneType;
        this.gameId = `${gameId}`;
    }
}

type TypeName = string;

/**
 * 事件系统
 */
@we.decorator.typeSingleton('EventSystem')
export class EventSystem extends Singleton {
    private readonly allEvents = new Map<TypeName, EventInfo[]>();

    private readonly allInvokes = new Map<TypeName, Map<string, any>>();

    static get Inst() {
        return this.getInstance();
    }

    /**
     * 启动事件系统
     */
    public enableSystem(): void {
        we.core.eventSystem = EventSystem.Inst;
        for (const type of we.core.eventSystemTypeCache) {
            EventSystem.Inst.add(type);
        }
        we.core.eventSystemTypeCache = [];
    }

    /**
     * 注册事件
     * @param TYPE 事件类型
     * @returns
     */
    public add(TYPE: any) {
        const typename = Reflect.getMetadata(KeySymbol.Type, TYPE);

        if (!typename) {
            return;
        }

        const tInst = new TYPE();
        if (tInst instanceof IEvent) {
            const eventInfo: EventInfo = new EventInfo(tInst, Reflect.getMetadata(KeySymbol.SceneType, TYPE), Reflect.getMetadata(KeySymbol.GameId, TYPE));

            const event = Reflect.getMetadata(DecoratorSymbol.EventAttribute, TYPE);
            const eventType: string = event.name;

            if (!this.allEvents.has(eventType)) {
                this.allEvents.set(eventType, new Array<EventInfo>());
            }

            // 移除之前的同类型事件
            let isSingleton = Reflect.getMetadata(KeySymbol.Singleton, TYPE);
            if (isSingleton) {
                this.allEvents.get(eventType).remove((item) => {
                    return item.gameId === eventInfo.gameId && item.sceneType === eventInfo.sceneType;
                });
            }

            this.allEvents.get(eventType).push(eventInfo);
        }

        if (tInst instanceof IInvoke) {
            let invokeClassType = tInst.__type__;
            const invokeClass = Reflect.getMetadata(DecoratorSymbol.InvokeAttribute, TYPE);
            if (invokeClass) {
                invokeClassType = invokeClass.name;
            }

            if (!this.allInvokes.has(invokeClassType)) {
                this.allInvokes.set(invokeClassType, new Map<string, any>());
            }

            const invokeType: string = Reflect.getMetadata(KeySymbol.InvokeType, TYPE);
            this.allInvokes.get(invokeClassType).set(`${invokeType}`, tInst);
        }
    }

    /** 只支持异步事件发布 */
    public async publishAsync<T>(scene: Scene, a: T): Promise<void> {
        if (!a) {
            we.warn('EventSystem publishAsync, a is null');
            return;
        }

        if (!scene) {
            return;
        }

        if (scene.IsDisposed) {
            return;
        }

        const iEvents: EventInfo[] = this.allEvents.get(a.constructor.name);
        if (iEvents == null) {
            return;
        }

        const list = [];

        for (const eventInfo of iEvents) {
            if (eventInfo == null) {
                continue;
            }

            if (scene.SceneType !== eventInfo.sceneType && eventInfo.sceneType !== -1) {
                continue;
            }

            if (eventInfo.gameId != null && eventInfo.gameId !== `${scene.gameId}`) {
                continue;
            }

            if (!(eventInfo.event instanceof IEvent)) {
                we.error(`EventSystem publishAsync, scene ${scene.Name} event ${a.constructor.name} type error`);
                continue;
            }

            list.push(eventInfo.event.handle(scene, a));
        }

        try {
            list.length > 0 && (await Promise.all(list));
        } catch (err) {
            we.error(`EventSystem publishAsync, scene ${scene.Name} event ${a.constructor.name} err: ${JSON.stringify(err.message || err)}`);
            throw err;
        }
    }

    /**
     * 异步/同步事件发布
     * @param scene
     * @param a
     * @returns
     */
    public publish<T>(scene: Scene, a: T) {
        if (!a) {
            we.warn('EventSystem publish, a is null');
            return;
        }

        if (!scene) {
            return;
        }

        if (scene.IsDisposed) {
            return;
        }

        const iEvents: EventInfo[] = this.allEvents.get(a.constructor.name);
        if (iEvents == null) {
            return;
        }

        for (const eventInfo of iEvents) {
            if (scene.IsDisposed) {
                break;
            }

            try {
                if (eventInfo == null) {
                    continue;
                }

                if (scene.SceneType !== eventInfo.sceneType && eventInfo.sceneType !== -1) {
                    continue;
                }

                if (eventInfo.gameId != null && eventInfo.gameId !== `${scene.gameId}`) {
                    continue;
                }

                if (!(eventInfo.event instanceof IEvent)) {
                    we.error(`EventSystem publish, scene ${scene.Name} event ${a.constructor.name} type error`);
                    continue;
                }

                eventInfo.event.handle(scene, a);
            } catch (err) {
                we.error(`EventSystem publish, scene ${scene.Name} event ${a.constructor.name} err: ${JSON.stringify(err.message || err)}`);
            }
        }
    }

    /**
     *  同步调用 ECS 接口
     *  Invoke跟Publish的区别(特别注意)：
     *      Invoke类似函数，必须有被调用方，否则异常，调用者跟被调用者属于同一模块，比如MoveComponent中的Timer计时器，调用跟被调用的代码均属于移动模块
     *      既然Invoke跟函数一样，那么为什么不使用函数呢? 因为有时候不方便直接调用，比如Config加载，在客户端跟服务端加载方式不一样。比如TimerComponent需要根据Id分发
     *      注意，不要把Invoke当函数使用，这样会造成代码可读性降低，能用函数不要用Invoke
     *      publish是事件，抛出去可以没人订阅，调用者跟被调用者属于两个模块，比如任务系统需要知道道具使用的信息，则订阅道具使用事件
     * @param args 方法参数对象
     * @param type 方法类别
     * @returns
     */
    public invoke<A, T>(args: A, type?: number | string): T {
        type ??= '0';
        const invokeType = args.constructor.name;
        const invokeHandlers = this.allInvokes.get(invokeType);
        if (invokeHandlers == null) {
            throw new Error(`EventSystem invoke, allInvokes err: ${invokeType}`);
        }

        const aInvokeHandler = invokeHandlers.get(`${type}`);
        if (aInvokeHandler == null) {
            throw new Error(`EventSystem invoke, invokeHandlers err: ${invokeType}`);
        }

        if (!(aInvokeHandler instanceof IInvoke)) {
            throw new Error(`EventSystem invoke, aInvokeHandler not instanceof IInvoke: ${invokeType} ${type}`);
        }

        return aInvokeHandler.handle(args) as T;
    }

    /**
     * 异步调用 ECS 接口
     * @param args 方法参数对象
     * @param type 方法类别
     * @returns
     */
    public async invokeAsync<A, T>(args: A, type?: number | string): Promise<T> {
        type ??= '0';
        const invokeType = args.constructor.name;
        const invokeHandlers = this.allInvokes.get(invokeType);
        if (invokeHandlers == null) {
            throw new Error(`EventSystem invokeAsync, allInvokes err: ${invokeType}`);
        }

        const aInvokeHandler = invokeHandlers.get(`${type}`);
        if (aInvokeHandler == null) {
            throw new Error(`EventSystem invokeAsync, invokeHandlers err: ${invokeType}`);
        }

        if (!(aInvokeHandler instanceof IInvoke)) {
            throw new Error(`EventSystem invokeAsync, aInvokeHandler not instanceof IInvoke: ${invokeType} ${type}`);
        }

        return await aInvokeHandler.handle(args);
    }
}

we.core.eventSystemTypeCache = [];
we.core.addEventSystemType = function (type) {
    if (we.core.eventSystem) {
        we.core.eventSystem.add(type);
    } else {
        we.core.eventSystemTypeCache.push(type);
    }
};
