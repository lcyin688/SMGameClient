import { AsyncTask } from '../async/AsyncTask';
import { Func } from '../func/Func';
import { FuncAsync } from '../func/FuncAsync';
import { TimerComponent } from '../timer/TimerComponent';

declare global {
    interface ICore {
        EventGroup: typeof EventGroup;
    }

    namespace we {
        namespace core {
            type EventGroup<E> = InstanceType<typeof EventGroup<E>>;
            type EventFunc<E> = Func<(msg: E) => void> | Func<(self: Entity, msg: E) => void> | FuncAsync<(msg: E) => Promise<void>> | FuncAsync<(self: Entity, msg: E) => Promise<void>>;
        }
    }
}

type All = '*';
/**
 * 一个轻量级的事件系统
 */
export class EventGroup<E> {
    private events = new Map<keyof E | All, we.core.EventFunc<E[keyof E]>[]>();
    private onceEvents = new Map<keyof E | All, we.core.EventFunc<E[keyof E]>[]>();

    // 持久数据
    private persistenceDatas = new Map<keyof E | All, any>();
    // 粘性数据
    private stickys = new Map<keyof E | All, any>();

    /** 取持久化数据 */
    public persistence<K extends keyof E>(k: K | All) {
        return this.persistenceDatas.get(k);
    }

    /**
     * 监听事件
     * @param k 事件名
     * @param func 回调
     */
    public on<K extends keyof E>(k: K, func: we.core.EventFunc<E[K]>);
    public on<K extends keyof E>(k: K, func: (msg: E[K]) => void | Promise<void>, target: any);
    public on<K extends keyof E>(k: K | All, func: (k: K, msg: E[K]) => void | Promise<void>, target: any);
    public on<K extends keyof E>(k: K, ...args) {
        if (null == k) {
            we.warn(`EventGroup on, k is null`);
            return;
        }

        let func = args[0];
        if (null == func) {
            we.warn(`EventGroup on, func is null`);
            return;
        }

        if (!this.events.has(k)) {
            this.events.set(k, []);
        }

        if (args.length === 2) {
            func = FuncAsync.create(func, args[1]);
        }

        this.events.get(k).push(func);

        const stickysMsg = this.stickys.get(k);
        if (stickysMsg != null) {
            func.exec(stickysMsg);
            this.stickys.delete(k);
        }
    }

    /**
     * 监听事件（一次性）
     * @param k 事件名
     * @param func 回调kk
     */
    public once<K extends keyof E>(k: K, func: we.core.EventFunc<E[K]>);
    public once<K extends keyof E>(k: K, func: (msg: E[K]) => void | Promise<void>, target: any);
    public once<K extends keyof E>(k: K, ...args) {
        if (null == k) {
            we.warn(`EventGroup once, k is null`);
            return;
        }

        let func = args[0];
        if (null == func) {
            we.warn(`EventGroup once, func is null`);
            return;
        }

        if (!this.onceEvents.has(k)) {
            this.onceEvents.set(k, []);
        }

        if (args.length === 2) {
            func = FuncAsync.create(func, args[1]);
        }

        const stickysMsg = this.stickys.get(k);
        if (stickysMsg != null) {
            func.exec(stickysMsg);
            this.stickys.delete(k);
        } else {
            this.onceEvents.get(k).push(func);
        }
    }

    /**
     * 异步等待事件
     * @param k 事件key
     * @param target 事件绑定对象
     * @param timeout 超时时间，单位【秒】默认：10s
     * @returns
     */
    public async onceAsync<K extends keyof E>(k: K, target?: any, timeout: number = 10): Promise<E[K]> {
        if (null == k) {
            we.warn(`EventGroup onceAsync, k is null`);
            return;
        }

        const stickysMsg = this.stickys.get(k);
        if (stickysMsg != null) {
            this.stickys.delete(k);
            return stickysMsg;
        }

        if (!this.onceEvents.has(k)) {
            this.onceEvents.set(k, []);
        }

        let task = AsyncTask.create<E[K]>();
        let func = FuncAsync.create(async (msg: E[K]) => {
            task.setResult(msg);
        }, target);

        this.onceEvents.get(k).push(func);

        const Tag = `EventGroup onceAsync ${String(k)}`;

        if (timeout > 0) {
            const timeoutAction = async () => {
                await TimerComponent.Inst.scheduleOnce(timeout, null, Tag);
                this.onceEvents.get(k).removeOne(func);
                if (!func.isValidFunc() || task.isCompleted()) {
                    return;
                }

                task.setException(Error(`EventGroup onceAsync, Wait ${String(k)} event timeout ${timeout} seconds`));
            };
            timeoutAction().catch(() => {});
        }

        const result = await task.wait();
        TimerComponent.Inst.removeByTag(Tag);
        return result;
    }

    /**
     * 取消监听事件
     * @param k 事件名
     * @param cb 回调
     * @param target 订阅对象
     */
    public off<K extends keyof E>(k: K | All, cb: (...args: any[]) => any, target: any) {
        if (this.events.has(k)) {
            const subscriptions = this.events.get(k);
            subscriptions.forReverse((item, i) => {
                if (item.equal(cb, target)) {
                    subscriptions.splice(i, 1);
                }
            });
        }

        // 一次性事件
        if (this.onceEvents.has(k)) {
            const subscriptions = this.onceEvents.get(k);
            subscriptions.forReverse((item, i) => {
                if (item.equal(cb, target)) {
                    subscriptions.splice(i, 1);
                }
            });
        }
    }

    /**
     * 通过target取消监听事件
     * @param target
     */
    public offByTarget(target: any) {
        this.events.forEach((subscriptions, k) => {
            subscriptions.forEach((v) => {
                this.off(k, v.cb, target);
            });
        });

        this.onceEvents.forEach((subscriptions, k) => {
            subscriptions.forEach((v) => {
                this.off(k, v.cb, target);
            });
        });
    }

    /**
     * 发射事件
     * @param k 事件名
     * @param msg 参数
     * @param p 其他参数
     *  persistence 是否持久化数据
     *  sticky 是否为粘性消息
     */
    public emit<K extends keyof E>(k: K, msg?: E[K], p: { persistence?: boolean; sticky?: boolean } = {}) {
        if (p.persistence) {
            this.persistenceDatas.set(k, msg);
        }

        // 消息是否有处理函数
        let hasHandler = false;
        const removes: we.core.EventFunc<E[keyof E]>[] = [];

        let subscriptions = this.events.get(k);
        if (subscriptions?.length > 0) {
            for (let i = 0; i < subscriptions.length; i++) {
                const handler = subscriptions[i];
                if (!handler.isValidFunc()) {
                    removes.push(handler);
                    continue;
                }
                try {
                    handler.exec(msg);
                } finally {
                }
            }

            p.sticky = false;
            hasHandler = true;

            removes.forEach((item) => {
                this.off(k, item.cb, item['target']);
            });
            removes.length = 0;
        }

        subscriptions = this.events.get('*');
        for (let i = 0; i < subscriptions?.length; i++) {
            const handler = subscriptions[i];
            if (!handler.isValidFunc()) {
                removes.push(handler);
                continue;
            }
            try {
                handler.exec(k, msg);
                hasHandler = true;
            } finally {
            }
        }
        removes.forEach((item) => {
            this.off('*', item.cb, item['target']);
        });
        removes.length = 0;

        // 一次性事件
        subscriptions = this.onceEvents.get(k);
        if (subscriptions?.length > 0) {
            for (let i = 0; i < subscriptions.length; i++) {
                const handler = subscriptions[i];
                if (!handler.isValidFunc()) {
                    removes.push(handler);
                    continue;
                }
                try {
                    handler.exec(msg);
                } finally {
                }
            }

            subscriptions.length = 0;
            p.sticky = false;
            hasHandler = true;

            removes.forEach((item) => {
                this.off(k, item.cb, item['target']);
            });
            removes.length = 0;
        }

        if (p.sticky) {
            this.stickys.set(k, msg);
        }

        return hasHandler;
    }

    /**
     * 发射事件
     * @param name 事件名
     * @param args 参数
     */
    public async emitAsync<K extends keyof E>(k: K, msg: E[K], p: { persistence?: boolean; sticky?: boolean } = {}) {
        if (p.persistence) {
            this.persistenceDatas.set(k, msg);
        }

        // 消息是否有处理函数
        let hasHandler = false;
        const removes: we.core.EventFunc<E[keyof E]>[] = [];

        let subscriptions = this.events.get(k);
        if (subscriptions?.length > 0) {
            for (let i = 0; i < subscriptions.length; i++) {
                const handler = subscriptions[i];
                if (!handler.isValidFunc()) {
                    removes.push(handler);
                    continue;
                }
                await handler.exec(msg);
            }

            p.sticky = false;
            hasHandler = true;

            removes.forEach((item) => {
                this.off(k, item.cb, item['target']);
            });
            removes.length = 0;
        }

        subscriptions = this.events.get('*');
        for (let i = 0; i < subscriptions?.length; i++) {
            const handler = subscriptions[i];
            if (!handler.isValidFunc()) {
                removes.push(handler);
                continue;
            }
            await handler.exec(k, msg);
            hasHandler = true;
        }
        removes.forEach((item) => {
            this.off('*', item.cb, item['target']);
        });
        removes.length = 0;

        subscriptions = this.onceEvents.get(k);
        // 一次性事件
        if (subscriptions?.length > 0) {
            for (let i = 0; i < subscriptions.length; i++) {
                const handler = subscriptions[i];
                if (!handler.isValidFunc()) {
                    removes.push(handler);
                    continue;
                }
                await handler.exec(msg);
                hasHandler = true;
            }

            subscriptions.length = 0;
            p.sticky = false;

            removes.forEach((item) => {
                this.off(k, item.cb, item['target']);
            });
            removes.length = 0;
        }

        if (p.sticky) {
            this.stickys.set(k, msg);
        }

        return hasHandler;
    }

    /**
     * 移除事件
     */
    public remove<K extends keyof E>(k: K | All) {
        if (this.events.has(k)) {
            this.events.delete(k);
        }
        if (this.onceEvents.has(k)) {
            this.onceEvents.delete(k);
        }

        this.stickys.delete(k);
        this.persistenceDatas.delete(k);
    }

    /**
     * 移除所有事件
     */
    public removeAll() {
        this.events.clear();
        this.onceEvents.clear();
        this.stickys.clear();
        this.persistenceDatas.clear();
    }
}

we.core.EventGroup = EventGroup;
