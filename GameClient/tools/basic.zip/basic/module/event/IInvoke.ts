declare global {
    interface ICore {
        AInvokeHandler: typeof AInvokeHandler;
    }

    namespace we {
        namespace core {
            type AInvokeHandler<A, T> = InstanceType<typeof AInvokeHandler<A, T>>;
        }
    }
}

@we.decorator.typeRegister('IInvoke')
export abstract class IInvoke<A, T> {
    /** 具体类型 */
    abstract get __type__(): string;

    abstract handle(args: A): Promise<T> | T;

    invokeType: number;
}

export abstract class AInvokeHandler<A, T> extends IInvoke<A, T> {
    constructor(private readonly CLASS: new (...args) => A) {
        super();
    }

    get __type__(): string {
        return this.CLASS ? this.CLASS.name : null;
    }
}

we.core.AInvokeHandler = AInvokeHandler;
