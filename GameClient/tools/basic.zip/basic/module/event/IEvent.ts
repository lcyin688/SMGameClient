import { Scene } from '../scene/Scene';

declare global {
    interface ICore {
        AEventAsync: typeof AEventAsync;
        AEvent: typeof AEvent;
    }

    namespace we {
        namespace core {
            type AEventAsync = InstanceType<typeof AEventAsync>;
            type AEvent = InstanceType<typeof AEvent>;
        }
    }
}

@we.decorator.typeRegister('IEvent')
export abstract class IEvent {
    abstract handle(scene: Scene, object: any);
}

/**
 * 支持异步Event
 */
export abstract class AEventAsync<A> extends IEvent {
    protected abstract run(scene: Scene, a: A): Promise<void>;

    public async handle(scene: Scene, a: A) {
        try {
            await this.run(scene, a);
        } catch (err) {
            we.error(`AEventAsync handle, run, a: ${JSON.stringify(a)}, err: ${JSON.stringify(err.message || err)}`);
            throw err;
        }
    }
}

we.core.AEventAsync = AEventAsync;
/**
 * 非异步Event
 */
export abstract class AEvent<A> extends IEvent {
    protected abstract run(scene: Scene, a: A): void;

    public handle(scene: Scene, a: A) {
        try {
            this.run(scene, a);
        } catch (err) {
            we.error(`AEvent handle, run, a: ${JSON.stringify(a)}, err: ${JSON.stringify(err.message || err)}`);
            throw err;
        }
    }
}

we.core.AEvent = AEvent;
