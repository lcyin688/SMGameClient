/**
 * 用于创建过渡组，以支持流畅的API
 */
export class Transitions<T> {
    constructor(protected fsm: FiniteStateMachine<T>) {}

    /** 存储过渡的起始状态 */
    public fromStates: T[];
    /** 存储过渡的结束状态 */
    public toStates: T[];

    /**
     * 指定过渡函数的结束状态
     */
    public to(...states: T[]) {
        this.toStates = states;
        this.fsm.addTransitions(this);
        return this.fsm;
    }

    /**
     * 指定从任何给定的状态到其他状态的过渡
     */
    public toAny(states: any) {
        const toStates: T[] = [];
        for (const s in states) {
            if (Object.prototype.hasOwnProperty.call(states, s)) {
                toStates.push(<T>states[s]);
            }
        }

        this.toStates = toStates;
        this.fsm.addTransitions(this);

        return this.fsm;
    }
}

/**
 * 内部表示一个过渡函数，包含FSM、起始状态和目标状态。
 */
export class TransitionFunction<T> {
    constructor(
        public fsm: FiniteStateMachine<T>,
        public from: T,
        public to: T
    ) {}
}

/**
 * 用于 reset() 方法的选项，决定是否在重置时调用开始状态的回调。
 */
export interface ResetOptions {
    /** Whether or not the speciefied `on()` handlers for the start state should be called when resetted. */
    runCallbacks?: boolean;
}

/**
 * 默认的 ResetOptions 值，设置为不运行回调。
 */
export const DefaultResetOptions: ResetOptions = {
    runCallbacks: false,
};

/**
 * 有限状态机的核心实现，模板参数 T 用于与枚举一起使用
 */
export class FiniteStateMachine<T> {
    /** 当前状态 */
    public currentState: T;
    /** 起始状态 */
    private _startState: T;
    /** 是否允许隐式自转换 */
    private _allowImplicitSelfTransition: boolean;
    /** 过渡函数数组 */
    private _transitionFunctions: TransitionFunction<T>[] = [];
    /** 回调函数 */
    private _onCallbacks: { [key: string]: { (from: T, event?: any): void }[] } = {};
    private _exitCallbacks: { [key: string]: { (to: T): boolean | Promise<boolean> }[] } = {};
    private _enterCallbacks: { [key: string]: { (from: T, event?: any): boolean | Promise<boolean> }[] } = {};
    private _invalidTransitionCallback: (to: T, from: T) => boolean = null;

    constructor(startState: T, allowImplicitSelfTransition: boolean = false) {
        this.currentState = startState;
        this._startState = startState;
        this._allowImplicitSelfTransition = allowImplicitSelfTransition;
    }

    /** 添加过渡函数 */
    public addTransitions(fcn: Transitions<T>) {
        fcn.fromStates.forEach((from) => {
            fcn.toStates.forEach((to) => {
                // Only add the transition if the state machine is not currently able to transition.
                if (!this._canGo(from, to)) {
                    this._transitionFunctions.push(new TransitionFunction<T>(this, from, to));
                }
            });
        });
    }

    /**
     * 注册当进入某个状态时触发的回调。
     */
    public on(state: T, callback: (from: T, event?: any) => any): FiniteStateMachine<T> {
        const key = state.toString();
        if (!this._onCallbacks[key]) {
            this._onCallbacks[key] = [];
        }
        this._onCallbacks[key].push(callback);
        return this;
    }

    /**
     * 注册当进入某个状态时触发的回调
     */
    public onEnter(state: T, callback: (from: T, event?: any) => boolean | Promise<boolean>): FiniteStateMachine<T> {
        const key = state.toString();
        if (!this._enterCallbacks[key]) {
            this._enterCallbacks[key] = [];
        }
        this._enterCallbacks[key].push(callback);
        return this;
    }

    /**
     * 注册当离开某个状态时触发的回调，返回 false 可阻止离开。
     */
    public onExit(state: T, callback: (to: T) => boolean | Promise<boolean>): FiniteStateMachine<T> {
        const key = state.toString();
        if (!this._exitCallbacks[key]) {
            this._exitCallbacks[key] = [];
        }
        this._exitCallbacks[key].push(callback);
        return this;
    }

    /**
     * 注册处理无效转换的回调。
     */
    public onInvalidTransition(callback: (from: T, to: T) => boolean): FiniteStateMachine<T> {
        if (!this._invalidTransitionCallback) {
            this._invalidTransitionCallback = callback;
        }
        return this;
    }

    /**
     * from(...states: T[]) 和 fromAny(states: any) 分别用于声明过渡函数的起始状态。
     */
    public from(...states: T[]): Transitions<T> {
        const _transition = new Transitions<T>(this);
        _transition.fromStates = states;
        return _transition;
    }

    public fromAny(states: any): Transitions<T> {
        const fromStates: T[] = [];
        for (const s in states) {
            if (Object.prototype.hasOwnProperty.call(states, s)) {
                fromStates.push(<T>states[s]);
            }
        }

        const _transition = new Transitions<T>(this);
        _transition.fromStates = fromStates;
        return _transition;
    }

    /** 检查是否有有效的过渡函数。 */
    private _validTransition(from: T, to: T): boolean {
        return this._transitionFunctions.some((tf) => {
            return tf.from === from && tf.to === to;
        });
    }

    /**
     * 检查是否可以进行状态转换。
     */
    private _canGo(fromState: T, toState: T): boolean {
        return (this._allowImplicitSelfTransition && fromState === toState) || this._validTransition(fromState, toState);
    }

    /**
     * 检查是否可以转移到给定状态。
     */
    public canGo(state: T): boolean {
        return this._canGo(this.currentState, state);
    }

    /**
     * 进行有效状态转换。
     */
    public go(state: T, event?: any): Promise<void> {
        if (!this.canGo(state)) {
            if (!this._invalidTransitionCallback || !this._invalidTransitionCallback(this.currentState, state)) {
                throw new Error('Error no transition function exists from state ' + this.currentState.toString() + ' to ' + state.toString());
            }
        } else {
            return this._transitionTo(state, event);
        }
    }

    /**
     * This method is availble for overridding for the sake of extensibility.
     * It is called in the event of a successful transition.
     */
    public onTransition(from: T, to: T) {
        // pass, does nothing until overidden
    }

    /**
     * 重置状态机到起始状态，可选则是否运行回调。
     */
    public reset(options?: ResetOptions) {
        options = { ...DefaultResetOptions, ...(options || {}) };
        this.currentState = this._startState;
        if (options.runCallbacks) {
            this._onCallbacks[this.currentState.toString()].forEach((fcn) => {
                fcn.call(this, null, null);
            });
        }
    }

    /**
     * 判断当前状态是否等于给定状态。
     */
    public is(state: T): boolean {
        return this.currentState === state;
    }

    /**
     * 处理实际的状态转换，包括执行退出、进入和回调。
     * @param state
     * @param event
     * @private
     */
    private async _transitionTo(state: T, event?: any): Promise<void> {
        if (!this._exitCallbacks[this.currentState.toString()]) {
            this._exitCallbacks[this.currentState.toString()] = [];
        }

        if (!this._enterCallbacks[state.toString()]) {
            this._enterCallbacks[state.toString()] = [];
        }

        if (!this._onCallbacks[state.toString()]) {
            this._onCallbacks[state.toString()] = [];
        }

        let canExit = true;
        for (const exitCallback of this._exitCallbacks[this.currentState.toString()]) {
            let returnValue: boolean | Promise<boolean> = exitCallback.call(this, state);
            // No return value
            if (returnValue === undefined) {
                // Default to true
                returnValue = true;
            }
            // If it's not a boolean, it's a promise
            if (returnValue !== false && returnValue !== true) {
                returnValue = await returnValue;
            }
            // Still no return value
            if (returnValue === undefined) {
                // Default to true
                returnValue = true;
            }
            canExit = canExit && returnValue;
        }

        let canEnter = true;
        for (const enterCallback of this._enterCallbacks[state.toString()]) {
            let returnValue: boolean | Promise<boolean> = enterCallback.call(this, this.currentState, event);
            // No return value
            if (returnValue === undefined) {
                // Default to true
                returnValue = true;
            }
            // If it's not a boolean, it's a promise
            if (returnValue !== false && returnValue !== true) {
                returnValue = await returnValue;
            }
            // Still no return value
            if (returnValue === undefined) {
                // Default to true
                returnValue = true;
            }
            canEnter = canEnter && returnValue;
        }

        if (canExit && canEnter) {
            const old = this.currentState;
            this.currentState = state;
            this._onCallbacks[this.currentState.toString()].forEach((fcn) => {
                fcn.call(this, old, event);
            });
            this.onTransition(old, state);
        }
    }
}
