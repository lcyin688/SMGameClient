import { WENodeFullscreenScale } from './ccitem/WENodeFullscreenScale';
import { Entity } from '../module/entity/Entity';

declare global {
    interface ICore {
        SceneBigBackground: typeof SceneBigBackground;
    }

    namespace we {
        namespace core {
            type SceneBigBackground = InstanceType<typeof SceneBigBackground>;
        }
    }
}

/**
 * 场景大背景
 * 用于竖版时，避免场景左右两边黑屏
 */
@we.decorator.typeSingleton('SceneBigBackground')
export class SceneBigBackground extends Entity {
    static Inst: SceneBigBackground;
    private bigNode: cc.Node;

    protected async awakeAsync(bigUrl: string) {
        if (!bigUrl) {
            return;
        }

        this.bigNode = new cc.Node();
        this.bigNode.name = '___SceneBigBackground';
        this.bigNode.addComponent(cc.Sprite);

        // 设置对齐
        let widget = this.bigNode.addComponentUnique(cc.Widget);
        widget.isAlignVerticalCenter = true;
        widget.verticalCenter = 0;
        widget.isAlignHorizontalCenter = true;
        widget.horizontalCenter = 0;

        await we.core.CCHelper.Asset.loadImage2Node(this.bigNode, bigUrl);

        // 加入场景
        cc.director.getScene().addChild(this.bigNode);

        // 最后渲染
        this.bigNode.zIndex = cc.macro.MIN_ZINDEX;

        // 防止场景跳转是被销毁
        cc.game.addPersistRootNode(this.bigNode);

        // 最大化全屏显示
        this.bigNode.addComponentUnique(WENodeFullscreenScale);
    }

    protected destroy(): void {
        SceneBigBackground.Inst = null;
        if (cc.isValid(this.bigNode)) {
            cc.game.removePersistRootNode(this.bigNode);
            this.bigNode.destroy();
        }

        this.bigNode = null;
    }
}

we.core.SceneBigBackground = SceneBigBackground;
