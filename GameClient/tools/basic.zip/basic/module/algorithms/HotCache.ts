import { Func } from '../func/Func';

declare global {
    interface ICore {
        HotCache: typeof HotCache;
    }

    namespace we {
        namespace core {
            type HotCache<S> = InstanceType<typeof HotCache<S>>;
        }
    }
}

interface CacheEntry<T = any> {
    /** 数据 */
    value: T;
    /** 插入时间戳 */
    timestamp: number;
}

interface HotCacheOptions {
    /** 默认每个类型最大缓存数量 */
    defaultMax?: number;
    /** 各类型的最大数量（覆盖默认值） */
    typeMax?: Record<string, number>;
    /** 是否启用访问时间更新（LRU 行为） */
    enableAccessTime?: boolean;
}

/**
 * 热数据缓存组件
 * 支持 LRU 缓存策略
 * 支持过期回调
 */
@we.decorator.typeRegister('HotCache')
export class HotCache<S> extends we.core.Entity {
    private defaultMax: number;
    private typeMax: Map<any, number>;
    private cache: Map<any, Map<any, CacheEntry>>;
    private enableAccessTime: boolean;
    private evictListeners: Map<any, Func<(key: any, value: any) => void>>;
    protected awake(options: HotCacheOptions = {}): void {
        this.defaultMax = options.defaultMax ?? 100;
        this.typeMax = new Map(Object.entries(options.typeMax ?? {})) as Map<keyof S, number>;
        this.cache = new Map<any, Map<any, CacheEntry>>();
        this.enableAccessTime = options.enableAccessTime ?? false;
        this.evictListeners = new Map<any, Func<(key: any, value: any) => void>>();
    }
    protected destroy(): void {
        this.typeMax = null;
        this.cache = null;
        this.evictListeners = null;
    }

    public on<T extends keyof S, K extends keyof S[T]>(type: T, handler: Func<(key: K, value: Partial<S[T][K]>) => void>) {
        this.evictListeners.set(type, handler);
    }

    public off<T extends keyof S>(type: T) {
        this.evictListeners.delete(type);
    }

    /**
     * 添加数据到缓存
     * @param type 数据类型
     * @param key 数据唯一标识
     * @param value 数据值
     */
    public set<T extends keyof S, K extends keyof S[T]>(type: T, key: K, value: Partial<S[T][K]>): void {
        let typeCache = this.cache.get(type);
        if (!typeCache) {
            typeCache = new Map();
            this.cache.set(type, typeCache);
        }

        if (typeCache.has(key)) {
            typeCache.delete(key);
        }

        typeCache.set(key, { value, timestamp: Date.now() });

        // 检查并淘汰旧数据
        const max = this.getTypeMax(type);
        this.evict(type, typeCache, max);
    }

    /**
     * 淘汰指定类型、指定key数据
     * @param type 数据类型
     * @param key 数据key
     */
    public evictTypeValue<T extends keyof S, K extends keyof S[T]>(type: T, key: K): void {
        let typeCache = this.cache.get(type);
        if (!typeCache) {
            return;
        }

        const entry = typeCache.get(key);
        if (!entry) {
            return;
        }
        const listener = this.evictListeners.get(type);
        listener?.exec(key, entry.value);
        typeCache.delete(key);
    }

    /**
     * 获取缓存数据
     * @param type 数据类型
     * @param key 数据唯一标识
     */
    public get<T extends keyof S, K extends keyof S[T]>(type: T, key: K): T | undefined {
        const typeCache = this.cache.get(type);
        if (!typeCache) {
            return undefined;
        }

        const entry = typeCache.get(key);
        if (!entry) {
            return undefined;
        }

        if (this.enableAccessTime) {
            typeCache.delete(key);
            typeCache.set(key, { ...entry, timestamp: Date.now() });
        }

        return entry.value as T;
    }

    /**
     * 删除指定数据
     * @param type 数据类型
     * @param key 数据唯一标识
     */
    public delete<T extends keyof S, K extends keyof S[T]>(type: T, key: K): boolean {
        const typeCache = this.cache.get(type);
        return !!typeCache?.delete(key);
    }

    /**
     * 清空缓存（可指定类型）
     * @param type 数据类型，不传则清空所有
     */
    public clear<T extends keyof S>(type?: T): void {
        if (type) {
            this.cache.get(type)?.clear();
        } else {
            this.cache.clear();
        }
    }

    /**
     * 获取当前缓存大小
     * @param type 数据类型，不传则返回总数
     */
    public getSize<T extends keyof S>(type?: T): number {
        if (type) {
            return this.cache.get(type)?.size ?? 0;
        }
        return Array.from(this.cache.values()).reduce((sum, map) => {
            return sum + map.size;
        }, 0);
    }

    /**
     * 设置某类型的最大缓存数量
     * @param type 数据类型
     * @param max 最大数量
     */
    public setTypeMax<T extends keyof S>(type: T, max: number): void {
        this.typeMax.set(type, max);
        const typeCache = this.cache.get(type);
        if (typeCache) {
            this.evict(type, typeCache, max);
        }
    }

    /**
     * 淘汰旧数据直到满足最大数量
     * @param typeCache
     * @param max
     */
    private evict<T extends keyof S>(type: T, typeCache: Map<string, CacheEntry>, max: number): void {
        while (typeCache.size > max) {
            const oldestKey = typeCache.keys().next().value;
            const entry = typeCache.get(oldestKey);
            typeCache.delete(oldestKey);
            const listener = this.evictListeners.get(type);
            listener?.exec(oldestKey, entry.value);
        }
    }

    /**
     * 获取某类型的最大数量限制
     * @param type 数据类型
     * @returns
     */
    private getTypeMax<T extends keyof S>(type: T): number {
        return this.typeMax.get(type) ?? this.defaultMax;
    }
}

we.core.HotCache = HotCache;
