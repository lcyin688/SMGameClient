declare global {
    interface ICore {
        MultiMap: typeof MultiMap;
    }

    namespace we {
        namespace core {
            type MultiMap<T, K> = InstanceType<typeof MultiMap<T, K>>;
        }
    }
}

export class MultiMap<T, K> extends Map<T, K[]> {
    private readonly empty: K[] = [];

    public add(t: T, k: K): void {
        let list = super.get(t);
        if (!list) {
            list = [];
            this.set(t, list);
        }
        list.push(k);
    }

    public remove(t: T, k: K): boolean {
        const list = super.get(t);
        if (!list) {
            return false;
        }
        const index = list.indexOf(k);
        if (index === -1) {
            return false;
        }
        list.splice(index, 1);
        if (list.length === 0) {
            this.delete(t);
        }
        return true;
    }

    public removeAll(t: T) {
        const list = super.get(t);
        if (!list) {
            return false;
        }

        list.length = 0;
        this.delete(t);

        return;
    }

    public getSize(t: T): number {
        const list = super.get(t) ?? this.empty;
        return list.length;
    }

    public getAll(t: T): K[] {
        const list = super.get(t);
        if (!list) {
            return [];
        }
        return [...list];
    }

    public get(t: T): K[] {
        const list = super.get(t);
        return list ? [...list] : this.empty;
    }

    public getOne(t: T): K | undefined {
        const list = super.get(t);
        if (list && list.length > 0) {
            return list[0];
        }
        return undefined;
    }

    public contains(t: T, k: K): boolean {
        const list = super.get(t);
        if (!list) {
            return false;
        }
        return list.includes(k);
    }
}

we.core.MultiMap = MultiMap;
