declare global {
    interface ICore {
        DoubleMap: typeof DoubleMap;
    }

    namespace we {
        namespace core {
            type DoubleMap<K, V> = InstanceType<typeof DoubleMap<K, V>>;
        }
    }
}

export class DoubleMap<K, V> {
    private readonly kv: Map<K, V> = new Map<K, V>();
    private readonly vk: Map<V, K> = new Map<V, K>();

    public forEach(callback: (key: K, value: V) => void) {
        if (callback === undefined) {
            return;
        }
        for (const [key, value] of this.kv) {
            callback(key, value);
        }
    }

    public get keys(): K[] {
        return Array.from(this.kv.keys());
    }

    public get values(): V[] {
        return Array.from(this.vk.keys());
    }

    public add(key: K, value: V) {
        if (key === undefined || value === undefined || this.kv.has(key) || this.vk.has(value)) {
            return;
        }
        this.kv.set(key, value);
        this.vk.set(value, key);
    }

    public getValueByKey(key: K): V | undefined {
        if (key !== undefined && this.kv.has(key)) {
            return this.kv.get(key);
        }
        return undefined;
    }

    public getKeyByValue(value: V): K | undefined {
        if (value !== undefined && this.vk.has(value)) {
            return this.vk.get(value);
        }
        return undefined;
    }

    public removeByKey(key: K) {
        if (key === undefined) {
            return;
        }
        const value = this.kv.get(key);
        if (value === undefined) {
            return;
        }
        this.kv.delete(key);
        this.vk.delete(value);
    }

    public removeByValue(value: V) {
        if (value === undefined) {
            return;
        }
        const key = this.vk.get(value);
        if (key === undefined) {
            return;
        }
        this.kv.delete(key);
        this.vk.delete(value);
    }

    public clear() {
        this.kv.clear();
        this.vk.clear();
    }

    public containsKey(key: K): boolean {
        if (key === undefined) {
            return false;
        }
        return this.kv.has(key);
    }

    public containsValue(value: V): boolean {
        if (value === undefined) {
            return false;
        }
        return this.vk.has(value);
    }

    public contains(key: K, value: V): boolean {
        if (key === undefined || value === undefined) {
            return false;
        }
        return this.kv.has(key) && this.vk.has(value);
    }
}

we.core.DoubleMap = DoubleMap;
