declare global {
    interface ICore {
        Queue: typeof Queue;
    }

    namespace we {
        namespace core {
            type Queue<T> = InstanceType<typeof Queue<T>>;
        }
    }
}

class Node<T> {
    value: T;
    next: Node<T> | null;

    constructor(value: T) {
        this.value = value;
        this.next = null;
    }
}

export class Queue<T> {
    private head: Node<T> | null;
    private tail: Node<T> | null;
    private _size: number = 0; // 添加一个计数器

    constructor() {
        this.head = null;
        this.tail = null;
    }

    enqueue(item: T): void {
        const newNode = new Node(item);
        if (!this.head) {
            this.head = newNode;
            this.tail = newNode;
        } else {
            this.tail.next = newNode;
            this.tail = newNode;
        }
        this._size++; // 更新计数器
    }

    dequeue(): T | undefined {
        if (!this.head) {
            return undefined;
        }

        const item = this.head.value;
        this.head = this.head.next;

        if (!this.head) {
            this.tail = null;
        }

        this._size--; // 更新计数器

        return item;
    }

    get isEmpty(): boolean {
        return this.head === null;
    }

    get size(): number {
        return this._size; // 直接返回计数器的值
    }
}

we.core.Queue = Queue;
