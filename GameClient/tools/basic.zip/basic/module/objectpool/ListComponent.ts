import { IDisposable } from '../entity/IDisposable';
import { ObjectPool } from './ObjectPool';

export class ListComponent<T> extends Array<T> implements IDisposable {
    static create<T>(): ListComponent<T> {
        return ObjectPool.Inst.fetch(ListComponent) as ListComponent<T>;
    }

    dispose(): void {
        this.length = 0;
        ObjectPool.Inst.recycle(this);
    }
}
