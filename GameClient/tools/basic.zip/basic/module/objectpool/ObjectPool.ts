import { Queue } from '../algorithms/Queue';
import { Singleton } from '../singleton/Singleton';

declare global {
    interface ICore {
        ObjectPool: typeof ObjectPool;
    }

    namespace we {
        namespace core {
            type ObjectPool = InstanceType<typeof ObjectPool>;
        }
    }
}

@we.decorator.typeSingleton('ObjectPool')
export class ObjectPool extends Singleton {
    private readonly pool = new Map<new (...args: any[]) => any, Queue<any>>();

    static get Inst() {
        return this.getInstance();
    }

    fetch<T extends new (...args: any[]) => any>(CLASS: T, ...args: ConstructorParameters<T>): InstanceType<T> {
        let objPool = this.pool.get(CLASS);
        if (!objPool) {
            objPool = new Queue<any>();
            this.pool.set(CLASS, objPool);
        }

        let instance: InstanceType<T>;
        if (objPool.size === 0) {
            instance = new CLASS(...args);
        } else {
            instance = objPool.dequeue();
        }

        return instance;
    }

    recycle<T extends new (...args: any[]) => any>(obj: InstanceType<T>) {
        const ctor = obj.constructor as T;
        let objPool = this.pool.get(ctor);
        if (!objPool) {
            objPool = new Queue<any>();
            this.pool.set(ctor, objPool);
        }

        if (objPool.size < 1000) {
            objPool.enqueue(obj);
        }
    }

    /**
     * 清理对象池
     * @param match 匹配值
     * @returns
     */
    clear(match?: string) {
        if (match) {
            for (let [CLASS] of this.pool) {
                if (CLASS.name.startsWith(match)) {
                    this.pool.delete(CLASS);
                }
            }
            return;
        }
        this.pool.clear();
    }
}

we.core.ObjectPool = ObjectPool;
