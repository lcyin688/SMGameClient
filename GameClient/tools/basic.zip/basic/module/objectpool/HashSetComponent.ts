import { IDisposable } from '../entity/IDisposable';
import { ObjectPool } from './ObjectPool';

export class HashSetComponent<T> extends Set<T> implements IDisposable {
    static create<T>(): HashSetComponent<T> {
        return ObjectPool.Inst.fetch(HashSetComponent) as HashSetComponent<T>;
    }

    dispose(): void {
        this.clear();
        ObjectPool.Inst.recycle(this);
    }
}
