declare global {
    interface ICore {
        ClientError: typeof ClientError;
        ClientErrorType: typeof ClientErrorType;
        isClientError(err: any): err is ClientError;
    }
    interface TCore {
        ClientErrorType: ClientErrorType;
    }
    namespace we {
        namespace core {
            type ClientError = InstanceType<typeof ClientError>;
            type ClientErrorType = TCore['ClientErrorType'];
        }
    }
}

/**
 * 客户端错误类型定义
 */
export enum ClientErrorType {
    /**
     * 常规类型错误
     */
    Error = 'ClientError',
    /**
     * Tip类型错误
     */
    TipError = 'NetworkError',
    /**
     * Confirm类型错误
     */
    ConfirmError = 'ConfirmError',
    /**
     * 资源加载失败
     */
    ResError = 'ResError',
}

we.core.ClientErrorType = ClientErrorType;

export interface ClientErrorData {
    /**
     * 错误信息
     */
    message?: string;
    /**
     * 错误码
     */
    code?: string | number;

    /**
     * 错误类型：常规类型错误 ClientError
     */
    type?: ClientErrorType;

    /**
     * 扩展数据
     */
    [key: string]: any;
}

export class ClientError extends Error implements ClientErrorData {
    message!: string;
    code?: string | number;
    type: ClientErrorType;
    [key: string]: any;

    constructor(data: ClientErrorData);
    constructor(err: Error, data?: Partial<ClientErrorData>);
    constructor(message: string, data?: Partial<ClientErrorData>);
    constructor(dataOrMessageOrErr: ClientErrorData | string | Error, data?: Partial<ClientErrorData>) {
        super();
        // 类型常规类型错误
        this.type ??= ClientErrorType.Error;
        if (typeof dataOrMessageOrErr === 'string') {
            this.message = dataOrMessageOrErr;
            we.npm.lodash.assign(this, data);
        } else if (dataOrMessageOrErr instanceof Error) {
            this.message = dataOrMessageOrErr.message;
            this.stack = dataOrMessageOrErr.stack;
            we.npm.lodash.assign(this, data);
        } else {
            we.npm.lodash.assign(this, dataOrMessageOrErr);
        }
    }

    toString() {
        return `[ClientError ${this.type}]: ${this.message}`;
    }
}

we.core.ClientError = ClientError;

export function isClientError(err: any): err is ClientError {
    return err instanceof ClientError;
}
we.core.isClientError = isClientError;
