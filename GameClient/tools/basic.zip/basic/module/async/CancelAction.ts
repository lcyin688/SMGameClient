declare global {
    interface ICore {
        CancelAction: typeof CancelAction;
    }

    namespace we {
        namespace core {
            type CancelAction = InstanceType<typeof CancelAction>;
        }
    }
}

type Action = () => void;

/**
 * 取消会话
 */
export class CancelAction {
    private actions = new Set<Action>();

    static create() {
        return new CancelAction();
    }

    static destroy(cancelAction: CancelAction) {
        cancelAction?.cancel();
    }

    public reset() {
        this.actions.clear();
    }

    public add(action: Action) {
        if (!action) {
            we.warn('CancelAction add, action is null or undefined');
            return;
        }
        this.actions.add(action);
    }

    public remove(action: Action) {
        this.actions.delete(action);
    }

    public get isDispose(): boolean {
        return this.actions.size == 0;
    }

    public cancel() {
        if (this.isDispose) {
            return;
        }

        this.invoke();
    }

    private invoke() {
        const runActions = this.actions;

        try {
            for (const action of runActions) {
                action();
            }
        } catch (err) {
            we.error(`CancelAction invoke, err: ${JSON.stringify(err.message || err)}`);
        }

        this.actions.clear();
    }
}

we.core.CancelAction = CancelAction;
