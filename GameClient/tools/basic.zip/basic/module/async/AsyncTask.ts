declare global {
    interface ICore {
        AsyncTask: typeof AsyncTask;
    }

    namespace we {
        namespace core {
            type AsyncTask<T = boolean> = InstanceType<typeof AsyncTask<T>>;
        }
    }
}

export enum AwaiterStatus {
    /** 未完成 */
    Pending = 0,
    /** 成功 */
    Succeeded = 1,
    /** 错误 */
    Faulted = 2,
    /** 超时 */
    Timeout = 3,
}

type Action = (err: any, result: any) => void;

type TaskObject = object & { isValid: (() => boolean) | boolean };

/**
 * 异步任务
 */
export class AsyncTask<T = boolean> {
    private resolve: (r: T) => void;
    private reject: (e: any) => void;
    promise: Promise<T>;
    private state: AwaiterStatus;
    private value: T;
    private err: any;
    private callback: Action;
    /**
     * 对象是否有效
     */
    private target: TaskObject;
    constructor() {
        this.promise = new Promise<T>((resolve, reject) => {
            this.resolve = resolve;
            this.reject = reject;
        });
        this.state = AwaiterStatus.Pending;
    }

    static create<T>() {
        return new AsyncTask<T>();
    }

    /**
     * 异步Promise等待
     * 支持超时【可选】
     * @param time 超时时间,单位【秒】，ms:null时，永久等待
     * @param target 任务对象，主要用于判定对象是否有效，无效时，异步无效再执行
     * @param ret 超时返回值
     * @returns
     */
    async wait(time?: number, target?: TaskObject, ret?: T) {
        this.target = target;

        if (time && time > 0) {
            const timer = setTimeout(() => {
                if (this.state !== AwaiterStatus.Pending) {
                    return;
                }
                this.setResult(ret);
                this.state = AwaiterStatus.Timeout;
            }, time * 1000);

            // 当Promise解决或拒绝时，清理定时器
            this.promise.finally(() => {
                this.target = null;
                clearTimeout(timer);
            });
        }

        return this.promise;
    }

    /**
     * 设置结果
     * @param t
     * @returns
     */
    setResult(t: T) {
        if (this.state !== AwaiterStatus.Pending) {
            we.debug('AsyncTask setResult, promise already completed');
            return;
        }

        if (!this.resolve) {
            return;
        }

        this.state = AwaiterStatus.Succeeded;
        this.value = t;

        if (this.isInvalidTarget) {
            return;
        }

        this.resolve(t);
        this.triggerCallback();
    }

    /**
     * 设置异常
     * @param e
     */
    setException(e: any) {
        if (this.state !== AwaiterStatus.Pending) {
            throw new Error('AsyncTask setException, promise already completed');
        }

        this.state = AwaiterStatus.Faulted;
        this.err = e;

        if (this.isInvalidTarget) {
            return;
        }

        this.reject(e);
        this.triggerCallback();
    }

    public isCompleted() {
        return this.state !== AwaiterStatus.Pending;
    }

    public onCompleted(action: Action) {
        if (this.state !== AwaiterStatus.Pending) {
            if (action) {
                action(null, null);
            }
            return;
        }
        this.callback = action;
    }

    public getResult(): T {
        switch (this.state) {
            case AwaiterStatus.Succeeded:
                return this.value;
            case AwaiterStatus.Faulted:
                this.callback = null;
                throw this.err;
            default:
                throw new Error("AsyncTask getResult, does not allow call getResult directly when task not completed. Please use 'await'.");
        }
    }

    private triggerCallback() {
        if (this.callback) {
            this.callback(this.err ?? null, this.value);
            this.callback = null;
        }
    }

    private get isInvalidTarget() {
        return this.target && this.target.isValid && (typeof this.target.isValid === 'function' ? !this.target.isValid() : !this.target.isValid);
    }
}

we.core.AsyncTask = AsyncTask;
