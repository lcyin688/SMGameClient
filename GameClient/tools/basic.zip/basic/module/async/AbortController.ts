/**
 * https://developer.mozilla.org/zh-CN/docs/Web/API/AbortController
 * 根据MDN文档，实现AbortController接口用于取消异步操作，
 * 兼容原生平台不支持的问题
 */

if (typeof window.DOMException === 'undefined') {
    (window as any).DOMException = class DOMException extends Error {
        constructor(message: string, name: string) {
            super(message);
            this.name = name;
        }
    };
}

class Event {
    type: string;
    constructor(type: string) {
        this.type = type;
    }
}

/**
 * 异步中断信号
 */
export class AbortSignal {
    /** 是否已中断 */
    private _aborted: boolean = false;
    private eventListeners: { [type: string]: Function[] } = {};

    private constructor() {}

    /** 内部创建方法 */
    static create(): AbortSignal {
        return new AbortSignal();
    }

    /**
     * TODO: 暂未实现
     * 返回一个指定时间后将自动中止的 AbortSignal 对象
     * 信号在超时时使用 TimeoutError DOMException 中止
     * await fetch(url, { signal: AbortSignal.timeout(5000) });
     * @param ms 超时时间，单位为毫秒
     * @returns
     */
    static timeout(ms: number): AbortSignal {
        return;
    }

    /**
     * TODO 暂未实现
     * 返回一个已经设置为中止的 AbortSignal（并且不会触发 abort 事件）
     * @returns
     */
    static abort(): AbortSignal {
        return;
    }

    get aborted(): boolean {
        return this._aborted;
    }

    public onabort: ((this: AbortSignal, event: Event) => void) | null = null;

    public addEventListener(type: string, listener: (event: Event) => void, _options?: boolean | AddEventListenerOptions): void {
        if (!this.eventListeners[type]) {
            this.eventListeners[type] = [];
        }
        this.eventListeners[type].push(listener);
    }

    public removeEventListener(type: string, listener: (event: Event) => void, _options?: boolean | EventListenerOptions): void {
        const listeners = this.eventListeners[type];
        if (listeners) {
            const index = listeners.indexOf(listener);
            if (index !== -1) {
                listeners.splice(index, 1);
            }
        }
    }

    public throwIfAborted(): void {
        if (this.aborted) {
            throw new DOMException('AbortSignal throwIfAborted, operation is aborted', 'AbortError');
        }
    }

    dispatchAbort(): void {
        if (this._aborted) {
            return;
        }
        this._aborted = true;

        const event = new Event('abort');

        // 触发 onabort 回调
        if (typeof this.onabort === 'function') {
            try {
                this.onabort.call(this, event);
            } catch (err) {
                we.error('AbortSignal dispatchAbort, error in onabort handler:', err);
            }
        }

        // 触发事件监听器
        const listeners = this.eventListeners['abort'] || [];
        for (const listener of listeners) {
            try {
                listener.call(this, event);
            } catch (err) {
                we.error('AbortSignal dispatchAbort, error in abort event listener:', err);
            }
        }
    }
}

/**
 * 异步中断控制器
 */
export class AbortController {
    signal: AbortSignal;

    constructor() {
        this.signal = AbortSignal.create();
    }

    public abort(): void {
        this.signal.dispatchAbort();
    }
}

if (typeof window.AbortController === 'undefined') {
    (window as any).AbortController = AbortController;
}

if (typeof window.AbortSignal === 'undefined') {
    (window as any).AbortSignal = AbortSignal;
}
