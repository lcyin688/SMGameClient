import { AsyncTask } from './AsyncTask';
import { CancelAction } from './CancelAction';

declare global {
    interface ICore {
        PromiseHelper: typeof PromiseHelper;
    }
}

// 声明一个全局的类型，用于扩展 Promise 构造函数
declare global {
    interface PromiseConstructor {
        serial<T>(values: Iterable<T | PromiseLike<T>>): Promise<T[]>;
    }
}

// 扩展 Promise 构造函数上的 serial 方法
Promise.serial = function <T>(values: Iterable<T | PromiseLike<T>>): Promise<T[]> {
    let results: T[] = [];
    let currentPromise: Promise<void> = Promise.resolve();

    for (const task of values) {
        currentPromise = currentPromise
            .then(() => {
                if (task instanceof Promise) {
                    return task;
                } else {
                    return Promise.resolve(task);
                }
            })
            .then((result) => {
                results.push(result);
            });
    }

    const resultPromise: Promise<T[]> = currentPromise.then(() => {
        return results;
    });

    return resultPromise;
};

// 已知 android 8.0、8.1 以下版本浏览器不支持 Promise.allSettled
if (!Promise.allSettled) {
    Promise.allSettled = function <T>(values: Iterable<T | PromiseLike<T>>): Promise<PromiseSettledResult<T>[]> {
        const promises = Array.from(values);
        return Promise.all(
            promises.map((p) => {
                return Promise.resolve(p).then(
                    (value) => {
                        return { status: 'fulfilled', value } as const;
                    },
                    (reason) => {
                        return { status: 'rejected', reason } as const;
                    }
                );
            })
        );
    };
}

export class PromiseHelper {
    /**
     * 优雅的异步处理
     * @param promise 要包装的 promise
     * @returns
     */
    static async asyncWrapper<T>(promise: Promise<T>): Promise<[T | null, Error | null]> {
        try {
            const result = await promise;
            return [result, null];
        } catch (error) {
            return [null, error];
        }
    }

    static async parallelWithLimit(tasks: (() => Promise<any>)[], limit: number) {
        const results = [];
        const executing = new Set();
        let asyncTask: AsyncTask = null;
        for (const task of tasks) {
            asyncTask = null;
            const p = task().then((result) => {
                executing.delete(p);
                asyncTask?.setResult(true);
                return result;
            });
            executing.add(p);
            results.push(p);

            if (executing.size >= limit) {
                asyncTask = AsyncTask.create();
                await asyncTask.wait();
                continue;
            }
        }

        return Promise.allSettled(results);
    }

    /**
     * 休眠，支持中断
     * @param timeout 超时时间，单位秒
     * @param cancelAction 会话中断
     */
    static async sleep(timeout: number, cancelAction?: CancelAction) {
        const tcs = new AsyncTask<boolean>();

        const timeId = setTimeout(() => {
            tcs.setResult(true);
        }, timeout * 1000);

        const cancel = () => {
            tcs.setResult(true);
            clearTimeout(timeId);
        };

        try {
            cancelAction?.add(cancel);
            await tcs.wait();
        } finally {
            cancelAction?.remove(cancel);
        }
    }

    /**
     * 创建一个异步内容对象
     * 支持安全调用，防止重复调用
     * @returns
     */
    static defer<T>() {
        const df = {
            called: false,
            promise: null as () => Promise<T>,
            resolve: null as (value?: T | PromiseLike<T>) => void,
            reject: null as (reason: any) => void,
        };

        const promise: Promise<T> = new Promise((resolve, reject) => {
            df.resolve = (value) => {
                if (!df.called) {
                    df.called = true;
                    resolve(value);
                }
            };

            df.reject = (reason) => {
                if (!df.called) {
                    df.called = true;
                    reject(reason);
                }
            };
        });

        df.promise = () => {
            return promise;
        };

        return df;
    }
}

we.core.PromiseHelper = PromiseHelper;
