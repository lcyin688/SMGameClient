import { Entity } from '../entity/Entity';
import { TimerComponent } from '../timer/TimerComponent';
import { AsyncTask } from './AsyncTask';

declare global {
    interface ICore {
        ObjectWait: typeof ObjectWait;
        IWaitType: typeof IWaitType;
        WaitTypeError: typeof WaitTypeError;
    }
    interface TCore {
        WaitTypeError: WaitTypeError;
    }
    namespace we {
        namespace core {
            type ObjectWait = InstanceType<typeof ObjectWait>;
            type WaitTypeError = TCore['WaitTypeError'];
        }
    }
}

export enum WaitTypeError {
    /** 等待成功 */
    Success = 0,
    /** 通知等待任务执行失败 */
    Fail = 1,
    /** 通知等待任务被取消 */
    Cancel = 2,
    /** 通知等待超时 */
    Timeout = 3,
    /** 中断任务，等待处后面的任务不在执行 */
    Broken = 4,
    /** 等待任务被销毁 */
    Destroy = 5,
}
we.core.WaitTypeError = WaitTypeError;

export class IWaitType {
    constructor(public err: WaitTypeError = WaitTypeError.Success) {}

    get __type__(): string {
        return this.constructor.name;
    }
}

we.core.IWaitType = IWaitType;

abstract class IDestroyRun {
    abstract setResult();
}

class ResultCallback<K extends IWaitType> extends IDestroyRun {
    public userData: any;
    constructor(private readonly CLASS: new (...args) => K) {
        super();
        this.tcs = new AsyncTask<K>();
    }

    private tcs: AsyncTask<K>;

    get isDisposed() {
        return this.tcs == null;
    }

    get Task() {
        return this.tcs;
    }

    public setResult(k: K = null) {
        const t = this.tcs;
        this.tcs = null;
        if (k == null) {
            k = new this.CLASS(WaitTypeError.Destroy);
        }
        t.setResult(k);
    }
}

/**
 * 等待事件
 * 一对一事件
 * 支持异步等待
 * 支持超时等待
 * 支持粘包事件
 * 支持中断事件
 */
@we.decorator.typeRegister('ObjectWait')
export class ObjectWait extends Entity {
    /**
     * 等待事件
     */
    private tcss = new Map<string, any>();

    /**
     * 粘包事件
     */
    private stickys = new Map<string, any>();

    private timerTagId = 0;

    protected awake() {
        this.tcss.clear();
    }

    protected destroy() {
        for (const v of this.tcss.values()) {
            const tsc: ResultCallback<any> = v;
            tsc.setResult();
        }
    }

    /**
     * 等待事件返回
     * @param CLASS wait类型
     * @param timeout 超时时间，单位【秒】
     * @returns
     */
    public async wait<T extends IWaitType>(CLASS: new (...args) => T, timeout: number = 0) {
        const tcs = new ResultCallback<T>(CLASS);
        this.tcss.set(CLASS.name, tcs);

        if (timeout > 0) {
            const timeoutAction = async () => {
                tcs.userData = this.genTimerTag();
                await TimerComponent.Inst.scheduleOnce(timeout, this, tcs.userData);
                if (tcs.isDisposed) {
                    return;
                }
                this.notify(new CLASS(WaitTypeError.Timeout));
            };
            timeoutAction().catch(() => {});
        }

        const stickyTcs: T = this.stickys.get(CLASS.name);
        if (stickyTcs) {
            // 存在粘包事件，则在下一帧通知事件
            TimerComponent.Inst.scheduleOnce(0, this).then(() => {
                this.notify(stickyTcs);
            });
        }

        let result = await tcs.Task.wait();
        TimerComponent.Inst.removeByTag(tcs.userData);
        return result;
    }

    /**
     * 取消等待事件
     * @param CLASS 等待类型
     * @param isBroken 是否中断等待任务后面的逻辑,默认：true
     */
    public cancel<T extends IWaitType>(CLASS: new (...args) => T, isBroken: boolean = true) {
        const tcs = this.tcss.get(CLASS.name);
        if (tcs) {
            this.notify(new CLASS(isBroken ? WaitTypeError.Broken : WaitTypeError.Cancel));
        }

        if (tcs?.userData) {
            TimerComponent.Inst.removeByTag(tcs.userData);
        }
    }

    /**
     * 通知等待事件
     * @param obj 事件对象
     * @param sticky 是否为粘包
     * @returns
     */
    public notify<T extends IWaitType>(obj: T, sticky?: boolean) {
        const tcs: ResultCallback<T> = this.tcss.get(obj.__type__);

        if (!tcs) {
            if (sticky) {
                // 保存粘包消息
                this.stickys.set(obj.__type__, obj);
            }
            return;
        }

        this.stickys.delete(obj.__type__);
        this.tcss.delete(obj.__type__);
        // 撤销不执行等待
        if (obj.err != WaitTypeError.Broken) {
            tcs.setResult(obj);
        }
    }

    private genTimerTag() {
        return `${this.Id}-${++this.timerTagId}`;
    }
}

we.core.ObjectWait = ObjectWait;
