import { Queue } from '../algorithms/Queue';
import { Singleton } from '../singleton/Singleton';
import { type Scene } from '../scene/Scene';
import { type Entity } from './Entity';
import { EntitySceneFactory } from './EntitySceneFactory';
import { TimerComponent } from '../timer/TimerComponent';

declare global {
    interface ICore {
        Root: typeof Root;
    }

    namespace we {
        namespace core {
            type Root = InstanceType<typeof Root>;
        }
    }
}

export enum InstanceQueueIndex {
    Start,
    Update,
    LateUpdate,
    Max,
}

/**
 * 管理根部的 Scene
 * 存放所有Entity的引用
 * 负责Entity生命周期update/lateUpdate调用
 */
@we.decorator.typeSingleton('Root')
export class Root extends Singleton {
    // 管理所有的 Entity
    private readonly allEntities = new Map<number, Entity>();

    private readonly queues: Array<Queue<number>> = [];

    public scene: Scene;

    static get Inst() {
        return this.getInstance();
    }

    protected awake() {
        for (let i = 0; i < InstanceQueueIndex.Max; i++) {
            this.queues[i] = new Queue<number>();
        }
    }

    protected update() {
        this.start();
        const queue = this.queues[InstanceQueueIndex.Update];
        let count = queue.size;
        while (count-- > 0) {
            const instanceId = queue.dequeue();
            const component: Entity = this.get(instanceId);
            if (component == null) {
                continue;
            }

            if (component.IsDisposed) {
                // 已经被销毁了
                continue;
            }

            if (!component.IsActive) {
                // 处于非激活状态
                continue;
            }

            queue.enqueue(instanceId);

            try {
                component?.['update']?.apply(component);
            } catch (err) {
                we.error(`Root update, err: ${JSON.stringify(CC_DEV ? err.stack : err.message || err)}`);
            }
        }
    }

    protected lateUpdate() {
        const queue = this.queues[InstanceQueueIndex.LateUpdate];
        let count = queue.size;
        while (count-- > 0) {
            const instanceId = queue.dequeue();
            const component: Entity = this.get(instanceId);
            if (component == null) {
                continue;
            }

            if (component.IsDisposed) {
                // 已经被销毁了
                continue;
            }

            if (!component.IsActive) {
                // 处于非激活状态
                continue;
            }

            queue.enqueue(instanceId);

            try {
                component?.['lateUpdate']?.apply(component);
            } catch (err) {
                we.error(`Root lateUpdate, err: ${JSON.stringify(CC_DEV ? err.stack : err.message || err)}`);
            }
        }
    }

    private start() {
        const queue = this.queues[InstanceQueueIndex.Start];
        let count = queue.size;
        while (count-- > 0) {
            const instanceId = queue.dequeue();
            const component: Entity = this.get(instanceId);
            if (component == null) {
                continue;
            }

            if (component.IsDisposed) {
                // 已经被销毁了
                continue;
            }

            if (!component.IsActive) {
                // 处于非激活状态
                continue;
            }

            try {
                component?.['start']?.apply(component);
            } catch (err) {
                we.error(`Root start, err: ${JSON.stringify(CC_DEV ? err.stack : err.message || err)}`);
            }
        }
    }

    /** 创建Root Scene */
    public createRoot(id?: number, instanceId?: number): void {
        if (id != null && instanceId != null) {
            this.scene = EntitySceneFactory.createScene(id, instanceId, 0, 0, 'Process');
        } else {
            this.scene = EntitySceneFactory.createScene(0, 0, 'Process');
        }
        this.add(this.scene);
    }

    public dispose(): void {
        this.scene.dispose();
    }

    public add(entity: Entity): void {
        if (!entity || entity.IsDisposed) {
            return;
        }
        this.allEntities.set(entity.InstanceId, entity);

        const preInstanceId = entity.InstanceId;
        TimerComponent.Inst.scheduleOnce(0, entity).then(() => {
            if (preInstanceId !== entity.InstanceId) {
                return;
            }
            if (entity.IsNew && entity?.['start']) {
                this.queues[InstanceQueueIndex.Start].enqueue(entity.InstanceId);
            }
        });

        if (entity?.['update']) {
            this.queues[InstanceQueueIndex.Update].enqueue(entity.InstanceId);
        }

        if (entity?.['lateUpdate']) {
            this.queues[InstanceQueueIndex.LateUpdate].enqueue(entity.InstanceId);
        }
    }

    public remove(instanceId: number): void {
        this.allEntities.delete(instanceId);
    }

    public get(instanceId: number): Entity {
        return this.allEntities.get(instanceId) ?? null;
    }

    public ToString(): string {
        const sb: string[] = [];

        const noParent = new Set<Function>();
        const typeCount: Record<string, number> = {};
        const noDomain = new Set<Function>();

        for (const instanceId of this.allEntities.keys()) {
            const entity = this.allEntities.get(instanceId);
            const type = entity.constructor;

            if (!entity.Parent) {
                noParent.add(type);
            }

            if (!entity.Domain) {
                noDomain.add(type);
            }

            if (typeCount[type.name]) {
                typeCount[type.name]++;
            } else {
                typeCount[type.name] = 1;
            }
        }

        sb.push('not set parent type: ');
        for (const type of noParent) {
            sb.push(`\t${type.name}`);
        }

        sb.push('not set domain type: ');
        for (const type of noDomain) {
            sb.push(`\t${type.name}`);
        }

        const orderByDescending = Object.entries(typeCount).sort((a, b) => {
            return b[1] - a[1];
        });

        sb.push('Entity Count: ');
        for (const [typeName, count] of orderByDescending) {
            if (count === 1) {
                continue;
            }

            sb.push(`\t${typeName}: ${count}`);
        }

        return sb.join('\n');
    }
}

we.core.Root = Root;
