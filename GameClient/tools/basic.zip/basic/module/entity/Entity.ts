import { KeySymbol } from '../../decorator/DecoratorSymbol';
import { BasicType } from '../../type/BasicType';
import { Scene } from '../scene/Scene';
import { IEntityLifecycle } from './IEntityLifecycle';
import { ObjectPool } from '../objectpool/ObjectPool';

declare global {
    interface ICore {
        Entity: typeof Entity;
    }

    namespace we {
        namespace core {
            type Entity = InstanceType<typeof Entity>;
        }
    }
}

/** 实体状态 */
enum EntityStatus {
    None = 0,
    IsFromPool = 1,
    IsRegister = 1 << 1,
    IsComponent = 1 << 2,
    IsCreated = 1 << 3,
    IsNew = 1 << 4,
    IsActive = 1 << 5,
}

/**
 * Entity awake方法参数类型
 */
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-expect-error
export type AwakeParamsType<T> = BasicType.WithOptionalParameters<BasicType.ProtectedMethodParams<T, 'awake'>, [options: { isFromPool: boolean }]>;

/**
 * Entity awakeAsync方法参数类型
 */
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-expect-error
export type AwakeAsyncParamsType<T> = BasicType.WithOptionalParameters<BasicType.ProtectedMethodParams<T, 'awakeAsync'>, [options: { isFromPool: boolean }]>;

function isOptions(options: any) {
    return options != null && typeof options === 'object' && options.isFromPool != null && typeof options.isFromPool === 'boolean';
}

export abstract class Entity extends IEntityLifecycle {
    /** 组件实例ID */
    private instanceId = 0;
    /** 实体ID生成器 */
    static generateInstanceId = 1;
    /** 实体ID生成器 */
    static generateId = 1;

    private isAsyncCreate = false;

    /** 组件实例ID，每次创建都会自动更新 */
    protected set InstanceId(v: number) {
        this.instanceId = v;
    }

    get InstanceId() {
        return this.instanceId;
    }

    /** 实体状态 */
    private status: EntityStatus = EntityStatus.None;

    /** 是否来自对象池 */
    get IsFromPool() {
        return (this.status & EntityStatus.IsFromPool) === EntityStatus.IsFromPool;
    }

    set IsFromPool(value) {
        if (value) {
            this.status |= EntityStatus.IsFromPool;
        } else {
            this.status &= ~EntityStatus.IsFromPool;
        }
    }

    get IsRegister() {
        return (this.status & EntityStatus.IsRegister) === EntityStatus.IsRegister;
    }

    set IsRegister(value) {
        if (this.IsRegister === value) {
            return;
        }

        if (value) {
            this.status |= EntityStatus.IsRegister;
        } else {
            this.status &= ~EntityStatus.IsRegister;
        }

        if (!value) {
            we.core.Root.Inst.remove(this.InstanceId);
        } else {
            if (!this.isAsyncCreate) {
                we.core.Root.Inst.add(this);
            }
        }
    }

    get IsComponent() {
        return (this.status & EntityStatus.IsComponent) === EntityStatus.IsComponent;
    }

    set IsComponent(value) {
        if (value) {
            this.status |= EntityStatus.IsComponent;
        } else {
            this.status &= ~EntityStatus.IsComponent;
        }
    }

    get IsCreated() {
        return (this.status & EntityStatus.IsCreated) === EntityStatus.IsCreated;
    }

    set IsCreated(value) {
        if (value) {
            this.status |= EntityStatus.IsCreated;
        } else {
            this.status &= ~EntityStatus.IsCreated;
        }
    }

    get IsNew() {
        return (this.status & EntityStatus.IsNew) === EntityStatus.IsNew;
    }

    set IsNew(value) {
        if (value) {
            this.status |= EntityStatus.IsNew;
        } else {
            this.status &= ~EntityStatus.IsNew;
        }
    }

    /** 是否激活状态，awake/start之后才是激活状态 */
    get IsActive() {
        return (this.status & EntityStatus.IsActive) === EntityStatus.IsActive;
    }

    set IsActive(value) {
        if (value) {
            this.status |= EntityStatus.IsActive;
        } else {
            this.status &= ~EntityStatus.IsActive;
        }
    }

    /**
     * 是否已销毁
     * 异步场景时，应该在异步调用之前记录一下实例Id,异步返回之后判定一下当前实例Id是否已经变了，如果变了，则说明已经销毁了
     */
    get IsDisposed() {
        return this.instanceId === 0;
    }

    protected parent!: Entity;

    get Parent() {
        return this.parent;
    }

    /** 可以改变parent，但是不能设置为null */
    private set Parent(value: Entity) {
        if (value == null) {
            throw new Error('Entity Parent, cant set parent null');
        }

        if (value === this) {
            throw new Error('Entity Parent, cant set parent self');
        }

        // 严格限制parent必须要有domain,也就是说parent必须在数据树上面
        if (value.Domain == null) {
            throw new Error('Entity Parent, cant set parent because parent domain is null');
        }

        // 之前有parent
        if (this.parent != null) {
            // parent相同，不设置
            if (this.parent === value) {
                we.warn('Entity Parent, set parent repeat');
                return;
            }

            this.parent.removeFromChildren(this);
        }

        this.parent = value;
        this.IsComponent = false;
        this.parent.addToChildren(this);
        this.Domain = this.parent.domain;
    }

    get Scene() {
        return this.Domain as Scene;
    }

    get Zone(): number {
        return (this.Domain as Scene)?.Zone ?? 0;
    }

    /** 该方法只能在AddComponent中调用，其他人不允许调用 */
    // eslint-disable-next-line accessor-pairs
    private set ComponentParent(value: Entity) {
        if (value == null) {
            throw new Error('Entity ComponentParent, cant set parent null');
        }

        if (value === this) {
            throw new Error('Entity ComponentParent, cant set parent self');
        }

        // 严格限制parent必须要有domain,也就是说parent必须在数据树上面
        if (value.Domain == null) {
            throw new Error('Entity ComponentParent, cant set parent because parent domain is null');
        }

        if (this.parent != null) {
            // 之前有parent
            // parent相同，不设置
            if (this.parent === value) {
                we.warn('Entity ComponentParent, set parent repeat');
                return;
            }
            this.parent.removeFromComponents(this);
        }

        this.parent = value;
        this.IsComponent = true;
        this.parent.addToComponents(this);
        this.Domain = this.parent.domain;
    }

    public getParent<T extends Entity>(): T {
        return this.Parent as T;
    }

    protected id = 0;

    set Id(v: number) {
        this.id = v;
    }

    get Id() {
        return this.id;
    }

    public get __type__() {
        return this.constructor.name;
    }

    protected domain!: Entity;

    get Domain() {
        return this.domain;
    }

    set Domain(value: Entity) {
        if (value == null) {
            throw new Error('Entity Domain, domain cant set null');
        }

        if (this.domain === value) {
            return;
        }

        const preDomain: Entity = this.domain;
        this.domain = value;

        if (preDomain == null) {
            this.instanceId = ++Entity.generateInstanceId;
            this.IsRegister = true;
        }

        // 是否注册跟parent一致
        if (this.parent != null) {
            this.IsRegister = this.Parent.IsRegister;
        }

        // 递归设置孩子的Domain
        if (this.children != null) {
            for (const entity of this.children.values()) {
                entity.Domain = this.domain;
            }
        }

        if (this.components != null) {
            for (const component of this.components.values()) {
                component.Domain = this.domain;
            }
        }

        if (!this.IsCreated) {
            this.IsCreated = true;
        }
    }

    private children: Map<number, Entity> | null | undefined;

    get Children() {
        if (this.children == null) {
            this.children = ObjectPool.Inst.fetch(Map as new () => Map<number, Entity>);
        }
        return this.children;
    }

    private addToChildren(entity: Entity) {
        this.Children?.set(entity.id, entity);
    }

    private removeFromChildren(entity: Entity): void {
        if (this.children == null) {
            return;
        }

        this.children.delete(entity.id);

        if (this.children.size === 0) {
            ObjectPool.Inst.recycle(this.children);
            this.children = null;
        }
    }

    /**
     * 组件集合
     */
    private components: Map<string, Entity> | null | undefined;

    get Components() {
        if (this.components == null) {
            this.components = ObjectPool.Inst.fetch(Map as new () => Map<string, Entity>);
        }
        return this.components;
    }

    private addToComponents(component: Entity) {
        this.Components.set(component.__type__, component);
    }

    private removeFromComponents(component: Entity) {
        if (this.components == null) {
            return;
        }

        this.components.delete(component.__type__);

        if (this.components.size === 0) {
            ObjectPool.Inst.recycle(this.components);
            this.components = null;
        }
    }

    public getChild<T extends Entity>(id: number): T {
        if (this.children == null) {
            return null;
        }
        return this.children.get(id) as T;
    }

    public removeChild(id: number) {
        if (this.children == null) {
            return;
        }

        const child: Entity = this.children.get(id);
        if (!child) {
            return;
        }

        this.children.delete(id);
        child.dispose();
    }

    removeComponent(type: Entity): void;
    removeComponent(type: string): void;
    removeComponent<T extends Entity>(type: new () => T): void;
    removeComponent(type: any) {
        if (this.IsDisposed) {
            return;
        }

        if (!this.components) {
            return;
        }

        let component: Entity = null;
        let typeClass = null;
        if (type instanceof Entity) {
            component = type;
            typeClass = type.__type__;
        } else {
            typeClass = type;
        }

        const c = this.getComponent(typeClass);
        if (c == null) {
            return;
        }

        if (component != null && c.instanceId !== component.instanceId) {
            return;
        }

        this.removeFromComponents(c);
        c.dispose();
    }

    getComponent(type: string): Entity;
    getComponent<T extends Entity>(type: new () => T): T;
    getComponent<T extends Entity>(type: string | (new () => T)): Entity {
        if (this.components == null) {
            return null;
        }

        let className: string = null;
        if (typeof type === 'string') {
            className = type;
        } else {
            className = type.name;
        }

        return this.components.get(className);
    }

    private static create<T extends Entity>(CLASS: new () => T, isFromPool: boolean): Entity {
        let component: Entity;
        if (isFromPool) {
            component = ObjectPool.Inst.fetch(CLASS);
        } else {
            component = new CLASS();
        }
        component.IsFromPool = isFromPool;
        component.IsCreated = true;
        component.IsNew = true;
        component.id = 0;
        return component;
    }

    /**
     * 添加组件，实体下组件具有唯一性
     * @param component
     */
    addComponent<T extends Entity>(component: T): T;
    addComponent<T extends Entity>(component: new () => T, ...args: AwakeParamsType<T>): T;
    addComponent<T extends Entity>(component: any, ...args: any[]): T {
        let classType: string = null;
        let inst: T = null;
        let isFromPool = false;

        if (component instanceof Entity) {
            classType = component.__type__;
            inst = component as T;
        } else {
            classType = component.name;
        }

        if (this.Components.has(classType)) {
            if (!inst && Reflect.getMetadata(KeySymbol.Singleton, component)) {
                return component.Inst;
            }
            throw new Error(`Entity addComponent, component already exists, id: ${this.id}, component: ${classType}`);
        }

        if (!inst) {
            // 设置是否使用对象池
            if (args.length > 0) {
                if (isOptions(args[args.length - 1])) {
                    isFromPool = args.pop().isFromPool;
                }
            }

            const isSingleton = Reflect.getMetadata(KeySymbol.Singleton, component);
            inst = (isSingleton ? component.Inst : null) ?? Entity.create(component, isFromPool);
            inst.id = this.id;
            inst.ComponentParent = this;

            if (isSingleton) {
                if (component.Inst) {
                    return inst;
                }
                component.Inst = inst;
            }

            inst?.awake?.apply(inst, [...args]);
            inst.IsActive = true;
        } else {
            inst.ComponentParent = this;
        }

        return inst;
    }

    /**
     * 添加组件，实体下组件具有唯一性【支持异步】
     * @param component
     */
    async addComponentAsync<T extends Entity>(component: T): Promise<T>;
    async addComponentAsync<T extends Entity>(component: new () => T, ...args: AwakeAsyncParamsType<T>): Promise<T>;
    async addComponentAsync<T extends Entity>(component: any, ...args: any[]): Promise<T> {
        let classType: string = null;
        let inst: T = null;
        let isFromPool = false;

        if (component instanceof Entity) {
            classType = component.__type__;
            inst = component as T;
        } else {
            classType = component.name;
        }

        if (this.Components.has(classType)) {
            if (!inst && Reflect.getMetadata(KeySymbol.Singleton, component)) {
                return component.Inst;
            }

            throw new Error(`Entity addComponentAsync, component already exists, id: ${this.id}, component: ${classType}`);
        }

        if (!inst) {
            // 设置是否使用对象池
            if (args.length > 0) {
                if (isOptions(args[args.length - 1])) {
                    isFromPool = args.pop().isFromPool;
                }
            }

            const isSingleton = Reflect.getMetadata(KeySymbol.Singleton, component);
            inst = (isSingleton ? component.Inst : null) ?? Entity.create(component, isFromPool);
            inst.id = this.id;
            inst.isAsyncCreate = inst.IsNew ? true : false;
            inst.ComponentParent = this;

            if (isSingleton) {
                if (component.Inst) {
                    return inst;
                }
                component.Inst = inst;
            }

            if (inst?.awakeAsync) {
                await inst?.awakeAsync?.(...args);
            } else {
                await inst?.awake?.(...args);
            }
            we.core.Root.Inst.add(inst);
            inst.IsActive = true;
        } else {
            inst.ComponentParent = this;
        }

        return inst;
    }

    addChild<T extends Entity>(entity: T): T;
    addChild<T extends Entity>(entity: new () => T, ...args: AwakeParamsType<T>): T;
    addChild<T extends Entity>(entity: any, ...args: any[]): T {
        if (entity instanceof Entity) {
            entity.Parent = this;
            return entity as T;
        }

        let isFromPool = false;

        // 设置是否使用对象池
        if (args.length > 0) {
            if (isOptions(args[args.length - 1])) {
                isFromPool = args.pop().isFromPool;
            }
        }

        const isSingleton = Reflect.getMetadata(KeySymbol.Singleton, entity);
        const inst = (isSingleton ? entity.Inst : null) ?? Entity.create(entity, isFromPool);

        inst.id = ++Entity.generateId;
        inst.Parent = this;

        if (isSingleton) {
            if (entity.Inst) {
                return inst;
            }
            entity.Inst = inst;
        }

        inst?.awake?.(...args);
        inst.IsActive = true;

        return inst;
    }

    async addChildAsync<T extends Entity>(entity: T): Promise<T>;
    async addChildAsync<T extends Entity>(entity: new () => T, ...args: AwakeAsyncParamsType<T>): Promise<T>;
    async addChildAsync<T extends Entity>(entity: any, ...args: any[]): Promise<T> {
        if (entity instanceof Entity) {
            entity.Parent = this;
            return entity as T;
        }

        let isFromPool = false;

        // 设置是否使用对象池
        if (args.length > 0) {
            if (isOptions(args[args.length - 1])) {
                isFromPool = args.pop().isFromPool;
            }
        }

        const isSingleton = Reflect.getMetadata(KeySymbol.Singleton, entity);
        const inst = (isSingleton ? entity.Inst : null) ?? Entity.create(entity, isFromPool);
        inst.isAsyncCreate = inst.IsNew ? true : false;
        inst.id = ++Entity.generateId;
        inst.Parent = this;

        if (isSingleton) {
            if (entity.Inst) {
                return inst;
            }
            entity.Inst = inst;
        }

        if (inst?.awakeAsync) {
            await inst?.awakeAsync?.(...args);
        } else {
            await inst?.awake?.(...args);
        }

        we.core.Root.Inst.add(inst);
        inst.IsActive = true;

        return inst;
    }

    addChildWithId<T extends Entity>(id: number, entity: T): T;
    addChildWithId<T extends Entity>(id: number, entity: new () => T, ...args: any[]): T;
    addChildWithId<T extends Entity>(id: number, entity: any, ...args: any[]): T {
        if (entity instanceof Entity) {
            entity.Parent = this;
            return entity as T;
        }

        let isFromPool = false;
        // 设置是否使用对象池
        if (args.length > 0) {
            if (isOptions(args[args.length - 1])) {
                isFromPool = args.pop().isFromPool;
            }
        }

        const isSingleton = Reflect.getMetadata(KeySymbol.Singleton, entity);
        const inst = (isSingleton ? entity.Inst : null) ?? Entity.create(entity, isFromPool);
        inst.id = id;
        inst.Parent = this;

        if (isSingleton) {
            if (entity.Inst) {
                return inst;
            }
            entity.Inst = inst;
        }

        inst?.awake?.(...args);
        inst.IsActive = true;

        return inst;
    }

    async addChildWithIdAsync<T extends Entity>(id: number, entity: T): Promise<T>;
    async addChildWithIdAsync<T extends Entity>(id: number, entity: new () => T, ...args: any[]): Promise<T>;
    async addChildWithIdAsync<T extends Entity>(id: number, entity: any, ...args: any[]): Promise<T> {
        if (entity instanceof Entity) {
            entity.Parent = this;
            return entity as T;
        }

        let isFromPool = false;
        // 设置是否使用对象池
        if (args.length > 0) {
            if (isOptions(args[args.length - 1])) {
                isFromPool = args.pop().isFromPool;
            }
        }

        const isSingleton = Reflect.getMetadata(KeySymbol.Singleton, entity);
        const inst = (isSingleton ? entity.Inst : null) ?? Entity.create(entity, isFromPool);
        inst.id = id;
        inst.isAsyncCreate = inst.IsNew ? true : false;
        inst.Parent = this;

        if (isSingleton) {
            if (entity.Inst) {
                return inst;
            }
            entity.Inst = inst;
        }

        if (inst?.awakeAsync) {
            await inst?.awakeAsync?.(...args);
        } else {
            await inst?.awake?.(...args);
        }
        we.core.Root.Inst.add(inst);
        inst.IsActive = true;

        return inst;
    }

    /** 实体是否有效 */
    isValid() {
        return !this.IsDisposed;
    }

    dispose() {
        if (this.IsDisposed) {
            return;
        }

        this.destroyBefore?.();

        this.IsRegister = false;
        this.IsActive = false;
        this.instanceId = 0;
        this.isAsyncCreate = false;

        // 清理Children
        if (this.children != null) {
            for (const child of this.children.values()) {
                child.dispose();
            }
            this.children.clear();
            ObjectPool.Inst.recycle(this.children);
            this.children = null;
        }

        // 清理Component
        if (this.components != null) {
            for (const component of this.components.values()) {
                component.dispose();
            }
            this.components.clear();
            ObjectPool.Inst.recycle(this.components);
            this.components = null;
        }

        // 触发Destroy事件
        this.destroy?.();

        this.domain = null;

        if (this.parent != null && !this.parent.IsDisposed) {
            if (this.IsComponent) {
                this.parent.removeComponent(this);
            } else {
                this.parent.removeFromChildren(this);
            }
        }

        this.parent = null;

        if (this.IsFromPool) {
            ObjectPool.Inst.recycle(this);
        }

        this.status = EntityStatus.None;
    }
}

we.core.Entity = Entity;
