/**
 * 组件生命周期
 */
export abstract class IEntityLifecycle {
    protected awake?(...args: any[]): void;
    protected awakeAsync?(...args: any[]): Promise<void>;
    protected start?(): void;
    protected destroyBefore?(): void;
    protected destroy?(): void;
    protected update?(): void;
    protected lateUpdate?(): void;
    abstract dispose(): void;
}
