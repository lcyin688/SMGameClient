import { Scene } from '../scene/Scene';
import { Entity } from './Entity';

export class EntitySceneFactory {
    static createScene(id: number, instanceId: number, zone: number, sceneType: number, name: string, parent?: Entity): Scene;
    static createScene(zone: number, sceneType: number, name: string, parent?: Entity): Scene;
    static createScene(idOrZone: number | number, instanceIdOrSceneType: number | number, zoneOrName: number | string, sceneTypeOrParent: number | Entity, name?: string, parent?: Entity): Scene {
        if (typeof idOrZone === 'number' && typeof instanceIdOrSceneType === 'number' && typeof zoneOrName === 'number' && typeof sceneTypeOrParent === 'number' && typeof name === 'string' && parent instanceof Entity) {
            return new Scene(idOrZone, instanceIdOrSceneType, zoneOrName, sceneTypeOrParent, name, parent);
        } else if (typeof idOrZone === 'number' && typeof instanceIdOrSceneType === 'number' && typeof zoneOrName === 'number' && typeof sceneTypeOrParent === 'number' && typeof name === 'string') {
            return new Scene(idOrZone, instanceIdOrSceneType, zoneOrName, sceneTypeOrParent, name, parent);
        } else if (typeof idOrZone === 'number' && typeof instanceIdOrSceneType === 'number' && typeof zoneOrName === 'string' && (sceneTypeOrParent == null || sceneTypeOrParent instanceof Entity)) {
            const instanceId = ++Entity.generateInstanceId;
            return new Scene(instanceId, idOrZone, instanceIdOrSceneType, zoneOrName, sceneTypeOrParent as Entity);
        } else {
            throw new Error('Invalid arguments for createScene');
        }
    }
}
