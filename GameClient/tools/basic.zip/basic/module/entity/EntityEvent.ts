import { EventGroup } from '../event/EventGroup';

declare global {
    interface ICore {
        EntityEvent: typeof EntityEvent;
    }

    namespace we {
        namespace core {
            type EntityEvent<T> = InstanceType<typeof EntityEvent<T>>;
        }
    }
}

/**
 * 支持事件的Entity
 */
@we.decorator.typeRegister('EntityEvent')
export class EntityEvent<E = any> extends we.core.Entity {
    /** 事件Group */
    eventGroup: EventGroup<E>;

    constructor() {
        super();
        we.core.FuncAsync.bindFunc(this, 'start', this.__startEnableMobx);
        we.core.FuncAsync.bindFunc(this, 'destroy', this.__destroyDisableMobx);
    }

    protected awake(...args: any[]): void {
        this.eventGroup = new EventGroup<E>();
    }

    protected destroy(): void {
        this.eventGroup.removeAll();
    }

    @we.mobx.enable
    protected __startEnableMobx(): void {}

    @we.mobx.disable
    protected __destroyDisableMobx() {}

    /**
    /**
    * 监听事件
    * @param k 事件名
    * @param func 回调
    */
    public on<K extends keyof E>(k: K, func: we.core.EventFunc<E[K]>);
    public on<K extends keyof E>(k: K, func: (msg: E[K]) => void | Promise<void>, target: any);
    public on<K extends keyof E>(k: K, ...args) {
        // eslint-disable-next-line prefer-spread, prefer-rest-params
        this.eventGroup.on.apply(this.eventGroup, Array.prototype.slice.call(arguments, 0));
    }

    /**
     * 监听事件（一次性）
     * @param k 事件名
     * @param func 回调kk
     */
    public once<K extends keyof E>(k: K, func: we.core.EventFunc<E[K]>);
    public once<K extends keyof E>(k: K, func: (msg: E[K]) => void | Promise<void>, target: any);
    public once<K extends keyof E>(k: K, ...args) {
        // eslint-disable-next-line prefer-spread, prefer-rest-params
        this.eventGroup.once.apply(this.eventGroup, Array.prototype.slice.call(arguments, 0));
    }

    /**
     * 异步等待事件
     * @param k 事件key
     * @param target 事件绑定对象
     * @param timeout 超时时间，单位【秒】默认：10s
     * @returns
     */
    public async onceAsync<K extends keyof E>(k: K, target?: any, timeout: number = 10): Promise<E[K]> {
        return await this.eventGroup.onceAsync(k, target, timeout);
    }

    /**
     * 取消监听事件
     * @param name 事件名
     * @param callback 回调
     * @param target 订阅对象
     */
    public off<K extends keyof E>(k: K, cb: (...args: any[]) => any, target: any) {
        this.eventGroup.off(k, cb, target);
    }

    /**
     * 通过target取消监听事件
     * @param target
     */
    public offByTarget(target: any) {
        this.eventGroup.offByTarget(target);
    }

    /**
     * 发射事件
     * @param k 事件名
     * @param msg 消息
     * @param p 其他参数
     *  persistence 是否持久化数据
     *  sticky 是否为粘性消息
     */
    public emit<K extends keyof E>(k: K, msg: E[K], p: { persistence?: boolean; sticky?: boolean } = {}) {
        this.eventGroup.emit(k, msg, p);
    }

    /**
     * 发射事件
     * @param name 事件名
     * @param msg 参数
     *  persistence 是否持久化数据
     *  sticky 是否为粘性消息
     */
    public async emitAsync<K extends keyof E>(k: K, msg: E[K], p: { persistence?: boolean; sticky?: boolean } = {}) {
        await this.eventGroup.emitAsync(k, msg, p);
    }

    /**
     * 移除事件
     */
    public remove<K extends keyof E>(k: K) {
        this.eventGroup.remove(k);
    }

    /**
     * 移除所有事件
     */
    public removeAll() {
        this.eventGroup.removeAll();
    }
}

we.core.EntityEvent = EntityEvent;
