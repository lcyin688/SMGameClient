/* eslint-disable no-console */
import { lodash } from '../../utils/NpmExport';
import { TimeHelper } from '../time/TimeHelper';
import { ILogDataOutput, ILogger, LogFormatType, LogLevel, printn } from './ILogger';

const consoleCallers = ['log', 'debug', 'info', 'warn', 'error'];

export class WELogger implements ILogger {
    /** 日志打印等级 */
    private printLevel: number = LogLevel.verbose;
    /** 日志上报等级 */
    private reportLevel: number = LogLevel.info;
    /** 日志数据输出 */
    private dataOutput: ILogDataOutput;

    public constructor() {
        this.setLevel('verbose', 'info');
    }

    public setLevel<K extends keyof typeof LogLevel>(printLevel: K, reportLevel?: K): void {
        this.printLevel = LogLevel[printLevel] ?? this.printLevel;
        this.reportLevel = LogLevel[reportLevel] ?? this.reportLevel;

        if (CC_DEV) {
            this.setDevLog();
        } else {
            this.setReleaseLog();
        }
    }

    public setDataOutput(output: ILogDataOutput): void {
        this.dataOutput = output;
    }

    public log: (...args: any[]) => void;
    public debug: (...args: any[]) => void;
    public info: (...args: any[]) => void;
    public warn: (...args: any[]) => void;
    public error: (...args: any[]) => void;

    /**
     * 设置开发模式日志
     * 只打印不上报, 不被日志开关控制, 点击日志可以直接跳转到对应行
     */
    private setDevLog(): void {
        let levelStype = 'border-radius: 2px 2px 2px 2px; color: #ffffff; font-weight: bold;';
        this.log = this.printLevel <= LogLevel.verbose ? console.log.bind(console, `%c%s`, `font-weight: bold;`, `[V]`) : printn;
        this.debug = this.printLevel <= LogLevel.debug ? console.debug.bind(console, `%c%s%c %s`, `background:#0B71DD; ${levelStype}`, `[D]`, `color: #0B71DD;`) : printn;
        this.info = this.printLevel <= LogLevel.info ? console.info.bind(console, `%c%s%c %s`, `background:#009586; ${levelStype}`, `[I]`, `color: #009586;`) : printn;
        this.warn = this.printLevel <= LogLevel.warn ? console.warn.bind(console, `%c%s%c %s`, `background:#F1561E; ${levelStype}`, `[W]`, `color: #F1561E;`) : printn;
        this.error = this.printLevel <= LogLevel.error ? console.error.bind(console, `%c%s%c %s`, `background:#F11F30; ${levelStype}`, `[E]`, `color: #F11F30;`) : printn;
    }

    /**
     * 设置发布模式日志
     * 打印 + 上报, 被日志开关控制
     */
    private setReleaseLog(): void {
        this.log = (...args: any[]) => {
            // 只打印不上报
            this.logPrint(LogLevel.verbose, ...args);
        };
        this.debug = (...args: any[]) => {
            // 只在 dev 打印不上报
        };
        this.info = (...args: any[]) => {
            this.logPrint(LogLevel.info, ...args);
            this.logReport(LogLevel.info, ...args);
        };
        this.warn = (...args: any[]) => {
            this.setStack(args, new Error());
            this.logPrint(LogLevel.warn, ...args);
            this.logReport(LogLevel.warn, ...args);
        };
        this.error = (...args: any[]) => {
            this.setStack(args, new Error());
            this.logPrint(LogLevel.error, ...args);
            this.logReport(LogLevel.error, ...args);
        };
    }

    /**
     * 设置堆栈信息
     * @param args
     * @param err
     * @returns
     */
    private setStack(args: any[], err: Error): any[] {
        args ??= [];

        const custom = args.find((item) => {
            return item?.custom == true;
        });

        if (custom) {
            if (!custom.stack) {
                custom.stack = err.stack;
            }
        } else {
            args.push({ custom: true, stack: err.stack });
        }

        return args;
    }

    /**
     * 日志打印
     * @param level 日志等级
     * @param args 日志信息
     */
    private logPrint(level: LogLevel, ...args: any[]): void {
        if (level < this.printLevel) {
            return;
        }

        args.filter((arg) => {
            return !lodash.isEmpty(arg);
        });

        if (args.length === 0) {
            we.warn(`WELogger logPrint, level ${LogLevel[level]} no data`, we.noup);
            return;
        }

        let data = this.dataOutput?.format(LogFormatType.print, level, args);
        if (!data) {
            return;
        }

        let message = `[${LogLevel[level].toUpperCase().charAt(0)}] ${data}`;
        if (cc.sys.isBrowser && cc.sys.isMobile && window['vConsole']) {
            // 手机浏览器 vConsole 添加时间戳
            let timestamp = TimeHelper.formatTime('HH:mm:ss.SSS');
            message = `${timestamp} ${message}`;
        }

        let logMethod = console[consoleCallers[level]] ?? console.log;
        logMethod.call(console, message);
    }

    /**
     * 日志上报
     * @param level 日志等级
     * @param args 日志信息
     */
    private logReport(level: LogLevel, ...args: any[]): void {
        if (level < this.reportLevel) {
            return;
        }

        args.filter((arg) => {
            return !lodash.isEmpty(arg);
        });

        if (args.length === 0) {
            we.warn(`WELogger logReport, level ${LogLevel[level]} no data`, we.noup);
            return;
        }

        let data = this.dataOutput?.format(LogFormatType.report, level, args);
        if (!data) {
            return;
        }

        this.dataOutput?.report(data);
    }
}
