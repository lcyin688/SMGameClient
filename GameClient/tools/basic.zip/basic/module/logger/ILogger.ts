/**
 * 日志等级
 */
export enum LogLevel {
    /** 详细: 只打印不上报 */
    verbose,
    /** 调试: 只在 dev 打印不上报 */
    debug,
    /** 信息: 一般用来重要数据上报 */
    info,
    /** 警告: 代码运行不符合预期, 不会阻塞流程 */
    warn,
    /** 错误: 代码运行不符合预期, 可能会阻塞流程 */
    error,
    /** 致命: 监听 js 抛出的异常, 无法手动调用 */
    fatal,
    /** 关闭日志 */
    none,
}

/**
 * 日志格式化类型
 */
export enum LogFormatType {
    /** 打印 */
    print,
    /** 上报 */
    report,
}

/**
 * 打印空内容 print none
 * @param args
 */
export function printn(...args: any[]) {}

export abstract class ILogger {
    /**
     * 设置日志等级
     * @param printLevel 打印等级
     * @param reportLevel 上报等级
     */
    public abstract setLevel<K extends keyof typeof LogLevel>(printLevel: K, reportLevel?: K): void;

    /**
     * 设置数据输出处理器
     * @param output
     */
    public abstract setDataOutput(output: ILogDataOutput): void;

    /** 详细: 只打印不上报 */
    public abstract log(...args: any[]): void;

    /** 调试: 只在 dev 打印不上报 */
    public abstract debug(...args: any[]): void;

    /** 信息: 一般用来重要数据上报 */
    public abstract info(...args: any[]): void;

    /** 警告: 代码运行不符合预期, 不会阻塞流程 */
    public abstract warn(...args: any[]): void;

    /** 错误: 代码运行不符合预期, 可能会阻塞流程 */
    public abstract error(...args: any[]): void;
}

export abstract class ILogDataOutput {
    /**
     * 数据格式化接口
     * @param type
     * @param level
     * @param data
     */
    public abstract format(type: LogFormatType, level: LogLevel, ...data: any[]): string;

    /**
     * 数据上报接口
     * @param data
     */
    public abstract report(data: string): void;
}
