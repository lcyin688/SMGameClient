declare global {
    interface ICore {
        Func: typeof Func;
    }

    namespace we {
        namespace core {
            type Func<T extends (...args) => any> = InstanceType<typeof Func>;
        }
    }
}

/**
 * 用于绑定回调函数this指针
 */
export class Func<T extends (...args) => any> {
    public cb: T;
    protected target: any;
    protected fn: any;
    protected args: any[];

    protected isValid: () => boolean;

    protected isOnce: boolean = false;

    setValid(valid: () => boolean) {
        this.isValid = valid;
        return this;
    }

    /**
     * 创建函数实例
     * @param cb 回调函数
     * @param target 目标对象，可选
     * @param args 参数列表
     * @returns 返回函数实例
     */
    public static create<T extends (...args) => any>(cb: T, target: any = null, ...args: any[]): Func<T> {
        const caller: Func<T> = new Func<T>();
        // 这里要展开args, 否则会将args当数组传给wrapper, 导致其args参数变成2维数组[[]]
        caller.init(cb, target, ...args);
        return caller;
    }

    /** Check and invoke callback function */
    public static invoke(cb: (...args) => void, target: any = null, ...args: any[]) {
        if (!!cb && typeof cb === 'function') {
            // eslint-disable-next-line prefer-spread, prefer-rest-params
            return cb.bind(target).apply(target, Array.prototype.slice.call(arguments, 2));
        }
    }

    public static bindFunc<T>(thisTarget: T, oriFunc: string, newFunc: (...args) => void, newFuncAfter: boolean = false) {
        const onOriFunc = thisTarget[oriFunc];
        thisTarget[oriFunc] = function (...args) {
            if (newFuncAfter) {
                onOriFunc?.bind?.(thisTarget)?.(...args);
                newFunc.apply(thisTarget, args);
            } else {
                newFunc.apply(thisTarget, args);
                onOriFunc?.bind?.(thisTarget)?.(...args);
            }
        };
    }

    public static bindFuncAsync<T>(thisTarget: T, oriFunc: string, newFunc: (...args) => Promise<void>, newFuncAfter: boolean = false) {
        const onOriFunc = thisTarget[oriFunc];
        thisTarget[oriFunc] = async function (...args) {
            if (newFuncAfter) {
                await onOriFunc?.bind?.(thisTarget)?.(...args);
                await newFunc.apply(thisTarget, args);
            } else {
                await newFunc.apply(thisTarget, args);
                await onOriFunc?.bind?.(thisTarget)?.(...args);
            }
        };
    }

    public exec(...extras): any {
        if (!this.isValidFunc()) {
            return;
        }

        return this.cb.apply(this.target, this.args.concat(extras));
    }

    public execOnce(...extras): any {
        if (this.isOnce) {
            return;
        }
        this.isOnce = true;
        this.exec(...extras);
    }

    public isValidFunc() {
        let targetValid = true;
        if (this?.target?.isValid != null) {
            targetValid = typeof this.target.isValid === 'function' ? this.target.isValid() : this.target.isValid;
        }

        if ((this.isValid && !this.isValid?.()) || !targetValid) {
            return false;
        }

        return true;
    }

    public equal(cb: T, target?: any) {
        if (this.target) {
            return cb === this.cb && target === this.target;
        }

        return cb === this.cb;
    }

    protected init(cb: T, target = null, ...args) {
        this.cb = cb;
        this.target = target;
        if (args.length === 1 && args[0] == null) {
            args = [];
        }
        this.args = args;
    }
}

we.core.Func = Func;
