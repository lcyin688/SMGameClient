import { Func } from './Func';

declare global {
    interface ICore {
        FuncAsync: typeof FuncAsync;
    }

    namespace we {
        namespace core {
            type FuncAsync<T extends (...args) => any> = InstanceType<typeof FuncAsync>;
        }
    }
}

/**
 * 用于绑定回调函数this指针
 */
export class FuncAsync<T extends (...args) => Promise<any>> extends Func<T> {
    public static create<T extends (...args) => Promise<any>>(cb: T, target: any = null, ...args: any[]): FuncAsync<T> {
        const caller: FuncAsync<T> = new FuncAsync<T>();
        // 这里要展开args, 否则会将args当数组传给wrapper, 导致其args参数变成2维数组[[]]
        caller.init(cb, target, ...args);
        return caller;
    }

    public async exec(...extras) {
        if (!this.isValidFunc()) {
            return;
        }

        // eslint-disable-next-line @typescript-eslint/return-await
        return await this.cb.apply(this.target, this.args.concat(extras));
    }

    public async execOnce(...extras) {
        if (this.isOnce) {
            return;
        }
        this.isOnce = true;
        this.exec(...extras);
    }
}

we.core.FuncAsync = FuncAsync;
