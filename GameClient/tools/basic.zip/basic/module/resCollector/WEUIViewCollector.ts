import { MultiMap } from '../algorithms/MultiMap';

const { ccclass, property, executeInEditMode, menu, executionOrder } = cc._decorator;

declare global {
    interface IUI {
        /**
         * UIView专用收集器
         */
        WEUIViewCollector: typeof WEUIViewCollector;
    }

    namespace we {
        namespace ui {
            type WEUIViewCollector = InstanceType<typeof WEUIViewCollector>;
        }
    }
}

/**
 * 节点引用收集器
 */
@ccclass
@executeInEditMode
// 脚本生命周期回调的执行优先级。小于 0 的脚本将优先执行，大于 0 的脚本将最后执行。该优先级只对
// onLoad, onEnable, start, update 和 lateUpdate 有效，对 onDisable 和 onDestroy 无效。
@executionOrder(-5001)
@menu('we/other/WEUIViewCollector(自动节点引用收集器)')
export class WEUIViewCollector extends cc.Component {
    /**
     * 资源收集关注节点前缀
     * RC_:节点及节点下组件收集
     * RCN_:收集当前节点
     * Item_:Item模块节点收集
     * LANG_:多语言节点
     */
    static autoLoadNodePrefix = ['RC_', 'RCN_', 'Item_', 'LANG_'];

    /**
     * 节点后缀关注
     */
    static autoLoadNodeSuffix = ['Itm'];

    /**
     * 不往下收集的节点前缀
     */
    static autoBreakLoadNodePrefix = ['Item_'];

    /**
     * 不往下收集的节点后缀
     */
    static autoBreakLoadNodeSuffix = ['Itm'];

    /** 所有节点 */
    private allNodes: cc.Node[] = [];
    /** 不可重复节点 */
    private readonly dictNodes = new Map<string, cc.Node>();
    /** 可重复节点，用于多语言节点 */
    private readonly multiDictNodes = new MultiMap<string, cc.Node>();
    /** 是否已加载节点 */
    private isLoaded = false;

    /** 自动加载Node集合 */
    @property({
        type: [cc.Node],
        readonly: true,
        visible: false,
        tooltip: CC_DEV && '自动加载Node集合',
    })
    autoNodes: cc.Node[] = [];

    /** 手动添加Node集合 */
    @property({
        type: [cc.Node],
        visible: true,
        tooltip: CC_DEV && '手动添加Node集合',
    })
    manualNodes: cc.Node[] = [];

    @property({
        tooltip: CC_DEV && '检查是否存在重复资源引用',
        override: true,
        visible: false,
    })
    get check() {
        this.checkNodeRepeatKey(this.autoNodes.concat(this.manualNodes));
        return 0;
    }

    onFocusInEditor() {
        if (CC_EDITOR) {
            this.autoLoadNode();
        }
    }

    onLostFocusInEditor() {
        if (CC_EDITOR) {
            this.autoLoadNode();
        }
    }

    protected onLoad() {
        if (this.isLoaded) {
            return;
        }
        this.autoLoadNode();
    }

    start() {
        if (CC_EDITOR) {
            this.autoLoadNode();
        }
    }

    /** 绑定视图 */
    public bindTo(o: object): void {
        const __ccbind__ = <object>o['__ccbind__'];
        if (!__ccbind__) {
            return;
        }

        const __cclinkname__ = <object>o['__cclinkname__'] || {};

        for (const k of Object.keys(__ccbind__)) {
            o[k] = this.get(__cclinkname__[k] || k, __ccbind__[k]);
        }
    }

    /** 卸载视图 */
    public unBindTo(o: object): void {
        const __ccbind__ = <object>o['__ccbind__'];
        if (!__ccbind__) {
            return;
        }
        for (const k of Object.keys(__ccbind__)) {
            o[k] = null;
        }
    }

    /** 绑定子视图 */
    public convertTo<T extends object>(CLASS: new () => T): T {
        const o = new CLASS();
        this.bindTo(o);
        return o;
    }

    /**
     * 节点是否存在
     * @param key 节点名
     * @returns
     */
    public has(key: string): boolean {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        return this.dictNodes.has(key);
    }

    /** 获取节点资源 */
    public get<T>(key: string, component?: new () => T): T {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        const v = this.dictNodes.get(key);
        if (!v) {
            // 取消日志上报，因为不同皮肤相同功能点可能不存在不同节点收集，所以收集节点为空是正常的
            // we.warn(`WEUIViewCollector get, node is null, key: ${key}`);
            return null;
        }

        // @ts-ignore
        if (component && component !== cc.Node) {
            return v.getComponent(component) as T;
        }

        return v as T;
    }

    public gets<T>(key: string, component?: new () => T): T[] {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        const v = this.multiDictNodes.get(key);
        if (!v) {
            return null;
        }

        // @ts-ignore
        if (component && component !== cc.Node) {
            return v
                .map((item) => {
                    return item.getComponent(component) as T;
                })
                .filter((item) => {
                    return item !== null;
                });
        }

        return v as T[];
    }

    /** 获取节点资源 */
    public getsByReg<T>(reg: RegExp, component?: new () => T): T[] {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        const results: T[] = [];
        this.allNodes.forEach((item) => {
            if (reg.test(item.name)) {
                // @ts-ignore
                if (component && component !== cc.Node) {
                    results.push(item.getComponent(component) as T);
                } else {
                    results.push(item as T);
                }
            }
        });

        return results;
    }

    private checkNodeRepeatKey(dictArray: cc.Node[]) {
        if (!dictArray || dictArray.length === 0) {
            return;
        }
        const keys = new Set<string>();
        for (let i = 0; i < dictArray.length; i++) {
            if (!dictArray[i]) {
                continue;
            }

            const bRegex = this.isValidVariableName(dictArray[i].name);
            if (bRegex == false) {
                cc.error(`WEUIViewCollector checkNodeRepeatKey, name: ${dictArray[i].name}, node name error`);
                continue;
            }

            let nodeName = dictArray[i].name;
            if (keys.has(nodeName) && !nodeName.startsWith('LANG_')) {
                cc.warn(`WEUIViewCollector checkNodeRepeatKey, name: ${dictArray[i].name}, node name repeat`);
                continue;
            }
            keys.add(dictArray[i].name);
        }
    }

    private autoLoadNode() {
        this.isLoaded = true;
        this.dictNodes.clear();
        this.multiDictNodes.clear();

        this.autoNodes = [];
        this.loadNode(this.node, '', (node) => {
            if (this.isRequireNode(node.name)) {
                this.autoNodes.push(node);
            }
            if (this.isBreakLoadNode(node.name)) {
                return false;
            }
            return true;
        });

        for (const node of this.autoNodes) {
            if (!cc.isValid(node)) {
                continue;
            }
            this.dictNodes.set(node.name, node);
            this.multiDictNodes.add(node.name, node);
        }

        for (const node of this.manualNodes) {
            if (!cc.isValid(node)) {
                continue;
            }
            this.dictNodes.set(node.name, node);
        }

        this.allNodes = this.autoNodes.concat(this.manualNodes);
    }

    private loadNode(root: cc.Node, path, handler: (node: cc.Node) => boolean) {
        for (let i = 0; i < root.children.length; i++) {
            const c = handler(root.children[i]);
            if (!c) {
                continue;
            }

            this.loadNode(root.children[i], `${path}${root.children[i].name}/`, handler);
        }
    }

    /**
     * 是否是需要自动Load的节点
     * @param nodeName
     * @returns
     */
    private isRequireNode(nodeName: string) {
        for (const prefix of WEUIViewCollector.autoLoadNodePrefix) {
            if (nodeName.startsWith(prefix)) {
                return true;
            }
        }

        for (const prefix of WEUIViewCollector.autoLoadNodeSuffix) {
            if (nodeName.endsWith(prefix)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 是否中断收集节点
     * @param nodeName
     */
    private isBreakLoadNode(nodeName: string) {
        for (const prefix of WEUIViewCollector.autoBreakLoadNodePrefix) {
            if (nodeName.startsWith(prefix)) {
                return true;
            }
        }

        for (const prefix of WEUIViewCollector.autoBreakLoadNodeSuffix) {
            if (nodeName.endsWith(prefix)) {
                return true;
            }
        }

        return false;
    }

    /** 变量名正则校验 */
    private isValidVariableName(name: string): boolean {
        const regex = /^[a-zA-Z_$][0-9a-zA-Z_$]*$/;
        return regex.test(name);
    }
}

we.ui.WEUIViewCollector = WEUIViewCollector;
