declare global {
    interface IUI {
        /**
         * 绑定节点组件
         * @param componentClass 组件类名
         * @param $childName 组件所在节点名称
         */
        ccComp($componentClass: INewable<cc.Component>, $childName?: string): PropertyDecorator;

        /**
         * 绑定子节点
         */
        ccChild($opt?: ParamType): PropertyDecorator;
    }
}

/**
 * CC组件节点资源收集器
 */
type PropertyDecorator = ($class: Record<string, any>, $propertyKey: string | symbol, $descriptorOrInitializer?: any) => void;

// 所有实现了该接口的类，都可以使用此收集器，自动收集节点资源
export interface IComponentCollector {
    node: cc.Node;
    /** cc 组件 */
    onLoad(): void;
    /** Entity 组件 */
    awake(...args);
}

const searchChild = function (node: cc.Node, name: string) {
    let ret = node.getChildByName(name);
    if (ret) {
        return ret;
    }
    for (let i = 0; i < node.children.length; i++) {
        const child = node.children[i];
        if (!child.isValid) {
            continue;
        }
        ret = searchChild(child, name);
        if (ret) {
            return ret;
        }
    }
    return null;
};

const CookDecoratorKey = ($desc: string) => {
    return `__ccc_decorator_${$desc}__`;
};

const KeyChild = CookDecoratorKey('child_cache');
interface ParamType {
    name?: string;
}

function appendElement($target) {
    const oldOnLoad: () => void = $target.onLoad || undefined; // $target.onLoad也可以拿到父类的实现
    $target.onLoad = function () {
        const cacheChild: Array<{ propertyKey: string; childName: string }> = ($target[KeyChild] ??= []);
        // eslint-disable-next-line no-return-assign
        cacheChild.forEach(($vo) => {
            return (this[$vo.propertyKey] = searchChild(this.node, $vo.childName));
        });
        const cacheComp: Array<{
            propertyKey: string;
            compClass: INewable<cc.Component>;
            childName: string;
        }> = ($target[KeyComp] ??= []);
        cacheComp.forEach(($vo) => {
            const node = $vo.childName ? searchChild(this.node, $vo.childName) : this.node;
            if (!node) {
                we.log(`WECompCollector onLoad, ccComp not found node:${$target.name}`);
                return;
            }
            this[$vo.propertyKey] = node.getComponent($vo.compClass) || node.addComponent($vo.compClass);
        });
        oldOnLoad && oldOnLoad.apply(this);
    };

    const oldAwake: () => void = $target.awake || undefined;
    $target.awake = function (...args) {
        const uiRoot = args[0];
        if (uiRoot && cc.isValid(uiRoot)) {
            const cacheChild: Array<{ propertyKey: string; childName: string }> = ($target[KeyChild] ??= []);
            // eslint-disable-next-line no-return-assign
            cacheChild.forEach(($vo) => {
                return (this[$vo.propertyKey] = searchChild(uiRoot, $vo.childName));
            });
            const cacheComp: Array<{
                propertyKey: string;
                compClass: INewable<cc.Component>;
                childName: string;
            }> = ($target[KeyComp] ??= []);
            cacheComp.forEach(($vo) => {
                const node = $vo.childName ? searchChild(uiRoot, $vo.childName) : uiRoot;
                if (!node) {
                    we.log(`WECompCollector awake, ccComp not found node:${$target.name}`);
                    return;
                }
                this[$vo.propertyKey] = node.getComponent($vo.compClass) || node.addComponent($vo.compClass);
            });
        }

        oldAwake && oldAwake.apply(this, args);
    };
}

export function ccChild($opt?: ParamType): PropertyDecorator {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return ($target, $propertyKey: string, $descriptorOrInitializer) => {
        const cache: Array<{ propertyKey: string; childName: string }> = ($target[KeyChild] ??= []);
        if (
            !cache.some(($vo) => {
                return $vo.propertyKey === $propertyKey;
            })
        ) {
            cache.push({
                propertyKey: $propertyKey,
                childName: $opt?.name || $propertyKey,
            });
        } else {
            we.log(`WECompCollector ccChild, repead bind property key: ${$propertyKey}，class: ${$target.name}`);
            return;
        }
        if (cache.length === 1) {
            appendElement($target);
        }
    };
}

we.ui.ccChild = ccChild;

type INewable<T = any> = new (...args: any[]) => T;

const KeyComp = CookDecoratorKey('comp_cache');

export function ccComp($componentClass: INewable<cc.Component>, $childName?: string): PropertyDecorator {
    return ($target, $propertyKey: string, $descriptorOrInitializer) => {
        const cache: Array<{
            propertyKey: string;
            compClass: INewable<cc.Component>;
            childName: string;
        }> = ($target[KeyComp] ??= []);
        if (
            !cache.some(($vo) => {
                return $vo.propertyKey === $propertyKey;
            })
        ) {
            cache.push({
                propertyKey: $propertyKey,
                compClass: $componentClass,
                childName: $childName || $propertyKey,
            });
        } else {
            we.log(`WECompCollector ccComp, repead bind property key: ${$propertyKey}，class: ${$target.name}`);
            return;
        }
        if (cache.length === 1) {
            appendElement($target);
        }
    };
}

we.ui.ccComp = ccComp;
