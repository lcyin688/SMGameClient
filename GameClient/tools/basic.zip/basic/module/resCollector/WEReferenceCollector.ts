import { MultiMap } from '../algorithms/MultiMap';

const { ccclass, property, executeInEditMode, menu, executionOrder } = cc._decorator;

declare global {
    interface IUI {
        /**
         * 资源收集器
         */
        WEReferenceCollector: typeof WEReferenceCollector;
        /**
         * 通过装饰器标记节点绑定
         * @param TYPE 绑定节点类型（Node, SpriteFrame、自定义组件等）
         * @param nodeAlias 节点别名，对象属性名和节点名不一致时，标记节点中的名字，建立关联
         */
        ccBind: typeof ccBind;
    }

    namespace we {
        namespace ui {
            type WEReferenceCollector = InstanceType<typeof WEReferenceCollector>;
        }
    }
}

/**
 * 通过装饰器标记节点绑定
 * WEReferenceCollector 通过 __ccbind__ 和 __cclinkname__
 * 自动读取节点，通过 convertTo 或者 bindTo 绑定到任意对象类型
 * @param TYPE 绑定节点类型 (Node, SpriteFrame, 自定义组件等)
 * @param nodeAlias 节点别名，对象属性名和节点名不一致时，标记节点中的名字，建立关联
 */
export function ccBind(TYPE: any, nodeAlias?: string) {
    return (target: any, name: string) => {
        target.__ccbind__ = target.__ccbind__ || {};
        target.__ccbind__[name] = TYPE;
        if (nodeAlias) {
            target.__cclinkname__ = target.__cclinkname__ || {};
            target.__cclinkname__[name] = nodeAlias;
        }
    };
}
we.ui.ccBind = ccBind;

/**
 * 节点引用收集器
 */
@ccclass
@executeInEditMode
// 脚本生命周期回调的执行优先级。小于 0 的脚本将优先执行，大于 0 的脚本将最后执行。该优先级只对 onLoad, onEnable, start, update 和 lateUpdate 有效，对 onDisable 和 onDestroy 无效。
@executionOrder(-5001)
@menu('we/other/WEReferenceCollector(节点引用收集器)')
export class WEReferenceCollector extends cc.Component {
    /**
     * 资源收集关注节点前缀
     * RC_:节点及节点下组件收集
     * RCN_:收集当前节点
     * LANG_:多语言节点
     */
    static autoLoadNodePrefix = ['RC_', 'RCN_', 'LANG_'];

    /** 所有节点 */
    private allNodes: cc.Node[] = [];
    /** 不可重复节点 */
    private readonly dictNodes = new Map<string, cc.Node>();
    /** 可重复节点，用于多语言节点 */
    private readonly multiDictNodes = new MultiMap<string, cc.Node>();
    /** 是否已加载节点 */
    private isLoaded = false;
    /** spriteFrame资源 */
    private readonly dictSpriteFrames = new Map<string, cc.SpriteFrame>();
    /** prefab资源 */
    private readonly dictPrefabs = new Map<string, cc.Prefab>();
    /** material资源 */
    private readonly dictMaterials = new Map<string, cc.Material>();
    /** json资源 */
    private readonly dictJsons = new Map<string, cc.JsonAsset>();
    /** 骨骼资源 */
    private readonly dictSkeletonData = new Map<string, sp.SkeletonData>();
    /** 字体资源 */
    private readonly dictFonts = new Map<string, cc.Font>();

    /** 手动添加Node集合 */
    @property({
        type: [cc.Node],
        tooltip: CC_DEV && '手动添加Node集合',
    })
    dictArray: cc.Node[] = [];

    /** 自动加载Node集合 */
    @property({
        type: [cc.Node],
        readonly: true,
        tooltip: CC_DEV && '自动加载Node集合',
        visible: false,
    })
    dictArrayAuto: cc.Node[] = [];

    @property({
        type: [cc.SpriteFrame],
        tooltip: CC_DEV && 'SpriteFrame集合',
    })
    dictSpriteFrameArray: cc.SpriteFrame[] = [];

    @property({
        type: [cc.Prefab],
        tooltip: CC_DEV && 'Prefab集合',
    })
    dictPrefabArray: cc.Prefab[] = [];

    @property({
        type: [cc.Material],
        tooltip: CC_DEV && 'Material集合',
    })
    dictMaterialArray: cc.Material[] = [];

    @property({
        type: [cc.JsonAsset],
        tooltip: CC_DEV && 'JsonAsset集合',
    })
    dictJsonAssetArray: cc.JsonAsset[] = [];

    @property({
        type: [cc.Font],
        tooltip: CC_DEV && 'Font集合',
    })
    fontAssetArray: cc.Font[] = [];

    @property({
        type: [sp.SkeletonData],
        tooltip: CC_DEV && 'Spine集合',
    })
    skeletonDataArray: sp.SkeletonData[] = [];

    @property({
        tooltip: CC_DEV && '检查是否存在重复资源引用',
        override: true,
        visible: false,
    })
    get check() {
        this.checkNodeRepeatKey(this.dictArray.concat(this.dictArrayAuto));
        this.checkResRepeatKey(cc.SpriteFrame);
        this.checkResRepeatKey(cc.Prefab);
        return 0;
    }

    onFocusInEditor() {
        if (CC_EDITOR) {
            this.autoLoadNode();
        }
    }

    onLostFocusInEditor() {
        if (CC_EDITOR) {
            this.autoLoadNode();
        }
    }

    protected onLoad(): void {
        if (this.dictArrayAuto.length) {
            return;
        }

        this.autoLoadNode();
    }

    start() {
        if (CC_EDITOR) {
            this.autoLoadNode();
        }
    }

    /** 绑定视图 */
    public bindTo(o: object): void {
        const __ccbind__ = <object>o['__ccbind__'];
        if (!__ccbind__) {
            return;
        }

        const __cclinkname__ = <object>o['__cclinkname__'] || {};

        for (const k of Object.keys(__ccbind__)) {
            o[k] = this.get(__cclinkname__[k] || k, __ccbind__[k]);
        }
    }

    /** 卸载视图 */
    public unBindTo(o: object): void {
        const __ccbind__ = <object>o['__ccbind__'];
        if (!__ccbind__) {
            return;
        }
        for (const k of Object.keys(__ccbind__)) {
            o[k] = null;
        }
    }

    /** 绑定子视图 */
    public convertTo<T extends object>(CLASS: new () => T): T {
        const o = new CLASS();
        this.bindTo(o);
        return o;
    }

    /**
     * 节点是否存在
     * @param key 节点名
     * @returns
     */
    public has(key: string): boolean {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        return this.dictNodes.has(key);
    }

    /** 获取节点资源 */
    public get<T>(key: string, component?: new () => T): T {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        const v = this.dictNodes.get(key);
        if (!v) {
            // 取消日志上报，因为不同皮肤相同功能点可能不存在不同节点收集，所以收集节点为空是正常的
            // we.warn(`WEReferenceCollector get, node is null, key: ${key}`);
            return null;
        }

        // @ts-ignore
        if (component && component !== cc.Node) {
            return v.getComponent(component) as T;
        }

        return v as T;
    }

    public gets<T>(key: string, component?: new () => T): T[] {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        const v = this.multiDictNodes.get(key);
        if (!v) {
            return null;
        }

        // @ts-ignore
        if (component && component !== cc.Node) {
            return v
                .map((item) => {
                    return item.getComponent(component) as T;
                })
                .filter((item) => {
                    return item !== null;
                });
        }

        return v as T[];
    }

    /** 获取节点资源 */
    public getsByReg<T>(reg: RegExp, component?: new () => T): T[] {
        if (!this.isLoaded) {
            this.autoLoadNode();
        }

        const results: T[] = [];
        this.allNodes.forEach((item) => {
            if (reg.test(item.name)) {
                // @ts-ignore
                if (component && component !== cc.Node) {
                    results.push(item.getComponent(component) as T);
                } else {
                    results.push(item as T);
                }
            }
        });

        return results;
    }

    /** 获取挂载资源 */
    public getRes<T>(key: string, type: any): T {
        const resDicst: any = this.getResDict(type);
        if (resDicst.size === 0) {
            this.initResDicts(type);
        }

        const v = resDicst.get(key);
        if (!v) {
            cc.warn('WEReferenceCollector getRes, key not find', key);
            return null;
        }

        return v as T;
    }

    private checkNodeRepeatKey(dictArray: cc.Node[]) {
        if (!dictArray || dictArray.length === 0) {
            return;
        }
        const keys = new Set<string>();
        for (let i = 0; i < dictArray.length; i++) {
            if (!dictArray[i]) {
                continue;
            }

            let bRegex = this.isValidVariableName(dictArray[i].name);
            if (bRegex == false) {
                cc.warn(`WEReferenceCollector checkNodeRepeatKey, Node name ${dictArray[i].name} improper naming can lead to errors in generated `);
                continue;
            }

            let nodeName = dictArray[i].name;
            if (keys.has(nodeName) && !nodeName.startsWith('LANG_')) {
                cc.warn(`WEReferenceCollector checkNodeRepeatKey, Node name ${dictArray[i].name} repeat，please check node ${this.node.name} naming`);
                continue;
            }
            keys.add(dictArray[i].name);
        }
    }

    private getResDict(type: any) {
        let resDicts: any;
        switch (type) {
            case cc.SpriteFrame:
                resDicts = this.dictSpriteFrames;
                break;
            case cc.Prefab:
                resDicts = this.dictPrefabs;
                break;
            case cc.Material:
                resDicts = this.dictMaterials;
                break;
            case cc.JsonAsset:
                resDicts = this.dictJsons;
                break;
            case cc.Font:
                resDicts = this.dictFonts;
                break;
            case sp.SkeletonData:
                resDicts = this.dictSkeletonData;
                break;
            default:
                break;
        }
        return resDicts;
    }

    private getResArray(type: any) {
        let resArray: any;
        switch (type) {
            case cc.SpriteFrame:
                resArray = this.dictSpriteFrameArray;
                break;
            case cc.Prefab:
                resArray = this.dictPrefabArray;
                break;
            case cc.Material:
                resArray = this.dictMaterialArray;
                break;
            case cc.JsonAsset:
                resArray = this.dictJsonAssetArray;
                break;
            case cc.Font:
                resArray = this.fontAssetArray;
                break;
            case sp.SkeletonData:
                resArray = this.skeletonDataArray;
                break;
            default:
                break;
        }

        return resArray;
    }

    private initResDicts(type: any) {
        const resDicts: any = this.getResDict(type);
        const resArray: any = this.getResArray(type);
        for (const res of resArray) {
            if (!res) {
                continue;
            }
            resDicts.set(
                res.name ||
                    res.data?.name ||
                    // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                    res.effectName.substring(res.effectName.lastIndexOf('/') + 1), // Material材质文件
                res
            );
        }
    }

    private checkResRepeatKey(type: any) {
        const resArray = this.getResArray(type);
        if (!resArray || resArray.length === 0) {
            return;
        }

        const keys = new Set<string>();
        for (let i = 0; i < this.dictSpriteFrameArray.length; i++) {
            if (!this.dictSpriteFrameArray[i]) {
                continue;
            }

            if (keys.has(this.dictSpriteFrameArray[i].name)) {
                cc.warn(`WEReferenceCollector checkResRepeatKey, ${type.name} res ${this.dictSpriteFrameArray[i].name} repeat add`);
                continue;
            }
            keys.add(this.dictSpriteFrameArray[i].name);
        }
    }

    private autoLoadNode() {
        this.isLoaded = true;
        this.dictNodes.clear();
        this.multiDictNodes.clear();

        this.dictArrayAuto = [];
        this.loadNode(this.node, '', (node) => {
            if (node.getComponent(WEReferenceCollector)) {
                if (this.isRequireNode(node.name)) {
                    this.dictArrayAuto.push(node);
                }
                return false;
            }
            if (this.isRequireNode(node.name)) {
                this.dictArrayAuto.push(node);
            }
            return true;
        });

        for (const node of this.dictArray) {
            if (!cc.isValid(node)) {
                continue;
            }
            this.dictNodes.set(node.name, node);
            this.multiDictNodes.add(node.name, node);
        }

        for (const node of this.dictArrayAuto) {
            if (!cc.isValid(node)) {
                continue;
            }
            this.dictNodes.set(node.name, node);
        }

        this.allNodes = this.dictArray.concat(this.dictArrayAuto);
    }

    private loadNode(root: cc.Node, path, handler: (node: cc.Node) => boolean) {
        for (let i = 0; i < root.children.length; i++) {
            const c = handler(root.children[i]);
            if (!c) {
                continue;
            }

            this.loadNode(root.children[i], `${path}${root.children[i].name}/`, handler);
        }
    }

    /**
     * 是否是需要自动Load的节点
     * @param nodeName
     * @returns
     */
    private isRequireNode(nodeName: string) {
        for (let prefix of WEReferenceCollector.autoLoadNodePrefix) {
            if (nodeName.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }

    /** 变量名正则校验 */
    private isValidVariableName(name: string): boolean {
        const regex = /^[a-zA-Z_$][0-9a-zA-Z_$]*$/;
        return regex.test(name);
    }
}

we.ui.WEReferenceCollector = WEReferenceCollector;
