import { MersenneTwister } from './MersenneTwister';

declare global {
    interface ICore {
        RandomHelper: typeof RandomHelper;
    }
}

enum BOOLEAN {
    TRUE = 1,
    FALSE = 0,
}

class Random {
    mt: MersenneTwister;

    /**
     * 随机数生成器类
     * @param seed - 种子值，可选
     */
    constructor(seed?: number | number[]) {
        this.mt = new MersenneTwister(seed);
    }

    /**
     * 生成随机整数[min, max]
     * @param min - 最小值，默认为Number.MIN_VALUE
     * @param max - 最大值，默认为Number.MAX_VALUE
     * @returns 随机整数
     */
    public next(min?: number, max?: number): number {
        min = min ?? Number.MIN_VALUE;
        max = max ?? Number.MAX_VALUE;
        return Math.floor(this.mt.random() * (max - min + 1) + min);
    }

    /**
     * 生成随机浮点数
     * @param min - 最小值
     * @param max - 最大值
     * @returns 随机浮点数
     */
    public nextFloat(min: number, max: number): number {
        return this.mt.random() * (max - min) + min;
    }

    /**
     * 生成随机布尔值
     * @returns 随机布尔值
     */
    public nextBool(): boolean {
        return this.mt.random() < 0.5;
    }

    /**
     * 从数组中随机选择一个元素
     * @param array - 数组
     * @returns 随机选择的元素
     */
    public nextElement<t>(array: t[]): t | undefined {
        const index = Math.floor(this.mt.random() * array.length);
        return array[index];
    }
}

// 随机字符串类型
export enum RandomStrType {
    // 不带0数字
    number = 1,
    // 带0数值
    number0,
    // a~z字符串
    string,
    // a~z0~9字符串
    mix,
}

const StringNumber = '123456789';
const StringNumber0 = '0123456789';
const StringABC = 'abcdefghijklmnpqrstuvwxyz';
const StringNumberABC = '0123456789abcdefghijklmnpqrstuvwxyz';

export class RandomHelper {
    /**
     * 随机类
     */
    private static random: Random | null = null;

    /**
     * 获取随机对象
     * @returns {Random} 随机对象
     */
    private static get Random(): Random {
        return this.random ?? (this.random = new Random());
    }

    /**
     * 生成整数随机数
     * @returns {number} 整数随机数
     */
    public static randInt32(): number {
        return this.Random.next();
    }

    /**
     * 生成无符号整数随机数
     * @returns {number} 无符号整数随机数
     */
    public static randUInt32(): number {
        return this.Random.next(0);
    }

    /**
     * 生成[min, max]范围内的随机数整数
     * @param min 下限
     * @param max 上限
     * @returns {number} 随机数
     */
    public static randInt(min: number | number[], max?: number): number {
        if (min instanceof Array) {
            max = min[1];
            min = min[0];
        }
        return this.Random.next(min, max);
    }

    /**
     * 生成浮点随机数
     * @param min 下限
     * @param [max] 上限
     * @returns {number} 随机数
     */
    public static randFloat(min: number | number[], max?: number): number {
        if (min instanceof Array) {
            max = min[1];
            min = min[0];
        }

        return this.Random.nextFloat(min, max);
    }

    /**
     * 生成布尔随机值
     * @returns {boolean} 布尔随机值
     */
    public static randBool(): boolean {
        return this.Random.nextBool();
    }

    /**
     * 随机数组元素
     * @param array 数组
     * @returns {T} 随机数组元素
     */
    public static randArray<T>(array: T[]): T | undefined {
        return this.Random.nextElement(array);
    }

    /**
     * 从数组中随机选择n个不同的元素
     * @param array 源数组
     * @param count 选择元素个数
     * @returns {T[]} 选择的元素数组
     */
    public static randomNDistinct<T>(array: T[], count: number): T[] {
        if (array.length < count) {
            throw new Error('Cannot select more distinct elements than there are in the array');
        }

        const selection: T[] = [];
        const indices: number[] = array.map((_, i) => {
            return i;
        });

        for (let i = 0; i < count; i++) {
            const index = this.Random.next(i, indices.length - 1);
            selection[i] = array[indices[index]];
            indices[index] = indices[i];
        }

        return selection;
    }

    /**
     * 随机打乱数组
     * @param arr 数组
     * @returns {T[]} 打乱顺序的数组
     */
    public static breakRank<T>(arr: T[]): T[] {
        if (arr == null || arr.length < 2) {
            return;
        }

        for (let i = 0; i < arr.length; i++) {
            const index = this.Random.next(0, arr.length - 1);
            [arr[index], arr[i]] = [arr[i], arr[index]];
        }

        return arr;
    }

    /**
     * 从数组中随机获取num个元素
     * @param arr 源数组
     * @param num 要获取的数量
     * @param repeat 获取的元素是否可以重复，true：可重复（同一位置的元素可能被多次获取） false：不可重复（同一位置的元素不会被多次获取）
     * @returns T[] 获取的元素数组
     */
    public static randArrays<T>(arr: T[], num: number, repeat = false): T[] {
        if (arr.length === 0 || num === 0) {
            return [];
        }
        if (!repeat && arr.length < num) {
            throw new Error('array length less than num');
        }
        if (arr.length === num) {
            return arr;
        }
        const newArray = [];
        while (newArray.length < num) {
            const rand = this.random.next(0, arr.length - 1);
            if (repeat || !newArray.includes(rand)) {
                newArray.push(rand);
            }
        }
        return newArray.map((item) => {
            return arr[item];
        });
    }

    /**
     * 通过权重模型从数组中随机获取num个元素
     * @param arr 源数组，其中的权重最大支持两位小数
     * @param num 要获取的数量
     * @param repeat 获取的元素是否可以重复，true：可重复（同一位置的元素可能被多次获取） false：不可重复（同一位置的元素不会被多次获取）
     * @returns T[] 获取的元素数组
     */
    public static randomArraysByWeight<T extends { weight: number }>(arr: T[], num: number, repeat = false): T[] {
        if (arr.length === 0 || num === 0) {
            return [];
        }
        if (!repeat && arr.length < num) {
            throw new Error('array length less than num');
        }
        if (arr.length === num) {
            return arr;
        }
        const weights = arr.map((x) => {
            return x.weight;
        });
        const newArray = [];
        while (newArray.length < num) {
            const randIndex = this.randWeightIndex(weights);
            if (repeat || !newArray.includes(randIndex)) {
                newArray.push(randIndex);
            }
        }
        return newArray.map((item) => {
            return arr[item];
        });
    }

    /**
     * 通过权重数组随机获取一个元素
     * @param arr 带权重的数组
     * @returns {T} 获取的元素
     */
    public static randomByArrayAndWeight<T extends { weight: number }>(arr: T[]): T {
        return this.randomArraysByWeight<T>(arr, 1)[0];
    }

    /**
     * 通过概率来计算是否命中
     * @param probability 命中概率（百分比的形式，例如89.2%就是89.2）
     * @returns {boolean} 命中结果，true：命中，false：未命中
     */
    public static randomHit(probability: number): boolean {
        return this.randWeightIndex([probability, 100 - probability]) === 0;
    }

    /**
     * 过概率来计算是否命中
     * @param  probability 命中概率（0-1）
     * @return true:命中，false:未命中
     */
    public static randomHitByMaxOne(probability: number): boolean {
        return this.randWeightIndex([probability, 1 - probability]) === 0;
    }

    /**
     * 通过权重随机
     * @param weightArray 权重数组
     * @return 随机到的索引
     */
    public static randWeightIndex(weightArray: number[]): number {
        if (!weightArray || weightArray.length === 0) {
            return -1;
        }
        const range = [];
        const total = weightArray.reduce((pre, item) => {
            range.push(pre + item);
            return pre + item;
        }, 0);

        if (total === 0) {
            return -1;
        }
        const rnd = Math.random() * total;

        let rndIndex = -1;
        for (let i = 0; i < range.length; i++) {
            if (range[i] !== 0 && range[i] >= rnd) {
                rndIndex = i;
                break;
            }
        }
        return rndIndex;
    }

    /**
     * 生成随机字符串
     * @param length
     * @param randType
     * @returns {string}
     */
    public static randomString(length: number, randType: RandomStrType) {
        let str = 'abcdefghijklmnpqrstuvwxyz123456789';
        if (typeof randType === 'number') {
            switch (randType) {
                case RandomStrType.number:
                    str = StringNumber;
                    break;
                case RandomStrType.number0:
                    str = StringNumber0;
                    break;
                case RandomStrType.string:
                    str = StringABC;
                    break;
                default:
                    str = StringNumberABC;
                    break;
            }
        }
        const maxPos = str.length;
        let code = '';
        for (let i = 0; i < length; i++) {
            const txt = str.charAt(Math.floor(Math.random() * maxPos));
            code += txt;
        }
        return code;
    }
}

we.core.RandomHelper = RandomHelper;
