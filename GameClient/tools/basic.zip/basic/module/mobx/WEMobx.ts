/* eslint-disable prefer-rest-params */
import {
    IReactionDisposer,
    IReactionPublic,
    action as Action,
    computed as Computed,
    observable as Observable,
    autorun as Autorun,
    configure as Configure,
    makeAutoObservable as MakeAutoObservable,
    makeObservable as MakeObservable,
    reaction as Reaction,
    observe as Observe,
    comparer as Comparer,
    runInAction as RunInAction,
    trace as Trace,
    IReactionOptions,
} from 'mobx';
import 'reflect-metadata';

declare global {
    interface IWe {
        mobx: typeof Mobx;
        mobxHelper: typeof MobxHelper;
    }
}

// observe 无法满足对嵌套对象的监听，一般不使用
// observable 使用makeAutoObservable, makeObservable替代

// mobx 相关配置
Configure({
    /**
     * "observed" (默认值): 可观察状态必须通过actions来修改。 这是默认选项，对于有一定复杂度的应用来说这是推荐的严格模式。
     *  "never": 状态可以在任何地方被修改。
     *  "always": 任何状态都能只能通过actions来修改，在实际开发中也包括新建状态。
     */
    enforceActions: 'never',
    /**
     * "always" (默认值): MobX 只能运行在支持 Proxy的环境中，如果环境不支持 Proxy 将报错。
     *  "never": Proxy将不会被使用，MobX降级到non-proxy替代方案。 兼容 ES5 环境， 但是会带来一些限制 limitations.
     *  "ifavailable" (实验阶段): 如果环境支持则启用 Proxy，否则 降级到non-proxy替代方案。
     *  这个模式的优势是:MobX将对不能在ES5环境中使用的API以及语言特性发出警告，触发ES5标准限制时抛出错误。
     */
    useProxies: 'never',
});

interface IStoreCache {
    __disposer: IReactionDisposer[];
    __reaction?: string[];
    __autorun?: string[];
    name: string;
}

const autorunMap = new WeakMap<object, Set<string>>();
const reactionMap = new WeakMap<object, Set<string>>();
const disposerMap = new WeakMap<object, Array<Function>>();

function getAllFuncKeys(funcKeyMap: WeakMap<object, Set<string>>, target: any): Set<string> {
    const keys = new Set<string>();
    let proto = Object.getPrototypeOf(target);

    while (proto && proto !== Object.prototype) {
        const protoKeys = funcKeyMap.get(proto);
        if (protoKeys) {
            for (const key of protoKeys) {
                keys.add(key);
            }
        }
        proto = Object.getPrototypeOf(proto);
    }

    // 自身 prototype 上的也查一下
    const selfKeys = funcKeyMap.get(target);
    if (selfKeys) {
        for (const key of selfKeys) {
            keys.add(key);
        }
    }

    return keys;
}

function setFuncKey(funcKeyMap: WeakMap<object, Set<string>>, prototype: any, key: string) {
    if (!funcKeyMap.has(prototype)) {
        funcKeyMap.set(prototype, new Set());
    }
    funcKeyMap.get(prototype).add(key);
}

function getDisposer(target: any) {
    return disposerMap.get(target);
}

function setDisposer(target: any, disposers: Array<Function>) {
    disposerMap.set(target, disposers);
}

class MobxHelper {
    /**
     * 开始ob
     */
    public static observe(system: any & IStoreCache, self?: object & IStoreCache) {
        const __disposer = getDisposer(system) ?? [];
        if (__disposer?.length) {
            return;
        }

        const __autorun = getAllFuncKeys(autorunMap, system);
        const __reaction = getAllFuncKeys(reactionMap, system);
        if (__autorun) {
            for (const fn of __autorun) {
                const view = (system as any)[fn]?.bind(system);
                if (!view) {
                    continue;
                }

                const disposer = Autorun(
                    (r) => {
                        if (system?.IsDisposed) {
                            disposer();
                            return;
                        }
                        if (self) {
                            view(self, r);
                        } else {
                            view(r);
                        }
                    },
                    { name: self?.name ?? system.name ?? system?.constructor?.name + '#' + fn }
                );
                __disposer.push(disposer);
            }
        }

        if (__reaction) {
            for (let fn of __reaction) {
                const disposer = (system as any)[fn]?.bind(system)(self);
                if (!disposer) {
                    continue;
                }
                __disposer.push(disposer);
            }
        }

        setDisposer(system, __disposer);
    }

    /**
     * 结束ob
     */
    public static dispose(system: any & IStoreCache, self?: object & IStoreCache) {
        const __disposer = getDisposer(system);
        if (!__disposer) {
            return;
        }

        if (__disposer.length) {
            __disposer.splice(0).forEach((desposer) => {
                return desposer?.();
            });
        }
    }

    /**
     * 创建Observable Store
     * @param Store
     * @param args
     * @returns
     */
    // @ts-ignore
    public static createObservable<T extends new (...args: any[]) => any>(ObservableStore: T, ...args: ConstructorParameters<T>): T['prototype'] {
        let store = new ObservableStore(...args);
        MakeAutoObservable(store);
        return store;
    }

    public static reactorArg3(target: any, key: string, _: TypedPropertyDescriptor<(self: object) => IReactionDisposer>) {
        setFuncKey(reactionMap, target, key);
    }

    public static reactorArg1<T>(expression: (r: IReactionPublic) => T) {
        return (target: any, key: string, descriptor: TypedPropertyDescriptor<(arg: T) => void>) => {
            setFuncKey(reactionMap, target, key);

            const value = descriptor.value as (arg: T) => void;
            descriptor.value = function () {
                return Reaction(expression, value.bind(this), { fireImmediately: true });
            };
        };
    }
}
we.mobxHelper = MobxHelper;

namespace Mobx {
    /**
     * 配置Store
     * @param options
     */
    export function setConfigure(options: {
        enforceActions?: 'never' | 'always' | 'observed';
        computedRequiresReaction?: boolean;
        /**
         * Warn if you try to create to derivation / reactive context without accessing any observable.
         */
        reactionRequiresObservable?: boolean;
        /**
         * Warn if observables are accessed outside a reactive context
         */
        observableRequiresReaction?: boolean;
        isolateGlobalState?: boolean;
        disableErrorBoundaries?: boolean;
        safeDescriptors?: boolean;
        reactionScheduler?: (f: () => void) => void;
        useProxies?: 'always' | 'never' | 'ifavailable';
    }) {
        Configure(options);
    }

    /**
     * 在constructor中执行makeObservable(this)，自动将类的实例转换成可观察对象
     */
    export const makeObservable = MakeObservable;
    /**
     * 在constructor中执行makeAutoObservable(this)，自动将类的实例转换成可观察对象
     * 参数1:Store对象
     * 参数2:排除属性和方法,{reset:false}
     */
    export const makeAutoObservable = MakeAutoObservable;
    /**
     * 注解多实例的类, 会将 Render 和 Reactor 所注解的方法 纳入生命周期来管理
     */
    export const observer = <T extends new (...args: any[]) => any>(Constructor: T) => {
        return class extends Constructor {
            __disposer: IReactionDisposer[] = [];

            constructor(...args: any[]) {
                super(...args);
                MobxHelper.observe(this);
            }
            /**
             * 兼容带有onLoad/onDestroy生命周期的类
             */
            public onLoad() {
                if (super.onLoad && super.onLoad()) {
                    return;
                }
                setDisposer(this, []);
                MobxHelper.observe(this);
            }

            public onDestroy() {
                MobxHelper.dispose(this);
                if (super.onDestroy) {
                    super.onDestroy();
                }
            }

            /**
             * 兼容带有awake/dispose生命周期的类
             */
            public awake() {
                if (super.awake) {
                    super.awake();
                }
                setDisposer(this, []);
                MobxHelper.observe(this);
            }

            public dispose() {
                MobxHelper.dispose(this);
                if (super.dispose) {
                    super.dispose(...Array.prototype.slice.call(arguments, 0));
                }
            }
        };
    };

    /**
     * 如果不通过Observer控制Store生命周期
     * 则通过自主在自己的生命周期函数上手动挂载Enable,启动Store监听
     * @returns
     */
    export function enable(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
        const originalMethod = descriptor.value;
        descriptor.value = function (...args: any[]) {
            originalMethod.apply(this, args);
            MobxHelper.observe(this);
        };
    }

    /**
     * 如果不通过Observer控制Store生命周期
     * 则通过自主在自己的生命周期函数上手动挂载Disable，关闭Store监听
     * @returns
     */
    export function disable(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
        const originalMethod = descriptor.value;
        descriptor.value = function (...args: any[]) {
            MobxHelper.dispose(this);
            originalMethod.apply(this, args);
        };
    }

    /**
     * 具备修改Store的权限
     * @action.bound 自动绑定上下文
     */
    export const action = Action;
    /**
     * 标记方法为计算通过其他值，计算一个结果，不保存数据
     */
    export const computed = Computed;
    export const observe = Observe;
    export const comparer = Comparer;
    /**
     * 标记为可观察对象
     * - observable.deep @observable 默认装饰器， 复杂嵌套数据,递归所有层级,性能影响较大
     * - observable.struct 仅在新值与旧值结构不同时触发更新（通过深度比较结构而非引用），避免不必要的渲染
     * - observable.shallow 仅观察集合（数组、Map、Set）的第一层结构变化，不递归处理内部元素
     * - observable.box 将原始值（如 number、string、boolean）包装成一个可观察的“盒子”
     * - observable.array 将数组转换为可观察数组，自动追踪元素的增删和替换,需要响应式处理数组结构变化（push、pop、splice 等）
     * - observable.map 将 ES6 Map 转换为可观察的键值对集合
     * - observable.set 将 ES6 Set 转换为可观察的集合
     * - observable.object 将普通对象转换为可观察对象，递归转换所有属性。
     * ### 1.Date 对象需要特别处理
     * let date = new Date();
     * date = observable.box(date);
     * ### 2.集合类型不会自动转换
     * let set = new Set();
     * set = observable.set(this.set);
     * ### 3.等价简写
     * - @observable list: string[] = []; // 等价于 observable.array
     * - @observable config = { theme: "dark" }; // 等价于 observable.object
     */
    export const observable = Observable;

    /**
     * 用来渲染
     * ```
     * ```
     * 注解的方法会在 onLoad/awake执行之后自动调用一次, 并在关注的数据发生变化的时候执行
     * ```
     * ```
     * 注意: 此注解永远只关心最新值，如果需要关心旧值请使用 ‎@we.mobx.reactor
     */
    export const render = (target: any, key: string, _: TypedPropertyDescriptor<() => void>) => {
        setFuncKey(autorunMap, target, key);
    };

    /**
     * 调试追踪【todo待尝试】
     */
    export const trace = Trace;

    /**
     * 创建时，会先执行一次
     * ```
     * Autorun(() => {
     *  console.log("counter.count", counterStore.count)
     * })
     * ```
     */
    export const autorun = Autorun;

    /**
     * 异步的使用：async/await + runInAction的配合使用
     * 来确保异步操作的结果能够正确地触发 Reaction
     */
    export const runInAction = RunInAction;

    /**
     * 使用示例：
     * ```javascript
     * ‎we.mobx.reactor
     * protected betChange() {
     *    return we.mobx.reaction(
     *        () => {
     *            return SlotModel.Inst.store.bet;
     *        },
     *        (newValue, oldValue) => {
     *            if (oldValue == 0) return;
     *            oldValue < newValue && we.core.audioMgr.playEffect(Comslotv2ResConfig.audio.slot_rec_bet);
     *            oldValue > newValue && we.core.audioMgr.playEffect(Comslotv2ResConfig.audio.slot_inc_bet);
     *        }
     *    );
     * }
     * ```
     * 和reactor搭配进行副作用操作
     * 创建时，不执行，变化时，才执行
     * fireImmediately:确保初始化时处理已有数据
     */
    export function reaction<T>(expression: (r: IReactionPublic) => T, effect: (arg: T, pre: T, r: IReactionPublic) => void, opts?: IReactionOptions<T, boolean>): IReactionDisposer {
        return Reaction(expression, effect, opts ?? { fireImmediately: true });
    }
    /**
     * 1.map 使用实例：
     * ```javascript
     * ‎@we.mobx.reactor
     *   protected handlePlayerUnit() {
     *       return we.mobx.reaction(
     *           () => {
     *               return Array.from(AirfighterRoomModel.Inst.playerUnits.keys());
     *           },
     *           (currentKeys: we.combase.type.SEAT_ID[], oldKeys: we.combase.type.SEAT_ID[]) => {
     *               const currentSet = new Set(currentKeys);
     *               const oldSet = new Set(oldKeys || []);
     *
     *               const added = currentKeys.filter((key) => {
     *                   return !oldSet.has(key);
     *               });
     *               added.forEach((key) => {
     *               });
     *
     *               const removed = Array.from(oldSet).filter((key) => {
     *                   return !currentSet.has(key);
     *               });
     *               removed.forEach((key) => {=
     *               });
     *           },
     *           {
     *               // 优化点3：使用浅比较避免无效触发
     *               equals: we.mobx.comparer.shallow,
     *               fireImmediately: true,
     *           }
     *       );
     *   }
     * ```
     * 2.使用示例：
     * ```javascript
     * ‎@we.mobx.reactor
     * protected betChange() {
     *    return we.mobx.reaction(
     *        () => {
     *            return SlotModel.Inst.store.bet;
     *        },
     *        (newValue, oldValue) => {
     *            if (oldValue == 0) return;
     *            oldValue < newValue && we.core.audioMgr.playEffect(Comslotv2ResConfig.audio.slot_rec_bet);
     *            oldValue > newValue && we.core.audioMgr.playEffect(Comslotv2ResConfig.audio.slot_inc_bet);
     *        }
     *    );
     * }
     * ```
     * 监听值的变化，当值发生变化是 在 reaction 中的回调会返回新值和旧值
     * ```
     * ```
     * 如果不关心 oldValue 请使用 ‎@we.mobx.render
     * @param target
     * @param key
     * @param descriptor
     */
    export function reactor(target: any, key: string, descriptor: TypedPropertyDescriptor<() => IReactionDisposer>): void;
    /**
     * 使用示例：
     * ```javascript
     * ‎@we.mobx.reactor
     * protected betChange() {
     *    return we.mobx.reaction(
     *        () => {
     *            return SlotModel.Inst.store.bet;
     *        },
     *        (newValue, oldValue) => {
     *            if (oldValue == 0) return;
     *            oldValue < newValue && we.core.audioMgr.playEffect(Comslotv2ResConfig.audio.slot_rec_bet);
     *            oldValue > newValue && we.core.audioMgr.playEffect(Comslotv2ResConfig.audio.slot_inc_bet);
     *        }
     *    );
     * }
     * ```
     *
     * 监听值的变化，当值发生变化是 在 reaction 中的回调会返回新值和旧值
     * ```
     * ```
     * 如果不关心 oldValue 请使用 ‎@we.mobx.render
     * @param expression
     */
    export function reactor<T>(expression: (r: IReactionPublic) => T): (target: any, key: string, descriptor: TypedPropertyDescriptor<(arg: T) => void>) => void;
    export function reactor() {
        if (arguments.length === 3) {
            return MobxHelper.reactorArg3(arguments[0], arguments[1], arguments[2]);
        } else {
            return MobxHelper.reactorArg1(arguments[0]);
        }
    }

    /** 创建数据监听 */
    // @ts-ignore
    export function createStore<T extends new (...args: any[]) => any>(Store: T, ...args: ConstructorParameters<T>): T['prototype'] {
        let store = new Store(...args);
        we.mobx.makeAutoObservable(store);
        return store;
    }
}

we.mobx = Mobx;
