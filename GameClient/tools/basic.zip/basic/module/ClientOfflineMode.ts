import { EventMsg } from '../type/EventType';

declare global {
    interface ICore {
        ClientOfflineMode: typeof ClientOfflineMode;
    }

    namespace we {
        namespace core {
            type ClientOfflineMode = InstanceType<typeof ClientOfflineMode>;
        }
    }
}

/**
 * 客户端离线模式管理器组件
 * 实现离线模式下完游戏不受影响
 */
@we.decorator.typeSingleton('ClientOfflineMode')
export class ClientOfflineMode extends we.core.Entity {
    public static Inst: ClientOfflineMode;
    /**
     * 客户端是否进入离线模式，离线模式状态:
     * 1、禁止任何公共确认弹窗和公共转圈
     * 2、Toast提示
     * 3、不阻止业务弹窗和延时转圈
     */
    private offlineMode: boolean;
    /** 离线模式收集的任务 */
    private offlineTasks: (() => Promise<void>)[];

    protected awake(): void {
        this.offlineMode = false;
        this.offlineTasks = [];

        we.event<EventMsg>().on(
            'OfflineMode',
            (offline) => {
                this.offlineMode = offline;
                we.core.timer.scheduleOnce(2, this).then(() => {
                    we.log(`ClientOfflineMode awake, ${this.offlineMode ? 'enter offline mode' : 'exit offline mode'}`);
                    this.runTask();
                });
            },
            this
        );
    }
    protected destroy(): void {
        this.offlineMode = false;
        we.event().offByTarget(this);
    }

    public get isOfflineMode(): boolean {
        return this.offlineMode;
    }

    public addTask(task: () => Promise<void>): void {
        if (!this.offlineMode) {
            return;
        }

        this.offlineTasks.push(task);
    }

    public reset() {
        this.offlineTasks.length = 0;
    }

    private async runTask() {
        if (this.offlineMode) {
            this.offlineTasks.length = 0;
            return;
        }

        if (this.offlineTasks.length > 0) {
            let tasks = [...this.offlineTasks];
            this.offlineTasks.length = 0;
            // 退出离线模式时，执行任务队列中的任务
            for (let task of tasks) {
                try {
                    await task();
                } catch (_) {}
            }
        }
    }
}

we.core.ClientOfflineMode = ClientOfflineMode;
