import { CoroutineLockKey, type CoroutineLock } from './CoroutineLock';
import { CoroutineLockQueue } from './CoroutineLockQueue';

export class CoroutineLockQueueType {
    private readonly coroutineLockQueues = new Map<CoroutineLockKey, CoroutineLockQueue>();

    constructor(private readonly type: number) {}

    private get(key: CoroutineLockKey): CoroutineLockQueue | undefined {
        return this.coroutineLockQueues.get(key);
    }

    private create(key: CoroutineLockKey): CoroutineLockQueue {
        const queue = CoroutineLockQueue.create(this.type, key);
        this.coroutineLockQueues.set(key, queue);
        return queue;
    }

    private remove(key: CoroutineLockKey, locker: CoroutineLock): void {
        const queue = this.coroutineLockQueues.get(key);
        if (queue) {
            if (queue.recycle(locker)) {
                this.coroutineLockQueues.delete(key);
            }
        }
    }

    /**
     * 等待锁返回
     * @param key
     * @param timeout 单位【秒】
     * @returns
     */
    public async wait(key: CoroutineLockKey, timeout: number, isSafe: boolean): Promise<CoroutineLock> {
        const queue = this.get(key) || this.create(key);
        try {
            return await queue.wait(timeout, isSafe);
        } catch (err) {
            if (queue.count === 0) {
                this.remove(key, null);
            }
            throw err;
        }
    }

    public notify(key: CoroutineLockKey, level: number, locker: CoroutineLock): void {
        const queue = this.get(key);
        if (!queue) {
            return;
        }

        if (queue.count === 0) {
            this.remove(key, locker);
        }

        queue.notify(level);
    }
}
