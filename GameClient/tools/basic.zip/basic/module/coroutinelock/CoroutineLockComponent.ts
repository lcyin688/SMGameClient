import { ISingletonUpdate, Singleton } from '../singleton/Singleton';
import { CoroutineLock, CoroutineLockKey } from './CoroutineLock';
import { CoroutineLockQueueType } from './CoroutineLockQueueType';

declare global {
    interface ICore {
        CoroutineLockComponent: typeof CoroutineLockComponent;
    }

    namespace we {
        namespace core {
            type CoroutineLockComponent = InstanceType<typeof CoroutineLockComponent>;
        }
    }
}

@we.decorator.typeSingleton('CoroutineLockComponent')
export class CoroutineLockComponent extends Singleton implements ISingletonUpdate {
    private readonly dictionary = new Map<number, CoroutineLockQueueType>();
    private readonly nextFrameRun: Array<[number, CoroutineLockKey, number, CoroutineLock]> = [];

    static get Inst() {
        return this.getInstance();
    }

    public dispose(): void {
        this.nextFrameRun.length = 0;
    }

    public update(): void {
        while (this.nextFrameRun.length > 0) {
            const [coroutineLockType, key, count, locker] = this.nextFrameRun.shift();
            this.notify(coroutineLockType, key, count, locker);
        }
    }

    public runNextCoroutine(coroutineLockType: number, key: CoroutineLockKey, level: number, locker: CoroutineLock): void {
        if (level === 100) {
            we.warn(`CoroutineLockComponent runNextCoroutine, too much coroutine level: ${coroutineLockType} ${key}`);
        }

        this.nextFrameRun.push([coroutineLockType, key, level, locker]);
    }

    /**
     * 等待携程锁，
     * 成功返回CoroutineLock，处理完逻辑再CoroutineLock.dispose()
     * 超时抛出异常，则中断逻辑，
     * @param lockType 锁类型
     * @param key 锁Key
     * @param timeout 锁超时时间,单位:s,默认30s
     * @returns
     */
    public async wait(lockType: number, key: CoroutineLockKey, timeout = 30): Promise<CoroutineLock> {
        let coroutineLockQueueType = this.dictionary.get(lockType);
        if (!coroutineLockQueueType) {
            coroutineLockQueueType = new CoroutineLockQueueType(lockType);
            this.dictionary.set(lockType, coroutineLockQueueType);
        }

        return await coroutineLockQueueType.wait(key, timeout, false);
    }

    /**
     * 等待携程锁
     * 成功返回CoroutineLock，处理完逻辑再CoroutineLock.dispose()
     * 超时不会抛出异常，可以通过返回CoroutineLock获取超时状态
     * @param lockType 锁类型
     * @param key 锁Key
     * @param timeout 锁超时时间,单位:s,默认30s
     * @returns
     */
    public async waitSafe(lockType: number, key: CoroutineLockKey, timeout = 30): Promise<CoroutineLock> {
        let coroutineLockQueueType = this.dictionary.get(lockType);
        if (!coroutineLockQueueType) {
            coroutineLockQueueType = new CoroutineLockQueueType(lockType);
            this.dictionary.set(lockType, coroutineLockQueueType);
        }

        return await coroutineLockQueueType.wait(key, timeout, true);
    }

    private notify(coroutineLockType: number, key: CoroutineLockKey, level: number, locker: CoroutineLock): void {
        const coroutineLockQueueType = this.dictionary.get(coroutineLockType);
        if (!coroutineLockQueueType) {
            return;
        }

        coroutineLockQueueType.notify(key, level, locker);
    }
}

we.core.CoroutineLockComponent = CoroutineLockComponent;
