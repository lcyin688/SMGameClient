import { ObjectPool } from '../objectpool/ObjectPool';
import { TimerComponent } from '../timer/TimerComponent';
import { CoroutineLock, CoroutineLockKey } from './CoroutineLock';
import { WaitCoroutineLock } from './WaitCoroutineLock';

export class CoroutineLockQueue {
    private type: number;
    private key: CoroutineLockKey;
    private runLocker: CoroutineLock | null;

    private readonly queue: WaitCoroutineLock[] = [];

    public static create(type: number, key: CoroutineLockKey): CoroutineLockQueue {
        const coroutineLockQueue = ObjectPool.Inst.fetch(CoroutineLockQueue);
        coroutineLockQueue.type = type;
        coroutineLockQueue.key = key;
        return coroutineLockQueue;
    }

    public get count(): number {
        return this.queue.length;
    }

    /**
     * 等待锁返回
     * @param timeout 单位【秒】
     * @returns
     */
    public async wait(timeout: number, isSafe: boolean): Promise<CoroutineLock> {
        if (!this.runLocker || this.runLocker.isDispose) {
            let runLocker = CoroutineLock.create(this.type, this.key, 1);
            this.runLocker = runLocker;
            return runLocker;
        }

        const waitCoroutineLock = WaitCoroutineLock.create();
        this.queue.push(waitCoroutineLock);
        if (timeout > 0) {
            TimerComponent.Inst.scheduleOnce(timeout, null, waitCoroutineLock).then(() => {
                if (waitCoroutineLock.isDisposed) {
                    return;
                }
                this.queue.remove(waitCoroutineLock);
                if (isSafe) {
                    waitCoroutineLock.setResult(CoroutineLock.create(this.type, this.key, 1, true));
                } else {
                    waitCoroutineLock.setException(new Error(`CoroutineLockQueue wait, locker type:${this.type} key:${this.key} timeout`));
                }
            });
        }

        const locker = await waitCoroutineLock.wait();
        this.runLocker = locker;
        return locker;
    }

    public notify(level: number): void {
        if (this.runLocker && !this.runLocker.isDispose) {
            // 当前锁，未解除，则不能解除队列中的锁
            return;
        }

        TimerComponent.Inst.removeByTag(this.runLocker);

        while (this.queue.length > 0) {
            const waitCoroutineLock = this.queue.shift();

            if (waitCoroutineLock.isDisposed) {
                continue;
            }

            TimerComponent.Inst.removeByTag(waitCoroutineLock);

            this.runLocker = CoroutineLock.create(this.type, this.key, level);

            waitCoroutineLock.setResult(this.runLocker);
            break;
        }
    }

    public recycle(locker: CoroutineLock): boolean {
        // 无法回收
        if (locker && this.runLocker && locker !== this.runLocker) {
            return false;
        }

        this.queue.length = 0;
        this.key = 0;
        this.type = 0;
        this.runLocker?.dispose();
        this.runLocker = null;
        ObjectPool.Inst.recycle(this);

        return true;
    }
}
