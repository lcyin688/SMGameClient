import { CoroutineLockComponent } from './CoroutineLockComponent';

declare global {
    interface ICore {
        coroutine: typeof Coroutine;
    }
}

export type CoroutineLockKey = number | string;

export class CoroutineLock {
    private type: number;
    private key: CoroutineLockKey;
    private level: number;
    public isDispose = false;
    /** 是否超时 */
    public isTimeout = false;

    public static create(type: number, key: CoroutineLockKey, level: number, isTimeout: boolean = false): CoroutineLock {
        const coroutineLock = new CoroutineLock();
        coroutineLock.type = type;
        coroutineLock.key = key;
        coroutineLock.level = level;
        coroutineLock.isDispose = false;
        coroutineLock.isTimeout = isTimeout;
        return coroutineLock;
    }

    public dispose(): void {
        if (this.isDispose) {
            return;
        }
        CoroutineLockComponent.Inst.runNextCoroutine(this.type, this.key, this.level + 1, this);
        this.type = 0;
        this.key = 0;
        this.level = 0;
        this.isDispose = true;
    }
}

interface CoroutineLockerOptions {
    lockType: number;
    key?: CoroutineLockKey;
    /** ⚠️注意：如果需要使用访问实例对象时，不要使用箭头函数 */
    getKey?(...args: any): CoroutineLockKey;
    timeout?: number;
}

export namespace Coroutine {
    /**
     * 锁定方法，避免重放【超时不抛出异常】
     *
     * - 成功返回CoroutineLock，处理完逻辑再CoroutineLock.dispose()
     * - 超时不会抛出异常，可以通过返回CoroutineLock获取超时状态
     * @param options.lockType 锁类型
     * @param options.key 锁Key,默认0
     * @param options.getKey 自定义key
     * @param options.timeout 锁超时时间,单位:s, 默认30s
     * @returns
     */
    export function lockerSafe(options: CoroutineLockerOptions): MethodDecorator {
        return (target: any, propertyKey: string, descriptor: PropertyDescriptor) => {
            const originalMethod = descriptor.value;
            descriptor.value = async function (...args: any[]) {
                options.timeout ??= 30;
                options.key ??= 0;
                this.__lockers__ = this.__lockers__ || [];
                let locker: CoroutineLock | undefined = null;
                try {
                    locker = await CoroutineLockComponent.Inst.waitSafe(options.lockType, options?.getKey?.bind(this)(...args) ?? options.key, options.timeout);
                    this.__lockers__.push(locker);
                    return await originalMethod.apply(this, args);
                } finally {
                    this.__lockers__.removeOne(locker);
                    locker?.dispose();
                }
            };
        };
    }

    /**
     * 锁定方法，避免重放【超时抛异常】
     * - 成功返回CoroutineLock，处理完逻辑再CoroutineLock.dispose()
     * - 超时抛出异常，则中断逻辑，
     * @param options.lockType 锁类型
     * @param options.key 锁Key,默认0
     * @param options.getKey 自定义key
     * @param options.timeout 锁超时时间,单位:s, 默认30s
     * @returns
     */
    export function locker(options: CoroutineLockerOptions): MethodDecorator {
        return (target: any, propertyKey: string, descriptor: PropertyDescriptor) => {
            const originalMethod = descriptor.value;
            descriptor.value = async function (...args: any[]) {
                options.timeout ??= 30;
                options.key ??= 0;
                this.__lockers__ = this.__lockers__ || [];
                let locker: CoroutineLock | undefined = null;
                try {
                    locker = await CoroutineLockComponent.Inst.wait(options.lockType, options?.getKey?.bind(this)(...args) ?? options.key, options.timeout);
                    this.__lockers__.push(locker);
                    return await originalMethod.apply(this, args);
                } finally {
                    this.__lockers__.removeOne(locker);
                    locker?.dispose();
                }
            };
        };
    }

    /**
     * 释放所有锁
     * @returns
     */
    export function releaseAllLocker(): MethodDecorator {
        return (target: any, propertyKey: string, descriptor: PropertyDescriptor) => {
            const originalMethod = descriptor.value;
            descriptor.value = function (...args: any[]) {
                this.__lockers__ = this.__lockers__ || [];
                try {
                    return originalMethod.apply(this, args);
                } catch (err) {
                } finally {
                    this.__lockers__.length = 0;
                }
            };
        };
    }

    /**
     * 等待携程锁
     * 成功返回CoroutineLock，处理完逻辑再CoroutineLock.dispose()
     * 超时抛出异常，则中断逻辑，
     * @param lockType 锁类型
     * @param key 锁Key,默认0
     * @param timeout 锁超时时间,单位:s, 默认30s
     * @returns
     */
    export async function wait(lockType: number, key: CoroutineLockKey = 0, timeout = 30): Promise<CoroutineLock> {
        key ??= 0;
        timeout ??= 30;
        return await CoroutineLockComponent.Inst.wait(lockType, key, timeout);
    }

    /**
     * 等待携程锁
     * 成功返回CoroutineLock，处理完逻辑再CoroutineLock.dispose()
     * 超时不会抛出异常，可以通过返回CoroutineLock获取超时状态
     * @param lockType 锁类型
     * @param key 锁Key,默认0
     * @param timeout 锁超时时间,单位:s, 默认30s
     * @returns
     */
    export async function waitSafe(lockType: number, key: CoroutineLockKey = 0, timeout = 30): Promise<CoroutineLock> {
        key ??= 0;
        timeout ??= 30;
        return await CoroutineLockComponent.Inst.waitSafe(lockType, key, timeout);
    }
}

we.core.coroutine = Coroutine;
