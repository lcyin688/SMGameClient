import { AsyncTask } from '../async/AsyncTask';
import { type CoroutineLock } from './CoroutineLock';

export class WaitCoroutineLock {
    private tcs: AsyncTask<CoroutineLock> | null;

    public static create(): WaitCoroutineLock {
        const waitCoroutineLock = new WaitCoroutineLock();
        waitCoroutineLock.tcs = new AsyncTask<CoroutineLock>();
        return waitCoroutineLock;
    }

    public setResult(coroutineLock: CoroutineLock): void {
        if (!this.tcs) {
            throw new Error('WaitCoroutineLock setResult, tcs is null');
        }
        const t = this.tcs;
        this.tcs = null;
        t.setResult(coroutineLock);
    }

    public setException(exception: Error): void {
        if (!this.tcs) {
            throw new Error('WaitCoroutineLock setException, tcs is null');
        }
        const t = this.tcs;
        this.tcs = null;
        t.setException(exception);
    }

    public get isDisposed(): boolean {
        return this.tcs === null;
    }

    public async wait(): Promise<CoroutineLock> {
        if (!this.tcs) {
            throw new Error('WaitCoroutineLock wait, tcs is null');
        }
        return await this.tcs.wait();
    }
}
