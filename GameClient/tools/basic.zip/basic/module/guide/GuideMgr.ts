import { BasicType } from '../../type/BasicType';
import { PromiseHelper } from '../async/PromiseHelper';
import { Entity } from '../entity/Entity';

declare global {
    interface ICore {
        GuideMgr: typeof GuideMgr;
    }
}

@we.decorator.typeRegister('GuideMgr')
export default class GuideMgr extends Entity {
    /** 引导遮罩节点 */
    private guidMaskNode: cc.Node = null;

    /** 遮罩节点 */
    private mask: cc.Node = null;

    /**
     * 点击mask 防止点击穿透
     */
    private clickMask: cc.Node = null;

    /** 多点触摸配置 */
    private enableMultiTouch = null;

    /** 引导列表 */
    private guideList: BasicType.GuideTmp[] = [];

    /** 当前引导模板 */
    private curGuideTmp: BasicType.GuideTmp = null;

    /** 当前引导节点 */
    private curGuideNode: cc.Node = null;

    /** 当前引导是否结束 */
    private curIsComplete = true;

    // 引导结束等待队列
    private onEndPromisList: any[] = [];

    protected destroy(): void {
        this.clearNodeGroupIndex(this.curGuideNode);
        this.guideList.length = 0;
        this.curGuideTmp = null;
        this.curGuideNode = null;
        this.curIsComplete = true;
        this.onEndPromisList.length = 0;
        this.enableMultiTouch = null;
    }

    async begin(index: number);
    async begin(name: string);
    async begin();
    async begin(...args: any[]) {
        if (this.guideList.length == 0) {
            this._runEnd();
            return;
        }

        if (!this.guidMaskNode) {
            this.createGuideMask();
            this.mask.opacity = 0;
        }

        if (args.length == 0 && this.guideList.length > 0) {
            this.guide(this.guideList[0]);
            return;
        }

        let isGuide = false;
        for (const item of this.guideList) {
            if (item.index == args[0] || item.name == args[0]) {
                this.guide(item);
                isGuide = true;
                break;
            }
        }

        if (!isGuide && this.guideList.length > 0) {
            this.guide(this.guideList[0]);
        }
    }

    // 等待引导结束
    async onEnd() {
        if (this.guideList.length == 0) {
            return;
        }
        const defer = PromiseHelper.defer();
        this.onEndPromisList.push(defer.resolve);
        await defer.promise();
    }

    public async next();
    public async next(...args: any[]) {
        const curTmp = this.curGuideTmp;

        // 如果没有完成则先完成了
        if (curTmp && !this.curIsComplete) {
            await this.completeCurrTmp(false);
        }
    }

    /**
     * 完成当前引导
     * @param isJump
     * @returns
     */
    private async completeCurrTmp(isJump: boolean) {
        const curTmp = this.curGuideTmp;
        if (!curTmp) {
            return;
        }

        const curGuideNode = this.curGuideNode;
        const next = curTmp?.next;
        this.remove(curTmp.name);
        this.curGuideTmp = null;
        this.curGuideNode = null;
        this.curIsComplete = true;
        await Promise.resolve().then(() => {
            return curTmp.onGuideComplete({ guideNode: curGuideNode, mask: this.mask, setGroup: this.getSetGroupCall(), isJump });
        });
        this.clearNodeGroupIndex(curGuideNode);

        if (this.guideList.length <= 0) {
            // 引导结束
            this._runEnd();
            return;
        }

        const nameOrIndex = next?.(curTmp.name, curTmp.index, isJump) ?? -1;
        if (nameOrIndex == -1) {
            this.begin();
            return;
        }

        this.begin(nameOrIndex as any);
    }

    private _runEnd() {
        if (this.enableMultiTouch !== null) {
            cc.macro.ENABLE_MULTI_TOUCH = this.enableMultiTouch;
        }

        this.guidMaskNode?.destroy();
        this.guidMaskNode = null;
        this.mask = null;

        this.onEndPromisList.forEach((item) => {
            item();
        });

        this.onEndPromisList.length = 0;
        this.dispose();
    }

    /**
     * 清理所有引导
     * @returns
     */
    clear() {
        this.guideList.length = 0;
    }

    /**
     * 添加一个引导
     * @param tmp
     */
    add(tmp: BasicType.GuideTmp) {
        const isGuide = tmp?.isGuide?.() ?? true;
        if (!isGuide) {
            return;
        }

        this.guideList.push(tmp);
        // 重新排序
        this.guideList.sort((a, b) => {
            return a.index - b.index;
        });
    }

    /**
     * 添加多个引导配置
     * @param tmps
     */
    set(tmps: BasicType.GuideTmp[]) {
        tmps = tmps.filter((item) => {
            return item?.isGuide?.() ?? true;
        });

        this.guideList.push(...tmps);
        // 重新排序
        this.guideList.sort((a, b) => {
            return a.index - b.index;
        });
    }

    /**
     * 删除一个引导
     * @param name 引导名称
     */
    remove(name: string);
    /**
     * 删除一个引导
     * @param index 引导序号
     */
    remove(index: number);
    remove(...args: any[]) {
        // 删除第一个引导
        if (args.length == 0 && this.guideList.length > 0) {
            this.guideList.shift();
            return;
        }

        // 移除相关的引导
        for (let i = 0; i < this.guideList.length; i++) {
            const item = this.guideList[i];
            if (item.name === args[0] || item.index === args[0]) {
                this.guideList.splice(i, 1);
                i--;
            }
        }
    }

    /**
     * 对某个模板进行引导
     * @param tmp
     */
    private async guide(tmp: BasicType.GuideTmp) {
        this.curGuideTmp = tmp;
        const guideNode = tmp.guideNode();
        this.curGuideNode = guideNode;
        this.setNodeGroupIndex(guideNode);
        this.guidMaskNode.active = true;
        this.curIsComplete = false;

        await Promise.resolve().then(() => {
            return tmp.onGuideShow({ guideNode: guideNode, mask: this.mask, setGroup: this.getSetGroupCall() });
        });

        this.regsterEvent();
    }

    private getSetGroupCall() {
        return (node: cc.Node) => {
            this.setNodeGroupIndex(node);
        };
    }

    private createGuideMask() {
        this.enableMultiTouch = cc.macro.ENABLE_MULTI_TOUCH;
        cc.macro.ENABLE_MULTI_TOUCH = true;

        const node = new cc.Node('EtxGruidMgr');
        this.guidMaskNode = node;
        const parent = we.ui.UILayer.top;
        parent.addChild(node);

        this.addMaskWidget(node);

        this.addCamera(node);

        this.addClickMask(node);

        this.addMask(node);
    }

    private addMaskWidget(node: cc.Node) {
        const widget = node.addComponent(cc.Widget);
        widget.isAlignBottom = true;
        widget.isAlignTop = true;
        widget.isAlignLeft = true;
        widget.isAlignRight = true;
        widget.left = 0;
        widget.right = 0;
        widget.bottom = 0;
        widget.top = 0;
    }

    /**
     * 添加一个相机节点
     * @param paretNode
     */
    private addCamera(paretNode: cc.Node) {
        const cameraNode = new cc.Node('guideCameraNode');
        paretNode.addChild(cameraNode);
        const camera = cameraNode.addComponent(cc.Camera);
        camera.depth = 1;
        camera.cullingMask = 4096;
        camera.alignWithScreen = true;
        camera.clearFlags = 0;
        // camera.clearFlags = cc.Camera.ClearFlags.STENCIL;

        camera.rect.x = 0;
        camera.rect.y = 0;
        camera.rect.width = 1;
        camera.rect.height = 1;
    }

    private async addMask(parentNode: cc.Node) {
        const node = new cc.Node('mask');
        parentNode.addChild(node);

        this.mask = node;

        const defer = PromiseHelper.defer();

        cc.assetManager.loadAny([{ uuid: '0275e94c-56a7-410f-bd1a-fc7483f7d14a' }], (err, data: cc.Texture2D) => {
            if (err) {
                return defer.resolve();
            }
            const spriteFrame = new cc.SpriteFrame(data);
            const sprite = node.addComponent(cc.Sprite);
            sprite.spriteFrame = spriteFrame;
            defer.resolve();
        });

        await defer.promise();
        node.opacity = 180;
        node.color = cc.color().fromHEX('#000000');
        this.addMaskWidget(node);

        // node.groupIndex = 12;
    }

    private addClickMask(parent: cc.Node) {
        const node = new cc.Node('clickMask');
        this.clickMask = node;
        parent.addChild(node);
        node.addComponent(cc.BlockInputEvents);
        this.addMaskWidget(node);
    }

    /**
     * 设置节点分组
     * @param node
     * @returns
     */
    private setNodeGroupIndex(node: cc.Node) {
        if (!cc.isValid(node)) {
            return;
        }

        if (node['__cacheGroupIndex'] == null) {
            node['__cacheGroupIndex'] = node.groupIndex;
        }

        node.groupIndex = 12;

        // 设置子节点的引导内容
        if (node.children.length > 0) {
            node.children.forEach((cNode) => {
                this.setNodeGroupIndex(cNode);
            });
        }
    }

    /**
     * 清理节点分组
     * @param node
     * @returns
     */
    private clearNodeGroupIndex(node: cc.Node) {
        if (!cc.isValid(node)) {
            return;
        }
        if (node?.['__cacheGroupIndex'] != null) {
            node.groupIndex = node['__cacheGroupIndex'];
        }

        if (node.children.length > 0) {
            node.children.forEach((cNode) => {
                this.clearNodeGroupIndex(cNode);
            });
        }
    }

    private async regsterEvent() {
        const startEvent = (event) => {
            const curTmp = this.curGuideTmp;
            curTmp?.isUseGuideNodeClick && this.testingGuideClick(event) && this.guidMaskNode?.['_touchListener']?.setSwallowTouches?.(false);
        };

        const offEvent = async () => {
            await we.core.timer.scheduleOnce(0, this);
            this.guidMaskNode?.['_touchListener']?.setSwallowTouches?.(true);
            this.guidMaskNode.off(cc.Node.EventType.TOUCH_END);
            this.guidMaskNode.off(cc.Node.EventType.TOUCH_START);
            this.clickMask.active = true;
            await we.core.timer.scheduleOnce(0, this);
        };

        const endEvent = async (event) => {
            const curTmp = this.curGuideTmp;
            const curGuideNode = this.curGuideNode;
            const isUseGuideNodeClick = curTmp?.isUseGuideNodeClick ?? false;
            // 是否点击了引导节点区域
            let isClickGuideNode = this.testingGuideClick(event);
            const clickMaskJump = curTmp?.clickMaskJump ?? true;

            const isJump = (!isClickGuideNode || (!curTmp?.onGuideClick && !curTmp?.isUseGuideNodeClick)) && clickMaskJump;

            // 点击了遮罩,跳过
            if (isJump) {
                await offEvent();
                this.completeCurrTmp(true);
                return;
            }

            // 如果点击了节点时间则不进行下一步，需要配置中手动调用next
            if (isUseGuideNodeClick && isClickGuideNode) {
                await offEvent();
                await Promise.resolve()
                    .then(() => {
                        return curTmp?.onGuideClick?.({ guideNode: curGuideNode, mask: this.mask, setGroup: this.getSetGroupCall() });
                    })
                    .then((isClick: boolean) => {
                        !isClick && this.regsterEvent();
                    });
                return;
            }

            // 如果点击了引导区域则发送事件并等事件执行完成进行一下一个引导
            if (isClickGuideNode && curTmp?.onGuideClick) {
                await offEvent();
                await Promise.resolve()
                    .then(() => {
                        return curTmp?.onGuideClick?.({ guideNode: curGuideNode, mask: this.mask, setGroup: this.getSetGroupCall() });
                    })
                    .then((isClick: boolean) => {
                        !isClick && this.regsterEvent();
                    });

                this.completeCurrTmp(false);
            }
        };

        this.clickMask.active = false;
        this.guidMaskNode.on(cc.Node.EventType.TOUCH_START, startEvent);
        this.guidMaskNode.on(cc.Node.EventType.TOUCH_END, endEvent);
    }

    private testingGuideClick(event: cc.Event) {
        const { width, height } = this.curGuideNode;
        const worldPos = this.curGuideNode.parent.convertToWorldSpaceAR(this.curGuideNode.position);
        const right = worldPos.x + width / 2;
        const left = worldPos.x - width / 2;
        const top = worldPos.y + height / 2;
        const bottom = worldPos.y - height / 2;
        const point: { x: number; y: number } = event['touch']['_point'];

        if (point.y > top || point.y < bottom || point.x < left || point.x > right) {
            return false;
        }
        return true;
    }
}

we.core.GuideMgr = GuideMgr;
