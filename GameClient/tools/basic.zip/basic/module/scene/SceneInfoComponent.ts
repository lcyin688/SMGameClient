import { UIType } from '../../ui/core/UIType';
import { Entity } from '../entity/Entity';

declare global {
    interface ICore {
        SceneInfoComponent: typeof SceneInfoComponent;
        SceneDatas: SceneDatas;
    }

    namespace we {
        namespace core {
            type SceneInfoComponent = InstanceType<typeof SceneInfoComponent>;
            type SceneDatas = ICore['SceneDatas'];
        }
    }
}

export interface SceneDatas {
    /** 是否启用多点触控 */
    ENABLE_MULTI_TOUCH: boolean;
    /** 场景默认点击音效配置 */
    clickUrl: string;
    /** 场景默认按钮点击sleep时间 */
    clickSleepTime: number;
    /** 场景加载视图ID */
    sceneLoadingViewId?: string;
    /** 场景大背景，一般用于竖版 */
    bigBgUrl?: string;
    /** 确认弹窗内容类型 */
    confirmContentType?: UIType.PopupContentType;
    /** 跳转场景名称 */
    sceneName?: string;
}

/**
 * 场景信息组件
 */
@we.decorator.typeRegister('SceneInfoComponent')
export class SceneInfoComponent extends Entity {
    private _datas: Partial<SceneDatas> = null;

    get datas() {
        return this._datas;
    }

    protected awake(): void {
        this._datas = {};
    }

    protected destroy(): void {}

    public append(datas: Partial<SceneDatas>) {
        this._datas = {
            ...this._datas,
            ...datas,
        };
    }
}

we.core.SceneInfoComponent = SceneInfoComponent;
