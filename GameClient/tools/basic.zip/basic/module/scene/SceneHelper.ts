import { GameConfig } from '../../config/GameConfig';
import { ScreenOrientation } from '../../config/ProjectConfig';
import Flavor from '../../flavor/Flavor';
import NativeUtil from '../../platform/NativeUtil';
import { UILayer } from '../../ui/core/UILayer';
import { SceneBigBackground } from '../SceneBigBackground';
import { Scene } from './Scene';
import { SceneDatas, SceneInfoComponent } from './SceneInfoComponent';

declare global {
    interface ICore {
        SceneHelper: typeof SceneHelper;
    }
}

export class SceneHelper {
    /**
     * 设置场景配置
     * @param options
     * @param scene
     */
    public static setSceneInfo(options: Partial<SceneDatas>, scene?: Scene) {
        scene ??= we.currentScene;
        scene ??= we.clientScene;
        scene.getComponent(SceneInfoComponent).append(options);
    }

    public static getSceneInfoItem<K extends keyof SceneDatas>(key: K, scene?: Scene): Partial<SceneDatas>[K] {
        if (scene) {
            return scene.getComponent(SceneInfoComponent)?.datas?.[key];
        }

        return this.getSceneInfoCmp()?.datas?.[key] ?? we.clientScene?.getComponent(SceneInfoComponent)?.datas?.[key];
    }

    private static getSceneInfoCmp() {
        return we.currentScene?.getComponent?.(SceneInfoComponent) ?? we.clientScene?.getComponent(SceneInfoComponent);
    }

    public static setSceneUI(scene: Scene) {
        if (!scene || scene.IsDisposed) {
            we.warn(`SceneHelper setSceneUI, params err`);
            return;
        }

        let screenOrientation = Flavor.getSkinOrientation();

        // 设置横竖屏
        if (GameConfig.isSubGame(scene.gameId)) {
            let gameConfig = GameConfig.getGameConfig(scene.gameId);
            screenOrientation = gameConfig.screenOrientation;
        }
        NativeUtil.setScreenOrientation(screenOrientation);

        // 设置竖版场景
        if (cc.sys.isBrowser && !cc.sys.isMobile && screenOrientation === ScreenOrientation.PORTRAIT) {
            // 是否使用场景遮罩
            UILayer.uiRoot.addComponentUnique(cc.Mask).enabled = true;
            const bigBgUrl = this.getSceneInfoItem('bigBgUrl', scene);
            // 动态设置竖版大背景
            if (bigBgUrl) {
                scene.addComponentAsync(SceneBigBackground, bigBgUrl);
            }
        }
    }
}

we.core.SceneHelper = SceneHelper;
