import { Entity } from '../entity/Entity';
import { Scene } from './Scene';

declare global {
    interface ICore {
        CurrentScenesComponent: typeof CurrentScenesComponent;
    }

    namespace we {
        namespace core {
            type CurrentScenesComponent = InstanceType<typeof CurrentScenesComponent>;
        }
    }
}

/** 可以用来管理多个客户端场景，比如大世界会加载多块场景 */
@we.decorator.typeRegister('CurrentScenesComponent')
export class CurrentScenesComponent extends Entity {
    public scene: Scene;

    public static currentScene(clientScene: Scene) {
        return clientScene.getComponent(CurrentScenesComponent).scene;
    }
}

we.core.CurrentScenesComponent = CurrentScenesComponent;
