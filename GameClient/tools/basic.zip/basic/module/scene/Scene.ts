import { Entity } from '../entity/Entity';

declare global {
    interface ICore {
        Scene: typeof Scene;
    }

    namespace we {
        namespace core {
            type Scene = InstanceType<typeof Scene>;
        }
    }
}

@we.decorator.typeRegister('Scene')
export class Scene extends Entity {
    /**
     * 如果配置了，则Scene属于这个游戏的，否则，属于公共的
     */
    public gameId: we.GameId;
    private readonly zone: number;
    private readonly sceneType: number;
    private readonly name: string;

    get Zone() {
        return this.zone;
    }

    get SceneType() {
        return this.sceneType;
    }

    get Name() {
        return this.name;
    }

    constructor(id: number, instanceId: number, zone: number, sceneType: number, name: string, parent: Entity);
    constructor(instanceId: number, zone: number, sceneType: number, name: string, parent: Entity);
    constructor(idOrInstanceId: number, instanceIdOrZone: number | number, zoneOrSceneType: number | number, sceneTypeOrName: number | string, nameOrParent: string | Entity, parent?: Entity) {
        super();
        if (
            typeof idOrInstanceId === 'number' &&
            typeof instanceIdOrZone === 'number' &&
            typeof zoneOrSceneType === 'number' &&
            typeof sceneTypeOrName === 'number' &&
            typeof nameOrParent === 'string' &&
            (parent == null || parent instanceof Entity)
        ) {
            // 第一个构造函数的实现
            this.Id = idOrInstanceId;
            this.InstanceId = instanceIdOrZone;
            this.zone = zoneOrSceneType;
            this.sceneType = sceneTypeOrName;
            this.name = nameOrParent;
        } else if (
            typeof idOrInstanceId === 'number' &&
            typeof instanceIdOrZone === 'number' &&
            typeof zoneOrSceneType === 'number' &&
            typeof sceneTypeOrName === 'string' &&
            (nameOrParent == null || nameOrParent instanceof Entity)
        ) {
            // 第二个构造函数的实现
            this.Id = idOrInstanceId;
            this.InstanceId = idOrInstanceId;
            this.zone = instanceIdOrZone;
            this.sceneType = zoneOrSceneType;
            this.name = sceneTypeOrName;
        } else {
            throw new Error('Invalid arguments for Scene constructor');
        }

        this.IsCreated = true;
        this.IsNew = true;
        this.Parent = parent;
        this.Domain = this;
        this.IsRegister = true;
        we.log(`Create scene: type=${this.SceneType} name=${this.Name} id=${this.Id} gameId=${this.gameId} instanceId=${this.InstanceId} zone=${this.Zone}`);
    }

    dispose() {
        if (this.IsDisposed) {
            return;
        }

        we.log(`Scene dispose, scene dispose: type=${this.SceneType} name=${this.Name} id=${this.Id} gameId=${this.gameId} instanceId=${this.InstanceId} zone=${this.Zone}`);

        super.dispose();
    }

    get Domain(): Entity {
        return this.domain;
    }

    set Domain(value: Entity) {
        this.domain = value;
    }

    get Parent(): Entity {
        return this.parent;
    }

    set Parent(value: Entity) {
        if (value == null) {
            this.parent = this;
            return;
        }

        this.parent = value;
        this.parent.Children.set(this.Id, this);
    }
}

we.core.Scene = Scene;
