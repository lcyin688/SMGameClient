declare global {
    interface ICore {
        SceneType: typeof SceneType;
    }
}

export enum SceneType {
    /** None */
    None = -1,
    /** 进程 */
    Process = 0,

    // 客户端Model层
    Client = 1000,
    Current = 1001,
}

we.core.SceneType = SceneType;
