import { UIComponent } from '../../ui/core/UIComponent';
import { HotCache } from '../algorithms/HotCache';
import { ObjectWait } from '../async/ObjectWait';
import { Entity } from '../entity/Entity';
import { EntityEvent } from '../entity/EntityEvent';
import { EntitySceneFactory } from '../entity/EntitySceneFactory';
import { Root } from '../entity/Root';
import { PoolComponent } from '../nodepool/PoolComponent';
import { CurrentScenesComponent } from './CurrentScenesComponent';
import { Scene } from './Scene';
import { SceneInfoComponent } from './SceneInfoComponent';
import { SceneType } from './SceneType';

declare global {
    interface ICore {
        SceneFactory: typeof SceneFactory;
    }
}

export class SceneFactory {
    /**
     * 创建客户端场景
     * @param zone 分区id
     * @param name 场景名称
     * @returns
     */
    public static createClientScene(zone: number, name: string): Scene {
        const clientScene: Scene = EntitySceneFactory.createScene(zone, SceneType.Client, name, Root.Inst.scene);
        we.clientScene = clientScene;
        // 创建公共组件
        clientScene.addComponent(ObjectWait);
        clientScene.addComponent(PoolComponent);
        clientScene.addComponent(EntityEvent);
        clientScene.addComponent(CurrentScenesComponent);
        clientScene.addComponent(SceneInfoComponent);
        we.kit.hotCache = clientScene.addComponent(HotCache, { typeMax: { bundle: 2 } });
        we.clientUI = clientScene.addComponent(UIComponent);

        return clientScene;
    }

    /** 创建当前场景 */
    public static async createCurrentScene(sceneName: string, gameId: we.GameId): Promise<Scene> {
        const currentScenesComponent: CurrentScenesComponent = we.clientScene.getComponent(CurrentScenesComponent);

        const currentScene: Scene = EntitySceneFactory.createScene(++Entity.generateId, ++Entity.generateInstanceId, we.clientScene.Zone, SceneType.Current, sceneName, currentScenesComponent);
        currentScene.gameId = gameId;
        currentScenesComponent.scene = currentScene;
        currentScene.addComponent(PoolComponent);
        currentScene.addComponent(EntityEvent);
        currentScene.addComponent(ObjectWait);
        currentScene.addComponent(SceneInfoComponent);
        we.currentUI = currentScene.addComponent(UIComponent);
        we.currentScene = currentScene;

        return currentScene;
    }
}

we.core.SceneFactory = SceneFactory;
