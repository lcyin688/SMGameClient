import * as dayjs from 'dayjs';
import * as timezone from 'dayjs/plugin/timezone.js';
import * as utc from 'dayjs/plugin/utc.js';

dayjs.extend(utc);
dayjs.extend(timezone);

declare global {
    interface ICore {
        TimeHelper: typeof TimeHelper;
    }
}

/**
 * 时间字符格式
 * https://day.nodejs.cn/docs/en/display/format
 */

// 所有可用格式的列表
// 格式	输出	描述
// YY	18	两位数年份
// YYYY	2018	四位数年份
// M	1-12	月份，从 1 开始
// MM	01-12	月份，2 位数字
// MMM	Jan-Dec	月份名称缩写
// MMMM	January-December	完整的月份名称
// D	1-31	该月的哪一天
// DD	01-31	月份中的日期，2 位数字
// d	0-6	一周中的某一天，星期日为 0
// dd	Su-Sa	星期几的最小名称
// ddd	Sun-Sat	星期几的简称
// dddd	Sunday-Saturday	星期几的名称
// H	0-23	小时
// HH	00-23	小时，2 位数字
// h	1-12	小时、12 小时制
// hh	01-12	小时，12 小时制，2 位数字
// m	0-59	分钟
// mm	00-59	分钟，2 位数字
// s	0-59	第二
// ss	00-59	第二个，2 位数字
// SSS	000-999	毫秒，3 位数字
// Z	+05:00	The offset from UTC, ±HH:mm
// ZZ	+0500	The offset from UTC, ±HHmm
// A	上午下午
// a	am pm
export const TimeFormat = {
    /** 2006-07-02 08:09:04 */
    FMT_DT: 'YYYY-MM-DD HH:mm:ss',
    /** 2006-07-02 08:09:04.423 */
    FMT_DT_S: 'YYYY-MM-DD HH:mm:ss.SSS',
    /** 2006-07-02 */
    FMT_D: 'YYYY-MM-DD',
    /** 2006.07.02 */
    FMT_D_DOT: 'YYYY.MM.DD',
    /** 20060702 */
    FMT_DB: 'YYYYMMDD',
    /** 08:09:04 */
    FMT_T: 'HH:mm:ss',
    FMT_THM: 'HH:mm',
    FMT_mm: 'mm',
    FMT_UTC_4: 'YYYY-MM-DDTHH:mm:ss.SSS-04:00',
    /** 2009-03-10 二 20:09:04 */
    FMT_E: 'yyyy-MM-dd E HH:mm:ss',
    /** 2009-03-10 周二 20:09:04 */
    FMT_EE: 'yyyy-MM-dd EE HH:mm:ss',
    /** 2009-03-10 星期二 20:09:04 */
    FMT_EEE: 'yyyy-MM-dd EEE HH:mm:ss',
};

export class TimeHelper {
    public static readonly OneDay = 86400000;
    public static readonly Hour = 3600000;
    public static readonly Minute = 60000;

    /**
     * 获取系统时区
     */
    public static getTimezone() {
        return dayjs.tz.guess();
    }

    /**
     * 设置系统时区
     * @param timezone
     */
    public static setTimezone(timezone: string) {
        dayjs.tz.setDefault(timezone);
    }

    /**
     * 获取本地化时间字符串
     * @param fmt
     * @param time
     * @param timezone
     * @returns
     */
    public static formatTime(fmt?: string, time?: dayjs.ConfigType, timezone?: string) {
        return dayjs(time).tz(timezone).format(fmt);
    }

    /**
     * 获取本地化时间字符串
     * @param fmt
     * @param time
     * @param timezone
     * @deprecated 4.1版本后，删除此方法
     * @returns
     */
    public static getLocalFormatTime(fmt?: string, time?: dayjs.ConfigType, timezone?: string) {
        return dayjs(time).tz(timezone).format(fmt);
    }

    /** 获取本地时间戳(秒) */
    public static getTimestampS(time?: dayjs.ConfigType): number {
        return Math.floor(dayjs(time).valueOf() / 1000);
    }

    /** 获取本地时间戳(毫秒) */
    public static getTimestampMS(time?: dayjs.ConfigType): number {
        return dayjs(time).valueOf();
    }

    /** 获取时间差 */
    public static getTimeDiff(unit: dayjs.QUnitType, toTime: dayjs.ConfigType, fromTime?: dayjs.ConfigType) {
        return dayjs(fromTime).diff(dayjs(toTime), unit, true);
    }

    public static getTime(time?: dayjs.ConfigType) {
        return dayjs(time);
    }

    /** 指定时间是否在指定时间范围内 */
    public static isBetween(start: dayjs.QUnitType, end: dayjs.ConfigType, time?: dayjs.ConfigType) {
        return dayjs(time).isAfter(start) && dayjs(time).isBefore(end);
    }

    /**
     * 是否为同一天
     * @param toTime  (毫秒)
     * @param fromTime  (毫秒)
     */
    public static isSameDay(toTime: dayjs.ConfigType, fromTime: dayjs.ConfigType) {
        const moment1 = dayjs(toTime);
        const moment2 = dayjs(fromTime);
        return moment1.isSame(moment2, 'day');
    }

    /** 获取过去X时0分时间戳 */
    public static getPassXHourZero(passed: number, time?: dayjs.ConfigType): number {
        return this.getTimestampS(dayjs(time).startOf('hour').subtract(passed, 'hour').valueOf());
    }

    /** 获取过去X分0秒时间戳 */
    public static getPassXMinuteZero(passed: number, time?: dayjs.ConfigType): number {
        return this.getTimestampS(dayjs(time).startOf('minute').subtract(passed, 'minute').valueOf());
    }

    /** 获取过去X天0点时间戳 */
    public static getPassXDayZero(passed: number, time?: dayjs.ConfigType): number {
        return this.getTimestampS(dayjs(time).startOf('day').subtract(passed, 'day').valueOf());
    }

    /** 获取未来X天0点时间戳 */
    public static getAfterXDayZero(after: number, time?: dayjs.ConfigType): number {
        return this.getTimestampS(dayjs(time).startOf('day').add(after, 'day').valueOf());
    }

    /** 获取过去x周0点时间戳 */
    public static getPassXWeekZero(passed: number, time?: dayjs.ConfigType) {
        return this.getTimestampS(dayjs(time).startOf('week').subtract(passed, 'week').valueOf());
    }

    /** 获取未来x周0点时间戳 */
    public static getAfterXWeekZero(passed: number, time?: dayjs.ConfigType) {
        return this.getTimestampS(dayjs(time).startOf('week').add(passed, 'week').valueOf());
    }

    /** TODO 获取本周开始0点时间戳 */
    public static getPassCNWeekZero(passed: number, time?: dayjs.ConfigType) {
        const dd = dayjs(time).startOf('week').subtract(passed, 'week');
        return this.getTimestampS(dd.startOf('day').add(1, 'day').valueOf());
    }

    /** 获取过去X月0点时间戳 */
    public static getPassXMonthZero(passed: number, time?: dayjs.ConfigType) {
        return this.getTimestampS(dayjs(time).startOf('month').subtract(passed, 'month').valueOf());
    }

    /** 获取过去X月0点时间戳 */
    public static getAfterXMonthZero(passed: number, time?: dayjs.ConfigType) {
        return this.getTimestampS(dayjs(time).startOf('month').add(passed, 'month').valueOf());
    }

    /** 是否跨周 */
    public static isCrossWeek() {
        return dayjs().day() === 1;
    }

    /** 是否跨月 */
    public static isCrossMonth() {
        return dayjs().date() === 1;
    }

    /** 指定时间零点 */
    public static getPointTimeZero(time?: dayjs.ConfigType) {
        return dayjs(time).hour(0).minute(0).second(0).millisecond(0);
    }
}

we.core.TimeHelper = TimeHelper;
