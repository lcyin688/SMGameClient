import { ISingletonUpdate, Singleton } from '../singleton/Singleton';

declare global {
    interface ICore {
        TimeInfo: typeof TimeInfo;
    }
}

@we.decorator.typeSingleton('TimeInfo')
export class TimeInfo extends Singleton implements ISingletonUpdate {
    static get Inst() {
        return this.getInstance();
    }

    /**
     * 时差毫秒数
     */
    public serverMinusClientTime: number;
    public frameTime: number;
    /**
     * 时区
     * @private
     */
    private timeZone: number;
    private lastUpdateTime: number;
    public constructor() {
        super();
        this.timeZone = 0;
        this.frameTime = this.clientNow();
        this.serverMinusClientTime = 0;
    }

    async syncServerTime(timeGetter: () => Promise<number>): Promise<boolean> {
        if (!we.npm.lodash.isFunction(timeGetter)) {
            return false;
        }

        try {
            const time1 = this.clientNow();
            const serverTs = (await timeGetter?.()) ?? this.clientNow();
            if (this.lastUpdateTime && time1 < this.lastUpdateTime) {
                // 避免延时请求覆盖最新的同步时间
                return false;
            }
            const time2 = this.clientNow();
            const minus = serverTs + (time2 - time1) / 2 - time2;

            this.serverMinusClientTime = minus;
            this.lastUpdateTime = this.clientNow();
            we.debug(`TimeInfo syncServerTime, server and client time minus ${minus} ms`);
            return true;
        } catch (err) {
            we.warn(`TimeInfo syncServerTime, server time sync err: ${JSON.stringify(err?.message || err)}`);
        }

        return false;
    }

    update(): void {
        this.frameTime = this.clientNow();
    }

    public get TimeZone(): number {
        return this.timeZone;
    }

    public set TimeZone(value: number) {
        this.timeZone = value;
    }

    /**
     * 客户端毫秒时间戳
     * @returns
     */
    public clientNow(): number {
        return Date.now();
    }

    /**
     * 服务器毫秒时间戳
     * @returns
     */
    public serverNow(): number {
        return this.clientNow() + this.serverMinusClientTime;
    }

    /**
     * 当前帧时间戳
     * @returns
     */
    public clientFrameTime(): number {
        return this.frameTime;
    }

    /**
     * 当前帧时间戳
     * @returns
     */
    public serverFrameTime(): number {
        return this.frameTime + this.serverMinusClientTime;
    }
}

we.core.TimeInfo = TimeInfo;
