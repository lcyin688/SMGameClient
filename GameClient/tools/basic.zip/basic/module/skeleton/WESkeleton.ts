import AssetManager from '../../manager/AssetManager';
import { PromiseHelper } from '../async/PromiseHelper';

const { ccclass, property, menu, executeInEditMode } = cc._decorator;

declare global {
    interface IUI {
        WESkeleton: typeof WESkeleton;
    }

    namespace we {
        namespace ui {
            type WESkeleton = InstanceType<typeof WESkeleton>;
        }
    }
}

/** 播放完成回调 */
interface IComplete {
    (success?: boolean): void;
}

/** 自动播放生命周期枚举 */
enum Time {
    none = 0,
    onLoad = 1,
    start = 2,
    onEnable = 3,
}

/** 自动播放生命周期声明 */
const timeEnum = cc.Enum(Time);

interface PlayOpts {
    /** 播放完成回调 */
    onComplete?: IComplete;
    /** 播放速度 */
    timeScale?: number;
    /** 动画皮肤 */
    skin?: string;
    /** 开始播放时间点 */
    startTime?: number;
}

interface PlayOb {
    /** 播放id */
    id: number;
    /** 播放完成回调 */
    onComplete?: IComplete;
    /** 开始播放时间点 */
    startTime?: number;
    /** 动画名 */
    animation: string;
    /** 播放异步回调 */
    defer: {
        promise: () => Promise<any>;
        resolve: (data?: any) => void;
        reject: (e: any) => void;
    };
    /** 播放次数 < 1代表无限循环 */
    times: number;

    /** 已播放完成次数 */
    completeTimes: number;

    /** 动画时长 */
    animDuration: number;

    /** 当前动画已播放时长 */
    animElapsed: number;
}

/**
 * 什么是挂点：
 * 挂点在spine动画中就是一个动画骨骼，一般动画中带有文字的部分动画需要将文字部分的UI去掉，保留骨骼动画和插槽动画即可, 文字部分UI程序这边手动挂到骨骼上
 * spine动画挂点制作约定：
 * 1、挂点必须是骨骼，骨骼实现除颜色变化外的所有动画，骨骼名就是挂点名，挂点名在当前动画中唯一
 * 2、骨骼下面必须有一个与其同名的插槽，插槽用于实现挂点的颜色，透明度等变化
 * 3、骨骼和插槽的原点必须一致
 */

// 挂点数据结构体
interface MountDataSt {
    name: string;
    /** 挂点偏移量 基于 0,0位置偏移 */
    offset?: { x?: number; y?: number };
}

// 挂点颜色数据结构体
interface SyncMountColor {
    nodeOpacity: number;
    slotColor: cc.Color;
}

@ccclass
@menu('we/spine/WESkeleton(动画挂点)')
// @ts-ignore
export default class WESkeleton extends cc.Component {
    private _skeletonComp: sp.Skeleton;

    /** 自动播放选项 */
    @property({ type: timeEnum, tooltip: CC_DEV && '自动播放时机 none为不播放 animation和loop遵循选项' })
    private autoPlay: Time = Time.none;
    /** 隐藏loop选项并私有化 */
    @property({
        visible(this: WESkeleton) {
            return this.autoPlay !== Time.none;
        },
        override: true,
    })
    /** 预乘开关改为默认为关闭 */
    @property({ serializable: true, override: true })
    protected _premultipliedAlpha = false;

    /** 设置动画时长 */
    private _animDuration = {};

    /**
     * 挂点列表
     */
    private _moutList: Map<cc.Node, MountDataSt> = new Map();

    /**
     * 挂点颜色同步列表
     */
    private _syncMountColorMap: Map<cc.Node, SyncMountColor> = new Map();

    /** 当前动画时长缩放 */
    private _timeScale = 1;

    /**
     * 递增id，用于记录播放对象id
     */
    private _playObId = 0;

    private _playOb: PlayOb = null;

    get skeletonComp() {
        if (!this._skeletonComp) {
            this._skeletonComp = this.getComponent(sp.Skeleton);
        }
        return this._skeletonComp;
    }

    protected onLoad() {
        if (!this.skeletonComp) {
            we.error('WESkeleton onLoad, play error not skleton Component');
            return;
        }
        const times = this.skeletonComp.loop ? -1 : 1;
        // 自动播放处理
        if (!this._playOb && this.autoPlay === Time.onLoad && !CC_EDITOR) {
            this.play(this.skeletonComp.animation, times);
        }
    }

    protected start() {
        if (!this.skeletonComp) {
            we.error('WESkeleton start, play error not skleton Component');
            return;
        }
        const times = this.skeletonComp.loop ? -1 : 1;
        if (!this._playOb && this.autoPlay === Time.start && !CC_EDITOR) {
            this.play(this.skeletonComp.animation, times);
        }
    }

    protected onEnable() {
        if (!this.skeletonComp) {
            we.error('WESkeleton onEnable, play error not skleton Component');
            return;
        }
        const times = this.skeletonComp.loop ? -1 : 1;
        if (!this._playOb && this.autoPlay === Time.onEnable && !CC_EDITOR) {
            this.play(this.skeletonComp.animation, times);
        }
    }

    /**
     * 设置动画SkeletonData
     * @param data SkeletonData
     * @returns
     */
    public setSkeletonData(data: sp.SkeletonData) {
        const oldData = this.skeletonComp.skeletonData;
        if (oldData?.['_uuid'] == data['_uuid']) {
            return this;
        }

        this.runComplete(true);
        this.clearPlayOb();

        this.skeletonComp.skeletonData = data;
        this.clearCache();
        return this;
    }

    /**
     * 设置skeleton动画资源
     * @param resUrl skectlon资源url
     * @returns
     */
    public setSkeletonRes(resUrl: string) {
        const data = AssetManager.getAsset(resUrl, sp.SkeletonData);
        if (!data) {
            we.error('WESkeleton setSkeletonRes, error: Not res url: ', resUrl);
            return this;
        }

        this.setSkeletonData(data);
        return this;
    }

    /**
     * 设置skeleton动画资源
     * @param resUrl skectlon资源url
     * @returns
     */
    public async setSkeletonResAsync(resUrl: string) {
        const data = await AssetManager.loadAsset(resUrl, sp.SkeletonData, this);
        this.setSkeletonData(data);
        return this;
    }

    /**
     * 设置播放速度
     * @param scale 0~1
     */
    public setTimeScale(scale: number) {
        this._timeScale = scale;

        const animation = this._playOb?.animation;
        if (!animation) {
            return this;
        }

        const animDuration = this.skeletonComp.findAnimation(animation)?.duration || 0.1;
        scale = scale * (animDuration / (this._animDuration[animation] || animDuration));
        this.updateTimeScale(scale);
        return this;
    }

    /**
     * 设置动画播放时长
     * 解决主要问题：如果两个动画播放时长不一致，但需求是要求一致，此时则可利用此函数将播放时间设置成一致的时长
     * @param animName 动画名
     * @param time 时长
     */
    public setAnimDuration(animName: string, time: number) {
        const anims = this.skeletonComp.skeletonData?.skeletonJson?.animations ?? {};
        // 动画不存在则不能播放
        if (!anims[animName]) {
            we.error(`WESkeleton setAnimDuration, Animation ${animName} does not exist`);
            return;
        }

        this._animDuration[animName] = time;
        // 如果当前播放动画与设置动画名不一致则不重新设置播放scale
        if (animName != this._playOb?.animation) {
            return this;
        }

        this.setTimeScale(this._timeScale);
        return this;
    }

    /**
     * 开启合批，如果渲染大量相同纹理，且结构简单的骨骼动画，开启合批可以降低drawcall，否则请不要开启，cpu消耗会上升。
     * @param isEnable
     */
    public setEnableBatch(isEnable: boolean) {
        this.skeletonComp.enableBatch = isEnable;
    }

    /**
     * 清理相关动画设置的动画时长，使用原有的动画时长
     * @param animName
     */
    public clearAnimDuration(animName: string) {
        delete this._animDuration[animName];
        return this;
    }

    /**
     * 设置帧事件
     */
    public setEventListener(handler: (trak, event: sp.spine.Event) => void) {
        this.skeletonComp.setEventListener(handler);
    }

    /**
     * ⚠️ 请勿在缓存模式下使用这个接口
     * 为所有关键帧设定混合及混合时间
     * @param fromAnimation 过渡起始动画
     * @param toAnimation 过渡结束动画
     * @param duration 动画过渡时间。
     */
    public setMix(fromAnimation: string, toAnimation: string, duration: number) {
        let anis = this.skeletonComp.skeletonData.skeletonJson.animations;
        if (!anis[fromAnimation] || !anis[toAnimation]) {
            we.warn(`WESkeleton setMix, animation ${fromAnimation} or ${toAnimation} does not exist`);
            return;
        }

        this.skeletonComp.setMix(fromAnimation, toAnimation, duration);
    }

    /**
     * @description: 播放Spine
     * @param {string} animation 动画名称, null时播放默认动画
     * @param {number} times 播放次数，>0 播放指定次数接受，<=0 永久循环播放
     * @param {{onComplete?: IComplete, timeScale?: number, autoDestroy?: boolean}} opts 可选项
     */
    public play(animation?: string, times: number = 1, opts?: PlayOpts) {
        // 先清理当前播放的动画，如果有异步函数则返回异步，如果有回调则返回回调
        this.runComplete(true);
        this.clearPlayOb();

        const _playOb = this.createOb({ animation, times });

        if (!_playOb) {
            we.error('WESkeleton play, base data error!');
            return;
        }

        _playOb.animDuration = this.getAnimationDuration(_playOb.animation);

        _playOb.startTime = opts?.startTime ?? 0;
        _playOb.startTime = _playOb.startTime < 0 ? 0 : _playOb.startTime;

        _playOb.onComplete = opts?.onComplete || null;

        this._playOb = _playOb;

        this._timeScale = opts?.timeScale ?? this._timeScale;

        if (opts?.skin) {
            this.setSkin(opts.skin);
        }

        this.__play();
    }

    /**
     * @description: 异步播放Spine
     * @param {string} animation 动画名称, null时播放默认动画
     * @param {number} times 播放次数，必须大于 0
     * @param {{onComplete?: IComplete, timeScale?: number, autoDestroy?: boolean}} opts 可选项
     */
    public async playAsync(animation?: string, times: number = 1, opts?: Omit<PlayOpts, 'onComplete'>) {
        this.play(animation, times, opts);
        if (!this._playOb) {
            return;
        }
        await this._playOb.defer?.promise();
    }

    /**
     * 播放1次spine
     * @param animation 动画名称, null时播放默认动画
     * @param opts 可选项
     */
    public playOnce(animation?: string, opts?: PlayOpts) {
        this.play(animation, 1, opts);
    }

    /**
     * 异步播放1次spine
     * @param animation 动画名称, null时播放默认动画
     * @param opts 可选项
     */
    public async playOnceAsync(animation?: string, opts?: Omit<PlayOpts, 'onComplete'>) {
        this.play(animation, 1, opts);
        if (!this._playOb) {
            return;
        }
        await this._playOb.defer?.promise();
    }

    /**
     * @description: 循环播放spine
     * @param {string} animation 动画名称, null时播放默认动画
     * @param {{onComplete?: IComplete, timeScale?: number}} opts 可选项
     * @returns 返回异步，当播放其他动画时会停止播放并返回异步
     */
    public async playLoop(animation?: string, opts?: Omit<PlayOpts, 'onComplete' | 'autoDestroy'>) {
        this.play(animation, -1, opts);
        if (!this._playOb) {
            return;
        }
        await this._playOb.defer?.promise();
    }

    /**
     * ⚠️ 请勿在缓存模式下使用这个接口
     * 添加挂点，spine中将骨骼(bone)作为挂点，但是骨骼没有颜色相关变换操作，所以骨骼下面的 插槽(slot) 也是挂点的一部分，插槽用于颜色变换
     * @param mountName 挂点名称
     * @param node 需要挂载的节点
     * @returns
     */
    public addMount(mountName: string, node: cc.Node, offset?: { x?: number; y?: number }) {
        offset = offset ?? { x: 0, y: 0 };
        offset.x = offset.x || 0;
        offset.y = offset.y || 0;

        this._moutList.set(node, {
            name: mountName,
            offset: offset,
        });

        const attachUtil: any = this.skeletonComp['attachUtil'];
        // 生成挂点(骨骼) 节点
        const boneNodes: cc.Node[] = attachUtil.generateAttachedNodes(mountName);
        if (boneNodes.length == 0) {
            this._moutList.delete(node);
            // 没有找到骨骼
            we.error(`WESkeleton addMount, SpineSlot->addMount:${mountName} bone does not exist`);
            return;
        }

        // 查找插槽
        const slot = this.skeletonComp.findSlot(mountName);
        if (!slot) {
            this._moutList.delete(node);
            // 没有找到插槽
            we.error(`WESkeleton addMount, SpineSlot->addMount: ${mountName} slot does not exist`);
            return;
        }

        // 用单独的属性记录初始透明度，避免再次设置次节点挂点时真实透明度丢失
        if (node['_cache_opacity'] == undefined) {
            node['_cache_opacity'] = node.opacity;
            node['_cache_parent'] = node.parent;
        }

        const boneNode = boneNodes[0];
        node.setParent(boneNode);
        node.setPosition(offset.x, offset.y);

        this._syncMountColorMap.set(node, {
            nodeOpacity: node['_cache_opacity'],
            slotColor: slot.color,
        });

        return this;
    }

    /**
     * 更新节点的color属性
     * @param item
     * @returns
     */
    private updateMountColor(node, item: SyncMountColor) {
        if (!cc.isValid(node, true)) {
            return;
        }
        node.opacity = item.nodeOpacity * (item?.slotColor?.a ?? 1);
    }

    /**
     * 移除多个挂点
     * @param names
     */
    public removeMount(names: string[]): cc.Node[];
    /**
     * 删除所有挂点
     */
    public removeMount(): cc.Node[];
    /**
     * 移除一个挂点
     * @param name
     */
    public removeMount(name: string): cc.Node;
    public removeMount(...args: any[]): any {
        let names = args[0];
        if (Array.isArray(names)) {
            return this._removeMount(names);
        } else {
            names = names ? [names] : null;
            return this._removeMount(names)?.[0] || null;
        }
    }

    private _removeMount(names?: string[]): cc.Node[] {
        const nodes: cc.Node[] = [];
        this._moutList.forEach((item, node) => {
            if (!names || names.includes(item.name)) {
                nodes.push(node);
            }
        });

        for (const node of nodes) {
            this._moutList.delete(node);
            this._syncMountColorMap.delete(node);
            node.setParent(null);
        }
        return nodes;
    }

    /**
     * 清理当前回调中的异步
     * **** 当前动画播放器，每次播放必定会完成之前未完成的动画回调
     * 需要监听动画完成
     * 并且如果不受上次动画完成情况影响的需要调用此方法清除异步回调
     */
    public clearAsync() {
        if (!this._playOb) {
            return this;
        }
        this._playOb.defer = null;
        return this;
    }

    /**
     * @description: 停止播放
     */
    public stop() {
        this.runComplete(true);
        this.clearPlayOb();
    }

    /**
     * @description: 暂停
     * @returns {boolean}
     */
    public pause(): boolean {
        if (this._playOb) {
            this.skeletonComp.paused = true;
            return true;
        }
        return false;
    }

    /**
     * @description: 恢复暂停
     * @returns {boolean}
     */
    public resume(): boolean {
        if (this._playOb) {
            this.skeletonComp.paused = false;
            return true;
        }
        return false;
    }

    /**
     * 设置皮肤
     */
    public setSkin(name: string) {
        this.skeletonComp.setSkin(name);
        return this;
    }

    /**
     * 清理动画数据缓存
     */
    private clearCache() {
        if (this.skeletonComp.isAnimationCached()) {
            this.skeletonComp.invalidAnimationCache();
        }
    }

    update(dt: number) {
        this._syncMountColorMap.forEach((item, node) => {
            this.updateMountColor(node, item);
        });
        this.updateAnimDt(dt);
    }

    private __play() {
        // 没有播放参数则不播放
        if (!this._playOb) {
            return;
        }
        let { animation, startTime } = this._playOb;

        if (this._playOb.animDuration == 0) {
            this._playOb.animDuration = this.getAnimationDuration(animation);
        }

        this._playOb.animElapsed = 0;

        const duration = this._playOb.animDuration;

        // 设置在固定时间点播放
        if (startTime > 0) {
            this._playOb.animElapsed = startTime;
            startTime = this._playOb.startTime = startTime > duration ? startTime % duration : startTime;
        }

        const isChaced = this.skeletonComp.isAnimationCached();

        isChaced ? (this.skeletonComp.animation = animation) : this.skeletonComp.setAnimation(0, animation, false);

        // 非缓存模式设置播放进度
        if (startTime > 0 && !isChaced) {
            const track = this.skeletonComp?.getState()?.getCurrent(0);
            track && (track.trackTime = startTime);
        }

        // 缓存模式设置进度
        if (startTime > 0 && isChaced) {
            // 将时间缩放设置到1，能够正确运行 anim的 update函数
            const timeScale = this.skeletonComp.timeScale;
            this.updateTimeScale(1);

            // h5上将播放时间设置为0
            this.skeletonComp['_accTime'] = 0;

            // 直接更新一帧，将这一帧的时间设置为起始时间
            if (cc.sys.isNative) {
                // 原生上必须使用原生接口
                this.skeletonComp?.['_nativeSkeleton']?.['update']?.(startTime);
            } else {
                // h5 使用h5 接口
                this.skeletonComp['update'](startTime);
            }

            // 设置完成后恢复原来设置的时间缩放
            this.updateTimeScale(timeScale);

            // 设置播放时间
            this.skeletonComp['_accTime'] = startTime;
        }

        this.setTimeScale(this._timeScale);

        this.skeletonComp.loop = false;
        this.skeletonComp.paused = false;

        this.skeletonComp.setCompleteListener(this.completeListener.bind(this));
    }

    // 更新动画播放时长
    protected updateAnimDt(dt: number) {
        // 如果当前没有动画播放则不计入超时
        if (!this._playOb) {
            return;
        }
        const opts = this._playOb;

        if (opts.animElapsed == opts.animDuration) {
            return;
        }
        if (this.skeletonComp.paused) {
            return;
        }

        const timeScale = this.skeletonComp.timeScale;
        if (timeScale <= 0) {
            return;
        }

        dt *= timeScale;
        opts.animElapsed += dt;

        // 超时
        if (opts.animElapsed >= opts.animDuration) {
            this.runComplete(false);
            we.error(`WESkeleton updateAnimDt, anim timeout=> fileName: ${this.skeletonComp.skeletonData.name}, animName: ${this.skeletonComp.animation}`, we.noup);
        }
    }

    private getAnimationDuration(animation: string) {
        let animDuration = 0;
        animDuration = this.skeletonComp.findAnimation(animation)?.duration ?? 0;
        if (animDuration == 0) {
            return 0;
        }
        return animDuration + 1;
    }

    private getAnimNames(): string[] {
        const anims = this.skeletonComp.skeletonData?.skeletonJson?.animations ?? {};
        const animNames = Object.keys(anims);
        return animNames;
    }

    /**
     * 创建播放参数
     * @param param
     * @returns
     */
    private createOb(param?: { animation?: string; times?: number }) {
        /** 如果没有动画数据则不播放 */
        if (!this.skeletonComp.skeletonData) {
            return null;
        }

        // 获取所有动画名称
        const animNames = this.getAnimNames();
        if (animNames.length == 0) {
            return null;
        }

        const animation = param?.animation || this.skeletonComp.animation || animNames[0];
        const times = param?.times ?? 1;
        this._playObId += 1;
        const opts: PlayOb = {
            id: this._playObId,
            animation: animation,
            defer: PromiseHelper.defer(),
            times: times,
            completeTimes: 0,
            animDuration: 0,
            animElapsed: 0,
            onComplete: null,
        };
        return opts;
    }

    /**
     * 清理播放对象
     */
    private clearPlayOb() {
        if (!this._playOb) {
            return;
        }
        this.skeletonComp.setCompleteListener(null);
        this._playOb = null;
    }

    /**
     * 播放结束参数
     * @returns
     */
    private completeListener() {
        if (!this._playOb) {
            return;
        }
        this._playOb.animElapsed = this._playOb.animDuration;
        this.runComplete(false);
    }

    /**
     * 是否强制完成
     * @param force
     * @returns
     */
    private runComplete(force: boolean) {
        if (!this._playOb) {
            return;
        }

        // 已经结束，则不继续强制
        if (force && !this._playOb.defer) {
            return;
        }

        // 重置参数
        this._playOb.animElapsed = this._playOb.animDuration;
        this.skeletonComp.setCompleteListener(null);

        const { onComplete, defer, times } = this._playOb;

        // 次数+1
        this._playOb.completeTimes += 1;

        const isOver = times > 0 && this._playOb.completeTimes >= times;

        // 播放完成移除相关配置
        if (isOver || force) {
            this._playOb.onComplete = null;
            this._playOb.defer = null;
        }

        onComplete?.();

        // 结束异步回调
        if (isOver || force) {
            defer?.resolve?.();
            return;
        }

        // 继续下一次播放
        if (!force && (times < 1 || this._playOb.completeTimes < times)) {
            // 回到起始动作
            this.skeletonComp.setToSetupPose();
            this.__play();
            this._playOb.animElapsed = 0;
        }
    }

    private updateTimeScale(scale: number) {
        if (typeof scale == 'string') {
            we.warn('SpineHelper updateTimeScale scale type error', typeof scale);
            scale = Number(scale);
        }

        if (isNaN(scale)) {
            scale = 1;
            we.warn('WESkeleton updateTimeScale error: scale is NaN');
        }

        this.skeletonComp.timeScale = scale;
    }
}

we.ui.WESkeleton = WESkeleton;
