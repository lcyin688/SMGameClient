import AssetManager from '../../manager/AssetManager';
import { Entity } from '../entity/Entity';

declare global {
    interface ICore {
        PoolComponent: typeof PoolComponent;
    }

    namespace we {
        namespace core {
            type PoolComponent = InstanceType<typeof PoolComponent>;
        }
    }
}

/**
 * 节点池组件
 */
@we.decorator.typeRegister('PoolComponent')
export class PoolComponent extends Entity {
    /** 节点池map */
    public poolMap: Map<string, cc.NodePool>;
    /** 预制体map */
    public prefabMap: Map<string, cc.Prefab>;
    /** 缓存key与资源路径的映射 */
    public cacheKey2PathMap: Map<string, string>;

    protected awake() {
        this.poolMap = new Map<string, cc.NodePool>();
        this.prefabMap = new Map<string, cc.Prefab>();
        this.cacheKey2PathMap = new Map<string, string>();
    }

    protected destroy() {
        // 释放NodePool中缓存的所有节点
        for (let pool of this.poolMap.values()) {
            pool.clear();
        }

        // 释放预制体资源
        for (let cacheUrl of this.prefabMap.keys()) {
            const resUrl = this.cacheKey2PathMap.get(cacheUrl);
            AssetManager.removeAsset(resUrl, cc.Prefab);
        }
    }

    /**
     * 通过预制体路径获取节点
     * @param path 预制体路径
     */
    public get(path: string, alias?: string): cc.Node;
    /**
     * 通过指定Node获取节点
     * @param key 节点Key
     * @param item Node节点
     */
    public get(key: string, item: cc.Node | cc.Prefab): cc.Node;
    public get(...args: any[]): cc.Node {
        if (!this.isValid()) {
            return;
        }

        const key = args[0];
        let cacheKey = key;
        const alias = args[1];
        if (alias && typeof alias === 'string') {
            cacheKey = alias;
        }

        const pool = this.poolMap.get(cacheKey);
        if (pool && pool.size() > 0) {
            return pool.get();
        } else if (this.prefabMap.has(cacheKey)) {
            return cc.instantiate(this.prefabMap.get(cacheKey));
        }

        let node: cc.Node = null;

        const item: cc.Node = args[1];
        if ((item && item instanceof cc.Node) || item instanceof cc.Prefab) {
            node = cc.instantiate(item); // 直接通过节点克隆
        } else {
            node = this.getRes(key, cacheKey); // 通过loadAsset加载克隆
        }
        return node ?? null;
    }

    /**
     * 通过预制体路径获取节点
     * @param path 预制体路径
     * @param alias 预制体缓存key别名
     */
    public async getAsync(path: string, alias?: string): Promise<cc.Node>;
    /**
     * 通过指定Node获取节点
     * @param key 节点Key
     * @param item Node节点
     */
    public async getAsync(key: string, item: cc.Node): Promise<cc.Node>;
    public async getAsync(...args: any[]): Promise<cc.Node> {
        if (!this.isValid()) {
            return;
        }

        const key = args[0];
        let cacheKey = key;
        const alias = args[1];
        if (alias && typeof alias === 'string') {
            cacheKey = alias;
        }
        const pool = this.poolMap.get(cacheKey);
        if (pool && pool.size() > 0) {
            return pool.get();
        } else if (this.prefabMap.has(cacheKey)) {
            return cc.instantiate(this.prefabMap.get(cacheKey));
        }

        let node: cc.Node = null;
        const item: cc.Node = args[1];
        if (item && item instanceof cc.Node) {
            node = cc.instantiate(item); // 直接通过节点克隆
        } else {
            node = await this.getResAsync(key, cacheKey); // 通过loadAsset加载克隆
        }
        return node ?? null;
    }

    /** 归还资源 */
    public put(path: string, node: cc.Node): void {
        if (!this || !this.isValid() || !node || !cc.isValid(node, true)) {
            return;
        }
        let pool = this.poolMap.get(path);
        if (!pool) {
            pool = new cc.NodePool();
            this.poolMap.set(path, pool);
        }
        pool.put(node);
    }

    private getRes(path: string, cacheKey: string): cc.Node {
        const prefabAsset = AssetManager.getAsset(path, cc.Prefab);
        if (prefabAsset) {
            prefabAsset.addRef();
            this.prefabMap.set(cacheKey, prefabAsset);
            this.cacheKey2PathMap.set(cacheKey, path);
            return cc.instantiate(prefabAsset);
        }
    }

    private async getResAsync(path: string, cacheKey: string): Promise<cc.Node> {
        const prefabAsset = await AssetManager.loadAsset(path, cc.Prefab, this);
        if (prefabAsset) {
            prefabAsset.addRef();
            this.prefabMap.set(cacheKey, prefabAsset);
            this.cacheKey2PathMap.set(cacheKey, path);
            return cc.instantiate(prefabAsset);
        }
    }
}

we.core.PoolComponent = PoolComponent;
