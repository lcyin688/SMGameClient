import { type IDisposable } from '../entity/IDisposable';

declare global {
    interface ICore {
        Singleton: typeof Singleton;
    }

    namespace we {
        namespace core {
            type Singleton = InstanceType<typeof Singleton>;
        }
    }
}

export interface ISingleton extends IDisposable {
    register<T extends Singleton>(type: new () => T): void;
    destroy<T extends Singleton>(type: new () => T): void;
    isDispose(): boolean;
}

/**
 * 静态接口约束
 */
export interface ISingletonInstance {
    Inst: any;
}

export abstract class ISingletonAwake {
    abstract awake(): void;
}

export abstract class ISingletonUpdate {
    abstract update(): void;
}

export abstract class ISingletonLateUpdate {
    abstract lateUpdate(): void;
}

export abstract class Singleton implements ISingleton {
    protected static instances = new Map<any, any>();

    private isDisposed = false;

    protected static getInstance<U extends Singleton>(this: new (...args) => U): U {
        return Singleton.instances.get(this);
    }

    register<T extends Singleton>(type: new () => T) {
        if (Singleton.instances.has(type)) {
            throw new Error(`singleton register twice! ${typeof type}`);
        }
        Singleton.instances.set(type, this);
    }

    destroy<T extends Singleton>(type: new () => T): void {
        if (this.isDisposed) {
            return;
        }

        this.isDisposed = true;
        this.dispose();
        Singleton.instances.delete(type);
    }

    isDispose(): boolean {
        return this.isDisposed;
    }

    public dispose(): void {
        // do something to dispose
    }
}

we.core.Singleton = Singleton;
