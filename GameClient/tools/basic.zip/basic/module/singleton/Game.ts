import { DoubleMap } from '../algorithms/DoubleMap';
import { type ISingleton, type ISingletonAwake, type ISingletonLateUpdate, type ISingletonUpdate, type Singleton } from './Singleton';
import { AsyncTask } from '../async/AsyncTask';

declare global {
    interface ICore {
        Game: typeof Game;
    }
}

export class Game {
    private static readonly singletonTypes: DoubleMap<any, ISingleton> = new DoubleMap<any, ISingleton>();

    private static readonly singletons: ISingleton[] = [];
    private static readonly updates: ISingleton[] = [];
    private static readonly lateUpdates: ISingleton[] = [];
    private static readonly frameFinishTask: AsyncTask[] = [];

    public static addSingleton<T extends Singleton>(TYPE: new () => T): T {
        const singleton: T = new TYPE();
        this.addSingletonInstance(TYPE, singleton);
        return singleton;
    }

    public static addSingletonInstance<T extends Singleton>(TYPE: new () => T, singleton: ISingleton): void {
        const singletonType: string = singleton.constructor.name;
        if (Game.singletonTypes.getValueByKey(singletonType)) {
            throw new Error(`already exist singleton: ${singletonType}`);
        }

        Game.singletonTypes.add(singletonType, singleton);
        Game.singletons.push(singleton);
        singleton.register(TYPE);

        if (this.implementsInterface(singleton, 'awake')) {
            (singleton as unknown as ISingletonAwake).awake();
        }

        if (this.implementsInterface(singleton, 'update')) {
            Game.updates.push(singleton);
        }

        if (this.implementsInterface(singleton, 'lateUpdate')) {
            Game.lateUpdates.push(singleton);
        }
    }

    public static async waitFrameFinish(): Promise<void> {
        const task = AsyncTask.create<boolean>();
        Game.frameFinishTask.push(task);
        await task.wait();
    }

    public static update(): void {
        let count = Game.updates.length;
        while (count-- > 0) {
            const singleton = Game.updates.shift();

            if (singleton.isDispose()) {
                continue;
            }

            Game.updates.push(singleton);
            try {
                (singleton as unknown as ISingletonUpdate).update();
            } catch (err) {
                we.error(`Game update, singleton update err: ${JSON.stringify(err.message || err)}`);
            }
        }
    }

    public static lateUpdate(): void {
        let count = Game.lateUpdates.length;
        while (count-- > 0) {
            const singleton = Game.lateUpdates.shift();

            if (singleton.isDispose()) {
                continue;
            }

            Game.lateUpdates.push(singleton);
            try {
                (singleton as unknown as ISingletonLateUpdate).lateUpdate();
            } catch (err) {
                we.error(`Game lateUpdate, singleton lateUpdate err: ${JSON.stringify(err.message || err)}`);
            }
        }
    }

    public static frameFinishUpdate(): void {
        while (Game.frameFinishTask.length > 0) {
            const task = Game.frameFinishTask.shift();
            task.setResult(true);
        }
    }

    public static close(): void {
        // 顺序反过来清理
        while (Game.singletons.length > 0) {
            const iSingleton = Game.singletons.pop();
            iSingleton.destroy(Game.singletonTypes.getKeyByValue(iSingleton));
        }

        for (let key of Object.keys(Game.singletonTypes)) {
            Game.singletonTypes.removeByKey(key);
        }
    }

    /**
     * 是否实现指定接口
     * @param obj
     * @param method
     */
    private static implementsInterface(obj: any, method: string): boolean {
        return obj && typeof obj[method] === 'function';
    }
}

we.core.Game = Game;
