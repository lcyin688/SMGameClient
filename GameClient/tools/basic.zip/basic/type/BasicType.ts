import { Func } from '../module/func/Func';
import { FuncAsync } from '../module/func/FuncAsync';

declare global {
    interface ICore {
        type: typeof BasicType;
    }
    namespace we {
        type ProtoClientConfig = BasicType.ProtoClientConfig;
        type IAdjustConf = BasicType.IAdjustConf;

        namespace core {
            type StorageTable = BasicType.StorageTable;
            type Callback<E> = Func<(msg: E) => void> | Func<(self: Entity, msg: E) => void> | FuncAsync<(msg: E) => Promise<void>> | FuncAsync<(self: Entity, msg: E) => Promise<void>>;
            type GuideTmp = BasicType.GuideTmp;
            type IntersectionFromUnion<U> = BasicType.IntersectionFromUnion<U>;
            type WithOptionalParameters<T extends any[], U extends any[]> = BasicType.WithOptionalParameters<T, U>;
            type ProtectedMethodParams<T, K extends keyof T> = BasicType.ProtectedMethodParams<T, K>;
            type AssetPreloadConfig = BasicType.AssetPreloadConfig;
        }
    }
}

export namespace BasicType {
    /** 自研游戏厂商ID */
    export const SDGameVendorId = 0;
    /** 自研游戏最大游戏ID  */
    export const SDGameMaxGameId = 9999;
    /** 游戏厂商事件前缀 */
    export const GameVendorEventPrefix = 'gameVendor';

    /** 默认版本 */
    export const VersionDefault = '1.0.0';

    export interface ProtoClientConfig {
        protoMsgId: object;
        req2Res: object;
        proto: string;
    }

    export enum GameReturnType {
        /** 返回游戏大厅 */
        BackHall = 1,
        /** 返回代理门户网站 */
        BackAgency = 2,
    }

    /** adjust 配置 */
    export interface IAdjustConf {
        /** adjust_app_token */
        appToken: string;
        /** 事件 token */
        eventList: { eventName: string; eventToken: string }[];
        /** 是否客户端上报 */
        isClientReport: boolean;
    }

    interface SysStorageInfo {
        /** 设备 id */
        app_device_id: string;
        /** 语言 code */
        app_language_code: string;
        /** 音乐大小 */
        app_music_volume: number;
        /** 音效大小 */
        app_effect_volume: number;
        /** 记录 app 通知授权状态 */
        app_permission_notification: string;
        /** 域名缓存 */
        app_domain_list: string[];
        /** app 安装引荐 */
        app_install_referrer: string;
        /** adjust 配置 */
        app_adjust_config: IAdjustConf;
        /** adjust 归因数据 campaign 上报服务器状态标识  */
        app_adjust_campaign_tag: boolean;
        /** main 更新版本记录 {bundName: version} */
        app_bundle_update_record: { [bundName: string]: string };
        /** 热更：vest首次启动 状态记录, 数据格式: { [track_vest_{事件名 | 事件 token }: string]: string } */
        app_track_game_updated: {};
        /** 浏览器隐藏参数 数据格式:{ [`url_key_${urlParam}`]: any } */
        url_key: {};

        /** userId */
        user_id: number;
        /** token */
        user_token: string;
        /** 用户创建渠道 */
        user_create_channel: string;
        /** 马甲包免密更换时，临时登录 tag */
        user_tmp_token_login_tag: number;
        /** 获取临时登录 token 标记 */
        user_get_tmp_token_login_tag: number;

        /** 设备账号情况 0-没有绑定账户 1-只有游客账户 2-只有正式账户 3-游客账户正式账户都有 */
        user_account_guest_status: number;
        /** 品牌自定义登录背景地址 横版 */
        brand_loading_bg_url: string;
        /** 品牌自定义登录背景地址 竖版 */
        brand_loading_bg_url_v: string;
    }

    export class ProtoHeader {
        static readonly XAuthToken = 'X-Auth-Token';
    }

    export interface StorageTable {
        sys: SysStorageInfo;
    }

    export interface HotCacheData {
        bundle: Record<string, undefined>;
    }

    /**
     * 类型指定字段变成必选
     */
    export type MakeRequired<T, K extends keyof T> = Required<Pick<T, K>> & Omit<T, K>;

    type MapTopParameter<U> = U extends any ? (arg: U) => void : never;
    /**
     * 联合类型转交叉类型(交集转并集)
     *```
     * type A = {a: 2}
     * type B = {b: 3}
     * type C = {c: 4}
     * type Result = IntersectionFromUnion<A | B | C> // 将类型 A | B | C 转换成了 类型A & B & C
     *```
     */
    export type IntersectionFromUnion<U> = MapTopParameter<U> extends (arg: infer T) => void ? T : never;

    /**
     * 推导方法参数，不存在返回never
     */
    export type MethodParams<T, K extends keyof T> = K extends keyof T
        ? // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          Parameters<T[K]>
        : never;

    /**
     * 推导方法参数,支持受保护的方法
     */
    export type ProtectedMethodParams<T, K extends keyof T> = T[K] extends (...args: infer P) => any ? P : never;

    /**
     * 推导类中所有方法的参数类型
     */
    export type ClassMethodParams<T> = {
        [K in keyof T as T[K] extends (...args: any[]) => any ? K : never]: MethodParams<T, K>;
    };

    /**
     * 排除第一个参数的类型
     */
    export type ExcludeFirstParameter<T extends any[]> = T extends [any, ...infer Rest] ? Rest : [];

    /**
     * 动态添加参数
     */
    export type WithOptionalParameters<T extends any[], U extends any[]> = [T] extends [never] ? [...Partial<U>] : [...T, ...Partial<U>];

    /**
     * 引导配置模板
     */
    export interface GuideTmp {
        /** 引导名称 */
        name: string;
        /** 引导序号 */
        index: number;
        /** 点击遮罩是否跳过,默认跳过 */
        clickMaskJump?: boolean;
        /**
         * 是否使用引导节点本身点击事件, 默认 false：如果使用节点本身事件则不会触发 onGuideClick 回调
         */
        isUseGuideNodeClick?: boolean;
        /** 是否开启引导，如果不开启，则不会放进引导队列 */
        isGuide: () => boolean;
        /**
         *返回引导节点
         */
        guideNode: () => cc.Node;
        /**
         * 显示引导时
         * @param name 引导名
         * @param index 序号
         * @param guideNode 节点
         * @param opts 选项
         * @param opts.mask 引导遮罩节点
         * @param opts.next 开始下一个引导，nameOrIndex?: 下一个引导的序号或者名称，不填默认第一个序号开始
         * @param opts.setGroup 设置某个节点为引导层节点
         */
        onGuideShow: (opts: { guideNode: cc.Node; mask: cc.Node; setGroup: (node: cc.Node) => void }) => Promise<void> | void;
        /**
         * 引导完成时,下一个引导开始之前，所有引导结束
         * @param name
         * @param index
         * @param guideNode
         * @param opts 选项
         * @param opts.mask 引导遮罩节点
         * @param opts.setGroup 设置节点显示到引导层
         * @param opts.isJump 是否跳过了引导
         * @param opts?.next 开始下一个引导，nameOrIndex?: 下一个引导的序号或者名称，不填默认第一个序号开始
         */
        onGuideComplete: (opts: { guideNode: cc.Node; mask: cc.Node; setGroup: (node: cc.Node) => void; isJump: boolean }) => Promise<void> | void;
        /**
         * 引导内容被点击
         * @param name
         * @param index
         * @param guideNode
         * @param opts 选项
         * @param opts.mask 引导遮罩节点
         * @param opts.next 开始下一个引导，nameOrIndex?: 下一个引导的序号或者名称，不填默认第一个序号开始
         * @returns boolean 点击是否穿透节点
         */
        onGuideClick?: (opts: { guideNode: cc.Node; mask: cc.Node; setGroup: (node: cc.Node) => void }) => Promise<boolean> | boolean;

        /**
         * 下一个引导
         * @param currName 当前引导名
         * @param currIndex 当前引导下标
         * @returns  number | string 如果返回 -1 则自动默认序号+1引导
         */
        next?: (currName: string, currIndex: number, isJump: boolean) => number | string;
    }

    /** 预加载配置 */
    export type AssetPreloadConfig = {
        /** 资源路径, 指定文件或者目录 */
        path: string;
        /** 资源类型 */
        type?: typeof cc.Asset;
        /** 优先级：0～9 (默认0, 越大越优先) */
        priority?: number;
        /** 不打印日志，过滤部分不需要检查的资源 */
        noLog?: boolean;
    }[];
}

we.core.type = BasicType;
