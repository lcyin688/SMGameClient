import { IWaitType } from '../module/async/ObjectWait';
import { Scene } from '../module/scene/Scene';

declare global {
    interface ICore {
        EventObjectWait: typeof EventObjectWait;
        eventInvoke: typeof EventInvoke;
        eventType: typeof EventType;
    }
    interface TCore {
        EventMsg: EventMsg;
    }
    namespace we {
        namespace core {
            type EventObjectWait = typeof EventObjectWait;
            /**
             * 事件消息定义
             */
            type EventMsg = TCore['EventMsg'];

            /**
             * ECS 方法调用
             */
            namespace eventInvoke {
                type SceneEnter = EventInvoke.SceneEnter;
                type SceneLeave = EventInvoke.SceneLeave;
                type ReportLanguage = EventInvoke.ReportLanguage;
            }

            /**
             * ECS 事件定义
             */
            namespace eventType {
                type SceneSelector = EventType.SceneSelector;
            }
        }
    }
}

/**
 * 事件消息定义
 */
export interface EventMsg {
    /** 皮肤变化 */
    SkinChanged: string;
    /** 语言变化 */
    LangChanged: string;
    /** Token变化 */
    Token: string;
    /** 加载进度 */
    LoadingProgress: number;
    /** 是否后台运行 */
    IsHide: boolean;
    /** 窗口大小变化 */
    WindowResize: boolean;
    /** 启动指定场景 */
    LaunchScene: number;
    /** 是否进入离线模式 */
    OfflineMode: boolean;
    /** 场景准备就绪 */
    SceneReady: boolean;
    /** 场景切换之前 */
    SceneChangeStart: boolean;
    /** 场景切换完成 */
    SceneChangeEnd: boolean;
}

export namespace EventObjectWait {
    /**
     * 进入场景准备就绪
     */
    @we.decorator.typeRegister('SceneReady')
    export class SceneReady extends IWaitType {
        /**
         * @param err 场景准备结果错误码
         */
        constructor(public err: we.core.WaitTypeError) {
            super();
        }
    }
}

we.core.EventObjectWait = EventObjectWait;

/**
 * ECS 方法调用
 */
export namespace EventInvoke {
    /** 进入场景 */
    @we.decorator.typeRegister('SceneEnter')
    export class SceneEnter {
        /**
         * 构造参数
         * @param current 当前场景
         * @param loadingShowFinish 场景loading显示完成回调
         * @param gameUrl h5游戏链接
         */
        constructor(
            public current: Scene,
            public loadingShowFinish: () => Promise<void>,
            public gameUrl?: string
        ) {}
    }

    /** 离开场景 */
    @we.decorator.typeRegister('SceneLeave')
    export class SceneLeave {
        constructor(public current: Scene) {}
    }

    /** 上报语言 */
    @we.decorator.typeRegister('ReportLanguage')
    export class ReportLanguage {
        constructor(public langCode: string) {}
    }
}

we.core.eventInvoke = EventInvoke;

/**
 * ECS 事件定义
 */
export namespace EventType {
    /** 场景选择器 */
    @we.decorator.typeRegister('SceneSelector')
    export class SceneSelector {
        constructor(public bundle: string) {}
    }
}

we.core.eventType = EventType;
