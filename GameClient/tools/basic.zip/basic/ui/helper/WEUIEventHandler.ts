import { Func } from '../../module/func/Func';
import { FuncAsync } from '../../module/func/FuncAsync';
import { UIType } from '../core/UIType';

const { ccclass, menu } = cc._decorator;

type Event = 'slider' | 'toggle' | UIType.EditBoxEvent | UIType.ScrollViewEvent;

/**
 * 代理UI事件：Toggle/Sliderd等
 */
@ccclass
@menu('we/other/WEUIEventHandler(Cocos组件事件代理)')
@we.decorator.typeRegister('WEUIEventHandler')
export class WEUIEventHandler extends cc.Component {
    handlers = new Map<Event, Func<any> | FuncAsync<any> | Function>();

    static isClicked: boolean;

    public setHandler(event: Event, handler: Func<any> | FuncAsync<any> | Function) {
        if (handler) {
            this.handlers.set(event, handler);
        } else {
            this.handlers.delete(event);
        }
    }

    /** *
     * 接受Toggle事件，并转发给真正的处理函数
     * */
    protected onToggleEvent(toggle: cc.Toggle) {
        const toggleData = toggle['customEventData'];

        let handler = this.handlers.get('toggle');
        if (!handler) {
            return;
        }

        if (handler instanceof FuncAsync) {
            this.onToggleAsync(toggle, toggleData).catch(() => {});
        } else if (handler instanceof Func) {
            handler.exec(toggle, toggleData);
        } else {
            handler(toggle, toggleData);
        }
    }

    private async onToggleAsync(toggle: cc.Toggle, toggleData: any) {
        let handler = this.handlers.get('toggle');

        // 防止重复点击
        if (WEUIEventHandler.isClicked) {
            return;
        }

        try {
            WEUIEventHandler.isClicked = true;
            await (handler as FuncAsync<any>).exec(toggle, toggleData);
        } finally {
            WEUIEventHandler.isClicked = false;
        }
    }

    /**
     * @en recieve slide event and deliver them to the real handlers.
     * @zh 接受 Slide 事件，并转发给真正的处理函数
     * */
    protected onSliderEvent(slider: cc.Slider, customEventData: any) {
        let handler = this.handlers.get('slider');
        if (!handler) {
            return;
        }

        if (handler instanceof FuncAsync) {
            this.onSliderAsync(slider, customEventData).catch(() => {});
        } else if (handler instanceof Func) {
            handler.exec(slider, customEventData);
        } else {
            handler(slider, customEventData);
        }
    }

    private async onSliderAsync(slider: cc.Slider, customEventData: any) {
        let handler = this.handlers.get('slider');
        // 防止重复点击
        if (WEUIEventHandler.isClicked) {
            return;
        }

        try {
            WEUIEventHandler.isClicked = true;
            await (handler as FuncAsync<any>).exec(slider, customEventData);
        } finally {
            WEUIEventHandler.isClicked = false;
        }
    }

    protected onEditingDidBegan(editBox: cc.EditBox) {
        let handler = this.handlers.get('editingDidBegan');
        if (!handler) {
            return;
        }

        if (handler instanceof FuncAsync) {
            this.onEditBoxHandlerAsync(editBox, handler).catch(() => {});
        } else if (handler instanceof Func) {
            handler.exec(editBox);
        } else {
            handler(editBox);
        }
    }

    protected onTextChanged(value: string, editBox: cc.EditBox) {
        let handler = this.handlers.get('textChanged');
        if (!handler) {
            return;
        }

        if (handler instanceof FuncAsync) {
            this.onEditBoxHandlerAsync(editBox, handler, value).catch(() => {});
        } else if (handler instanceof Func) {
            handler.exec(value, editBox);
        } else {
            handler(value, editBox);
        }
    }

    protected onEditingDidEnded(editBox: cc.EditBox) {
        let handler = this.handlers.get('editingDidEnded');
        if (!handler) {
            return;
        }

        if (handler instanceof FuncAsync) {
            this.onEditBoxHandlerAsync(editBox, handler).catch(() => {});
        } else if (handler instanceof Func) {
            handler.exec(editBox);
        } else {
            handler(editBox);
        }
    }

    protected onEditingReturn(editBox: cc.EditBox) {
        let handler = this.handlers.get('editingReturn');
        if (!handler) {
            return;
        }

        if (handler instanceof FuncAsync) {
            this.onEditBoxHandlerAsync(editBox, handler).catch(() => {});
        } else if (handler instanceof Func) {
            handler.exec(editBox);
        } else {
            handler(editBox);
        }
    }

    private async onEditBoxHandlerAsync(editBox: cc.EditBox, handler: FuncAsync<any> | Function, value?: string) {
        // 防止重复点击
        if (WEUIEventHandler.isClicked) {
            return;
        }

        try {
            WEUIEventHandler.isClicked = true;
            if (value) {
                await (handler as FuncAsync<any>).exec(value, editBox);
            } else {
                await (handler as FuncAsync<any>).exec(editBox);
            }
        } finally {
            WEUIEventHandler.isClicked = false;
        }
    }

    protected onScrollViewEvent(scrollview: cc.ScrollView, event: cc.ScrollView.EventType) {
        let eventName = cc.ScrollView.EventType[event];
        if (!eventName) {
            return;
        }

        eventName = eventName.toLowerCase().replace(/_/g, '-');
        let handler = this.handlers.get(<Event>eventName);
        if (!handler) {
            return;
        }

        if (handler instanceof Func) {
            handler.exec(scrollview);
        } else {
            handler(scrollview);
        }
    }
}
