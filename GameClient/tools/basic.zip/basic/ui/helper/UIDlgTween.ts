import { AsyncTask } from '../../module/async/AsyncTask';
import { UIBase } from '../core/UIBase';
import { UIType } from '../core/UIType';

declare global {
    interface IUI {
        UIDlgTween: typeof UIDlgTween;
    }
}

export class UIDlgTween {
    /**
     * 默认UI打开动画
     * @param uiBase
     */
    static async open(uiBase: UIBase) {
        const task = AsyncTask.create();
        // opacity为0时，无法保证在onShow阶段，保证Layout组件下子节点正常更新节点大小、位置等，所以修改为1.
        uiBase.uiRoot.opacity = 1;

        // 渐显
        if (uiBase.uiConfig.viewType !== UIType.UIViewType.Popup) {
            // 全屏默认渐显即可
            cc.tween(uiBase.uiRoot)
                .to(uiBase.uiConfig.openTime, { opacity: uiBase.nodeRawData.rootOpacity })
                .call(() => {
                    task.setResult(true);
                })
                .start();
        } else {
            let uiContentWidget = uiBase.uiContent.getComponent(cc.Widget);
            if (uiContentWidget) {
                if (!uiContentWidget.enabled) {
                    uiContentWidget = null;
                } else {
                    // 在禁用预制体上的 widget 之前，延迟 1 帧，保证节点的 enabled 执行完毕，避免 ui widget、layout 影响 ui 位置的组件未刷新
                    await we.core.timer.scheduleOnce(0);
                    uiContentWidget.enabled = false;
                }
            }

            cc.tween(uiBase.uiContent)
                .set({ scale: 0.3 })
                .to(uiBase.uiConfig.openTime, { scale: uiBase.nodeRawData.contentScale }, { easing: 'backOut' })
                .call(() => {
                    if (uiContentWidget) {
                        uiContentWidget.enabled = true;
                    }
                })
                .start();

            cc.tween(uiBase.uiRoot)
                .to(uiBase.uiConfig.openTime, { opacity: uiBase.nodeRawData.rootOpacity })
                .call(() => {
                    task.setResult(true);
                })
                .start();
        }

        await task.wait(uiBase.uiConfig.openTime, uiBase);
    }

    /**
     * 默认UI关闭动画
     * @param uiBase
     */
    static async close(uiBase: UIBase) {
        const task = AsyncTask.create();
        // 渐隐
        if (uiBase.uiConfig.viewType !== UIType.UIViewType.Popup) {
            // 全屏默认渐隐即可
            cc.tween(uiBase.uiRoot)
                .to(uiBase.uiConfig.closeTime, { opacity: 1 })
                .call(() => {
                    task.setResult(true);
                })
                .start();
        } else {
            let uiContentWidget = uiBase.uiContent.getComponent(cc.Widget);
            if (uiContentWidget) {
                if (!uiContentWidget.enabled) {
                    uiContentWidget = null;
                } else {
                    // 在禁用预制体上的 widget 之前，延迟 1 帧，保证节点的 enabled 执行完毕，避免 ui widget、layout 影响 ui 位置的组件未刷新
                    await we.core.timer.scheduleOnce(0);
                    uiContentWidget.enabled = false;
                }
            }
            cc.tween(uiBase.uiContent)
                .to(uiBase.uiConfig.closeTime, { scale: 0.45 }, { easing: 'backIn' })
                .call(() => {
                    if (uiContentWidget) {
                        uiContentWidget.enabled = true;
                    }
                })
                .start();
            cc.tween(uiBase.uiRoot)
                .to(uiBase.uiConfig.closeTime, { opacity: 1 })
                .call(() => {
                    task.setResult(true);
                })
                .start();
        }

        await task.wait(uiBase.uiConfig.closeTime);
    }

    /**
     * 顶部掉落显示
     * @param uiBase
     */
    static async topOpen(uiBase: UIBase) {
        const task = AsyncTask.create();
        // opacity为0时，无法保证在onShow阶段，保证Layout组件下子节点正常更新节点大小、位置等，所以修改为1.
        uiBase.uiRoot.opacity = 1;
        const height = uiBase.uiRoot.height;
        const contentY = uiBase.uiContent.y;
        const delta = (height - uiBase.uiContent.height) / 2;
        uiBase.uiContent.y = uiBase.uiContent.height + delta;

        cc.tween(uiBase.uiContent).to(uiBase.uiConfig.openTime, { y: contentY }, { easing: 'backOut' }).start();

        cc.tween(uiBase.uiRoot)
            .to(uiBase.uiConfig.openTime, { opacity: uiBase.nodeRawData.rootOpacity })
            .call(() => {
                task.setResult(true);
            })
            .start();

        await task.wait(2 * uiBase.uiConfig.openTime, uiBase);
    }

    /**
     * 顶部掉落关闭
     * @param uiBase
     */
    static async topClose(uiBase: UIBase) {
        const task = AsyncTask.create();

        const height = uiBase.uiRoot.height;
        const delta = (height - uiBase.uiContent.height) / 2;

        cc.tween(uiBase.uiContent)
            .to(uiBase.uiConfig.closeTime, { y: height + delta }, { easing: 'backIn' })
            .start();

        cc.tween(uiBase.uiRoot)
            .to(uiBase.uiConfig.closeTime, { opacity: 1 })
            .call(() => {
                task.setResult(true);
            })
            .start();

        await task.wait(2 * uiBase.uiConfig.closeTime, uiBase);
    }
}

we.ui.UIDlgTween = UIDlgTween;
