import { UIDlgTween } from './UIDlgTween';

declare global {
    interface IUI {
        /** 场景缓动工具 */
        anim: typeof SceneAnimHelper;
        /** open动画类型 */
        animOpenType: typeof SceneAnimOpenType;
        /** close动画类型 */
        animCloseType: typeof SceneAnimCloseType;
    }
}

export enum SceneAnimOpenType {
    /** 系统默认 */
    SYS = 0,
    /** 无效果 */
    NONE = 1,
    /** 右边划入 */
    RIGHT_IN = 2,
    /** 顶部掉落 */
    TOP_DROP = 3,
}

export enum SceneAnimCloseType {
    /** 系统默认 */
    SYS = 0,
    /** 无效果 */
    NONE = 1,
    /** 右边划出 */
    RIGHT_OUT = 2,
    /** 底部弹出 */
    BOTTOM_POP = 3,
}

export default class SceneAnimHelper {
    /** 播放 open 动画 */
    public static async openAnim(uiBase: we.ui.UIBase, type: SceneAnimOpenType) {
        switch (type) {
            case SceneAnimOpenType.NONE:
                uiBase.uiRoot.active = true;
                uiBase.uiRoot.opacity = uiBase.nodeRawData.rootOpacity;
                break;
            case SceneAnimOpenType.RIGHT_IN:
                await this.rightOpen(uiBase);
                break;
            case SceneAnimOpenType.TOP_DROP:
                await UIDlgTween.topOpen(uiBase);
                break;
            default:
                await UIDlgTween.open(uiBase);
                break;
        }
    }

    /** 播放 close 动画 */
    public static async closeAnim(uiBase: we.ui.UIBase, type: SceneAnimCloseType) {
        switch (type) {
            case SceneAnimCloseType.NONE:
                uiBase.uiRoot.active = false;
                break;
            case SceneAnimCloseType.RIGHT_OUT:
                await this.rightClose(uiBase);
                break;
            case SceneAnimCloseType.BOTTOM_POP:
                await UIDlgTween.topClose(uiBase);
                break;
            default:
                await UIDlgTween.close(uiBase);
                break;
        }
    }

    /** 右边划入开启 */
    static async rightOpen(uiBase: we.ui.UIBase) {
        const task = we.core.AsyncTask.create();
        uiBase.uiRoot.opacity = 255;
        const width = uiBase.uiRoot.width;
        const contentX = uiBase.uiContent.x;
        const delta = (width - uiBase.uiContent.width) / 2;
        uiBase.uiContent.x = uiBase.uiContent.width + delta;
        cc.tween(uiBase.uiContent).to(uiBase.uiConfig.openTime, { x: contentX }, { easing: 'backOut' }).start();
        cc.tween(uiBase.uiRoot)
            .to(uiBase.uiConfig.openTime, { opacity: uiBase.nodeRawData.rootOpacity })
            .call(() => {
                task.setResult(true);
            })
            .start();
        await task.wait(2 * uiBase.uiConfig.openTime, uiBase);
    }

    /** 右边划出关闭 */
    static async rightClose(uiBase: we.ui.UIBase) {
        const task = we.core.AsyncTask.create();

        const width = uiBase.uiRoot.width;
        const delta = (width - uiBase.uiContent.width) / 2;

        cc.tween(uiBase.uiContent)
            .to(uiBase.uiConfig.closeTime, { x: width + delta }, { easing: 'backIn' })
            .call(() => {
                task.setResult(true);
            })
            .start();

        await task.wait(2 * uiBase.uiConfig.closeTime, uiBase);
    }
}

we.ui.anim = SceneAnimHelper;
