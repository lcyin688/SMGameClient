import { WEReferenceCollector } from '../../module/resCollector/WEReferenceCollector';
import { WEUIViewCollector } from '../../module/resCollector/WEUIViewCollector';
import { WEI18nFont } from '../i18n/WEI18nFont';
import { WEI18nLabelLite } from '../i18n/WEI18nLabelLite';

declare global {
    interface IUI {
        UIHelper: typeof UIHelper;
    }
}

export class UIHelper {
    /**
     * 设置UI多语言文本
     * @param rc 节点收集器
     * @param langs 多语言key集合
     */
    public static setUILangText(rc: WEReferenceCollector | WEUIViewCollector, langs: object, params?: object) {
        if (!langs || !rc) {
            return;
        }

        params ??= {};

        let nodes: cc.Node[] = rc.getsByReg(/^LANG_/, cc.Node);
        for (let node of nodes) {
            node.addComponentUnique(WEI18nFont);
            let stringCmp = node.addComponentUnique(WEI18nLabelLite);
            if (!stringCmp) {
                we.warn(`UIHelper setUILangText, node ${node.name} not has WEI18nLabelLite`);
                continue;
            }
            const langKey = node.name.replace('LANG_', '');
            const langParam = params[langKey];
            if (langParam) {
                if (langParam instanceof Array) {
                    stringCmp.setFormatResId(langs[langKey], ...langParam);
                } else {
                    stringCmp.setFormatResId(langs[langKey], langParam);
                }
            } else {
                stringCmp.langId = langs[langKey];
            }
        }
    }
}

we.ui.UIHelper = UIHelper;
