export class UIScreenshot {
    /** 同步截取屏幕 */
    static captureScreenSync() {
        const rt = new cc.RenderTexture();
        let { width, height } = cc.winSize;
        // 像素数据为(长 x 高 x 4) 的 Uint8Array，所以长、宽必须为整数
        width = Math.floor(width);
        height = Math.floor(height);
        rt.initWithSize(width, height, (<any>cc).gfx.RB_FMT_S8);

        const uiRoot = cc.find('Global');

        let cameraNode = new cc.Node('camera_node');
        uiRoot.addChild(cameraNode);

        let camera = cameraNode.addComponent(cc.Camera);
        camera.alignWithScreen = false;
        camera.orthoSize = height / 2;
        camera.targetTexture = rt;
        camera.render();

        let pixels = rt.readPixels();
        cameraNode.destroy();

        // flipY
        let data = new Uint8Array(width * height * 4);
        let rowBytes = width * 4;
        for (let row = 0; row < height; row++) {
            let start = (height - 1 - row) * width * 4;
            let reStart = row * width * 4;
            for (let i = 0; i < rowBytes; i++) {
                let index = reStart + i;
                data[index] = pixels[start + i];
                if (index % 4 == 3) {
                    // fillA
                    if (data[index] != 0) {
                        data[index] = 255;
                    }
                }
            }
        }

        let texture2d = new cc.Texture2D();
        texture2d.initWithData(<any>data, (<any>cc).gfx.TEXTURE_FMT_RGBA8, width, height);

        let spriteFrame = new cc.SpriteFrame();
        spriteFrame.setTexture(texture2d);

        let captureNode = new cc.Node();
        captureNode.x = 0;
        captureNode.y = 0;
        captureNode.width = width;
        captureNode.height = height;
        captureNode.addComponent(cc.Sprite).spriteFrame = spriteFrame;

        return captureNode;
    }
}
