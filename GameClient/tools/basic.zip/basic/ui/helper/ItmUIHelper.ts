import AssetManager from '../../manager/AssetManager';
import { Entity } from '../../module/entity/Entity';
import { PoolComponent } from '../../module/nodepool/PoolComponent';
import { UIType } from '../core/UIType';

declare global {
    interface IUI {
        ItmUIHelper: typeof ItmUIHelper;
    }
}

/** 定义 ExcludeFirstParam 用来从方法签名中排除第一个参数 */
type ExcludeFirstParam<T extends any[]> = T extends [infer _, ...infer Rest] ? Rest : [];
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-expect-error
type CreateByNodeParamsType<T> = we.core.ProtectedMethodParams<T, 'awake'>;
type CreateWithoutNode<T> = ExcludeFirstParam<CreateByNodeParamsType<T>>;

export class ItmUIHelper {
    /**
     * 异步创建Item模块
     * @param viewId view id
     * @param ItemClass Item逻辑类
     * @param parent Entity组件父节点
     * @param options 创建选项
     * @param options.usePool 是否使用对象池，默认使用对象池
     * @returns
     */
    public static async createItemAsync<T extends we.ui.ItmSystem>(viewId: UIType.ViewId, ItemClass: new () => T, parent: Entity, options?: we.ui.ItmOption, ...args: CreateWithoutNode<T>): Promise<T | null> {
        options ??= { usePool: true };
        options.isChild ??= true;

        const preInstanceId = parent.InstanceId;
        let itemNode: cc.Node = null;
        let poolKey = options.subViewId != null ? `${viewId}:${options.subViewId}` : viewId;
        if (options?.usePool) {
            itemNode = await parent.Scene.getComponent(PoolComponent).getAsync(viewId, poolKey);
            if (!itemNode) {
                we.warn(`ItmUIHelper createItemAsync, viewId=${viewId} not found`);
                return null;
            }
        } else {
            let itemPrefab = await AssetManager.loadAsset(viewId, cc.Prefab, parent);
            if (!itemPrefab) {
                we.warn(`ItmUIHelper createItemAsync, loadAsset viewId=${viewId} not found`);
                return null;
            }
            itemNode = cc.instantiate(itemPrefab);
        }

        if (parent.InstanceId !== preInstanceId) {
            return null;
        }

        // @ts-ignore
        args.unshift(itemNode);
        // @ts-ignore
        args.push({ isFromPool: options?.usePool });

        let item: T = null;
        if (options.isChild) {
            item = await parent.addChildAsync<T>(ItemClass, ...(<any>args));
        } else {
            item = await parent.addComponentAsync<T>(ItemClass, ...(<any>args));
        }

        if (options?.position) {
            item.view.uiRoot.setPosition(options.position);
        }
        if (options?.parent) {
            item.view.uiRoot.parent = options.parent;
        }

        item.setDestroyFunc(
            we.core.Func.create((itemSystem: T) => {
                if (options?.usePool) {
                    return parent.Scene.getComponent(PoolComponent).put(poolKey, itemSystem.view.uiRoot);
                } else {
                    if (cc.isValid(itemSystem.view.uiRoot, true)) {
                        itemSystem.view.uiRoot.destroy();
                        itemSystem.view.uiRoot.destroy = () => {
                            we.warn(`ItmUIHelper createItemAsync, itemNode already destroyed, viewId=${viewId} please check it`, we.noup);
                            return true;
                        };
                    }
                }
            })
        );

        return item as T;
    }

    /**
     * 创建Item模块
     * @param viewId view id
     * @param ItemClass Item逻辑类
     * @param parent Entity组件父节点
     * @param options 创建选项
     * @param options.usePool 是否使用对象池，默认使用对象池
     * @returns
     */
    public static createItem<T extends we.ui.ItmSystem>(viewId: UIType.ViewId, ItemClass: new () => T, parent: Entity, options?: we.ui.ItmOption, ...args: CreateWithoutNode<T>): T | null {
        options ??= { usePool: true };
        options.isChild ??= true;

        let itemNode: cc.Node = null;
        let poolKey = options.subViewId != null ? `${viewId}:${options.subViewId}` : viewId;
        if (options?.usePool) {
            itemNode = parent.Scene.getComponent(PoolComponent).get(viewId, poolKey);
            if (!itemNode) {
                parent.isValid() && we.warn(`ItmUIHelper createItem, viewId=${viewId} not found`);
                return null;
            }
        } else {
            let itemPrefab = AssetManager.getAsset(viewId, cc.Prefab);
            if (!itemPrefab) {
                parent.isValid() && we.warn(`ItmUIHelper createItem, getAsset viewId=${viewId} not found`);
                return null;
            }
            itemNode = cc.instantiate(itemPrefab);
        }

        // @ts-ignore
        args.unshift(itemNode);
        // @ts-ignore
        args.push({ isFromPool: options?.usePool });

        let item: T = null;
        if (options.isChild) {
            item = parent.addChild<T>(ItemClass, ...(<any>args));
        } else {
            item = parent.addComponent<T>(ItemClass, ...(<any>args));
        }

        if (options?.position) {
            item.view.uiRoot.setPosition(options.position);
        }
        if (options?.parent) {
            item.view.uiRoot.parent = options.parent;
        }

        item.setDestroyFunc(
            we.core.Func.create((itemSystem: T) => {
                if (options?.usePool) {
                    return parent.Scene.getComponent(PoolComponent).put(poolKey, itemSystem.view.uiRoot);
                } else {
                    if (cc.isValid(itemSystem.view.uiRoot, true)) {
                        itemSystem.view.uiRoot.destroy();
                        itemSystem.view.uiRoot.destroy = () => {
                            we.warn(`ItmUIHelper createItem, itemNode already destroyed, viewId=${viewId} please check it`, we.noup);
                            return true;
                        };
                    }
                }
            })
        );

        return item as T;
    }

    /**
     * 通过已经存在的节点创建Item
     * ⚠️注意：cc.Node节点销毁由创建者负责销毁，内部不做任何处理
     * @param ItemClass Item逻辑类
     * @param parent Entity组件父节点
     * @param args Item组件参数
     * @returns
     */
    public static createItemByNode<T extends we.ui.ItmSystem>(ItemClass: new () => T, parent: Entity, ...args: CreateByNodeParamsType<T>): T {
        return parent.addChild<T>(ItemClass, ...(<any>args));
    }

    /**
     * 使用于列表的Item创建，会自动清理掉之前的Item逻辑组件
     * ⚠️注意：cc.Node节点销毁由创建者负责销毁，内部不做任何处理
     * @param ItemClass Item逻辑类
     * @param parent Entity组件父节点
     * @param args Item组件awake参数
     * @returns
     */
    public static createListItem<T extends we.ui.ItmSystem>(ItemClass: new () => T, parent: Entity, ...args: CreateByNodeParamsType<T>): T | null {
        const uiRoot = args[0] as cc.Node;
        if (uiRoot && cc.isValid(uiRoot)) {
            parent.getChild(uiRoot.__entityId__)?.dispose();
        }

        // @ts-ignore
        args.push({ isFromPool: true });
        return parent.addChild<T>(ItemClass, ...(<any>args));
    }
}

we.ui.ItmUIHelper = ItmUIHelper;
