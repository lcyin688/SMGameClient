import { Decorator } from '../../decorator/Decorator';
import { DlgSystem } from '../core/DlgSystem';
import { UIType } from '../core/UIType';

declare global {
    interface IUI {
        UIClassFactory: typeof UIClassFactory;
    }
}

export class UIClassFactory {
    /**
     * 动态创建UI事件处理类
     * @param UIEventHandler Event handler基类
     * @param DlgBase Dlg基类
     * @param viewId ViewId
     * @returns
     */
    static createUIHandler<T extends new (...args: any[]) => any, P extends new () => DlgSystem>(UIEventHandler: T, DlgBase: P, viewId: UIType.ViewId) {
        @Decorator.eventUI(DlgBase, viewId)
        class EventHandlerClass extends UIEventHandler {}
        return EventHandlerClass;
    }
}

we.ui.UIClassFactory = UIClassFactory;
