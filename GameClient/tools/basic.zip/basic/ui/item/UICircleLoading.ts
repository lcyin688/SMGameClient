import { ccBind } from '../../module/resCollector/WEReferenceCollector';
import { WEUIViewCollector } from '../../module/resCollector/WEUIViewCollector';
import { UIResConfig } from '../core/UIResConfig';
import { UISingletonView } from '../core/UISingletonView';
import { UIType } from '../core/UIType';
import AssetManager from '../../manager/AssetManager';
import { TimerComponent } from '../../module/timer/TimerComponent';
import { ClientOfflineMode } from '../../module/ClientOfflineMode';
import Utils from '../../utils/Utils';
import { TimeHelper } from '../../module/time/TimeHelper';
import BasicEventName from '../../const/BasicEventName';
import { Singleton } from '../../module/singleton/Singleton';

declare global {
    interface IUI {
        UICircleLoading: typeof UICircleLoading;
    }

    namespace we {
        namespace ui {
            type UICircleLoading = InstanceType<typeof UICircleLoading>;
        }
    }
}

interface CircleLoadingInfo {
    /** 转圈根节点 */
    node: cc.Node;
    /** view代码 */
    view: UICircleLoadingView;
    /** 转圈配置 */
    options: UIType.CircleLoadingOptions;
    /** 开始显示时间 */
    startShowTime: number;
    /** 引用计数 */
    refCount: number;
    /** timer 结束时间戳 */
    timerEndTime: number;
}

export class UICircleLoadingView {
    @ccBind(cc.Node)
    RCN_mask: cc.Node;

    @ccBind(cc.Label)
    RC_tip: cc.Label;

    @ccBind(cc.Label)
    RC_lab_debug: cc.Label;

    @ccBind(cc.Node)
    RC_circle: cc.Node;
}

/** 转圈加载进度条，全屏转圈，阻挡用户操作 */
@we.decorator.typeSingleton('UICircleLoading')
export class UICircleLoading extends UISingletonView {
    static get Inst() {
        return this.getInstance();
    }

    /** 预制体路径 */
    protected prefabUrl: string;

    /** 预制体 */
    protected prefab: cc.Prefab = null;

    /** 最少显示时长ms 默认 750 ms */
    private readonly mustShow: number = 750;

    /** 超时时间ms 默认 30s */
    private readonly timeOut: number = 30;

    /** 默认转圈文案 */
    private readonly defaultText: string = '';

    private nodePools = new cc.NodePool();

    /** 转圈的实例 */
    protected circleItems = new Map<string, CircleLoadingInfo>();

    private delayTagCounter = 0;

    awake(): void {
        super.awake();
        cc.director.on(BasicEventName.FPS_STATUS_UPDATE, this.onFpsStatusUpdate, this);
    }

    destroy<T extends Singleton>(type: new () => T): void {
        super.destroy(type);
        cc.director.off(BasicEventName.FPS_STATUS_UPDATE, this.onFpsStatusUpdate, this);
    }

    /**
     * 显示加载
     * - 支持离线模式
     * @param options 配置参数
     */
    public static async show(options: UIType.CircleLoadingOptions) {
        this.reviseOptions(options);

        const parentUuid = options.parent.uuid;

        if (options.delay > 0) {
            if (!options.cancel) {
                we.error(`UICircleLoading show, delay show must cancel`);
                return;
            }

            const delayTag = `UICircleLoading:${parentUuid}:${++UICircleLoading.Inst.delayTagCounter}`;
            options.cancel.add(() => {
                TimerComponent.Inst.removeByTag(delayTag);
            });

            let circleInfo = UICircleLoading.Inst.circleItems.get(parentUuid);
            if (circleInfo) {
                ++circleInfo.refCount;
            }

            // 延迟显示, timer 绑定周期到 currentScene, 在延时等待期间, 场景发生跳转, 则无需再显示此转圈
            await TimerComponent.Inst.scheduleOnce(options.delay, we.currentScene, delayTag);
            if (options.cancel && options.cancel.isDispose) {
                return;
            }

            if (circleInfo) {
                --circleInfo.refCount;
            }
        }

        const showHandler = async function () {
            await UICircleLoading.Inst.show(options);
        };

        if (ClientOfflineMode.Inst.isOfflineMode && !options.force) {
            ClientOfflineMode.Inst.addTask(showHandler);
            return;
        }

        await showHandler();
    }

    public static async hide(parent: cc.Node, force: boolean = false) {
        try {
            await this.Inst.hide(parent, force);
        } catch (err) {
            we.warn(`UICircleLoading hide, parent name:${parent.name} err: ${JSON.stringify(err.message || err)}`);
        }
    }

    /**
     * 显示
     */
    @we.core.coroutine.locker({
        lockType: UIType.UICoroutineLockType.CommonSingletonUI,
        getKey(options: UIType.CircleLoadingOptions) {
            if (!cc.isValid(options.parent)) {
                return;
            }
            return UIType.CommonUILockId.UICircleLoading + '_uuid_' + options.parent.uuid;
        },
    })
    private async show(options: UIType.CircleLoadingOptions) {
        if (!cc.isValid(options.parent)) {
            return;
        }

        const parentUuid = options.parent.uuid;
        TimerComponent.Inst.removeByTag(`UICircleLoading:${parentUuid}`, true);
        we.log(`UICirecleLoading show, node enter parentUuid:${parentUuid}`);

        let circleInfo = this.circleItems.get(parentUuid);
        if (!circleInfo || !cc.isValid(circleInfo.node, true)) {
            // 不存在，则创建
            circleInfo = { node: null, view: new UICircleLoadingView(), options: options, startShowTime: 0, refCount: 1, timerEndTime: TimeHelper.getTimestampS() + options.timeout };
            this.circleItems.set(parentUuid, circleInfo);

            let usePrefab: cc.Prefab = null;
            if (options.prefabUrl) {
                usePrefab = await AssetManager.loadAsset(options.prefabUrl, cc.Prefab, null, false);
            }

            if (!usePrefab) {
                // 新建转圈实例
                await this.setPrefab();
                if (!this.prefab) {
                    this.circleItems.delete(parentUuid);
                    return;
                }

                usePrefab = this.prefab;
            }

            // 实例化预制体
            const uiRoot = cc.instantiate(usePrefab);
            circleInfo.node = uiRoot;

            uiRoot.name = 'UICircleLoading';
            uiRoot.active = true;
            uiRoot.position = cc.v3(0, 0, 0);
            uiRoot.parent = options.parent;
            uiRoot.addComponentUnique(WEUIViewCollector)?.bindTo(circleInfo.view);

            circleInfo['scene'] = we.clientScene.gameId;
            circleInfo.startShowTime = Date.now();

            we.log(`UICircleLoading show, node new nodeUuid: ${uiRoot.uuid} parentUuid:${parentUuid}`);
        } else {
            // 已存在实例，增加引用计数
            circleInfo.refCount++;
            we.log(`UICircleLoading show, node reuse nodeUuid: ${circleInfo.node.uuid} parentUuid:${parentUuid}`);
        }

        // 更新配置
        circleInfo.options = options;

        // 更新内容
        this.updateUI(circleInfo.node, circleInfo);

        const freeTime = circleInfo.timerEndTime - TimeHelper.getTimestampS();
        if (options.timeout < freeTime) {
            options.timeout = freeTime;
        }

        this.setTimeout(options, circleInfo);
    }

    /**
     * 隐藏转圈
     * @param parent 转圈父节点
     * @param force 是否强制关闭
     */
    @we.core.coroutine.locker({
        lockType: UIType.UICoroutineLockType.CommonSingletonUI,
        getKey(parent: cc.Node) {
            if (!cc.isValid(parent)) {
                return;
            }
            return UIType.CommonUILockId.UICircleLoading + '_uuid_' + parent.uuid;
        },
    })
    private async hide(parent: cc.Node, force: boolean = false) {
        if (!cc.isValid(parent)) {
            return;
        }
        const parentUuid = parent.uuid;
        let circleInfo = this.circleItems.get(parentUuid);
        if (!circleInfo) {
            return;
        }

        circleInfo.refCount--;
        if (circleInfo.refCount > 0 && !force) {
            // 继续显示
            return;
        }

        TimerComponent.Inst.removeByTag(`UICircleLoading:${parentUuid}`, true);
        const delay = this.mustShow - (Date.now() - circleInfo.startShowTime);
        if (delay > 0) {
            await TimerComponent.Inst.scheduleOnce(delay / 1000, we.clientScene, `UICircleLoading:mustShow:${parentUuid}`);
        }

        if (cc.isValid(circleInfo.node, true)) {
            cc.Tween.stopAllByTarget(circleInfo.view.RC_circle);
            circleInfo.node.destroy();
        }
        this.circleItems.delete(parentUuid);
    }

    /** 更新显示 */
    private updateUI(uiRoot: cc.Node, circleInfo: CircleLoadingInfo) {
        uiRoot.active = true;
        uiRoot.addComponentUnique(cc.BlockInputEvents);

        circleInfo.options.debug ??= '';
        uiRoot['__UICircleLoading_debug'] = circleInfo.options.debug;

        cc.Tween.stopAllByTarget(circleInfo.view.RC_circle);
        cc.tween(circleInfo.view.RC_circle).by(1.75, { angle: -360 }).repeatForever().start();

        if (circleInfo.view.RC_tip) {
            circleInfo.view.RC_tip.string = circleInfo.options.text;
            Utils.labelPointBounce(circleInfo.view.RC_tip, circleInfo.options.text);
        }

        const mask: cc.Node = circleInfo.view.RCN_mask ?? uiRoot.getChildByName('mask');
        if (mask) {
            mask.opacity = circleInfo.options.text === '' ? 120 : 180;
        }

        if (cc.debug.isDisplayStats() && circleInfo.options.debug) {
            if (circleInfo.view.RC_lab_debug) {
                circleInfo.view.RC_lab_debug.string = circleInfo.options.debug;
            }
        } else {
            if (circleInfo.view.RC_lab_debug) {
                circleInfo.view.RC_lab_debug.string = '';
            }
        }
    }

    private setTimeout(data: UIType.CircleLoadingOptions, circleInfo: CircleLoadingInfo) {
        if (data.timeout == null || data.timeout <= 0) {
            return;
        }

        circleInfo.timerEndTime = TimeHelper.getTimestampS() + data.timeout;
        TimerComponent.Inst.scheduleOnce(data.timeout, we.clientScene, `UICircleLoading:${data.parent.uuid}`).then(() => {
            this.hide(data.parent, true);
        });
    }

    private onFpsStatusUpdate(isEnable: boolean = false) {
        if (isEnable == false) {
            return;
        }
        for (let item of this.circleItems.values()) {
            if (item.node == null || !cc.isValid(item.node)) {
                continue;
            }
            this.updateUI(item.node, item);
        }
    }

    /** 清理 */
    protected clear() {
        Array.from(this.circleItems.values()).forEach((item) => {
            this.hide(item.node?.parent);
        });
        super.clear();
    }

    private async setPrefab() {
        const curPrefabUrl = UIResConfig.getUrl('circleLoadingUrl');
        if (curPrefabUrl != this.prefabUrl || this.prefab == null) {
            this.prefab = await AssetManager.loadAsset(curPrefabUrl, cc.Prefab, null, false);
            if (!this.prefab) {
                return;
            }
            this.prefabUrl = curPrefabUrl;
        }
    }

    /**
     * 参数修正
     * @param options
     */
    private static reviseOptions(options: UIType.CircleLoadingOptions) {
        options.text = options.text ?? '';
        options.timeout = options.timeout ?? 30;
        if (options.timeout > 60 || options.timeout < 0) {
            options.timeout = 30;
        }

        options.delay ??= 0;
        if (options.delay < 0 || options.delay > 5) {
            options.delay = 0.5;
        }

        options.force ??= false;
    }
}

we.ui.UICircleLoading = UICircleLoading;
