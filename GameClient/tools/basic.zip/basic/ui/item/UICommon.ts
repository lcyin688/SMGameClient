import LangManager from '../../manager/LangManager';
import { CancelAction } from '../../module/async/CancelAction';
import { UIType } from '../core/UIType';
import { UIConfirm } from './UIConfirm';
import { UICircleLoading } from './UICircleLoading';
import { UIOrientationGuide } from './UIOrientationGuide';
import { toastOptionsDefault, ToastOptions, UIToast } from './UIToast';
import { UILayer } from '../core/UILayer';

export class UICommon {
    /**
     * 显示文本
     * @param text 文本内容
     * @param showTimed 显示时间（秒）
     * @param gravity 限制位置 UIToastGravity
     * @param isSingle 相同显示内容是否单例
     */
    public static showToast(text: string, options: ToastOptions = toastOptionsDefault) {
        if (text && text.length > 0) {
            UIToast.show(text, options);
        }
    }

    /**
     * 显示文本
     * @param langId 多语言文本Id
     * @param showTimed 显示时间（秒）
     * @param gravity 限制位置 UIToastGravity
     * @param isSingle 相同显示内容是否单例
     */
    public static showToastById(langId: string, options: ToastOptions = toastOptionsDefault) {
        this.showToast(LangManager.getLangText(langId), options);
    }

    /**
     * 显示转圈动画，默认显示在UILayer.top层
     * @param options 转圈参数
     */
    public static async showCircleLoading(options?: UIType.CircleLoadingOptions) {
        try {
            options ??= {};
            options.parent ??= UILayer.top;
            await UICircleLoading.show(options);
        } catch (err) {
            we.warn(`UICommon showLoading, options:${JSON.stringify(options)} err: ${JSON.stringify(err.message || err)}`);
        }
    }

    /**
     * TODO 兼容性保留, 延迟显示转圈, 全局转圈，默认显示在UILayer.top层
     * @param delay 单位【s】
     * @param cancel
     * @deprecated 建议使用 showLoading, 后续删除
     */
    public static showCircleLoadingByDelay(delay: number, cancel: CancelAction) {
        const option: UIType.CircleLoadingOptions = {
            delay: delay,
            cancel: cancel,
            parent: UILayer.top,
        };
        UICircleLoading.show(option);
    }

    /**
     * 隐藏转圈
     * @param parent 局部转圈的父节点, 默认全局转圈 UILayer.top
     * @param force 是否强制关闭转圈, 默认 false
     */
    public static async hideCircleLoading(parent?: cc.Node, force: boolean = false) {
        parent ??= UILayer.top;
        await UICircleLoading.hide(parent, force);
    }

    /**
     * 显示确认弹窗
     * @param options
     */
    public static async showConfirm(options: UIType.ConfirmPopupOptions) {
        try {
            options ??= {};
            options.priority ??= UIType.PopupPriority.Normal;
            await UIConfirm.show(options);
        } catch (err) {
            we.warn(`UICommon showConfirm, options:${JSON.stringify(options)} err: ${JSON.stringify(err.message || err)}`);
        }
    }

    /**
     * 关闭确认弹窗
     *
     * 挂载使用方法：we.commonUI.hideConfirm(we.ui.type.PopupPriority.xxxx)
     * @param priority 弹窗优先级分类
     */
    public static hideConfirm(priority: UIType.PopupPriority = UIType.PopupPriority.Normal) {
        UIConfirm.hide(priority);
    }

    /**
     * 是否显示传入优先级确认框
     *
     * 1.传入 UIType.PopupPriority.Null 表明检查所有优先级弹窗是否有显示
     *
     * 2.传入 非 UIType.PopupPriority.Null 检测指定优先级弹窗是否有显示
     * @param priority
     * @returns
     */
    public static isShowConfirm(priority: UIType.PopupPriority = UIType.PopupPriority.All) {
        return UIConfirm.isShow(priority);
    }

    /**
     * 显示横竖屏提示向导
     * @param orientation 引导设备方向
     * @param text 引导提示文字
     */
    public static showOrientationGuide(orientation: we.core.ScreenOrientation, text?: string) {
        UIOrientationGuide.Inst.show(orientation, text);
    }

    /**
     * 隐藏横竖屏提示向导
     */
    public static hideOrientationGuide() {
        UIOrientationGuide.Inst.hide();
    }

    /**
     * 创建常规节点
     * @param path 资源路径
     * @param parent 父节点，默认 top 层级
     * @param zIndex 节点深度
     * @param newCreate 新创建节点
     * @returns
     */
    public static createNode(path: string, parent?: cc.Node, zIndex: number = 0, newCreate: boolean = true): Promise<cc.Node> {
        if (!(typeof path === 'string' && path.length > 0)) {
            return Promise.reject(new Error('UICommon createNode, param is error'));
        }

        parent = parent || UILayer.top;
        const nodeName = path.split('/').pop();

        return new Promise((resolve, reject) => {
            // 存在同名节点
            let node = parent.getChildByName(nodeName);
            if (cc.isValid(node) && !newCreate) {
                node.active = true;
                resolve(node);
                return;
            }

            // 不存在同名节点
            we.core.assetMgr.loadAsset(path, cc.Prefab).then((prefab: cc.Prefab) => {
                if (!cc.isValid(prefab)) {
                    reject(new Error(`UICommon createNode, failed to load prefab, path: ${path}`));
                    return;
                }

                const node = parent.getChildByName(nodeName);
                if (cc.isValid(node)) {
                    if (newCreate) {
                        node.removeFromParent(true);
                    } else {
                        resolve(node);
                        return;
                    }
                }

                const item = cc.instantiate(prefab);
                item.parent = parent;
                item.name = nodeName;
                item.active = true;
                if (zIndex) {
                    item.zIndex = zIndex;
                }
                resolve(item);
            });
        });
    }

    /**
     * 创建节点并初始化  组件必须支持: init公共方法
     * @param data
     * @param newCreate 新创建节点
     * @param cache 缓存节点
     * @returns
     */
    public static createNodeAddInit(
        data: { path: string; loading?: boolean; parent?: cc.Node; componentName?: string; funcName?: string; zIndex?: number; alias?: string; args?: any[]; cacheNode?: boolean },
        newCreate: boolean = true
    ) {
        if (!data) {
            return;
        }

        if (!(!!data.path && !!data.componentName)) {
            we.warn(`UICommon createNodeAddInit, param error path: ${data.path} componentName: ${data.componentName}`);
            return;
        }

        const funcName = data.funcName || 'init';

        this.createNode(data.path, data.parent, data.zIndex, newCreate).then((node) => {
            if (node && cc.isValid(node)) {
                const comp = node.getComponent(data.componentName);
                const args = data.args || [];
                if (comp) {
                    if (args.length > 0) {
                        comp[funcName]?.(...args);
                    } else {
                        comp[funcName]?.();
                    }
                }
            }
        });
    }
}
