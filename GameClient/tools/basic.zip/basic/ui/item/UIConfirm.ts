import { Func } from '../../module/func/Func';
import { ccBind } from '../../module/resCollector/WEReferenceCollector';
import { WEUIViewCollector } from '../../module/resCollector/WEUIViewCollector';
import { UILayer } from '../core/UILayer';
import { UIResConfig } from '../core/UIResConfig';
import { UISingletonView } from '../core/UISingletonView';
import { UIType } from '../core/UIType';
import { CCHelper } from '../../helper/CCHelper';
import { PromiseHelper } from '../../module/async/PromiseHelper';
import LangManager from '../../manager/LangManager';
import AssetManager from '../../manager/AssetManager';
import WESpriteIndex from '../../module/ccitem/WESpriteIndex';
import { ClientOfflineMode } from '../../module/ClientOfflineMode';
import { EventMsg } from '../../type/EventType';
import { SceneHelper } from '../../module/scene/SceneHelper';

declare global {
    interface IUI {
        UIConfirm: typeof UIConfirm;
    }

    namespace we {
        namespace ui {
            type UIConfirm = InstanceType<typeof UIConfirm>;
        }
    }
}

interface ConfirmInfo {
    /** 节点 */
    node: cc.Node;
    /** 弹窗view代码 */
    view: UIConfirmView;
    /** 弹窗数据 */
    options: UIType.ConfirmPopupOptions;
}

export class UIConfirmView {
    // 信息根节点
    @ccBind(cc.Node)
    RC_content: cc.Node;

    // 标题
    @ccBind(cc.Label)
    RC_title?: cc.Label;

    @ccBind(WESpriteIndex, 'RC_title')
    RC_titleSprite?: WESpriteIndex;

    @ccBind(cc.Node)
    RC_close: cc.Node;

    // 信息根节点
    @ccBind(cc.Node)
    RC_info: cc.Node;

    // 信息文本节点
    @ccBind(cc.Label)
    RC_infoText: cc.Label;

    // 信息富文本节点
    @ccBind(cc.RichText)
    RC_infoRichText: cc.RichText;

    // 信息图片节点
    @ccBind(cc.Sprite)
    RC_infoImageText: cc.Sprite;

    // 确认按钮
    @ccBind(cc.Node)
    RC_yes: cc.Node;

    // 确认按钮节点
    @ccBind(cc.Label)
    RC_yesText: cc.Label;

    // 否认按钮
    @ccBind(cc.Node)
    RC_no: cc.Node;

    // 否认按钮节点
    @ccBind(cc.Label)
    RC_noText: cc.Label;
}

interface ConfirmLangKey {
    yes?: string;
    no?: string;
    title?: string;
}

@we.decorator.typeSingleton('UIConfirm')
export class UIConfirm extends UISingletonView {
    static get Inst() {
        return this.getInstance();
    }

    /** 弹窗加入顺序 */
    private order = 0;
    /** 弹窗层级 Index */
    private confirmZIndex: number = cc.macro.MAX_ZINDEX - 10;
    /** 弹窗按钮多语言 */
    private langKey: ConfirmLangKey = {};
    /** 不同优先级确认弹窗节点 Map */
    private confirmCaches = new Map<number, ConfirmInfo>();
    /** 等待显示的弹窗队列 */
    private queues = new Array<UIType.ConfirmPopupOptions & { order: number }>();

    awake(): void {
        super.awake();

        we.event<EventMsg>().on(
            'SceneChangeStart',
            () => {
                this.queues.length = 0;
            },
            this
        );
    }

    public setDefaultLangKey(langKey: ConfirmLangKey) {
        if (!langKey) {
            return;
        }

        this.langKey ??= {};

        this.langKey = {
            ...this.langKey,
            ...langKey,
        };
    }

    public static async show(options: UIType.ConfirmPopupOptions) {
        const showHandler = async function () {
            await UIConfirm.Inst.show(options);
        };

        if (ClientOfflineMode.Inst.isOfflineMode && !options.forceShow) {
            ClientOfflineMode.Inst.addTask(showHandler);
            return;
        }

        await showHandler();
    }

    public static hide(priority: UIType.PopupPriority = UIType.PopupPriority.Normal) {
        this.Inst.hide(priority);
    }

    /**
     * 是否显示弹窗
     * @param priority
     * @returns boolean
     */
    public static isShow(priority: UIType.PopupPriority) {
        if (priority != UIType.PopupPriority.All) {
            const confirmInfo = this.Inst.confirmCaches.get(priority);
            if (cc.isValid(confirmInfo?.node)) {
                return confirmInfo?.node.active;
            } else {
                return false;
            }
        } else {
            let show = false;
            let keys = Object.keys(this.Inst.confirmCaches);
            for (let i = 0; i < keys.length; i++) {
                if (show) {
                    break;
                }

                const confirmInfo = this.Inst.confirmCaches.get(Number(keys[i]));
                if (cc.isValid(confirmInfo?.node)) {
                    show = confirmInfo?.node.active;
                }
            }

            return show;
        }
    }

    private async show(options: UIType.ConfirmPopupOptions) {
        // 设置关闭按钮默认状态
        options.isHideCloseBtn ??= true;
        // 设置弹窗默认可被覆盖
        options.cover ??= true;

        this.queues.push({ ...options, order: ++this.order });

        // 重新按优先级排序
        this.queues.sort((a, b) => {
            return b.priority - a.priority;
        });

        await this.showNext();
    }

    @we.core.coroutine.locker({
        lockType: UIType.UICoroutineLockType.CommonSingletonUI,
        timeout: 8,
    })
    private async showNext() {
        try {
            if (!this.canShowNext()) {
                return;
            }

            const options = this.queues.shift();
            if (!options) {
                return;
            }

            let confirmInfo = this.confirmCaches.get(options.priority);
            confirmInfo ??= {
                view: new UIConfirmView(),
            } as ConfirmInfo;

            let uiRoot: cc.Node = null;
            if (cc.isValid(confirmInfo.node)) {
                // 如果当前优先级弹窗是展示状态，并且不可被覆盖 需要终止当前优先级新弹窗弹出
                if (confirmInfo.node.active && !confirmInfo.options.cover) {
                    return;
                }
                uiRoot = confirmInfo.node;
            } else {
                let usePrefab: cc.Prefab = null;
                if (options.prefabUrl) {
                    usePrefab = await AssetManager.loadAsset(options.prefabUrl, cc.Prefab, null, false);
                }

                if (!usePrefab) {
                    await this.setPrefab();
                    if (!this.prefab) {
                        return;
                    }

                    usePrefab = this.prefab;
                }
                uiRoot = cc.instantiate(usePrefab);
                uiRoot.addComponentUnique(WEUIViewCollector)?.bindTo(confirmInfo.view);
            }

            confirmInfo.options = options;
            confirmInfo.node = uiRoot;

            // 更新 UI
            this.updateUi(uiRoot, confirmInfo);

            // 更新弹窗缓存
            this.confirmCaches.set(confirmInfo.options.priority, confirmInfo);
        } catch (err) {
            we.error(`UIConfirm show, err: ${JSON.stringify(err.message || err)}`);
            this.handleNext(false);
        }
    }

    @we.core.coroutine.locker({
        lockType: UIType.UICoroutineLockType.CommonSingletonUI,
        timeout: 8,
    })
    private async hide(priority: UIType.PopupPriority) {
        let confirmInfo = UIConfirm.Inst.confirmCaches.get(priority);
        if (!confirmInfo) {
            return;
        }

        try {
            if (!confirmInfo.options || confirmInfo.node.active === false) {
                return;
            }

            // 优先播放自定义关闭动画
            if (confirmInfo.options.closeAnimation) {
                await confirmInfo.options.closeAnimation.exec(this);
            } else {
                await this.closeAnimation(confirmInfo);
            }

            if (cc.isValid(confirmInfo.node, true)) {
                confirmInfo.node.active = false;
            }
        } catch (err) {
            we.error(`UIConfirm hide, err: ${JSON.stringify(err.message || err)}`);
        }
    }

    /** 更新显示 */
    private async updateUi(uiRoot: cc.Node, confirmInfo: ConfirmInfo) {
        this.registerUIEvent(confirmInfo);

        const mask = confirmInfo.view.RC_info.addComponentUnique(cc.Mask);
        mask.enabled = false;

        const sv = confirmInfo.view.RC_info.addComponentUnique(cc.ScrollView);
        sv.enabled = false;
        sv.horizontal = false;
        sv.vertical = true;
        sv.brake = 0.25;
        sv.content = confirmInfo.view.RC_infoRichText.node;

        this.setInfo(confirmInfo);

        uiRoot.active = true;
        uiRoot.parent = confirmInfo.options.parent ?? UILayer.popUp;

        if (!uiRoot.getComponent(cc.Widget)) {
            we.warn(`UIConfirm updateSceneUi, uiRoot not find cc.Widget, name:${uiRoot.name}`);
        }

        uiRoot.addComponentUnique(cc.BlockInputEvents);

        // 设置层级
        uiRoot.zIndex = UIConfirm.Inst.confirmZIndex + (confirmInfo.options.priority || 0);

        // 放穿透
        confirmInfo.view.RC_content?.addComponentUnique(cc.BlockInputEvents);

        // 优先播放自定义弹出动画
        if (confirmInfo.options.showAnimation) {
            await confirmInfo.options.showAnimation.exec(this);
        } else {
            // 播放默认动画
            await this.showAnimation(confirmInfo);
        }
    }

    /** 清理 */
    protected clear() {
        super.clear();
        this.confirmCaches.forEach((confirmInfo) => {
            if (cc.isValid(confirmInfo.node, true)) {
                confirmInfo.node.destroy();
            }
        });
        this.confirmCaches.clear();
        this.queues.length = 0;
    }

    private async setPrefab() {
        const curPrefabUrl = UIResConfig.getUrl('confirmUrl');
        if (curPrefabUrl != this.prefabUrl || this.prefab == null) {
            this.clear();
            this.prefab = await AssetManager.loadAsset(curPrefabUrl, cc.Prefab);
            if (!this.prefab) {
                return;
            }
            this.prefabUrl = curPrefabUrl;
        }
    }

    private registerUIEvent(confirmInfo: ConfirmInfo) {
        if (confirmInfo.view.RC_yes) {
            confirmInfo.view.RC_yes.active = !!confirmInfo.options.yesButtonName || !!confirmInfo.options.yesHandler;
            this.cc_onBtnClick(
                confirmInfo.view.RC_yes,
                Func.create(async () => {
                    if (we.core.utils.isQuickClick(null, 1500)) {
                        return;
                    }
                    await this.hide(confirmInfo.options?.priority);
                    const broken = confirmInfo.options.yesHandler?.exec();
                    this.handleNext(broken);
                    this.offUIEvent(confirmInfo);
                }, this)
            );

            confirmInfo.view.RC_yesText && (confirmInfo.view.RC_yesText.string = confirmInfo.options.yesButtonName ?? LangManager.getLangText(this.langKey?.yes));
        }

        if (confirmInfo.view.RC_no) {
            confirmInfo.view.RC_no.active = !!confirmInfo.options.noButtonName || !!confirmInfo.options.noHandler;
            this.cc_onBtnClick(
                confirmInfo.view.RC_no,
                Func.create(async () => {
                    if (we.core.utils.isQuickClick(null, 1500)) {
                        return;
                    }
                    await this.hide(confirmInfo.options?.priority);
                    const broken = confirmInfo.options.noHandler?.exec();
                    this.handleNext(broken);
                    this.offUIEvent(confirmInfo);
                }, this)
            );

            confirmInfo.view.RC_noText && (confirmInfo.view.RC_noText.string = confirmInfo.options.noButtonName ?? LangManager.getLangText(this.langKey?.no));
        }

        if (confirmInfo.view.RC_close) {
            confirmInfo.view.RC_close.active = !confirmInfo.options.isHideCloseBtn;
            this.cc_onBtnClick(
                confirmInfo.view.RC_close,
                Func.create(() => {
                    if (we.core.utils.isQuickClick(null, 1500)) {
                        return;
                    }
                    this.offUIEvent(confirmInfo);
                    this.hide(confirmInfo.options?.priority);
                    this.handleNext(false);
                }, this)
            );
        }
    }

    private offUIEvent(confirmInfo: ConfirmInfo) {
        confirmInfo.options.yesHandler = null;
        confirmInfo.options.noHandler = null;
    }

    private setInfo(confirmInfo: ConfirmInfo) {
        confirmInfo.view.RC_infoText.node.active = false;
        confirmInfo.view.RC_infoRichText.node.active = false;
        confirmInfo.view.RC_infoImageText.node.active = false;

        let contentType = confirmInfo.options?.type ?? SceneHelper.getSceneInfoItem('confirmContentType');
        switch (contentType) {
            case UIType.PopupContentType.Text:
                this.initText(confirmInfo);
                break;
            case UIType.PopupContentType.SpriteFrame:
                this.initSpriteFrame(confirmInfo).catch(() => {});
                break;
            default:
                this.initRichText(confirmInfo).catch(() => {});
                break;
        }

        if (confirmInfo.view.RC_title) {
            confirmInfo.view.RC_title.string = (confirmInfo.options.title as string) ?? LangManager.getLangText(this.langKey?.title) ?? '';
        } else if (confirmInfo.view.RC_titleSprite) {
            if (typeof confirmInfo.options.title === 'string') {
                confirmInfo.view.RC_titleSprite.setName(confirmInfo.options.title ?? LangManager.getLangText(this.langKey?.title) ?? '');
            } else {
                confirmInfo.view.RC_titleSprite.index = confirmInfo.options.title ?? 0;
            }
        }
    }

    private initText(confirmInfo: ConfirmInfo) {
        confirmInfo.view.RC_infoText.string = confirmInfo.options.content;
        confirmInfo.view.RC_infoText.node.active = true;
    }

    private async initRichText(confirmInfo: ConfirmInfo) {
        if (confirmInfo.options.content) {
            confirmInfo.view.RC_infoRichText.string = confirmInfo.options.content;
        }
        if (confirmInfo.options.imageAtlas) {
            confirmInfo.view.RC_infoRichText.imageAtlas = await AssetManager.loadAsset(confirmInfo.options.imageAtlas, cc.SpriteAtlas);
        }
        confirmInfo.view.RC_infoRichText.node.active = true;
        confirmInfo.view.RC_infoRichText['_updateRichText'];
        // 刷新位置
        if (confirmInfo.view.RC_infoRichText.node.height > confirmInfo.view.RC_info.height) {
            const mask = confirmInfo.view.RC_info.addComponentUnique(cc.Mask);
            mask.enabled = true;
            const sv = confirmInfo.view.RC_info.addComponentUnique(cc.ScrollView);
            sv.enabled = true;
            sv.scrollTo(cc.v2(0, 1), 0.1);
        } else {
            const mask = confirmInfo.view.RC_info.addComponentUnique(cc.Mask);
            mask.enabled = false;
            const sv = confirmInfo.view.RC_info.addComponentUnique(cc.ScrollView);
            sv.enabled = false;
            confirmInfo.view.RC_infoRichText.node.setPosition(new cc.Vec2(0, 0));
        }
    }

    private async initSpriteFrame(confirmInfo: ConfirmInfo) {
        if (confirmInfo.options.content) {
            confirmInfo.view.RC_infoImageText.spriteFrame = await AssetManager.loadAsset(confirmInfo.options.content, cc.SpriteFrame);
        }
        CCHelper.Node.maxScaleNode(confirmInfo.view.RC_infoImageText.node);
        confirmInfo.view.RC_infoImageText.node.active = true;
    }

    private async showAnimation(confirmInfo: ConfirmInfo) {
        let defer = PromiseHelper.defer();

        // 播放默认动画
        if (cc.isValid(confirmInfo?.view.RC_content)) {
            cc.tween(confirmInfo?.view.RC_content)
                .set({ scale: 0.36 })
                .to(0.5, { scale: 1, opacity: 255 }, { easing: 'backOut' })
                .call(() => {
                    defer.resolve();
                })
                .start();
        }

        await defer.promise();
    }

    private async closeAnimation(confirmInfo: ConfirmInfo) {
        let defer = PromiseHelper.defer();

        if (!cc.isValid(confirmInfo?.node)) {
            await defer.promise();
            return;
        }

        // 播放默认动画
        if (cc.isValid(confirmInfo.view?.RC_content)) {
            cc.tween(confirmInfo.view?.RC_content)
                .to(0.5, { scale: 0.45, opacity: 100 }, { easing: 'backIn' })
                .call(() => {
                    if (cc.isValid(confirmInfo.node, true)) {
                        confirmInfo.node.active = false;
                    }
                    defer.resolve();
                })
                .start();
        }

        await defer.promise();
    }

    private handleNext(broken: boolean) {
        if (broken) {
            this.queues.length = 0;
        } else {
            this.showNext();
        }
    }

    private canShowNext() {
        for (let item of this.confirmCaches.values()) {
            if (item.node.active) {
                return false;
            }
        }

        return true;
    }
}

we.ui.UIConfirm = UIConfirm;
