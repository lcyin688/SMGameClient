import { ccBind } from '../../module/resCollector/WEReferenceCollector';
import { UIResConfig } from '../core/UIResConfig';
import { UISingletonView } from '../core/UISingletonView';
import AssetManager from '../../manager/AssetManager';
import { WEUIViewCollector } from '../../module/resCollector/WEUIViewCollector';
import { UILayer } from '../core/UILayer';

declare global {
    interface IUI {
        UIOrientationGuide: typeof UIOrientationGuide;
    }

    namespace we {
        namespace ui {
            type UIOrientationGuide = InstanceType<typeof UIOrientationGuide>;
        }
    }
}

/** 转圈加载进度条 */
@we.decorator.typeSingleton('UIOrientationGuide')
export class UIOrientationGuide extends UISingletonView {
    @ccBind(cc.Node)
    RCN_icon: cc.Node;

    @ccBind(cc.Label)
    RCN_tip?: cc.Label;

    /** UI根节点 */
    protected root: cc.Node = null;

    static get Inst() {
        return this.getInstance();
    }

    awake(): void {
        super.awake();
    }

    /** 显示 */
    async show(orientation: we.core.ScreenOrientation, text?: string) {
        await this.setPrefab();

        if (!this.prefab) {
            we.warn('UIOrientationGuide show, prefab is null');
        }

        this.root = this.root ?? cc.instantiate(this.prefab);
        if (this.root.parent && this.root.active) {
            // 重复调用相同Circle， 直接更新显示内容即可
            if (this.RCN_tip) {
                this.RCN_tip.string = text ?? '';
            }
            return;
        }

        this.root.addComponentUnique(WEUIViewCollector)?.bindTo(this);
        if (this.RCN_tip) {
            this.RCN_tip.string = text ?? '';
        }

        let initAngle = (this.RCN_icon.angle = we.core.projectConfig.orientation == we.core.ScreenOrientation.LANDSCAPE_RIGHT ? 90 : 0);
        let angle = orientation == we.core.ScreenOrientation.PORTRAIT ? 0 : 90;

        // top
        this.root.active = true;
        this.root.position = cc.v3(0, 0, initAngle);
        this.root.parent = UILayer.top;
        cc.tween(this.RCN_icon)
            .to(0.6, { eulerAngles: cc.v3(0, 0, initAngle) })
            .to(0.6, { eulerAngles: cc.v3(0, 0, angle) })
            .union()
            .repeatForever()
            .start();
    }

    /** 隐藏 */
    hide() {
        this.RCN_icon && cc.Tween.stopAllByTarget(this.RCN_icon);
        this.root && (this.root.active = false);
    }

    /** 清理 */
    protected clear() {
        if (cc.isValid(this.root, true)) {
            cc.Tween.stopAllByTarget(this.RCN_icon);
            this.root.destroy();
        }
        this.root = null;

        super.clear();
    }

    private async setPrefab() {
        const curPrefabUrl = UIResConfig.getUrl('orientationGuideUrl');
        if (curPrefabUrl != this.prefabUrl || this.prefab == null) {
            this.clear();
            this.prefab = await AssetManager.loadAsset(curPrefabUrl, cc.Prefab);
            if (!this.prefab) {
                return;
            }
            this.prefabUrl = curPrefabUrl;
        }
    }
}

we.ui.UIOrientationGuide = UIOrientationGuide;
