import AssetManager from '../../manager/AssetManager';
import { ClientOfflineMode } from '../../module/ClientOfflineMode';
import { UILayer } from '../core/UILayer';
import { UIResConfig } from '../core/UIResConfig';
import { UISingletonView } from '../core/UISingletonView';

declare global {
    interface IUI {
        UIToast: typeof UIToast;
    }

    namespace we {
        namespace ui {
            type UIToast = InstanceType<typeof UIToast>;
            type UIToastGravity = typeof UIToastGravity;
        }
    }
}

/**
 * 吸附位置
 */
export enum UIToastGravity {
    // 居中显示
    CENTER = 0,
    // 顶部显示
    TOP = 3,
    // 底部显示
    BOTTOM = 4,
}

export interface ToastOptions {
    /** 显示时间（秒） */
    showTimed?: number;
    /** 显示位置 */
    gravity?: UIToastGravity;
    /** 相同显示内容是否单例 */
    isSingle?: boolean;
    /** 强制显示，不受离线模式影响 */
    forceShow?: boolean;
}

export const toastOptionsDefault: ToastOptions = {
    showTimed: 2,
    gravity: UIToastGravity.CENTER,
    isSingle: false,
    forceShow: false,
};

/**
 * 提示信息组件
 */
@we.decorator.typeSingleton('UIToast')
export class UIToast extends UISingletonView {
    /** 吸附位置 */
    private gravity: UIToastGravity = UIToastGravity.CENTER;
    private toastArray: Array<cc.Node> = [];
    private singleMap: Record<string, cc.Node> = {};

    static get Inst() {
        return this.getInstance();
    }

    awake(): void {
        super.awake();
    }

    /** 显示Toast */
    public static show(text: string, options: ToastOptions = toastOptionsDefault) {
        if (options !== toastOptionsDefault) {
            options = {
                ...toastOptionsDefault,
                ...options,
            };
        }

        // eslint-disable-next-line consistent-this
        const selfThis = this;
        const showHandler = async function () {
            selfThis.Inst.show(text, options.showTimed, options.gravity, options.isSingle).catch(() => {});
        };
        if (ClientOfflineMode.Inst.isOfflineMode && options.forceShow !== true) {
            ClientOfflineMode.Inst.addTask(showHandler);
            return;
        }

        showHandler();
    }

    public async show(text: string, duration: number = 2, gravity: UIToastGravity = UIToastGravity.CENTER, isSingle = false) {
        await this.setPrefab();

        if (!this.prefab) {
            return;
        }

        if (isSingle && this.singleMap[text]) {
            const toast = this.singleMap[text];
            cc.Tween.stopAllByTarget(toast);
            this._show(toast, text, duration, gravity);
            return;
        }
        const toast = cc.instantiate(this.prefab);
        if (isSingle) {
            this.singleMap[text] = toast;
        }
        this._show(toast, text, duration, gravity);
    }

    private _show(toast: cc.Node, text: string, duration: number = 1.5, gravity: UIToastGravity = UIToastGravity.CENTER) {
        this.gravity = gravity;

        const High = UILayer.top;
        const trans = High;

        const width = trans.width;
        const height = trans.height;

        const toastTrans = toast;
        const labelText = toast.getComponentInChildren(cc.Label);
        labelText.string = text;
        const labelTrans = labelText.node;
        // toast.width = text_label.node.width + 50;

        // todo labelText.updateRenderData(true);
        if (labelTrans.width > (width / 3) * 2) {
            labelText.overflow = cc.Label.Overflow.RESIZE_HEIGHT;
            labelTrans.width = (width / 3) * 2;
            labelText.lineHeight = 48;
            // todo labelText.updateRenderData(true);
        }
        labelText['_forceUpdateRenderData']();

        toastTrans.width = labelTrans.width + 60;
        toastTrans.height = labelTrans.height + 60;

        toast.parent = High;

        switch (gravity) {
            case UIToastGravity.BOTTOM:
                toast.position = cc.v3(0, -height * 0.5 * 0.8);
                break;
            case UIToastGravity.CENTER:
                toast.position = cc.v3(0, 0);
                break;

            case UIToastGravity.TOP:
                toast.position = cc.v3(0, height * 0.5 * 0.8);
                break;
            default:
                break;
        }

        toast.attr({
            gravity: this.gravity,
            text: text,
            duration: duration,
            bourn: toast.position.y,
        });
        const toastArray = this.toastArray;
        const space = 5;
        const idx = this.toastArray.indexOf(toast);
        if (idx != -1) {
            this.toastArray.splice(idx, 1);
        }
        this.toastArray.push(toast);

        for (let k = toastArray.length; k--; ) {
            const element = toastArray[k];
            if (!element.isValid) {
                toastArray.splice(k, 1);
            }
        }
        // 做位置的排列，这里测试位置没问题，如果显示位置不正确，是因为两个 toast 出现的时间间隔太短，暂时没有好的处理方法
        for (let j = toastArray.length - 1; j > 0; j--) {
            const node1 = toastArray[j];
            const node2 = toastArray[j - 1];
            const height1 = node1.height;
            const height2 = node2.height;
            node2['bourn'] = node1['bourn'] + (height2 + height1) / 2 + space;
        }

        for (let i = 0; i < toastArray.length - 1; i++) {
            const child = toastArray[i];
            cc.tween(child)
                .to(0.1, { position: cc.v2(child.position.x, child['bourn']) })
                .start();
        }

        toast.scale = 0.8;

        cc.Tween.stopAllByTarget(toast);
        toast.opacity = 255;
        const t = cc.tween;
        t(toast)
            .parallel(t(toast).to(0.3, { opacity: 255 }), t(toast).delay(duration))
            .to(0.3, { opacity: 0 })
            .start();

        cc.tween(toast)
            .parallel(cc.tween(toast).to(0.3, { scale: 1 }, { easing: cc.easing.bounceOut }), cc.tween(toast).delay(duration))
            .by(0.3, { position: cc.v3(0, 100, 0) })
            .call(() => {
                const index = this.toastArray.indexOf(toast);
                if (index > -1) {
                    this.toastArray.splice(index, 1);
                }

                delete this.singleMap[text];
                toast.destroyAllChildren();
                toast.destroy();
            })
            .start();
    }

    private async setPrefab() {
        const curPrefabUrl = UIResConfig.getUrl('toastUrl');
        if (curPrefabUrl != this.prefabUrl || this.prefab == null) {
            this.prefab = await AssetManager.loadAsset(curPrefabUrl, cc.Prefab);
            this.prefabUrl = curPrefabUrl;
        }
    }

    protected clear() {
        this.toastArray.forEach((toast) => {
            if (toast.isValid && toast['_components']) {
                const opacityCom = toast.color;
                cc.Tween.stopAllByTarget(toast);
                cc.Tween.stopAllByTarget(opacityCom);
                toast.destroy();
            }
        });
        this.toastArray.length = 0;
        this.singleMap = {};

        super.clear();
    }
}

we.ui.UIToast = UIToast;
