import { LangCode } from '../../flavor/FlavorConf';
import { StringHelper } from '../../helper/StringHelper';
import AssetManager from '../../manager/AssetManager';
import LangManager from '../../manager/LangManager';
import { WEI18nBase } from './WEI18nBase';

const { ccclass, disallowMultiple, menu, property } = cc._decorator;

declare global {
    interface IUI {
        WEI18nFont: typeof WEI18nFont;
    }

    namespace we {
        namespace ui {
            type WEI18nFont = InstanceType<typeof WEI18nFont>;
        }
    }
}

/**
 * 支持 cc.Label或cc.RichText组件，自动切换多语言字体
 * 命名规范：xxx_lang_id.ttf，xxx_lang_en.ttf
 * 多语言字体目录格式为 launcher/skin/ct3/dyn/langfont/id/xxx_lang_id
 */
@ccclass
@disallowMultiple
@menu('we/lang/WEI18nFont(多语言Font组件)')
export class WEI18nFont extends WEI18nBase<cc.SpriteFrame> {
    private label: cc.Label | cc.RichText | null = null;
    private fontUUID: string;

    private static resIdDirReg = /(langfont\/)([^\/]+)/;
    private static resIdFileReg = /(lang_)(.+)/;

    private defaultFont: cc.Font | null = null;

    @property({ visible: false })
    protected _resId: string = '';

    @property({
        visible: false,
        override: true,
    })
    get resId(): string {
        return this._resId;
    }
    set resId(value: string) {
        this._resId = value;
        this.setRes();
    }

    resSetFinish: () => void;

    protected onLoad() {
        super.onLoad();
        this.label = this.node.getComponent(cc.Label) || this.node.getComponent(cc.RichText);
        this.fontUUID = this.label?.font?.['_uuid'];
        this.defaultFont = this.label?.font;
        if (this.label && !CC_EDITOR) {
            this.node.opacity = 0;
        }
        this.setRes().catch((e) => {
            we.warn('WEI18nFont onLoad, setRes error=', e);
        });
    }

    protected async getRes(): Promise<cc.Font> {
        if (!this.resId) {
            this._resId = AssetManager.getUrlByUuid(this.fontUUID);
        }

        if (StringHelper.isNullOrEmpty(this.resId)) {
            we.warn('WEI18nFont getRes, resId not config');
            return;
        }

        this._resId = this.getLangFontRes(this.resId, LangManager.getCurLangCode());
        if (!AssetManager.isAssetExist(this.resId)) {
            return;
        }

        return await AssetManager.loadAsset(this.resId, cc.Font, this);
    }

    private getLangFontRes(curRes: string, langCode: string): string {
        let resId = curRes;
        resId = resId.replace(WEI18nFont.resIdDirReg, `$1${langCode}`);
        if (!WEI18nFont.resIdFileReg.test(resId)) {
            // 默认字体名称没有_lang_langcode，则追加
            resId = `${resId}_lang_${langCode}`;
        } else {
            resId = resId.replace(WEI18nFont.resIdFileReg, `$1${langCode}`);
        }

        return resId;
    }

    public async setRes() {
        if (!this.label) {
            return;
        }

        const res = await this.getRes();
        if (!res) {
            // 指定语言的资源不存在，则直接显示默认的
            this.node.opacity = 255;
            this.label.font = this.defaultFont;
            return;
        }

        if (this.isMatchFont(res)) {
            this.node.opacity = 255;
            this.label.font = res;
        }

        this.resSetFinish && this.resSetFinish();
    }

    private isMatchFont(res: cc.Font): boolean {
        if (!this.label) {
            return false;
        }

        if (this.label instanceof cc.RichText && !(res instanceof cc.TTFFont)) {
            return false;
        }

        return true;
    }

    public setFont(font: cc.Font) {
        if (!this.isMatchFont(font)) {
            return;
        }
        this._resId = null;
        this.label.font = font;
        this.fontUUID = this.label.font['_uuid'];
        this.setRes();
    }
}

we.ui.WEI18nFont = WEI18nFont;
