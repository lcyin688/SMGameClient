import LangManager from '../../manager/LangManager';
import { WEI18nBase } from '../../ui/i18n/WEI18nBase';

const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

enum LanguageModule {
    launcher = 0,
    common = 1,
    hall = 2,
}

const LanguageJson: { [key: string]: string } = {
    [LanguageModule.common]: 'ce2a2d22-594d-4b3a-9ca3-7cf301cb3b53',
    [LanguageModule.launcher]: 'ebced573-76a6-42b8-b4be-6c7cf76aac28',
    [LanguageModule.hall]: '200daacd-786b-421e-8e2b-66a35da1e7d7',
};

/**
 * 大厅 多语言 文字插件，
 * @warning 一般只在 prefab 编辑模式下使用，不会挂载全局
 * 不支持字符串格式化
 */

@ccclass
@executeInEditMode
@disallowMultiple
@menu('we/lang/WEI18nLabelFull(多语言翻译-只用于大厅)')
export class WEI18nLabelFull extends WEI18nBase<string> {
    private label: cc.Label | cc.RichText | null = null;

    @property({ visible: false })
    protected _resId: string = '';

    @property({
        tooltip: CC_DEV && '语言资源ID',
    })
    get resId(): string {
        return this._resId;
    }
    set resId(value: string) {
        this._resId = value;
        this.setRes();
    }

    @property
    private _moduleName: LanguageModule = LanguageModule.launcher;
    @property({
        type: cc.Enum(LanguageModule),
        visible: function () {
            return !this._useCustomStyle;
        },
        tooltip: CC_DEV && '语言模块',
    })
    get moduleName(): LanguageModule {
        return this._moduleName;
    }
    set moduleName(name: LanguageModule) {
        if (this._moduleName === name) {
            return;
        }
        this._moduleName = name;
        this.setRes();
    }

    protected onLoad() {
        super.onLoad();
        this.label = this.node.getComponent(cc.Label) || this.node.getComponent(cc.RichText);
        this.setRes();
    }

    async getRes() {
        if (!CC_EDITOR) {
            return;
        }
        let url = LanguageJson[this.moduleName];
        let arr = await this.loadJson(url);
        return arr.json?.[this.resId] || '';
    }

    async setRes() {
        if (!this.label) {
            return;
        }
        // const moduleNames = this.getEnumKeys(LanguageModule);
        let moduleName = LanguageModule[this.moduleName];
        if (CC_EDITOR) {
            let value = await this.getRes();
            if (!value || !this.label) {
                cc.log('json key not font:', moduleName, this.resId);
                return;
            }
            this.label.string = value;
            if (this.label instanceof cc.Label) {
                this.label['_forceUpdateRenderData']();
            }
        } else {
            this.label.string = LangManager.getLangText(`${moduleName}/${this.resId}`);
            if (this.label instanceof cc.Label) {
                this.label['_forceUpdateRenderData']();
            }
        }
    }

    async loadJson(url: string): Promise<cc.JsonAsset> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(url, (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${url}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.label = this.node.getComponent(cc.Label) || this.node.getComponent(cc.RichText);
        this.setRes();
    }
}
