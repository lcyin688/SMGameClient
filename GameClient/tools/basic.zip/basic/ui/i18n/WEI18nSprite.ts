import { StringHelper } from '../../helper/StringHelper';
import AssetManager from '../../manager/AssetManager';
import LangManager from '../../manager/LangManager';
import { WEI18nBase } from './WEI18nBase';

const { ccclass, requireComponent, menu, property } = cc._decorator;

declare global {
    interface IUI {
        WEI18nSprite: typeof WEI18nSprite;
    }

    namespace we {
        namespace ui {
            type WEI18nSprite = InstanceType<typeof WEI18nSprite>;
        }
    }
}

@ccclass
@requireComponent(cc.Sprite)
@menu('we/lang/WEI18nSprite(多语言Sprite组件)')
export class WEI18nSprite extends WEI18nBase<cc.SpriteFrame> {
    @property({ visible: false })
    protected _resId: string = '';
    @property({
        visible: false,
        tooltip: CC_DEV && '语言资源ID',
    })
    get resId(): string {
        return this._resId;
    }
    set resId(value: string) {
        this._resId = value;
        this.setRes();
    }

    private _sprite: cc.Sprite;
    private get sprite(): cc.Sprite | null {
        this._sprite ??= this.node.getComponent(cc.Sprite);
        return this._sprite;
    }
    private spUUID: string;

    /** 默认挂载的图片作为默认多语言资源 */
    private defaultSprite: cc.SpriteFrame | null = null;

    private static resIdReg = /(langtexture\/)([^\/]+)/;

    resSetFinish: () => void;

    protected onLoad() {
        super.onLoad();
        this.setSpriteFrame(this.sprite?.spriteFrame);
        if (this.sprite && !CC_EDITOR) {
            this.sprite.spriteFrame = null;
        }
        this.setRes().catch((e) => {
            we.warn('WEI18nSprite onLoad, setRes error=', e);
        });
    }

    protected async getRes(): Promise<cc.SpriteFrame> {
        if (!this.resId) {
            this._resId = AssetManager.getUrlByUuid(this.spUUID);
        }

        if (StringHelper.isNullOrEmpty(this.resId)) {
            we.warn('WEI18nSprite getRes, resId not config');
            return;
        }

        let resUrl = this.resId.replace(WEI18nSprite.resIdReg, `$1${LangManager.getCurLangCode()}`);

        const isExist = AssetManager.isAssetExist(resUrl);
        if (!isExist) {
            // @ts-ignore
            resUrl = this.resId.replace(WEI18nSprite.resIdReg, `$1${LangManager.getDefaultLangCode()}`);
            if (!AssetManager.isAssetExist(resUrl)) {
                return;
            }
        }

        this._resId = resUrl;

        return await AssetManager.loadAsset(this.resId, cc.SpriteFrame, this);
    }

    public async setRes() {
        if (!this.sprite) {
            return;
        }

        const res = await this.getRes();
        if (!res) {
            // 指定语言的资源不存在，则直接显示默认的
            this.sprite.spriteFrame = this.defaultSprite;
            return;
        }
        if (this.sprite) {
            this.sprite.spriteFrame = res;
        }

        this.resSetFinish && this.resSetFinish();
    }

    public setSp(sp: cc.SpriteFrame) {
        if (!sp || !this.sprite) {
            return;
        }

        this._resId = null;
        this.setSpriteFrame(sp);
        this.setRes();
    }

    /**
     * 动态设置资源地址
     * @param url hall/skin/ct/res/langtexture/id/main/Start
     * @returns
     */
    public setResId(url: string) {
        // url 中必须存在 langtexture
        if (!url.includes('langtexture')) {
            we.warn('WEI18nSprite setResId, url must include langtexture', url);
            return;
        }
        this._resId = url;
        this.setRes();
        return this;
    }

    private setSpriteFrame(sp: cc.SpriteFrame) {
        if (!this.sprite || !sp) {
            return;
        }

        this.sprite.spriteFrame = sp;
        this.spUUID = this.sprite.spriteFrame?.['_uuid'];
        this.defaultSprite = this.sprite.spriteFrame;
    }
}

we.ui.WEI18nSprite = WEI18nSprite;
