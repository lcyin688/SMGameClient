import { Entity } from '../../module/entity/Entity';

declare global {
    interface IUI {
        I18nData: typeof I18nData;
    }

    namespace we {
        namespace IUI {
            type I18nData = InstanceType<typeof I18nData>;
        }
    }
}

@we.decorator.typeRegister('I18nData')
export class I18nData extends Entity {
    /**
     * 多语言数据
     */
    lang: object;
}

we.ui.I18nData = I18nData;
