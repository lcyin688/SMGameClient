import { StringHelper } from '../../helper/StringHelper';
import LangManager from '../../manager/LangManager';
import { WEI18nBase } from './WEI18nBase';

const { ccclass, requireComponent, executeInEditMode, disallowMultiple, property, menu } = cc._decorator;

declare global {
    interface IUI {
        WEI18nLabelLite: typeof WEI18nLabelLite;
    }

    namespace we {
        namespace IUI {
            type WEI18nLabelLite = InstanceType<typeof WEI18nLabelLite>;
        }
    }
}

@ccclass
@executeInEditMode
@disallowMultiple
@menu('we/lang/WEI18nLabelLite(多语言Label组件)')
export class WEI18nLabelLite extends WEI18nBase<string> {
    /** 中文配置表资源UUID */
    static ExcelResUuid: string = null;

    private label: cc.Label | cc.RichText | null = null;

    private params: Record<string, string | number> | any | null = null;

    private zone: string;

    @property
    protected resId = '';

    @property
    set langId(value: string) {
        this.setResId(value);
    }

    get langId() {
        return this.resId;
    }

    /**
     * 设置当前语言资源id
     */
    public setResId(resId: string) {
        this.resId = resId;
        this.flushChanged();
        return this;
    }

    /**
     * 设置当前语言资源id
     * @param params 多语言参数,格式化示例中的字符串：
     * - 使用 `{name}` 格式：
     *   ```javascript
     *   format('我叫{name},性别{sex},今年{age}岁', { name: '美男子', sex: '男', age: 20 });
     *   ```
     *
     * - 使用 `<%=name%>` 格式：
     *   ```javascript
     *   format("张三<%=name%> 年龄<%=age%>", {name: 'zhangsan', age: 20});
     *   ```
     *
     * - 使用 `%s` 和 `%d` 格式：
     *   ```javascript
     *   format("sounds/music/%s/%d", 'ab', 100);
     *   ```
     *
     * - 使用 `{0}`, `{1}`, `{2}` 格式：
     *   ```javascript
     *   format('我叫{0},性别{1},今年{2}岁', '美男子', '男', 20);
     *   ```
     */
    public setFormatResId(resId: string, ...params: any[]) {
        this.params = params;
        this.setResId(resId);
        return this;
    }

    protected onLoad() {
        super.onLoad();
        this.label = this.node.getComponent(cc.Label) || this.node.getComponent(cc.RichText);
        if (this.label && !CC_EDITOR) {
            this.label.string = '';
        }
        this.setRes();
    }

    protected async getRes(): Promise<string> {
        if (StringHelper.isNullOrEmpty(this.resId)) {
            return;
        }
        if (CC_EDITOR && WEI18nLabelLite.ExcelResUuid) {
            // 编辑器环境测试用
            return new Promise((resolve) => {
                cc.assetManager.loadAny(WEI18nLabelLite.ExcelResUuid, (err, asset: cc.JsonAsset) => {
                    let langId = this.resId;
                    let parts = this.resId.split('/');
                    this.zone = parts[0];
                    langId = parts[1];
                    resolve(asset?.json?.[langId]);
                });
            });
        } else {
            return LangManager.getLangText(this.resId);
        }
    }

    protected async setRes() {
        const value = await this.getRes();
        if (!value) {
            return;
        }
        if (this.label) {
            if (this.params) {
                this.label.string = StringHelper.format(value, this.params);
            } else {
                this.label.string = value;
            }
            this.label.enabled = true;
        }
    }

    resetInEditor() {
        this.label = this.node.getComponent(cc.Label) || this.node.getComponent(cc.RichText);
    }

    onLostFocusInEditor() {
        this.label = this.node.getComponent(cc.Label) || this.node.getComponent(cc.RichText);
        this.setRes();
    }
}

we.ui.WEI18nLabelLite = WEI18nLabelLite;
