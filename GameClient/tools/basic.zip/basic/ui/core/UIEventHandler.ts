import { UIBase } from './UIBase';

declare global {
    interface IUI {
        /**
         * UI声明周期接口定义
         */
        UIEventHandler: typeof UIEventHandler;
    }

    namespace we {
        namespace ui {
            type UIEventHandler = InstanceType<typeof UIEventHandler>;
        }
    }
}

/**
 * UI声明周期接口定义
 */
export abstract class UIEventHandler {
    /**
     * UI实体加载后,初始化窗口数据
     * @param uiBase
     */
    abstract onInitCoreData(uiBase: UIBase): void;

    /**
     * UI实体加载后，初始化业务逻辑数据
     * @param uiBase
     */
    abstract onInitComponent(uiBase: UIBase): void;

    /**
     * 注册UI业务逻辑事件
     * @param uiBase
     */
    abstract onRegisterUIEvent(uiBase: UIBase): Promise<void>;

    /**
     * 显示窗口的业务逻辑
     * @param uiBase
     * @param showData
     */
    abstract onShow(uiBase: UIBase, ...showData: any[]): Promise<void>;

    /**
     * 隐藏UI窗口的业务逻辑
     * 支持异步关闭
     * 支持返回数据
     * 对于Stack类的相同UI窗口，可以保证窗口有序显示
     * @param uiBase
     */
    abstract onHide(uiBase: UIBase): Promise<void>;

    /**
     * 完全关闭销毁UI窗口之前的业务逻辑，用于完全释放UI相关对象
     * @param uiBase
     */
    abstract beforeUnload(uiBase: UIBase): void;

    /**
     * 窗口显示动画
     * @param uiBase
     */
    async onShowAnimation?(uiBase: UIBase): Promise<void>;

    /**
     * 窗口隐藏动画
     * @param uiBase
     */
    async onHideAnimation?(uiBase: UIBase): Promise<void>;
}

we.ui.UIEventHandler = UIEventHandler;
