import { UIBase } from './UIBase';
import { Func } from '../../module/func/Func';
import { UIComponent } from './UIComponent';
import { UIView } from './UIView';
import { __initUI__, __unloadUI__, UISystem } from './UISystem';

declare global {
    interface IUI {
        /**
         * Dlg 逻辑类基类
         */
        DlgSystem: typeof DlgSystem;
    }

    namespace we {
        namespace ui {
            type DlgSystem<T extends UIView = UIView> = InstanceType<typeof DlgSystem<T>>;
        }
    }
}

/**
 * Dlg 逻辑类基类
 */
export abstract class DlgSystem<T extends UIView = UIView> extends UISystem<T> {
    view: T;

    constructor() {
        super();
        Func.bindFuncAsync(this, 'onShow', this.__onShowEnableMobx);
        Func.bindFunc(this, 'destroy', this.__destroyDisableMobx, false);
    }

    protected awake(view: T, ...args: any[]): void {
        this.view = view;
        this[__initUI__]();
    }

    @we.mobx.enable
    protected async __onShowEnableMobx(...args: any[]) {}

    @we.mobx.disable
    protected __destroyDisableMobx(): void {
        this[__unloadUI__]();
    }

    /**
     * 等待窗口关闭
     * @param timeout 超时时间单位【秒】0:用不超时，>0:超时时间
     * @param cancellationToken 主动中断
     * @returns
     */
    async waitClose<T>(timeout = 0) {
        return this.getParent<UIBase>().waitClose<T>(timeout);
    }

    /**
     * 设置窗口返回数据
     * @param data
     */
    public setReturn<T>(data: T) {
        this.getParent<UIBase>().returnData = data;
    }

    protected closeView() {
        this.Scene?.getComponent(UIComponent).close(this.getParent<UIBase>().viewId);
    }

    protected hideView() {
        this.Scene?.getComponent(UIComponent).hide(this.getParent<UIBase>().viewId);
    }

    public async registerUIEvent() {}

    public async onShow(...args: any[]) {}

    /**
     * 隐藏窗口
     */
    public async onHide() {}

    public beforeUnload() {}
}

we.ui.DlgSystem = DlgSystem;
