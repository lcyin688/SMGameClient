import { UIType } from './UIType';
import { UIEventCallback, UIViewHelper } from './UIViewHelper';
import { WEReferenceCollector } from '../../module/resCollector/WEReferenceCollector';
import { WEButton } from '../../module/ccitem/WEButton';
import AssetManager from '../../manager/AssetManager';
import { Func } from '../../module/func/Func';

const { ccclass, property } = cc._decorator;

declare global {
    interface IUI {
        NodeBase: typeof NodeBase;
    }

    namespace we {
        namespace ui {
            type NodeBase = InstanceType<typeof NodeBase>;
        }
    }
}

/**
 * 组件基类
 * @example
 */
@ccclass
export class NodeBase<Options = any> extends cc.Component {
    // -----------------------------------------------------------必要参数

    /**
     * 透传参数，上下文，类型为Object
     */
    protected _context: Options = null;

    private tweenTargets = new Set<any>();

    /**
     * 节点引用收集器,节点自动收集器
     */
    protected _rc: WEReferenceCollector = null;

    /**
     * 当前 com 的名字
     */
    protected _base_view_name = cc.js.getClassName(this);

    /**
     * 事件管理器
     */
    protected _base_event: cc.EventTarget = new cc.EventTarget();

    /**
     * 是否初始化收集器
     */
    private _isInitRc = false;

    /**
     * 是否初始化收集器
     */
    public get isInitRc() {
        return this._isInitRc;
    }

    // -----------------------------------------------------------生命周期

    /**
     * 组件加载预处理，会在 onLoad() 之前执行
     */
    protected __preload(): void {
        if (typeof super['__preload'] === 'function') {
            super['__preload']();
        }
        this.tweenTargets.clear();
        this.__initRc();
    }

    /**
     * 组件销毁预处理，会在 onDestroy() 之前执行
     */
    protected _onPreDestroy(): void {
        if (typeof super['_onPreDestroy'] === 'function') {
            super['_onPreDestroy']();
        }
        this._context = null;
        this.targetOff(this);
        this._isInitRc = false;
        this.tweenTargets.forEach((t) => {
            cc.Tween.stopAllByTarget(t);
        });
        this.tweenTargets.clear();
    }

    /**
     * 初始化收集器数据
     */
    protected __initRc() {
        if (!cc.isValid(this.node) || this._isInitRc === true) {
            return;
        }
        this._rc = this.node.addComponentUnique(WEReferenceCollector);
        if (this._rc) {
            this._isInitRc = true;
            this._rc.bindTo(this);
        }
    }

    // -----------------------------------------------------------基类方法

    /** 设置上下文数据 */
    public setContextData(data: Options) {
        this._context = data;
    }

    /** this视图绑定 */
    bindThisView<T extends object>(CLASS: new () => T): T {
        return this._rc.convertTo(CLASS);
    }

    /**
     * node视图绑定
     */
    bindNodeView<T extends object>(node: cc.Node, CLASS: new () => T): T {
        const rc = node.addComponentUnique(WEReferenceCollector);
        return rc.convertTo(CLASS);
    }

    /**
     * 为节点添加组件 | 获取节点组件（可以保证组件唯一性）
     */
    nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        return node.addComponentUnique(CLASS);
    }

    /**
     * 为节点添加按钮事件
     * @param node 事件节点
     * @param handler 事件处理处理函数
     * @param isOnce 是否只执行一次点击事件,默认：false
     */
    onBtnClick(node: cc.Node, handler: UIEventCallback, isOnce: boolean = false): WEButton {
        return UIViewHelper.onBtnClick(node, handler, isOnce);
    }

    /**
     * 移除按钮事件
     */
    offBtnClick(node: cc.Node) {
        UIViewHelper.offBtnClick(node);
    }

    onToggle(node: cc.Node, handler: UIEventCallback, toggleData?: any | any[]) {
        UIViewHelper.onToggle(node, handler, toggleData);
    }

    offToggle(node: cc.Node) {
        UIViewHelper.offToggle(node);
    }

    /** 注册 EditBox 事件 */
    onEditBoxEvent(node: cc.Node, event: UIType.EditBoxEvent, handler: UIEventCallback) {
        UIViewHelper.onEditBoxEvent(node, event, handler);
    }

    // -----------------------------------------------------------事件派发

    /**
     * 通过事件名发送自定义事件
     */
    public emit(event: string | number, ...data: any[]) {
        this._base_event.emit(event as any, ...data);
    }

    public on(event: string | number, cb: (...any: any[]) => void, target?: any) {
        this._base_event.on(event as any, cb, target || this);
    }

    /**
     * 注册事件目标的特定事件类型回调，回调会在第一时间被触发后删除自身
     */
    public once(event: string | number, cb: (...any: any[]) => void, target?: any) {
        this._base_event.once(event as any, cb, target || this);
    }

    /**
     * 取消事件监听
     */
    public off(event: string | number, cb?: (...any: any[]) => void, target?: any) {
        this._base_event.off(event as any, cb, target || this);
    }

    /**
     * 在当前 EventTarget 上删除指定目标（target 参数）注册的所有事件监听器。
     */
    public targetOff(target: any) {
        this._base_event.targetOff(target);
    }

    public tween<T>(target: T) {
        this.tweenTargets.add(target);
        return cc.tween(target);
    }

    // -----------------------------------------------------------加载资源

    /**
     * 获取资源
     * @param url 资源 url
     * @param type 资源类型
     */
    public getAsset<T extends cc.Asset>(url: string, type: { prototype: T }): T {
        return AssetManager.getAsset<T>(url, type);
    }

    /**
     * 加载资源
     * - 回调模式返回 handler(asset | null), 异步模式返回 resolve(asset | null), 是否加载成功业务层判断 asset 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 资源 url
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     * @param loading 加载 prefab 时是否延迟显示 loading, 默认 true
     */
    public loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: cc.Node | cc.Component, loading?: boolean): Promise<T | null>;
    public loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: Func<(asset?: T | null) => void>, loading?: boolean): Promise<T | null>;
    public loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, ...args: any[]): Promise<T | null> {
        return AssetManager.loadAsset(url, type, args[0] ?? this, args[1]);
    }

    /**
     * 加载同类型的多个资源
     * - 回调模式返回 handler(assets[] | null), 异步模式返回 resolve(assets[] | null), 是否加载成功业务层判断 assets 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * - assets 和 urls 的顺序一致
     * @param urls 资源 url 数组
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     */
    public loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, handler?: cc.Node | cc.Component): Promise<T[] | null>;
    public loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, handler?: Func<(assets?: T[] | null) => void>): Promise<T[] | null>;
    public loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, ...args: any[]): Promise<T[] | null> {
        return AssetManager.loadAssetArray(urls, type, args[0] ?? this);
    }

    /**
     * 加载目录下所有资源
     * - 回调模式返回 handler(assets[] | null), 异步模式返回 resolve(assets[] | null), 是否加载成功业务层判断 assets 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 目录 url
     * @param handler 资源加载生命周期处理器
     */
    public loadAssetDir(url: string, handler?: cc.Node | cc.Component): Promise<cc.Asset[] | null>;
    public loadAssetDir(url: string, handler?: Func<(assets?: cc.Asset[] | null) => void>): Promise<cc.Asset[] | null>;
    public loadAssetDir(url: string, ...args: any[]): Promise<cc.Asset[] | null> {
        return AssetManager.loadAssetDir(url, args[0] ?? this);
    }

    /**
     * 加载远程资源
     * - 回调模式返回 handler(asset | null), 异步模式返回 resolve(asset | null), 是否加载成功业务层判断 asset 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 远程资源 http url
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     * @param loadingParent 局部 loading 父节点(size > 0)
     * @param extname 资源扩展名 如 .png .txt 等, 优先使用传入值, 为空时从 url 解析
     */
    public loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: cc.Node | cc.Component, loadingParent?: cc.Node, extname?: string): Promise<T | null>;
    public loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: Func<(asset?: T | null) => void>, loadingParent?: cc.Node, extname?: string): Promise<T | null>;
    public loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, ...args: any[]): Promise<T | null> {
        return AssetManager.loadAssetRemote(url, type, args[0] ?? this, args[1], args[2]);
    }

    /**
     * 移除资源
     * @param url 资源 url
     * @param type 资源类型
     */
    public releaseAsset(path: string, type?: typeof cc.Asset) {
        AssetManager.removeAsset(path, type);
    }
}

we.ui.NodeBase = NodeBase;
