import { AsyncTask } from '../../module/async/AsyncTask';
import { FuncAsync } from '../../module/func/FuncAsync';
import { UIType } from './UIType';
import BasicEventName from '../../const/BasicEventName';
import { UIView } from './UIView';
import { __initUI__, __unloadUI__, UISystem } from './UISystem';

declare global {
    interface IUI {
        /** Itm 逻辑类基类 */
        ItmSystem: typeof ItmSystem;
    }
    interface TUI {
        ItmOption: ItmOption;
    }
    namespace we {
        namespace ui {
            type ItmSystem<T extends UIView = UIView> = InstanceType<typeof ItmSystem<T>>;
            type ItmOption = TUI['ItmOption'];
        }
    }
}

export interface ItmOption {
    /**
     * entity 组件、 Node 是否使用对象池
     * 默认：false
     */
    usePool?: boolean;
    /**
     * Node 节点父亲节点
     */
    parent?: cc.Node;
    /**
     * 初始化位置
     */
    position?: cc.Vec3 | cc.Vec2;
    /**
     * 同一预制体资源，通过 subViewId 进行细分对象池
     */
    subViewId?: number | string;
    /**
     * UIView代码
     */
    uiView?: new () => UIView;

    /**
     * 是否是子节点，默认 true
     */
    isChild?: boolean;
}

export interface ItemUIConfig {
    /**
     * 是否是固定 UI
     */
    isFixed: boolean;
    /**
     * 是否使用 tween 动画
     * 默认 false，不使用
     */
    useTween: boolean;
    /**
     * open 动画时间，单位【s】
     * 默认0.3s
     */
    openTime: number;

    /**
     * 关闭动画时间，单位【s】
     * 默认0.3s
     */
    closeTime: number;

    /**
     * 打开动画函数
     */
    onOpenAnimation?: FuncAsync<(ui: we.ui.UIBase) => Promise<void>>;
    /**
     * 关闭动画函数
     */
    onCloseAnimation?: FuncAsync<(ui: we.ui.UIBase) => Promise<void>>;

    /** 点击 mask 遮罩是否关闭 默认 true */
    maskClose?: boolean;
}

/**
 * 节点原始数据
 */
interface NodeOriginalData {
    positon: cc.Vec2 | cc.Vec3;
    opacity: number;
    scale: number;
    color: cc.Color;
}

/**
 * Itm 逻辑类基类
 */
export abstract class ItmSystem<T extends UIView = UIView, D = any> extends UISystem<T> {
    /**
     * UI View 代码组件
     */
    view: T;
    /**
     * 持久化上下文数据
     * 组件销毁时，会自动保存到持久化数据中
     * 对象池服用时，会自动从持久化数据中恢复数据
     */
    __context__: D;

    /**
     * View 配置
     */
    protected abstract viewConfig(): new () => T;

    /**
     * view 资源收集器
     */
    public rc: we.ui.WEUIViewCollector;

    /**
     * 预制体根节点
     */
    public uiRoot: cc.Node;
    /**
     * 根节点下 Content 节点
     */
    public uiContent?: cc.Node;
    /**
     * 根节点下 Mask 节点
     */
    public uiMask?: cc.Node;

    /**
     * 节点销毁处理函数
     */
    protected destroyFunc?: we.core.Callback<any>;

    /**
     * UI 配置
     */
    protected uiConfig: ItemUIConfig;

    /**
     * 节点数据
     */
    protected nodeDatas: {
        uiRoot: NodeOriginalData;
        uiContent?: NodeOriginalData;
        uiMask?: NodeOriginalData;
    };

    constructor() {
        super();
        this.uiConfig = {
            isFixed: true,
            useTween: false,
            openTime: 0.3,
            closeTime: 0.3,
            maskClose: true,
        };

        we.core.FuncAsync.bindFunc(this, 'start', this.__startEnableMobx);
        we.core.FuncAsync.bindFunc(this, 'destroy', this.__destroyDisableMobx);
    }

    protected awake(uiRoot: cc.Node, ...args: any[]): void {
        // @ts-ignore
        this.view = this.addComponent(this.viewConfig(), uiRoot, () => {
            // 保存持久化数据
            if (!we.npm.lodash.isEmpty(this.__context__)) {
                this.view.uiRoot['__context__'] = this.__context__;
            }

            if (this.destroyFunc) {
                this.destroyFunc.exec(this);
            }
        });

        this.uiRoot = this.view.uiRoot;
        // 初始化持久化上下文数据
        this.__context__ = this.uiRoot['__context__'] ?? {};

        this.uiRoot.__entityId__ = this.Id;
        this.uiContent = this.uiRoot.getChildByName('content') ?? this.uiRoot.getChildByName('RCN_content') ?? this.uiRoot.getChildByName('RC_content');
        this.uiMask = this.uiRoot.getChildByName('mask') ?? this.uiRoot.getChildByName('RCN_mask') ?? this.uiRoot.getChildByName('RC_mask');

        if (!this.uiConfig.isFixed) {
            this.uiRoot.active = false;
        }

        this.collectNodeData();

        this[__initUI__]();
    }

    @we.core.coroutine.releaseAllLocker()
    protected destroy() {
        this[__unloadUI__]();
        this.view = null;
    }

    /**
     * 设置 UI 配置
     * @param config
     */
    public setUIConfig(config: Partial<ItemUIConfig>) {
        this.uiConfig = {
            ...this.uiConfig,
            ...config,
        };
    }

    @we.mobx.enable
    protected __startEnableMobx(): void {}

    @we.mobx.disable
    protected __destroyDisableMobx() {}

    /**
     * 切换显示
     */
    public async switch() {
        if (this.uiRoot.active) {
            await this.hide();
        } else {
            await this.show();
        }
    }

    /**
     * 显示
     * @returns
     */
    @we.core.coroutine.lockerSafe({
        lockType: UIType.UICoroutineLockType.ItmUI,
        getKey() {
            return this.Id;
        },
        timeout: 5,
    })
    public async show() {
        try {
            if (!this.uiConfig.useTween || this.uiConfig.isFixed) {
                this.uiRoot.active = true;
                return;
            }

            if (this.uiRoot.active) {
                return;
            }

            this.uiRoot.active = true;

            await this.playOpenAnimation();

            if (this.uiConfig.maskClose) {
                cc.director.on(BasicEventName.FULL_TOUCH_END, this.hide, this);
            }
        } catch (err) {
            we.warn(`ItmSystem show, ${this.view.__type__} err: ${JSON.stringify(err?.message || err)}`);
        }
    }

    /**
     * 隐藏
     * @returns
     */
    @we.core.coroutine.lockerSafe({
        lockType: UIType.UICoroutineLockType.ItmUI,
        getKey() {
            return this.Id;
        },
        timeout: 5,
    })
    public async hide() {
        cc.director.off(BasicEventName.FULL_TOUCH_END, this.hide, this);

        if (!this.uiConfig.useTween || this.uiConfig.isFixed) {
            this.uiRoot.active = false;
            return;
        }

        if (!this.uiRoot.active) {
            return;
        }

        await this.playCloseAnimation();

        this.uiRoot.active = false;
        this.recoverNodeData();
    }

    /**
     * 设置 Item 销毁回调函数
     * @param cb
     */
    public setDestroyFunc(cb: we.core.Callback<any>) {
        this.destroyFunc = cb;
    }

    /**
     * 播放打开动画
     */
    private async playOpenAnimation() {
        const task = AsyncTask.create();
        const promise = new Promise<void>((resolve) => {
            (async () => {
                try {
                    if (this.uiConfig.onOpenAnimation) {
                        await this.uiConfig.onOpenAnimation.exec();
                    } else {
                        await this.openAnimation();
                    }
                } finally {
                    resolve();
                }
            })();
        });

        promise.finally(() => {
            task.setResult(null);
        });

        await task.wait(this.uiConfig.openTime, this);
    }

    private async playCloseAnimation() {
        const task = AsyncTask.create();
        const promise = new Promise<void>((resolve) => {
            (async () => {
                try {
                    if (this.uiConfig.onCloseAnimation) {
                        await this.uiConfig.onCloseAnimation.exec();
                    } else {
                        await this.closeAnimation();
                    }
                } finally {
                    resolve();
                }
            })();
        });

        promise.finally(() => {
            task.setResult(null);
        });

        await task.wait(this.uiConfig.closeTime, this);
    }

    /**
     * 打开动画
     */
    protected async openAnimation() {
        const defer = we.core.PromiseHelper.defer<void>();

        if (this.uiContent) {
            this.tween(this.uiContent).set({ scale: 0.3 }).to(this.uiConfig.openTime, { scale: 1 }, { easing: 'backOut' }).start();
        }

        this.uiRoot.opacity = 0;
        this.tween(this.uiRoot)
            .to(this.uiConfig.openTime, { opacity: 255 })
            .call(() => {
                defer.resolve();
            })
            .start();

        await defer.promise();
    }

    /**
     * 关闭动画
     */
    protected async closeAnimation() {
        const defer = we.core.PromiseHelper.defer<void>();

        if (this.uiContent) {
            this.tween(this.uiContent).to(this.uiConfig.closeTime, { scale: 0.45 }, { easing: 'backIn' }).start();
        }

        this.tween(this.uiRoot)
            .to(this.uiConfig.closeTime, { opacity: 1 })
            .call(() => {
                defer.resolve();
            })
            .start();

        await defer.promise();
    }

    private collectNodeData() {
        this.nodeDatas = {
            uiRoot: {
                positon: this.uiRoot.position,
                opacity: this.uiRoot.opacity,
                scale: this.uiRoot.scale,
                color: this.uiRoot.color.clone(),
            },
        };
        if (this.uiContent) {
            this.nodeDatas.uiContent = {
                positon: this.uiContent.position.clone(),
                opacity: this.uiContent.opacity,
                scale: this.uiContent.scale,
                color: this.uiContent.color.clone(),
            };
        }

        if (this.uiMask) {
            this.nodeDatas.uiMask = {
                positon: this.uiMask.position.clone(),
                opacity: this.uiMask.opacity,
                scale: this.uiMask.scale,
                color: this.uiMask.color.clone(),
            };
        }
    }

    private recoverNodeData() {
        this.uiRoot.position = this.nodeDatas.uiRoot.positon;
        this.uiRoot.opacity = this.nodeDatas.uiRoot.opacity;
        this.uiRoot.scale = this.nodeDatas.uiRoot.scale;
        this.uiRoot.color = this.nodeDatas.uiRoot.color.clone();

        if (this.uiContent) {
            this.uiContent.position = this.nodeDatas.uiContent.positon.clone();
            this.uiContent.opacity = this.nodeDatas.uiContent.opacity;
            this.uiContent.scale = this.nodeDatas.uiContent.scale;
            this.uiContent.color = this.nodeDatas.uiContent.color.clone();
        }

        if (this.uiMask) {
            this.uiMask.position = this.nodeDatas.uiMask.positon.clone();
            this.uiMask.opacity = this.nodeDatas.uiMask.opacity;
            this.uiMask.scale = this.nodeDatas.uiMask.scale;
            this.uiMask.color = this.nodeDatas.uiMask.color.clone();
        }
    }
}

we.ui.ItmSystem = ItmSystem;
