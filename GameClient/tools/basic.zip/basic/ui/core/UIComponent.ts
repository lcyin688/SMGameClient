import { CancelAction } from '../../module/async/CancelAction';
import { Entity } from '../../module/entity/Entity';
import { FuncAsync } from '../../module/func/FuncAsync';
import { Queue } from '../../module/algorithms/Queue';
import { BasicType } from '../../type/BasicType';
import { UIDlgTween } from '../helper/UIDlgTween';
import { UIBase } from './UIBase';
import { UIEventManager } from './UIEventManager';
import { UILayer } from './UILayer';
import { UIPathManager } from './UIPathManager';
import { UIResConfig } from './UIResConfig';
import { UIType } from './UIType';
import { EventMsg } from '../../type/EventType';
import { UICommon } from '../item/UICommon';
import LangManager from '../../manager/LangManager';
import AssetManager from '../../manager/AssetManager';
import { DlgSystem } from './DlgSystem';
import WEDlgAnimType from '../../module/ccitem/WEDlgAnimType';
import SceneAnimHelper, { SceneAnimCloseType, SceneAnimOpenType } from '../helper/SceneAnimHelper';
import { AsyncTask } from '../../module/async/AsyncTask';
import { PromiseHelper } from '../../module/async/PromiseHelper';
import { ClientError, ClientErrorType } from '../../module/error/ClientError';

declare global {
    interface IUI {
        /**
         * UI组件控制器
         */
        UIComponent: typeof UIComponent;
    }

    namespace we {
        namespace ui {
            type UIComponent = InstanceType<typeof UIComponent>;
        }
    }
}

export interface QueueViewItem {
    id: UIType.ViewId;
    params?: any[];
}

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-expect-error
export type OnShowParamsType<T> = BasicType.WithOptionalParameters<BasicType.ProtectedMethodParams<T, 'onShow'>, [showConf?: UIType.ShowConf]>;

type ShowReturn<T> = Promise<[T | null, Error | null]>;
/**
 * UI组件控制器
 * 支持多实例
 * 离开子游戏时，自动销毁所有UI
 */
@we.decorator.typeRegister('UIComponent')
export class UIComponent extends Entity {
    // 所有窗口
    private allViewsDic: Map<UIType.ViewId, UIBase>;
    // 显示中的窗口
    private visibleViewsDic: Map<UIType.ViewId, UIBase>;
    // 打开中（onShow、播放窗体打开动画中）的窗口
    private openViewsDic: Map<UIType.ViewId, UIBase>;
    // 加载中（加载预制体、创建示例）的窗口
    private loadViewsDic: Set<UIType.ViewId>;
    // 弹栈中的窗口
    private viewItemQueue: Queue<QueueViewItem>;
    // 是否在出队列中
    private isPopQueueStatus: boolean;
    // 显示转圈超时时间，单位毫秒
    private showCircleTimeout: number;

    protected awake(): void {
        this.isPopQueueStatus = false;
        this.allViewsDic = new Map<string, UIBase>();
        this.visibleViewsDic = new Map<string, UIBase>();
        this.openViewsDic = new Map<string, UIBase>();
        this.loadViewsDic = new Set<UIType.ViewId>();
        this.viewItemQueue = new Queue<QueueViewItem>();
        this.showCircleTimeout = 0.5;
        we.event<EventMsg>().on('SkinChanged', this.onSkinChanged, this);
    }

    @we.core.coroutine.releaseAllLocker()
    protected destroy(): void {
        we.event<EventMsg>().offByTarget(this);
    }

    /**
     * 是否可见
     * @param id 窗口viewId
     * @returns
     */
    public isViewVisible(id: UIType.ViewId): boolean {
        return this.visibleViewsDic.has(id);
    }

    /**
     * 获取UI dlg逻辑组件
     * @param UIClass 窗口类
     * @param isNeedShowState 是否必须是显示状态,默认false
     * @returns
     */
    public getDlg<T extends DlgSystem>(id: UIType.ViewId, isNeedShowState?: boolean): T | null;
    public getDlg<T extends DlgSystem>(UIClass: new (...args) => T, isNeedShowState?: boolean): T | null;
    public getDlg<T extends DlgSystem>(...args): T | null {
        let id: UIType.ViewId = null;
        let p1 = args[0];
        if (args[0] instanceof DlgSystem.constructor) {
            id = this.getViewIdByUIClass(p1);
        } else {
            id = p1;
        }

        const isNeedShowState = args[1] ?? false;
        const uiBase: UIBase = this.getUIBase(id);
        if (uiBase == null || !uiBase.isValid()) {
            // 节点不存在或者已经销毁状态
            return null;
        }

        if (!uiBase.isPreLoad) {
            // 资源未加载完成
            return null;
        }

        if (isNeedShowState) {
            if (!this.isViewVisible(id)) {
                we.warn(`UIComponent getDlg, ${id} is need show state`, we.noup);
                return null;
            }
        }

        const UIClass = UIPathManager.Inst.getUIClass(id);

        return uiBase.getComponent(UIClass) as T;
    }

    /**
     * 压入一个进栈队列界面
     * @param UIClass
     * @param showData
     */
    public showFIFO<T extends DlgSystem>(UIClass: new (...args) => T, ...showData: OnShowParamsType<T>);
    public showFIFO(id: UIType.ViewId, showData?: UIType.ShowConf);
    public showFIFO(id: UIType.ViewId, ...args: any[]);
    public showFIFO(...args) {
        let id: UIType.ViewId = args[0];
        if (id == null) {
            we.warn('UIComponent showFIFO, viewId is null');
            return;
        }

        if (typeof id !== 'string') {
            id = this.getViewIdByUIClass(id);
        }

        if (id == null) {
            we.warn('UIComponent showFIFO, viewId is not exist');
            return;
        }

        let showConfig: UIType.ShowConf = null;
        if (args.length > 1 && UIType.isShowConf(args[args.length - 1])) {
            // 最后一个参数是否为 ui 显示配置
            showConfig = args[args.length - 1];
        } else {
            // 新建默认 ui 显示配置
            showConfig = {};
            args.push(showConfig);
        }

        // 设置弹窗类型配置为Popup
        showConfig.uiConfig ??= {};
        showConfig.uiConfig.viewType ??= UIType.UIViewType.Popup;

        this.viewItemQueue.enqueue({ id, params: args.slice(1, args.length) });

        if (this.isPopQueueStatus) {
            return;
        }

        this.isPopQueueStatus = true;
        this.popFIFOUIBase();
    }

    /**
     * 显示UI窗口【会抛出异常，需要异常处理机制，保证业务流程正常】
     * 调用者需要捕获异常，否则会触发 unhandledRejectedPromise 异常
     * @param UIClass
     * @param showData
     */
    public show<T extends DlgSystem>(UIClass: new (...args) => T, ...showData: OnShowParamsType<T>): Promise<T> | null;
    public show<T extends DlgSystem>(id: UIType.ViewId, showConf?: UIType.ShowConf): Promise<T> | null;
    public show<T extends DlgSystem>(id: UIType.ViewId, ...args: any[]): Promise<T> | null;
    public show<T extends DlgSystem>(...args): Promise<T> | null {
        let id: UIType.ViewId = args[0];
        if (id == null) {
            we.warn('UIComponent show, viewId is null');
            return;
        }

        if (typeof id !== 'string') {
            id = this.getViewIdByUIClass(id);
        }

        if (id == null) {
            we.warn('UIComponent show, viewId is null');
            return;
        }

        let showData = [];
        let showConf: any = null;

        if (args.length > 1) {
            let lastArg = args[args.length - 1];
            if (UIType.isShowConf(lastArg)) {
                showConf = lastArg;
            }
            showData = args.slice(1, showConf ? args.length - 1 : args.length);
        }

        return new Promise<T>((resolve, reject) => {
            this.realShow(id, showConf, ...showData)
                .then((uiBase) => {
                    if (!uiBase) {
                        we.warn(`UIComponent show, realShow then viewid=${id} uiBase is null`, we.noup);
                        return resolve(null);
                    }
                    resolve(uiBase.getComponent(UIPathManager.Inst.getUIClass(uiBase.viewId)) as T);
                })
                .catch((err) => {
                    reject(err);
                });
        });
    }

    /**
     * 显示UI窗口【安全调用，不会抛任何异常，中断流程】
     * 可根据返回值判定是否成功
     * @param UIClass
     * @param showData
     */
    public async showSafe<T extends DlgSystem>(UIClass: new (...args) => T, ...showData: OnShowParamsType<T>): Promise<ShowReturn<T>>;
    public async showSafe<T extends DlgSystem>(id: UIType.ViewId, showConf?: UIType.ShowConf): Promise<ShowReturn<T>>;
    public async showSafe<T extends DlgSystem>(id: UIType.ViewId, ...args: any[]): Promise<ShowReturn<T>>;
    public async showSafe<T extends DlgSystem>(id, ...args: any[]): Promise<ShowReturn<T>> {
        return await PromiseHelper.asyncWrapper<T>(this.show(id, ...args));
    }

    /**
     * 根据窗口Id隐藏并完全关闭卸载UI窗口实例
     * @param id 窗口ID
     * @param isReleaseAsset 是否卸载资源，默认为false
     */
    public close(id: UIType.ViewId, isReleaseAsset?: boolean): void | Promise<void>;
    /**
     * 根据窗口泛型类型隐藏并完全关闭卸载UI窗口实例
     * @param UIClass 窗口类
     * @param isReleaseAsset 是否卸载资源，默认为false
     */
    public close<T extends DlgSystem>(UIClass: new (...args) => T, isReleaseAsset?: boolean): void | Promise<void>;
    public close(...args) {
        let id: UIType.ViewId = args[0];
        if (id == null) {
            we.warn('UIComponent close, view id is null');
            return;
        }

        // 是否释放资源
        const isReleaseAsset: boolean = args[1] ?? false;
        if (typeof id !== 'string') {
            id = this.getViewIdByUIClass(id);
        }

        if (id == null) {
            we.warn('UIComponent close, hide view id is null');
            return;
        }

        return new Promise<void>((resolve) => {
            (async () => {
                try {
                    await this.hide(id);
                    this.unLoad(id, isReleaseAsset);
                } catch (err) {
                    we.warn(`UIComponent close, viewId=${id} err: ${JSON.stringify(err.message || err)}`);
                } finally {
                    resolve();
                }
            })();
        });
    }

    /**
     * 关闭并卸载所有的窗口实例
     * @param self
     * @param bundles bundle名
     * @param layers ui所属层级
     * @param isReleaseAsset 是否卸载资源。默认true
     */
    @we.core.coroutine.releaseAllLocker()
    public closeAll(bundles: string[] = [], layers: UILayer[] = [], isReleaseAsset: boolean = true) {
        this.isPopQueueStatus = false;
        if (this.allViewsDic == null) {
            return;
        }

        const closeViewIds: UIType.ViewId[] = [];

        // 检查加载中的窗口
        for (let viewId of this.loadViewsDic.values()) {
            if (bundles.length > 0 && !bundles.includes(viewId.split('/')[0])) {
                continue;
            }
            closeViewIds.push(viewId);
            this.loadViewsDic.delete(viewId);
        }

        // 检查打开中的窗口
        for (let uiBase of this.openViewsDic.values()) {
            if (uiBase == null || uiBase.viewId == null || !uiBase.isValid()) {
                continue;
            }

            if (bundles.length > 0 && !bundles.includes(uiBase.viewId.split('/')[0])) {
                continue;
            }

            if (layers.length > 0 && !layers.includes(uiBase.uiConfig.viewType)) {
                continue;
            }

            closeViewIds.push(uiBase.viewId);
            this.openViewsDic.delete(uiBase.viewId);
        }

        // 检查显示中的窗口
        for (const uiBase of this.allViewsDic.values()) {
            if (uiBase == null || uiBase.viewId == null || !uiBase.isValid()) {
                continue;
            }

            if (bundles.length > 0 && !bundles.includes(uiBase.viewId.split('/')[0])) {
                continue;
            }

            if (layers.length > 0 && !layers.includes(uiBase.uiConfig.viewType)) {
                continue;
            }

            closeViewIds.push(uiBase.viewId);
            this.unLoad(uiBase.viewId, isReleaseAsset);
        }

        if (bundles.length > 0 || layers.length > 0) {
            let count = this.viewItemQueue.size;
            while (count-- > 0) {
                const item = this.viewItemQueue.dequeue();
                if (bundles.length > 0 && !bundles.includes(item.id.split('/')[0])) {
                    this.viewItemQueue.enqueue(item);
                    continue;
                }

                if (layers.length > 0 && !layers.includes(item.params[item.params.length - 1]?.uiConfig?.viewType)) {
                    this.viewItemQueue.enqueue(item);
                    continue;
                }
            }
        } else {
            this.loadViewsDic.clear();
            this.openViewsDic.clear();
            this.allViewsDic.clear();
            this.visibleViewsDic.clear();
            this.viewItemQueue = new Queue<QueueViewItem>();
        }

        return closeViewIds;
    }

    /**
     * 隐藏ID指定的UI窗口
     * @param id
     */
    public hide(id: UIType.ViewId): void | Promise<void>;
    /**
     * 根据泛型类型隐藏UI窗口
     * @param UIClass
     */
    public hide<T extends DlgSystem>(UIClass: new (...args) => T);
    @we.core.coroutine.lockerSafe({ lockType: UIType.UICoroutineLockType.DlgUI, timeout: 10 })
    public hide(...args): void | Promise<void> {
        let id: UIType.ViewId = args[0];
        if (id == null) {
            we.warn('UIComponent hide, viewId is null');
            return;
        }

        if (typeof id !== 'string') {
            id = this.getViewIdByUIClass(id);
        }

        if (id == null) {
            we.warn('UIComponent hide, viewId is null');
            return;
        }

        return new Promise<void>((resolve) => {
            (async () => {
                let uiBase: UIBase = null;
                try {
                    if (this.loadViewsDic.has(id)) {
                        this.loadViewsDic.delete(id);
                        return;
                    }

                    uiBase = this.openViewsDic.get(id);
                    if (uiBase) {
                        we.debug(`UIComponent hide, viewId: ${id} openning can't hide`);
                        return;
                    }

                    uiBase = this.visibleViewsDic.get(id);
                    if (!uiBase) {
                        we.debug(`UIComponent hide, viewId: ${id} check visibleViewsDic not visible`);
                        return;
                    }

                    if (!uiBase.isValid()) {
                        we.warn(`UIComponent hide, viewId: ${id} is disposed`);
                        resolve();
                        return;
                    }

                    this.autoShowView(uiBase);

                    try {
                        await this.playCloseAnimation(uiBase);
                        if (!uiBase.isValid()) {
                            return;
                        }
                        await UIEventManager.Inst.getHandler(id).onHide(uiBase);
                    } catch (err) {
                        // 关闭时，动画播放报错、onHide报错，不影响正常关闭
                        we.warn(`UIComponent hide, viewId=${id} hide animation or onHide err: ${JSON.stringify(err.message || err)}`, we.noup);
                    }

                    uiBase.notifyClose(null);
                    uiBase.isActive = false;
                    this.visibleViewsDic.delete(id);
                    this.popNextFIFOUIBase(id);
                } catch (err) {
                    uiBase?.notifyClose(err);
                } finally {
                    resolve();
                }
            })();
        });
    }

    /**
     * TODO 接口暂未被使用，待后续优化，隐藏所有已显示的窗口
     * @param self
     * @param filter 保留窗口类型
     * @private
     */
    public hideAllShow(filter?: UIType.UIViewType[]) {
        this.isPopQueueStatus = false;
        const hideViewIds: UIType.ViewId[] = [];
        for (const value of this.visibleViewsDic.values()) {
            if (filter.includes(value.uiConfig.viewType)) {
                continue;
            }
            if (!value.isValid()) {
                continue;
            }
            hideViewIds.push(value.viewId);
            value.isActive = false;
            UIEventManager.Inst.getHandler(value.viewId)
                .onHide(value)
                .catch(() => {});

            value.notifyClose();
        }

        if (hideViewIds.length > 0) {
            for (let i = 0; i < hideViewIds.length; i++) {
                this.visibleViewsDic.delete(hideViewIds[i]);
            }
        }

        this.viewItemQueue = new Queue<QueueViewItem>();

        return hideViewIds;
    }

    /**
     *
     * @param id 窗口Id
     * @param isReleaseAsset
     */
    private unLoad(id: UIType.ViewId, isReleaseAsset?: boolean): void | Promise<void>;
    private unLoad(id: UIBase, isReleaseAsset?: boolean): void | Promise<void>;
    /**
     * 窗口类卸载窗口
     * @param UIClass 窗口类
     * @param isReleaseAsset 是否释放资源， 默认true
     */
    private unLoad<T extends DlgSystem>(UIClass: new (...args) => T, isReleaseAsset?: boolean);
    private unLoad(...args) {
        let id: UIType.ViewId | UIBase = args[0];
        let isReleaseAsset: boolean = args[1] ?? true;
        let uiBase: UIBase = null;

        if (id instanceof UIBase) {
            uiBase = id;
        } else {
            if (typeof id !== 'string') {
                id = this.getViewIdByUIClass(id);
            }
            uiBase = this.getUIBase(id);
        }

        if (uiBase == null || !uiBase.isValid()) {
            return;
        }

        let viewId = uiBase.viewId;
        if (this.openViewsDic.has(viewId)) {
            return;
        }

        this.allViewsDic.delete(viewId);
        this.visibleViewsDic.delete(viewId);
        if (isReleaseAsset) {
            uiBase.uiConfig.closeType == UIType.UICloseType.Destroy;
        }
        uiBase.dispose();
    }

    /**
     * 皮肤切换
     */
    private async onSkinChanged() {
        const recoverViewIds: { id: UIType.ViewId; index: number; showConf: UIType.ShowConf }[] = [];

        for (const uiBase of this.visibleViewsDic.values()) {
            if (uiBase == null || uiBase.viewId == null || !uiBase.isValid()) {
                continue;
            }

            recoverViewIds.push({
                id: uiBase.viewId,
                index: uiBase.uiRoot.getSiblingIndex(),
                showConf: uiBase.showConf,
            });
        }

        this.closeAll();

        for (let item of recoverViewIds) {
            await this.show(item.id, item.showConf);
        }

        for (let item of recoverViewIds) {
            this.visibleViewsDic.get(item.id).uiRoot.setSiblingIndex(item.index);
        }
    }

    /** 根据泛型类型获取窗口Id */
    private getViewIdByUIClass<T extends Entity>(UIClass: new (...args) => T): UIType.ViewId {
        if (UIClass == null) {
            we.warn('UIComponent getViewIdByUIClass, UIClass is null');
            return;
        }

        const viewId: UIType.ViewId = UIPathManager.Inst.getViewId(UIClass.name);
        if (viewId) {
            let reg = new RegExp(`(_${we.core.flavor.getSkinOrientationTag()}|_${we.core.flavor.getSkinCode()})$`);
            return viewId.replace(reg, '');
        }

        we.warn(`UIComponent getViewIdByUIClass, ${UIClass.name} is not have any viewId!`);
        return UIType.ViewId_Invaild as UIType.ViewId;
    }

    /** 弹出并显示一个栈队列中的界面 */
    private async popFIFOUIBase() {
        if (this.viewItemQueue.size > 0) {
            const item = this.viewItemQueue.dequeue();
            await this.show(item.id, ...item.params);
            const uiBase: UIBase = this.getUIBase(item.id);
            uiBase.isInQueue = true;
        } else {
            this.isPopQueueStatus = false;
        }
    }

    /** 弹出并显示下一个栈队列中的界面 */
    private popNextFIFOUIBase(id: UIType.ViewId) {
        const uiBase: UIBase = this.getUIBase(id);
        if (uiBase != null && uiBase.isValid() && this.isPopQueueStatus && uiBase.isInQueue) {
            uiBase.isInQueue = false;
            this.popFIFOUIBase();
        }
    }

    @we.core.coroutine.lockerSafe({
        lockType: UIType.UICoroutineLockType.DlgCreateUIBase,
        getKey(id: UIType.ViewId) {
            return id;
        },
        timeout: 5,
    })
    private async readyToShowBase(id: UIType.ViewId, showData: UIType.ShowConf = null): Promise<UIBase> {
        let uiBase: UIBase = null;
        try {
            uiBase = this.getUIBase(id);
            if (uiBase == null) {
                if (UIPathManager.Inst.hasViewId(id)) {
                    uiBase = this.addChild(UIBase);
                    uiBase.viewId = id;
                    await this.loadBaseView(uiBase, showData);
                }
            }

            if (!uiBase.isPreLoad) {
                await this.loadBaseView(uiBase, showData);
            }

            uiBase.setUIConfig(showData);
            await uiBase.createBefore();

            return uiBase;
            // eslint-disable-next-line no-useless-catch
        } catch (err) {
            uiBase?.dispose();
            throw err;
        }
    }

    @we.core.coroutine.lockerSafe({ lockType: UIType.UICoroutineLockType.DlgUI, timeout: 10 })
    private async realShow(id: UIType.ViewId, showConf: UIType.ShowConf = null, ...showData: any[]) {
        const cancelToken = CancelAction.create();
        try {
            const cancelAction = () => {
                UICommon.hideCircleLoading();
                this.loadViewsDic.delete(id);
            };
            cancelToken.add(cancelAction);

            const showTimeout = showConf?.showCircleTimeout ?? this.showCircleTimeout;
            UICommon.showCircleLoading({ cancel: cancelToken, delay: showTimeout, force: true, text: LangManager.getLangText(UIResConfig.getLangKey('loadingKey')), debug: 'UIComponent realShow' });

            this.loadViewsDic.add(id);

            let uiBase: UIBase = this.visibleViewsDic.get(id);
            if (uiBase?.IsActive) {
                return uiBase;
            }

            uiBase = await this.readyToShowBase(id, showConf);
            if (!uiBase || !uiBase.isValid()) {
                // uiBase已销毁，直接返回
                this.loadViewsDic.delete(id);
                return;
            }

            if (!this.loadViewsDic.has(id)) {
                // 加载中的，已经被关闭,直接卸载
                this.unLoad(uiBase);
                return;
            }

            this.loadViewsDic.delete(id);
            this.openViewsDic.set(id, uiBase);

            uiBase.isActive = true;

            uiBase.nodeRawData.rootOpacity = uiBase.nodeRawData.rootOpacity ?? uiBase.uiRoot.opacity;
            uiBase.nodeRawData.rootScale = uiBase.nodeRawData.rootScale ?? uiBase.uiRoot.scale;
            uiBase.nodeRawData.maskOpacity = uiBase.nodeRawData.maskOpacity ?? uiBase.uiMask?.opacity;
            uiBase.nodeRawData.contentScale = uiBase.nodeRawData.contentScale ?? uiBase.uiContent?.scale;
            // opacity为0时，无法保证在onShow阶段，保证Layout组件下子节点正常更新节点大小、位置等，所以修改为1.
            uiBase.uiRoot.opacity = 1;

            try {
                await UIEventManager.Inst.getHandler(id).onShow(uiBase, ...showData);
            } finally {
                cancelToken.cancel();
            }

            if (!uiBase.isValid()) {
                return;
            }

            uiBase.uiRoot.opacity = uiBase.nodeRawData.rootOpacity;
            await this.playOpenAnimation(uiBase);

            if (!this.openViewsDic.has(id)) {
                // 打开中的，已经被关闭,直接卸载
                this.unLoad(uiBase);
                return;
            }

            uiBase.uiRoot.opacity = uiBase.nodeRawData.rootOpacity;
            this.visibleViewsDic.set(id, uiBase);

            this.autoHideView(uiBase);
            uiBase.createAfter();
            return uiBase;
        } catch (err) {
            if (we.core.isClientError(err) && err.type != ClientErrorType.ResError) {
                we.warn(`UIComponent realShow, show viewId=${id} , err: ${JSON.stringify(err.message || err)}`);
            }

            this.openViewsDic.delete(id);
            this.unLoad(id);
            throw err;
        } finally {
            cancelToken.cancel();
            this.openViewsDic.delete(id);
        }
    }

    private autoHideView(uiBase: UIBase) {
        if (uiBase.uiConfig.viewType !== UIType.UIViewType.Normal) {
            return;
        }

        if (UILayer.normal.children.length === 1) {
            return;
        }

        for (const child of UILayer.normal.children) {
            if (child.name === uiBase.uiRoot.name) {
                continue;
            }

            if (child.active) {
                child.active = false;
            }
        }
    }

    private autoShowView(uiBase: UIBase) {
        if (uiBase.uiConfig.viewType !== UIType.UIViewType.Normal) {
            return;
        }

        if (UILayer.normal.children.length < 2) {
            // 节点数量·= 1，无需处理自动显示问题。
            return;
        }

        if (UILayer.normal.children.indexOf(uiBase.uiRoot) !== UILayer.normal.children.length - 1) {
            // 当前关闭的不是最上层窗口，无需处理自动显示问题。
            return;
        }

        const curShowUI = UILayer.normal.children[UILayer.normal.children.length - 2];
        if (!curShowUI.active) {
            curShowUI.active = true;
        }
        // curShowUI.setSiblingIndex(UILayer.normal.children.length - 1);
    }

    /** 根据窗口Id获取UIBase */
    private getUIBase(id: UIType.ViewId): UIBase {
        if (this.allViewsDic.has(id)) {
            return this.allViewsDic.get(id);
        }

        return null;
    }

    /** 加载UI窗口实例 */
    private async loadBaseView(uiBase: UIBase, showData: UIType.ShowConf = null) {
        // 资源加载
        const go = await AssetManager.loadAsset(uiBase.viewId, cc.Prefab, uiBase.Scene, false);
        if (!go) {
            we.debug(`UIComponent loadBaseView, viewId ${uiBase.viewId} res load failed`);
            throw new ClientError(`UIComponent loadBaseView, viewId ${uiBase.viewId} res load failed`, { type: ClientErrorType.ResError });
        }

        uiBase.uiRoot = cc.instantiate(go);
        uiBase.uiRoot.name = go.name;
        uiBase.prefabPath = uiBase.viewId;

        try {
            const uiEventHandler = UIEventManager.Inst.getHandler(uiBase.viewId);
            uiEventHandler.onInitCoreData(uiBase);

            uiBase.setUIConfig(showData);

            uiBase.setRoot(this.getTargetRoot(uiBase.uiConfig.viewType));

            uiEventHandler.onInitComponent(uiBase);

            uiBase.isActive = false;

            await uiEventHandler.onRegisterUIEvent(uiBase);

            this.allViewsDic.set(uiBase.viewId, uiBase);
        } catch (err) {
            // 释放节点资源
            uiBase.uiRoot.destroy();
            throw err;
        }
    }

    private getTargetRoot(type: UIType.UIViewType) {
        const root = UILayer.getLayer(type);
        if (!root) {
            we.error('UIComponent getTargetRoot, uiroot type is error: ' + type.toString());
            return null;
        }

        return root;
    }

    /**
     * 播放打开动画
     * @param uiBase
     */
    private async playOpenAnimation(uiBase: UIBase) {
        if (!uiBase.isActive) {
            // 激活状态才播放动画
            return;
        }

        const task = AsyncTask.create();
        let promise = new Promise<void>((resolve) => {
            (async () => {
                try {
                    const dlgAnimType = uiBase.uiRoot.getComponent(WEDlgAnimType);
                    if (dlgAnimType?.enabled) {
                        // 预制体动画优先级最高,不受useTween开关限制
                        const animType = dlgAnimType.open;
                        if (animType == SceneAnimOpenType.NONE && uiBase.uiMask) {
                            uiBase.uiMask.opacity = 0;
                            cc.tween(uiBase.uiMask).to(uiBase.uiConfig.openTime, { opacity: uiBase.nodeRawData.maskOpacity }).start();
                        } else {
                            await SceneAnimHelper.openAnim(uiBase, animType);
                        }
                        return;
                    }

                    if (!uiBase.uiConfig.useTween) {
                        return;
                    }

                    const openAnimation = uiBase.uiConfig.onOpenAnimation ?? UIEventManager.Inst.getHandler(uiBase.viewId)?.onShowAnimation;
                    if (uiBase.uiConfig.useCustomTween && openAnimation) {
                        // 优先使用自定义动画接口
                        if (openAnimation instanceof FuncAsync) {
                            await openAnimation.exec();
                        } else {
                            await openAnimation(uiBase);
                        }
                    } else {
                        // 使用默认显示动画
                        await UIDlgTween.open(uiBase);
                    }
                } finally {
                    resolve();
                }
            })();
        });

        promise.finally(() => {
            task.setResult(null);
        });

        await task.wait(uiBase.uiConfig.openTime, uiBase);
    }

    /**
     * 播放关闭动画
     * @param uiBase
     */
    private async playCloseAnimation(uiBase: UIBase) {
        if (!uiBase.isActive) {
            // 激活状态才播放动画
            return;
        }

        const task = AsyncTask.create();
        let promise = new Promise<void>((resolve) => {
            (async () => {
                try {
                    const dlgAnimType = uiBase.uiRoot.getComponent(WEDlgAnimType);
                    if (dlgAnimType?.enabled) {
                        // 预制体动画优先级最高,不受useTween开关限制
                        const animType = uiBase.uiRoot.getComponent(WEDlgAnimType).close;
                        if (animType == SceneAnimCloseType.NONE && uiBase.uiMask) {
                            cc.tween(uiBase.uiMask).to(uiBase.uiConfig.openTime, { opacity: 1 }).start();
                        } else {
                            await SceneAnimHelper.closeAnim(uiBase, animType);
                        }
                        return;
                    }

                    if (!uiBase.uiConfig.useTween) {
                        return;
                    }

                    const closeAnimation = uiBase.uiConfig.onCloseAnimation ?? UIEventManager.Inst.getHandler(uiBase.viewId)?.onHideAnimation;
                    if (uiBase.uiConfig.useCustomTween && closeAnimation) {
                        // 优先使用自定义动画接口
                        if (closeAnimation instanceof FuncAsync) {
                            await closeAnimation.exec();
                        } else {
                            await closeAnimation(uiBase);
                        }
                    } else {
                        // 使用默认显示动画
                        await UIDlgTween.close(uiBase);
                    }
                } finally {
                    resolve();
                }
            })();
        });

        promise.finally(() => {
            task.setResult(null);
        });

        await task.wait(uiBase.uiConfig.closeTime, uiBase);
    }
}

we.ui.UIComponent = UIComponent;
