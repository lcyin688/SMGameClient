import { ISingletonAwake, ISingletonInstance, Singleton } from '../../module/singleton/Singleton';
import { Entity } from '../../module/entity/Entity';
import { UIType } from './UIType';
import { UIViewHelper } from './UIViewHelper';

/**
 * UI路径管理器
 */
@we.decorator.typeSingleton<ISingletonInstance>('UIPathManager')
export class UIPathManager extends Singleton implements ISingletonAwake {
    public windowPrefabPath: Map<UIType.ViewId, string>;
    public windowTypeIdDict: Map<
        string,
        {
            viewId: UIType.ViewId;
            uiClass: any;
        }
    >;

    static get Inst() {
        return this.getInstance();
    }

    awake(): void {
        this.windowPrefabPath = new Map<UIType.ViewId, string>();
        this.windowTypeIdDict = new Map<
            string,
            {
                viewId: UIType.ViewId;
                uiClass: any;
            }
        >();
    }

    public getViewId(uiClassName: string) {
        return this.windowTypeIdDict.get(uiClassName)?.viewId;
    }

    public getUIClass(viewId: UIType.ViewId) {
        let uiClassName = this.getUIClassName(viewId);
        return this.windowTypeIdDict.get(uiClassName)?.uiClass;
    }

    public hasViewId(viewId: UIType.ViewId) {
        return this.getUIClassName(viewId) != null;
    }

    /**
     * 动态注册窗口Id
     * @param uiClass
     * @param viewId
     */
    public registerViewId(uiClass: new () => Entity, viewId: UIType.ViewId) {
        this.windowPrefabPath.set(viewId, uiClass.name);
        this.windowTypeIdDict.set(uiClass.name, {
            viewId,
            uiClass,
        });
    }

    public unregisterViewId(bundleName: string) {
        let viewIds: UIType.ViewId[] = [];
        for (let [key, value] of this.windowTypeIdDict) {
            if (value.viewId.startsWith(bundleName)) {
                this.windowTypeIdDict.delete(key);
                UIViewHelper.getViewIds(value.viewId).forEach((v) => {
                    this.windowPrefabPath.delete(v);
                });
                viewIds.push(value.viewId);
            }
            return viewIds;
        }
    }

    private getUIClassName(viewId: UIType.ViewId) {
        const viewIds = UIViewHelper.getViewIds(viewId);
        for (let id of viewIds) {
            let uiClassName = this.windowPrefabPath.get(id);
            if (uiClassName) {
                return uiClassName;
            }
        }
    }
}
