import { Entity } from '../../module/entity/Entity';

declare global {
    interface IUI {
        UIResConfig: typeof UIResConfig;
    }

    namespace we {
        namespace ui {
            type UIResConfig = InstanceType<typeof UIResConfig>;
        }
    }
}

export interface UIResConfigOptions {
    toastUrl?: string;
    confirmUrl?: string;
    circleLoadingUrl?: string;
    orientationGuideUrl?: string;
}

export interface UILangKeyOptions {
    loadingKey?: string;
}

@we.decorator.typeRegister('UIResConfig')
export class UIResConfig extends Entity {
    resOptions: UIResConfigOptions;
    langKeys: UILangKeyOptions;

    protected awake(opts?: { resOptions?: UIResConfigOptions; langKeys?: UILangKeyOptions }): void {
        if (!opts) {
            return;
        }
        this.resOptions = opts.resOptions ?? {};
        this.langKeys = opts.langKeys ?? {};
    }

    static getUrl(key: keyof UIResConfigOptions) {
        return this.getRes()?.resOptions?.[key] ?? we.clientScene?.getComponent(UIResConfig)?.resOptions?.[key];
    }

    static getLangKey(key: keyof UILangKeyOptions) {
        return this.getRes()?.langKeys?.[key] ?? we.clientScene?.getComponent(UIResConfig)?.langKeys?.[key];
    }

    private static getRes() {
        return we.currentScene?.getComponent?.(UIResConfig) ?? we.clientScene?.getComponent(UIResConfig);
    }

    public setLangOptions(options: UILangKeyOptions) {
        // 合并
        this.langKeys = {
            ...this.langKeys,
            ...options,
        };
    }

    public setResOptions(options: UIResConfigOptions) {
        // 合并
        this.resOptions = {
            ...this.resOptions,
            ...options,
        };
    }
}

we.ui.UIResConfig = UIResConfig;
