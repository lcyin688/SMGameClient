import { StringHelper } from '../../helper/StringHelper';
import { WEButton } from '../../module/ccitem/WEButton';
import { Func } from '../../module/func/Func';
import { FuncAsync } from '../../module/func/FuncAsync';
import { WEUIEventHandler } from '../helper/WEUIEventHandler';
import { UIType } from './UIType';

declare global {
    interface IUI {
        UIViewHelper: typeof UIViewHelper;
    }
    interface TUI {
        UIEventCallback: UIEventCallback;
    }
    namespace we {
        namespace ui {
            type UIEventCallback = TUI['UIEventCallback'];
        }
    }
}

export type UIEventCallback = Func<(...args) => void> | FuncAsync<(...args) => Promise<void>> | ((...args) => void);
export type NodeTouchEventHandler = Func<(...args) => void> | FuncAsync<(...args) => Promise<void>> | ((touch: Touch, event?: cc.Event) => void);

export interface NodeEventOptions {
    /**
     * 是否在捕获阶段触发，默认：false
     */
    useCapture?: boolean;
    /**
     * 是否只触发一次，默认：false
     */
    isOnce?: boolean;
}

export class UIViewHelper {
    /**
     * 为节点添加按钮事件
     * @param node 事件节点
     * @param handler 事件处理处理函数
     * @param isOnce 是否只执行一次点击事件,默认：false
     * @param target 闭包模式，事件处理函数执行上下文
     */
    static onBtnClick(node: cc.Node, handler: UIEventCallback, isOnce: boolean = false, target?: any) {
        if (!node) {
            we.warn('UIViewHelper onBtnClick, node is null');
            return;
        }

        const button = node.addComponentUnique(WEButton);
        if (handler instanceof FuncAsync) {
            button.onListenerAsync(handler, isOnce);
        } else if (handler instanceof Func) {
            button.onListener(handler, isOnce);
        } else {
            // 普通闭包模式
            const effectiveTarget = target || handler['target'] || null;
            button.onListener(
                Func.create(() => {
                    return handler();
                }, effectiveTarget),
                isOnce
            );
        }
        return button;
    }

    static offBtnClick(node: cc.Node) {
        if (!node) {
            return;
        }

        const button = node.getComponent(WEButton);
        if (button) {
            button.offListener();
        }
    }

    /**
     * 监听节点事件
     * @param node 事件节点
     * @param type 事件类型
     * @param handler 事件处理函数
     * @param options 选项配置
     */
    static onNodeEvent(node: cc.Node, type: string, handler: NodeTouchEventHandler, options?: NodeEventOptions) {
        if (!node) {
            we.warn('UIViewHelper onNodeEvent, node is null');
            return;
        }

        let touchHandler = function (touch: Touch, event: cc.Event) {
            if (handler instanceof FuncAsync || handler instanceof Func) {
                handler.exec(touch, event);
            } else {
                // 普通闭包模式
                handler(touch, event);
            }
        };
        if (options?.isOnce) {
            node.once(type, touchHandler, options?.useCapture ?? false);
        } else {
            node.on(type, touchHandler, options?.useCapture ?? false);
        }
    }

    static offNodeEvent(node: cc.Node, type: string) {
        if (!node) {
            return;
        }

        node.off(type);
    }

    /**
     * 注册Toggle/ToggleContainer组件事件
     * @param node
     * @param handler
     * @param toggleData
     */
    static onToggle(node: cc.Node, handler: UIEventCallback, toggleData: any | any[]) {
        if (!node) {
            we.warn('UIViewHelper onToggle, node is null');
            return;
        }

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent.setHandler('toggle', handler);

        const toggle = node.getComponent(cc.ToggleContainer) ?? node.getComponent(cc.Toggle);
        if (!toggle) {
            we.warn(`UIViewHelper onToggle, fail node ${node.name} has not ToggleContainer or Toggle component`);
            return;
        }

        let checkEvents: cc.Component.EventHandler[];

        const checkEvent = new cc.Component.EventHandler();
        checkEvent.target = node;
        checkEvent.component = WEUIEventHandler.name;
        checkEvent.handler = 'onToggleEvent';

        if (toggle instanceof cc.ToggleContainer) {
            checkEvents = toggle.checkEvents;
            const childToggles = node.getComponentsInChildren(cc.Toggle);
            if (childToggles.length !== toggleData.length) {
                we.warn(`UIViewHelper onToggle, fail node ${node.name} The issue of the number of child nodes not matching the length of the toggleData`);
                return;
            }

            for (let i = 0; i < childToggles.length; i++) {
                childToggles[i]['customEventData'] = toggleData[i] ?? undefined;
            }
        } else if (toggle instanceof cc.Toggle) {
            checkEvents = toggle.checkEvents;
            toggle['customEventData'] = toggleData;
        }

        checkEvents.push(checkEvent);
    }

    static offToggle(node: cc.Node) {
        if (!node) {
            return;
        }

        const toggle = node.getComponent(cc.ToggleContainer) ?? node.getComponent(cc.Toggle);
        if (!toggle) {
            return;
        }

        toggle.checkEvents = [];

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent?.setHandler('toggle', null);
    }

    /**
     * 注册Slider组件事件
     * @param node
     * @param handler
     */
    static onSlider(node: cc.Node, handler: UIEventCallback) {
        if (!node) {
            we.warn('UIViewHelper onSlider, node is null');
            return;
        }

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent.setHandler('slider', handler);

        const slider = node.getComponent(cc.Slider);
        if (!slider) {
            we.warn(`UIViewHelper onSlider, fail node ${node.name} has not slider component`);
            return;
        }

        const checkEvent = new cc.Component.EventHandler();
        checkEvent.target = node;
        checkEvent.component = WEUIEventHandler.name;
        checkEvent.handler = 'onSliderEvent';

        slider.slideEvents.push(checkEvent);
    }

    static offSlider(node: cc.Node) {
        if (!node) {
            return;
        }

        const slider = node.getComponent(cc.Slider);
        if (!slider) {
            return;
        }

        slider.slideEvents = [];

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent?.setHandler('slider', null);
    }

    /**
     * 注册 EditBox 事件
     */
    static onEditBoxEvent(node: cc.Node, event: UIType.EditBoxEvent, handler: UIEventCallback) {
        if (!node) {
            we.warn('UIViewHelper onEditBoxEvent, node is null');
            return;
        }

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent.setHandler(event, handler);

        const editBox = node.getComponent(cc.EditBox);
        if (!editBox) {
            we.warn(`UIViewHelper onEditBoxEvent, fail node ${node.name} has not EditBox compoent`);
            return;
        }

        const checkEvent = new cc.Component.EventHandler();
        checkEvent.target = node;
        checkEvent.component = WEUIEventHandler.name;
        checkEvent.handler = `on${StringHelper.toUpFirst(event)}`;

        editBox[`${event}`].push(checkEvent);
    }

    static offEditBoxEvent(node: cc.Node, event: UIType.EditBoxEvent) {
        if (!node) {
            return;
        }

        const editBox = node.getComponent(cc.EditBox);
        if (!editBox) {
            return;
        }

        editBox[`${event}`] = [];

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent?.setHandler(event, null);
    }

    /**
     * 注册 ScrollView 事件
     */
    static onScrollViewEvent(node: cc.Node, event: UIType.ScrollViewEvent, handler: UIEventCallback) {
        if (!node) {
            we.warn('UIViewHelper onScrollViewEvent, node is null');
            return;
        }

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent.setHandler(event, handler);

        const scrollview = node.getComponent(cc.ScrollView);
        if (!scrollview) {
            we.warn(`UIViewHelper onScrollViewEvent, fail node ${node.name} has not ScrollView compoent`);
            return;
        }

        const checkEvent = new cc.Component.EventHandler();
        checkEvent.target = node;
        checkEvent.component = WEUIEventHandler.name;
        checkEvent.handler = `onScrollViewEvent`;
        checkEvent['__event__'] = event;
        scrollview.scrollEvents.push(checkEvent);
    }

    static offScrollViewEvent(node: cc.Node, event: UIType.ScrollViewEvent) {
        if (!node) {
            return;
        }

        const scrollview = node.getComponent(cc.ScrollView);
        if (!scrollview) {
            return;
        }

        scrollview.scrollEvents.remove((item) => {
            return item['__event__'] === event;
        });

        const agent = node.addComponentUnique(WEUIEventHandler);
        agent?.setHandler(event, null);
    }

    static getViewIds(id: UIType.ViewId) {
        return [`${id}_${we.core.flavor.getSkinCode()}`, `${id}_${we.core.flavor.getSkinOrientationTag()}`, id];
    }
}

we.ui.UIViewHelper = UIViewHelper;
