import { Entity } from '../../module/entity/Entity';
import { WEUIViewCollector } from '../../module/resCollector/WEUIViewCollector';
import { UIBase } from './UIBase';
import { UIType } from './UIType';
import { NodeEventOptions, NodeTouchEventHandler, UIEventCallback, UIViewHelper } from './UIViewHelper';

declare global {
    interface IUI {
        UIView: typeof UIView;
    }

    namespace we {
        namespace ui {
            type UIView = InstanceType<typeof UIView>;
        }
    }
}

type ItemDestroyHandler = (item: UIView) => void;

/**
 * UI view基类
 */
export abstract class UIView extends Entity {
    /**
     * UI根节点
     */
    public uiRoot: cc.Node;

    /**
     * view资源收集器
     */
    public rc: WEUIViewCollector;

    /**
     * View组件销毁回调函数
     */
    protected destroyedHandler: ItemDestroyHandler = null;

    protected awake(uiRoot?: cc.Node, destroyed?: ItemDestroyHandler) {
        if (uiRoot) {
            this.uiRoot = uiRoot;
        } else {
            this.uiRoot = this.getParent<UIBase>().uiRoot;
        }
        this.destroyedHandler = destroyed;
        this.rc = this.uiRoot.addComponentUnique(WEUIViewCollector);
        this.rc?.bindTo(this);
    }

    protected destroy(): void {
        this.destroyedHandler?.(this);
        this.destroyedHandler = null;
        this.uiRoot = null;
        this.rc?.unBindTo(this);
    }

    /**
     * 为节点添加按钮事件
     * @param node 事件节点
     * @param handler 事件处理处理函数
     * @param isOnce 是否只执行一次点击事件,默认：false
     */
    public cc_onBtnClick(node: cc.Node, handler: UIEventCallback, isOnce: boolean = false) {
        return UIViewHelper.onBtnClick(node, handler, isOnce);
    }

    public cc_offBtnClick(node: cc.Node) {
        UIViewHelper.offBtnClick(node);
    }

    public cc_onToggle(node: cc.Node, handler: UIEventCallback, toggleData?: any | any[]) {
        UIViewHelper.onToggle(node, handler, toggleData);
    }

    public cc_offToggle(node: cc.Node) {
        UIViewHelper.offToggle(node);
    }

    public cc_onSlider(node: cc.Node, handler: UIEventCallback) {
        UIViewHelper.onSlider(node, handler);
    }

    public cc_offSlider(node: cc.Node) {
        UIViewHelper.offSlider(node);
    }

    /**
     * 监听节点事件
     * @param node 事件节点
     * @param type 事件类型
     * @param handler 事件处理函数
     * @param options 选项配置
     */
    public cc_onNodeEvent(node: cc.Node, type: string, handler: NodeTouchEventHandler, options?: NodeEventOptions) {
        UIViewHelper.onNodeEvent(node, type, handler, options);
    }

    /**
     * 关闭节点事件jsb监听
     * @param node
     * @param type
     */
    public cc_offNodeEvent(node: cc.Node, type: string) {
        UIViewHelper.offNodeEvent(node, type);
    }

    public cc_onEditBoxEvent(node: cc.Node, event: UIType.EditBoxEvent, handler: UIEventCallback) {
        UIViewHelper.onEditBoxEvent(node, event, handler);
    }

    public cc_offEditBoxEvent(node: cc.Node, event: UIType.EditBoxEvent) {
        UIViewHelper.offEditBoxEvent(node, event);
    }

    public cc_onScrollViewEvent(node: cc.Node, event: UIType.ScrollViewEvent, handler: UIEventCallback) {
        UIViewHelper.onScrollViewEvent(node, event, handler);
    }

    public cc_offScrollViewEvent(node: cc.Node, event: UIType.ScrollViewEvent) {
        UIViewHelper.offScrollViewEvent(node, event);
    }
}

we.ui.UIView = UIView;
