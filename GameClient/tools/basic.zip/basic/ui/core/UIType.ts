import { CancelAction } from '../../module/async/CancelAction';
import { Func } from '../../module/func/Func';
import { FuncAsync } from '../../module/func/FuncAsync';
import { UIConfirm } from '../item/UIConfirm';
import { UIBase } from './UIBase';

declare global {
    interface IUI {
        type: typeof UIType;
    }

    namespace we {
        namespace ui {
            namespace type {
                type ConfirmPopupOptions = UIType.ConfirmPopupOptions;
                type CircleLoadingInfo = UIType.CircleLoadingOptions;
                type EditBoxEvent = UIType.EditBoxEvent;
            }
        }
    }
}

export namespace UIType {
    /**
     * UI锁类型定义
     */
    export class UICoroutineLockType {
        static readonly CoroutineLockType_Min = 31001;
        /**
         * Dlg UI 创建 UIBase 锁
         */
        static readonly DlgCreateUIBase = 31002;
        /**
         * 公共 UI 锁
         */
        static readonly CommonSingletonUI = 31003;
        /**
         * Dlg UI 锁
         */
        static readonly DlgUI = 31004;
        /**
         * Itm UI 锁
         */
        static readonly ItmUI = 31005;

        static readonly CoroutineLockType_Max = 32000;
    }

    export enum CommonUILockId {
        UICircleLoading = 1,
        UIConfirm = 2,
    }

    export enum PopupContentType {
        /** 文本 */
        Text = 1,
        /** 富文本 */
        RichText = 2,
        /** 图片精灵 */
        SpriteFrame = 3,
    }

    /** 弹窗优先级 */
    export enum PopupPriority {
        /** 所有优先级 用于获取当前是否正在显示确认弹窗 */
        All = -1,
        /** 常规弹窗 */
        Normal = 1,
        /** 资源加载相关 */
        Asset = 2,
        /** 维护弹窗/顶号/在线热更 */
        System = 3,
        /** 网络相关 */
        Network = 4,
    }

    /** 资源弹窗选项类型 */
    export interface ConfirmPopupOptions {
        /** 自定义弹窗预制体 url */
        prefabUrl?: string;
        /** 弹窗优先级，每个优先级弹窗仅会保留一个 */
        priority?: PopupPriority;
        /** 覆盖弹窗 仅针对相同优先级且正在显示弹窗 默认 true */
        cover?: boolean;
        /** Yes 回调, 返回true则清理队列中的弹窗 */
        yesHandler?: Func<() => true | void>;
        /** Yes 按钮显示名称 */
        yesButtonName?: string;
        /** No 回调, 返回true则清理队列中的弹窗  */
        noHandler?: Func<() => true | void>;
        /** No 按钮显示名称 */
        noButtonName?: string;
        /** 标题:标题文本或者 WESpriteIndex 组件图片索引 */
        title?: string | number;
        /** 内容类型，默认富文本 */
        type?: PopupContentType;
        /** 内容值 */
        content?: string;
        /** 图集地址 */
        imageAtlas?: string;
        /** 显示动画 */
        showAnimation?: FuncAsync<(ui: UIConfirm) => Promise<void>>;
        /** 关闭动画 */
        closeAnimation?: FuncAsync<(ui: UIConfirm) => Promise<void>>;
        /** 是否隐藏关闭按钮, 默认隐藏：true */
        isHideCloseBtn?: boolean;
        /** 指定父节点 */
        parent?: cc.Node;
        /** 强制显示，不受离线模式影响 */
        forceShow?: boolean;
    }

    interface CircleLoadingOptionsBase {
        /** 提示文本 */
        text?: string;
        /** 自定义转圈预制体 url */
        prefabUrl?: string;
        /** 设置显示父节点, 默认: UILayer.top */
        parent?: cc.Node;
        /** 最大显示时长，时间到自动关闭，单位 s */
        timeout?: number;
        /** 追踪数据 */
        debug?: string;
        /** 是否强制显示，不受离线模式影响, 默认 false */
        force?: boolean;
    }

    export interface CircleLoadingOptionsWithoutDelay extends CircleLoadingOptionsBase {
        delay?: undefined;
        cancel?: CancelAction;
    }

    export interface CircleLoadingOptionsWithDelay extends CircleLoadingOptionsBase {
        delay: number;
        cancel: CancelAction;
    }

    /**
     * 转圈参数
     */
    export type CircleLoadingOptions = CircleLoadingOptionsWithoutDelay | CircleLoadingOptionsWithDelay;

    export interface LoadingTipOptions {
        /** 提示内容 */
        tip: string;
        /** 延迟显示【单位：ms】，如果加载、网络请求等响应很快的情况，则不显示 */
        delay?: number;
        /** 显示最低时长【单位：ms】，避免闪现 */
        mustWait?: number;
    }

    export interface LoadingProgressOptions {
        /** 延迟显示【单位：ms】，如果加载、网络请求等响应很快的情况，则不显示 */
        delay?: number;
        /** 显示最低时长【单位：ms】，避免闪现 */
        mustWait?: number;
    }

    /**
     * UI窗口类型
     */
    export enum UIViewType {
        // 全屏窗口
        Normal,
        // 固定窗口层,如公共导航、公共UI等固定显示在Normal层之上
        Fixed,
        // 弹出窗口
        Popup,
        // 顶层窗口
        Top,
        // RootNode 节点
        RootNode,
    }

    /**
     * UI动画类型
     */
    export enum UITweenType {
        // 无动画
        None = 1,
        // 场景动画类型
        Scene,
        // 弹窗动画类型
        Popup,
    }

    export enum UseBlockInputType {
        /**
         * 不使用
         */
        None = 0,
        /**
         * 只加Root遮罩层
         */
        Root = 1,
        /**
         * 只加遮罩层
         */
        Mask = 2,
        /**
         * 只加Main层
         */
        Main = 3,
        /**
         * Mask/Main都加
         */
        All = 4,
    }

    export enum UICloseType {
        // 隐藏节点
        Hide = 1,
        // 移除节点，不销毁资源
        Remove = 2,
        // 移除节点+销毁资源
        Destroy = 3,
    }

    export const UIAttributeSymbol = {
        ViewUIClass: Symbol('ViewUIClass'),
        ViewId: Symbol('ViewId'),
    };

    export const ViewId_Invaild = 'ViewId_Invaild';

    export type ViewId = string;

    export interface UIConfig {
        /**
         * 窗口类型
         * 默认值：UIViewType.Normal
         */
        viewType: UIViewType;
        /**
         * 是否使用UI动画
         * 预制体脚本控制的动画不受此限制
         * 默认值：true
         */
        useTween: boolean;
        /**
         * 是否使用自定义动画
         * 默认值:true
         */
        useCustomTween: boolean;
        /**
         * 是否使用BlockInputEvent组件防穿透
         * 默认值：UseBlockInputType.All
         */
        useBlockInput: UseBlockInputType;
        /**
         * 默认关闭窗口行为类型
         * 默认值：UICloseType.Remove
         */
        closeType: UICloseType;
        /**
         * 是否点击Mask区域，关闭窗口
         * 默认值：false
         */
        closeByMask: boolean;

        /**
         * open动画时间，单位【s】
         * 默认0.3s
         */
        openTime: number;

        /**
         * 关闭动画时间，单位【s】
         * 默认0.3s
         */
        closeTime: number;
        /**
         * 打开动画函数
         */
        onOpenAnimation?: FuncAsync<(ui: UIBase) => Promise<void>>;
        /**
         * 关闭动画函数
         */
        onCloseAnimation?: FuncAsync<(ui: UIBase) => Promise<void>>;
    }

    export type ShowConf = { [key: string]: any } & {
        /**
         * 超时转圈，单位【秒】
         */
        showCircleTimeout?: number;
        /**
         * UI配置
         */
        uiConfig?: Partial<UIConfig>;
    };

    export function isShowConf(obj: any): obj is ShowConf {
        return obj && (obj.showCircleTimeout != null || obj.uiConfig != null);
    }

    export type EditBoxEvent = 'editingDidBegan' | 'textChanged' | 'editingDidEnded' | 'editingReturn';

    export type ScrollViewEvent =
        | 'scrolling'
        | 'scroll-began'
        | 'scroll-ended'
        | 'touch-up'
        | 'bounce-right'
        | 'bounce-left'
        | 'bounce-top'
        | 'bounce-bottom'
        | 'scroll-to-top'
        | 'scroll-to-bottom'
        | 'scroll-to-left'
        | 'scroll-to-right';
}

we.ui.type = UIType;
