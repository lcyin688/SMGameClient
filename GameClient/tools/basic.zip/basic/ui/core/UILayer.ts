import { UIType } from './UIType';

declare global {
    interface IUI {
        /**
         * 场景层级管理器
         */
        UILayer: typeof UILayer;
    }
}

/**
 * 场景层级管理器
 */
export class UILayer {
    private static layers = new Map<number, cc.Node>();

    static getLayer(layer: number) {
        return this.layers.get(layer);
    }

    static addLayer(layer: number, node: cc.Node) {
        this.layers.set(layer, node);
    }

    /** 普通主界面 */
    static get normal(): cc.Node {
        return this.getLayer(UIType.UIViewType.Normal);
    }

    /** 固定窗口 */
    static get fixed(): cc.Node {
        return this.getLayer(UIType.UIViewType.Fixed);
    }

    /** 弹出窗口 */
    static get popUp(): cc.Node {
        return this.getLayer(UIType.UIViewType.Popup);
    }

    /** 顶层窗口 */
    static get top(): cc.Node {
        return this.getLayer(UIType.UIViewType.Top);
    }

    /** ui根节点 */
    static get uiRoot(): cc.Node {
        return this.normal.parent;
    }

    static get rootNode(): cc.Node {
        return this.getLayer(UIType.UIViewType.RootNode);
    }

    static getUi(type: UIType.UIViewType): cc.Node {
        const root = this.getLayer(type);
        if (cc.isValid(root, true)) {
            return root;
        }
        we.error('UILayer getUi, not found ui layer', type);
        return null;
    }
}

we.ui.UILayer = UILayer;
