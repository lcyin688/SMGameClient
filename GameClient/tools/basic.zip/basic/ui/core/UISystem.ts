import AssetManager from '../../manager/AssetManager';
import { Entity } from '../../module/entity/Entity';
import { Func } from '../../module/func/Func';
import { TimerTag, TimerTarget } from '../../module/timer/TimerComponent';
import { UIHelper } from '../helper/UIHelper';
import { I18nData } from '../i18n/I18nData';
import { WEI18nFont } from '../i18n/WEI18nFont';
import { WEI18nLabelLite } from '../i18n/WEI18nLabelLite';
import { UIView } from './UIView';

export const __initUI__ = Symbol('__initUI__');
export const __unloadUI__ = Symbol('__unloadUI__');

/**
 * UI 系统基础类
 */
export abstract class UISystem<T extends UIView = UIView> extends Entity {
    abstract view: T;

    /**
     * 收集 tween 对象
     */
    private tweenTargets = new Set<any>();

    protected [__initUI__]() {
        this.tweenTargets.clear();
        // 自动设置节点上的多语言文本
        let langs = this.view.Scene.getComponent(I18nData)?.lang ?? this.langsConf();
        if (langs) {
            UIHelper.setUILangText(this.view.rc, langs, this.langParamsConf());
        }
    }

    protected [__unloadUI__]() {
        this.tweenTargets.forEach((t) => {
            cc.Tween.stopAllByTarget(t);
        });
        this.tweenTargets.clear();
    }

    /**
     * 获取上一帧的增量时间
     */
    protected get deltaTime() {
        return cc.director.getDeltaTime();
    }

    /**
     * 设置节点多语言
     * @param key 多语言 key
     * @param params 多语言参数,支持多种占位符模式,格式化示例中的字符串：
     * ```ts
     * 1.{key}:
     * format('我叫{name},性别{sex},今年{age}岁', { name: '美男子', sex: '男', age: 20 });
     * 2.<%=key%>:
     * format("张三<%=name%> 年龄<%=age%>", {name: 'zhangsan', age: 20});
     * 3.%s/%d:
     * format("sounds/music/%s/%d", 'ab', 100);
     * 4.{index}:
     * format('我叫{0},性别{1},今年{2}岁', '美男子', '男', 20);
     * ```
     */
    protected setLang<T>(key: keyof T, ...params: any[]) {
        let langNodes = this.view.rc.gets(`LANG_${String(key)}`, cc.Node);
        if (!langNodes || langNodes.length === 0) {
            we.warn(`UISystem setLang, node LANG_${String(key)} not found`);
            return;
        }

        // 获取多语言key配置
        let langs = this.langsConf() ?? this.view.Scene.getComponent(I18nData)?.lang;
        if (!langs) {
            we.warn(`UISystem setLang, langs not found`);
            return;
        }

        langNodes.forEach((langNode) => {
            langNode.addComponentUnique(WEI18nFont);
            langNode.addComponentUnique(WEI18nLabelLite).setFormatResId(langs[String(key)], params);
        });
    }

    /**
     * 多语言 key 配置
     */
    protected langsConf(): object {
        return null;
    }

    /**
     * 多语参数配置
     */
    protected langParamsConf(): object {
        return null;
    }

    /**
     * 创建随组件生命周期销毁的 tween 对象
     * @param target tween 目标对象
     * @returns tween 对象
     */
    public tween<T>(target?: T) {
        if (target) {
            this.tweenTargets.add(target);
            return cc.tween(target);
        }

        return cc.tween();
    }

    /**
     * 执行一次的定时器
     * @param time 时长，单位【秒】,为0时，下帧执行
     * @param target 定时器生命周期绑定对象（Entity/cc.Node/cc.Component等）,存在 isValid()或者 isValid, 为 null 时，默认绑定到当前组件实例
     * @param tag 定时器 tag，当前组件实例
     * @returns
     */
    public async scheduleOnce(time: number, target?: TimerTarget, tag?: TimerTag): Promise<void> {
        await we.core.timer.scheduleOnce(time, target ?? this, tag ?? this);
    }

    /**
     * 周期执行的定时器
     * @param time 间隔时间，单位【秒】
     * @param func 定时器处理函数对象
     * @param target func 所属对象 Entity/cc.Node/cc.Component 等）, 为 null 时，默认绑定到当前组件实例
     * @param tag 定时器 tag，当前组件实例
     * @returns
     */
    public schedule(time: number, func: () => void, target?: TimerTarget, tag?: TimerTag): number;
    /**
     * 周期执行的定时器
     * @param time 间隔时间，单位【秒】
     * @param func func 所属对象 Entity/cc.Node/cc.Component等）, 为 null 时，默认绑定到当前组件实例
     * @param tag 定时器 tag，当前组件实例
     * @returns
     */
    public schedule(time: number, func: Func<any>, tag?: TimerTag): number;
    public schedule(time: number, ...args: any[]): number {
        let func: Func<any> = args[0];
        let tag: TimerTag;
        if (!(func instanceof Func)) {
            func = Func.create(func, args[1] ?? this);
            tag = args[2];
        } else {
            tag = args[1];
        }

        return we.core.timer.schedule(time, func, tag ?? this);
    }

    /**
     * 移除定时器
     * @param tag 定时器 tag，默认当前组件实例
     * @param isBroken 默认: true, 是否中断定时任务，后面逻辑不再执行
     * @returns
     */
    public removeTimerByTag(tag?: TimerTag, isBroken: boolean = true) {
        we.core.timer.removeByTag(tag ?? this, isBroken);
    }
    /**
     * 移除定时器
     * @param id 定时器 id
     * @param isBroken 默认: true，是否中断定时任务，后面逻辑不再执行
     * @returns
     */
    public removeTimerById(id: number, isBroken: boolean = true) {
        we.core.timer.removeById(id, isBroken);
    }

    /**
     * 获取资源
     * @param url 资源 url
     * @param type 资源类型
     */
    public getAsset<T extends cc.Asset>(url: string, type: { prototype: T }): T {
        return AssetManager.getAsset<T>(url, type);
    }

    /**
     * 加载资源
     * - 回调模式返回 handler(asset | null), 异步模式返回 resolve(asset | null), 是否加载成功业务层判断 asset 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 资源 url
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     * @param loading 加载 prefab 时是否延迟显示 loading, 默认 true
     */
    public loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: cc.Node | cc.Component | Entity, loading?: boolean): Promise<T | null>;
    public loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: Func<(asset?: T | null) => void>, loading?: boolean): Promise<T | null>;
    public loadAsset<T extends cc.Asset>(url: string, type: { prototype: T }, ...args: any[]): Promise<T | null> {
        return AssetManager.loadAsset(url, type, args[0] ?? this, args[1]);
    }

    /**
     * 加载同类型的多个资源
     * - 回调模式返回 handler(assets[] | null), 异步模式返回 resolve(assets[] | null), 是否加载成功业务层判断 assets 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * - assets 和 urls 的顺序一致
     * @param urls 资源 url 数组
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     */
    public loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, handler?: cc.Node | cc.Component | Entity): Promise<T[] | null>;
    public loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, handler?: Func<(assets?: T[] | null) => void>): Promise<T[] | null>;
    public loadAssetArray<T extends cc.Asset>(urls: string[], type: { prototype: T }, ...args: any[]): Promise<T[] | null> {
        return AssetManager.loadAssetArray(urls, type, args[0] ?? this);
    }

    /**
     * 加载目录下所有资源
     * - 回调模式返回 handler(assets[] | null), 异步模式返回 resolve(assets[] | null), 是否加载成功业务层判断 assets 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 目录 url
     * @param handler 资源加载生命周期处理器
     */
    public loadAssetDir(url: string, handler?: cc.Node | cc.Component | Entity): Promise<cc.Asset[] | null>;
    public loadAssetDir(url: string, handler?: Func<(assets?: cc.Asset[] | null) => void>): Promise<cc.Asset[] | null>;
    public loadAssetDir(url: string, ...args: any[]): Promise<cc.Asset[] | null> {
        return AssetManager.loadAssetDir(url, args[0] ?? this);
    }

    /**
     * 加载远程资源
     * - 回调模式返回 handler(asset | null), 异步模式返回 resolve(asset | null), 是否加载成功业务层判断 asset 非空即可
     * - 不抛出异常, 确保业务流程不中断, 设计原则: 加载失败时不中断流程, 最小化影响范围
     * @param url 远程资源 http url
     * @param type 资源类型
     * @param handler 资源加载生命周期处理器
     * @param loadingParent 局部 loading 父节点(size > 0)
     * @param extname 资源扩展名 如 .png .txt 等, 优先使用传入值, 为空时从 url 解析
     */
    public loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: cc.Node | cc.Component | Entity, loadingParent?: cc.Node, extname?: string): Promise<T | null>;
    public loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, handler?: Func<(asset?: T | null) => void>, loadingParent?: cc.Node, extname?: string): Promise<T | null>;
    public loadAssetRemote<T extends cc.Asset>(url: string, type: { prototype: T }, ...args: any[]): Promise<T | null> {
        return AssetManager.loadAssetRemote(url, type, args[0] ?? this, args[1], args[2]);
    }

    /**
     * 移除资源
     * @param url 资源 url
     * @param type 资源类型
     */
    public releaseAsset(path: string, type?: typeof cc.Asset) {
        AssetManager.removeAsset(path, type);
    }
}
