import { ISingletonAwake, Singleton } from '../../module/singleton/Singleton';
import { EventMsg } from '../../type/EventType';
import { UIType } from './UIType';
import { NodeEventOptions, NodeTouchEventHandler, UIEventCallback, UIViewHelper } from './UIViewHelper';

declare global {
    interface IUI {
        UISingletonView: typeof UISingletonView;
    }

    namespace we {
        namespace ui {
            type UISingletonView = InstanceType<typeof UISingletonView>;
        }
    }
}

export abstract class UISingletonView extends Singleton implements ISingletonAwake {
    // 预制体路径
    protected prefabUrl: string;
    // 预制体
    protected prefab: cc.Prefab = null;

    awake(): void {
        // 加载新场景前清空当前显示的公共UI
        cc.director.on(cc.Director.EVENT_BEFORE_SCENE_LOADING, () => {
            this.clear();
        });

        we.event<EventMsg>().on(
            'SkinChanged',
            () => {
                this.clear();
            },
            this
        );

        we.event<EventMsg>().on(
            'SceneChangeEnd',
            () => {
                this.clear();
            },
            this
        );
    }

    /** 清理 */
    protected clear() {
        this.prefab = null;
        this.prefabUrl = null;
    }

    /**
     * 为节点添加按钮事件
     * @param node 事件节点
     * @param handler 事件处理处理函数
     * @param isOnce 是否只执行一次点击事件,默认：false
     */
    protected cc_onBtnClick(node: cc.Node, handler: UIEventCallback, isOnce: boolean = false) {
        return UIViewHelper.onBtnClick(node, handler, isOnce);
    }

    protected cc_offBtnClick(node: cc.Node) {
        UIViewHelper.offBtnClick(node);
    }

    protected cc_onToggle(node: cc.Node, handler: UIEventCallback, toggleData: any | any[]) {
        UIViewHelper.onToggle(node, handler, toggleData);
    }

    protected cc_offToggle(node: cc.Node) {
        UIViewHelper.offToggle(node);
    }

    protected cc_onSlider(node: cc.Node, handler: UIEventCallback) {
        UIViewHelper.onSlider(node, handler);
    }

    protected cc_offSlider(node: cc.Node) {
        UIViewHelper.offSlider(node);
    }

    /**
     * 监听节点事件
     * @param node 事件节点
     * @param type 事件类型
     * @param handler 事件处理函数
     * @param options 选项配置
     */
    protected cc_onNodeEvent(node: cc.Node, type: string, handler: NodeTouchEventHandler, options?: NodeEventOptions) {
        UIViewHelper.onNodeEvent(node, type, handler, options);
    }
    /**
     * 关闭节点事件jsb监听
     * @param node
     * @param type
     */
    protected cc_offNodeEvent(node: cc.Node, type: string) {
        UIViewHelper.offNodeEvent(node, type);
    }

    protected cc_onEditBoxEvent(node: cc.Node, event: UIType.EditBoxEvent, handler: UIEventCallback) {
        UIViewHelper.onEditBoxEvent(node, event, handler);
    }

    protected cc_offEditBoxEvent(node: cc.Node, event: UIType.EditBoxEvent) {
        UIViewHelper.offEditBoxEvent(node, event);
    }

    public cc_onScrollViewEvent(node: cc.Node, event: UIType.ScrollViewEvent, handler: UIEventCallback) {
        UIViewHelper.onScrollViewEvent(node, event, handler);
    }

    public cc_offScrollViewEvent(node: cc.Node, event: UIType.ScrollViewEvent) {
        UIViewHelper.offScrollViewEvent(node, event);
    }
}

we.ui.UISingletonView = UISingletonView;
