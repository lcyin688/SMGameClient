import AssetManager from '../../manager/AssetManager';
import { IWaitType, ObjectWait } from '../../module/async/ObjectWait';
import { Entity } from '../../module/entity/Entity';
import { UIComponent } from './UIComponent';
import { UIEventManager } from './UIEventManager';
import { UIType } from './UIType';
import { UIViewHelper } from './UIViewHelper';

declare global {
    interface IUI {
        UIBase: typeof UIBase;
    }

    namespace we {
        namespace ui {
            type UIBase = InstanceType<typeof UIBase>;
        }
    }
}

/**
 * 等待UI关闭
 */
@we.decorator.typeRegister('WaitUIClose')
export class WaitUIClose<T> extends IWaitType {
    constructor(
        public error: any,
        public closeData?: T
    ) {
        super();
    }
}

@we.decorator.typeRegister('UIBase')
export class UIBase extends Entity {
    /**
     * UI view id
     */
    public mViewId: UIType.ViewId;
    /**
     * 预制体根节点
     */
    public uiRoot: cc.Node;
    /**
     * 根节点下Content节点
     */
    public uiContent: cc.Node;
    /**
     * 根节点下Mask节点
     */
    public uiMask: cc.Node;
    /**
     * 是否在队列中
     */
    public isInQueue: boolean;
    /**
     * ui窗口预制体的路径
     */
    public prefabPath: string;

    /**
     * UI用户配置
     */
    public uiConfig: UIType.UIConfig;

    public showConf: UIType.ShowConf;

    /**
     * 等待窗口关闭，并接受关闭时的返回数据
     */
    private waitUIClose: ObjectWait;

    /**
     * 窗口返回数据
     */
    public returnData: any;

    /**
     * 节点原始数据
     */
    public nodeRawData: {
        maskOpacity?: number;
        rootScale?: number;
        rootOpacity?: number;
        contentScale?: number;
    };

    protected awake(): void {
        this.isInQueue = false;
        this.uiRoot = null;
        this.uiContent = null;
        this.uiMask = null;
        this.mViewId = null;

        this.nodeRawData = {};

        // 初始化UI默认配置
        this.uiConfig = {
            viewType: UIType.UIViewType.Normal,
            useTween: true,
            useCustomTween: true,
            useBlockInput: UIType.UseBlockInputType.All,
            closeType: UIType.UICloseType.Remove,
            closeByMask: false,
            openTime: 0.3,
            closeTime: 0.2,
        };

        this.waitUIClose = this.addComponent(ObjectWait);
        this.returnData = null;
    }

    protected destroyBefore(): void {
        this.releaseUI();
    }

    protected destroy(): void {
        this.viewId = null;
        this.isInQueue = false;
    }

    notifyClose(error: any = null) {
        this.waitUIClose.notify(new WaitUIClose(error, this.returnData));
    }

    /**
     * 等待窗口关闭
     * @param timeout 超时时间单位【秒】0:用不超时，>0:超时时间
     * @returns
     */
    async waitClose<T>(timeout = 0) {
        return this.waitUIClose.wait(WaitUIClose, timeout) as Promise<WaitUIClose<T>>;
    }

    /**
     * 是否已经预加载
     */
    public get isPreLoad() {
        return this.uiRoot != null;
    }

    public get isActive(): boolean {
        return this.uiRoot?.active ?? false;
    }

    public set isActive(value: boolean) {
        this.uiRoot.active = value;
    }

    /**
     * 获取窗口Id
     */
    public get viewId() {
        if (this.mViewId == null) {
            we.warn('UIBase viewId, mViewId id is null');
        }
        return this.mViewId;
    }

    public set viewId(v: UIType.ViewId) {
        this.mViewId = v;
    }

    public setUIConfig(showData?: UIType.ShowConf) {
        this.showConf = showData;
        // 如果用户传递了UI配置，则进行合并配置操作，用户参数传递的UI配置优先级最高
        if (showData?.uiConfig) {
            this.uiConfig = {
                ...this.uiConfig,
                ...showData.uiConfig,
            };
        }
    }

    /**
     * 创建之前
     * 设置UI配置
     */
    async createBefore() {
        this.uiContent = this.uiRoot.getChildByName('content') ?? this.uiRoot.getChildByName('RCN_content') ?? this.uiRoot.getChildByName('RC_content');
        this.uiMask = this.uiRoot.getChildByName('mask') ?? this.uiRoot.getChildByName('RCN_mask') ?? this.uiRoot.getChildByName('RC_mask');

        if (!this.uiContent) {
            we.warn(`UIBase createBefore, prefab content node is null, please check prefab ${this.uiRoot.name}`);
        }

        switch (this.uiConfig.useBlockInput) {
            case UIType.UseBlockInputType.Root:
                this.uiRoot?.addComponentUnique(cc.BlockInputEvents);
                break;
            case UIType.UseBlockInputType.Mask:
                this.uiMask?.addComponentUnique(cc.BlockInputEvents);
                break;
            case UIType.UseBlockInputType.Main:
                this.uiContent?.addComponentUnique(cc.BlockInputEvents);
                break;
            case UIType.UseBlockInputType.All:
                this.uiRoot?.addComponentUnique(cc.BlockInputEvents);
                this.uiMask?.addComponentUnique(cc.BlockInputEvents);
                this.uiContent?.addComponentUnique(cc.BlockInputEvents);
                break;
            default:
                break;
        }
    }

    /**
     * 创建之后
     */
    public async createAfter() {
        if (this.uiConfig.closeByMask && this.uiMask) {
            UIViewHelper.onBtnClick(this.uiMask, () => {
                switch (this.uiConfig.closeType) {
                    case UIType.UICloseType.Hide:
                        this.getParent<UIComponent>().hide(this.viewId);
                        break;
                    case UIType.UICloseType.Remove:
                        this.getParent<UIComponent>().close(this.viewId, false);
                        break;
                    case UIType.UICloseType.Destroy:
                        this.getParent<UIComponent>().close(this.viewId, true);
                        break;
                    default:
                        break;
                }
                UIViewHelper.offBtnClick(this.uiMask);
            });
        }
    }

    public setRoot(rootNode: cc.Node) {
        if (this.uiRoot == null) {
            we.error(`UIBase setRoot, UIViewId ${this.viewId} uiTransform is null!!!`);
            return;
        }
        if (rootNode == null) {
            we.error(`UIBase setRoot, UIViewId ${this.viewId} rootNode is null!!!`);
            return;
        }

        // 注意第二个参数用途
        this.uiRoot.setParent(rootNode);
        this.uiRoot.position = cc.Vec3.ZERO;

        this.uiRoot.setSiblingIndex(rootNode.children.length - 1);
    }

    private releaseUI() {
        if (this.uiRoot != null && cc.isValid(this.uiRoot, true)) {
            try {
                UIEventManager.Inst.getHandler(this.viewId).beforeUnload(this);
            } finally {
            }
            this.uiRoot.destroy();
            this.uiRoot = null;

            if (this.uiConfig.closeType == UIType.UICloseType.Destroy) {
                AssetManager.removeAsset(this.prefabPath, cc.Prefab);
            }
        }
    }
}

we.ui.UIBase = UIBase;
