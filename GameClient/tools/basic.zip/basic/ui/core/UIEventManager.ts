import { EnumHelper } from '../../helper/EnumHelper';
import { Game } from '../../module/singleton/Game';
import { ISingletonAwake, ISingletonInstance, Singleton } from '../../module/singleton/Singleton';
import { WEReferenceCollector } from '../../module/resCollector/WEReferenceCollector';
import { UIEventHandler } from './UIEventHandler';
import { UILayer } from './UILayer';
import { UIPathManager } from './UIPathManager';
import { UIType } from './UIType';
import { UIViewHelper } from './UIViewHelper';

declare global {
    interface IUI {
        /**
         * 注册 UI 事件类型
         * @param type
         */
        addUIEventType(type: any): void;
    }
}

/** UI 事件类型缓存 */
const uiEventTypeCache = [];

/**
 * UI 事件管理器
 */
@we.decorator.typeSingleton<ISingletonInstance>('UIEventManager')
export class UIEventManager extends Singleton implements ISingletonAwake {
    public eventHandlers = new Map<UIType.ViewId, UIEventHandler>();

    static get Inst() {
        return this.getInstance();
    }

    awake(): void {
        Game.addSingleton(UIPathManager);

        const uiRoot = cc.find('Global');
        cc.game.addPersistRootNode(uiRoot);

        const rc = uiRoot.getComponent(WEReferenceCollector);

        EnumHelper.getEnumValues(UIType.UIViewType).forEach((type: UIType.UIViewType) => {
            UILayer.addLayer(type, rc.get<cc.Node>(EnumHelper.getKeyFromValue(UIType.UIViewType, type)));
        });

        this.eventHandlers.clear();

        this.loadUIEvent();
    }

    /**
     * 加载缓存的UI事件
     */
    loadUIEvent() {
        for (const type of uiEventTypeCache) {
            this.addHandler(type);
        }
        uiEventTypeCache.length = 0;
    }

    public addHandler(TYPE: any) {
        const viewId: UIType.ViewId = Reflect.getMetadata(UIType.UIAttributeSymbol.ViewId, TYPE);
        const viewUIClass = Reflect.getMetadata(UIType.UIAttributeSymbol.ViewUIClass, TYPE);

        const inst = new TYPE();
        if (!(inst instanceof UIEventHandler)) {
            we.error(`UIEventManager addHandler, message handle ${TYPE.name} need extends UIEventHandler`);
            return;
        }

        this.eventHandlers.set(viewId, inst);
        UIPathManager.Inst.registerViewId(viewUIClass, viewId);
    }

    public removeHandler(bundleName: string): void {
        let viewIds = UIPathManager.Inst.unregisterViewId(bundleName);
        viewIds.forEach((viewId) => {
            UIViewHelper.getViewIds(viewId).forEach((key) => {
                this.eventHandlers.delete(key);
            });
        });
    }

    public getHandler(viewId: UIType.ViewId): UIEventHandler {
        const viewIds = UIViewHelper.getViewIds(viewId);
        let handler = null;
        for (let id of viewIds) {
            handler = this.eventHandlers.get(id);
            if (handler) {
                return handler;
            }
        }
        we.warn(`UIEventManager getHandler, viewId : ${viewId} is not have any uiEvent`);
        return null;
    }
}

we.ui.addUIEventType = function (type) {
    if (UIEventManager.Inst) {
        UIEventManager.Inst.addHandler(type);
    } else {
        uiEventTypeCache.push(type);
    }
};
