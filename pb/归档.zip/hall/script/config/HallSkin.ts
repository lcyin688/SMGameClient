/**
 * 皮肤差异配置
 */
interface IHallSkinConfig {
    /** skin bg 小图标，限制区位置 */
    bg_limit_small_pos?: cc.Vec2;
    /** skin bg 大图标，限制区位置 */
    bg_limit_big_pos?: cc.Vec2;
    /** 默认缺省值 */
    DatePageItem_color_1: string;
    DatePageItem_color_2: string;
    VipView_off_x: number;
    VipView_off_y: number;
    headIcon_useClipCircle: boolean;
    /** 代理主界面是否为page */
    AgentMainIsPage: boolean;
    /** 其余自定义配置 */
    [key: string]: any;
}

const skin_cfg_bg: IHallSkinConfig = {
    bg_limit_small_pos: new cc.Vec2(-4, -25),
    bg_limit_big_pos: new cc.Vec2(-4, -78),
    DatePageItem_color_1: '#ffe87e',
    DatePageItem_color_2: '#D8885C',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#C52222', '#2FA34D', '#995C3D'],
    },
};

const skin_cfg_bg2: IHallSkinConfig = {
    bg_limit_small_pos: new cc.Vec2(-4, -25),
    bg_limit_big_pos: new cc.Vec2(-4, -78),
    DatePageItem_color_1: '#ffe87e',
    DatePageItem_color_2: '#D8885C',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#c95435', '#46bf57', '#bdbaae'],
    },
};

const skin_cfg_ct: IHallSkinConfig = {
    DatePageItem_color_1: '#FFCE0A',
    DatePageItem_color_2: '#C68157',
    VipView_off_x: -4,
    VipView_off_y: 4,
    headIcon_useClipCircle: true,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#FF1A30', '#4EC656', '#EA885E'],
    },
};

const skin_cfg_ct2: IHallSkinConfig = {
    DatePageItem_color_1: '#ffe87e',
    DatePageItem_color_2: '#D8885C',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#fe2f34', '#59dd4b', '#fff5bb'],
    },
};

const skin_cfg_ct3: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#FF3200', '#00A288', '#B96D39'],
    },
};

const skin_cfg_ct4: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#ff2211', '#00a288', '#b96d39'],
    },
};

const skin_cfg_cm1: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: false,
    RescueFundsRecordsItem: {
        color: ['#e92a55', '#00a288', '#7f61b6'],
    },
};

const skin_cfg_cm2: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: false,
    RescueFundsRecordsItem: {
        color: ['#FF3200', '#00a288', '#b96d39'],
    },
};

const skin_cfg_cm3: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: false,
    RescueFundsRecordsItem: {
        color: ['#e92a55', '#00a288', '#3860d7'],
    },
};

const skin_cfg_cm4: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#FF3200', '#5dadff', '#c6a8ff'],
    },
};

const skin_cfg_cm5: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: false,
    RescueFundsRecordsItem: {
        color: ['#d81313', '#019855', '#a83636'],
    },
};

const skin_cfg_cm6: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#ff5e5e', '#1edf7a', '#e0c375'],
    },
};

const skin_cfg_as: IHallSkinConfig = {
    GameItemBigSize: new cc.Size(230, 420),
    GameItemSmallSize: new cc.Size(200, 203),
    GameItemVerticalSpacing: 15,
    GameItemHorizontalSpacing: 0,
    GameItemBigIconMove: new cc.Vec2(-6, 0),
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    Calendar: {
        todayCol: '#50eb8b',
        dayCol: '#FFFFFF',
        stCol: ['#FFFFFF', '#FFFFFF', '#FFFFFF', '#FFFFFF'],
    },
    AgentMainIsPage: true,
    Bank: {
        InterestTipsPosOff: new cc.Vec2(-16, 15),
    },
    RescueFundsRecordsItem: {
        color: ['#fb3b96', '#ede62a', '#ffffff'],
    },
};
const skin_cfg_rs: IHallSkinConfig = {
    DatePageItem_color_1: '#b96d39',
    DatePageItem_color_2: '#d6986e',
    VipView_off_x: 0,
    VipView_off_y: 0,
    headIcon_useClipCircle: false,
    AgentMainIsPage: true,
    RescueFundsRecordsItem: {
        color: ['#ff5e5e', '#1edf7a', '#e0c375'],
    },
};

const HallSkinConfig: Readonly<{ [key in keyof typeof we.core.SkinCode]: IHallSkinConfig }> = {
    [we.core.SkinCode.bg]: skin_cfg_bg,
    [we.core.SkinCode.bg2]: skin_cfg_bg2,
    [we.core.SkinCode.ct]: skin_cfg_ct,
    [we.core.SkinCode.ct2]: skin_cfg_ct2,
    [we.core.SkinCode.ct3]: skin_cfg_ct3,
    [we.core.SkinCode.ct4]: skin_cfg_ct4,
    [we.core.SkinCode.cm1]: skin_cfg_cm1,
    [we.core.SkinCode.cm2]: skin_cfg_cm2,
    [we.core.SkinCode.cm3]: skin_cfg_cm3,
    [we.core.SkinCode.cm4]: skin_cfg_cm4,
    [we.core.SkinCode.cm5]: skin_cfg_cm5,
    [we.core.SkinCode.cm6]: skin_cfg_cm6,
    [we.core.SkinCode.as]: skin_cfg_as,
    [we.core.SkinCode.rs]: skin_cfg_rs,
};

export default class HallSkin {
    /**
     * 皮肤差异配置
     */
    public static get config(): IHallSkinConfig {
        return HallSkinConfig[we.core.flavor.getSkinCode()];
    }
}
