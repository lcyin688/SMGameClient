/** 事件名 */
export const HallEvent = {
    /** 显示初始游戏币 */
    SHOW_PLAYER_START_COIN: Symbol('SHOW_PLAYER_START_COIN'),

    /** 关闭 每日充值界面 */
    CLOSE_DAILY_RECHARGE_VIEW: Symbol('CLOSE_DAILY_RECHARGE_VIEW'),

    /** 邮件 读取内容 */
    EVENT_MAIL_CONTEXT_READ: Symbol('EVENT_MAIL_CONTEXT_READ'),

    /** 邮件 关闭内容界面 */
    EVENT_MAIL_CONTEXT_CLOSE: Symbol('EVENT_MAIL_CONTEXT_CLOSE'),

    /** 事件中心 防点击遮罩 */
    ACTIVITY_CENTER_MASK: Symbol('ACTIVITY_CENTER_MASK'),

    /** 事件中心打开全屏弹窗 */
    ACTIVITY_CENTER_OPEN_OTHER: Symbol('ACTIVITY_CENTER_OPEN_OTHER'),

    /** 切换vip界面 */
    SWITCHING_VIP: Symbol('SWITCHING_VIP'),

    /** 提现 更新绑定银行卡信息 */
    WITHDRAW_UPDATE_BANK_INFO: Symbol('WITHDRAW_UPDATE_BANK_INFO'),

    /** 提现 账号列表信息 */
    WITHDRAW_UPDATE_ACCOUNT_LIST: Symbol('WITHDRAW_UPDATE_ACCOUNT_LIST'),

    /** 提现更新金币 */
    WITHDRAW_UPDATE_GOLD: Symbol('WITHDRAW_UPDATE_GOLD'),

    /** 提现账号列表 更新账号选择 */
    WITHDRAW_ACCOUNT_SELECT: Symbol('WITHDRAW_ACCOUNT_SELECT'),

    /** 提现 刷新订单列表 */
    WITHDRAW_UPDATE_ORDER_LIST: Symbol('WITHDRAW_UPDATE_ORDER_LIST'),

    /** 游戏搜索 通知显示和关闭页面 */
    EVENT_SEARCH_GAME_SHOW: Symbol('EVENT_SEARCH_GAME_SHOW'),

    /** 跟新选择充值金额 */
    UPDATE_RECHARGE_AMOUNT: Symbol('UPDATE_RECHARGE_AMOUNT'),

    /** 更新充值订单列表 */
    RECHARGE_UPDATE_ORDER_LIST: Symbol('RECHARGE_UPDATE_ORDER_LIST'),

    /** 月签到刷新 */
    MONTH_SIGN_AWARD_UPDATE_DATA: Symbol('MONTH_SIGN_AWARD_UPDATE_DATA'),

    /** 周卡界面刷新 */
    WEEK_CARD_REFRESH_UI: Symbol('WEEK_CARD_REFRESH_UI'),

    /** 周卡显示状态更新 */
    WEEK_CARD_SHOW_STATUS: Symbol('WEEK_CARD_SHOW_STATUS'),

    /** 七日福利-更新数据 */
    SEVEN_DAY_UPDATE_DATA: Symbol('SEVEN_DAY_UPDATE_DATA'),
};
