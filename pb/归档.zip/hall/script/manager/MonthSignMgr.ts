import { HallLanguage } from '../const/HallLanguage';

/** 签到活动每日奖励领取状态 */
enum M_SignInDailyStatus {
    /** 未到领取时间 */
    DAILY_NOT_STARTED = 0,
    /** 可领取 */
    DAILY_CAN_CLAIM = 10,
    /** 可再领取 */
    DAILY_CAN_RECLAIM = 20,
    /** 已失效 */
    DAILY_EXPIRED = 30,
    /** 已领取 */
    DAILY_CLAIMED = 40,
    /** 可补签 */
    DAILY_CAN_TO_SIGN = 50,
}

/** 签到活动累计奖励领取状态 */
enum M_SignInCumulativeStatus {
    /** 未完成签到次数无法领取 */
    CUMULATIVE_NOT_FINISHED = 0,
    /** 可领取 */
    CUMULATIVE_CAN_CLAIM = 10,
    /** 已领取 */
    CUMULATIVE_CLAIMED = 20,
}

/** 签到领取奖励类型 */
enum M_SignCheckInAwardType {
    /** 普通签到奖励 */
    BONUS_NORMAL = 0,
    /** 随机倍数奖励 */
    BONUS_RANDOM_MULTIPLIER = 1,
}

/**
 * 月签到管理器，按照当前登陆天领取
 */
class MonthSign {
    /** 单例 */
    private static _instance: MonthSign | null = null;

    /** 上次请求时间 */
    private lastRequestTime: number = 0;

    /** 签到数据 */
    public data: ApiProto.SignInConfResp = null;

    private constructor() {}

    public static get Instance(): MonthSign {
        if (!this._instance) {
            this._instance = new MonthSign();
        }
        return this._instance;
    }

    public async init() {
        this.data = null;
        cc.director.on(we.common.EventName.CROSS_DAY_PUSH, this.onCrossDayPush, this);
        cc.director.on(we.common.EventName.RECHARGE_FINISH, this.onFinishRecharge, this);
        await this.asyncData();
        // 定时刷新
        const crossDayPush = () => {
            let delay = we.common.commonMgr.getCrossDayInterval();
            setTimeout(async () => {
                await this.asyncData();
                crossDayPush();
            }, delay);
        };
        crossDayPush();
    }

    /**
     * 同步数据
     */
    public async asyncData() {
        // 10s 内只请求一次
        if (this.lastRequestTime > 0 && Date.now() - this.lastRequestTime < 10 * 1000) {
            cc.director.emit(we.common.EventName.UPDATE_MONTH_MONTH_SIGN);
            return;
        }
        await this.getServerData();
        this.updateRedDot();
        cc.director.emit(we.common.EventName.UPDATE_MONTH_MONTH_SIGN);
    }

    /**
     * 跨天推送刷新
     */
    private onCrossDayPush() {
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.monthSign, 1, true);
    }

    /**
     * 完成充值刷新
     */
    private onFinishRecharge() {
        if (this.data && this.data.isUnlockMultiplier === true) {
            return;
        }
        this.asyncData();
    }

    /**
     * 活动是否开启
     */
    public isActive(): boolean {
        return !!this.data?.switchStatus;
    }

    /**
     * 获取签到数据
     */
    public getData(): ApiProto.SignInConfResp | null {
        return this.data;
    }

    /**
     * 获取签到奖励
     * @param day 日期
     * @param type 0 普通领取，1 倍数领取
     */
    public getDay(day: number): ApiProto.DailySignInAwardConf | undefined {
        return this.data?.dailySignInAwardConf.find((item) => {
            return item.day == day;
        });
    }

    /**
     * 获取最大累计签到天数
     */
    public getCumulativeSignMaxDay(): number {
        let arr = this.data?.cumulativeSignInAwardConf || [];
        if (!arr || arr.length == 0) {
            return 1;
        }
        return Math.max(
            ...arr.map((item) => {
                return item.count;
            })
        );
    }

    /**
     * 获取签到数据
     * @param showLoading 是否显示加载
     */
    private async getServerData(showLoading = false): Promise<ApiProto.SignInConfResp | null> {
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSignInfo(
                (res: ApiProto.SignInConfResp) => {
                    this.lastRequestTime = Date.now();
                    if (res) {
                        res.cumulativeSignInAwardConf.sort((a, b) => {
                            return a.count - b.count;
                        });
                        this.data = res;
                        resolve(res);
                    } else {
                        resolve(null);
                    }
                },
                () => {
                    this.data = null;
                    resolve(null);
                },
                showLoading
            );
        });
    }

    /**
     * 签到
     * @param day 日期
     * @param type 0 普通领取，1 倍数领取
     */
    public sign(day: number, type: M_SignCheckInAwardType, showLoading = true): Promise<ApiProto.SignInReceiveDailyRewardResp> {
        if (!this.data) {
            return null;
        }

        const d_day = this.getDay(day);
        if (!d_day || ![M_SignInDailyStatus.DAILY_CAN_CLAIM, M_SignInDailyStatus.DAILY_CAN_RECLAIM].includes(d_day.awardStatus)) {
            return null;
        }

        const data: ApiProto.SignInReceiveDailyRewardReq = { day: day, awardType: type };
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSignDailyReward(
                data,
                (res: ApiProto.SignInReceiveDailyRewardResp) => {
                    if (!res) {
                        resolve(null);
                        return;
                    }
                    if (this.data.isUnlockMultiplier == true && d_day.awardStatus == M_SignInDailyStatus.DAILY_CAN_CLAIM && type == M_SignCheckInAwardType.BONUS_RANDOM_MULTIPLIER) {
                        // 双签
                        this.data.cumulativeSignInCount++;
                        d_day.awardStatus = M_SignInDailyStatus.DAILY_CLAIMED;
                    } else if (type == M_SignCheckInAwardType.BONUS_NORMAL && d_day.awardStatus == M_SignInDailyStatus.DAILY_CAN_CLAIM) {
                        // 签到
                        this.data.cumulativeSignInCount++;
                        d_day.awardStatus = M_SignInDailyStatus.DAILY_CAN_RECLAIM;
                    } else if (type == M_SignCheckInAwardType.BONUS_RANDOM_MULTIPLIER && d_day.awardStatus == M_SignInDailyStatus.DAILY_CAN_RECLAIM) {
                        // 再签
                        d_day.awardStatus = M_SignInDailyStatus.DAILY_CLAIMED;
                    }
                    // 刷新
                    this.refreshCumulativeRewardStatus();
                    this.updateRedDot();
                    resolve(res);
                },
                (code) => {
                    this.onErrorCode(code);
                    resolve(null);
                },
                showLoading
            );
        });
    }

    /**
     * 补签
     * @param day 日期
     */
    public getReSignReward(day: number): Promise<ApiProto.SignInReCheckResp | null> {
        if (!this.data || !this.data.reSignInConf) {
            return null;
        }
        if (this.data.reSignInConf.availableCount <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HINT_1));
            return;
        }
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSignReSignReward(
                { day: day },
                (res: ApiProto.SignInReCheckResp) => {
                    if (!res) {
                        resolve(null);
                        return;
                    }
                    // 标记已领取
                    const dayData = this.getDay(day);
                    dayData.awardStatus = M_SignInDailyStatus.DAILY_CLAIMED;
                    this.data.cumulativeSignInCount++;
                    // 标记已使用
                    this.data.reSignInConf.availableCount--;
                    this.data.reSignInConf.usedCount++;
                    // 刷新累计奖励状态
                    this.refreshCumulativeRewardStatus();
                    // 刷新红点
                    this.updateRedDot();
                    resolve(res);
                },
                (code) => {
                    this.onErrorCode(code);
                    resolve(null);
                },
                true
            );
        });
    }

    /**
     * 签到活动累积领取请求
     * @param cumulativeCount 累计签到次数
     */
    public getAccumulateReward(cumulativeCount: number): Promise<ApiProto.SignInMonthlyCumulativeRewardResp> {
        const data = this.data?.cumulativeSignInAwardConf.find((item) => {
            return item.count === cumulativeCount;
        });

        if (!data || data.awardStatus != M_SignInCumulativeStatus.CUMULATIVE_CAN_CLAIM) {
            return;
        }

        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSignAccumulateReward(
                { cumulativeCount: cumulativeCount },
                (res: ApiProto.SignInMonthlyCumulativeRewardResp) => {
                    if (!res) {
                        resolve(null);
                        return;
                    }
                    // 已领取
                    data.awardStatus = M_SignInCumulativeStatus.CUMULATIVE_CLAIMED;
                    this.updateRedDot();
                    resolve(res);
                },
                (code) => {
                    this.onErrorCode(code);
                    resolve(null);
                },
                true
            );
        });
    }

    private onErrorCode(code: number) {
        const codeArr = [
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11000,
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11001,
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11002,
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11003,
        ];
        if (codeArr.includes(code)) {
            this.asyncData();
        } else if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11007) {
            if (this.data.totalSignInRechargeConf) {
                let value = we.common.utils.formatPrice(this.data.totalSignInRechargeConf.totalSignInRechargeAmount, false, false);
                let text = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_9, value);
                we.commonUI.showToast(text);
            }
        } else {
            we.commonUI.showToastById(HallLanguage.BANK_HINT_6);
        }
    }

    /**
     * 刷新累计奖励状态
     */
    private refreshCumulativeRewardStatus() {
        if (this.data && this.data.cumulativeSignInAwardConf) {
            const award = this.data?.cumulativeSignInAwardConf.find((item) => {
                return item.count == this.data.cumulativeSignInCount;
            });

            // 如果当前累计奖励状态为未开始，则修改为可领取
            if (award && award.awardStatus == M_SignInCumulativeStatus.CUMULATIVE_NOT_FINISHED) {
                award.awardStatus = M_SignInCumulativeStatus.CUMULATIVE_CAN_CLAIM;
            }
        }
    }

    /**
     * 更新红点
     */
    private updateRedDot() {
        let isShow = false;

        if (this.data) {
            // 遍历是否存在可领取日期
            isShow = this.data.dailySignInAwardConf.some((day) => {
                return day.awardStatus == M_SignInDailyStatus.DAILY_CAN_CLAIM || (day.awardStatus == M_SignInDailyStatus.DAILY_CAN_RECLAIM && this.data.isUnlockMultiplier == true);
            });

            // 遍历是否存在可领取累计奖励
            isShow =
                isShow ||
                this.data.cumulativeSignInAwardConf.some((item) => {
                    return item.awardStatus == M_SignInCumulativeStatus.CUMULATIVE_CAN_CLAIM;
                });
        }

        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.monthSign, isShow ? 1 : 0, true);
    }

    /**
     * 动态计算进度值
     * @param signInDays 已签到天数
     * @param rewardConfig 奖励配置
     */
    public calculateProgress(signInDays: number, rewardConfig: ApiProto.CumulativeSignInAwardConf[]) {
        if (rewardConfig.length <= 0) {
            return 0;
        }
        const totalDays = rewardConfig[rewardConfig.length - 1].count;
        if (signInDays > totalDays) {
            return 1;
        }
        const totalSegments = rewardConfig.length;
        const segmentProgress = 1 / totalSegments;
        let progress = 0;
        for (let i = 0; i < totalSegments; i++) {
            const startDay = i === 0 ? 1 : rewardConfig[i - 1].count;
            const endDay = rewardConfig[i].count;
            if (signInDays >= startDay && signInDays <= endDay) {
                const relativeProgress = (signInDays - startDay + 1) / (endDay - startDay + 1);
                progress += segmentProgress * relativeProgress;
                break;
            } else if (signInDays > endDay) {
                progress += segmentProgress;
            }
        }
        return progress;
    }
}

/**
 * 月签到管理器，按照登陆次数累计领取
 */
class MonthSign2 {
    /** 单例 */
    private static _instance: MonthSign2 | null = null;

    /** 签到数据 */
    public data: ApiProto.NewSignInConfResp = null;

    private constructor() {}

    public static get Instance(): MonthSign2 {
        if (!this._instance) {
            this._instance = new MonthSign2();
        }
        return this._instance;
    }

    public async init() {
        this.data = null;
        cc.director.on(we.common.EventName.CROSS_DAY_PUSH, this.onCrossDayPush, this);
        cc.director.on(we.common.EventName.RECHARGE_FINISH, this.onFinishRecharge, this);
        await this.asyncData();
        // 定时刷新
        const crossDayPush = () => {
            let delay = we.common.commonMgr.getCrossDayInterval();
            setTimeout(async () => {
                await this.asyncData();
                crossDayPush();
            }, delay);
        };
        crossDayPush();
    }

    /**
     * 同步数据
     */
    public async asyncData() {
        await this.getServerData();
        this.updateRedDot();
        cc.director.emit(we.common.EventName.UPDATE_MONTH_MONTH_SIGN2);
    }

    /**
     * 跨天推送刷新
     */
    private onCrossDayPush() {
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.monthSign2, 1, true);
    }

    /**
     * 完成充值刷新
     */
    private onFinishRecharge() {
        if (this.data && this.data.isUnlockMultiplier === true) {
            return;
        }
        this.asyncData();
    }

    /**
     * 活动是否开启
     */
    public isActive(): boolean {
        return !!this.data?.switchStatus;
    }

    /**
     * 获取签到数据
     */
    public getData(): ApiProto.NewSignInConfResp | null {
        return this.data;
    }

    /**
     * 获取签到奖励
     * @param day 日期
     */
    public getDay(day: number): ApiProto.DailySignInAwardConf | undefined {
        return this.data?.dailySignInAwardConf.find((item) => {
            return item.day == day;
        });
    }

    /**
     * 获取最大累计签到天数
     */
    public getCumulativeSignMaxDay(): number {
        let arr = this.data?.cumulativeSignInAwardConf || [];
        if (!arr || arr.length == 0) {
            return 1;
        }
        return Math.max(
            ...arr.map((item) => {
                return item.count;
            })
        );
    }

    /**
     * 获取签到数据
     * @param showLoading 是否显示加载
     */
    private async getServerData(showLoading = false): Promise<ApiProto.NewSignInConfResp | null> {
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSign2Info(
                (res: ApiProto.NewSignInConfResp) => {
                    if (res) {
                        res.cumulativeSignInAwardConf.sort((a, b) => {
                            return a.count - b.count;
                        });
                        this.data = res;
                        resolve(res);
                    } else {
                        resolve(null);
                    }
                },
                () => {
                    this.data = null;
                    resolve(null);
                },
                showLoading
            );
        });
    }

    /**
     * 签到
     * @param day 日期
     * @param type 0 普通领取，1 倍数领取
     */
    public sign(day: number, type: M_SignCheckInAwardType, showLoading = true): Promise<ApiProto.SignInReceiveDailyRewardResp> {
        if (!this.data) {
            return null;
        }

        const d_day = this.getDay(day);
        if (!d_day || ![M_SignInDailyStatus.DAILY_CAN_CLAIM, M_SignInDailyStatus.DAILY_CAN_RECLAIM].includes(d_day.awardStatus)) {
            return null;
        }

        const data: ApiProto.SignInReceiveDailyRewardReq = { day: day, awardType: type };
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSign2DailyReward(
                data,
                async (res: ApiProto.SignInReceiveDailyRewardResp) => {
                    if (!res) {
                        resolve(null);
                        return;
                    }
                    if (this.data.isUnlockMultiplier == true && d_day.awardStatus == M_SignInDailyStatus.DAILY_CAN_CLAIM && type == M_SignCheckInAwardType.BONUS_RANDOM_MULTIPLIER) {
                        // 双签
                        this.data.cumulativeSignInCount++;
                        d_day.awardStatus = M_SignInDailyStatus.DAILY_CLAIMED;
                    } else if (type == M_SignCheckInAwardType.BONUS_NORMAL && d_day.awardStatus == M_SignInDailyStatus.DAILY_CAN_CLAIM) {
                        // 签到
                        this.data.cumulativeSignInCount++;
                        d_day.awardStatus = M_SignInDailyStatus.DAILY_CAN_RECLAIM;
                    } else if (type == M_SignCheckInAwardType.BONUS_RANDOM_MULTIPLIER && d_day.awardStatus == M_SignInDailyStatus.DAILY_CAN_RECLAIM) {
                        // 再签
                        d_day.awardStatus = M_SignInDailyStatus.DAILY_CLAIMED;
                    }
                    await this.asyncData();
                    resolve(res);
                },
                (code) => {
                    this.onErrorCode(code);
                    resolve(null);
                },
                showLoading
            );
        });
    }

    /**
     * 补签
     * @param day 日期
     */
    public getReSignReward(day: number): Promise<ApiProto.SignInReCheckResp | null> {
        if (!this.data || !this.data.reSignInConf) {
            return null;
        }
        if (this.data.reSignInConf.availableCount <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HINT_1));
            return;
        }
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSign2ReSignReward(
                { day: day },
                async (res: ApiProto.SignInReCheckResp) => {
                    if (!res) {
                        resolve(null);
                        return;
                    }
                    await this.asyncData();
                    resolve(res);
                },
                (code) => {
                    this.onErrorCode(code);
                    resolve(null);
                },
                true
            );
        });
    }

    /**
     * 签到活动累积领取请求
     * @param cumulativeCount 累计签到次数
     */
    public getAccumulateReward(cumulativeCount: number): Promise<ApiProto.SignInMonthlyCumulativeRewardResp> {
        const data = this.data?.cumulativeSignInAwardConf.find((item) => {
            return item.count === cumulativeCount;
        });

        if (!data || data.awardStatus != M_SignInCumulativeStatus.CUMULATIVE_CAN_CLAIM) {
            return;
        }

        return new Promise((resolve, reject) => {
            we.common.apiMgr.getMonthSign2AccumulateReward(
                { cumulativeCount: cumulativeCount },
                (res: ApiProto.SignInMonthlyCumulativeRewardResp) => {
                    if (!res) {
                        resolve(null);
                        return;
                    }
                    // 已领取
                    data.awardStatus = M_SignInCumulativeStatus.CUMULATIVE_CLAIMED;
                    this.updateRedDot();
                    resolve(res);
                },
                (code) => {
                    this.onErrorCode(code);
                    resolve(null);
                },
                true
            );
        });
    }

    private onErrorCode(code: number) {
        const codeArr = [
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11000,
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11001,
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11002,
            we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11003,
        ];
        if (codeArr.includes(code)) {
            this.asyncData();
        } else if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11007) {
            if (this.data.cumulativeSignInAwardConf) {
                let value = we.common.utils.formatPrice(this.data.cumulativeSignInAwardConf[1].needRecharge, false, false);
                let text = we.core.langMgr.getLangText(HallLanguage.DAILY_CHECK_HALL_9, value);
                we.commonUI.showToast(text);
            }
        } else {
            we.commonUI.showToastById(HallLanguage.BANK_HINT_6);
        }
    }

    /**
     * 更新红点
     */
    private updateRedDot() {
        let isShow = false;

        if (this.data) {
            // 遍历是否存在可领取日期
            isShow = this.data.dailySignInAwardConf.some((day) => {
                return day.awardStatus == M_SignInDailyStatus.DAILY_CAN_CLAIM || (day.awardStatus == M_SignInDailyStatus.DAILY_CAN_RECLAIM && this.data.isUnlockMultiplier == true);
            });

            // 遍历是否存在可领取累计奖励
            isShow =
                isShow ||
                this.data.cumulativeSignInAwardConf.some((item) => {
                    return item.awardStatus == M_SignInCumulativeStatus.CUMULATIVE_CAN_CLAIM;
                });
        }

        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.monthSign2, isShow ? 1 : 0, true);
    }

    /**
     * 动态计算进度值
     * @param signInDays 已签到天数
     * @param rewardConfig 奖励配置
     */
    public calculateProgress(signInDays: number, rewardConfig: ApiProto.CumulativeSignInAwardConf[]) {
        if (rewardConfig.length <= 0) {
            return 0;
        }
        const totalDays = rewardConfig[rewardConfig.length - 1].count;
        if (signInDays > totalDays) {
            return 1;
        }
        const totalSegments = rewardConfig.length;
        const segmentProgress = 1 / totalSegments;
        let progress = 0;
        for (let i = 0; i < totalSegments; i++) {
            const startDay = i === 0 ? 1 : rewardConfig[i - 1].count;
            const endDay = rewardConfig[i].count;
            if (signInDays >= startDay && signInDays <= endDay) {
                const relativeProgress = (signInDays - startDay + 1) / (endDay - startDay + 1);
                progress += segmentProgress * relativeProgress;
                break;
            } else if (signInDays > endDay) {
                progress += segmentProgress;
            }
        }
        return progress;
    }
}

const MonthSignMgr = {
    /** 月签到 */
    month: MonthSign.Instance,
    /** 月签到 */
    month2: MonthSign2.Instance,
    /** 月签到每日奖励领取状态 */
    m_status: M_SignInDailyStatus,
    /** 月签到累计奖励领取状态 */
    m_cumulativeStatus: M_SignInCumulativeStatus,
    /** 月签到领取奖励类型 */
    m_signCheckInAwardType: M_SignCheckInAwardType,
};

export default MonthSignMgr;
