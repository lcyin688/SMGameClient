import { HallRes } from '../config/HallRes';

/**
 * 入口游戏图标
 */
export interface ILoadHallGameIcon {
    // 游戏 id
    gameId: number;
    // 是否是大图标
    isBig: boolean;
    // 动画
    anim: sp.Skeleton;
    // 图标
    image: cc.Sprite;
    // 回调
    callBack?: Function;
    // 继承 NodeBase 的组件本身，需要保护 gameId 属性
    self: any;
}

/**
 *  入口游戏图标管理
 *  https://docs.cocos.com/creator/2.4/manual/zh/getting-started/faq.html?h=sp.skeletondata
 *  https://docs.cocos.com/creator/3.8/manual/zh/asset/spine.html
 */
export default class HallGameIconMgr {
    /** 加载 icon */
    public static loadIcon(data: ILoadHallGameIcon) {
        let isSupportRemote = false;

        // 判断是否支持远程加载
        const gameIcon = we.core.projectConfig.settingsConfig.gameDetails?.[data.gameId]?.icon;
        if (gameIcon) {
            const iconUrl = data.isBig ? gameIcon.bigIconImg : gameIcon.smallIconImg;
            isSupportRemote = !!iconUrl && iconUrl.length > 0;
        }

        if (isSupportRemote) {
            this.loadRemoteIcon(data);
        } else {
            this.loadLocalIcon(data);
        }
    }

    /** 加载本地 icon */
    private static loadLocalIcon(data: ILoadHallGameIcon) {
        const gameId = data.gameId;
        const isBig = data.isBig;

        let animPath = we.core.utils.stringFormat(HallRes.ctryres.gameEnter, gameId + '');
        animPath = we.core.assetMgr.getCountryAssetUrl(animPath);
        const isExistAnim = we.core.assetMgr.isAssetExist(animPath, sp.SkeletonData);

        // anim
        if (isExistAnim) {
            we.core.assetMgr.loadAsset(animPath, sp.SkeletonData, data.anim, false).then((asset) => {
                // 确定此资源是否为当前 icon 所需资源
                if (gameId !== data.self?.gameId) {
                    return;
                }
                if (asset && cc.isValid(data.anim)) {
                    data.anim.skeletonData = asset;
                    we.common.utils.setSkeletonSkin(data.anim);
                    if (we.core.flavor.getSkinOrientation() === we.core.ScreenOrientation.PORTRAIT) {
                        data.anim.setAnimation(0, 'animation', true);
                    } else {
                        data.anim.setAnimation(0, isBig ? 'animation1' : 'animation2', true);
                    }
                    data.anim.node.opacity = 255;
                    typeof data.callBack == 'function' && data.callBack();
                }
            });
        } else {
            // image
            const iconPath = animPath + (isBig ? '_big' : '');
            we.core.assetMgr.loadAsset(iconPath, cc.SpriteFrame, data.image.node, false).then((asset) => {
                // 确定此资源是否为当前 icon 所需资源
                if (gameId !== data.self?.gameId) {
                    return;
                }
                if (asset && cc.isValid(data.image)) {
                    data.image.spriteFrame = asset;
                    data.image.node.opacity = 255;
                    data.image.type = cc.Sprite.Type.SIMPLE;
                    data.image.sizeMode = cc.Sprite.SizeMode.TRIMMED;
                    typeof data.callBack == 'function' && data.callBack();
                }
            });
        }
    }

    /** 加载远程 icon */
    private static async loadRemoteIcon(data: ILoadHallGameIcon) {
        const isBig = data.isBig;
        const gameId = data.gameId;
        const gameIcon = we.core.projectConfig.settingsConfig.gameDetails[gameId].icon;
        const imageUrl = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, data.isBig ? gameIcon.bigIconImg : gameIcon.smallIconImg);

        // 判断是否支持远程动画
        let isExistAnim = false;
        const ske = data.isBig ? gameIcon.bigIconJson : gameIcon.smallIconJson;
        const atlas = data.isBig ? gameIcon.bigIconAtlas : gameIcon.smallIconAtlas;
        isExistAnim = !!ske && !!atlas && ske.length > 0 && atlas.length > 0;

        // anim
        if (isExistAnim) {
            const skeUrl = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, ske);
            const atlasUrl = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, atlas);

            const tasks = [];
            tasks.push(we.core.assetMgr.loadAssetRemote(imageUrl, cc.Texture2D, data.anim));
            tasks.push(we.core.assetMgr.loadAssetRemote(skeUrl, cc.TextAsset, data.anim, null, '.txt'));
            tasks.push(we.core.assetMgr.loadAssetRemote(atlasUrl, cc.TextAsset, data.anim, null, '.txt'));

            try {
                const [texture, spineJson, atlasJson] = await Promise.all(tasks);
                // 确定此资源是否为当前 icon 所需资源，由于是虚拟列表，异步加加载会有资源对不齐的情况，所以需要判断
                if (gameId !== data.self?.gameId || !cc.isValid(data.anim)) {
                    return;
                }
                if (!texture || !spineJson || !atlasJson) {
                    we.warn(`HallGameIconMgr loadRemoteIcon, asset load failed, gameId: ${gameId}`);
                    return;
                }
                const asset = new sp.SkeletonData();
                // 可以传入任意字符串，但不能为空
                // https://docs.cocos.com/creator/3.8/manual/zh/asset/spine.html
                asset['_uuid'] = skeUrl;
                asset.skeletonJson = (spineJson as cc.TextAsset).text;
                asset.atlasText = (atlasJson as cc.TextAsset).text;
                asset.textures = [texture as cc.Texture2D];
                // 需要设置图片名称
                asset['textureNames'] = ['game_icon.png'];
                data.anim.skeletonData = asset;
                we.common.utils.setSkeletonSkin(data.anim);
                data.anim.node.opacity = 255;
                // 竖版皮肤
                if (we.core.flavor.getSkinOrientation() === we.core.ScreenOrientation.PORTRAIT) {
                    data.anim.setAnimation(0, 'animation', true);
                } else {
                    data.anim.setAnimation(0, isBig ? 'animation1' : 'animation2', true);
                }
                typeof data.callBack == 'function' && data.callBack();
            } catch (err) {
                we.error(`HallGameIconMgr loadRemoteIcon, gameId: ${gameId}, err: ${JSON.stringify(err.message || err)}`);
            }
        } else {
            // image
            let spf = await we.core.assetMgr.loadAssetRemote(imageUrl, cc.SpriteFrame, data.image);
            if (gameId !== data.self?.gameId || !cc.isValid(data.image) || !spf) {
                return;
            }
            data.image.spriteFrame = spf;
            data.image.node.opacity = 255;
            data.image.type = cc.Sprite.Type.SIMPLE;
            data.image.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            typeof data.callBack == 'function' && data.callBack();
        }
    }
}
