import { HallPageEnum } from '../const/HallConst';
import { EnterGameFlow } from '../task/entergame/EnterGameFlow';
import { HallViewId } from '../view/HallViewId';
import HallMgr from './HallMgr';
import { HallPopupMgr } from './HallPopupMgr';
import MonthSignMgr from './MonthSignMgr';
import NewbieGuideMgr from './NewbieGuideMgr';
import SevenDayMgr from './SevenDayMgr';
import WeekCardMgr from './WeekCardMgr';

/** 跳转类型 */
export const JUMP_WAY = {
    NULL: 0,
    /** 游戏内 */
    IN_GAME: 1,
    /** 游戏外 */
    OUT_GAME: 2,
};

interface IJumpModule {
    /**
     * 弹出条件
     * @param autoPop 自动弹出，主要用于自动弹窗队列
     * @param args 参数
     * @returns
     */
    condition: (autoPop?: boolean, ...args: any[]) => boolean;
    /**
     * 弹出函数
     * @param args
     * @returns
     */
    func: (...args: any[]) => Promise<any | void>;
}

class JumpModMgr {
    public readonly conf: { [k: string]: IJumpModule } = {
        // 授权弹窗
        [we.common.JumpCmd.Notice_Permission]: {
            condition: (autoPop?: boolean, Permission_Type?: number, isShowDlg: boolean = true) => {
                if (!(cc.sys.isNative || we.core.nativeUtil.isPlatformLand())) {
                    return false;
                }

                let cvc = we.core.nativeUtil.getVersionCode();
                if (cvc < 48) {
                    return false;
                } // h5落地页框架 cvc: 47

                let type = Permission_Type || HallMgr.Permission_Type.NOTIFICATION;
                let isOpenDialog = false;
                switch (type) {
                    case HallMgr.Permission_Type.NOTIFICATION:
                        {
                            let localStorage = !!we.kit.storage.get('sys', 'app_permission_notification');
                            if (localStorage) {
                                we.core.nativeUtil.oneSignalRequestPermission();
                                isOpenDialog = true;
                            }
                        }
                        break;
                    default:
                        break;
                }

                // 授权弹窗则不需要再弹
                if (isOpenDialog) {
                    return false;
                }

                if (isShowDlg) {
                    we.currentUI.show(HallViewId.AppPermissionDlg, type);
                }

                return true;
            },
            func: () => {
                return new Promise((resolve) => {
                    resolve(null);
                });
            },
        },

        // 系统维护弹窗
        [we.common.JumpCmd.System_Maintain]: {
            condition: () => {
                let maintenanceData = we.common.pushMsgMgr.pushMsgCacheList.get(we.common.pushMsgMgr.PUSH_TYPE.SYS_MAINTENANCE);
                if (maintenanceData && maintenanceData.length > 0) {
                    return true;
                }
                return false;
            },
            func: () => {
                return we.common.commonMgr.servicesMaintainDialog(() => {
                    we.common.userMgr.clearLoginData(false, `PUSH_TYPE.SYS_MAINTENANCE`);
                    we.common.pushMsgMgr.pushMsgCacheList && we.common.pushMsgMgr.pushMsgCacheList.clear();
                });
            },
        },

        // tokenV2 错误，返回登录界面
        [we.common.JumpCmd.Naming_Token_Error]: {
            condition: () => {
                return we.common.namingServiceMgr.goLoginTag;
            },
            func: () => {
                return new Promise((resolve) => {
                    we.common.namingServiceMgr.goLogin();
                    resolve(null);
                });
            },
        },

        // 未完成游戏弹窗
        [we.common.JumpCmd.Uncompleted_Game]: {
            condition: () => {
                let data = we.common.pushMsgMgr.pushMsgCacheList.get(we.common.pushMsgMgr.PUSH_TYPE.RECOVER_LAST_GAME);
                return !!data;
            },
            func: () => {
                let data = we.common.pushMsgMgr.pushMsgCacheList.get(we.common.pushMsgMgr.PUSH_TYPE.RECOVER_LAST_GAME);
                if (data) {
                    we.common.pushMsgMgr.pushMsgCacheList.set(we.common.pushMsgMgr.PUSH_TYPE.RECOVER_LAST_GAME, null);
                    let gameId = data[0]?.['game_id'];
                    let roomKind = data[0]?.['room_id'];
                    if (we.core.gameConfig.isSubGame(gameId)) {
                        return we.common.commonMgr.unfinishedGameDialog(gameId, roomKind, () => {
                            cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Uncompleted_Game);
                        });
                    }
                }

                return new Promise((resolve) => {
                    resolve(null);
                });
            },
        },

        // 子游戏返回大厅处理，在线热更
        [we.common.JumpCmd.Game_Back_Hall]: {
            condition: () => {
                let result = we.common.gameOverEventMgr.gameOverCommonEventHandle();
                return result;
            },
            func: () => {
                // TODO NewbieGuideMgr 优化新手引导模块，是否开启引导与打开引导逻辑分离
                return new Promise<void>((resolve) => {
                    resolve();
                });
            },
        },

        // 启动跳转模块
        [we.common.JumpCmd.App_Launcher_Jump]: {
            condition: () => {
                if (typeof we.core.projectConfig.appLauncherJump == 'string' && we.core.projectConfig.appLauncherJump.length > 0) {
                    return true;
                }

                return false;
            },
            func: () => {
                we.log(`JumpModMgr openPopup, appLauncherJump: ${we.core.projectConfig.appLauncherJump}`);
                we.core.projectConfig.appLauncherJump = null;

                return this.jumpToModule(we.core.projectConfig.appLauncherJump);
            },
        },

        // 功能引导
        [we.common.JumpCmd.Module_Guide]: {
            condition: () => {
                // TODO NewbieGuideMgr 优化新手引导模块，是否开启引导与打开引导逻辑分离
                let result = NewbieGuideMgr.judgeStartModGuide(NewbieGuideMgr.getModGuides());
                return result;
            },
            func: () => {
                return new Promise<void>((resolve) => {
                    resolve();
                });
            },
        },

        // 自定义弹窗
        [we.common.JumpCmd.Custom_Dlg]: {
            condition: () => {
                let result = HallPopupMgr.Inst.getCustomPopConf();
                return result.length > 0;
            },
            func: (...args: any) => {
                return we.currentUI.show(HallViewId.CustomPopDlg, ...args);
            },
        },

        // 下载引导
        [we.common.JumpCmd.Download_Guide]: {
            condition: () => {
                let result = false;
                if (we.common.downloadGuideMgr?.isOpenGuide()) {
                    if (we.common.downloadGuideMgr.forceGuideConf?.forceLeadSwitch) {
                        result = true;
                    }
                }
                return result;
            },
            func: () => {
                return we.currentUI.show(HallViewId.DownLoadGuideDlg);
            },
        },

        // 最近游戏
        [we.common.JumpCmd.Recent_Game]: {
            condition: () => {
                return true;
            },
            func: () => {
                return new Promise<void>((resolve) => {
                    HallMgr.openRecentGame();
                    resolve();
                });
            },
        },

        // 官方 apk 下载
        [we.common.JumpCmd.Official_Pkg]: {
            condition: () => {
                let result = !!we.core.projectConfig.settingsConfig?.dApk;
                return result;
            },
            func: () => {
                return new Promise<void>((resolve) => {
                    let url = we.core.projectConfig.settingsConfig.dApk;
                    we.core.nativeUtil.openUrl(url);
                    resolve();
                });
            },
        },

        // 官方网址
        [we.common.JumpCmd.Official_Web]: {
            condition: () => {
                let result = !!we.core.projectConfig.commonConfig?.officialWebsiteDownAddress;
                if (!result) {
                    we.warn(`JumpModMgr jumpModules, officialWebsiteDownAddress is null`);
                }

                return result;
            },
            func: () => {
                return new Promise<void>((resolve) => {
                    let url = we.core.projectConfig.commonConfig?.officialWebsiteDownAddress;
                    we.core.nativeUtil.openUrl(url);
                    resolve();
                });
            },
        },

        // 设置界面
        [we.common.JumpCmd.Setting]: {
            condition: () => {
                return true;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.UserCenterSettingDlg);
            },
        },

        // 个人中心
        [we.common.JumpCmd.User_center]: {
            condition: () => {
                return true;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.UserCenterDlg);
            },
        },

        // 充值
        [we.common.JumpCmd.Recharge]: {
            condition: () => {
                return true;
            },
            func: (...args) => {
                return HallMgr.openStoreDlg(...args);
            },
        },

        // 充值引导
        [we.common.JumpCmd.Recharge_Guide]: {
            condition: () => {
                return true;
            },
            func: (...args) => {
                return new Promise<void>((resolve) => {
                    if (we.common.storeMgr.shopConf) {
                        we.core.nativeUtil.openUrl(we.common.storeMgr.shopConf.payTypeGuideUrl);
                        resolve();
                    } else {
                        we.common.storeMgr.getShopConfig(() => {
                            if (we.common.userMgr.isLogin()) {
                                we.core.nativeUtil.openUrl(we.common.storeMgr.shopConf.payTypeGuideUrl);
                            }
                            resolve();
                        });
                    }
                });
            },
        },

        // 提现
        [we.common.JumpCmd.Withdraw]: {
            condition: (autoPop: boolean) => {
                // 账号类型判定
                if (!we.common.userMgr.isFormal()) {
                    if (NewbieGuideMgr.IsInHallGuide()) {
                        cc.director.emit(we.common.EventName.UPDATE_GUIDE_STEP);
                    }

                    // 不是自动弹窗才触发账号绑定弹窗
                    !autoPop && we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
                    return false;
                }

                // 提现次数判定下载官方包，仅针对马甲包和 h5 苹果相关系统不做处理
                if (we.common.downloadGuideMgr.isOpenGuide(we.common.downloadGuideMgr.Type.Withdraw)) {
                    if (NewbieGuideMgr.IsInHallGuide()) {
                        cc.director.emit(we.common.EventName.ON_HIDE_GUIDE); // 关闭引导
                    }
                    we.currentUI.show(HallViewId.WithdrawGuideDownloadDlg);
                    return false;
                }

                if (!we.common.withdrawMgr.openNormalChn && !we.common.withdrawMgr.openVipChn) {
                    if (NewbieGuideMgr.IsInHallGuide()) {
                        cc.director.emit(we.common.EventName.ON_HIDE_GUIDE); // 关闭引导
                    }
                    // 全部提现通道已关闭
                    cc.director.emit(we.common.EventName.HALL_IS_SHOW_WITHDRAW, false);
                    we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_20087));
                    return false;
                }

                return true;
            },
            func: () => {
                if (NewbieGuideMgr.IsInHallGuide()) {
                    cc.director.emit(we.common.EventName.UPDATE_GUIDE_STEP);
                }
                return we.currentUI.getDlg(HallViewId.HallDlg)?.onShow(HallPageEnum.withdraw);
            },
        },

        // 新手赠送
        [we.common.JumpCmd.Newbie_Give]: {
            condition: () => {
                return we.common.userMgr.isShowGiveDialog;
            },
            func: () => {
                // 重置新手赠送开关
                we.common.userMgr.isShowGiveDialog = false;
                return we.currentUI.showSafe(HallViewId.NewbieGiveDlg);
            },
        },

        // 手机绑定
        [we.common.JumpCmd.Bind_Phone]: {
            condition: () => {
                const phoneEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Phone);
                const emailEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(we.common.AccountVerifySwitch.Email);
                return (phoneEnabled && we.common.userMgr.userInfo.phone.length === 0) || (emailEnabled && we.common.userMgr.userInfo.emailAccount.length === 0);
            },
            func: () => {
                return we.currentUI.showSafe(we.common.CommonViewId.PhoneBindHighDlg, 0, null, we.common.userMgr.userInfo.phone.length > 0);
            },
        },

        // 新手礼包
        [we.common.JumpCmd.Newbie_Gift_Bag]: {
            condition: () => {
                return we.common.storeMgr.isNewbieGift;
            },
            func: () => {
                return HallMgr.openNewbieGiftBag(true);
            },
        },

        // apk 下载弹窗
        [we.common.JumpCmd.Download_apk]: {
            condition: () => {
                let result = false;
                if (we.common.downloadGuideMgr?.isVestAndroid()) {
                    if (we.core.projectConfig.settingsConfig?.h5HallDownloadTooltipSwitch) {
                        result = true;
                    }
                }
                return result;
            },
            func: () => {
                return we.currentUI.show(HallViewId.ApkDownloadDlg);
            },
        },

        // 加入官方频道
        [we.common.JumpCmd.Join_Us]: {
            condition: (autoPop: boolean) => {
                let result = we.core.projectConfig.settingsConfig?.thirdLinkJoinSwitch;
                if (result) {
                    // 今日不在弹出仅在自动弹出时机时生效
                    if (we.common.activityMgr.todayNoPropJoinUs && autoPop) {
                        result = false;
                    }
                }
                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.JoinUsDlg);
            },
        },

        // VIP
        [we.common.JumpCmd.Vip]: {
            condition: () => {
                return true;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.VipViewDlg);
            },
        },

        // 代理
        [we.common.JumpCmd.Agent]: {
            condition: (autoPop: boolean) => {
                // 仅正式账户可使用
                if (!we.common.userMgr.isFormal()) {
                    // 不是自动弹窗才触发账号绑定弹窗
                    !autoPop && we.currentUI.showSafe(we.common.CommonViewId.PhoneBindHighDlg);
                    return false;
                }
                return true;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.AgentDlg);
            },
        },

        // 返利
        [we.common.JumpCmd.Rebate]: {
            condition: (autoPop: boolean) => {
                if (!we.common.userMgr.isFormal()) {
                    // 不是自动弹窗才触发账号绑定弹窗
                    !autoPop && we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
                    return false;
                }
                return true;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.RebateCodeDlg);
            },
        },

        // 账号绑定
        [we.common.JumpCmd.Account_Bind]: {
            condition: () => {
                return !we.common.userMgr.isFormal();
            },
            func: () => {
                return we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
            },
        },

        // 礼包码
        [we.common.JumpCmd.Gift_Code]: {
            condition: (autoPop: boolean) => {
                let result = true;

                let guestLimit = !we.core.projectConfig.settingsConfig?.funcSwitch?.guestGiftReceive;
                // 开启游客限制时，判定账户类型
                if (guestLimit && !we.common.userMgr.isFormal()) {
                    // 不是自动弹窗才触发账号绑定弹窗
                    !autoPop && we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
                    result = false;
                }
                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.ActivityGiftCodeDlg);
            },
        },

        // 账号截屏
        [we.common.JumpCmd.Screen_Shot]: {
            condition: () => {
                return true;
            },
            func: (...args) => {
                return we.currentUI.showSafe(HallViewId.PhoneBindScreenshotPromptDlg, ...args);
            },
        },

        // 邮件
        [we.common.JumpCmd.Mail]: {
            condition: () => {
                return true;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.MailDlg);
            },
        },

        // 官网包奖励
        [we.common.JumpCmd.Official_Award]: {
            condition: () => {
                // 正式账号且活动开启
                let show = we.common.userMgr.isFormal() && we.common.activityMgr.getOfficialPkgIsAct();
                return show;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.OfficialPkgAwardDlg);
            },
        },

        // 事件中心
        [we.common.JumpCmd.Activity]: {
            condition: (autoPop: boolean) => {
                let result = we.common.activityMgr.activityConf.length > 0;
                // 兼容弹窗队列和主动点击
                if (autoPop) {
                    // 弹窗队列 竖版不弹
                    if (we.core.flavor.isSkinVertical()) {
                        result = false;
                    }
                    // 玩家设置今日不再弹出，也不弹出
                    if (we.common.storage.getDay('common', 'no_prop_activity') === true) {
                        result = false;
                    }
                }

                return result;
            },
            func: () => {
                return HallMgr.openActivity();
            },
        },

        // 独立活动
        [we.common.JumpCmd.Independent]: {
            condition: (autoPop?: boolean) => {
                // 服务器要求充值类活动任务打开界面时需要重新请求数据，防止充值任务数据刷新不及时
                we.common.independentMgr.getActivityInfo();

                let result = we.common.independentMgr.isOpenAct();
                if (!result && !autoPop) {
                    let data = we.common.independentMgr?.actInfo;
                    if (data) {
                        HallMgr.activityStatusTips(data.startTime, data.endTime);
                    }
                }

                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.IndependentDlg);
            },
        },

        // 每日签到
        [we.common.JumpCmd.Daily_Sign]: {
            condition: () => {
                // 竖版皮肤：全部支持
                // 横版皮肤：cm5
                // TODO 注意有竖版不支持或者新增横版支持需要调整该处代码
                let supportSkins = [we.core.SkinCode.cm5];
                let result = we.core.flavor.isSkinVertical() || supportSkins.includes(we.core.flavor.getSkinCode());
                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.ActivityDailyAwardDlg);
            },
        },

        // 狂欢活动
        [we.common.JumpCmd.Carnival]: {
            condition: (autoPop: boolean) => {
                // 服务器要求充值类活动任务打开界面时需要重新请求数据，防止充值任务数据刷新不及时
                we.common.carnivalMgr.getActivityInfo();

                let result = we.common.carnivalMgr.isOpenAct();
                if (!result && !autoPop) {
                    let data = we.common.carnivalMgr.actInfo;
                    if (data) {
                        HallMgr.activityStatusTips(data.startTime, data.endTime);
                    }
                }

                // 弹窗队列时，如果满足已弹出，则今日不在主动弹出，改为玩家触发
                if (autoPop && result) {
                    result = !we.common.activityMgr.todayNoPropCarnival;
                }

                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.CarnivalDlg);
            },
        },

        // 每日累冲
        [we.common.JumpCmd.Daily_Recharge]: {
            condition: (autoPop: boolean) => {
                // 服务器要求充值类活动任务打开界面时需要重新请求数据，防止充值任务数据刷新不及时
                let result = we.common.dailyRechargeMgr.isOpenAct();
                if (!result && !autoPop) {
                    let data = we.common.carnivalMgr.actInfo;
                    if (data) {
                        HallMgr.activityStatusTips(data.startTime, data.endTime);
                    }
                }

                // 弹窗队列时，如果满足已弹出，则今日不在主动弹出，改为玩家触发
                if (autoPop && result) {
                    result = !we.common.activityMgr.todayNoPropDailyRecharge;
                }

                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.DailyRechargeRewardDlg);
            },
        },

        // 转盘
        [we.common.JumpCmd.Turntable]: {
            condition: (autoPop?: boolean) => {
                let result = we.common.turntableMgr.getTurntableIsAct();
                if (!result && !autoPop) {
                    let data = we.common.turntableMgr.turntableData;
                    if (data) {
                        HallMgr.activityStatusTips(data.startTime, data.endTime);
                    }
                }
                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.TurntableDlg);
            },
        },

        // 银行
        [we.common.JumpCmd.Bank]: {
            condition: (autoPop?: boolean) => {
                let result = we.common.bankMgr?.getBankIsAct();
                if (!result && !autoPop) {
                    HallMgr.activityStatusTips();
                }
                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.BankDlg);
            },
        },

        // 周卡
        [we.common.JumpCmd.Week_Card]: {
            condition: () => {
                let result = WeekCardMgr.isOpenAc();
                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.WeekCardDlg);
            },
        },

        // 月签到
        [we.common.JumpCmd.Month_Sign]: {
            condition: (autoPop?: boolean) => {
                let result = MonthSignMgr.month.isActive();
                if (!result && !autoPop) {
                    HallMgr.activityStatusTips();
                }
                return result;
            },
            func: () => {
                return we.currentUI.show(HallViewId.MonthSignDlg);
            },
        },

        // 月签到2
        [we.common.JumpCmd.Month_Sign2]: {
            condition: (autoPop?: boolean) => {
                let result = MonthSignMgr.month2.isActive();
                if (!result && !autoPop) {
                    HallMgr.activityStatusTips();
                }
                return result;
            },
            func: () => {
                // TODO ui 修改
                return we.currentUI.show(HallViewId.MonthSign2Dlg);
            },
        },

        // 救援金
        [we.common.JumpCmd.Rescue_Funds]: {
            condition: (autoPop?: boolean) => {
                let result = we.common.rescueFundsMgr?.getRescueFundsIsAct();
                if (!result && !autoPop) {
                    HallMgr.activityStatusTips();
                }
                return result;
            },
            func: () => {
                return we.currentUI.showSafe(HallViewId.RescueFundsDlg);
            },
        },

        // 新手七日活动
        [we.common.JumpCmd.Seven_Day]: {
            condition: (autoPop?: boolean) => {
                let result = SevenDayMgr.instance.open;
                if (!result && !autoPop) {
                    HallMgr.activityStatusTips();
                }
                return result;
            },
            func: (...args) => {
                return we.currentUI.show(HallViewId.SevenDayDlg, ...args);
            },
        },
    };

    public init() {
        cc.director.off(we.common.EventName.JUMP_ACTION_CMD, this.jumpToModule, this);
        cc.director.on(we.common.EventName.JUMP_ACTION_CMD, this.jumpToModule, this);
    }

    /**
     * 跳转模块
     * @param jumCmd 跳转命令
     * @param args 可变参数[]
     * @returns
     */
    public jumpToModule(jumCmd: string, ...args): Promise<void> {
        if (typeof jumCmd != 'string') {
            we.warn(`JumpModMgr jumpToModule, param error`);
            return;
        }

        // 外部跳转
        if (jumCmd.startsWith('http')) {
            we.core.nativeUtil.openUrl(jumCmd);
            return;
        }

        // 非子游戏跳转
        let strArr = jumCmd.split('.');
        if (isNaN(parseInt(strArr[0]))) {
            let module = this.conf[jumCmd];
            if (typeof module?.func == 'function') {
                let condition = module.condition();
                condition && module.func?.(...args);
            } else {
                we.warn(`JumpModMgr jumpToModule, nonsupport jumpType: ${jumCmd}`);
            }

            return;
        }

        // 子游戏跳转
        let gameId = parseInt(strArr[0]);
        if (we.core.gameConfig.isSubGame(gameId)) {
            // 未开放游戏无法进行正常跳转
            if (!we.core.projectConfig.gameListMap.has(gameId)) {
                we.warn(`JumpModMgr jumpToModule, jump str:${gameId} `);
                return;
            }

            if (!HallMgr.canEnterSubGame(gameId)) {
                return;
            }

            let roomKind = -1;
            if (strArr.length > 1) {
                roomKind = parseInt(strArr[1]);
            }

            EnterGameFlow.Inst.run(gameId);
        }
    }
}

export default new JumpModMgr();
