import { HallEvent } from '../config/HallEvent';
import { HallLanguage } from '../const/HallLanguage';

interface IWeeklyCardConfResp extends ApiProto.WeeklyCardConfResp {
    /** 时间戳 */
    ts: number;
}

/**
 * 月签到管理器
 */
class WeekCardMgr {
    /** 单例 */
    private static _instance: WeekCardMgr | null = null;

    public static Instance(): WeekCardMgr {
        if (!this._instance) {
            this._instance = new WeekCardMgr();
        }
        return this._instance;
    }

    /** 周卡配置 */
    public data: IWeeklyCardConfResp = null;

    public async init() {
        this.data = null;

        cc.director.off(we.common.EventName.WEEK_CARD_BUY_SUCCESS, this.syncData, this);
        cc.director.on(we.common.EventName.WEEK_CARD_BUY_SUCCESS, this.syncData, this);

        // 进打开周卡时，同步红点数据
        let open = we.core.projectConfig.settingsConfig.funcSwitch.weeklyCardActivitySwitch;
        if (open) {
            let redDot = we.core.projectConfig.settingsConfig.userWeeklyCardClaimStatus;
            we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.weekCard, redDot ? 1 : 0);
        }
    }

    /**
     * 同步周卡信息
     * @param forceUpdate 强制刷新
     * @param showLoading
     * @returns
     */
    public async syncData(forceUpdate: boolean = false, showLoading: boolean = false) {
        let offsetTime = Date.now() - (this.data?.ts || 0);
        if (!forceUpdate && offsetTime < 6 * 1000) {
            return;
        }

        await this.getWeekCardConf(showLoading);

        // UI 层刷新
        if (forceUpdate) {
            cc.director.emit(HallEvent.WEEK_CARD_REFRESH_UI);
        }
    }

    /**
     * 获取周卡配置信息
     * @param showLoading
     * @returns
     */
    private getWeekCardConf(showLoading: boolean = false): Promise<IWeeklyCardConfResp> {
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getWeekCardConf(
                (data: ApiProto.WeeklyCardConfResp) => {
                    this.data = data as IWeeklyCardConfResp;
                    this.data.ts = Date.now();

                    // 同步活动开关
                    we.core.projectConfig.settingsConfig.funcSwitch.weeklyCardActivitySwitch = data.activitySwitch;
                    cc.director.emit(HallEvent.WEEK_CARD_SHOW_STATUS, data.activitySwitch);
                    // 提示活动关闭
                    if (!data.activitySwitch) {
                        we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_44));
                    }

                    // 红点
                    let redPot = data.userWeeklyCard[0]?.claimStatus ? 1 : 0;
                    we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.weekCard, redPot);
                    we.core.projectConfig.settingsConfig.userWeeklyCardClaimStatus = !!redPot;

                    resolve(this.data);
                },
                (code) => {
                    this.data = null;
                    reject(code);
                },
                showLoading
            );
        });
    }

    /**
     * 领取周卡每日奖励
     * @param level 周卡档位
     * @param sucCb
     * @param errCb
     */
    public getWeekCardAward(level: number, sucCb?: Function, errCb?: Function) {
        let reqData = {} as ApiProto.UserWeeklyCardClaimReq;
        reqData.level = level;

        we.common.apiMgr.getWeekCardAward(
            reqData,
            (data: ApiProto.UserWeeklyCardClaimResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 是否开启周卡活动
     * @returns
     */
    public isOpenAc(): boolean {
        let open = we.core.projectConfig.settingsConfig.funcSwitch.weeklyCardActivitySwitch;
        return open || this.data?.activitySwitch;
    }
}

export default WeekCardMgr.Instance();
