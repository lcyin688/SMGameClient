import { HallRes } from '../config/HallRes';

export interface IGameEntryConf {
    /** game */
    gameId: we.GameId;
    /** 入口动画上层目录名 */
    animFilesName: string;
    /** 是大图标 */
    isBigIcon: boolean;
    /** 是未开放 */
    isLock: boolean;
    /** 是否有引导标识 */
    isGuide: boolean;
    /** 热门标签 */
    isHot: boolean;
    /** 新游戏标签 */
    isNew: boolean;
    /** 游戏厂商名 */
    vendorName: string;
    /** 游戏厂商图标 */
    vendorIcon: string;
    /** 即将开启标识 */
    comingsoonStart: boolean;
    /** 维护标识 */
    safeguard: boolean;
}

const GroupCustomKey = {
    /** 全部游戏 */
    all: 'all',
    /** 我的收藏 */
    myFavorite: 'myFavorite',
    /** 热门 */
    hot: 'hot',
    /** 百人 */
    hundred: 'hundred',
    /** Slots */
    slots: 'slots',
    /** 牌类 */
    poker: 'poker',
    /** 休闲 */
    casual: 'casual',
    /** 新游戏 */
    new: 'new',
    /** 视讯 */
    live: 'live',
};

/** 开放的GroupKey */
const SupportGroupKey: string[] = [
    GroupCustomKey.all,
    GroupCustomKey.myFavorite,
    GroupCustomKey.hot,
    GroupCustomKey.hundred,
    GroupCustomKey.slots,
    GroupCustomKey.poker,
    GroupCustomKey.casual,
    GroupCustomKey.new,
    GroupCustomKey.live,
];

class HallGameListMgr {
    /** 火爆游戏 */
    private hotGameId: number[] = [];
    /** 新游戏 */
    private newGameId: number[] = [];
    /** 手指引导游戏配置 */
    private guideEntryCof: we.GameId[] = [];

    /** 游戏分组 */
    private groupList: string[] = [];
    /** 大厅游戏分组下标 */
    private _curGroupIndex: number = 0;
    set curGroupIndex(idx: number) {
        this._curGroupIndex = idx;
    }
    get curGroupIndex() {
        return this._curGroupIndex;
    }

    /** 大厅游戏列表 */
    private hallGameMap = new Map<string, we.GameId[][]>();

    /** 搜索游戏列表 */
    private searchGameMap: Map<string, we.GameId[]> = new Map<string, we.GameId[]>();
    /** 搜索游戏列表 */
    private gameNameMap: Map<we.GameId, string> = new Map<we.GameId, string>();
    /** 字符索引 */
    private invertedIndexMap: Map<string, Set<we.GameId>> = new Map<string, Set<we.GameId>>();
    /** 游戏对应厂商配置 */
    private gameVendorConfig: Record<string, string> = {};
    /** 游戏厂商图标配置 */
    private iconVendorConfig: Record<string, string> = {};
    /** 即将开启标识配置 */
    private comingsoonStartArr: number[] = [];
    /** 维护标识配置 */
    private safeguardArr: number[] = [];

    /** 大厅游戏列表 - 最后一次进入子游戏的位置 */
    public lastGameEnterLocation = {
        /** 大厅参数 */
        hallParams: {
            scrollOffset: null as cc.Vec2,
            groupIndex: 0,
        },
        /** 搜索页参数 */
        searchParams: {
            scrollOffset: null as cc.Vec2,
            groupIndex: 0,
            vendorIndex: -1,
            searchValue: '',
        },
    };

    public init(): void {
        this.curGroupIndex = 0;

        if (we.core.projectConfig.settingsConfig && we.core.projectConfig.settingsConfig.funcSwitch) {
            this.hotGameId = we.core.projectConfig.settingsConfig.funcSwitch.redHot || [];
            this.newGameId = we.core.projectConfig.settingsConfig.funcSwitch.newHot || [];
            this.guideEntryCof = we.core.projectConfig.settingsConfig.funcSwitch.finger || [];
            this.gameVendorConfig = we.core.projectConfig.settingsConfig.funcSwitch.gameVendor || {};
            this.iconVendorConfig = we.core.projectConfig.settingsConfig.funcSwitch.vendorIcon || {};
            this.comingsoonStartArr = we.core.projectConfig.settingsConfig.funcSwitch.comingSoonStart || [];
            this.safeguardArr = we.core.projectConfig.settingsConfig.funcSwitch.safeguard || [];
            let sortGroupList = we.core.projectConfig.settingsConfig.funcSwitch.layoutSort || [];
            this.groupList = this.getSupportGroup(sortGroupList);
        }

        this.initHallGameData();
    }

    private initHallGameData(): void {
        this.hallGameMap.clear();

        if (we.core.projectConfig.settingsConfig && we.core.projectConfig.settingsConfig.funcSwitch.layout) {
            const isGroupList = this.groupList.length > 0;
            const config = JSON.parse(we.core.projectConfig.settingsConfig.funcSwitch.layout);
            for (const key in config) {
                if (!isGroupList && SupportGroupKey.includes(key)) {
                    this.groupList.push(key);
                }
                let gameIds: we.GameId[][] = config[key];
                if (gameIds instanceof Array) {
                    gameIds = gameIds.map((row) => {
                        return row.map((gameId) => {
                            if (we.npm.lodash.isNaN(+gameId)) {
                                we.warn(`HallGameListMgr initHallGameData, gameId:${gameId} is not a number, please check!`);
                            }
                            return +gameId;
                        });
                    });
                    this.hallGameMap.set(key, gameIds);
                }
            }
        }

        this.initMyFavoriteGroup();
        this.initSearchGameData();
    }

    public getHallGameList(groupKey: string): we.GameId[][] {
        return [...(this.hallGameMap.get(groupKey) || [])];
    }

    public getHallGroupList(): string[] {
        let hallGroupList = [];
        for (let i = 0; i < this.groupList.length; i++) {
            if (this.hallGameMap.has(this.groupList[i]) && this.hallGameMap.get(this.groupList[i]).length > 0) {
                hallGroupList.push(this.groupList[i]);
            }
        }

        if (SupportGroupKey.includes(GroupCustomKey.myFavorite) && this.hallGameMap.has(GroupCustomKey.myFavorite)) {
            if (this.hallGameMap.get(GroupCustomKey.myFavorite).length > 0) {
                hallGroupList.push(GroupCustomKey.myFavorite);
            }
        }

        return hallGroupList;
    }

    public getSearchGameList(groupKey: string): we.GameId[] {
        return [...(this.searchGameMap.get(groupKey) || [])];
    }

    public getSearchGroupList(): string[] {
        let searchGroupList = [];
        for (let i = 0; i < this.groupList.length; i++) {
            if (this.groupList[i] == GroupCustomKey.hot) {
                continue;
            }
            if (this.searchGameMap.has(this.groupList[i]) && this.searchGameMap.get(this.groupList[i]).length > 0) {
                searchGroupList.push(this.groupList[i]);
            }
        }

        if (SupportGroupKey.includes(GroupCustomKey.all) && this.searchGameMap.has(GroupCustomKey.all)) {
            if (this.searchGameMap.get(GroupCustomKey.all).length > 0) {
                searchGroupList.unshift(GroupCustomKey.all);
            }
        }

        return searchGroupList;
    }

    /**
     * 获取游戏入口配置
     * @param gameIdStr
     * @param isBigIcon 是否为大图标
     * @param isSearch 是否为搜索界面图标
     * @returns
     */
    public getGameEntryConfig(gameId: we.GameId, isBigIcon: boolean, isSearch: boolean = false): IGameEntryConf {
        const gameCfg = {} as IGameEntryConf;
        gameCfg.gameId = gameId;
        gameCfg.animFilesName = gameId.toString();
        gameCfg.isBigIcon = !isSearch && isBigIcon;
        gameCfg.isGuide = !isSearch && this.guideEntryCof.includes(gameId);
        gameCfg.isHot = !isSearch && this.hotGameId.includes(gameId);
        gameCfg.isNew = !isSearch && this.newGameId.includes(gameId);
        gameCfg.comingsoonStart = this.comingsoonStartArr.includes(gameId);
        gameCfg.safeguard = this.safeguardArr.includes(gameId);

        gameCfg.vendorName = this.gameVendorConfig[gameId] || '';
        gameCfg.vendorIcon = '';
        // 厂商 icon 下载地址健全
        let iconPath = this.iconVendorConfig[gameCfg.vendorName];
        if (iconPath) {
            gameCfg.vendorIcon = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, iconPath);
        }

        return gameCfg;
    }

    /**
     * 初始化 myFavorite 页签的 gameList
     */
    private initMyFavoriteGroup(): void {
        // 获取游戏次数与最近时间的本地缓存，没有则删除该页签
        let localGameTimes: we.common.IGameTimesInfo[] = we.common.storage.get('common', 'game_play_times') || [];

        if (localGameTimes.length < 1) {
            return;
        }

        // 获取已开放的游戏
        let tempLocalGameTimes: we.common.IGameTimesInfo[] = [];
        let visibleGames = this.getGroupGame();
        for (let i = 0; i < localGameTimes.length; i++) {
            if (visibleGames.includes(localGameTimes[i].gameId)) {
                tempLocalGameTimes.push(localGameTimes[i]);
            }
        }

        let gameList: we.GameId[][] = [];
        // 按时间排序，从大到小
        tempLocalGameTimes.sort((a, b) => {
            return b.lastTime - a.lastTime;
        });
        let latestTimeArr: we.common.IGameTimesInfo[] = tempLocalGameTimes.splice(0, 2);
        for (let i = 0; i < latestTimeArr.length; i++) {
            gameList.push([latestTimeArr[i].gameId]);
        }

        if (tempLocalGameTimes.length == 0) {
            this.hallGameMap.set(GroupCustomKey.myFavorite, gameList);
            return;
        }

        // 按次数排序，从大到小
        tempLocalGameTimes.sort((a, b) => {
            return b.times - a.times;
        });
        let timesArr: we.common.IGameTimesInfo[] = tempLocalGameTimes.splice(0, 8);
        for (let i = 0; i < timesArr.length; i++) {
            if (i % 2 == 1) {
                continue;
            }
            let curGameId = timesArr[i].gameId;
            // TODO api nextGameId 为0 时， 业务是否正常
            let nextGameId = i + 1 < timesArr.length ? timesArr[i + 1].gameId : 0;
            gameList.push([curGameId, nextGameId]);
        }
        this.hallGameMap.set(GroupCustomKey.myFavorite, gameList);
    }

    /**
     * 初始化 gameListMap
     * key -> 游戏分类
     * value -> gameId 数组
     */
    private initSearchGameData(): void {
        this.searchGameMap.clear();

        let searchGroupList = [...this.groupList];
        searchGroupList.unshift(GroupCustomKey.all);
        for (let i = 0; i < searchGroupList.length; i++) {
            if (this.searchGameMap.has(searchGroupList[i])) {
                continue;
            }

            let curGameList = this.getGroupGame(searchGroupList[i]);
            curGameList = curGameList.sort((a, b) => {
                return a.toString().localeCompare(b.toString());
            });
            this.searchGameMap.set(searchGroupList[i], curGameList);
        }

        this.initGameNameData();
    }

    /**
     * 初始化gameNameMap
     * key -> gameId
     * value -> 游戏名
     */
    private initGameNameData(): void {
        this.gameNameMap.clear();

        let allGameList = this.searchGameMap.get(GroupCustomKey.all) || [];
        for (let i = 0; i < allGameList.length; i++) {
            let str = we.common.gameMgr.getGameEntryName(allGameList[i]);
            str = this.formatStr(str);
            this.gameNameMap.set(allGameList[i], str);
        }

        this.initInvertedIndex();
    }

    /**
     * 初始化字符索引
     * key -> 字符
     * value -> gameId Set
     */
    private initInvertedIndex(): void {
        this.invertedIndexMap.clear();

        this.gameNameMap.forEach((name, id) => {
            for (const char of name) {
                if (!this.invertedIndexMap.has(char)) {
                    this.invertedIndexMap.set(char, new Set());
                }
                this.invertedIndexMap.get(char)?.add(id);
            }
        });
    }

    public searchGamesByInvertedIndex(search: string, groupKey: string): we.GameId[] {
        const queryChars = search.split('');
        let potentialMatches: Set<we.GameId> | undefined;

        // 初步筛选，是否包含每个字符，顺序可以不一样，可以重复
        for (const char of queryChars) {
            if (this.invertedIndexMap.has(char)) {
                const ids = this.invertedIndexMap.get(char);
                if (!potentialMatches) {
                    potentialMatches = new Set(ids);
                } else {
                    const newPotentialMatches = new Set<we.GameId>();
                    potentialMatches.forEach((id) => {
                        if (ids?.has(id)) {
                            newPotentialMatches.add(id);
                        }
                    });
                    potentialMatches = newPotentialMatches;
                }
            } else {
                return [];
            }
        }

        // 当前分组下的gameid筛选
        const groupGameMatches: we.GameId[] = [];
        potentialMatches.forEach((id) => {
            let curGameList = this.getSearchGameList(groupKey);
            if (curGameList.includes(id)) {
                groupGameMatches.push(id);
            }
        });

        // 精确筛选，按顺序
        const results: we.GameId[] = [];

        groupGameMatches.forEach((id) => {
            const name = this.gameNameMap.get(id);
            if (name) {
                if (this.fuzzyMatch(search, name)) {
                    results.push(id);
                }
            }
        });

        return results;
    }

    /**
     * 模糊匹配
     * @param search 搜索字符串
     * @param name 游戏名字
     * @returns
     */
    private fuzzyMatch(search: string, name: string): boolean {
        let si = 0;
        let ni = 0;

        while (si < search.length && ni < name.length) {
            if (search[si] === name[ni]) {
                si++;
            }
            ni++;
        }

        return si === search.length;
    }

    /**
     * 格式化游戏名，用于搜索功能
     * @param str
     * @returns
     */
    public formatStr(str: string): string {
        if (typeof str != 'string') {
            return '';
        }

        str = str.replace(/\s+/g, ''); // 去除空格
        str = str.toLowerCase(); // 小写

        return str;
    }

    /**
     * 获取对应分组下的游戏列表，默认全部 groupKey = 'all'
     * @param groupKey
     * @returns
     */
    private getGroupGame(groupKey: string = GroupCustomKey.all): we.GameId[] {
        if (groupKey == GroupCustomKey.all) {
            return we.core.projectConfig.getVisibleGame();
        }

        const groupGames = this.hallGameMap.get(groupKey);
        if (!groupGames || groupGames.length == 0) {
            return [];
        }

        const gameSet = new Set<we.GameId>();
        groupGames
            .flatMap((row) => {
                return row;
            })
            .forEach((gameId) => {
                if (gameId > 0) {
                    return gameSet.add(gameId);
                }
            });

        return Array.from(gameSet);
    }

    /**
     * 获取支持的游戏分组
     * @param groupList
     * @returns
     */
    private getSupportGroup(groupList: string[]): string[] {
        let supportGroup: string[] = [];

        for (let i = 0; i < groupList.length; i++) {
            if (SupportGroupKey.includes(groupList[i])) {
                supportGroup.push(groupList[i]);
            }
        }

        return supportGroup;
    }

    /**
     * 获取厂商游戏列表
     * @param name
     */
    public getVendorGameList() {
        const group = new Map<string, { icon: string; name: string; gameList: number[] }>();
        for (let gameVendor in this.iconVendorConfig) {
            group.set(gameVendor, {
                icon: we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, this.iconVendorConfig[gameVendor]),
                name: gameVendor,
                gameList: [],
            });
        }

        for (let gameId in this.gameVendorConfig) {
            const gameVendor = this.gameVendorConfig[gameId];
            group.get(gameVendor)?.gameList.push(Number(gameId));
        }

        return Array.from(group, ([key, value]) => {
            return value;
        });
    }
}
export default new HallGameListMgr();
