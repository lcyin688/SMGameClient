import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class WithdrawAccountItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_account: cc.Label = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_range: cc.RichText = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_change: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_quota: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rangSelectBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rangUnSelectBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_selected: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_unSelected: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property({ tooltip: CC_DEV && '已使用提现通道额度颜色配置' })
    private quotaHex: string = '#FFFFFF';

    private data: ApiProto.WithdrawAccountInfo = null;

    /**
     * 获取当前 item 显示账号信息
     */
    public get accountInfo() {
        return this.data;
    }

    /**
     * 获取账号选择状态
     */
    public get selectStatus() {
        return this.RCN_selected.active;
    }

    protected onLoad(): void {
        this.RCN_quota.active = false;
        this.setSelectStatus(false);

        this.onBtnClick(this.RCN_change, we.core.Func.create(this.onClickChange, this));
        this.onBtnClick(this.node, we.core.Func.create(this.onClickSelf, this));

        cc.director.on(HallEvent.WITHDRAW_ACCOUNT_SELECT, this.onUpdateSelectSt, this);
    }

    protected onDestroy(): void {
        cc.director.off(HallEvent.WITHDRAW_ACCOUNT_SELECT, this.onUpdateSelectSt, this);
    }

    /**
     * 初始化提现绑定账号 Item
     * @param data 提现渠道
     * @param isSelect 是否选中
     */
    public init(data: ApiProto.WithdrawAccountInfo, isSelect: boolean): void {
        this.data = data;
        let bindInfo = data.info;
        if (!bindInfo) {
            return;
        }

        this.setSelectStatus(isSelect);

        // 提现渠道 icon
        let path = HallRes.texture.channelCode + bindInfo.channelCode;
        we.common.utils.setComponentSprite(this.RC_spr_icon, path);

        // 格式化 账号显示
        let info = we.common.withdrawMgr.getChannelInfoByCode(bindInfo.channelCode);
        if (info && bindInfo.account) {
            let account = '';
            if (we.core.flavor.getCountryCode() == we.core.CountryCode.br) {
                account = (info.code == we.common.payMgr.PAY_TYPE.PHONE_BRL ? `+${we.core.flavor.getCountryNum()}` : '') + bindInfo.account;
            } else if (we.core.flavor.getCountryCode() == we.core.CountryCode.in) {
                account = bindInfo.account;
            } else {
                let isDigitalPay = we.common.payMgr.isDigitalPay(info.code);
                account = (info.isBank || isDigitalPay ? '' : `+${we.core.flavor.getCountryNum()} `) + bindInfo.account;
            }
            this.RC_lab_account.string = account;

            // 提现通道限额设置
            let quotaAmount = data.channelLimitAmount || 0;
            this.RCN_quota.active = quotaAmount > 0;
            this.RCN_rangSelectBg.active = quotaAmount > 0;
            this.RCN_rangUnSelectBg.active = quotaAmount > 0;

            let str = `<color=${this.quotaHex}>${we.common.utils.formatPrice(data.channelUseAmount || 0, false)}</c> / ${we.common.utils.formatPrice(quotaAmount, false)}`;
            this.RC_rich_range.string = str;
        }
    }

    public setSelectStatus(select: boolean) {
        this.RCN_selected.active = select;
        this.RCN_unSelected.active = !select;
    }

    private onUpdateSelectSt(data: ApiProto.WithdrawAccountInfo): void {
        if (cc.isValid(this.node) && data) {
            let select = this.data?.info.account == data.info?.account && this.data.info.channelType == data.info.channelType;
            this.setSelectStatus(select);
        }
    }

    private onClickChange(): void {
        HallMgr.openWithdrawAccountInfoDlg(this.data?.info);
    }

    private onClickSelf(): void {
        if (this.RCN_selected.active) {
            return;
        }

        cc.director.emit(HallEvent.WITHDRAW_ACCOUNT_SELECT, this.data);
    }
}
