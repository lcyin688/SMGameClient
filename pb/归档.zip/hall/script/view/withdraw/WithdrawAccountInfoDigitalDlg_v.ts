import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoDigitalDlgView_v', we.bundles.hall)
class WithdrawAccountInfoDigitalDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_account: cc.EditBox = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_accountInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirmGray: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoDigitalDlg_v', we.bundles.hall)
export class WithdrawAccountInfoDigitalDlg_v extends we.ui.DlgSystem<WithdrawAccountInfoDigitalDlgView_v> {
    private inputContent: string = '';
    private isAddAccount: boolean = true;

    private bankInfo: ApiProto.UserBankInfo = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_edit_account.string = '';

        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidBegan', we.core.Func.create(this.onCardNumberEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidEnded', we.core.Func.create(this.onCardNumberEditBoxEditEnded, this));

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.onClickConfirm, this));
    }

    /** 显示窗口 */
    public async onShow(data: ApiProto.UserBankInfo, isAdd: boolean) {
        this.bankInfo = data;
        if (!data) {
            return;
        }
        this.isAddAccount = isAdd;
        this.inputContent = data.account ?? '';

        // 根据不同支付类型设置账号有效长度
        let channelType = data.channelType;
        if (channelType == we.common.payMgr.PAY_TYPE.MT_PAY) {
            // MT_PAY 账号长度 12
            this.view.RC_edit_account.maxLength = 12;
        }

        this.view.RCN_accountInfo.active = true;
        this.view.RC_edit_account.placeholder = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__RECORD_NUM);

        if (data.account) {
            this.view.RC_edit_account.string = data.account;
        }

        // 提现渠道 icon
        let path = HallRes.texture.channelCode + data.channelCode;
        we.common.utils.setComponentSprite(this.view.RC_spr_icon, path);

        this.setConfirmBtn();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onCardNumberEditBoxEditStarted() {
        let editBox = this.view.RC_edit_account;
        editBox.placeholderLabel.string = '';
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = this.inputContent;
        }
        this.view.RC_edit_account.string = this.inputContent;
    }

    private onCardNumberEditBoxEditEnded() {
        let editBox = this.view.RC_edit_account;

        let str: string = editBox.string.replace(/\s*/g, '');
        if (str == 'undefined') {
            str = '';
        }
        this.view.RC_edit_account.string = str;

        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = str;
        }
        this.inputContent = str;

        if (str.length <= 0) {
            this.view.RC_edit_account.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__RECORD_NUM);
        } else {
            // 判定输入是否合法
            if (!we.common.withdrawMgr.checkAccountFormat(this.bankInfo.channelType, str)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
                return;
            }
        }

        this.setConfirmBtn();
    }

    private onClickConfirm(): void {
        let bankStr = this.view.RC_edit_account.string.replace(/\s*/g, '');
        // 判定输入是否合法
        if (!we.common.withdrawMgr.checkAccountFormat(this.bankInfo.channelType, bankStr)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
            return;
        }
        // 判定是否有修改
        if (this.bankInfo.account === bankStr) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_MODIFY_TEXT));
            return;
        }

        this.changeBindInfo();
    }

    private changeBindInfo(): void {
        let param = {} as ApiProto.UserBankWithdrawUpdateReq;
        param.operationType = this.isAddAccount ? 0 : 1;
        param.originalAccount = this.bankInfo?.account || '';
        let bindInfo = {} as ApiProto.UserBankInfo;
        bindInfo.account = this.inputContent.replace(/\s*/g, '');
        bindInfo.channelType = this.bankInfo.channelType;
        bindInfo.channelCode = this.bankInfo.channelCode;
        param.info = bindInfo;
        param.bindCardVerificationToken = we.common.withdrawMgr.bindCardToken;

        we.common.withdrawMgr.modifyWithdrawBindInfo(
            param,
            (data: ApiProto.UserBankWithdrawUpdateResp) => {
                if (!we.common.userMgr.isLogin()) {
                    return;
                }

                if (data.suc) {
                    // 无可使用账号绑定成功时，需要更新提现主界面 绑定账号展示
                    let isUpdateMainUI = we.common.withdrawMgr.accountList.length < 1;
                    // 更新临时缓存账号信息
                    we.common.withdrawMgr.updateAccountInfo(bindInfo, this.isAddAccount ? null : this.bankInfo);

                    if (isUpdateMainUI) {
                        cc.director.emit(HallEvent.WITHDRAW_UPDATE_BANK_INFO, bindInfo, true);
                    }
                    cc.director.emit(HallEvent.WITHDRAW_UPDATE_ACCOUNT_LIST, bindInfo, this.isAddAccount);
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_TIPS_MODIFY_SUCCESS));

                    if (cc.isValid(this.view.uiRoot)) {
                        this.closeView();
                    }
                }
            },
            (code: number) => {
                if ([we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1029, we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1030].includes(code)) {
                    we.currentUI.show(HallViewId.VerifyLoginPasswordDlg);
                }
            }
        );
    }

    private setConfirmBtn(): void {
        let str = this.view.RC_edit_account.string.replace(/\s*/g, '');
        let legit = we.common.withdrawMgr.checkAccountFormat(this.bankInfo.channelType, str);

        this.view.RCN_confirm.active = legit;
        this.view.RCN_confirmGray.active = !legit;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawAccountInfoDigitalDlg_v, `${HallViewId.WithdrawAccountInfoDigitalDlg}_v`)
class WithdrawAccountInfoDigitalDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawAccountInfoDigitalDlg_v, uiBase.addComponent(WithdrawAccountInfoDigitalDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoDigitalDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawAccountInfoDigitalDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoDigitalDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoDigitalDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawAccountInfoDigitalDlg_v).beforeUnload();
    }
}
