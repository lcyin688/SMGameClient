import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoDlgView_h', we.bundles.hall)
class WithdrawAccountInfoDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_account: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_phone: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phoneArea: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_accountInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirmGray: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phoneInfo: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawAccountInfoDlg_h', we.bundles.hall)
export class WithdrawAccountInfoDlg_h extends we.ui.DlgSystem<WithdrawAccountInfoDlgView_h> {
    private inputContent: string = '';
    private oldAccount: string = '';

    private isBank: boolean = false;
    private isAddAccount: boolean = true;

    private bankInfo: ApiProto.UserBankInfo = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_edit_account.string = '';
        this.view.RC_edit_phone.string = '';

        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidBegan', we.core.Func.create(this.onCardNumberEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'textChanged', we.core.Func.create(this.onCardNumberEditBoxEditChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidEnded', we.core.Func.create(this.onCardNumberEditBoxEditEnded, this));

        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidBegan', we.core.Func.create(this.onPhoneEditBoxEditStarted, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidEnded', we.core.Func.create(this.onPhoneEditBoxEditEnded, this));

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.onClickConfirm, this)).setSleepTime(1.5);
    }

    /** 显示窗口 */
    public async onShow(data: ApiProto.UserBankInfo, isAdd: boolean) {
        this.bankInfo = data;
        if (!data) {
            return;
        }
        this.isAddAccount = isAdd;

        let conf = we.common.withdrawMgr.getChannelInfoByCode(data.channelCode);
        if (conf) {
            this.isBank = conf.isBank;
        }

        this.view.RCN_phoneInfo.active = !this.isBank;
        this.view.RCN_accountInfo.active = this.isBank;
        this.view.RC_edit_phone.placeholder = we.core.langMgr.getLangText(we.common.lang.LOGIN_FORGETFRAME_ENTER1_TIPS);
        this.view.RC_edit_account.placeholder = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_INPUT2);
        this.view.RC_lab_phoneArea.string = `+${we.core.flavor.getCountryNum()}`;

        if (data.account) {
            if (!this.isBank) {
                this.view.RC_edit_phone.string = data.account;
            } else {
                this.view.RC_edit_account.string = we.common.withdrawMgr.formatBankAccount(data.account);
            }

            this.inputContent = this.isBank ? we.common.withdrawMgr.formatBankAccount(data.account) : data.account;
        }

        // 提现渠道 icon
        let path = HallRes.texture.channelCode + data.channelCode;
        we.common.utils.setComponentSprite(this.view.RC_spr_icon, path);

        this.setConfirmBtn();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onCardNumberEditBoxEditStarted() {
        let editBox = this.view.RC_edit_account;
        editBox.placeholderLabel.string = '';
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = this.inputContent;
        }
        this.view.RC_edit_account.string = this.inputContent;
    }

    private onCardNumberEditBoxEditChanged(event) {
        if (cc.sys.isNative) {
            return;
        }

        let editBox = this.view.RC_edit_account;
        let str: string = '';
        if (event.length != 0 && event.length % 5 == 0 && event[event.length - 1] != ' ') {
            str = event.slice(0, event.length - 1) + ' ' + event.slice(event.length - 1);
            // @ts-ignore
            if (editBox && editBox._impl && editBox._impl._elem) {
                // @ts-ignore
                editBox._impl._elem.value = str;
            }
            this.view.RC_edit_account.string = str;
            this.oldAccount = str;
        }
        if (this.oldAccount.length > event.length && event[event.length - 1] == ' ') {
            str = event.slice(0, event.length - 1);
            this.view.RC_edit_account.string = str;
            this.oldAccount = str;
            // @ts-ignore
            if (editBox && editBox._impl && editBox._impl._elem) {
                // @ts-ignore
                editBox._impl._elem.value = str;
            }
        }
    }

    private onCardNumberEditBoxEditEnded() {
        let str: string = this.view.RC_edit_account.string || '';
        str = we.common.withdrawMgr.formatBankAccount(str);
        this.view.RC_edit_account.string = str;

        let editBox = this.view.RC_edit_account;
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = str;
        }
        this.inputContent = str;

        if (str.length <= 0) {
            this.view.RC_edit_account.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_INPUT2);
        } else {
            let bankStr = str.replace(/\s*/g, '');
            if (!this.isCard(bankStr)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
            }
        }

        this.setConfirmBtn();
    }

    private onPhoneEditBoxEditStarted() {
        let editBox = this.view.RC_edit_phone;
        editBox.placeholderLabel.string = '';
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = this.inputContent;
        }
        this.view.RC_edit_phone.string = this.inputContent;
    }

    private onPhoneEditBoxEditEnded() {
        let str: string = this.view.RC_edit_phone.string;
        if (str.length <= 0) {
            this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(we.common.lang.LOGIN_FORGETFRAME_ENTER1_TIPS);
        }

        this.inputContent = str;

        if (!we.common.utils.isPhoneNumber(str)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
        }

        this.setConfirmBtn();
    }

    private onClickConfirm(): void {
        let bankStr = '';
        if (this.isBank) {
            bankStr = this.view.RC_edit_account.string.replace(/\s*/g, '');
        } else {
            bankStr = this.view.RC_edit_phone.string.replace(/\s*/g, '');
        }

        // 判定输入是否合法
        if (!this.judgeLegit(bankStr)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CASH_OUT_TIPS7));
            return;
        }
        // 判定是否有修改
        if (this.bankInfo.account == bankStr) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_MODIFY_TEXT));
            return;
        }

        this.changeBindInfo();
    }

    private changeBindInfo(): void {
        let param = {} as ApiProto.UserBankWithdrawUpdateReq;
        param.operationType = this.isAddAccount ? 0 : 1;
        param.originalAccount = this.bankInfo?.account || '';
        let bindInfo = {} as ApiProto.UserBankInfo;
        bindInfo.account = this.inputContent.replace(/\s*/g, '');
        bindInfo.channelType = this.bankInfo.channelType;
        bindInfo.channelCode = this.bankInfo.channelCode;
        param.info = bindInfo;
        param.bindCardVerificationToken = we.common.withdrawMgr.bindCardToken;

        we.common.withdrawMgr.modifyWithdrawBindInfo(
            param,
            (data: ApiProto.UserBankWithdrawUpdateResp) => {
                if (!we.common.userMgr.isLogin()) {
                    return;
                }

                if (data.suc) {
                    // 无可使用账号绑定成功时，需要更新提现主界面 绑定账号展示
                    let isUpdateMainUI = we.common.withdrawMgr.accountList.length < 1;
                    // 更新临时缓存账号信息
                    we.common.withdrawMgr.updateAccountInfo(bindInfo, this.isAddAccount ? null : this.bankInfo);

                    if (isUpdateMainUI) {
                        cc.director.emit(HallEvent.WITHDRAW_UPDATE_BANK_INFO, bindInfo, true);
                    }
                    cc.director.emit(HallEvent.WITHDRAW_UPDATE_ACCOUNT_LIST, bindInfo, this.isAddAccount);
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_TIPS_MODIFY_SUCCESS));

                    if (cc.isValid(this.view.uiRoot)) {
                        this.closeView();
                    }
                }
            },
            (code: number) => {
                if ([we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1029, we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1030].includes(code)) {
                    we.currentUI.show(HallViewId.VerifyLoginPasswordDlg);
                }
            }
        );
    }

    private setConfirmBtn(): void {
        let str = '';
        if (this.isBank) {
            str = this.view.RC_edit_account.string.replace(/\s*/g, '');
        } else {
            str = this.view.RC_edit_phone.string.replace(/\s*/g, '');
        }
        let legit = this.judgeLegit(str);

        this.view.RCN_confirm.active = legit;
        this.view.RCN_confirmGray.active = !legit;
    }

    private judgeLegit(str: string): boolean {
        let legit = false;
        if (this.isBank) {
            legit = this.isCard(str);
        } else {
            legit = we.common.utils.isPhoneNumber(str);
        }

        return legit;
    }

    private isCard(str: string): boolean {
        if (/^[0-9]{3,30}$/.test(str)) {
            return true;
        } else {
            return false;
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawAccountInfoDlg_h, `${HallViewId.WithdrawAccountInfoDlg}_h`)
class WithdrawAccountInfoDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawAccountInfoDlg_h, uiBase.addComponent(WithdrawAccountInfoDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawAccountInfoDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountInfoDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawAccountInfoDlg_h).beforeUnload();
    }
}
