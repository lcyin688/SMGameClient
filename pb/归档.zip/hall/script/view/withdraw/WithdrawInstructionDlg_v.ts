import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawInstructionDlgView_v', we.bundles.hall)
class WithdrawInstructionDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_richTip: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.ScrollView)
    public RC_scrollView: cc.ScrollView = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawInstructionDlg_v', we.bundles.hall)
export class WithdrawInstructionDlg_v extends we.ui.DlgSystem<WithdrawInstructionDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.init();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private init(): void {
        let conf = we.common.withdrawMgr.config;
        if (conf) {
            let minAmount = we.common.utils.formatAmountCurrency(conf.withdrawLower);
            let percent = parseFloat((conf.rate / 100).toFixed(2));
            let minRemain = we.common.utils.formatAmountCurrency(conf.remain);
            let minPoundage = we.common.utils.formatAmountCurrency(conf.minFee);
            let minFeeCondition = we.common.utils.formatAmountCurrency(conf.minFeeCondition);

            let count = 1;
            // 最小数量
            if (minAmount) {
                this.view.RC_richTip.setStringFormat(we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS1), minAmount);
                this.view.RC_richTip.string = `${count}.${this.view.RC_richTip.string}`;
                count += 1;
            } else {
                this.view.RC_richTip.node.active = false;
            }
            // 手续费
            if (percent) {
                let richTextTags = this.addRuleRichText();
                let innerTag = this.view.RC_richTip.innerTags[0];
                // 三个参数所以需要修改 内置 tag 配置
                richTextTags.innerTags = [innerTag, innerTag, innerTag];
                richTextTags.setStringFormat(we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS2), percent + '%', minFeeCondition, minPoundage);
                richTextTags.string = `${count}.${richTextTags.string}`;
                count += 1;
            }
            // 保留金
            if (minRemain && parseInt(minRemain) > 0) {
                let richTextTags = this.addRuleRichText();
                richTextTags.setStringFormat(we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS3), minRemain);
                richTextTags.string = `${count}.${richTextTags.string}`;
                count += 1;
            }
            // 免手续费费
            if (conf.freeFeeSwitch) {
                let richTextTags = this.addRuleRichText();
                richTextTags.setStringFormat(we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS6), we.common.utils.formatAmountCurrency(conf.freeFeeAmount));
                richTextTags.string = `${count}.${richTextTags.string}`;
                count += 1;
            }

            // 银行限额提示
            const richTextQuota = this.addRuleRichText();
            richTextQuota.string = `${count}.${we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__DES_TIPS10)}`;
            count += 1;
        }
    }

    private addRuleRichText(): we.ui.WERichTags {
        let richText = cc.instantiate(this.view.RC_richTip.node);
        this.view.RC_scrollView.content.addChild(richText);
        richText.active = true;
        let richTextTags = richText.getComponent(we.ui.WERichTags);

        return richTextTags;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawInstructionDlg_v, `${HallViewId.WithdrawInstructionDlg}_v`)
class WithdrawInstructionDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawInstructionDlg_v, uiBase.addComponent(WithdrawInstructionDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawInstructionDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawInstructionDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawInstructionDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawInstructionDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawInstructionDlg_v).beforeUnload();
    }
}
