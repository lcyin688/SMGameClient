import { HallLanguage } from '../../const/HallLanguage';

interface BroadcastInfo {
    userId: number;
    userName: string;
    money: number;
    currency: string;
    finishTime: number;
    costTime: number;
}

const { ccclass, property } = cc._decorator;

@ccclass
export default class WithdrawBroadcast_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.RichText)
    public RC_rich_content: cc.RichText = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_root: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property({ tooltip: CC_DEV && '提现数量颜色' })
    private amountHex: string = '#ffffff';

    @property({ tooltip: CC_DEV && '提现时间颜色' })
    private timeHex: string = '#ffffff';

    private speed: number = 2;
    private broadcasting: boolean = false;
    private broadcastData: BroadcastInfo[] = [];
    private curBroadcastData: BroadcastInfo = null;

    protected onEnable() {
        this.RCN_root.active = false;
        this.RC_rich_content.node.setPosition(cc.v2(this.RCN_mask.width, 0));

        this.flushBroad();

        cc.director.on(we.common.EventName.WITHDRAW_BROAD, this.onUpdateBroad, this);
        we.event<we.core.EventMsg>().on('LangChanged', this.updataLabel, this);
    }

    protected update() {
        this.scrollAnim();
    }

    protected onDisable() {
        we.event<we.core.EventMsg>().off('LangChanged', this.updataLabel, this);
        cc.director.off(we.common.EventName.WITHDRAW_BROAD, this.onUpdateBroad, this);
    }

    private onUpdateBroad() {
        this.flushBroad();
    }

    private flushBroad() {
        this.broadcastData = JSON.parse(JSON.stringify(we.common.withdrawMgr.broadArray));
        this.broadcastData.sort((a: ApiProto.BankWithdrawBroadItem, b: ApiProto.BankWithdrawBroadItem) => {
            return b.finishTime - a.finishTime;
        });

        // 未播报的时候开始播报
        if (!this.broadcasting) {
            this.RCN_root.active = this.broadcastData.length > 0;

            let data = this.broadcastData.shift();
            if (data) {
                this.curBroadcastData = data;
                this.updataLabel();
                this.RC_rich_content.node.setPosition(cc.v2(this.RCN_mask.width, 0));
                this.broadcasting = true;
            }
        }
    }

    private updataLabel() {
        if (this.curBroadcastData) {
            let text = this.formatString(this.curBroadcastData);
            this.RC_rich_content.string = text;
        }
    }

    private scrollAnim() {
        if (this.broadcasting) {
            if (this.RC_rich_content.node.x < -this.RC_rich_content.node.width) {
                this.broadcasting = false;
                this.RCN_root.active = this.broadcastData.length > 0;

                let data = this.broadcastData.shift();
                if (data) {
                    this.curBroadcastData = data;
                    this.updataLabel();
                    this.RC_rich_content.node.setPosition(cc.v2(this.RCN_mask.width, 0));
                    this.broadcasting = true;
                }
            } else {
                this.RC_rich_content.node.x -= this.speed;
            }
        }
    }

    private formatString(info: BroadcastInfo): string {
        if (!info) {
            info = {
                userId: -1,
                userName: '',
                money: 0,
                currency: we.core.projectConfig.settingsConfig?.primaryCurrency,
                finishTime: 0,
                costTime: 0,
            };
        }
        if (!info.userName) {
            info.userName = '';
        }
        if (!info.money) {
            info.money = 0;
        }

        let formatDate = we.common.utils.formatSurplusTime(info.costTime);
        let minute = Number(formatDate.day) * 24 * 60 + Number(formatDate.hours) * 60 + Number(formatDate.minutes);
        let second = Number(formatDate.second);
        if (0 === minute && 0 === second) {
            second = 1;
        }
        let timeStr = second + ` ${we.core.langMgr.getLangText(HallLanguage.WITHDRAW__RECORDROLL_ROLL_SECOND)}`;
        if (minute > 0) {
            timeStr = minute + ` ${we.core.langMgr.getLangText(HallLanguage.WITHDRAW__RECORDROLL_ROLL_MINUTE)} ` + timeStr;
        }

        let showName = this.formatNick(info.userName);
        let money = we.common.utils.formatAmountCurrency(info.money);
        let text = we.core.langMgr.getLangText(HallLanguage.WITHDRAW__BROADCAST_1, showName, `<color=${this.amountHex}>${money}</c>`, `<color=${this.timeHex}>${timeStr}</c>`);
        return text;
    }

    private formatNick(realName: string): string {
        if (!realName) {
            realName = '';
        }
        let showName = '';
        if (realName.length > 6) {
            showName = realName.slice(0, 2) + '*'.repeat(realName.length - 4) + realName.slice(-2);
        } else {
            if (realName.length >= 2) {
                if (realName.length == 2) {
                    showName = realName[0] + '*';
                } else {
                    showName = realName.slice(0, 1) + '*'.repeat(realName.length - 2) + realName.slice(-1);
                }
            } else {
                showName = '*';
            }
        }
        return showName;
    }
}
