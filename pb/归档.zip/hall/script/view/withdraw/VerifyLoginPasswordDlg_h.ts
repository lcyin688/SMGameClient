import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('VerifyLoginPasswordDlgView_h', we.bundles.hall)
class VerifyLoginPasswordDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnConfirm: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_password: cc.EditBox = null;

    @we.ui.ccBind(cc.Node)
    public RCN_pwdStatus: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('VerifyLoginPasswordDlg_h', we.bundles.hall)
export class VerifyLoginPasswordDlg_h extends we.ui.DlgSystem<VerifyLoginPasswordDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnConfirm, we.core.Func.create(this.onClickConfirm, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_password.node, 'editingDidBegan', we.core.Func.create(this.onPwdInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_password.node, 'editingDidEnded', we.core.Func.create(this.onPwdInputEnd, this));
        this.view.cc_onBtnClick(this.view.RCN_pwdStatus, we.core.Func.create(this.onChangePwdShow, this)).setSleepTime(0.1);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.onPwdInputEnd();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onPwdInputStart() {
        this.view.RC_edit_password.placeholderLabel.string = ``;
    }

    private onPwdInputEnd() {
        if (this.view.RC_edit_password.string == '') {
            this.view.RC_edit_password.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.WITHDRAW_WINDOW_7);
        }
    }

    private onClickConfirm() {
        const pwd = this.view.RC_edit_password.string;
        if (!pwd) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.WITHDRAW_WINDOW_7));
            return;
        }
        we.common.apiMgr.getWithdrawVerifyToken(
            {
                password: pwd,
                verificationType: we.common.withdrawMgr.bindCardTokenType.bindCard,
            },
            (data: ApiProto.GetPasswordVerificationTokenResp) => {
                if (data.token) {
                    we.common.withdrawMgr.bindCardToken = data.token;
                    this.closeView();
                    // 无可用账号 直接打开提现选择界面，有账号时打开提现账号列表
                    const accounts = we.common.withdrawMgr.accountList;
                    if (accounts.length > 0) {
                        we.currentUI.show(HallViewId.WithdrawAccountDlg);
                    } else {
                        we.currentUI.show(HallViewId.WithdrawSelectChannelDlg);
                    }
                }
            }
        );
    }

    private onChangePwdShow(): void {
        this.view.RC_edit_password.inputFlag = this.view.RC_edit_password.inputFlag == cc.EditBox.InputFlag.DEFAULT ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
        let children = this.view.RCN_pwdStatus.children || [];
        if (children.length == 2) {
            children[0].active = this.view.RC_edit_password.inputFlag == cc.EditBox.InputFlag.DEFAULT;
            children[1].active = this.view.RC_edit_password.inputFlag == cc.EditBox.InputFlag.PASSWORD;
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(VerifyLoginPasswordDlg_h, `${HallViewId.VerifyLoginPasswordDlg}_h`)
class VerifyLoginPasswordDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(VerifyLoginPasswordDlg_h, uiBase.addComponent(VerifyLoginPasswordDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VerifyLoginPasswordDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<VerifyLoginPasswordDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(VerifyLoginPasswordDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VerifyLoginPasswordDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(VerifyLoginPasswordDlg_h).beforeUnload();
    }
}
