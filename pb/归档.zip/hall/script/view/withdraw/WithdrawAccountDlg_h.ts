import { HallEvent } from '../../config/HallEvent';
import { HallViewId } from '../HallViewId';
import WithdrawAccountItem_h from './WithdrawAccountItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WithdrawAccountDlgView_h', we.bundles.hall)
class WithdrawAccountDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnNew: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_confirm: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_noData: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WithdrawAccountDlg_h', we.bundles.hall)
export class WithdrawAccountDlg_h extends we.ui.DlgSystem<WithdrawAccountDlgView_h> {
    /** 当前选择账号信息 */
    private curAccountInfo: ApiProto.WithdrawAccountInfo = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_confirm, we.core.Func.create(this.onClickConfirm, this));
        this.view.cc_onBtnClick(this.view.RCN_btnNew, we.core.Func.create(this.onClickNew, this));

        cc.director.on(HallEvent.WITHDRAW_UPDATE_ACCOUNT_LIST, this.onUpdateBankInfo, this);
        cc.director.on(HallEvent.WITHDRAW_ACCOUNT_SELECT, this.onUpdateSelectInfo, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        let accounts = we.common.withdrawMgr.accountList || [];
        this.view.RCN_noData.active = accounts.length == 0;

        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list.numItems = accounts.length;

        // 设置默认选中
        let curSelectAccount = we.common.withdrawMgr.selectAccountInfo;
        let children = this.view.RC_list.content.children || [];
        if (curSelectAccount) {
            for (let i = 0; i < children.length; i++) {
                const cmp = children[i]?.getComponent(WithdrawAccountItem_h);
                let itemAccountInfo = cmp?.accountInfo?.info;
                let select = itemAccountInfo?.channelType == curSelectAccount.channelType && itemAccountInfo.account == curSelectAccount.account;
                if (select) {
                    cmp.setSelectStatus(true);
                    this.curAccountInfo = cmp.accountInfo;
                    break;
                }
            }
        } else {
            const cmp = children[0]?.getComponent(WithdrawAccountItem_h);
            if (cmp) {
                this.curAccountInfo = cmp.accountInfo;
                cmp.setSelectStatus(true);
            }
        }
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy(): void {
        cc.director.off(HallEvent.WITHDRAW_UPDATE_ACCOUNT_LIST, this.onUpdateBankInfo, this);
        cc.director.off(HallEvent.WITHDRAW_ACCOUNT_SELECT, this.onUpdateSelectInfo, this);
    }

    private onClickNew(): void {
        we.currentUI.show(HallViewId.WithdrawSelectChannelDlg);
    }

    private onClickConfirm(): void {
        if (this.curAccountInfo?.info) {
            cc.director.emit(HallEvent.WITHDRAW_UPDATE_BANK_INFO, this.curAccountInfo.info, true);
            this.closeView();
        }
    }

    // 更新已绑定账号列表
    private onUpdateBankInfo(data: ApiProto.UserBankInfo) {
        let accounts = we.common.withdrawMgr.accountList;
        this.view.RC_list.numItems = accounts.length;

        // 更新提现主界面 绑定账号展示
        let curSelectAccount = we.common.withdrawMgr.selectAccountInfo;
        let updateMainUI = data?.channelType == curSelectAccount?.channelType && data.account == curSelectAccount?.account;
        if (updateMainUI) {
            cc.director.emit(HallEvent.WITHDRAW_UPDATE_BANK_INFO, data, true);
        }
    }

    protected onRenderEvent(item: cc.Node, i: number): void {
        let accounts = we.common.withdrawMgr.accountList;
        if (accounts.length > i) {
            let select = this.curAccountInfo?.info.channelType == accounts[i].info.channelType && this.curAccountInfo?.info.account == accounts[i].info.account;
            item.getComponent(WithdrawAccountItem_h).init(accounts[i], select);
        }
    }

    private onUpdateSelectInfo(data: ApiProto.WithdrawAccountInfo): void {
        if (cc.isValid(this.view.uiRoot)) {
            this.curAccountInfo = data;
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WithdrawAccountDlg_h, `${HallViewId.WithdrawAccountDlg}_h`)
class WithdrawAccountDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WithdrawAccountDlg_h, uiBase.addComponent(WithdrawAccountDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WithdrawAccountDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(WithdrawAccountDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WithdrawAccountDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WithdrawAccountDlg_h).beforeUnload();
    }
}
