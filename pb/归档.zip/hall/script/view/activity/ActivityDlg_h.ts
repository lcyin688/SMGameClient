import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import ActivityCommonPreview_h from './ActivityCommonPreview_h';
import ActivityToggleItem_h from './ActivityToggleItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('ActivityDlgView_h', we.bundles.hall)
class ActivityDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_clickMask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_menu: cc.Node = null;

    @we.ui.ccBind(cc.Toggle)
    public RC_toggle_autoOpen: cc.Toggle = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('ActivityDlg_h', we.bundles.hall)
export class ActivityDlg_h extends we.ui.DlgSystem<ActivityDlgView_h> {
    private curActType: number = 0;
    private curAct: we.common.IActivityConf = null;
    private countTimeSchedule: number = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.view.RC_toggle_autoOpen.node.on('toggle', this.onClickNoProp, this);
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.initMenu();

        cc.director.on(HallEvent.ACTIVITY_CENTER_OPEN_OTHER, this.closeView, this);
        cc.director.on(HallEvent.ACTIVITY_CENTER_MASK, this.onClickMaskSt, this);

        let isClickNoProp = we.common.storage.getDay('common', 'no_prop_activity');
        this.view.RC_toggle_autoOpen.isChecked = isClickNoProp === true ? true : false;

        this.updateMenuList();
    }

    private async updateMenuList(): Promise<void> {
        this.curActType = we.common.activityMgr.SubActivity.NULL;
        const activityConf = this.filterPartActivity();
        this.view.RC_list.numItems = activityConf.length;

        // 注册 按钮切换管理组件
        await this.scheduleOnce(0);
        this.view.RC_menu.children.forEach((v, i) => {
            this.view.RC_menu.getComponent(we.ui.WESwitchMenu)?.addMenuBtn(v, i);
        });
        this.view.RC_menu.getComponent(we.ui.WESwitchMenu)?.onSwitchMenu(0);
    }

    private filterPartActivity(): we.common.IActivityConf[] {
        let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
        let conf = we.common.activityMgr.activityConf;
        let activityConf: we.common.IActivityConf[] = [];
        for (let i = 0; i < conf.length; i++) {
            if (conf[i].is_term && conf[i].expire_time - 1 < curTime) {
                continue;
            }

            if (conf[i].type != we.common.activityMgr.SubActivity.DAILY_SIGN_IN || we.core.flavor.getSkinCode() !== we.core.SkinCode.cm5) {
                activityConf.push(conf[i]);
            }
        }
        return activityConf;
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy(): void {
        let isShow = HallMgr.openPermissionDlg(HallMgr.Permission_Type.NOTIFICATION);
        if (!isShow) {
            cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Activity);
        }
        cc.director.off(HallEvent.ACTIVITY_CENTER_MASK, this.onClickMaskSt, this);
        cc.director.off(HallEvent.ACTIVITY_CENTER_OPEN_OTHER, this.closeView, this);
    }

    private initMenu() {
        this.view.RC_menu.getComponent(we.ui.WESwitchMenu).onSelected = (node: cc.Node, i: number) => {
            node.getChildByName('unSelect').active = false;
            node.getChildByName('select').active = true;

            this.onSwitchContent(node, i);
        };

        this.view.RC_menu.getComponent(we.ui.WESwitchMenu).onUnselected = (node: cc.Node, i: number) => {
            if (!cc.isValid(node)) {
                return;
            }
            node.getChildByName('unSelect').active = true;
            node.getChildByName('select').active = false;
        };
    }

    private onRenderEvent(node: cc.Node, index: number) {
        const activityConf = this.filterPartActivity();
        let data = activityConf[index];
        if ((index === 0 && this.curActType == we.common.activityMgr.SubActivity.NULL) || this.curAct == null) {
            this.curAct = data;
            this.curActType = data.type;
        }

        node.attr({ activityId: data._id, activityType: data.type });
        node.getComponent(ActivityToggleItem_h)?.init?.(data);
    }

    private onClickMaskSt(isShow: boolean = false): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        this.view.RC_clickMask.active = isShow;
    }

    /** 切换 */
    private onSwitchContent(node: cc.Node, index: number): void {
        let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
        let conf = this.filterPartActivity();

        let activityId = node?.['activityId'];
        for (let i = 0; i < conf.length; i++) {
            const element = conf[i];
            if (activityId == element?._id) {
                this.curAct = conf[i];
                this.curActType = this.curAct.type;

                let comp = node.getComponent(ActivityToggleItem_h);
                if (comp) {
                    comp.setCheckState();
                }
                if (this.curAct) {
                    // 加载右侧图片 加载右侧活动详情
                    this.loadingActivityShow();
                    // 定时
                    this.countTimeSchedule && this.removeTimerById(this.countTimeSchedule);
                    this.countTimeSchedule = null;
                    if (this.curAct.is_term) {
                        this.countActivityTime(this.curAct.expire_time - curTime);
                    }
                }

                return;
            }
        }

        this.activityEnd(activityId);
    }

    private loadSubActivity() {
        if (!this.curAct) {
            return;
        }

        let loadContent = (path: string, activityId: number, cb?: (node: cc.Node) => void) => {
            we.common.commonMgr.createRemoteLoading(this.view.RC_content);

            this.loadAsset(path, cc.Prefab, this, false).then((prefab) => {
                we.common.commonMgr.removeRemoteLoading(this.view.RC_content);
                if (this.curAct._id != activityId) {
                    return;
                }

                if (cc.isValid(prefab)) {
                    let content = cc.instantiate(prefab);
                    content.getComponent(cc.BlockInputEvents) ?? content.addComponent(cc.BlockInputEvents);
                    content.attr({ activityId: activityId });
                    this.view.RC_content.addChild(content);

                    typeof cb == 'function' && cb(content);
                }
            });
        };

        switch (this.curAct.type) {
            case we.common.activityMgr.SubActivity.COMMON_PREVIEW:
                loadContent(HallRes.prefab.ActivityCommonPreview, this.curAct._id, (node) => {
                    if (!cc.isValid(this.view.uiRoot)) {
                        return;
                    }
                    node.getComponent(ActivityCommonPreview_h)?.init?.(this.curAct);
                });
                break;
            case we.common.activityMgr.SubActivity.ACCOUNT_SAFE:
                loadContent(HallRes.prefab.ActivityAccountSafe, this.curAct._id);
                break;
            case we.common.activityMgr.SubActivity.FIRST_WITHDRAW:
                loadContent(HallRes.prefab.ActivityWithdrawal, this.curAct._id);
                break;
            case we.common.activityMgr.SubActivity.DAILY_SIGN_IN:
                // 每日签到入口
                loadContent(HallRes.prefab.ActivityDailyAward, this.curAct._id);
                break;
            case we.common.activityMgr.SubActivity.AGENT:
                loadContent(HallRes.prefab.ActivityAgent, this.curAct._id);
                break;
            case we.common.activityMgr.SubActivity.PEN_PEN_DELIVERY:
                loadContent(HallRes.prefab.ActivityPenPenDelivery, this.curAct._id);
                break;
            default:
                break;
        }
    }

    /** 加载右侧活动详情 */
    private loadingActivityShow(): void {
        if (!this.curAct) {
            return;
        }

        let find = false;
        for (let i = 0; i < this.view.RC_content.childrenCount; i++) {
            let content = this.view.RC_content.children[i];
            if (!find && this.curAct._id == content['activityId']) {
                content.active = true;
                find = true;
            } else {
                content.active = false;
            }
        }

        if (!find) {
            this.loadSubActivity();
        }
    }

    /** 设置活动剩余时间 */
    private countActivityTime(expireTime) {
        if (expireTime <= 0) {
            this.activityEnd();
            return;
        }

        let func = () => {
            expireTime -= 1;
            if (expireTime <= 0) {
                this.removeTimerById(this.countTimeSchedule);
                this.countTimeSchedule = null;
                this.activityEnd();
                return;
            }
        };

        this.countTimeSchedule = this.schedule(1, func);
    }

    private activityEnd(activityId?: number) {
        if (!activityId) {
            if (!this.curAct) {
                return;
            }
            activityId = this.curAct._id;
        }

        we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.ACTIVTY_TIPS_1));

        // 移除 活动内容
        for (let i = 0; i < this.view.RC_content.childrenCount; i++) {
            let content = this.view.RC_content.children[i];
            if (activityId == content['activityId']) {
                content.destroy();
                break;
            }
        }

        this.updateMenuList();
    }

    private onClickNoProp(toggle: cc.Toggle) {
        we.common.storage.setDay('common', 'no_prop_activity', toggle.isChecked);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(ActivityDlg_h, `${HallViewId.ActivityDlg}_h`)
class ActivityDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(ActivityDlg_h, uiBase.addComponent(ActivityDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ActivityDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<ActivityDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(ActivityDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ActivityDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(ActivityDlg_h).beforeUnload();
    }
}
