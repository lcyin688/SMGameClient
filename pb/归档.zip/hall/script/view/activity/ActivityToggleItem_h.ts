const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityToggleItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_offDesc: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_onDesc: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private activityConf: we.common.IActivityConf = null;
    private redDotName: string[];

    protected onLoad(): void {
        cc.director.on(we.common.EventName.NOTICE_EVENT_CENTER, this.onActionNotice, this);
    }

    protected onDestroy(): void {
        cc.director.off(we.common.EventName.NOTICE_EVENT_CENTER, this.onActionNotice, this);
    }

    public init(data: we.common.IActivityConf) {
        if (!data) {
            return;
        }

        this.activityConf = data;
        let descStr = data.activity_name?.[we.core.langMgr.getCurLangCode()];
        this.RC_lab_offDesc.string = descStr;
        this.RC_lab_onDesc.string = descStr;

        we.common.redDot.red.appendVRedDotNode(this.node).then((notice) => {
            this.redDotName = we.common.redDot.cfg.eventCenter.map((path) => {
                return `${path}/${this.node['activityId']}`;
            });
            we.common.redDot.red.quickSetRedDotData(we.common.redDot.cfg.eventCenter, [{ name: this.node['activityId'], count: 0 }]);
            we.common.redDot.red.registeredRedDot({ paths: this.redDotName, node: notice });
            this.onActionNotice();
        });
    }

    public setCheckState() {
        const actIds = we.common.activityMgr.clickRecord || [];
        if (actIds.indexOf(this.node['activityId']) < 0) {
            we.common.activityMgr.clickRecord?.push(this.node['activityId']);
            we.common.storage?.setById('common', 'click_event_center_record', we.common.activityMgr.clickRecord);
            // 清除当前红点
            this.onActionNotice();
        }

        cc.director.emit(we.common.EventName.NOTICE_EVENT_CENTER);
    }

    private onActionNotice(): void {
        if (!this.redDotName) {
            return;
        }

        let showNotice = we.common.activityMgr.getNoticeStatus(this.activityConf);
        we.common.redDot.red.updateRedDotCnt(this.redDotName, showNotice ? 1 : 0, true);
    }
}
