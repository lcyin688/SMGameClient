import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import JumpModMgr, { JUMP_WAY } from '../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityCommonPreview_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_bg: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private activityData: we.common.IActivityConf = null;

    protected onLoad(): void {
        this.onBtnClick(this.RC_spr_bg.node, we.core.Func.create(this.onClickBg, this));
    }

    public init(activityData: we.common.IActivityConf): void {
        this.RC_content.active = false;

        if (!activityData) {
            return;
        }
        this.activityData = activityData;

        let url = this.activityData.activity_picture?.[we.core.langMgr.getCurLangCode()];
        this.loadAssetRemote(url, cc.SpriteFrame, this, this.node).then((spf) => {
            if (spf) {
                this.RC_spr_bg.spriteFrame = spf;
                this.RC_content.active = true;
            }
        });
    }

    private onClickBg(): void {
        if (!this.activityData) {
            return;
        }
        if (this.activityData.is_jump == JUMP_WAY.NULL) {
            return;
        }

        if (this.activityData.jump_position == we.common.JumpCmd.Rebate && !we.core.projectConfig.settingsConfig?.userRebateSwitch) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_42));
            return;
        }

        if (this.activityData.is_jump == JUMP_WAY.IN_GAME) {
            JumpModMgr.jumpToModule(this.activityData.jump_position);
            if (this.activityData.jump_position == we.common.JumpCmd.Agent || this.activityData.jump_position == we.common.JumpCmd.Recharge) {
                cc.director.emit(HallEvent.ACTIVITY_CENTER_OPEN_OTHER);
            }
        } else if (this.activityData.is_jump == JUMP_WAY.OUT_GAME) {
            we.core.nativeUtil.openUrl(this.activityData.jump_position);
        }
    }
}
