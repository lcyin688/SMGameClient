import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import JumpModMgr, { JUMP_WAY } from '../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ActivityCommonPreview_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_bg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_bg: cc.Sprite = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */
    private activityData: we.common.IActivityConf = null;

    public init(activityData: we.common.IActivityConf): void {
        this.RC_bg.active = false;
        this.RC_content.active = false;
        this.setTitle();

        if (!activityData) {
            return;
        }

        this.activityData = activityData;
        this.setTitle(this.activityData.activity_name?.[we.core.langMgr.getCurLangCode()]);
        this.loadSubActivity();
    }

    private setTitle(str: string = ''): void {
        if (!cc.isValid(this.RC_lab_title)) {
            return;
        }

        if (!(typeof str == 'string')) {
            return;
        }

        this.RC_lab_title.string = str;
    }

    private loadSubActivity() {
        let path = null;
        let url = null;
        let loadContent = (path: string, activityId: number, cb?: (node: cc.Node) => void) => {
            we.common.commonMgr.createRemoteLoading(this.RC_content);
            this.RC_content.removeAllChildren();

            this.loadAsset(path, cc.Prefab, this, false).then((prefab) => {
                we.common.commonMgr.removeRemoteLoading(this.RC_content);

                if (this.activityData._id != activityId) {
                    return;
                }

                if (cc.isValid(prefab)) {
                    let content = cc.instantiate(prefab);
                    content.getComponent(cc.BlockInputEvents) ?? content.addComponent(cc.BlockInputEvents);
                    content.attr({ activityId: activityId });
                    this.RC_content.addChild(content);

                    typeof cb == 'function' && cb(content);
                    this.RC_content.active = true;
                }
            });
        };

        switch (this.activityData.type) {
            case we.common.activityMgr.SubActivity.COMMON_PREVIEW:
                url = this.activityData.activity_picture?.[we.core.langMgr.getCurLangCode()];
                this.loadAssetRemote(url, cc.SpriteFrame, this, this.node).then((spf) => {
                    if (spf) {
                        this.RC_spr_bg.spriteFrame = spf;
                        this.RC_bg.active = true;
                        this.onBtnClick(this.RC_spr_bg.node, we.core.Func.create(this.onClickBg, this)).setSleepTime(1.5);
                    }
                });
                break;
            case we.common.activityMgr.SubActivity.ACCOUNT_SAFE:
                loadContent(HallRes.prefab.ActivityAccountSafe, this.activityData._id);
                break;
            case we.common.activityMgr.SubActivity.FIRST_WITHDRAW:
                loadContent(HallRes.prefab.ActivityWithdrawal, this.activityData._id);
                break;
            case we.common.activityMgr.SubActivity.AGENT:
                loadContent(HallRes.prefab.ActivityAgent, this.activityData._id);
                break;
            case we.common.activityMgr.SubActivity.PEN_PEN_DELIVERY:
                loadContent(HallRes.prefab.ActivityPenPenDelivery, this.activityData._id);
                break;
            default:
                break;
        }
    }

    private onClickBg(): void {
        if (!this.activityData) {
            return;
        }
        if (this.activityData.is_jump == JUMP_WAY.NULL) {
            return;
        }

        if (this.activityData.jump_position == we.common.JumpCmd.Rebate && !we.core.projectConfig.settingsConfig?.userRebateSwitch) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_42));
            return;
        }

        if (this.activityData.is_jump == JUMP_WAY.IN_GAME) {
            JumpModMgr.jumpToModule(this.activityData.jump_position);
        } else if (this.activityData.is_jump == JUMP_WAY.OUT_GAME) {
            we.core.nativeUtil.openUrl(this.activityData.jump_position);
        }
    }
}
