import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import WeekCardMgr from '../../manager/WeekCardMgr';
import { HallViewId } from '../HallViewId';
import WeekCardMenuItem_h from './WeekCardMenuItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WeekCardDlgView_h', we.bundles.hall)
class WeekCardDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_day: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_now: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_price: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_total: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RCN_buy: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_getAward: cc.Node = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RCN_icon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RCN_leftDay: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RCN_leftDayRoot: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_received: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_tips: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WeekCardDlg_h', we.bundles.hall)
export class WeekCardDlg_h extends we.ui.DlgSystem<WeekCardDlgView_h> {
    /** 当前购买档位 level */
    private curBuyLv: number = -1;

    /** 当前选择档位 index  */
    private selectIndex: number = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RCN_buy.active = false;
        this.view.RCN_getAward.active = false;
        this.view.RCN_received.active = false;
        this.view.RCN_tips.active = false;
        this.view.RCN_leftDayRoot.active = false;

        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list.setSelectedEvent(we.core.Func.create(this.onRenderSelectEvent, this));

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_rule, we.core.Func.create(this.onClickRule, this));
        this.view.cc_onBtnClick(this.view.RCN_buy, we.core.Func.create(this.onClickBuy, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_getAward, we.core.Func.create(this.onClickGetAward, this)).setSleepTime(1.5);

        cc.director.on(HallEvent.WEEK_CARD_REFRESH_UI, this.onUpdateUI, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        await WeekCardMgr.syncData();

        if (!WeekCardMgr.data.activitySwitch) {
            we.currentUI.hide(HallViewId.WeekCardDlg);
            return;
        }

        this.curBuyLv = -1;
        let buyWeekCard = WeekCardMgr.data?.userWeeklyCard?.[0];
        if (buyWeekCard) {
            this.curBuyLv = buyWeekCard.level;
        }

        this.selectIndex = 0;
        let conf = WeekCardMgr.data?.configList || [];
        if (conf.length > 0) {
            for (let i = 0; i < conf.length; i++) {
                if (conf[i].level == this.curBuyLv) {
                    this.selectIndex = i;
                    break;
                }
            }
        }

        this.updateMenuList();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy(): void {
        cc.director.off(HallEvent.WEEK_CARD_REFRESH_UI, this.onUpdateUI, this);
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Week_Card);
    }

    private onUpdateUI() {
        this.curBuyLv = -1;
        let buyWeekCard = WeekCardMgr.data?.userWeeklyCard?.[0];
        if (buyWeekCard) {
            this.curBuyLv = buyWeekCard.level;
        }

        this.updateMenuList();
    }

    private onClickBuy() {
        let conf = WeekCardMgr.data?.configList?.[this.selectIndex];
        if (!conf) {
            return;
        }

        we.common.apiMgr.getActiveRechargeType(
            conf.id,
            (ptData: ApiProto.payTypeResp) => {
                if (cc.isValid(this.view.uiRoot)) {
                    let payChnList = ptData.rechargeTypeCategory || [];
                    let payType = payChnList[0].payType;
                    if (payChnList.length == 1 && (we.common.payMgr.isStorePay(payType) || we.common.payMgr.isIntegrationPay(payType))) {
                        we.common.payMgr.getOrderInfo(conf.id, payType);
                    } else {
                        we.currentUI.show(HallViewId.StorePayTypeDlg, { productData: conf, payTypeDataList: payChnList, price: conf.price });
                    }
                }
            },
            (code) => {},
            true
        );
    }

    private onClickGetAward() {
        if (this.curBuyLv == -1) {
            return;
        }

        let awardSwitch = WeekCardMgr.data?.activityAwardSwitch;
        if (awardSwitch) {
            WeekCardMgr.getWeekCardAward(this.curBuyLv, (data: ApiProto.UserWeeklyCardClaimResp) => {
                if (!we.common.userMgr.isLogin()) {
                    return;
                }

                we.core.projectConfig.settingsConfig.userWeeklyCardClaimStatus = false;
                WeekCardMgr.data.userWeeklyCard[0].claimStatus = false;

                if (cc.isValid(this.view.uiRoot)) {
                    this.upWeekCardInfo();
                }

                let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.reward }];
                HallMgr.openGetAwardsDlg(awardMap);

                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.weekCard, 0, true);
            });
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.TIPS_TYPE_2));
        }
    }

    private onClickRule() {
        we.currentUI.showSafe(HallViewId.WeekCardRuleDlg);
    }

    private onRenderEvent(node: cc.Node, index: number) {
        let conf = WeekCardMgr.data.configList?.[index];
        if (conf) {
            // 计算累计赠送
            let giveAmount = conf.immediateReward + 7 * conf.dailyReward - we.common.utils.priceToAmount(conf.price);
            node.getComponent(WeekCardMenuItem_h)?.init(index, giveAmount, conf.level == this.curBuyLv);
        }
    }

    private onRenderSelectEvent(node: cc.Node, index: number) {
        let conf = WeekCardMgr.data.configList?.[index];
        if (conf) {
            this.selectIndex = index;
            this.selectGroupMove(index);
            this.upWeekCardInfo();
        }
    }

    private selectGroupMove(i: number) {
        let scrollTo = 0;
        if (i <= 1) {
            scrollTo = 0;
        } else if (i >= 2) {
            scrollTo = i - 1;
        }
        this.view.RC_list.scrollTo(scrollTo);
    }

    private updateMenuList(): void {
        let conf = WeekCardMgr.data.configList;
        this.view.RC_list.numItems = conf.length;
        this.view.RC_list.selectedId = this.selectIndex;
        this.selectGroupMove(this.selectIndex);

        this.upWeekCardInfo();
    }

    private upWeekCardInfo() {
        let conf = WeekCardMgr.data?.configList?.[this.selectIndex];
        if (!conf) {
            return;
        }

        this.view.RCN_icon.index = this.selectIndex;

        let isBuy = this.curBuyLv != -1;
        let isSelectBuy = conf.level === this.curBuyLv;
        this.view.RCN_buy.active = !isBuy;
        this.view.RCN_leftDayRoot.active = isBuy && isSelectBuy;
        this.view.RCN_tips.active = isBuy && !isSelectBuy;
        let canDrawAward = WeekCardMgr.data.userWeeklyCard?.[0]?.claimStatus;
        this.view.RCN_getAward.active = isBuy && isSelectBuy && canDrawAward;
        this.view.RCN_received.active = isBuy && isSelectBuy && !canDrawAward;

        this.view.RC_lab_now.string = we.common.utils.formatAmountCurrency(conf.immediateReward, false);
        this.view.RC_lab_day.string = we.common.utils.formatAmountCurrency(conf.dailyReward, false);
        this.view.RC_lab_price.string = we.common.utils.formatPrice(conf.price, true, false);
        let totalAward = conf.immediateReward + 7 * conf.dailyReward;
        this.view.RC_lab_total.string = we.common.utils.formatAmountCurrency(totalAward, false);
        if (isBuy) {
            let leftDay = WeekCardMgr.data.userWeeklyCard?.[0]?.remainingDay;
            this.view.RCN_leftDay.setStringFormat(we.core.langMgr.getLangText(HallLanguage.WEEKLY_CARD_HALL_10), leftDay);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WeekCardDlg_h, `${HallViewId.WeekCardDlg}_h`)
class WeekCardDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WeekCardDlg_h, uiBase.addComponent(WeekCardDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WeekCardDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WeekCardDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(WeekCardDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WeekCardDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WeekCardDlg_h).beforeUnload();
    }
}
