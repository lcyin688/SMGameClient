const { ccclass, property } = cc._decorator;

@ccclass
export default class MailContentClick_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    /* =========================== AUTO CODE TOEND =========================== */

    public clickMe(event, param: string) {
        we.common.commonMgr.playBtnMusic();
        if (we.common.utils.isIncludeHttpUrl(param)) {
            we.core.nativeUtil.openUrl(param);
        }
    }
}
