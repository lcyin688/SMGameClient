import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import MailContent_v from './MailContent_v';
import MailItem_v from './MailItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('MailDlgView_v', we.bundles.hall)
class MailDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_newCount: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_noMessages: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_contentRoot: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_deleteAllMail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_readAllMail: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('MailDlg_v', we.bundles.hall)
export class MailDlg_v extends we.ui.DlgSystem<MailDlgView_v> {
    private contentComp: MailContent_v = null;
    private isCanReceiveAllMail: boolean = false;

    private _unreadMailCount: number = 0; // 仅指 系统邮件
    set unreadMailCount(num: number) {
        this._unreadMailCount = num;
        this.view.RC_lab_newCount.string = ' ' + this._unreadMailCount;
    }

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.resetInit();
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderMailList, this));
        this.view.cc_onScrollViewEvent(this.view.RC_list.node, 'scroll-to-bottom', we.core.Func.create(this.onRecordScrollEnd, this));

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_deleteAllMail, we.core.Func.create(this.onDeleteAllRead, this));
        this.view.cc_onBtnClick(this.view.RCN_readAllMail, we.core.Func.create(this.onReceiveAllAward, this));

        cc.director.on(we.common.EventName.UPDATE_MAIL_LIST, this.onUpdateList, this);
        cc.director.on(HallEvent.EVENT_MAIL_CONTEXT_READ, this.onShowMailContent, this);
        cc.director.on(HallEvent.EVENT_MAIL_CONTEXT_CLOSE, this.onCloseMailContent, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        let path = HallRes.prefab.mail.contentItm;
        let mailContentItm = await this.loadAsset(path, cc.Prefab);
        let node = cc.instantiate(mailContentItm);
        node.parent = this.view.RCN_contentRoot;
        this.contentComp = node.getComponent(MailContent_v);

        await we.common.mailMgr.getMailList();

        this.showMailList();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(we.common.EventName.UPDATE_MAIL_LIST, this.onUpdateList, this);
        cc.director.off(HallEvent.EVENT_MAIL_CONTEXT_READ, this.onShowMailContent, this);
        cc.director.off(HallEvent.EVENT_MAIL_CONTEXT_CLOSE, this.onCloseMailContent, this);
    }

    private resetInit(): void {
        this.view.RC_list.numItems = 0;
        this.view.RC_list.node.active = false;

        this.view.RC_noMessages.active = false;
        this.view.RCN_contentRoot.active = false;
        this.view.RCN_deleteAllMail.active = false;

        this.isCanReceiveAllMail = false;
        this.view.RCN_readAllMail.active = false;
    }

    /** 显示邮件列表 */
    private showMailList(): void {
        if (cc.isValid(this.view.uiRoot)) {
            this.resetInit();

            let mailListData = we.common.mailMgr.mailList || [];
            this.view.RCN_contentRoot.active = false;
            this.view.RC_noMessages.active = mailListData.length == 0;
            this.view.RCN_deleteAllMail.active = !this.view.RC_noMessages.active;

            this.view.RC_list.node.active = mailListData.length > 0;
            this.view.RC_list.numItems = mailListData.length;

            this.setMailOperation();
            this.onNewMail();
        }
    }

    private onRenderMailList(node: cc.Node, index: number): void {
        let mailData = we.common.mailMgr.mailList || [];
        if (index < mailData.length) {
            node.getComponent(MailItem_v).init(mailData[index], false);
        }
    }

    /** 邮件红点通知 */
    private onNewMail(): void {
        this.unreadMailCount = we.common.mailMgr.newMailNum;
    }

    private onRecordScrollEnd(): void {
        we.common.mailMgr.getMailList(false);
    }

    /**
     * 更新邮件列表
     * @param isForce 强制更新 默认 true
     */
    private onUpdateList(isForce: boolean = true): void {
        // 非强制刷新，邮件打开时不刷新邮件列表
        if (isForce) {
            this.showMailList();
        } else {
            if (!this.view.RCN_contentRoot.active) {
                this.showMailList();
            }
        }

        this.onNewMail();
    }

    /** 删除已读 */
    private onDeleteAllRead(): void {
        if (this.view.RC_noMessages.active) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.MAIL_EMPTYDATA));
            return;
        }

        // 删除已读/已领取
        if (we.common.mailMgr.isExistReadMail) {
            const positiveCallback = () => {
                we.common.mailMgr.deleteMail().then(() => {
                    if (!we.common.userMgr.isLogin()) {
                        return;
                    }

                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_DELETE_SUCCESS));

                    if (cc.isValid(this.view.RC_list)) {
                        this.view.RC_list.numItems = 0;
                    }

                    we.common.mailMgr.getMailList();
                });
            };

            we.commonUI.showConfirm({
                content: we.core.langMgr.getLangText(HallLanguage.MAIL_DELETE_ALL),
                yesButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CONFIRM),
                noButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CANCEL),
                yesHandler: we.core.Func.create(positiveCallback, this),
            });
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.MAIL_ALLDELETEFAIL));
        }
    }

    /** 读取所有邮件 */
    private onReceiveAllAward(): void {
        if (this.isCanReceiveAllMail) {
            we.common.mailMgr
                .getMailAward()
                .then((data: ApiProto.ReadAllMailResp) => {
                    HallMgr.openGetAwardsDlg(data.attachment);
                    we.common.mailMgr.getMailList();
                })
                .catch((code) => {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_GET_GIFT_FAIL));
                });
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TIPS_TYPE_1));
        }
    }

    /**
     * 打开邮件内容界面
     * @param data
     */
    private onShowMailContent(data: ApiProto.MailDetailItem) {
        if (!data) {
            return;
        }

        if (we.common.mailMgr.getMailValidTime(data) <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.MAIL_TIPS1));
            we.common.mailMgr.getMailList();
            return;
        }

        if (data.status == we.common.mailMgr.MailStatus.Unread) {
            we.common.mailMgr.readMail(data.mailId);

            let isExistAttachment = we.common.mailMgr.isExistAttachment(data);
            let status = isExistAttachment ? we.common.mailMgr.MailStatus.ReadUnDraw : we.common.mailMgr.MailStatus.Read;
            we.common.mailMgr.updateMailStatus([data.mailId], status);

            this.unreadMailCount = we.common.mailMgr.newMailNum;
        }

        this.scheduleOnce(0).then(() => {
            this.view.RC_list.node.active = false;
            this.view.RCN_contentRoot.active = true;
            this.view.RCN_readAllMail.active = false;
            this.view.RCN_deleteAllMail.active = false;
            this.contentComp.init(data);
        });
    }

    /** 关闭邮件内容展示 */
    private onCloseMailContent(): void {
        this.view.RCN_contentRoot.active = false;
        this.view.RC_list.node.active = true;
        this.view.RC_list.numItems = 0;

        this.scheduleOnce(0).then(() => {
            this.showMailList();
        });
    }

    private setMailOperation(): void {
        this.isCanReceiveAllMail = false;
        let mailData = we.common.mailMgr.mailList || [];
        for (let i = 0; i < mailData.length; i++) {
            const element = mailData[i];
            if (we.common.mailMgr.isExistAttachment(element)) {
                this.isCanReceiveAllMail = true;
                break;
            }
        }

        this.view.RCN_readAllMail.active = this.isCanReceiveAllMail;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(MailDlg_v, `${HallViewId.MailDlg}_v`)
class MailDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(MailDlg_v, uiBase.addComponent(MailDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MailDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<MailDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(MailDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(MailDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(MailDlg_v).beforeUnload();
    }
}
