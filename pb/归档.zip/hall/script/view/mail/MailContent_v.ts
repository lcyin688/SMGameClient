import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import MailItem_v from './MailItem_v';
import PropAwardItem_v from './PropAwardItem_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class MailContent_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_fromName: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_leftTime: cc.Label = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_contentRL: cc.RichText = null;

    @we.ui.ccBind(cc.Node)
    public RCN_award: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_delete: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_envelope: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private mailItem: cc.Prefab = null;
    private propAwardItem: cc.Prefab = null;
    private data: ApiProto.MailDetailItem = null;

    protected onLoad(): void {
        this.mailItem = this._rc.getRes('MailItem', cc.Prefab);
        this.propAwardItem = this._rc.getRes('PropAwardItem', cc.Prefab);

        this.onBtnClick(this.RCN_close, we.core.Func.create(this.onCloseOpenMail, this));
        this.onBtnClick(this.RCN_receive, we.core.Func.create(this.onReceiveMail, this));
        this.onBtnClick(this.RCN_delete, we.core.Func.create(this.onDeleteMail, this));
    }

    /**
     * 邮件内容
     * @param data
     */
    public init(data: ApiProto.MailDetailItem): void {
        this.node.opacity = 1;
        this.data = data;

        let validTime = we.common.mailMgr.getMailValidTime(data);
        let days = Math.ceil(validTime / (24 * 60 * 60));
        let dayStr = we.core.langMgr.getLangText(HallLanguage.ITEM_TIME, days);
        this.RC_lab_leftTime.string = we.core.langMgr.getLangText(HallLanguage.MAIL_TIPS2) + ' ' + dayStr;
        this.RC_lab_fromName.string = we.core.langMgr.getLangText(HallLanguage.PRIVATE_FROM) + ': ' + data.senderName;

        let hasAttachment = we.common.mailMgr.isExistAttachment(data);
        this.RCN_receive.active = hasAttachment;
        this.RCN_delete.active = !hasAttachment;

        this.RCN_envelope.removeAllChildren();
        this.RCN_award.removeAllChildren();

        // 显示邮件Item
        let myMailItem = cc.instantiate(this.mailItem);
        this.RCN_envelope.addChild(myMailItem);
        let comp = myMailItem?.getComponent(MailItem_v);
        if (comp) {
            comp.init(data, true);
        }

        // 邮件内容
        const newContent = this.data.content.split(': ').join(':\n');
        let str = newContent ? this.formatMailContent(newContent) : this.formatMailContent(data.content);
        if (we.common.utils.isIncludeHttpUrl(str)) {
            const httpReg = /http(s)?:\/\/[\w-]+(\.[\w-]+){1,5}(:\d+)?(\/[\S\w-]+)*\/?(\?\w+=\S*(&\w+=\S*)*)?/gm;
            const httpArr = str.match(httpReg); // 提取 http 的数组
            let strText = '';
            for (let i = 0; i < httpArr.length; i++) {
                const sepArr = str.split(httpArr[i]); // 按分割提取出的链接分割字符串
                const firstStr = sepArr.shift(); // 提取头部
                const startStrLength = (firstStr + httpArr[i]).length; // 计算第一段字符串长度
                str = str.slice(startStrLength); // 减去第一段字符串
                const text = '<u><size=22><color=#37e70e><on click="clickMe" param="' + httpArr[i] + '">' + httpArr[i] + '</on></c></size></u>';
                strText += firstStr + text;
                if (i == httpArr.length - 1 && sepArr.length > 0) {
                    // 最后一个分割
                    strText += sepArr[0];
                }
            }
            if (httpArr.length > 0) {
                str = strText;
            }
        }
        this.RC_rich_contentRL.string = str;

        // 附件
        for (let key in this.data.attachment) {
            let id = parseInt(key);
            let num = this.data.attachment[id];
            if (!this.propAwardItem) {
                we.warn(`MailContent_v init, propAwardItm is null`);
                break;
            }
            let gift = cc.instantiate(this.propAwardItem);
            this.RCN_award.addChild(gift);

            if (gift && gift.getComponent(PropAwardItem_v)) {
                gift.getComponent(PropAwardItem_v).init(num, this.data.status == we.common.mailMgr.MailStatus.ReadAndDraw, this.onReceiveMail.bind(this));
            }
        }

        this.node.opacity = 255;
    }

    /** 邮件点击领取(content中) */
    private onReceiveMail(): void {
        if (!this.data) {
            return;
        }

        if (this.data.status != we.common.mailMgr.MailStatus.ReadAndDraw && Object.keys(this.data.attachment).length > 0) {
            const mailId = this.data.mailId;
            we.common.mailMgr.getMailAward([mailId]).then((data: ApiProto.ReadAllMailResp) => {
                this.data.status = we.common.mailMgr.MailStatus.ReadAndDraw;

                HallMgr.openGetAwardsDlg(data.attachment);

                if (cc.isValid(this.node)) {
                    this.RCN_receive.active = false;
                    this.RCN_delete.active = true;

                    // 刷新礼物领取状态
                    let children = this.RCN_award.children;
                    for (let i = 0; i < children.length; i++) {
                        children[i].getComponent(PropAwardItem_v).updateStatus(true);
                    }
                }
            });
        } else {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.COMMON_RECEIVED));
        }
    }

    /** 删除邮件 */
    private onDeleteMail(): void {
        const condition1 = this.data.status == we.common.mailMgr.MailStatus.ReadAndDraw;
        const condition2 = this.data.status == we.common.mailMgr.MailStatus.Read;
        const condition3 = Object.keys(this.data.attachment).length <= 0;

        if (condition1 || (condition2 && condition3)) {
            const positiveCallback = () => {
                const mailId = this.data?.mailId;
                we.common.mailMgr.deleteMail([mailId]).then((data: ApiProto.ReadAllMailResp) => {
                    we.common.mailMgr.deleteMailById(mailId);

                    we.common.mailMgr.getMailList();

                    // 删除提示
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_DELETE_SUCCESS));

                    if (cc.isValid(this.node)) {
                        cc.director.emit(HallEvent.EVENT_MAIL_CONTEXT_CLOSE);
                    }
                });
            };

            we.commonUI.showConfirm({
                content: we.core.langMgr.getLangText(HallLanguage.MAIL_DELETE_ONE),
                yesHandler: we.core.Func.create(() => {
                    positiveCallback();
                }, this),
                noButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CANCEL),
            });
        } else {
            // 存在附件不可删除
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.MAIL_ALLDELETEFAIL)); // 删除失败
        }
    }

    /** 关闭已打开邮件界面 */
    private onCloseOpenMail(): void {
        cc.director.emit(HallEvent.EVENT_MAIL_CONTEXT_CLOSE);
    }

    private formatMailContent(content): string {
        let ret = '';
        const tag = 'timestamp';

        let searchStrPositions = (origin, sub) => {
            let positions = [];
            let pos = origin.indexOf(sub);
            while (pos > -1) {
                positions.push(pos);
                pos = origin.indexOf(sub, pos + 1);
            }
            return positions;
        };
        if (!content) {
            return '';
        }
        let matchResult = searchStrPositions(content, tag);
        if (0 === matchResult.length) {
            return content;
        }
        if (matchResult.length === 2) {
            let timeContent = content.substring(matchResult[0] + tag.length, matchResult[1]);
            if (timeContent && !Number.isNaN(Number(timeContent))) {
                let deltaUTC2LOCAL = new Date().getTimezoneOffset(); // 协调世界时（UTC）与本地时区之间的差值
                let deltaUTC2GMT7 = -7 * 60; // 协调世界时（UTC）与印尼时间(东七区)的差值
                let deltaMs = (deltaUTC2LOCAL - deltaUTC2GMT7) * 60 * 1000;
                deltaMs = 0; // 和邮件item时间保持一致

                let time = we.common.utils.formatDate(new Date(Number(timeContent) * 1000 + deltaMs), 'DD/MM/YYYY hh:mm');
                ret = content.substring(0, matchResult[0]) + time + content.substring(matchResult[1] + tag.length);
                return ret;
            } else {
                return content;
            }
        } else {
            return content;
        }
    }
}
