import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import UserCenterLangSelectItem_h from './UserCenterLangSelectItem_h';

const { ccclass, property } = cc._decorator;

@ccclass
export default class UserCenterLangSelect_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_langValue: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_langToggle: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_langDown: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_langSelectMask: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private langOptions = {
        [we.core.LangCode.en]: {
            key: HallLanguage.SETTINGS_LANGUAGE_1,
            index: -1,
        },
        [we.core.LangCode.ur]: {
            key: HallLanguage.SETTINGS_LANGUAGE_4,
            index: -1,
        },
    };

    protected onLoad(): void {
        const langList = we.core.flavor.getLangList();
        const curLang = this.langOptions[we.core.langMgr.getCurLangCode()];
        if (!curLang) {
            return;
        }
        if (langList.length > 1) {
            this.onToggle(this.node, we.core.Func.create(this.onToggleLangSelect, this));
            this.onBtnClick(this.RCN_langSelectMask, we.core.Func.create(this.onClickLangSelectMask, this));
            this.RC_langToggle.addComponentUnique(we.ui.WEToggleGroup)
                .setGroupMode(we.ui.ToggleGroupMode.SingleOne)
                .onListener(
                    we.core.Func.create((_: number, isChecked: boolean, index: number) => {
                        if (isChecked) {
                            this.onToggleLangChange(index);
                        }
                    }, this)
                );

            this.node.active = true;
            this.RC_lab_langValue.string = we.core.langMgr.getLangText(curLang.key);
            this.renderSelectItems(curLang, langList);
            this.renderLangSelectMask();
            this.node.getComponent(cc.Toggle).isChecked = false;
        } else {
            this.RCN_langDown.active = false;
            this.RC_lab_langValue.string = we.core.langMgr.getLangText(curLang.key);
        }
    }

    public async renderSelectItems(curLang: string, langList: string[]) {
        const prefab: cc.Prefab = await this.loadAsset(HallRes.prefab.userCenter.LangSelectItem, cc.Prefab);
        if (!prefab || !cc.isValid(this.node)) {
            return;
        }
        const toggleGroup = this.RC_langToggle.getComponent(we.ui.WEToggleGroup);
        langList.forEach((langCode, index) => {
            const langOption = this.langOptions[langCode];
            if (!langOption) {
                return;
            }
            const node = cc.instantiate(prefab);
            const item = node.addComponentUnique(UserCenterLangSelectItem_h);
            item.init(langOption.key);
            item.name = `toggle${index}`;
            toggleGroup.addToggle(node.getComponent(we.ui.WEToggle));
            this.RC_langToggle.addChild(node);
            langOption.index = index;

            if (curLang === langOption.key) {
                toggleGroup.setToggleStatus(index, true);
            }
        });
    }

    public async renderLangSelectMask() {
        const widget = this.RCN_langSelectMask.addComponentUnique(cc.Widget);
        widget.target = cc.director.getScene();
    }

    public onToggleLangChange(toggle: number | cc.Toggle) {
        let index = 0;
        if (toggle instanceof cc.Toggle) {
            index = Number(toggle.node.name.replace('toggle', ''));
        } else {
            index = Number(toggle);
        }
        let langCode = '';
        for (const key in this.langOptions) {
            if (this.langOptions[key].index === index) {
                langCode = key;
                break;
            }
        }
        if (!langCode) {
            we.warn('UserCenterDlg set langCode is undefined');
            return;
        }
        we.core.langMgr.switchLang(langCode as any);
        this.onClickLangSelectMask();

        we.currentUI.close(HallViewId.UserCenterDlg);
    }

    public onClickLangSelectMask() {
        const toggle = this.node.getComponent(cc.Toggle);
        toggle.isChecked = false;
        this.onToggleLangSelect();
    }

    public onToggleLangSelect() {
        const toggle = this.node.getComponent(cc.Toggle);
        this.RCN_langDown.angle = toggle.isChecked ? 180 : 0;
        if (toggle.isChecked) {
            const toggleGroup = this.RC_langToggle.getComponent(we.ui.WEToggleGroup);
            const curLang = we.core.langMgr.getCurLangCode();
            const langOption = this.langOptions[curLang];
            if (langOption && langOption.index != -1) {
                toggleGroup.setToggleStatus(langOption.index, true);
            }
        }
    }
}
