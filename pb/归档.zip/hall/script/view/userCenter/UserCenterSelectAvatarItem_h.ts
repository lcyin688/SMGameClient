const { ccclass, property } = cc._decorator;

@ccclass
export default class UserCenterSelectAvatarItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_head: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_select: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad() {
        this.RCN_select.active = false;
    }

    public initWithLocalData(data: string, gender) {
        we.common.utils.setAvatarSprite(this.RC_spr_head, data, gender);
    }

    /**
     * 设置选中状态
     * @param isSelect
     */
    public setItemSelect(isSelect: boolean = true) {
        this.RCN_select.active = isSelect;
    }

    protected start(): void {}

    protected onEnable(): void {}

    protected update(dt: number): void {}

    protected onDestroy(): void {}
}
