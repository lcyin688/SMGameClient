import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import UserCenterSelectAvatarItem_v from './UserCenterSelectAvatarItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('UserCenterSelectAvatarDlgView_v', we.bundles.hall)
class UserCenterSelectAvatarDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_modifyNickName: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_Name: cc.Label = null;

    @we.ui.ccBind(cc.ScrollView)
    public RC_scroll_mainView: cc.ScrollView = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_sendAvatar: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('UserCenterSelectAvatarDlg_v', we.bundles.hall)
export class UserCenterSelectAvatarDlg_v extends we.ui.DlgSystem<UserCenterSelectAvatarDlgView_v> {
    private checkIndex: number = 0;
    private AvatarArr: string[] = [];
    private avatarWidth: number = 0;
    private avatarHeight: number = 0;
    private tempUserNickName: string = '';
    private userEditText: boolean = false;

    /** 注册UI事件 */
    public async registerUIEvent() {
        // 按钮事件
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_sendAvatar, we.core.Func.create(this.onClickConfirm, this)).setSleepTime(2);

        // EditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_modifyNickName.node, 'textChanged', we.core.Func.create(this.onNickEditBoxTextChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_modifyNickName.node, 'editingDidEnded', we.core.Func.create(this.onNickNameChanged, this));
    }

    /** 显示窗口 */
    public async onShow(avatars: string[]) {
        this.view.RC_lab_Name.string = we.core.langMgr.getLangText(HallLanguage.WiTHDRAW__BINDCARD_NAME) + ':';
        this.view.RC_edit_modifyNickName.string = we.common.userMgr.userInfo.userName ? we.common.userMgr.userInfo.userName : '';
        this.tempUserNickName = we.common.userMgr.userInfo.userName;

        this.init(avatars);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    public async init(avatars: string[]) {
        this.AvatarArr = we.common.userMgr.avatarArr;
        if (avatars.length > 0) {
            // 顺序颠倒 最近使用的头像显示在最前面
            avatars = avatars.reverse();
            this.AvatarArr = avatars.concat(this.AvatarArr);
        }
        if (this.AvatarArr?.length < 1) {
            this.closeView();
            return;
        }

        const Prefab: cc.Prefab = await this.loadAsset(HallRes.prefab.userCenter.AvatarItem, cc.Prefab);

        this.view.RC_scroll_mainView.content.removeAllChildren();
        for (let i = 0; i < this.AvatarArr.length; i++) {
            let item = cc.instantiate(Prefab);
            this.view.RC_scroll_mainView.content.addChild(item);
            let itemCell = item.getComponent(UserCenterSelectAvatarItem_v);
            if (itemCell) {
                itemCell.initWithLocalData(this.AvatarArr[i], we.common.userMgr.userInfo.gender);
                this.view.cc_onBtnClick(
                    item,
                    we.core.Func.create(() => {
                        this.clickItem(i);
                    }, this)
                );
                if (this.AvatarArr[i] == we.common.userMgr.userInfo.avatar) {
                    this.checkIndex = i;
                    this.avatarWidth = item.getContentSize().width;
                    this.avatarHeight = item.getContentSize().height;
                }
            }
        }

        // 第一次进界面，默认第一个选中
        this.clickItem(this.checkIndex);

        let items = this.view.RC_scroll_mainView.content.children;
        if (items && items[this.checkIndex] && items[this.checkIndex].getComponent(UserCenterSelectAvatarItem_v)) {
            items[this.checkIndex].getComponent(UserCenterSelectAvatarItem_v).setItemSelect();
        }

        if (this.view.RC_scroll_mainView?.node) {
            this.view.RC_scroll_mainView.scrollToTop(0);
            this.scrollToCurSelect();
        }
    }

    // 定位到当前选中头像
    private scrollToCurSelect() {
        let maxScrollOffset = this.view.RC_scroll_mainView.getMaxScrollOffset();
        let selectWrapLayout = this.view.RC_scroll_mainView.content.getComponent(cc.Layout);
        let selectWrapSize = this.view.RC_scroll_mainView.content.getContentSize();
        let x_n, y_n;
        if (selectWrapSize.width - selectWrapLayout.paddingLeft - selectWrapLayout.paddingRight < 2 * this.avatarWidth + selectWrapLayout.spacingX) {
            x_n = 1;
        } else if (selectWrapSize.width - selectWrapLayout.paddingLeft - selectWrapLayout.paddingRight < 3 * this.avatarWidth + 2 * selectWrapLayout.spacingX) {
            x_n = 2;
        } else {
            x_n = 2 + Math.floor((selectWrapSize.width - selectWrapLayout.paddingLeft - selectWrapLayout.paddingRight - 2 * this.avatarWidth) / (this.avatarWidth + selectWrapLayout.spacingX));
        }
        y_n = Math.ceil(this.view.RC_scroll_mainView.content.childrenCount / x_n);

        let cur_line = Math.floor(this.checkIndex / x_n) + 1;

        let curHeight = selectWrapLayout.paddingTop + this.avatarHeight + (cur_line > 1 ? (cur_line - 2) * (this.avatarHeight + selectWrapLayout.spacingY) + this.avatarHeight / 2 + selectWrapLayout.spacingY : 0);
        if (curHeight < this.view.RC_scroll_mainView.node.getContentSize().height / 2) {
            this.view.RC_scroll_mainView.scrollToOffset(cc.v2(0, 0), 1);
        } else if (curHeight > selectWrapSize.height - this.view.RC_scroll_mainView.node.getContentSize().height / 2) {
            this.view.RC_scroll_mainView.scrollToOffset(cc.v2(0, maxScrollOffset.y), 1);
        } else {
            this.view.RC_scroll_mainView.scrollToOffset(cc.v2(0, curHeight - this.view.RC_scroll_mainView.node.getContentSize().height / 2), 1);
        }
    }

    private clickItem(index) {
        let arr = this.view.RC_scroll_mainView.content.children;
        if (arr) {
            if (arr[this.checkIndex] && arr[this.checkIndex].getComponent(UserCenterSelectAvatarItem_v)) {
                arr[this.checkIndex].getComponent(UserCenterSelectAvatarItem_v).setItemSelect(false);
            }
            if (arr[index] && arr[index].getComponent(UserCenterSelectAvatarItem_v)) {
                arr[index].getComponent(UserCenterSelectAvatarItem_v).setItemSelect();
            }
        }

        this.checkIndex = index;
        this.tempUserNickName = we.common.userMgr.userInfo.userName;
    }

    public onClickConfirm(): void {
        let canIn = true;
        if (this.tempUserNickName == '') {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.USERCENTER_NICKNAMEERROR));
            canIn = false;
        } else if (we.common.utils.getWordLength(this.tempUserNickName) > 18) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.USERCENTER_NICKNAMEERROR2));
            canIn = false;
        }
        if (!canIn && this.userEditText) {
            this.view.RC_edit_modifyNickName.string = we.common.userMgr.userInfo.userName;
            this.tempUserNickName = we.common.userMgr.userInfo.userName;
            return;
        }

        let uname = this.view.RC_edit_modifyNickName.string;
        let infoData = {} as ApiProto.ModifyUserReq;

        we.common.userMgr.userInfo.avatar = this.AvatarArr[this.checkIndex];
        infoData.avatar = we.common.userMgr.userInfo.avatar;
        infoData.userName = uname.trim();

        we.common.userMgr.updateChangeUserInfo(
            infoData,
            (data: ApiProto.ModifyUserResp) => {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_TIPS_MODIFY_SUCCESS));
                we.common.userMgr.refreshUserInfo();
                this.closeView();
            },
            (code) => {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.COMMON_TIPS_MODIFY_FAILURE));
            }
        );
    }

    /**
     * 监听输入框输入完成
     */
    private onNickNameChanged(): void {
        let uname = this.view.RC_edit_modifyNickName.string;
        if (uname == '') {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.USERCENTER_NICKNAMEERROR));
            this.view.RC_edit_modifyNickName.string = we.common.userMgr.userInfo.userName;
        } else if (we.common.utils.getWordLength(uname) > 18) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.USERCENTER_NICKNAMEERROR2));
            this.view.RC_edit_modifyNickName.string = we.common.userMgr.userInfo.userName;
        }
        this.view.RC_edit_modifyNickName.string = uname.trim();
    }

    /**
     * 监听输入框文字改变
     */
    private onNickEditBoxTextChanged(): void {
        this.userEditText = true;
        // 英文18个，中文9个
        let strIn = this.view.RC_edit_modifyNickName.string;
        let strOut = '';
        let byteCount = 0;
        for (let i = 0; i < strIn.length; i++) {
            let c = strIn.charAt(i);
            if (we.common.utils.isSingleByte(c)) {
                byteCount += 1;
            } else {
                byteCount += 2;
            }

            if (byteCount > 18) {
                break;
            }
            strOut += c;
        }

        this.view.RC_edit_modifyNickName.string = strOut;
        this.tempUserNickName = strOut;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(UserCenterSelectAvatarDlg_v, `${HallViewId.UserCenterSelectAvatarDlg}_v`)
class UserCenterSelectAvatarDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(UserCenterSelectAvatarDlg_v, uiBase.addComponent(UserCenterSelectAvatarDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterSelectAvatarDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<UserCenterSelectAvatarDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(UserCenterSelectAvatarDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(UserCenterSelectAvatarDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(UserCenterSelectAvatarDlg_v).beforeUnload();
    }
}
