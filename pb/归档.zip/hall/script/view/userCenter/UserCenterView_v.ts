import { HallRes } from '../../config/HallRes';
import { HallPageEnum } from '../../const/HallConst';
import HallMgr from '../../manager/HallMgr';
import JumpModMgr from '../../manager/JumpModMgr';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class UserCenterView_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_userGold: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_delegate: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_member: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rebate: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_redeem: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_service: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_store: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_vip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_withdraw: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private vip_notice: cc.Node;
    private service_notice: cc.Node;
    private event_notice: cc.Node;
    private delegate_btn_notice: cc.Node;

    private mail_tips: cc.Node;
    private service_tips: cc.Node;

    private emailCount = 0;

    protected onLoad(): void {
        this.onBtnClick(this.RCN_vip, this.onClickVip).setSleepTime(1.5);
        this.onBtnClick(this.RCN_service, this.onClickService).setSleepTime(1.5);
        this.onBtnClick(this.RCN_mail, this.onClickMail).setSleepTime(1.5);
        this.onBtnClick(this.RCN_rebate, this.onClickRebate).setSleepTime(1.5);
        this.onBtnClick(this.RCN_delegate, this.onClickDelegate).setSleepTime(1.5);
        this.onBtnClick(this.RCN_withdraw, this.showWithdraw).setSleepTime(1.5);
        this.onBtnClick(this.RCN_store, this.showTopShop).setSleepTime(1.5);
        this.onBtnClick(this.RCN_redeem, this.showRedeem).setSleepTime(1.5);
        this.onBtnClick(this.RCN_member, this.showMember).setSleepTime(1.5);

        this.vip_notice = this.RCN_vip.getChildByName('notice');
        this.service_notice = this.RCN_service.getChildByName('notice');
        this.event_notice = this.RCN_rebate.getChildByName('notice');
        this.delegate_btn_notice = this.RCN_delegate.getChildByName('notice');

        this.mail_tips = this.RCN_mail.getChildByName('tips');
        this.service_tips = this.RCN_service.getChildByName('tips');

        cc.director.on(we.common.EventName.NOTICE_NEW_CUSTOMER, this.onNoticeCustomerService, this); // 客服红点通知
        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);

        this.emailCount = we.common.redDot.red.getRedDotCnt(we.common.redDot.cfg.mail);
        this.bindRedDot();
    }

    protected start(): void {
        this.onUpdateUserInfo();
    }

    protected onEnable(): void {
        this.RCN_withdraw.active = we.common.withdrawMgr.judgeIsShowWithdraw();
        this.RCN_rebate.active = we.core.projectConfig.settingsConfig?.userRebateSwitch;
        this.RCN_delegate.active = we.core.projectConfig.settingsConfig?.funcSwitch?.agentSwitch;
    }

    protected onDestroy(): void {
        cc.director.off(we.common.EventName.NOTICE_NEW_CUSTOMER, this.onNoticeCustomerService, this); // 客服红点通知
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);
    }

    private onUpdateUserInfo(): void {
        if (!cc.isValid(this.node)) {
            return;
        }
        const coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
        this.RC_lab_userGold.string = we.common.utils.formatAmountCurrency(coin);
    }

    // 跳转提现
    private showWithdraw() {
        HallMgr.openWithdraw();
    }

    // 跳转充值
    private showTopShop() {
        we.currentUI.getDlg(HallViewId.HallDlg).onShow(HallPageEnum.shop);
    }

    private showRedeem() {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Gift_Code);
    }

    private showMember() {
        we.currentUI.show(HallViewId.MemberCenterDlg);
    }

    private onClickRebate(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Rebate);
    }

    private onClickMail(): void {
        we.currentUI.show(HallViewId.MailDlg);
    }

    private onClickVip(): void {
        we.currentUI.show(HallViewId.VipViewDlg);
    }

    private onClickService(): void {
        we.common.commonMgr.openCustomerDialog();
    }

    private onClickDelegate(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Agent);
    }

    // 绑定红点信息
    private bindRedDot() {
        // 客服红点
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.server, node: this.service_notice.getChildByName('notice') });

        // 邮件红点
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.mail, node: this.RCN_mail.getChildByName('notice'), callback: this.onNoticeMail.bind(this) });

        // 打码返利红点
        we.common.redDot.red.appendVRedDotNode(this.event_notice).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.rebateCode, node: notice });
        });

        // 代理红点
        we.common.redDot.red.appendVRedDotNode(this.delegate_btn_notice).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.agent, node: notice });
        });

        // vip红点
        we.common.redDot.red.appendVRedDotNode(this.vip_notice).then((notice) => {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vip, node: notice });
            const birthAwardStatus = we.common.VIPConfig.vipAwardStatus.data?.birthAwardStatus;
            if (birthAwardStatus === we.common.VIPConfig.VipAwardStatus.CAN_RECEIVE) {
                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.vipBirthdayAward, 1, true);
            }
            const vipSalary = we.common.VIPConfig.vipAwardStatus.data?.vipSalary || {};
            for (const key in vipSalary) {
                if (vipSalary[key] === we.common.VIPConfig.VipAwardStatus.CAN_RECEIVE) {
                    we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.vipSalary, 1);
                }
            }
        });
    }

    /** 邮件红点 设置 */
    private onNoticeMail(amount: number, info: any): void {
        if (!cc.isValid(this.mail_tips)) {
            return;
        }

        if (amount <= 0) {
            this.mail_tips.active = false;
            this.emailCount = 0;
            return;
        }

        if (this.emailCount >= amount) {
            this.emailCount = amount;
            return;
        }
        this.emailCount = amount;

        we.core.audioMgr.playEffect(HallRes.audio.ding);

        // 防抖
        if (we.core.utils.isQuickClick(this.mail_tips.uuid, 11000)) {
            return;
        }

        // anim
        this.mail_tips.active = true;
        this.mail_tips.stopAllActions();
        this.tween(this.mail_tips).set({ scale: 0, opacity: 1 }).show().to(0.4, { scale: 1, opacity: 255 }, { easing: 'sineIn' }).delay(10).to(0.2, { scale: 0, opacity: 1 }, { easing: 'sineOut' }).hide().start();
    }

    /** 客服红点 */
    private onNoticeCustomerService(): void {
        if (!cc.isValid(this.node)) {
            return;
        }

        let isNewMsg = we.common.storage.get('common', 'customer');
        if (isNewMsg) {
            this.service_tips.active = true;
            this.service_tips.stopAllActions();
            this.service_tips.scale = 0;
            this.service_tips.opacity = 0;
            this.tween(this.service_tips).to(0.4, { scale: 1, opacity: 255 }, { easing: 'sineInOut' }).start();
        } else {
            this.service_tips.active = false;
        }
    }
}
