import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('PWAInstallGuideDlgView_h', we.bundles.hall)
class PWAInstallGuideDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnCopy: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_url: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_animRoot: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('PWAInstallGuideDlg_h', we.bundles.hall)
export class PWAInstallGuideDlg_h extends we.ui.DlgSystem<PWAInstallGuideDlgView_h> {
    private playAnimIng: boolean = false;
    private url: string = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RCN_animRoot.setPosition(0, -this.view.RCN_animRoot.height);

        this.view.cc_onBtnClick(this.view.RC_content, we.core.Func.create(this.onClickClose, this));
        this.view.cc_onBtnClick(this.view.RC_btnCopy, we.core.Func.create(this.onClickCopy, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.url = we.core.projectConfig.settingsConfig?.pwaUrl || '';
        if (!this.url) {
            we.error(`PWAInstallGuide_h onShow, pwaFailUrl is null`);
        }
        this.view.RC_lab_url.string = this.url;

        this.playAnim(false);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onClickClose(): void {
        this.playAnim(true);
    }

    private onClickCopy(): void {
        let url = we.common.downloadGuideMgr.getPWAInstallUrl();

        we.core.nativeUtil.copyText(url);
        we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.COMMON_COPY_COMPLETE));
    }

    private playAnim(isClose: boolean): void {
        if (this.playAnimIng) {
            return;
        }
        this.playAnimIng = true;

        this.view.RCN_animRoot.stopAllActions();
        let y = this.view.RCN_animRoot.height;
        this.view.RCN_animRoot.setPosition(0, isClose ? 0 : -y);

        this.tween(this.view.RCN_animRoot)
            .to(0.2, { position: cc.v2(0, isClose ? -y : 0) })
            .call(() => {
                if (cc.isValid(this.view.uiRoot)) {
                    if (isClose) {
                        this.closeView();
                    }

                    this.playAnimIng = false;
                }
            })
            .start();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(PWAInstallGuideDlg_h, `${HallViewId.PWAInstallGuideDlg}_h`)
class PWAInstallGuideDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Top;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(PWAInstallGuideDlg_h, uiBase.addComponent(PWAInstallGuideDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PWAInstallGuideDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<PWAInstallGuideDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(PWAInstallGuideDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PWAInstallGuideDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(PWAInstallGuideDlg_h).beforeUnload();
    }
}
