import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AddIconGuideTipDlgView_v', we.bundles.hall)
class AddIconGuideTipDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WEPageView)
    public RC_banner: we.ui.WEPageView = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tip0_1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tip0_2: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_page: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AddIconGuideTipDlg_v', we.bundles.hall)
export class AddIconGuideTipDlg_v extends we.ui.DlgSystem<AddIconGuideTipDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        let tip2Arr: string[] = we.core.langMgr.getLangText(HallLanguage.IOS_BOOKMARK_TABLE_TIPS3).split('\\n');
        this.view.RC_lab_tip0_1.string = tip2Arr[0] + ' ';
        this.view.RC_lab_tip0_2.string = ' ' + tip2Arr[1];

        this.onUpdateBanner();
        this.view.RC_banner.autoLoop(6);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onUpdateBanner() {
        if (!cc.isValid(this.view.RC_banner)) {
            return;
        }

        this.view.RC_banner.setRender(we.core.Func.create(this.onRenderBanner, this));
        this.view.RC_banner.totalPage = 4;
        this.view.RC_banner.jumpToPage(0);
    }

    private onRenderBanner(item: cc.Node, idx: number) {
        const page = this.view.RCN_page.getChildByName(`page_${idx}`);
        item.removeAllChildren();
        if (page) {
            const node = cc.instantiate(page);
            node.parent = item;
            node.setPosition(0, 0);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AddIconGuideTipDlg_v, `${HallViewId.AddIconGuideTipDlg}_v`)
class AddIconGuideTipDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AddIconGuideTipDlg_v, uiBase.addComponent(AddIconGuideTipDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AddIconGuideTipDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AddIconGuideTipDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(AddIconGuideTipDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AddIconGuideTipDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AddIconGuideTipDlg_v).beforeUnload();
    }
}
