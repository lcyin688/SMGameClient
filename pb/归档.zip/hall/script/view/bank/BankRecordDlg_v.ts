import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import BankRecordItem_v from './BankRecordItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('BankRecordDlgView_v', we.bundles.hall)
class BankRecordDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_tips: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_noData: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_tipsBg: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('BankRecordDlg_v', we.bundles.hall)
export class BankRecordDlg_v extends we.ui.DlgSystem<BankRecordDlgView_v> {
    private recordList: ApiProto.BankRecord[] = [];

    /** 当前menu */
    private curMenuIdx: number = 0;

    /** all是否有数据, 如果all没有数据，其他也不会请求 */
    private isAllData: boolean = true;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.initList();
        this.initMenu();

        this.view.RCN_noData.active = false;
        this.view.RCN_tipsBg.active = false;

        this.curMenuIdx = 0;
        this.isAllData = true;

        this.view.cc_onBtnClick(this.view.RCN_close, we.core.Func.create(this.closeView, this));
        this.view.cc_onScrollViewEvent(this.view.RC_list.scrollView.node, 'scrolling', we.core.Func.create(this.onScrolling, this));

        cc.director.on(we.core.EventName.FULL_TOUCH_START, this.onFullTouchStart, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_menu.onSwitchMenu(this.curMenuIdx, true);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(we.core.EventName.FULL_TOUCH_START, this.onFullTouchStart, this);
    }

    private initList(): void {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
    }

    private initMenu(): void {
        this.view.RC_menu.setMenuStateByNodeName('select', 'unselect');
        this.view.RC_menu.onSelected = (node: cc.Node, i: number) => {
            this.onSelectedIndex(i);
        };
    }

    private clearList(): void {
        this.view.RC_list.scrollView.stopAutoScroll();
        this.view.RC_list.numItems = 0;
        this.view.RC_list.scrollTo(0, 0);
    }

    private getRecordData(eventType: string): void {
        // 获取缓存数据
        let recordData = we.common.bankMgr.getLocalRecordData(eventType);
        if (recordData) {
            this.setRecordData(eventType, recordData);
            return;
        }

        if (eventType != we.common.BankRecordEventType.all && !this.isAllData) {
            this.view.RCN_noData.active = true;
            return;
        }

        let param: ApiProto.BankRecordReq = {
            eventType: eventType,
        };
        we.common.bankMgr.getBankRecord(param, (data: ApiProto.BankRecordResp) => {
            // 设置缓存数据
            we.common.bankMgr.setLocalRecordData(eventType, data?.records);

            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }

            let recordData = data?.records || [];
            this.setRecordData(eventType, recordData);
        });
    }

    private setRecordData(eventType: string, recordData: ApiProto.BankRecord[]): void {
        const curEventType = this.getEventType(this.curMenuIdx);
        if (eventType != curEventType) {
            return;
        }

        this.recordList = recordData;
        if (eventType == we.common.BankRecordEventType.all) {
            this.isAllData = this.recordList.length > 0;
        }
        this.view.RCN_noData.active = this.recordList.length <= 0;
        this.addRecordItem();
    }

    private addRecordItem(): void {
        this.view.RC_list.numItems = this.recordList.length;
    }

    private onRenderEvent(item: cc.Node, i: number): void {
        const record: ApiProto.BankRecord = this.recordList[i];
        let recordItem = item.getComponent(BankRecordItem_v);
        recordItem?.init(record, (interestNode: cc.Node) => {
            this.showTips(interestNode, record);
        });
    }

    private onSelectedIndex(i: number) {
        this.curMenuIdx = i;
        this.clearList();
        this.view.RCN_noData.active = false;
        this.view.RCN_tipsBg.active = false;
        const curEventType = this.getEventType(i);
        this.getRecordData(curEventType);
    }

    private getEventType(menuIdx: number): string {
        let curEventType = we.common.BankRecordEventType.all;
        switch (menuIdx) {
            case 0:
                curEventType = we.common.BankRecordEventType.all;
                break;
            case 1:
                curEventType = we.common.BankRecordEventType.interest;
                break;
            case 2:
                curEventType = we.common.BankRecordEventType.stockIn;
                break;
            case 3:
                curEventType = we.common.BankRecordEventType.stockOut;
                break;
            default:
                break;
        }

        return curEventType;
    }

    // 显示提示
    private showTips(interest: cc.Node, record: ApiProto.BankRecord): void {
        // 如果提示背景无效，则返回
        if (!cc.isValid(this.view.RCN_tipsBg)) {
            return;
        }

        // 如果列表正在滚动或自动滚动，则返回
        if (this.view.RC_list.scrollView.isScrolling() || this.view.RC_list.scrollView.isAutoScrolling()) {
            return;
        }

        // 如果事件类型不是利息，则返回
        if (record.eventType != we.common.BankRecordEventType.interest) {
            return;
        }

        // 如果当前余额和利率无效，则返回
        if (!(record.currentBalance && record.interestRate)) {
            return;
        }

        // 显示提示背景
        this.view.RCN_tipsBg.active = true;

        // 获取tips动态坐标
        let interestPos = interest.convertToWorldSpaceAR(cc.v2(0, 0));
        // 转换坐标系
        let tipsPos = this.view.RCN_tipsBg.parent.convertToNodeSpaceAR(interestPos);

        this.view.RCN_tipsBg.setPosition(tipsPos);

        this.view.RC_rich_tips.setStringFormat(we.core.langMgr.getLangText(HallLanguage.BANK_RECORD_10), we.common.utils.formatAmountCurrency(record.currentBalance), `${record.interestRate}%`);
    }

    private onFullTouchStart(e: cc.Touch): void {
        const startPosition = e.getLocation();
        if (this.view.RCN_tipsBg.active) {
            const worldBoundingBox = this.view.RCN_tipsBg.getBoundingBoxToWorld();
            if (!(startPosition instanceof cc.Vec2) || !(worldBoundingBox instanceof cc.Rect)) {
                return;
            }
            if (worldBoundingBox.contains(startPosition)) {
                return;
            }

            this.view.RCN_tipsBg.active = false;
        }
    }

    private onScrolling(): void {
        if (this.view.RCN_tipsBg.active) {
            this.view.RCN_tipsBg.active = false;
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(BankRecordDlg_v, `${HallViewId.BankRecordDlg}_v`)
class BankRecordDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(BankRecordDlg_v, uiBase.addComponent(BankRecordDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankRecordDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<BankRecordDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(BankRecordDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankRecordDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(BankRecordDlg_v).beforeUnload();
    }
}
