import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('BankDlgView_v', we.bundles.hall)
class BankDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnDeposit: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnMax: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnMin: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRateRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecord: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTakeOut: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_amount: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bankBalance: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_lastIncome: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_rate: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_totalIncome: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vipLevel: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vipRate: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_yesterdayIncome: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vipIcon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_all: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_maintainMask: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('BankDlg_v', we.bundles.hall)
export class BankDlg_v extends we.ui.DlgSystem<BankDlgView_v> {
    /** 是否在维护 */
    private isMaintain: boolean = false;
    /** 最小存入金额, 服务器值 */
    private minDepositAmount: number = 0;
    /** 是否产生利息 */
    private interestSwitch: boolean = false;
    /** 存/取 金额, 修改时需转换为服务器值 */
    private editAmount: number = 0;
    /** 存/取 是否为最大值 */
    private isMaxAmount: boolean = false;
    /** 银行余额 */
    private bankBalance: number = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.isMaintain = false;
        this.view.RCN_maintainMask.active = this.isMaintain;
        // 输入框
        this.setEditBoxAmount();

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnRule, we.core.Func.create(this.onClickRule, this));
        this.view.cc_onBtnClick(this.view.RC_btnRecord, we.core.Func.create(this.onClickRecord, this));
        this.view.cc_onBtnClick(this.view.RC_btnRateRule, we.core.Func.create(this.onClickRateRule, this));
        this.view.cc_onBtnClick(this.view.RC_btnMax, we.core.Func.create(this.onClickMax, this));
        this.view.cc_onBtnClick(this.view.RC_btnMin, we.core.Func.create(this.onClickMin, this));
        this.view.cc_onBtnClick(this.view.RC_btnTakeOut, we.core.Func.create(this.onClickTakeOut, this)).setSleepTime(0);
        this.view.cc_onBtnClick(this.view.RC_btnDeposit, we.core.Func.create(this.onClickDeposit, this)).setSleepTime(0);

        this.view.cc_onEditBoxEvent(this.view.RC_edit_amount.node, 'editingDidBegan', we.core.Func.create(this.onEditingDidBegan, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_amount.node, 'editingDidEnded', we.core.Func.create(this.onEditingDidEnded, this));

        cc.director.on(we.common.EventName.VIP_EXP_CHANGE, this.onRefreshVipLevel, this);
        cc.director.on(we.common.EventName.UPDATE_BANK, this.onRefreshConfig, this);
        cc.director.on(we.common.EventName.UPDATE_BANK_INFO, this.onRefreshInfo, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        we.common.bankMgr.getBankConf(true);
        we.common.bankMgr.getBankInfo(true);
        this.initUI();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(we.common.EventName.VIP_EXP_CHANGE, this.onRefreshVipLevel, this);
        cc.director.off(we.common.EventName.UPDATE_BANK, this.onRefreshConfig, this);
        cc.director.off(we.common.EventName.UPDATE_BANK_INFO, this.onRefreshInfo, this);
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Bank);
    }

    private initUI(): void {
        this.onRefreshConfig(false);
        this.onRefreshVipLevel();
        this.onRefreshInfo();
    }

    /**
     * 刷新银行配置
     * @param interestTips 是否展示 不产生利息 提示
     * @returns
     */
    private onRefreshConfig(interestTips: boolean = true): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        let bankConfig = we.common.bankMgr.bankConfig?.data;
        if (!bankConfig) {
            return;
        }

        // 维护
        this.isMaintain = bankConfig.maintenanceSwitch;
        this.view.RCN_maintainMask.active = this.isMaintain;

        // 最小存入金额
        this.minDepositAmount = bankConfig.minStockInAmount ?? 0;

        // 是否产生利息
        this.interestSwitch = bankConfig.interestSwitch;
        if (!this.interestSwitch && interestTips) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_7));
        }
    }

    private onRefreshVipLevel(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        // vip等级与利率
        let vipLevel = we.common.userMgr.vipExp.level ?? 0;
        we.common.utils.setComponentSprite(this.view.RC_spr_vipIcon, HallRes.texture.VIP_Logo_icon + vipLevel);
        this.view.RC_lab_vipLevel.string = `VIP ${vipLevel}`;

        let vipRate = we.common.bankMgr.getVipRate(vipLevel);
        this.view.RC_lab_rate.string = `${vipRate}%`;
        this.view.RC_lab_vipRate.string = `${vipRate}%`;
    }

    private onRefreshInfo(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        let bankInfo = we.common.bankMgr.bankInfo;
        if (!bankInfo) {
            return;
        }

        // 银行余额
        let bankBalance = bankInfo.balance > 0 ? bankInfo.balance : 0;
        this.bankBalance = bankBalance;
        this.view.RC_lab_bankBalance.string = we.common.utils.formatAmountCurrency(bankBalance);

        // 收入
        this.view.RC_lab_lastIncome.string = we.common.utils.formatAmountCurrency(bankInfo.lastInterest);
        this.view.RC_lab_yesterdayIncome.string = we.common.utils.formatAmountCurrency(bankInfo.yesterdayInterest);
        this.view.RC_lab_totalIncome.string = we.common.utils.formatAmountCurrency(bankInfo.totalInterest);
    }

    private onRefreshUI() {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        this.initUI();
    }

    private onClickRule(): void {
        we.currentUI.show(HallViewId.BankRuleDlg);
    }

    private onClickRecord(): void {
        if (this.isMaintain) {
            return;
        }

        we.currentUI.showSafe(HallViewId.BankRecordDlg);
    }

    private onClickRateRule(): void {
        if (this.isMaintain) {
            return;
        }

        we.currentUI.showSafe(HallViewId.BankRateRuleDlg);
    }

    private onClickMax(): void {
        if (this.isMaintain) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HALL_13));
            return;
        }

        this.setMaxStatus(true);
    }

    private onClickMin(): void {
        if (this.isMaintain) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HALL_13));
            return;
        }

        this.setEditBoxAmount(this.minDepositAmount);
    }

    /**
     * 提取
     * @returns
     */
    private onClickTakeOut(): void {
        if (this.isMaintain) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HALL_13));
            return;
        }

        if (we.core.utils.isQuickClick(we.common.bankMgr.quickClickTag, we.common.bankMgr.quickClickTiem)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_6));
            return;
        }

        let takeOutAmount = 0;
        if (this.isMaxAmount || this.editAmount > this.bankBalance) {
            if (this.bankBalance <= 0) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HALL_15));
                return;
            }

            takeOutAmount = this.bankBalance;
        } else {
            takeOutAmount = this.editAmount;
        }

        if (takeOutAmount <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HALL_14));
            return;
        }

        // 输入框重置
        this.setEditBoxAmount();

        let param: ApiProto.BankStockOutReq = {
            amount: takeOutAmount,
        };
        we.common.bankMgr.bankStockOut(param, (data: ApiProto.BankStockOutResp) => {
            if (!we.common.userMgr.isLogin()) {
                return;
            }

            // 10: 成功 20: 失败
            if (data.code == we.common.BankStockCode.success) {
                we.common.userMgr.userInfo.gold = we.common.userMgr.userInfo.gold + takeOutAmount;
                cc.director.emit(we.common.EventName.UPDATE_GOLD_SHOW);
                let bankInfo = we.common.bankMgr.bankInfo;
                if (bankInfo) {
                    bankInfo.balance = bankInfo.balance - takeOutAmount;
                }

                we.common.userMgr.onSyncUserCoinInfo();
                we.common.bankMgr.getBankInfo();
                we.common.bankMgr.clearRecordData();

                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_4));

                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }

                this.onRefreshUI();
            } else {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_5));
            }
        });
    }

    /**
     * 存入
     * @returns
     */
    private onClickDeposit(): void {
        if (this.isMaintain) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HALL_13));
            return;
        }

        if (we.core.utils.isQuickClick(we.common.bankMgr.quickClickTag, we.common.bankMgr.quickClickTiem)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_6));
            return;
        }

        let userGold = we.common.userMgr.userInfo.gold;
        // id取整
        if (we.core.flavor.getCountryCode() === we.core.CountryCode.id) {
            userGold = Math.floor(userGold / we.core.flavor.getAmountPrecision()) * we.core.flavor.getAmountPrecision();
        }

        let depositAmount = 0;
        if (this.isMaxAmount || this.editAmount > userGold) {
            depositAmount = userGold;
        } else {
            depositAmount = this.editAmount;

            if (depositAmount <= 0) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HALL_14));
                return;
            }
        }

        if (depositAmount < this.minDepositAmount) {
            const option: we.ui.type.ConfirmPopupOptions = {
                content: we.core.langMgr.getLangText(HallLanguage.BANK_HINT_1, we.common.utils.formatAmountCurrency(this.minDepositAmount)),
                yesButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CONFIRM),
            };
            we.commonUI.showConfirm(option);
            return;
        }

        HallMgr.getOngoingGame(() => {
            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }

            this.bankStockIn(depositAmount);
        });
    }

    /**
     * 存入，调用之前保证金额已处理
     * @param depositAmount 存入金额
     */
    private bankStockIn(depositAmount: number): void {
        // 输入框重置
        this.setEditBoxAmount();

        let param: ApiProto.BankStockInReq = {
            amount: depositAmount,
        };
        we.common.bankMgr.bankStockIn(param, (data: ApiProto.BankStockInResp) => {
            if (!we.common.userMgr.isLogin()) {
                return;
            }

            // 10: 成功 20: 失败
            if (data.code == we.common.BankStockCode.success) {
                we.common.userMgr.userInfo.gold = we.common.userMgr.userInfo.gold - depositAmount;
                cc.director.emit(we.common.EventName.UPDATE_GOLD_SHOW);
                let bankInfo = we.common.bankMgr.bankInfo;
                if (bankInfo) {
                    bankInfo.balance = bankInfo.balance + depositAmount;
                }

                we.common.userMgr.onSyncUserCoinInfo();
                we.common.bankMgr.getBankInfo();
                we.common.bankMgr.clearRecordData();

                if (this.interestSwitch) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_2));
                } else {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_7));
                }

                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }

                this.onRefreshUI();
            } else {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.BANK_HINT_3));
            }
        });
    }

    private onEditingDidBegan(): void {
        this.setMaxStatus(false);
        this.view.RC_edit_amount.placeholderLabel.string = '';
    }

    private onEditingDidEnded(): void {
        let content = this.view.RC_edit_amount.string;
        let amount = Number(content) * we.core.flavor.getAmountPrecision();
        if (amount > 0) {
            this.setEditBoxAmount(amount);
        } else {
            this.setEditBoxAmount();
        }
    }

    /**
     * 设置输入框金额
     * @param amount 金额，服务器值
     */
    private setEditBoxAmount(amount: number = 0): void {
        // 输入框只要变化，max状态都为false
        this.setMaxStatus(false);

        // id取整
        if (we.core.flavor.getCountryCode() === we.core.CountryCode.id) {
            amount = Math.floor(amount / we.core.flavor.getAmountPrecision()) * we.core.flavor.getAmountPrecision();
        }

        this.editAmount = amount;
        if (amount <= 0) {
            this.view.RC_edit_amount.string = '';
            this.view.RC_edit_amount.placeholderLabel.string = we.core.langMgr.getLangText(HallLanguage.BANK_HALL_14);
        } else {
            this.view.RC_edit_amount.string = amount / we.core.flavor.getAmountPrecision() + '';
            this.view.RC_edit_amount.textLabel.string = we.common.utils.formatAmountCurrency(amount);
        }
    }

    /**
     * 设置max状态
     * @param isMax 是否max
     */
    private setMaxStatus(isMax: boolean): void {
        this.isMaxAmount = isMax;
        this.view.RCN_all.active = isMax;

        if (isMax) {
            this.view.RC_edit_amount.string = '';
            this.view.RC_edit_amount.placeholderLabel.string = '';
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(BankDlg_v, `${HallViewId.BankDlg}_v`)
class BankDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(BankDlg_v, uiBase.addComponent(BankDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<BankDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(BankDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(BankDlg_v).beforeUnload();
    }
}
