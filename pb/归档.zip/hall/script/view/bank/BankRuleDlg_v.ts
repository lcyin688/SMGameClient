import HallSkin from '../../config/HallSkin';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('BankRuleDlgView_v', we.bundles.hall)
class BankRuleDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_2: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_4: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_5: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_8: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_9: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('BankRuleDlg_v', we.bundles.hall)
export class BankRuleDlg_v extends we.ui.DlgSystem<BankRuleDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RCN_close, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.initTextLang();
    }

    private initTextLang(): void {
        this.view.RC_rich_2.setStringFormat('{0}', we.core.langMgr.getLangText(HallLanguage.BANK_RULE_2_1));
        this.view.RC_rich_2.string = `${this.view.RC_rich_2.string}${we.core.langMgr.getLangText(HallLanguage.BANK_RULE_2_2)}`;

        this.view.RC_rich_4.setStringFormat('{0}', we.core.langMgr.getLangText(HallLanguage.BANK_RULE_4_2));
        this.view.RC_rich_4.string = `${we.core.langMgr.getLangText(HallLanguage.BANK_RULE_4_1)}${this.view.RC_rich_4.string}`;

        this.view.RC_rich_5.setStringFormat('{0}', we.core.langMgr.getLangText(HallLanguage.BANK_RULE_5_1));
        this.view.RC_rich_5.string = `${this.view.RC_rich_5.string}${we.core.langMgr.getLangText(HallLanguage.BANK_RULE_5_2)}`;

        this.view.RC_rich_8.node.active = false;
        let stopInterestDays = we.common.bankMgr.bankConfig?.data?.stopInterestDays;
        if (stopInterestDays > 0) {
            this.view.RC_rich_8.node.active = true;
            this.view.RC_rich_8.setStringFormat(we.core.langMgr.getLangText(HallLanguage.BANK_RULE_8), stopInterestDays);
        }

        this.view.RC_rich_9.node.active = false;
        let minSettableBalance = we.common.bankMgr.bankConfig?.data?.minSettableBalance;
        if (minSettableBalance > 0) {
            this.view.RC_rich_9.node.active = true;
            this.view.RC_rich_9.setStringFormat(we.core.langMgr.getLangText(HallLanguage.BANK_RULE_9), we.common.utils.formatAmountCurrency(minSettableBalance));
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(BankRuleDlg_v, `${HallViewId.BankRuleDlg}_v`)
class BankRuleDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(BankRuleDlg_v, uiBase.addComponent(BankRuleDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankRuleDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<BankRuleDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(BankRuleDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankRuleDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(BankRuleDlg_v).beforeUnload();
    }
}
