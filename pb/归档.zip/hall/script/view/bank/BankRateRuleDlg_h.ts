import { HallViewId } from '../HallViewId';
import BankRateRuleItem_h from './BankRateRuleItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('BankRateRuleDlgView_h', we.bundles.hall)
class BankRateRuleDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('BankRateRuleDlg_h', we.bundles.hall)
export class BankRateRuleDlg_h extends we.ui.DlgSystem<BankRateRuleDlgView_h> {
    private vipRateList: ApiProto.BankVipInterest[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.vipRateList = we.common.bankMgr.getVipRateList();
        this.addVipRateItem();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private addVipRateItem(): void {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list.numItems = this.vipRateList.length;
    }

    private onRenderEvent(item: cc.Node, i: number): void {
        const vipRate: ApiProto.BankVipInterest = this.vipRateList[i];
        let vipRateItem = item.getComponent(BankRateRuleItem_h);
        vipRateItem?.init(vipRate);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(BankRateRuleDlg_h, `${HallViewId.BankRateRuleDlg}_h`)
class BankRateRuleDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(BankRateRuleDlg_h, uiBase.addComponent(BankRateRuleDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankRateRuleDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<BankRateRuleDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(BankRateRuleDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(BankRateRuleDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(BankRateRuleDlg_h).beforeUnload();
    }
}
