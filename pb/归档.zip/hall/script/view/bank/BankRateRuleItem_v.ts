const { ccclass, property } = cc._decorator;

@ccclass
export default class BankRateRuleItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_rate: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vipLevel: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(vipRate: ApiProto.BankVipInterest): void {
        this.__initRc();

        let vipLevel = vipRate.vipLevel ?? 0;
        this.RC_lab_vipLevel.string = `${vipLevel}`;

        let rate = vipRate.interestRate ?? 0;
        this.RC_lab_rate.string = `${rate}%`;
    }
}
