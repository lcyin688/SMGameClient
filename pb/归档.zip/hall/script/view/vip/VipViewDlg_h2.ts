import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import VipBarItem_h from './VipBarItem_h';
import VipRightsItem_h from './VipRightsItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('VipViewDlgView_h2', we.bundles.hall)
class VipViewDlgView_h2 extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.ProgressBar)
    public RC_bar_vipProgressBar: cc.ProgressBar = null;

    @we.ui.ccBind(cc.Node)
    public RC_barLayout: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_barPointer: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnCoinAdd: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoGame1: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoGame2: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoRecharge1: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoRecharge2: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnLeft: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRight: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_barXp: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_coin: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vipLevel: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_lockMask: cc.Node = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_lockMask1: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_lockMask2: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_vipUpTip: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RC_rightsLayout: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vipIcon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('VipViewDlg_h2', we.bundles.hall)
export class VipViewDlg_h2 extends we.ui.DlgSystem<VipViewDlgView_h2> {
    /** 当前选中的VIP等级 */
    private curSelectLevel = 0;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoGame1, we.core.Func.create(this.onClickGoGame, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoGame2, we.core.Func.create(this.onClickGoGame, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoRecharge1, we.core.Func.create(this.onClickRecharge, this));
        this.view.cc_onBtnClick(this.view.RC_btnGoRecharge2, we.core.Func.create(this.onClickRecharge, this));
        this.view.cc_onBtnClick(this.view.RC_btnCoinAdd, we.core.Func.create(this.onClickRecharge, this));
        this.view.cc_onBtnClick(this.view.RC_btnLeft, we.core.Func.create(this.onChangeCurrentLevel, this, -1)).setSleepTime(0.1);
        this.view.cc_onBtnClick(this.view.RC_btnRight, we.core.Func.create(this.onChangeCurrentLevel, this, 1)).setSleepTime(0.1);

        cc.director.on(we.common.EventName.VIP_EXP_CHANGE, this.initUI, this);
        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.initUI, this);
        cc.director.on(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lockMask.active = false;
        this.initUI();

        // 拉取最新数据
        we.common.VIPConfig.init(() => {
            if (!this.isValid()) {
                return;
            }
            this.initUI();
        });
    }

    /** 隐藏窗口 */
    public destroy() {
        cc.director.off(we.common.EventName.VIP_EXP_CHANGE, this.initUI, this);
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.initUI, this);
        cc.director.off(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
    }

    public beforeUnload() {}

    private async initUI() {
        this.curSelectLevel = 0;
        if (!we.common.VIPConfig.vipLevelConfig?.length) {
            return;
        }
        await this.renderLevelProgressBar();
        this.renderUI();
    }

    private renderUI() {
        // 金币数量
        this.view.RC_lab_coin.string = we.common.utils.formatAmountCurrency(we.common.userMgr.userInfo.gold);

        // 设置进度条
        let progress = 0;
        const vipExp = we.common.userMgr.vipExp;
        const totalLevel = we.common.VIPConfig.spe_user_vip_limit;
        const currVip = we.common.VIPConfig.vipLevelConfig[vipExp.level];
        const nextVip = we.common.VIPConfig.vipLevelConfig[vipExp.level + 1];
        if (vipExp.level < totalLevel) {
            const part = 1 / totalLevel || 0;
            progress = part * vipExp.level;
            let diffExp = vipExp.exp - currVip.minBetAmount;
            if (diffExp < 0) {
                diffExp = 0;
            }
            const diffBet = nextVip.minBetAmount - currVip.minBetAmount;
            const partProgress = part * (diffExp / diffBet);
            progress += partProgress > part ? part : partProgress;

            // 设置指针位置
            const x = this.view.RC_barLayout.width * progress;
            this.view.RC_barPointer.setPosition(x, this.view.RC_barPointer.y);
            this.view.RC_barPointer.active = true;
            // 设置升级文本
            const amount = nextVip.minBetAmount - vipExp.exp;
            if (amount <= 0) {
                // 后台修改经验值异常情况的特殊处理
                if (we.common.VIPConfig.experienceType === 0) {
                    this.view.RC_rich_vipUpTip.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_049));
                } else if (we.common.VIPConfig.experienceType === 1) {
                    this.view.RC_rich_vipUpTip.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_048));
                }
            } else {
                const amountStr = we.common.utils.formatAmount(amount, false);
                const langText = we.core.langMgr.getLangText(we.common.VIPConfig.experienceType ? HallLanguage.NEW_VIP_DESC_001_2 : HallLanguage.NEW_VIP_DESC_001_1);
                this.view.RC_rich_vipUpTip.setStringFormat(langText, amountStr, ` ${we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_001_3, vipExp.level + 1)}`);
            }
        } else {
            progress = 1;
            this.view.RC_barPointer.active = false;
            this.view.RC_rich_vipUpTip.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_002);
        }

        // 设置经验
        this.view.RC_bar_vipProgressBar.progress = progress;
        this.view.RC_lab_barXp.string = we.common.utils.formatAmount(vipExp.exp, false);

        this.view.RC_btnGoGame1.active = we.common.VIPConfig.experienceType === 0;
        this.view.RC_btnGoRecharge1.active = we.common.VIPConfig.experienceType === 1;

        // 设置vip图标
        we.common.utils.setComponentSprite(this.view.RC_spr_vipIcon, HallRes.texture.VIP_Logo_icon + vipExp.level);
        this.view.RC_lab_vipLevel.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_003, vipExp.level);

        this.renderLockMask(vipExp.level);
        this.onToggleCurrentLevel(vipExp.level);
    }

    protected async renderLevelProgressBar() {
        const prefab = await this.loadAsset(HallRes.prefab.vip.VipBarItem, cc.Prefab);
        const itemSize = new cc.Size(0, 0);
        const len = we.common.VIPConfig.vipLevelConfig.length;
        const toggleGroup = this.view.RC_barLayout.addComponentUnique(we.ui.WEToggleGroup);
        let spacing = 0;

        for (let i = 0; i < len; i++) {
            if (toggleGroup.toggles[i]) {
                continue;
            }
            const node = cc.instantiate(prefab);
            const item = node.addComponentUnique(VipBarItem_h);
            item.init(i);

            toggleGroup.addToggle(node.addComponentUnique(we.ui.WEToggle));
            node.setPosition((itemSize.width + spacing) * i, 0);
            this.view.RC_barLayout.addChild(node);

            if (i == 0) {
                itemSize.width = node.width;
                itemSize.height = node.height;
                spacing = (this.view.RC_barLayout.width - itemSize.width * (len - 1)) / (len - 1);
            }
        }

        toggleGroup.setGroupMode(we.ui.ToggleGroupMode.SingleOne);
        toggleGroup.offListener();
        toggleGroup.onListener(
            we.core.Func.create((_: any, _isChecked: boolean, index: number) => {
                this.onToggleCurrentLevel(index);
            }, this)
        );
    }

    protected async renderRightsLayout() {
        const level = this.curSelectLevel <= 0 ? 1 : this.curSelectLevel;
        if (this.view.RC_rightsLayout.children.length === 4) {
            this.view.RC_rightsLayout.children.forEach((child: cc.Node, index: number) => {
                const item = child.addComponentUnique(VipRightsItem_h);
                item.init(index, level);
            });
        } else {
            const prefab = await this.loadAsset(HallRes.prefab.vip.VipRightsItem, cc.Prefab);
            this.view.RC_rightsLayout.removeAllChildren();
            for (let i = 0; i < 4; i++) {
                const node = cc.instantiate(prefab);
                const item = node.addComponentUnique(VipRightsItem_h);
                item.init(i, level);
                this.view.RC_rightsLayout.addChild(node);
            }
        }

        this.view.RC_btnLeft.active = !(this.curSelectLevel <= 0);
        this.view.RC_btnRight.active = !(this.curSelectLevel === we.common.VIPConfig.vipLevelConfig.length - 1);
    }

    protected renderLockMask(level: number) {
        if (level != 0) {
            this.view.RC_lockMask.active = false;
            return;
        }
        this.view.RC_lockMask.active = true;
        let maxSalary = 0;
        const config = we.common.VIPConfig.vipLevelConfig[we.common.VIPConfig.spe_user_vip_limit];
        for (const key in config.vipSalary) {
            maxSalary += config.vipSalary[key] || 0;
        }
        const lockTip1 = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_027);
        this.view.RC_rich_lockMask1.setStringFormat(lockTip1, ` ${we.common.utils.formatAmountCurrency(maxSalary, false)} `);

        if (we.common.VIPConfig.vipLevelConfig?.length > 1) {
            const lockTip2 = we.core.langMgr.getLangText(we.common.VIPConfig.experienceType ? HallLanguage.NEW_VIP_DESC_001_2 : HallLanguage.NEW_VIP_DESC_001_1);
            this.view.RC_rich_lockMask2.setStringFormat(lockTip2, ` ${we.common.utils.formatAmount(we.common.VIPConfig.vipLevelConfig[1].minBetAmount - we.common.userMgr.vipExp?.exp, false)} `, ` VIP1`);
        }
        this.view.RC_btnGoGame2.active = we.common.VIPConfig.experienceType === 0;
        this.view.RC_btnGoRecharge2.active = we.common.VIPConfig.experienceType === 1;
    }

    /**
     * 切换当前显示等级
     */
    protected onToggleCurrentLevel(level: number) {
        if (level >= we.common.VIPConfig.vipLevelConfig.length) {
            level = we.common.VIPConfig.vipLevelConfig.length - 1;
        } else if (level < 0) {
            level = 0;
        }

        if (this.curSelectLevel !== level) {
            const toggleGroup = this.view.RC_barLayout.getComponent(we.ui.WEToggleGroup);
            toggleGroup.setToggleStatus(level, true);
        }

        this.curSelectLevel = level;
        this.renderRightsLayout();
    }

    protected onChangeCurrentLevel(val: 1 | -1) {
        this.onToggleCurrentLevel(this.curSelectLevel + val);
    }

    protected onClickGoGame() {
        HallMgr.openRecentGame(() => {
            if (cc.isValid(this.view.uiRoot)) {
                this.closeView();
            }
        });
    }

    protected onClickRecharge(): void {
        we.common.payMgr.trackFrom = we.common.JumpCmd.Vip;
        HallMgr.openStoreDlg();
    }

    protected coinFlyAnim(params: { node: cc.Node; award: number }): void {
        HallMgr.coinFlyAnim(params, this.view.uiRoot, this.view.RC_lab_coin.node);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(VipViewDlg_h2, `${HallViewId.VipViewDlg}_h2`)
class VipViewDlgHandler_h2 extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(VipViewDlg_h2, uiBase.addComponent(VipViewDlgView_h2));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipViewDlg_h2).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<VipViewDlg_h2['onShow']>): Promise<void> {
        await uiBase.getComponent(VipViewDlg_h2).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipViewDlg_h2).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(VipViewDlg_h2).beforeUnload();
    }
}

we.ui.UIClassFactory.createUIHandler(VipViewDlgHandler_h2, VipViewDlg_h2, `${HallViewId.VipViewDlg}_bg`);
we.ui.UIClassFactory.createUIHandler(VipViewDlgHandler_h2, VipViewDlg_h2, `${HallViewId.VipViewDlg}_ct`);
we.ui.UIClassFactory.createUIHandler(VipViewDlgHandler_h2, VipViewDlg_h2, `${HallViewId.VipViewDlg}_ct2`);
we.ui.UIClassFactory.createUIHandler(VipViewDlgHandler_h2, VipViewDlg_h2, `${HallViewId.VipViewDlg}_ct3`);
