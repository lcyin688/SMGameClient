import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import { VipViewDlg_v } from './VipViewDlg_v';
import VipRightsRowItem_v from './VipRightsRowItem_v';
import HallMgr from '../../manager/HallMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class VipRightsItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_barbette: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_birthdayBtn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_eventMask: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_num: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_text: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_lock: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_maskBox: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_public: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_receiveBtn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_received: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_salary: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_barbette: cc.Sprite = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_reward: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_table: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_timeBox: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_tipsBox: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_tipsBtn: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private renderIndex = 0;
    private currentLevel = 0;
    private renderLevel = 0;

    // 领取回调
    private receiveCallback: () => Promise<number>;

    protected onLoad() {
        this.onBtnClick(this.RC_tipsBtn, we.core.Func.create(this.onClickShowTips, this)).setSleepTime(0);
        this.onBtnClick(this.RC_eventMask, we.core.Func.create(this.onClickShowTips, this)).setSleepTime(0);
        this.onBtnClick(this.RC_birthdayBtn, we.core.Func.create(this.onClickBindBirthday, this));
        this.onBtnClick(this.RC_receiveBtn, we.core.Func.create(this.onClickReceive, this));
    }

    public init(index: number, level = 0, isInit = true) {
        if (!this.isInitRc) {
            this.__initRc();
        }

        this.RC_barbette.active = false;
        this.RC_spr_reward.node.active = false;
        this.RC_tipsBox.active = false;
        this.RC_timeBox.active = false;
        this.RC_salary.active = false;
        this.RC_public.active = false;
        this.RC_receiveBtn.active = false;
        this.RC_birthdayBtn.active = false;
        this.RC_lock.active = false;
        this.RC_lab_text.node.active = false;
        this.RC_received.active = false;
        this.renderIndex = index;
        this.renderLevel = level;
        this.currentLevel = we.common.userMgr.vipExp.level;
        this.initReward();
    }

    protected initReward() {
        const fns = [this.renderBarbette, this.renderBirthday, this.renderUpgrade, this.renderSalary];
        if (fns[this.renderIndex]) {
            fns[this.renderIndex].call(this);
        }
        const salaryIndex = 3;
        this.RC_public.active = !(this.renderIndex === salaryIndex);
        this.RC_salary.active = this.renderIndex === salaryIndex;

        const spriteIndex = this.node.getComponent(we.ui.WESpriteIndex);
        const index = Number(this.renderIndex === salaryIndex);
        if (spriteIndex) {
            spriteIndex.index = index;
        }
    }

    /**
     * 炮台奖励
     */
    protected renderBarbette() {
        this.RC_lab_title.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_008);
        this.RC_lab_tips1.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_007);

        const path = HallRes.texture.prop_equip_big_ + (we.common.userMgr.PropId.FishCannonId + this.renderLevel);
        we.common.utils.setComponentSprite(this.RC_spr_barbette, path);
        this.RC_barbette.active = true;
        this.RC_lab_num.node.active = false;
        this.renderMaskBox(0);
    }
    /**
     * 生日奖励
     */
    protected renderBirthday() {
        this.RC_lab_title.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_010);
        this.RC_lab_tips1.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_011);
        const config = we.common.VIPConfig.vipLevelConfig[this.renderLevel];
        this.RC_lab_num.string = we.common.utils.formatAmountCurrency(config.birthAward, false);

        const spriteIndex = this.RC_spr_reward.getComponent(we.ui.WESpriteIndex);
        if (spriteIndex) {
            spriteIndex.index = 0;
        }
        this.RC_spr_reward.node.active = true;

        if (this.renderLevel > this.currentLevel) {
            this.renderMaskBox(1);
            return;
        }
        this.renderMaskBox(0);
        const birthday = we.common.userMgr.userInfo?.birthday;
        if (birthday) {
            const awardStatus = we.common.VIPConfig.vipAwardStatus.data?.birthAwardStatus;
            if (this.renderLevel === this.currentLevel && awardStatus == we.common.VIPConfig.VipAwardStatus.CAN_RECEIVE) {
                this.RC_receiveBtn.active = true;
                this.RC_timeBox.active = false;

                this.receiveCallback = () => {
                    return new Promise((resolve) => {
                        we.common.VIPConfig.getVipSysAward(
                            { awardType: 1 },
                            (data: ApiProto.ReceiveVipSysRewardResp) => {
                                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.vipBirthdayAward, 0, true);
                                we.common.VIPConfig.vipAwardStatus.data.birthAwardStatus = we.common.VIPConfig.VipAwardStatus.RECEIVED;
                                resolve(data.award);
                            },
                            () => {
                                resolve(0);
                            }
                        );
                    });
                };

                we.common.redDot.red.appendVRedDotNode(this.RC_receiveBtn).then((notice) => {
                    we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vipBirthdayAward, node: notice });
                });
            } else {
                // 显示距离下次生日的天数
                const today = new Date();
                let nextBirthday = we.core.TimeHelper.getPointTimeZero(birthday * 1000).year(today.getFullYear());
                if (nextBirthday.isBefore(today, 'day')) {
                    nextBirthday = nextBirthday.add(1, 'year');
                }
                const diffDay = Math.ceil(nextBirthday.diff(today, 'day', true));
                this.RC_lab_time.string = we.core.langMgr.getLangText(HallLanguage.ITEM_TIME, diffDay);
                this.RC_timeBox.active = diffDay > 0;
                if (diffDay > 0) {
                    this.renderMaskBox(0);
                } else if (this.renderLevel === this.currentLevel) {
                    this.renderMaskBox(2);
                }
            }
        } else {
            // 显示绑定生日按钮
            this.RC_birthdayBtn.active = true;
        }
    }

    /**
     * 升级奖励
     */
    protected renderUpgrade() {
        this.RC_lab_title.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_012);
        this.RC_lab_tips1.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_013);
        const config = we.common.VIPConfig.vipLevelConfig[this.renderLevel];
        this.RC_lab_num.string = we.common.utils.formatAmountCurrency(config.upgradeAward, false);
        const spriteIndex = this.RC_spr_reward.getComponent(we.ui.WESpriteIndex);
        if (spriteIndex) {
            spriteIndex.index = 1;
        }
        this.RC_spr_reward.node.active = true;
        this.renderMaskBox(this.currentLevel >= this.renderLevel ? 2 : 1);
    }

    /**
     * 工资奖励
     */
    protected async renderSalary() {
        this.RC_lab_title.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_041);

        const spriteIndex = this.RC_spr_reward.getComponent(we.ui.WESpriteIndex);
        if (spriteIndex) {
            spriteIndex.index = 2;
        }
        this.RC_spr_reward.node.active = true;

        const colorIndex = this.RC_lab_title.node.getComponent(we.ui.WENodeColorIndex);
        if (colorIndex) {
            colorIndex.index = 1;
        }

        const config = we.common.VIPConfig.vipLevelConfig[this.renderLevel];

        // 渲染规则
        const prefab = await this.loadAsset(HallRes.prefab.vip.VipRightsRowItem, cc.Prefab);

        if (!cc.isValid(this.RC_table)) {
            return;
        }

        const pool = new cc.NodePool();
        for (let i = this.RC_table.children.length - 1; i >= 0; i--) {
            const child = this.RC_table.children[i];
            if (child.name === prefab.name) {
                pool.put(child);
            }
        }

        let nextVipSalaryDay = we.common.VIPConfig.vipAwardStatus.data?.nextVipSalaryDay || 0;
        let canVipSalary = false;
        const vipSalary = we.common.VIPConfig.vipAwardStatus.data?.vipSalary || {};

        for (const key in config.vipSalary) {
            let node = pool.get();
            if (!node) {
                node = cc.instantiate(prefab);
            }
            const item = node.addComponentUnique(VipRightsRowItem_v);
            const salary = config.vipSalary[key];
            item.init(key, we.common.utils.formatAmountCurrency(salary));
            this.RC_table.addChild(node);

            if (!canVipSalary && vipSalary[key] === we.common.VIPConfig.VipAwardStatus.CAN_RECEIVE) {
                nextVipSalaryDay = Number(key);
                canVipSalary = true;
            }
        }

        this.RC_lab_num.node.active = false;
        this.renderMaskBox(0);

        if (this.renderLevel <= this.currentLevel && canVipSalary) {
            this.RC_receiveBtn.active = true;
            this.RC_lab_text.node.active = false;
            we.common.redDot.red.appendVRedDotNode(this.RC_receiveBtn).then((notice) => {
                we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vipSalary, node: notice });
            });
            this.receiveCallback = () => {
                return new Promise((resolve) => {
                    we.common.VIPConfig.getVipSysAward(
                        { awardType: 2, vipSalaryDay: nextVipSalaryDay },
                        (data: ApiProto.ReceiveVipSysRewardResp) => {
                            if (data.salaryRechargeAmount > data.rechargeAmount) {
                                // 今日充值金额不足，不能领取工资
                                we.currentUI.show(HallViewId.VipRightsGetDlg, {
                                    rechargeAmount: data.rechargeAmount,
                                    salaryRechargeAmount: data.salaryRechargeAmount,
                                });
                                resolve(0);
                            } else {
                                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.vipSalary, 0, true);
                                we.common.VIPConfig.getVipAwardStatus(() => {
                                    resolve(data.award);
                                });
                            }
                        },
                        () => {
                            resolve(0);
                        }
                    );
                });
            };
        } else {
            // 当天是否已领取工资
            const curDay = we.core.TimeHelper.getPointTimeZero().date();
            if (this.renderLevel <= this.currentLevel && vipSalary[curDay] === we.common.VIPConfig.VipAwardStatus.RECEIVED) {
                nextVipSalaryDay = curDay;
                if (this.renderLevel == this.currentLevel) {
                    this.renderMaskBox(2);
                } else {
                    this.renderMaskBox(0);
                }
            } else {
                this.renderMaskBox(1);
            }
        }

        if (nextVipSalaryDay) {
            this.RC_lab_text.node.active = true;
            this.RC_lab_text.string = we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_042, nextVipSalaryDay);
            this.RC_lab_num.node.active = true;
            this.RC_lab_num.string = we.common.utils.formatAmountCurrency(config.vipSalary[nextVipSalaryDay] || 0);
        }
    }

    /**
     * 显示奖励遮罩
     * @param [type=1] 遮罩类型 0:不展示 1:未解锁 2:已领取
     */
    protected renderMaskBox(type: 0 | 1 | 2) {
        if (type) {
            this.RC_maskBox.active = true;
            this.RC_lock.active = type == 1;
            this.RC_received.active = type == 2;
        } else {
            this.RC_maskBox.active = false;
        }
    }

    protected onClickShowTips() {
        this.RC_tipsBox.active = !this.RC_tipsBox.active;
        const vipView = we.currentUI.getDlg(VipViewDlg_v);
        const convert = (target1: cc.Node, target2: cc.Node) => {
            const wp = target1.parent.convertToWorldSpaceAR(target1.position);
            const p = target2.convertToNodeSpaceAR(new cc.Vec2(wp.x, wp.y));
            target1.setPosition(p);
            target1.parent = target2;
        };
        const eventMask = vipView?.view.uiRoot;
        if (eventMask) {
            if (this.RC_tipsBox.active) {
                this.RC_eventMask.getComponent(cc.Widget).target = eventMask;
                convert(this.RC_tipsBox, eventMask);
            } else {
                convert(this.RC_tipsBox, this.node);
            }
        }
    }

    protected onClickBindBirthday() {
        we.currentUI.show(HallViewId.BirthdaySelectDlg);
    }

    protected async onClickReceive() {
        if (!this.receiveCallback) {
            return;
        }
        const award = await this.receiveCallback();
        if (award) {
            const awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: award }];
            HallMgr.openGetAwardsDlg(awardMap);
        }
        if (cc.isValid(this.node)) {
            this.init(this.renderIndex, this.renderLevel);
        }
    }
}
