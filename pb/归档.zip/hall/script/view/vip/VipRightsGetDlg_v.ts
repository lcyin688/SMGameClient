import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('VipRightsGetDlgView_v', we.bundles.hall)
class VipRightsGetDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnCancel: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnConfirm: cc.Node = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_need: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_progress: we.ui.WERichTags = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('VipRightsGetDlg_v', we.bundles.hall)
export class VipRightsGetDlg_v extends we.ui.DlgSystem<VipRightsGetDlgView_v> {
    private needAmount = 0;
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnCancel, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnConfirm, we.core.Func.create(this.onClickBtnConfirm, this));
    }

    /** 显示窗口 */
    public async onShow(showData: { salaryRechargeAmount: number; rechargeAmount: number }) {
        if (!showData) {
            this.closeView();
            return;
        }
        const need = Math.floor(showData.salaryRechargeAmount - showData.rechargeAmount);
        this.needAmount = need || 0;

        this.view.RC_rich_need.setStringFormat(we.core.langMgr.getLangText(HallLanguage.NEW_VIP_DESC_039), ` ${we.common.utils.formatPrice(this.needAmount, true, false)}`);

        this.view.RC_rich_progress.setStringFormat('{0}', we.common.utils.formatPrice(showData.rechargeAmount, true, false));
        this.view.RC_rich_progress.setStringFormat(this.view.RC_rich_progress.string + ' / ' + we.common.utils.formatPrice(showData.salaryRechargeAmount, true, false));
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    public onClickBtnConfirm() {
        we.common.payMgr.trackFrom = we.common.JumpCmd.Vip;
        HallMgr.openStoreDlg(this.needAmount);
        this.closeView();
        we.currentUI.hide(HallViewId.VipViewDlg);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(VipRightsGetDlg_v, `${HallViewId.VipRightsGetDlg}_v`)
class VipRightsGetDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(VipRightsGetDlg_v, uiBase.addComponent(VipRightsGetDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipRightsGetDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<VipRightsGetDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(VipRightsGetDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(VipRightsGetDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(VipRightsGetDlg_v).beforeUnload();
    }
}
