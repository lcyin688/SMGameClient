import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import JumpModMgr from '../../manager/JumpModMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class CarnivalTaskItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_progress: cc.RichText = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_progress: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_go: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_over: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property({ tooltip: CC_DEV && '任务进度颜色配置' })
    private fromHEX: string = '#ffffff';

    private data: ApiProto.TaskProgressDetail = null;
    private type: string = null;

    protected onLoad(): void {
        this.onBtnClick(this.RCN_go, we.core.Func.create(this.onClickGoing, this));
        this.onBtnClick(this.RCN_receive, we.core.Func.create(this.onClickReceive, this));
    }

    public init(data: ApiProto.TaskProgressDetail, taskType: string) {
        this.__initRc();

        if (!data) {
            return;
        }

        this.data = data;
        this.type = taskType;

        // 充值类型任务需要换算
        this.RC_lab_award.string = `x${we.common.utils.formatAmount(data.reward || 0)}`;
        this.RC_spr_progress.fillRange = data.progress / data.target;
        let realProgress = data.progress > data.target ? data.target : data.progress;

        let isRechargeTask = data.typeEnum == we.common.activityMgr.TaskType.recharge;
        let progress = isRechargeTask ? we.common.utils.formatPrice(realProgress, false, false) : we.common.utils.formatAmount(realProgress, false);
        let targetScore = isRechargeTask ? we.common.utils.formatPrice(data.target, false, false) : we.common.utils.formatAmount(data.target, false);
        if (we.core.flavor.getSkinCode() === we.core.SkinCode.cm4) {
            this.RC_rich_progress.string = `<outline color=#000000 width=2><color=${this.fromHEX}>${progress}</c> / ${targetScore}</outline>`;
        } else {
            this.RC_rich_progress.string = `${progress}<color=${this.fromHEX}> / ${targetScore}</c>`;
        }

        let taskDesc = we.core.utils.stringFormat(we.core.langMgr.getLangText(isRechargeTask ? HallLanguage.TASK_TYPE_1 : HallLanguage.TASK_TYPE_2), targetScore);
        this.RC_lab_title.string = taskDesc;

        this.setTaskStatus();
    }

    private onClickReceive(): void {
        if (!we.common.carnivalMgr.isOpenAct()) {
            we.common.carnivalMgr.activityClose();
            return;
        }

        let param = {} as ApiProto.DrawNewTaskAwardReq;
        param.level = this.data.level;
        param.taskType = we.common.activityMgr.ActivityType.carnival;
        param.typeEnum = this.data.typeEnum;
        we.common.apiMgr.drawActivityAward(param, (data: ApiProto.DrawNewTaskAwardResp) => {
            if (data.drawAwardStatus == 1) {
                if (cc.isValid(this.node)) {
                    this.data.taskStatus = we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
                }

                let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.drawAwardNum }];
                HallMgr.openGetAwardsDlg(awardMap);

                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.carnival, -1);
                cc.director.emit(we.common.EventName.UPDATE_CARNIVAL);
            } else {
                we.common.activityMgr.getTaskAwardErrorHandle(data?.drawAwardStatus);
            }
        });
    }

    private onClickGoing(): void {
        if (!we.common.carnivalMgr.isOpenAct()) {
            we.common.carnivalMgr.activityClose();
            return;
        }

        switch (this.type) {
            case we.common.activityMgr.TaskType.recharge:
                cc.director.emit(we.common.EventName.CLOSE_CARNIVAL_VIEW, false);
                we.common.payMgr.trackFrom = we.common.JumpCmd.Carnival;
                HallMgr.openStoreDlg();
                break;
            case we.common.activityMgr.TaskType.betAmount:
                {
                    let lastGame = we.common.gameMgr.getLastGameInfo()?.gameId;
                    if (we.core.gameConfig.isSubGame(lastGame)) {
                        cc.director.emit(we.common.EventName.CLOSE_CARNIVAL_VIEW, false);
                        JumpModMgr.jumpToModule(lastGame + '');
                    } else {
                        we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.QUICK_GAME_TIPS));
                    }
                }
                break;
            default:
                break;
        }
    }

    private setTaskStatus(): void {
        let status = this.data.taskStatus;
        this.RCN_receive.active = status == we.common.activityMgr.TaskStatus.COMPLETED;
        this.RCN_go.active = this.data?.progress / this.data?.target < 1;
        this.RCN_over.active = status == we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
        this.RCN_mask.active = status == we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
    }
}
