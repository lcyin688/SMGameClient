import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import CarnivalTaskItem_v from './CarnivalTaskItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('CarnivalDlgView_v', we.bundles.hall)
class CarnivalDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_countdown: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_totalAward: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RCN_betNotice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_close: cc.Node = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RCN_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_received: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receiveGray: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rechargeNotice: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rule: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('CarnivalDlg_v', we.bundles.hall)
export class CarnivalDlg_v extends we.ui.DlgSystem<CarnivalDlgView_v> {
    // 任务分类
    private type: string = null;
    // 活动剩余时间
    private leftTime: number = 0;
    private isStartCountdown: boolean = false;
    // 领取奖励中
    private receivingAward: boolean = false;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RCN_menu.setMenuStateByNodeName('select', 'unselect');
        this.view.RCN_menu.onSelected = (node: cc.Node, index: number) => {
            switch (index) {
                case 0: // 充值
                    this.type = we.common.carnivalMgr.taskType[0];
                    break;
                case 1: // 打码
                    this.type = we.common.carnivalMgr.taskType[1];
                    break;
                default:
                    break;
            }

            this.onRefreshUI();
        };

        this.view.cc_onBtnClick(this.view.RCN_close, we.core.Func.create(this.onCloseDlg, this)).setSleepTime(0.5);
        this.view.cc_onBtnClick(this.view.RCN_rule, we.core.Func.create(this.onClickRule, this));
        this.view.cc_onBtnClick(this.view.RCN_receive, we.core.Func.create(this.onClickReceive, this));

        cc.director.on(we.common.EventName.CLOSE_CARNIVAL_VIEW, this.onCloseDlg, this);
        cc.director.on(we.common.EventName.UPDATE_CARNIVAL, this.onRefreshUI, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RCN_receive.active = false;
        this.view.RCN_received.active = false;
        this.view.RCN_receiveGray.active = false;
        this.leftTime = 0;
        this.isStartCountdown = false;
        this.receivingAward = false;

        this.type = we.common.carnivalMgr.taskType[0];
        this.onRefreshUI();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    protected update(): void {
        if (this.isStartCountdown) {
            this.leftTime -= this.deltaTime;
            if (this.leftTime > 0) {
                this.view.RC_lab_countdown.string = we.common.utils.formatSeconds(Math.ceil(this.leftTime));
            } else {
                this.isStartCountdown = false;
                this.view.RC_lab_countdown.string = we.common.utils.formatSeconds(0);
            }
        }
    }

    protected destroy(): void {
        cc.director.off(we.common.EventName.CLOSE_CARNIVAL_VIEW, this.onCloseDlg, this);
        cc.director.off(we.common.EventName.UPDATE_CARNIVAL, this.onRefreshUI, this);
    }

    private onRenderEvent(node: cc.Node, index: number): void {
        if (this.type) {
            let taskData: ApiProto.TaskProgressDetail[] = we.common.carnivalMgr.actInfo?.[this.type] || [];
            taskData = we.common.activityMgr.sortTask(taskData);
            let cmp = node.getComponent(CarnivalTaskItem_v);
            if (index < taskData.length && cmp) {
                cmp.init(taskData[index], this.type);
            }
        }
    }

    private onClickRule() {
        we.currentUI.showSafe(HallViewId.CarnivalRuleDlg);
    }

    private onClickReceive() {
        if (this.receivingAward) {
            return;
        }
        this.receivingAward = true;

        if (we.common.carnivalMgr.isOpenAct()) {
            let req = {} as ApiProto.DrawNewTaskAwardReq;
            req.level = 0; // 总奖励 level 传入 0
            req.taskType = we.common.activityMgr.ActivityType.carnival;
            req.typeEnum = we.common.activityMgr.TaskType.ultimate;
            we.common.apiMgr.drawActivityAward(req, (data: ApiProto.DrawNewTaskAwardResp) => {
                if (data.drawAwardStatus == 1) {
                    if (we.common.carnivalMgr.actInfo) {
                        we.common.carnivalMgr.actInfo.ultimateTaskStatus = we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
                    }

                    let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.drawAwardNum }];
                    HallMgr.openGetAwardsDlg(awardMap);

                    we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.carnival, -1);
                    cc.director.emit(we.common.EventName.UPDATE_CARNIVAL);
                } else {
                    this.receivingAward = false;
                    we.common.activityMgr.getTaskAwardErrorHandle(data?.drawAwardStatus);
                }
            });
        } else {
            if (cc.isValid(this.view.uiRoot)) {
                this.receivingAward = false;
            }
            we.common.carnivalMgr.activityClose();
        }
    }

    private onCloseDlg(isCb: boolean = true): void {
        if (isCb) {
            cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Carnival);
        }

        this.closeView();
    }

    private onRefreshUI() {
        if (!we.common.carnivalMgr.isOpenAct()) {
            we.common.carnivalMgr.activityClose();
            return;
        }

        this.view.RC_list.numItems = 0;
        let taskData: ApiProto.TaskProgressDetail[] = we.common.carnivalMgr.actInfo?.[this.type] || [];
        this.view.RC_list.numItems = taskData.length;

        this.updateCarnival();
        this.setNotice();
    }

    private updateCarnival(): void {
        let data = we.common.carnivalMgr.actInfo;
        if (!data) {
            return;
        }

        // 总奖励
        this.view.RC_lab_totalAward.string = we.common.utils.formatAmountCurrency(data.ultimateReward);

        // 活动时间
        let startMs = data.startTime * 1000;
        let endMs = data.endTime * 1000;
        let start = we.common.utils.formatDate(new Date(startMs), 'DD/MM hh:mm');
        let end = we.common.utils.formatDate(new Date(endMs), 'DD/MM hh:mm');
        this.view.RC_lab_time.string = start + ' - ' + end;
        this.leftTime = data.endTime - we.core.TimeInfo.Inst.serverNow() / 1000;
        this.view.RC_lab_countdown.string = we.common.utils.formatSeconds(this.leftTime > 0 ? Math.ceil(this.leftTime) : 0);
        this.isStartCountdown = this.leftTime > 0;

        // 领取按钮状态
        let totalTaskSt = data.ultimateTaskStatus;
        this.view.RCN_receive.active = totalTaskSt === we.common.activityMgr.TaskStatus.COMPLETED;
        this.view.RCN_received.active = totalTaskSt === we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
        this.view.RCN_receiveGray.active = totalTaskSt === we.common.activityMgr.TaskStatus.ONGOING;
    }

    private setNotice(): void {
        let taskTypeKey = we.common.carnivalMgr.taskType;
        this.view.RCN_rechargeNotice.active = we.common.carnivalMgr.isShowRedPointByType(taskTypeKey[0]);
        this.view.RCN_betNotice.active = we.common.carnivalMgr.isShowRedPointByType(taskTypeKey[1]);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(CarnivalDlg_v, `${HallViewId.CarnivalDlg}_v`)
class CarnivalDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(CarnivalDlg_v, uiBase.addComponent(CarnivalDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CarnivalDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<CarnivalDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(CarnivalDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CarnivalDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(CarnivalDlg_v).beforeUnload();
    }
}
