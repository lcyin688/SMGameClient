import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('NewbieGiveDlgView_v', we.bundles.hall)
class NewbieGiveDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnGet: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnLoginOut: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ratio_0: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ratio_1: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_openAnim: cc.Node = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_welcome: cc.RichText = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('NewbieGiveDlg_v', we.bundles.hall)
export class NewbieGiveDlg_v extends we.ui.DlgSystem<NewbieGiveDlgView_v> {
    private animOpen: boolean = false;
    private autoCloseTime: number = 10;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnGet, we.core.Func.create(this.onClickReceive, this));
        this.view.cc_onBtnClick(this.view.RC_btnLoginOut, we.core.Func.create(this.onClickLoginOut, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lab_award.string = we.common.utils.formatAmount(we.common.userMgr.userInfo.gold);
        this.view.RC_rich_welcome.string = we.core.langMgr.getLangText(HallLanguage.NEWBIE_WELCOM_DESC);
        let tipsStr = we.core.projectConfig.settingsConfig?.initAssetsContent[we.core.langMgr.getCurLangCode()];
        if (tipsStr && tipsStr.length > 0) {
            this.view.RC_rich_welcome.string = tipsStr;
        }

        this.view.RC_lab_ratio_0.string = '1';
        this.view.RC_lab_ratio_1.string = `= 1 ${we.core.flavor.getCurrencySymbol().trim()}`;

        this.showAnim();
    }

    /** 隐藏窗口 */
    public async onHide() {
        we.common.userMgr.isShowGiveDialog = false;
        cc.director.emit(HallEvent.SHOW_PLAYER_START_COIN);
    }

    public beforeUnload() {}

    protected update(): void {
        const dt = this.deltaTime;
        this.countDown(dt);
    }

    private onClickReceive(): void {
        this.closeView();
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Newbie_Give);
    }

    private onClickLoginOut(): void {
        we.common.userMgr.exitLogin(true);
    }

    private setAnim(): void {
        this.scheduleOnce(1).then(() => {
            this.animOpen = true;
        });
    }

    private async showAnim() {
        const openAnim = this.view.RC_openAnim.getComponent(we.ui.WESkeleton);
        if (openAnim) {
            await openAnim.playOnceAsync('animation1');
            openAnim.play('animation2', -1);
        }
        this.setAnim();
    }

    private countDown(dt: number): void {
        if (this.animOpen) {
            this.autoCloseTime -= dt;
            if (this.autoCloseTime < 0) {
                this.animOpen = false;
                this.closeView();
                cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Newbie_Give);
            }
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(NewbieGiveDlg_v, `${HallViewId.NewbieGiveDlg}_v`)
class NewbieGiveDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(NewbieGiveDlg_v, uiBase.addComponent(NewbieGiveDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(NewbieGiveDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<NewbieGiveDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(NewbieGiveDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(NewbieGiveDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(NewbieGiveDlg_v).beforeUnload();
    }
}
