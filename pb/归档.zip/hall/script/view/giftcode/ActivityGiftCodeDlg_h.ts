import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

let GetGiftReqType = cc.Enum({
    /** 该账户不能使用礼包码 */
    ACCOUNT_LIMIT: 1,
    /** 礼包领取成功 */
    SUC: 2,
    /** 输入无效的礼包码 */
    INVALID: 3,
    /** 当前礼包码已过期 */
    OUT_TIME: 4,
    /** 礼包已被领完 */
    GIFT_TIME_OVER: 5,
    /** 已领取此礼包码 */
    ALREADY_GET: 6,
    /** 礼包码领取次数已达上限 针对时效多次礼包码  */
    OVERTIMES: 7,
    /** 礼包码不符合领取条件 */
    NOT_MATCH_REQUIRE: 8,
    /** 礼包码不满足充值条件 */
    NOT_MATCH_RECHARGE: 9,
    /** 礼包码不满足打码条件 */
    NOT_MATCH_BET: 10,
    /** 非正式用户可领取 */
    CASUAL_USER: 11,
    /** 正式用户可领取 */
    OFFICIAL_USER: 12,
    /** vip{}用户可以使用 */
    VIP_USER: 13,
});

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('ActivityGiftCodeDlgView_h', we.bundles.hall)
class ActivityGiftCodeDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnExchange: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_inputCode: cc.EditBox = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('ActivityGiftCodeDlg_h', we.bundles.hall)
export class ActivityGiftCodeDlg_h extends we.ui.DlgSystem<ActivityGiftCodeDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onEditBoxEvent(this.view.RC_edit_inputCode.node, 'editingDidBegan', we.core.Func.create(this.onInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_inputCode.node, 'editingDidEnded', we.core.Func.create(this.onInputEnd, this));
        this.view.cc_onBtnClick(this.view.RC_btnExchange, we.core.Func.create(this.onBtnExchange, this));
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_edit_inputCode.placeholder = we.core.langMgr.getLangText(HallLanguage.GIFT_CODE_INPUT);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onBtnExchange() {
        this.giftCodeHandle();
    }

    private giftCodeHandle(): void {
        let inputCode: string = this.view.RC_edit_inputCode.string.trimEnd();
        inputCode = inputCode.trimStart();
        if (inputCode == '' || inputCode.length <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.GIFT_CODE_INPUT));
            return;
        }

        if (!we.common.utils.isGiftCode(inputCode)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.CODE_USE_TIPS_3));
            return;
        }

        let codeHandle = (data: ApiProto.giftReceiveResp) => {
            if (!data) {
                we.warn(`ActivityGiftCodeLD_h giftCodeHandle, award is null`);
                return;
            }

            let langKey = null;
            let langArgs = [];
            switch (data.succ) {
                case GetGiftReqType.ACCOUNT_LIMIT:
                    langKey = HallLanguage.CODE_USE_TIPS_3;
                    break;
                case GetGiftReqType.SUC:
                    {
                        let awardMap = [];
                        let packages = data.package || {};
                        for (let key in packages) {
                            awardMap.push({ id: parseInt(key), num: packages[key] });
                        }
                        HallMgr.openGetAwardsDlg(awardMap);

                        if (!cc.isValid(this.view.uiRoot)) {
                            return;
                        }
                        this.view.RC_edit_inputCode.string = '';
                        this.onInputEnd();
                    }
                    break;
                case GetGiftReqType.INVALID:
                    langKey = HallLanguage.CODE_USE_TIPS_3;
                    break;
                case GetGiftReqType.OUT_TIME:
                    langKey = HallLanguage.CODE_USE_TIPS_2;
                    break;
                case GetGiftReqType.GIFT_TIME_OVER:
                    langKey = HallLanguage.CODE_USE_TIPS_5;
                    break;
                case GetGiftReqType.ALREADY_GET:
                    langKey = HallLanguage.CODE_USE_TIPS_4;
                    break;
                case GetGiftReqType.OVERTIMES:
                    langKey = HallLanguage.CODE_USE_TIPS_9;
                    break;
                case GetGiftReqType.NOT_MATCH_REQUIRE:
                    langKey = HallLanguage.CODE_USE_TIPS_8;
                    break;
                case GetGiftReqType.NOT_MATCH_RECHARGE:
                    langKey = HallLanguage.CODE_USE_TIPS_10;
                    break;
                case GetGiftReqType.NOT_MATCH_BET:
                    langKey = HallLanguage.CODE_USE_TIPS_11;
                    break;
                case GetGiftReqType.CASUAL_USER:
                    langKey = HallLanguage.CODE_USE_TIPS_13;
                    break;
                case GetGiftReqType.OFFICIAL_USER:
                    langKey = HallLanguage.CODE_USE_TIPS_12;
                    break;
                case GetGiftReqType.VIP_USER:
                    langKey = HallLanguage.CODE_USE_TIPS_14;
                    langArgs = [data.vipLevelLimit.join(',')];
                    break;
                default:
                    break;
            }

            if (langKey) {
                we.commonUI.showToast(we.core.langMgr.getLangText(langKey, ...langArgs));
            }
        };

        we.common.apiMgr.getGiftCodeCoin(
            inputCode,
            (data: ApiProto.giftReceiveResp) => {
                codeHandle(data);
            },
            (code) => {}
        );
    }

    private onInputStart(): void {
        this.view.RC_edit_inputCode.placeholderLabel.string = ``;
    }

    private onInputEnd(): void {
        if (this.view.RC_edit_inputCode.string == '') {
            this.view.RC_edit_inputCode.placeholder = we.core.langMgr.getLangText(HallLanguage.GIFT_CODE_INPUT);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(ActivityGiftCodeDlg_h, `${HallViewId.ActivityGiftCodeDlg}_h`)
class ActivityGiftCodeDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(ActivityGiftCodeDlg_h, uiBase.addComponent(ActivityGiftCodeDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ActivityGiftCodeDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<ActivityGiftCodeDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(ActivityGiftCodeDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(ActivityGiftCodeDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(ActivityGiftCodeDlg_h).beforeUnload();
    }
}
