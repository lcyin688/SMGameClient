import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import RebateCodeGameItem_h from './RebateCodeGameItem_h';
import RebateGroupItem_h from './RebateGroupItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RebateEffectiveCodeDlgView_h', we.bundles.hall)
class RebateEffectiveCodeDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips3: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips4: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_group: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_content: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_navigationBar: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RebateEffectiveCodeDlg_h', we.bundles.hall)
export class RebateEffectiveCodeDlg_h extends we.ui.DlgSystem<RebateEffectiveCodeDlgView_h> {
    /** 当前分组下标 */
    private curGroupIndex: number = 0;
    /** 当前游戏列表 */
    private curGameList: ApiProto.GameRebateRatioConfig[] = [];
    private font: cc.Font = null;

    private groupKey: string[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_lab_tips1.string = '1.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus21);
        this.view.RC_lab_tips2.string = '2.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus24);
        this.view.RC_lab_tips3.string = '3.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus27);
        this.view.RC_lab_tips4.string = '4.' + we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus29);

        // 设置回掉函数
        this.view.RC_list_group.setRenderEvent(we.core.Func.create(this.onGroupRenderEvent, this));
        await this.initNavigationBar();
        // 单选按钮事件
        this.view.RCN_navigationBar.addComponentUnique(we.ui.WEToggleGroup)
            .setGroupMode(we.ui.ToggleGroupMode.SingleOne)
            .onListener(
                we.core.Func.create((_: number, isChecked: boolean, index: number) => {
                    if (isChecked) {
                        this.curGroupIndex = index;
                        this.showGameEntryList();
                    }
                }, this)
            );

        this.showGameEntryList();

        this.initData();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    /**
     * 初始化导航条所有页签
     */
    private async initNavigationBar() {
        const Prefab = await this.loadAsset(HallRes.prefab.RebateGroupItem, cc.Prefab);
        if (!Prefab) {
            return;
        }

        this.groupKey = [...we.common.rebateCodeMgr.gameRatioMap.keys()];
        for (let i = 0; i < this.groupKey.length; i++) {
            let groupItem: cc.Node = cc.instantiate(Prefab);
            this.view.RCN_navigationBar.addChild(groupItem);

            let comp = groupItem.getComponent(RebateGroupItem_h);
            if (comp) {
                let showLine = i != this.groupKey.length - 1;
                comp.init(this.groupKey[i], showLine);
            }
        }
    }

    private showGameEntryList(): void {
        if (we.common.rebateCodeMgr.gameRatioMap.size > 0) {
            this.addGameItem();
        }
    }

    /** 添加子游戏入口 */
    private addGameItem(): void {
        if (!this.view.RC_list_group) {
            return;
        }

        this.curGameList = we.common.rebateCodeMgr.gameRatioMap.get(this.groupKey[this.curGroupIndex]);

        // 设置回掉函数
        this.view.RC_list_group.setRenderEvent(we.core.Func.create(this.onGroupRenderEvent, this));
        // 当前页签数据，默认火热
        this.view.RC_list_group.numItems = this.curGameList.length;
    }

    private onGroupRenderEvent(item: cc.Node, index: number): void {
        let config: ApiProto.GameRebateRatioConfig = this.curGameList[index];
        this.initEntryItem(item, config);
        if (index >= 4) {
        }
    }

    private initEntryItem(node: cc.Node, config: ApiProto.GameRebateRatioConfig): void {
        if (!cc.isValid(node)) {
            return;
        }
        node.getComponent(RebateCodeGameItem_h).init(config, this.font);
    }

    private initData() {
        let config = we.common.rebateCodeMgr.baseConfig.conf;
        let validBetList: number[] = [];
        config.forEach((item) => {
            item.rebateRates.forEach((bet) => {
                if (validBetList.indexOf(bet.validBet) == -1) {
                    validBetList.push(bet.validBet);
                }
            });
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RebateEffectiveCodeDlg_h, `${HallViewId.RebateEffectiveCodeDlg}_h`)
class RebateEffectiveCodeDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RebateEffectiveCodeDlg_h, uiBase.addComponent(RebateEffectiveCodeDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateEffectiveCodeDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RebateEffectiveCodeDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(RebateEffectiveCodeDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateEffectiveCodeDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RebateEffectiveCodeDlg_h).beforeUnload();
    }
}
