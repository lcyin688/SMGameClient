import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallGameIconMgr from '../../manager/HallGameIconMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RebateCodeGameItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(sp.Skeleton)
    public RC_anim: sp.Skeleton = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name_bottom: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name_middle: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name_top: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ratio: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RCN_icon: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RCN_icon_spr: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private gameId: number = -1;

    public init(config: ApiProto.GameRebateRatioConfig, font: cc.Font) {
        this.gameId = config.gameId;
        this.RCN_icon.node.active = true;
        this.RCN_icon.node.opacity = 0;
        this.RC_anim.node.active = true;
        this.RC_anim.node.opacity = 0;

        let str = '';
        if (!we.core.gameConfig.isSubGame(config.gameId)) {
            let langKey = we.common.rebateCodeMgr.groupLangKey[config.gameType];
            str = we.core.langMgr.getLangText(HallLanguage[langKey]);
            if (config.gameId != -1) {
                this.RCN_icon_spr.getComponent(we.ui.WESpriteIndex).setIndex(config.gameId);
                this.RCN_icon_spr.active = true;
            } else {
                this.RCN_icon_spr.active = false;
            }
        } else {
            this.RCN_icon_spr.active = false;

            HallGameIconMgr.loadIcon({
                gameId: config.gameId,
                isBig: false,
                anim: this.RC_anim,
                image: this.RCN_icon,
                self: this,
            });

            str = we.common.gameMgr.getGameEntryName(config.gameId, false);
        }
        this.RC_lab_ratio.string = Number((config.rebateRatio / 100).toFixed(4)) + '%';

        if (font) {
            this.RC_lab_name_top.font = font;
            this.RC_lab_name_middle.font = font;
            this.RC_lab_name_bottom.font = font;
        }
        if (str) {
            let strArr = str.split(`\n`);
            if (strArr.length > 1) {
                this.RC_lab_name_top.node.active = true;
                this.RC_lab_name_top.string = strArr[0];

                this.RC_lab_name_bottom.node.active = true;
                this.RC_lab_name_bottom.string = strArr[1];
                this.RC_lab_name_middle.node.active = false;
            } else {
                this.RC_lab_name_middle.node.active = true;
                this.RC_lab_name_middle.string = strArr[0];
                this.RC_lab_name_top.node.active = false;
                this.RC_lab_name_bottom.node.active = false;
            }
        }
    }
}
