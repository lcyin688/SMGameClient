const { ccclass, property } = cc._decorator;

@ccclass
export default class RebateBoxItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */
    public init(str: string, size: cc.Size): void {
        this.node.setContentSize(size);
        this.RC_lab.string = str;
    }
}
