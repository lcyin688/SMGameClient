import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RebateRecordItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_betNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_reward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_status: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: ApiProto.UserRebateRecordItem) {
        this.RC_lab_time.string = we.common.utils.formatDate(new Date(data.ts * 1000), we.core.flavor.getCountryDateFormate());
        this.RC_lab_betNum.string = we.common.utils.formatAmount(data.validBet, false);
        this.RC_lab_reward.string = we.common.utils.formatAmount(data.rebate, false);
        this.RC_lab_status.string = we.core.langMgr.getLangText(data.getStatus == 0 ? HallLanguage.NEW_Rebate_Bonus37 : HallLanguage.NEW_Rebate_Bonus36);
    }
}
