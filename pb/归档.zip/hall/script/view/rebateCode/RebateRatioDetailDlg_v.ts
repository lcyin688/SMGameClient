import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import RebateRatioDetailItem_v from './RebateRatioDetailItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('RebateRatioDetailDlgView_v', we.bundles.hall)
class RebateRatioDetailDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_content: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('RebateRatioDetailDlg_v', we.bundles.hall)
export class RebateRatioDetailDlg_v extends we.ui.DlgSystem<RebateRatioDetailDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        let config = we.common.rebateCodeMgr.baseConfig.conf;
        let validBetList: number[] = [];
        config.forEach((item) => {
            item.rebateRates.forEach((bet) => {
                if (validBetList.indexOf(bet.validBet) == -1) {
                    validBetList.push(bet.validBet);
                }
            });
        });
        const prefab = await this.loadAsset(HallRes.prefab.rebateRatioDetailItem, cc.Prefab);
        if (!prefab) {
            return;
        }
        const prefabBox = await this.loadAsset(HallRes.prefab.rebateBoxItem, cc.Prefab);
        if (!prefabBox) {
            return;
        }
        this.initTableHead(prefab, prefabBox, validBetList);
        this.initTableBody(prefab, prefabBox);
        await we.core.timer.waitFrame(2, this);
        // 故意预留2帧 留1帧给layou刷新
        this.view.RCN_content.width = this.view.RCN_content.children[0].width;
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private async initTableHead(prefab: cc.Prefab, prefabBox: cc.Prefab, validBetList: number[]) {
        let groupItem: cc.Node = cc.instantiate(prefab);
        this.view.RCN_content.addChild(groupItem);
        let comp = groupItem.getComponent(RebateRatioDetailItem_v);
        if (comp) {
            let strArr = [we.core.langMgr.getLangText(HallLanguage.NEW_Rebate_Bonus31)];
            for (let i = 0; i < validBetList.length; i++) {
                strArr.push(we.common.utils.formatAmount(validBetList[i], false));
            }
            comp.init(strArr, prefabBox);
        }
    }

    private initTableBody(prefab: cc.Prefab, prefabBox: cc.Prefab) {
        let config = we.common.rebateCodeMgr.baseConfig.conf;
        for (let i = 0; i < config.length; i++) {
            let groupItem: cc.Node = cc.instantiate(prefab);
            this.view.RCN_content.addChild(groupItem);
            let comp = groupItem.getComponent(RebateRatioDetailItem_v);
            if (comp) {
                let item = config[i];
                let strArr = ['VIP' + item.vipLevel];
                for (let c = 0; c < item.rebateRates.length; c++) {
                    strArr.push(item.rebateRates[c].rate / 100 + '%');
                }
                comp.init(strArr, prefabBox);
            }
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(RebateRatioDetailDlg_v, `${HallViewId.RebateRatioDetailDlg}_v`)
class RebateRatioDetailDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(RebateRatioDetailDlg_v, uiBase.addComponent(RebateRatioDetailDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateRatioDetailDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<RebateRatioDetailDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(RebateRatioDetailDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(RebateRatioDetailDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(RebateRatioDetailDlg_v).beforeUnload();
    }
}
