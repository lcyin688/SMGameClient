import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RebateGroupItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_line: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_select: cc.Sprite = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_unselect: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    /**
     * 初始化分组
     * @param index 下标
     * @param groupKey 分组 key
     * @param showLine 显示分割线
     */
    public init(index: number, groupKey: string, showLine: boolean): void {
        this.RC_line.active = showLine;

        this.loadAsset(HallRes.texture.gameTypeIcon + groupKey + '_select', cc.SpriteFrame).then((sprite) => {
            if (sprite) {
                this.RC_spr_select.spriteFrame = sprite;
            }
        });
        this.loadAsset(HallRes.texture.gameTypeIcon + groupKey + '_unselect', cc.SpriteFrame).then((sprite) => {
            if (sprite) {
                this.RC_spr_unselect.spriteFrame = sprite;
            }
        });

        let langKey = we.common.rebateCodeMgr.groupLangKey[groupKey];
        if (langKey) {
            let label: cc.Label[] = this.node.getComponentsInChildren(cc.Label);
            label.forEach((v) => {
                v.string = we.core.langMgr.getLangText(HallLanguage[langKey]);
            });
        }
    }
}
