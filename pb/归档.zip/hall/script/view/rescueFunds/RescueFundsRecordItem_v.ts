import HallSkin from '../../config/HallSkin';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RescueFundsRecordItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_date: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_funds: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_status: cc.Label = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_lose: cc.RichText = null;

    @we.ui.ccBind(cc.RichText)
    public RC_rich_recharge: cc.RichText = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: ApiProto.ReliefRecord): void {
        let date = new Date(data.applyDate * 1000);
        let rechargeAmount = we.common.utils.formatPrice(data.rechargeAmount, false);
        let rechargeStandard = we.common.utils.formatPrice(data.rechargeStandard, false);
        let lossAmount = we.common.utils.formatAmount(data.lossAmount, true);
        let lossStandard = we.common.utils.formatAmount(data.lossStandard, true);

        let status = '';
        let color = null;
        switch (data.orderStatus) {
            case 0:
            case 1:
                status = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_18);
                break;
            case 2:
                status = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_19);
                break;
            case 3:
                status = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_20);
                color = HallSkin.config.RescueFundsRecordsItem.color[0];
                break;
            default:
                break;
        }

        let amountColor = HallSkin.config.RescueFundsRecordsItem.color[1];
        let standardColor = HallSkin.config.RescueFundsRecordsItem.color[2];
        this.RC_lab_date.string = we.common.utils.formatDate(date, we.core.flavor.getCountryDateFormate());
        this.RC_rich_recharge.string = `<color=${amountColor}>${rechargeAmount}</c><color=${standardColor}>/${rechargeStandard}</color>`;
        this.RC_rich_lose.string = `<color=${amountColor}>${lossAmount}</c><color=${standardColor}>/${lossStandard}</color>`;
        let str = '';
        if (data.orderStatus < 2) {
            str = we.common.utils.formatAmount((data.lossScale * data.lossAmount) / 1000, false) + ` ( ${we.common.utils.formatAmount(data.lossAmount, false)} * ${data.lossScale / 10}% )`;
        } else {
            // 返利金额大于返利上限
            if (data.reliefAmountUpperLimit > 0 && data.reliefAmountActual > data.reliefAmountUpperLimit) {
                let limitStr = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_39);
                str =
                    we.common.utils.formatAmount(data.reliefAmountActual, false) +
                    `(${limitStr} ${we.common.utils.formatAmount(data.reliefAmountUpperLimit, false)}*${Math.floor((data.reliefAmountActual / data.reliefAmountUpperLimit) * 100)}%)`;
            } else if (data.reliefAmountUpperLimit > 0 && data.reliefAmountActual == data.reliefAmountUpperLimit) {
                let limitStr = we.core.langMgr.getLangText(HallLanguage.EVENT_RESCUE_FUNDS_39);
                str = we.common.utils.formatAmount(data.reliefAmountActual, false) + `(${limitStr} ${we.common.utils.formatAmount(data.reliefAmountUpperLimit, false)})`;
            } else {
                // 客服修改的返利比例
                let num: number = data.reliefAmountActual / Math.floor((data.lossScale * data.lossAmount) / 1000);
                str = we.common.utils.formatAmount(data.reliefAmountActual, false) + `(${we.common.utils.formatAmount(data.lossAmount, false)}*${data.lossScale / 10}%` + (num == 1 ? `)` : `*${Math.round(num * 100)}%)`);
            }
        }
        this.RC_lab_funds.string = str;
        this.RC_lab_status.string = status;
        if (color) {
            this.RC_lab_status.node.color = cc.color().fromHEX(color);
        }
    }
}
