import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import { TurntableRecordReel_h } from './TurntableRecordReel_h';
import TurntableItem_h from './TurntableItem_h';
import TurntableRecordItem_h from './TurntableRecordItem_h';
import TurntableTaskListItem_h from './TurntableTaskListItem_h';

/** 历史标签 */
export enum HistoryType {
    BIG = 'server_big',
    SERVER = 'server',
    SELF = 'self',
}

/**
 * spin按钮动画效果
 */
const SpinBtnAniNames = {
    WAIT: 'animation',
    START: 'animation1',
    LOOP: 'animation2',
    END: 'animation3',
    SELECTED: 'animation4',
};

enum TurntableTweenTag {
    WHEEL = 11111,
}

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('TurntableDlgView_h', we.bundles.hall)
class TurntableDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_barAnimNew: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_barValueAnim: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnBet: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecharge: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecord: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnSpin: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnSpinAnim: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTaskBox: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTimeHelp: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_btnTaskBox: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_spinCount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_taskCount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_taskRatio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_taskType: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_timeHelp: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_task: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_recordList: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_spinTitleLabel: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_barValue: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_timeHelpMask: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_timeHelpPrompt: cc.Node = null;

    @we.ui.ccBind(cc.ToggleContainer)
    public RC_toggleContainer_task: cc.ToggleContainer = null;

    @we.ui.ccBind(cc.Node)
    public RC_turntableInside: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

export class TurntableStore {
    taskType = we.common.activityMgr.TaskType.recharge;
    taskList: ApiProto.TaskProgressDetail[] = [];
    taskProgress: Omit<ApiProto.TaskProgressDetail, 'level' | 'typeEnum' | 'taskStatus'> = {
        target: 1,
        progress: 0,
        reward: 0,
    };
    /** 是否完成了所有任务 */
    isFull: boolean = false;
    title: string = '';
    spinCount = 0;

    // 转盘过期时间
    expireTime = 0;
    /** 数据更新次数,主要是通过操作此数据来通知更新其他数据 */
    updateCount = 0;

    /**
     * 更新旋转真实数据次数
     */
    updateSpinCount() {
        this.spinCount = (we.common.turntableMgr.turntableData.userData && we.common.turntableMgr.turntableData.userData.cnt) || 0;
    }
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('TurntableDlg_h', we.bundles.hall)
export class TurntableDlg_h extends we.ui.DlgSystem<TurntableDlgView_h> {
    constructor() {
        super();

        // 创建Stroe
        const store = new TurntableStore();
        we.mobx.makeAutoObservable(store);
        this.store = store;
    }

    /**
     * 转盘item组件存储
     */
    private turnTableItemMaps: Map<number, TurntableItem_h> = new Map();
    /** 转盘节点存储 */
    private turnTableItemNodes: cc.Node[] = [];

    /** store */
    protected store: TurntableStore = null;

    private model = {
        /** 是否旋转中 */
        isRunning: false,
        /**
         * 转盘选项item配置
         */
        rodaConfigMap: <Map<number, ApiProto.RodaConf>>new Map(),
        /** 中奖记录列表 */
        recordList: <ApiProto.RodaHistory[]>[],

        /** 列表节点池 */
        recordItemPool: new cc.NodePool(),
    };

    /**
     * 无限循环滚动轴
     */
    private infiniteReel: TurntableRecordReel_h = null;

    /** record节点 */
    protected recordItemPrefab: cc.Prefab = null;

    private timerId = 0;

    /** 滚动分页请求次数 */
    private requestRecordCount = 0;

    async init() {
        // 如果数据初始化不成功，则不继续往下执行
        if (!this.initRodaConfigMap()) {
            return;
        }

        if (!we.common.turntableMgr.getTurntableIsAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_26));
            this.onClickCloseView();
            return;
        }

        this.renderCountDown();
        // 更新spin次数
        this.store.updateSpinCount();
        this.view.RC_turntableInside.angle = 15;

        this.renderTaskToggle();
    }

    /**
     * 事件注册实现
     */
    async registerUIEvent() {
        this.view.RC_btnClose && this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.onClickCloseView, this));
        this.view.cc_onBtnClick(this.view.RC_btnSpin, we.core.Func.create(this._onClickBtnSpinEv, this));
        this.view.cc_onBtnClick(this.view.RC_btnBet, we.core.Func.create(this._onClickQuickStart, this));
        this.view.cc_onBtnClick(this.view.RC_btnRecharge, we.core.Func.create(this._onClickBtnRecharge, this));
        this.view.cc_onBtnClick(this.view.RC_btnRule, we.core.Func.create(this._onClickBtnRule, this));
        this.view.cc_onBtnClick(this.view.RC_btnRecord, we.core.Func.create(this._onClickBtnReward, this));

        // 倒计时帮助信息相关事件
        this.view.cc_onBtnClick(this.view.RC_btnTimeHelp, we.core.Func.create(this._onClickBtnTimeHelp, this));
        this.view.RC_timeHelpMask && this.view.cc_onBtnClick(this.view.RC_timeHelpMask, we.core.Func.create(this._onHideTimeHelp, this));

        /** 任务列表相关 */
        this.view.RC_list_task && this.view.RC_list_task.setRenderEvent(we.core.Func.create(this.onRenderItem, this));
        this.view.RC_toggleContainer_task && this.view.cc_onToggle(this.view.RC_toggleContainer_task.node, we.core.Func.create(this.onToggleTaskType, this), [0, 1]);
    }

    /**
     * 显示
     */
    async onShow() {
        this.init();
        this.updateTurntableData();
        this.requestRecords();
        this.timerId = this.schedule(30, this.requestRecords);
    }

    /**
     * 弹窗隐藏
     */
    async onHide() {
        this.removeTimerById(this.timerId);
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Turntable);
    }

    destroy() {
        this.model.recordItemPool.clear();
    }

    /**
     * 请求Records信息 \
     * @returns
     */
    protected async requestRecords() {
        if (this.requestRecordCount > 5) {
            this.removeTimerById(this.timerId);
            return;
        }
        if (!this.view.RC_recordList) {
            return;
        }

        const res = await we.common.turntableMgr.getRodaUndianUpPage({
            historyType: HistoryType.BIG,
            indexLow: 0,
            indexHigh: 20,
        });

        if (this.IsDisposed) {
            return;
        }

        const data = res?.serviceBigHistory ?? [];
        this.model.recordList.length = 0;
        this.model.recordList.push(...data);
        this.requestRecordCount += 1;

        if (!this.recordItemPrefab) {
            this.recordItemPrefab = await this.loadAsset(HallRes.prefab.turntable.TurntableRecordItem, cc.Prefab);
        }

        this.createInfiniteReel();
        return data;
    }

    private onClickCloseView() {
        if (this.model.isRunning) {
            return;
        }
        this.closeView();
    }

    private createInfiniteReel() {
        if (this.infiniteReel || this.IsDisposed) {
            return;
        }
        this.infiniteReel = new TurntableRecordReel_h({
            parent: this.view.RC_recordList,
            listSize: cc.size(this.view.RC_recordList.width, this.view.RC_recordList.height),
            layout: TurntableRecordReel_h.Layout.VERTICAL,
            direction: TurntableRecordReel_h.Direction.UP,
        });

        this.infiniteReel.onCreateItem((idx) => {
            const len = this.model.recordList.length;
            if ((len == 1 && idx > 0) || !this.recordItemPrefab) {
                return null;
            }

            if (len < 6 && idx >= len) {
                return null;
            }

            const data = this.model.recordList[idx % this.model.recordList.length];
            if (!data) {
                return null;
            }

            let node = this.model.recordItemPool.get();

            if (!node) {
                node = cc.instantiate(this.recordItemPrefab);
            }

            const comp = node.addComponentUnique(TurntableRecordItem_h);
            comp.init(data);

            return { node: comp.node, size: cc.size(node.width, node.height) };
        });

        // 回收item节点;
        this.infiniteReel.onRemoveItem((node) => {
            this.model.recordItemPool.put(node);
        });
    }

    protected async updateTurntableData() {
        await we.common.turntableMgr.getTurntableData(false);
        this.store.updateCount++;
        if (this.IsDisposed) {
            return;
        }

        this?.init?.();
    }

    /**
     * 通用流程
     * 初始化转盘数据
     */
    protected initRodaConfigMap() {
        const list = we.common.turntableMgr.turntableData.rodaConf;
        // 没有数据，提交错误
        if (!list) {
            we.error('TurntableDlg_h initRodaConfigMap, data error: not data!');
            return false;
        }

        // 数据长度不够，提交错苏
        // if (list.length < 12) {
        //     we.error('TurntableDlg_h initRodaConfigMap, data length error: data length lt 12');
        //     return false;
        // }

        // 将数据转存到map中，旋转结果验证
        for (const item of list) {
            this.model.rodaConfigMap.set(item.id, item);
        }

        // 渲染数据
        const renderList = Array.from(this.model.rodaConfigMap).map((it) => {
            return it[1];
        });
        this.renterTurnTabeleItem(renderList);
        return true;
    }

    /**
     * 渲染倒计时
     * @returns
     */
    protected async renderCountDown() {
        // 计算距离下个6点时间差
        const curTime = we.core.TimeInfo.Inst.serverNow();
        let nextTime = new Date(curTime).setHours(6, 0, 0, 0);
        if (curTime >= nextTime) {
            nextTime += 24 * 60 * 60 * 1000;
        }
        if (nextTime > we.common.turntableMgr.turntableData.endTime * 1000) {
            nextTime = we.common.turntableMgr.turntableData.endTime * 1000;
        }
        const duration = Math.floor((nextTime - curTime) / 1000);
        const timeCountDown = this.view.RC_lab_time.node.getComponent(we.ui.WETimeCountDown);
        timeCountDown.countDown(0, duration, `{HH}:{MM}:{SS}`, (str) => {
            this.view.RC_lab_time.string = str;
        });
        this.store.expireTime = nextTime;
    }

    /**
     * 渲染任务项
     */
    protected renderTaskToggle() {
        const toggleItems = this.view.RC_toggleContainer_task.toggleItems;
        const { recharge, betAmount } = we.common.turntableMgr.turntableData;

        let toggleIndex = 0;
        if (recharge.length && betAmount.length) {
            this.view.RC_btnTaskBox.active = false;
            this.view.RC_toggleContainer_task.node.active = true;
            if (this.store.taskType === we.common.activityMgr.TaskType.betAmount) {
                toggleIndex = 1;
            }
        } else {
            this.view.RC_btnTaskBox.active = true;
            this.view.RC_toggleContainer_task.node.active = false;
            if (recharge.length) {
                this.view.RC_lab_btnTaskBox.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_9);
                toggleIndex = 0;
            } else if (betAmount.length) {
                this.view.RC_lab_btnTaskBox.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_10);
                toggleIndex = 1;
            }
        }
        toggleItems[toggleIndex].check();
        this.onToggleTaskType(null, toggleIndex);
    }

    /** 任务列表切换 */
    protected onToggleTaskType(_: any, index: number) {
        this.store.taskType = index === 0 ? we.common.activityMgr.TaskType.recharge : we.common.activityMgr.TaskType.betAmount;
    }

    /**
     * 更新剩余旋转次数
     */
    @we.mobx.render
    private __renderSpinCount() {
        this.view.RC_lab_spinCount.string = this.store.spinCount.toString();
        we.common.turntableMgr.getTurntableRedCount(true);
        we.common.activityMgr.updateEventCenter();
    }

    /**
     * 当类型有变化时，重新设置数据
     */
    @we.mobx.render
    private __taskTypeChange() {
        const type = this.store.taskType;

        // 此处的作用是当数据更新时能响应数据更新
        this.store.updateCount;

        let list: ApiProto.TaskProgressDetail[] = [];
        let taskData: Omit<ApiProto.TaskProgressDetail, 'level' | 'typeEnum' | 'taskStatus'> = {
            target: 0,
            progress: 0,
            reward: 0,
        };
        let title = '';

        switch (type) {
            case we.common.activityMgr.TaskType.recharge:
                {
                    list = we.common.turntableMgr.turntableData.recharge;
                    taskData = list[we.common.turntableMgr.turntableData.rechargeTaskAttainCount] || taskData;
                    title = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_9);
                    this.store.isFull = we.common.turntableMgr.turntableData.rechargeTaskAttainCount >= list.length;
                }
                break;
            case we.common.activityMgr.TaskType.betAmount:
                {
                    list = we.common.turntableMgr.turntableData.betAmount;
                    taskData = list[we.common.turntableMgr.turntableData.betAmountTaskAttainCount] || taskData;
                    title = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_10);
                    this.store.isFull = we.common.turntableMgr.turntableData.betAmountTaskAttainCount >= list.length;
                }
                break;
            default:
                {
                    list = we.common.turntableMgr.turntableData.recharge;
                    taskData = list[we.common.turntableMgr.turntableData.rechargeTaskAttainCount] || taskData;
                    title = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_9);
                    this.store.isFull = we.common.turntableMgr.turntableData.rechargeTaskAttainCount >= list.length;
                }
                break;
        }

        this.store.taskList = list;
        this.store.taskProgress.progress = taskData.progress ?? 0;
        this.store.taskProgress.target = taskData.target ?? 0;
        this.store.taskProgress.reward = taskData.reward ?? 0;
        this.store.title = title;

        this.view.RC_btnBet.active = type == we.common.activityMgr.TaskType.betAmount;
        this.view.RC_btnRecharge.active = type == we.common.activityMgr.TaskType.recharge;
    }

    /**
     * 渲染task列表,当list有变化时会重新渲染
     */
    @we.mobx.render
    private __renderTaskList() {
        const list = this.store.taskList;
        this.view.RC_list_task && (this.view.RC_list_task.numItems = list.length);
    }

    /**
     * 当进度信息有变化时重新渲染进度
     * 进度条通用功能
     */
    @we.mobx.render
    private __renderProgressInfo() {
        const taskData = this.store.taskProgress;
        const isFull = this.store.isFull;
        const title = this.store.title;
        this.view.RC_lab_taskType.string = title;

        let progress = taskData.progress / (taskData.target || 1);
        progress = Math.max(0, progress);
        progress = Math.min(1, progress);

        // 播放进度条动画
        cc.Tween.stopAllByTarget(this.view.RC_spr_barValue);
        const curRange = this.view.RC_spr_barValue.fillRange;
        if (curRange < progress) {
            this.tween(this.view.RC_spr_barValue).to(0, { fillRange: progress }, { easing: 'sineOut' }).start();
        } else {
            this.view.RC_spr_barValue.fillRange = isFull ? 1 : progress;
        }

        const fromatAmout = (amout: number) => {
            switch (this.store.taskType) {
                case we.common.activityMgr.TaskType.recharge:
                    return we.common.utils.formatPrice(amout, false);
                case we.common.activityMgr.TaskType.betAmount:
                    return we.common.utils.formatAmount(amout);
                default:
                    return we.common.utils.formatPrice(amout, false);
            }
        };

        if (!isFull) {
            this.view.RC_lab_taskRatio.string = `${fromatAmout(taskData.progress)}/${fromatAmout(taskData.target)}`;
            this.view.RC_lab_taskCount.string = `+${taskData.reward}`;
            this.view.RC_spinTitleLabel && (this.view.RC_spinTitleLabel.active = true);
        } else {
            this.view.RC_lab_taskRatio.string = '';
            this.view.RC_lab_taskCount.string = '';
            this.view.RC_spinTitleLabel && (this.view.RC_spinTitleLabel.active = false);
        }
    }

    /**
     * 渲染进度条动画
     * 进度条差异功能
     */
    @we.mobx.render
    private renderProgressAnim() {
        const taskData = this.store.taskProgress;
        let progress = taskData.progress / (taskData.target || 1);
        progress = Math.max(0, progress);
        progress = Math.min(1, progress);

        const pos = this.view.RC_barValueAnim.getPosition();
        pos.y = this.view.RC_spr_barValue.node.height * progress - 5;

        // 播放进度条粒子动画
        cc.Tween.stopAllByTarget(this.view.RC_barValueAnim);
        const curRange = this.view.RC_spr_barValue.fillRange;

        // 重置当前粒子位置
        const currPosY = this.view.RC_spr_barValue.fillRange * this.view.RC_spr_barValue.node.height - 5;
        this.view.RC_barValueAnim.setPosition(pos.x, currPosY);

        if (curRange < progress) {
            this.view.RC_barValueAnim.active = true;
            this.tween(this.view.RC_barValueAnim)
                .to(0, { position: pos }, { easing: 'sineOut' })
                .call(() => {
                    this.view.RC_barValueAnim.active = progress > 0 && progress < 1;
                })
                .start();
        } else {
            this.view.RC_barValueAnim.setPosition(pos);
            this.view.RC_barValueAnim.active = progress > 0 && progress < 1;
        }

        this.view.RC_barAnimNew.active = progress > 0;
        this.view.RC_barAnimNew.height = this.view.RC_spr_barValue.fillRange * this.view.RC_spr_barValue.node.height;
    }

    /**
     * 渲染任务列表
     * @param node
     * @param index
     */
    protected onRenderItem(node: cc.Node, index: number) {
        const item = node.addComponentUnique(TurntableTaskListItem_h);
        const data = this.store.taskList[index];
        item.init({
            target: data.target,
            value: data.reward,
            type: this.store.taskType,
        });
    }

    /**
     * 开始按钮通用业务逻辑
     * 表现效果差异请在 spinStart、spinStop 、errorStop 中修改
     * @returns
     */
    protected async _onClickBtnSpinEv() {
        if (we.core.TimeInfo.Inst.serverNow() >= this.store.expireTime) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_26));
            this.closeView();
            return;
        }
        if (this.model.isRunning || !we.common.turntableMgr.turntableData.userData) {
            return;
        }

        if (we.common.turntableMgr.turntableData.userData.cnt <= 0) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_25));
            return;
        }

        if (!we.common.turntableMgr.getTurntableIsAct()) {
            // 任务活动已到期
            HallMgr.activityStatusTips(we.common.turntableMgr.turntableData.startTime, we.common.turntableMgr.turntableData.endTime);
            return;
        }

        this.model.isRunning = true;

        this.spinStart();

        const waitTimer = this.scheduleOnce(2);

        let res: ApiProto.RodaActivityAwardResp = null;

        // 旋转时先减少一次次数
        this.store.spinCount -= 1;

        // 请求旋转结果
        try {
            res = await we.common.turntableMgr.getRodaUndianAward();
            if (this.IsDisposed) {
                return;
            }
        } catch (e) {
            if (this.IsDisposed) {
                return;
            }
            we.error(e);
            this.errorStop();
            this.store.updateSpinCount();
            this.model.isRunning = false;
            return;
        }

        await waitTimer;

        this.store.updateSpinCount();
        // 数据不正确直接进行错误处理
        if (!this.model.rodaConfigMap.has(res?.awardId)) {
            this.errorStop();
            this.model.isRunning = false;
            // 弹出提示框，关闭弹框
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_26));
            this.closeView();
            return;
        }

        // 停止旋转
        await this.spinStop(res);

        // 创建奖励弹框
        const awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: res.awardNum64 }];
        HallMgr.openGetAwardsDlg(awardMap);
        this.model.isRunning = false;
    }

    /**
     * 快速开始
     */
    protected async _onClickQuickStart() {
        if (this.model.isRunning) {
            return;
        }
        HallMgr.openRecentGame(() => {
            this.isValid() && this.closeView();
        });
    }

    /**
     * 点击充值按钮
     */
    protected _onClickBtnRecharge() {
        if (this.model.isRunning) {
            return;
        }
        we.common.payMgr.trackFrom = we.common.JumpCmd.Turntable;
        HallMgr.openStoreDlg();
        this.closeView();
    }

    /**
     * 倒计时帮助按钮点击事件
     */
    protected _onClickBtnTimeHelp() {
        this.view.RC_timeHelpPrompt && (this.view.RC_timeHelpPrompt.active = true);
        if (we.common.turntableMgr.turntableData.rodaCntDailyRefresh) {
            this.view.RC_lab_timeHelp.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_13);
        } else {
            this.view.RC_lab_timeHelp.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_27);
        }
    }

    /**
     * 隐藏倒计时提示信息
     */
    protected _onHideTimeHelp() {
        this.view.RC_timeHelpPrompt && (this.view.RC_timeHelpPrompt.active = false);
    }

    /**
     * 点击规则
     */
    protected _onClickBtnRule() {
        we.currentUI.showSafe(HallViewId.TurntableRuleDlg);
    }

    /**
     * 点击中奖记录
     */
    protected _onClickBtnReward() {
        we.currentUI.showSafe(HallViewId.TurntableRewardDlg);
    }

    /**
     * 转盘item渲染
     * @param list
     * @returns
     */
    protected async renterTurnTabeleItem(list: ApiProto.RodaConf[]) {
        const prefab = await this.loadAsset(HallRes.prefab.turntable.TurntableItem, cc.Prefab);
        if (!prefab) {
            return;
        }

        const child = this.turnTableItemNodes;
        this.turnTableItemMaps.clear();

        const len = list.length;
        for (let i = 0; i < len; i++) {
            const { award, id } = list[i];
            let node = child[i];
            const isNode = !!node;
            if (!node) {
                node = cc.instantiate(prefab);
                this.turnTableItemNodes.push(node);
            }

            node.angle = i * 30;
            node.active = true;
            const item = node.addComponentUnique(TurntableItem_h);
            !isNode && this.view.RC_turntableInside.addChild(node);
            item.init(award, node.angle);
            this.turnTableItemMaps.set(id, item);
        }
    }

    /**
     * 旋转开始的表现
     */
    protected async spinStart() {
        const anim = this.view.RC_btnSpinAnim.getComponent(we.ui.WESkeleton);
        this.turnTableItemMaps.forEach((item) => {
            return item.hideBorder();
        });
        anim?.playOnceAsync(SpinBtnAniNames.START).then(() => {
            anim?.playLoop(SpinBtnAniNames.LOOP);
        });

        this.tween(this.view.RC_turntableInside)
            .tag(TurntableTweenTag.WHEEL)
            .repeatForever(new cc.Tween().by(0.8, { angle: -360 }))
            .start();
    }

    /**
     * 旋转错误的表现
     * @param data
     */
    protected async spinStop(data: ApiProto.RodaActivityAwardResp) {
        const anim = this.view.RC_btnSpinAnim.getComponent(we.ui.WESkeleton);
        anim?.clearAsync();
        anim?.playOnceAsync(SpinBtnAniNames.END);

        const item = this.turnTableItemMaps.get(data.awardId);
        item.init(data.awardNum64);
        const angle = item.angle - Math.abs(this.view.RC_turntableInside.angle % 360) + 720;
        cc.Tween.stopAllByTag(TurntableTweenTag.WHEEL);

        const defer = we.core.PromiseHelper.defer();
        this.tween(this.view.RC_turntableInside)
            .by(Math.abs(angle) * 0.001 + 0.8, { angle: -angle }, { easing: 'quadOut' })
            .call(defer.resolve)
            .start();

        await defer.promise();
        await this.scheduleOnce(0);

        this.view.RC_turntableInside.angle = -item.angle;
        await item.showBorder();
        anim?.playLoop(SpinBtnAniNames.WAIT);
    }

    /**
     * 旋转错误的表现
     */
    protected errorStop() {
        const anim = this.view.RC_btnSpinAnim.getComponent(we.ui.WESkeleton);
        anim?.clearAsync();
        anim?.playLoop(SpinBtnAniNames.WAIT);
        cc.Tween.stopAllByTag(TurntableTweenTag.WHEEL);
        this.view.RC_turntableInside.angle = this.view.RC_turntableInside.angle % 360;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(TurntableDlg_h, `${HallViewId.TurntableDlg}_h`)
class TurntableDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(TurntableDlg_h, uiBase.addComponent(TurntableDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<TurntableDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(TurntableDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(TurntableDlg_h).beforeUnload();
    }
}
