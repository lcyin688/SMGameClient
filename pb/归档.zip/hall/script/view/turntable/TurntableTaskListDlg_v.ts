import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import TurntableTaskListItem_v from './TurntableTaskListItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('TurntableTaskListDlgView_v', we.bundles.hall)
class TurntableTaskListDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTaskBox: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_btnTaskBox: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_scrollView: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_noData: cc.Node = null;

    @we.ui.ccBind(cc.ToggleContainer)
    public RC_toggleContainer: cc.ToggleContainer = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('TurntableTaskListDlg_v', we.bundles.hall)
export class TurntableTaskListDlg_v extends we.ui.DlgSystem<TurntableTaskListDlgView_v> {
    taskList: ApiProto.TaskProgressDetail[] = [];

    taskType = we.common.activityMgr.TaskType.recharge;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_list_scrollView.setRenderEvent(we.core.Func.create(this.onRenderItem, this));

        this.view.cc_onToggle(this.view.RC_toggleContainer.node, we.core.Func.create(this.onToggleTaskType, this), [0, 1]);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.view.RC_toggleContainer.toggleItems[0].isChecked = true;
        this.renderTaskToggle();
    }

    /**
     * 渲染任务项
     */
    protected renderTaskToggle() {
        const toggleItems = this.view.RC_toggleContainer.toggleItems;
        const { recharge, betAmount } = we.common.turntableMgr.turntableData;

        let toggleIndex = 0;
        if (recharge.length && betAmount.length) {
            this.view.RC_btnTaskBox.active = false;
        } else {
            this.view.RC_btnTaskBox.active = true;
            if (recharge.length) {
                this.view.RC_lab_btnTaskBox.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_9);
                toggleIndex = 0;
            } else if (betAmount.length) {
                this.view.RC_lab_btnTaskBox.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_10);
                toggleIndex = 1;
            }
        }
        toggleItems[toggleIndex].check();
        this.onToggleTaskType(null, toggleIndex);
    }

    public onToggleTaskType(_: any, index: number) {
        let list = [];
        if (index === 0) {
            list = we.common.turntableMgr.turntableData.recharge;
            this.taskType = we.common.activityMgr.TaskType.recharge;
        } else {
            list = we.common.turntableMgr.turntableData.betAmount;
            this.taskType = we.common.activityMgr.TaskType.betAmount;
        }
        this.taskList = list;
        this.view.RC_noData.active = list.length <= 0;
        this.view.RC_list_scrollView.numItems = list.length;
    }

    public onRenderItem(node: cc.Node, index: number) {
        const item = node.addComponentUnique(TurntableTaskListItem_v);
        const data = this.taskList[index];

        item.init({
            target: data.target,
            value: data.reward,
            type: this.taskType,
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(TurntableTaskListDlg_v, `${HallViewId.TurntableTaskListDlg}_v`)
class TurntableTaskListDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(TurntableTaskListDlg_v, uiBase.addComponent(TurntableTaskListDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableTaskListDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<TurntableTaskListDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(TurntableTaskListDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableTaskListDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(TurntableTaskListDlg_v).beforeUnload();
    }
}
