import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('TurntableRuleDlgView_v', we.bundles.hall)
class TurntableRuleDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_text1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_text2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_text3: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('TurntableRuleDlg_v', we.bundles.hall)
export class TurntableRuleDlg_v extends we.ui.DlgSystem<TurntableRuleDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        if (we.common.turntableMgr.turntableData.rodaCntDailyRefresh) {
            this.view.RC_lab_text1.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_18);
            this.view.RC_lab_text2.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_19);
            this.view.RC_lab_text3.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_20);
        } else {
            this.view.RC_lab_text1.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_28);
            this.view.RC_lab_text2.string = we.core.langMgr.getLangText(HallLanguage.TURNTABLE_LABEL_29);
            this.view.RC_lab_text3.string = '';
        }
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(TurntableRuleDlg_v, `${HallViewId.TurntableRuleDlg}_v`)
class TurntableRuleDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(TurntableRuleDlg_v, uiBase.addComponent(TurntableRuleDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableRuleDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<TurntableRuleDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(TurntableRuleDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(TurntableRuleDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(TurntableRuleDlg_v).beforeUnload();
    }
}
