const { ccclass, property } = cc._decorator;

/** 选中动画播放 */
const SELECTED_ANIM_NAME = 'animation4';

@ccclass
export default class TurntableItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_border: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_money: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_selectAnim: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    angle = 0;

    init(award: number, angle?: number) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.RC_lab_money.string = `${we.common.utils.formatAmount(award)}`;
        this.RC_border.active = false;
        if (angle) {
            this.angle = angle;
        }
    }

    async showBorder() {
        await this.playSelectedAnim();
        this.RC_border.opacity = 0;
        this.RC_border.active = true;
        this.tween(this.RC_border)
            .repeatForever(new cc.Tween().to(0.5, { opacity: 255 }).delay(0.2).to(0.5, { opacity: 0 }))
            .start();
        await we.core.timer.scheduleOnce(1);
    }

    hideBorder() {
        this.RC_border.active = false;
        cc.Tween.stopAllByTarget(this.RC_border);
        if (!this.RC_selectAnim) {
            return;
        }
        this.RC_selectAnim.active = false;
    }

    /**
     * 播放选中动画
     */
    private async playSelectedAnim() {
        if (!this.RC_selectAnim) {
            return;
        }

        const sk = this.RC_selectAnim.getComponent(we.ui.WESkeleton);
        if (!sk) {
            return;
        }

        this.RC_selectAnim.active = true;
        await sk?.playOnceAsync(SELECTED_ANIM_NAME);
        this.RC_selectAnim.active = false;
    }
    protected onLoad(): void {
        this.RC_border.active = false;
    }

    protected start(): void {}

    protected onEnable(): void {}

    protected update(dt: number): void {}

    protected onDestroy(): void {}
}
