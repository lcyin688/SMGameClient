import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StorePayItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_icon: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ratio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tag: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_ratio: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_tag: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
    private payInfo: ApiProto.RechargeTypeCategory;

    public init(info: ApiProto.RechargeTypeCategory) {
        if (!info) {
            return;
        }
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.RC_tag.active = false;
        this.RC_ratio.active = false;
        this.payInfo = info;

        const { name, payType } = info;
        this.RC_lab_name1.string = name;
        this.RC_lab_name2.string = name;

        if (we.common.payMgr.isTestPay(payType)) {
            this.RC_icon.addComponentUnique(cc.Sprite).spriteFrame = null;
        } else {
            let payTypeIconPath = HallRes.texture.payTypeIconSmall + payType;
            we.common.utils.setComponentSprite(this.RC_icon, payTypeIconPath);
        }

        this.setRecommendTag();
        this.updateAddRatio();
    }

    public updateAddRatio() {
        let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
        this.RC_ratio.active = this.payInfo.rechargeGiftScale > 0 && curTime < we.common.storeMgr.shopConf.rechargeGiftExpireTime;
        this.RC_lab_ratio.string = `+${this.payInfo.rechargeGiftScale / 100}%`;
    }

    protected setRecommendTag() {
        const tag = this.payInfo.tag;
        let langKey = null;
        let index = -1;
        // 0 默认 1 推荐 2 大额 3 便捷
        switch (tag) {
            case 1:
                langKey = HallLanguage.RECHARGE_SUB_TJ;
                index = 0;
                break;
            case 2:
                langKey = HallLanguage.RECHARGE_SUB_DE;
                index = 1;
                break;
            case 3:
                langKey = HallLanguage.RECHARGE_SUB_BJ;
                index = 2;
                break;
            default:
                break;
        }

        if (typeof langKey == 'string' && langKey.length > 0) {
            this.RC_tag.active = true;
            this.RC_lab_tag.string = we.core.langMgr.getLangText(langKey);
            const styleIndex = this.RC_tag.addComponentUnique(we.ui.WERenderStyleIndex);
            styleIndex.index = index;
        } else {
            this.RC_tag.active = false;
        }
    }
}
