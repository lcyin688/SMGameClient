import { HallViewId } from '../HallViewId';
import StoreSelectItem_v from './StoreSelectItem_v';
import StoreGoodsItem_v from './StoreGoodsItem_v';
import StoreVipPay_v from './StoreVipPay_v';
import HallMgr from '../../manager/HallMgr';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

// 支付渠道首屏仅展示 9 个
const channelMaxShow = 9;

@ccclass
export default class StoreDialog_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnAdd: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnChoose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnOrder: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecharge: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnService: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_clear: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_custom_amount: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_editbox_amount: cc.EditBox = null;

    @we.ui.ccBind(cc.Node)
    public RC_give_away: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_guide: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bankCardTips: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_giveAmount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_guideDesc: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_guideTitle: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_navTitle21: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_navTitle22: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_navTitle31: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_navTitle32: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vippayRatio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vippayTag: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_banks: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_goods: we.ui.List = null;

    @we.ui.ccBind(cc.PageView)
    public RC_page_index: cc.PageView = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_realAmount: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_scratch_tips: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_guideIcon: cc.Sprite = null;

    @we.ui.ccBind(cc.ToggleContainer)
    public RC_toggleContainer_nav: cc.ToggleContainer = null;

    @we.ui.ccBind(cc.Node)
    public RC_vippay: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_vippayPanel: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_vippayRatio: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_vippayTag: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_scratch_realAmount: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private viewIndex = {
        TOP_UP: 0,
        VIP_PAY: 1,
        OFFLINE: 2,
    };
    private toggleIndex = this.viewIndex.TOP_UP;

    private channelConf: ApiProto.RechargeTypeCategory[] = [];
    private channelLimit = channelMaxShow;
    private channelIndex = 0;

    private rechargeAmount: number = 0; // 充值数量
    private curPayType: number = 0; // 支付类型
    private isVipPayData = false; // VIP充值数据是否加载

    protected onLoad(): void {
        this.RC_toggleContainer_nav.node.active = false;
        this.RC_btnRecharge.active = false;
        this.RC_btnChoose.active = false;
        this.RC_page_index.node.active = false;
        this.RC_list_banks.enabled = false;
        this.RC_list_banks.scrollView.enabled = false;
        this.RC_list_goods.enabled = false;
        this.RC_list_goods.scrollView.enabled = false;
        this.RC_lab_giveAmount.string = we.common.storeMgr.formatPrice(0);
        this.RCN_scratch_realAmount.active = false;
        this.RC_rich_scratch_tips.setStringFormat(we.core.langMgr.getLangText(HallLanguage.TOPUP_WINDOW_4), ` ${we.core.langMgr.getLangText(HallLanguage.TOPUP_WINDOW_5)}`);
        this.RC_rich_scratch_tips.node.active = false;
        this.RC_rich_realAmount.node.active = false;
        this.RC_lab_bankCardTips.node.active = false;

        const nodeGray = this.RC_btnRecharge.addComponentUnique(we.ui.WENodeGray);
        nodeGray.setGrayMaterial(we.common.res.material.gray);

        this.RC_list_banks.setRenderEvent(we.core.Func.create(this.onRenderBankItem, this));
        this.RC_list_banks.setSelectedEvent(we.core.Func.create(this.onSelectBankItem, this));
        this.RC_list_goods.setRenderEvent(we.core.Func.create(this.onRenderGoodsItem, this));
        this.RC_list_goods.setSelectedEvent(we.core.Func.create(this.onSelectGoodsItem, this));

        this.RC_page_index.node.on('page-turning', this.onPageViewIndex, this);

        this.onEditBoxEvent(this.RC_editbox_amount.node, 'editingDidBegan', this.onInputBegin.bind(this));
        this.onEditBoxEvent(this.RC_editbox_amount.node, 'editingDidEnded', this.onInputEnd.bind(this));
        this.onToggle(this.RC_toggleContainer_nav.node, we.core.Func.create(this.onToggleChannelNav, this), ['TOP_UP', 'VIP_PAY', 'OFFLINE']);

        this.onBtnClick(this.RC_btnRecharge, we.core.Func.create(this.onClickRecharge, this)).setSleepTime(1.5);
        this.onBtnClick(this.RC_btnOrder, we.core.Func.create(this.onClickOrder, this)).setSleepTime(1.5);
        this.onBtnClick(this.RC_btnService, we.core.Func.create(this.onClickService, this)).setSleepTime(1.5);
        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRule, this)).setSleepTime(1.5);
        this.onBtnClick(this.RC_clear, we.core.Func.create(this.onClickClearAmount, this));
        this.onBtnClick(this.RC_btnChoose, we.core.Func.create(this.onClickChooseBank, this)).setSleepTime(1.5);

        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);
        cc.director.on(we.common.EventName.UPDATE_PAY_CHANNEL, this.onChangePayChannel, this);
        cc.director.on(we.common.EventName.STORE_COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.on(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);

        if (!(we.common.userMgr.vipExp.level >= 2)) {
            we.currentUI.show(HallViewId.StoreTipsDlg);
        }
        this.onToggleChannelNav(null, 'TOP_UP');
    }

    protected onDestroy() {
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);
        cc.director.off(we.common.EventName.UPDATE_PAY_CHANNEL, this.onChangePayChannel, this);
        cc.director.off(we.common.EventName.STORE_COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.off(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
    }

    protected onEnable() {
        this.isVipPayData = false;
        this.init();
        const nodeGray = this.RC_btnRecharge.addComponentUnique(we.ui.WENodeGray);
        if (nodeGray.isGray) {
            nodeGray.setGray(true, true);
        }
    }

    public init() {
        const showLoading = this.channelConf.length <= 0;
        we.common.storeMgr.getShopConfig(
            (data: ApiProto.ShopConfResp) => {
                if (!data || !cc.isValid(this.node)) {
                    return;
                }

                this.RC_page_index.node.active = true;

                const channel = (data.rechargeTypeCategory || []).filter((item) => {
                    return item.payType !== we.common.payMgr.PAY_TYPE.VIP_PAY && item.payType != we.common.payMgr.PAY_TYPE.OFFLINE;
                });

                // 与当前数据一致时，不刷新 UI
                if (we.npm.lodash.isEqual(channel, this.channelConf) && channel?.length > 0 && this.toggleIndex == this.viewIndex.TOP_UP) {
                    return;
                }

                if (we.common.storeMgr.prefillAmount > 0) {
                    this.setPreFilledAmount(we.common.storeMgr.prefillAmount);
                }

                this.channelConf = channel;

                this.renderChannelNav();
                this.onToggleChannelNav(null, this.toggleIndex);

                this.RC_list_banks.selectedId = -1;
                this.channelLimit = channelMaxShow;
                if (channel.length <= this.channelLimit) {
                    this.channelLimit = 0;
                    this.RC_list_banks.numItems = channel.length;
                } else {
                    this.RC_list_banks.numItems = this.channelLimit;
                }
                this.RC_list_banks.selectedId = this.channelIndex;
                if (this.toggleIndex === this.viewIndex.TOP_UP) {
                    this.setNormalChannel();
                }
                let leftTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000) - we.common.storeMgr.shopConf.rechargeGiftExpireTime;
                if (leftTime > 0 && leftTime < 12 * 60 * 60) {
                    this.scheduleOnce(this.updatePenPenDeliveryRatio, leftTime);
                }
                this.scheduleOnce(() => {
                    this.RC_list_banks.node.height = this.RC_list_banks.content.height;
                }, 0);
            },
            null,
            showLoading
        );
        this.onUpdateUserInfo();
    }

    private setNormalChannel() {
        if (this.channelConf.length <= 0) {
            return;
        }
        let prefillAmount = we.common.storeMgr.prefillAmount;
        if (prefillAmount <= 0) {
            this.onSelectBankItem(null, this.channelIndex);
            this.setEditBoxAmount(prefillAmount);
            return;
        }
        let index = 0;
        for (let i = 0; i < this.channelConf.length; i++) {
            let data = this.channelConf[i];
            if (data.maxAmount >= prefillAmount && data.minAmount <= prefillAmount) {
                index = i;
                this.onSelectBankItem(null, i);
                break;
            }
        }
        this.scheduleOnce(() => {
            // 限制最低最高值
            const channel = this.channelConf[index];
            if (channel && prefillAmount) {
                if (prefillAmount < channel.minAmount) {
                    prefillAmount = channel.minAmount;
                } else if (prefillAmount > channel.maxAmount) {
                    prefillAmount = channel.maxAmount;
                }
            }
            if (prefillAmount > 0) {
                this.setEditBoxAmount(prefillAmount);
            }
        }, 0);
    }

    public onPageViewIndex() {
        const index = this.RC_page_index.getCurrentPageIndex();
        this.RC_toggleContainer_nav.toggleItems[index].isChecked = true;
    }

    public onRenderBankItem(node: cc.Node, idx: number) {
        const item = this.nodeAddComponent(node, StoreSelectItem_v);
        const isMore = this.channelLimit && idx + 1 === this.channelLimit;
        if (isMore) {
            item.renderPayType(null, isMore);
        } else {
            item.renderPayType(this.channelConf[idx], isMore);
        }
    }

    public onSelectBankItem(node: cc.Node, idx: number) {
        if (this.channelLimit && idx + 1 === this.channelLimit) {
            // 点击更多
            this.channelLimit = 0;
            this.RC_list_banks.numItems = this.channelConf.length;
            this.RC_list_banks.selectedId = this.channelIndex;

            this.scheduleOnce(() => {
                this.RC_list_banks.node.height = this.RC_list_banks.content.height;
            }, 0);
        } else {
            // 点击支付方式
            const channel = this.channelConf[idx];
            if (!channel) {
                return;
            }
            this.channelIndex = idx;
            this.curPayType = channel.payType;
            this.RC_list_goods.numItems = channel.amounts.length;
            /** 选择支付方式时，清空充值金额 */
            this.RC_list_goods.selectedId = -1;
            this.setEditBoxAmount();

            const isScratchCardsPay = we.common.payMgr.isScratchCardsPay(channel.payType);
            this.RCN_scratch_realAmount.active = isScratchCardsPay;
            this.RC_rich_scratch_tips.node.active = isScratchCardsPay;
            this.RC_lab_bankCardTips.node.active = channel.payType == we.common.payMgr.PAY_TYPE.BANK_IDR;

            if (channel.banks && channel.banks.length > 0) {
                this.RC_btnChoose.active = true;
                this.RC_btnRecharge.active = false;
            } else if (channel.amounts && channel.amounts.length > 0) {
                this.RC_btnChoose.active = false;
                this.RC_btnRecharge.active = true;
            }

            if (this.RC_list_banks.selectedId !== idx) {
                this.RC_list_banks.selectedId = idx;
            }
        }
    }

    public onRenderGoodsItem(node: cc.Node, idx: number) {
        const item = this.nodeAddComponent(node, StoreGoodsItem_v);
        const channel = this.channelConf[this.channelIndex];
        const amount = channel.amounts[idx];
        const isAvailable = channel.minAmount <= amount && amount <= channel.maxAmount;
        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(amount, channel);
        item.renderUI({ amount, isAvailable, amountScale }, idx);
    }

    public onSelectGoodsItem(node: cc.Node, idx: number) {
        const channel = this.channelConf[this.channelIndex];
        if (!channel) {
            return;
        }
        const amount = channel.amounts[idx];
        if (!amount) {
            return;
        }
        this.setEditBoxAmount(amount);
    }

    // 刷新笔笔送活动充值赠送比率
    public updatePenPenDeliveryRatio() {
        let children = this.RC_list_banks.content.children || [];
        for (let i = 0; i < children.length; i++) {
            const node = children[i];
            if (!cc.isValid(node)) {
                continue;
            }
            const item = node.addComponentUnique(StoreSelectItem_v);
            item.updateAddRatio();
        }
        this.onSelectBankItem(null, this.channelIndex);
        this.renderVipPayTagAndRatio();
    }

    /**
     * 渲染vip支付推荐和笔笔送比例
     */
    public renderVipPayTagAndRatio() {
        if (!cc.isValid(this.RC_vippayTag) || !cc.isValid(this.RC_vippayRatio)) {
            return;
        }
        const channel = we.common.storeMgr.getPayChannelConf(we.common.payMgr.PAY_TYPE.VIP_PAY);
        if (!channel) {
            this.RC_vippayTag.active = false;
            this.RC_vippayRatio.active = false;
            return;
        }
        // 笔笔送比例
        const curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
        this.RC_vippayRatio.active = channel.rechargeGiftScale > 0 && curTime < we.common.storeMgr.shopConf.rechargeGiftExpireTime;
        this.RC_lab_vippayRatio.string = `+${channel.rechargeGiftScale / 100}%`;

        // 推荐标签
        let langKey = '';
        let index = -1;
        // 0 默认 1 推荐 2 大额 3 便捷
        switch (channel.tag) {
            case 1:
                langKey = HallLanguage.RECHARGE_SUB_TJ;
                index = 0;
                break;
            case 2:
                langKey = HallLanguage.RECHARGE_SUB_DE;
                index = 1;
                break;
            case 3:
                langKey = HallLanguage.RECHARGE_SUB_BJ;
                index = 2;
                break;
            default:
                break;
        }
        if (langKey && index > -1) {
            this.RC_vippayTag.active = true;
            this.RC_lab_vippayTag.string = we.core.langMgr.getLangText(langKey);
            this.RC_vippayPanel.addComponentUnique(we.ui.WESpriteIndex).index = index;
            this.RC_vippayTag.active = true;
        } else {
            this.RC_vippayTag.active = false;
        }
    }

    public renderChannelNav() {
        let vipPay;
        let offlinePay;
        let toggles = {
            vipPay: this.viewIndex.VIP_PAY,
            offline: this.viewIndex.OFFLINE,
        };
        const channelConf = we.common.storeMgr.shopConf.rechargeTypeCategory || [];
        channelConf.forEach((item) => {
            if (item.payType === we.common.payMgr.PAY_TYPE.VIP_PAY) {
                vipPay = item;
            } else if (item.payType === we.common.payMgr.PAY_TYPE.OFFLINE) {
                offlinePay = item;
            }
        });
        this.RC_toggleContainer_nav.node.active = true;

        if (vipPay) {
            this.RC_lab_navTitle21.string = vipPay.name;
            this.RC_lab_navTitle22.string = vipPay.name;
            this.renderVipPayTagAndRatio();
        } else {
            this.RC_toggleContainer_nav.toggleItems[toggles.vipPay]?.node.destroy();
            this.RC_page_index.removePageAtIndex(this.viewIndex.VIP_PAY);
            this.viewIndex.VIP_PAY = -1;
            this.viewIndex.OFFLINE = 1;
        }

        if (offlinePay) {
            this.RC_lab_navTitle31.string = offlinePay.name;
            this.RC_lab_navTitle32.string = offlinePay.name;
        } else {
            this.RC_toggleContainer_nav.toggleItems[toggles.offline]?.node.destroy();
            this.RC_page_index.removePageAtIndex(this.viewIndex.OFFLINE);
            this.viewIndex.OFFLINE = -1;
        }
    }

    private onInputBegin(): void {
        this.RC_editbox_amount.placeholderLabel.string = ``;
    }

    private onInputEnd(): void {
        let content = this.RC_editbox_amount.string;
        let amount = parseInt(content);
        if (amount > 0) {
            this.setEditBoxAmount(amount * we.core.flavor.getPricePrecision());
        } else {
            this.setEditBoxAmount();
        }

        let curPayTypeInfo = this.channelConf[this.channelIndex];
        if (!curPayTypeInfo) {
            return;
        }
        if (curPayTypeInfo.banks && curPayTypeInfo.banks.length > 0) {
            if (amount <= 0) {
                this.setEditBoxAmount();
            }
        } else {
            if (!(this.rechargeAmount >= curPayTypeInfo.minAmount && this.rechargeAmount <= curPayTypeInfo.maxAmount)) {
                this.setEditBoxAmount();
                this.RC_editbox_amount.placeholderLabel.string = `${we.common.utils.formatPrice(curPayTypeInfo.minAmount, false, false)} ~ ${we.common.utils.formatPrice(curPayTypeInfo.maxAmount, false, false)}`;
                if (content != ``) {
                    let content = we.core.langMgr.getLangText(
                        HallLanguage.SHOP_RECHARGE_18,
                        we.common.utils.formatPrice(curPayTypeInfo.minAmount, false, false),
                        we.common.utils.formatPrice(curPayTypeInfo.maxAmount, false, false)
                    );
                    we.commonUI.showToast(content);
                }
            }
        }

        this.renderGiveAwayAmount(curPayTypeInfo);
    }

    public onClickClearAmount() {
        this.setEditBoxAmount(0);
    }

    public onToggleChannelNav(toggle: cc.Toggle | null, key: string | number) {
        if (toggle) {
            we.common.commonMgr.playBtnMusic();
        }
        this.RC_btnRule.active = true;
        this.RC_btnChoose.active = false;
        this.RC_btnRecharge.active = true;

        let index = -1;
        if (typeof key === 'string') {
            index = this.viewIndex[key];
        } else if (typeof key === 'number') {
            index = key;
        }

        if (index < 0) {
            return;
        }

        switch (index) {
            case this.viewIndex.TOP_UP:
                this.setRechargeBtnGray(false);
                this.onSelectBankItem(null, this.channelIndex);
                break;
            case this.viewIndex.VIP_PAY:
                {
                    const vipPay = this.RC_vippay && this.RC_vippay.getComponent(StoreVipPay_v);
                    vipPay.setSelectEvent(
                        we.core.Func.create(() => {
                            this.setRechargeBtnGray(vipPay.RC_list_vipGoods.selectedId == -1);
                        }, this)
                    );
                    vipPay.init(!this.isVipPayData);
                    this.isVipPayData = true;
                }
                break;
            case this.viewIndex.OFFLINE:
                this.RC_btnRule.active = false;
                this.setRechargeBtnGray(false);
                break;
            default:
                break;
        }

        if (!this.RC_toggleContainer_nav.toggleItems[index].isChecked) {
            this.RC_toggleContainer_nav.toggleItems[index].isChecked = true;
        }
        if (this.RC_page_index.getCurrentPageIndex() != index) {
            this.RC_page_index.setCurrentPageIndex(index);
        }
        this.toggleIndex = index;
    }

    private setEditBoxAmount(amount = 0): void {
        this.rechargeAmount = amount;
        if (amount <= 0) {
            this.RC_editbox_amount.string = ``;
        } else {
            this.RC_editbox_amount.string = amount / we.core.flavor.getPricePrecision() + '';
            this.RC_editbox_amount.textLabel.string = we.common.utils.formatPrice(this.rechargeAmount, true, false);
        }

        let curPayTypeInfo = this.channelConf[this.channelIndex];
        if (!curPayTypeInfo) {
            return;
        }

        this.setRechargeBtnGray(false);
        if (we.common.payMgr.isScratchCardsPay(curPayTypeInfo.payType)) {
            const { realAmount, feesDesc } = we.common.storeMgr.getScratchCardsFees(amount, curPayTypeInfo);

            if (amount > 0 && realAmount != amount) {
                this.RC_rich_realAmount.node.active = true;
                this.RC_rich_realAmount.setStringFormat(we.core.langMgr.getLangText(HallLanguage.TOPUP_WINDOW_3), we.common.utils.formatPrice(realAmount, true, false), feesDesc);
            } else {
                this.RC_rich_realAmount.node.active = false;
            }

            if (realAmount <= 0) {
                this.setRechargeBtnGray(true);
            }
        }

        this.RC_editbox_amount.placeholderLabel.string = `${we.common.utils.formatPrice(curPayTypeInfo.minAmount, false, false)} ~ ${we.common.utils.formatPrice(curPayTypeInfo.maxAmount, false, false)}`;
        this.renderGiveAwayAmount(curPayTypeInfo);

        const index = curPayTypeInfo.amounts.findIndex((item) => {
            return item === amount;
        });
        if (this.RC_list_goods.selectedId === index) {
            return;
        }
        this.RC_list_goods.selectedId = index;
    }

    private renderGiveAwayAmount(payTypeInfo?: ApiProto.RechargeTypeCategory) {
        if (!payTypeInfo) {
            payTypeInfo = this.channelConf[this.channelIndex];
        }
        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(this.rechargeAmount, payTypeInfo);
        this.RC_lab_giveAmount.string = we.common.storeMgr.formatPrice(amountScale.amount, true, false);
    }

    private getCurPayType() {
        let payType = this.curPayType;
        const index = this.RC_page_index.getCurrentPageIndex();
        if (index === this.viewIndex.VIP_PAY) {
            payType = we.common.payMgr.PAY_TYPE.VIP_PAY;
        } else if (index === this.viewIndex.OFFLINE) {
            payType = we.common.payMgr.PAY_TYPE.OFFLINE;
        }
        return payType;
    }

    private onClickRecharge(): void {
        const payType = this.getCurPayType();
        const payTypeInfo = we.common.storeMgr.getPayChannelConf(payType);
        if (payTypeInfo) {
            if (payTypeInfo.formalRequired && !we.common.userMgr.isRealName()) {
                we.currentUI.show(HallViewId.UserCenterRealNameDlg);
                return;
            }
            if (payTypeInfo.payType === we.common.payMgr.PAY_TYPE.VIP_PAY) {
                // vip支付
                const vipPay = this.RC_vippay && this.RC_vippay.getComponent(StoreVipPay_v);
                if (vipPay) {
                    vipPay.createRechargeOrder();
                }
            } else if (payTypeInfo.payType === we.common.payMgr.PAY_TYPE.OFFLINE) {
                // 线下支付
                let url = payTypeInfo.offlinePayH5Url;
                if (url?.includes('http')) {
                    url += `&skin=${we.core.flavor.getSkinCode()}&lang=${we.core.langMgr.getCurLangCode()}&aid=${we.core.nativeUtil.getDeviceId()}`;
                    we.core.nativeUtil.openUrl(url);
                } else {
                    we.common.commonMgr.openCustomerDialog();
                }
            } else {
                // 普通支付
                if (this.rechargeAmount == 0) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_17));
                    return;
                }
                if (!(this.rechargeAmount >= payTypeInfo.minAmount && this.rechargeAmount <= payTypeInfo.maxAmount)) {
                    let content = we.core.langMgr.getLangText(
                        HallLanguage.SHOP_RECHARGE_18,
                        we.common.utils.formatPrice(payTypeInfo.minAmount, false, false),
                        we.common.utils.formatPrice(payTypeInfo.maxAmount, false, false)
                    );
                    we.commonUI.showToast(content);
                    return;
                }

                we.common.storeMgr.CheckOrder(() => {
                    // 3. 发起订单请求
                    let amount = (this.rechargeAmount / we.core.flavor.getPricePrecision()) * we.core.flavor.getAmountPrecision();
                    we.common.payMgr.getOrderInfo(we.common.storeMgr.goodsId, this.curPayType, ``, amount);
                });
            }
        } else {
            we.warn(`StoreDialog_v onClickRecharge, payTypeInfo is null`);
        }
    }

    private onClickOrder(): void {
        we.common.storeMgr.getOrderList((data: ApiProto.GetOrderListResp) => {
            if (!cc.isValid(this.node) || !data) {
                return;
            }
            let orderRecord = data.orderList || [];
            if (orderRecord.length > 0) {
                we.currentUI.show(HallViewId.StorePayOrderDlg, data.orderList);
            } else {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.MAIL_NO));
            }
        });
    }

    private onClickService(): void {
        we.common.commonMgr.openCustomerDialog();
    }

    private onClickRule(): void {
        const payType = this.getCurPayType();
        if (payType === we.common.payMgr.PAY_TYPE.VIP_PAY) {
            we.currentUI.show(HallViewId.StoreVipPayRuleDlg);
        } else {
            const payTypeInfo = this.channelConf[this.channelIndex];
            const guideUrl = we.common.storeMgr.shopConf.payTypeGuideUrl;
            if (typeof guideUrl == 'string' && guideUrl.length > 0) {
                const url = guideUrl + `?pay=${payTypeInfo.payType}&lang=${we.core.langMgr.getCurLangCode()}`;
                we.core.nativeUtil.openUrl(url);
            }
        }
    }

    private onUpdateUserInfo(): void {
        if (!cc.isValid(this.node)) {
            return;
        }
        const coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
        this.RC_lab_amount.string = we.common.utils.formatAmountCurrency(coin);
    }

    private onClickChooseBank() {
        HallMgr.openStoreBankSelectDlg(this.curPayType, this.rechargeAmount);
    }

    private onChangePayChannel(channel: number) {
        if (channel === we.common.payMgr.PAY_TYPE.VIP_PAY) {
            this.onToggleChannelNav(null, this.viewIndex.VIP_PAY);
        } else if (channel === we.common.payMgr.PAY_TYPE.OFFLINE) {
            this.onToggleChannelNav(null, this.viewIndex.OFFLINE);
        } else {
            this.onToggleChannelNav(null, this.viewIndex.TOP_UP);
            const index = this.channelConf.findIndex((item) => {
                return item.payType === channel;
            });
            this.onSelectBankItem(null, index);
        }
    }

    protected setPreFilledAmount(amount = 0) {
        this.setNormalChannel();
        this.setEditBoxAmount(amount);

        // 重置预填充充值数量
        we.common.storeMgr.prefillAmount = 0;
    }

    public setRechargeBtnGray(isActive = false) {
        const nodeGray = this.RC_btnRecharge.getComponent(we.ui.WENodeGray);
        nodeGray.setGray(isActive, true);
        const btn = this.RC_btnRecharge.getComponent(cc.Button);
        btn.interactable = !isActive;
    }

    private coinFlyAnim(params: { node: cc.Node; award: number }) {
        HallMgr.coinFlyAnim(params, this.node, this.RC_lab_amount.node, false);
    }
}
