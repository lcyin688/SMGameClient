import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import StoreBankItem_v from './StoreBankItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('StoreBankDlgView_v', we.bundles.hall)
class StoreBankDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnChoose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RCN_animRoot: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('StoreBankDlg_v', we.bundles.hall)
export class StoreBankDlg_v extends we.ui.DlgSystem<StoreBankDlgView_v> {
    /** 支付类型 */
    private payType: number = 0;
    /** 充值数量 */
    private rechargeAmount: number = 0;
    /** 当前选择银行 */
    private curBank: string = ``;
    /** 银行列表 */
    private bankList: ApiProto.Banks[];
    /** 回掉函数 */
    private callBack: Function = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list.setSelectedEvent(we.core.Func.create(this.onSelectEvent, this));

        this.view.cc_onBtnClick(this.view.RC_btnChoose, we.core.Func.create(this.onClickRecharge, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.view.RCN_animRoot.setPosition(cc.v2(0, -this.view.RCN_animRoot.height));
    }

    /** 显示窗口 */
    public async onShow(showData: { data: number | ApiProto.Banks; amount: number; callback?: Function }) {
        if (!showData) {
            this.closeView();
            return;
        }
        this.rechargeAmount = showData.amount;
        this.callBack = showData.callback;
        if (typeof showData.data == 'number') {
            this.payType = showData.data;
            this.processNumberPayType();
        } else if (Array.isArray(showData.data)) {
            this.bankList = showData.data;
            this.view.RC_list.numItems = this.bankList.length;
        } else {
            we.warn('StoreBankDlg_v onShow, param error', showData.data);
            this.closeView();
        }
    }

    public onShowAnimation(): Promise<void> {
        return new Promise((res) => {
            let animNode = this.view.RCN_animRoot;
            animNode.stopAllActions();
            animNode.setPosition(cc.v2(0, -animNode.height));

            this.tween(animNode)
                .to(0.3, { position: cc.v2(0, 0) })
                .call(() => {
                    res();
                })
                .start();
        });
    }

    public onHideAnimation(): Promise<void> {
        return new Promise((res) => {
            let animNode = this.view.RCN_animRoot;
            animNode.stopAllActions();
            animNode.setPosition(cc.v2(0, 0));

            this.tween(animNode)
                .to(0.2, { position: cc.v2(0, -animNode.height) })
                .call(() => {
                    res();
                })
                .start();
        });
    }

    private processNumberPayType(): void {
        let payTypeInfo = we.common.storeMgr.getPayChannelConf(this.payType);
        if (!payTypeInfo) {
            return;
        }
        if (payTypeInfo.banks && payTypeInfo.banks.length > 0) {
            let bankList = [];
            if (payTypeInfo && payTypeInfo.banks) {
                let bankListTemp = payTypeInfo.banks;
                bankList = bankListTemp.sort((a, b) => {
                    return a.minAmount - b.minAmount;
                });
            }
            this.bankList = bankList;
            this.view.RC_list.numItems = this.bankList.length;
        }
    }

    protected onRenderEvent(node: cc.Node, i: number) {
        const bank = this.bankList[i];
        const item = node.addComponentUnique(StoreBankItem_v);
        item.init(bank);
    }

    protected onSelectEvent(node: cc.Node, i: number) {
        const bank = this.bankList[i];
        this.curBank = bank.name;
    }

    /** 选择充值 */
    private onClickRecharge(): void {
        if (typeof this.callBack == `function`) {
            if (!(typeof this.curBank == `string` && this.curBank.length > 0)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_15));
                return;
            }
            this.callBack(this.curBank);
            this.closeView();
            return;
        }

        let payTypeInfo = we.common.storeMgr.getPayChannelConf(this.payType);
        if (payTypeInfo) {
            // 判定是否输入充值金额
            if (this.rechargeAmount == 0) {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_17));
                return;
            }
            // 判断是否需要选择银行
            if (payTypeInfo.banks && payTypeInfo.banks.length > 0) {
                if (this.curBank.length < 1) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_15));
                    return;
                } else {
                    // 判定充值区间是否合法
                    let data = this.getBanInfoByName(this.curBank, payTypeInfo.banks);
                    if (!(this.rechargeAmount >= data.minAmount && this.rechargeAmount <= data.maxAmount)) {
                        let content = we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_18, we.common.utils.formatPrice(data.minAmount, false, false), we.common.utils.formatPrice(data.maxAmount, false, false));
                        we.commonUI.showToast(content);
                        return;
                    }
                }
            }
            // 3. 发起订单请求
            we.common.storeMgr.CheckOrder(() => {
                let amount = (this.rechargeAmount / we.core.flavor.getPricePrecision()) * we.core.flavor.getAmountPrecision();
                we.common.payMgr.getOrderInfo(we.common.storeMgr.goodsId, this.payType, this.curBank, amount);
            });
        } else {
            we.warn(`StoreBankDlg_v onClickRecharge, payTypeInfo is null`);
        }
    }

    // 获取 银行信息
    private getBanInfoByName(name: string, bankList: ApiProto.Banks[]): ApiProto.Banks {
        let bankInfo = null;
        if (typeof name == `string` && name.length > 0 && bankList && bankList.length > 0) {
            for (let i = 0; i < bankList.length; i++) {
                if (bankList[i].name == name) {
                    bankInfo = bankList[i];
                    break;
                }
            }
        }
        return bankInfo;
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(StoreBankDlg_v, `${HallViewId.StoreBankDlg}_v`)
class StoreBankDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(StoreBankDlg_v, uiBase.addComponent(StoreBankDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreBankDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<StoreBankDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(StoreBankDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreBankDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(StoreBankDlg_v).beforeUnload();
    }

    async onShowAnimation(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreBankDlg_v).onShowAnimation();
    }

    async onHideAnimation(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreBankDlg_v).onHideAnimation();
    }
}
