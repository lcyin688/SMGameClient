import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import StoreGoodsItem_h from './StoreGoodsItem_h';
import StorePayItem_h from './StorePayItem_h';
import StoreScratchCardsPay_h from './StoreScratchCardsPay_h';

enum ViewIndex {
    TOP_UP = 1,
    VIP_PAY = 2,
    OFFLINE = 3,
    SCRATCHCARDS_PAY = 4,
}

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('StoreDlgView_h', we.bundles.hall)
class StoreDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_arrowLeft: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_arrowRight: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnChoose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClear: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGuide: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnJump: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnOrder: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRecharge: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnService: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_custom_amount: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_amount: cc.EditBox = null;

    @we.ui.ccBind(cc.Node)
    public RC_give_away: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_guide: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_guideTitle: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_bankCardTips: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_giveAmount: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_goods: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_pay: we.ui.List = null;

    @we.ui.ccBind(we.ui.WESwitchPage)
    public RC_page: we.ui.WESwitchPage = null;

    @we.ui.ccBind(cc.Node)
    public RC_scratchCardPay: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('StoreDlg_h', we.bundles.hall)
export class StoreDlg_h extends we.ui.DlgSystem<StoreDlgView_h> {
    private channelConf: ApiProto.RechargeTypeCategory[] = [];
    private channelIndex = 0;
    private rechargeAmount: number = 0; // 充值数量
    private curPayType: number = 0; // 支付类型

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_list_pay.setRenderEvent(we.core.Func.create(this.onRenderPayItem, this));
        this.view.RC_list_pay.setSelectedEvent(we.core.Func.create(this.onSelectPayItem, this));
        this.view.RC_list_goods.setRenderEvent(we.core.Func.create(this.onRenderGoodsItem, this));
        this.view.RC_list_goods.setSelectedEvent(we.core.Func.create(this.onSelectGoodsItem, this));
        this.view.RC_list_pay.node.on('scrolling', this.onScrollingPayList, this);

        this.view.cc_onBtnClick(this.view.RC_btnGuide, we.core.Func.create(this.onClickRule, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnRule, we.core.Func.create(this.onClickRule, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_amount.node, 'editingDidBegan', we.core.Func.create(this.onInputAmountBegin, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_amount.node, 'editingDidEnded', we.core.Func.create(this.onInputAmountEnd, this));
        this.view.cc_onBtnClick(this.view.RC_btnRecharge, we.core.Func.create(this.onClickRecharge, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClear, we.core.Func.create(this.onClickClearAmount, this));
        this.view.cc_onBtnClick(this.view.RC_btnChoose, we.core.Func.create(this.onClickChooseBank, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnOrder, we.core.Func.create(this.onClickOrder, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnService, we.core.Func.create(this.onClickService, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnJump, we.core.Func.create(this.onClickJump, this)).setSleepTime(1.5);

        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);
        cc.director.on(we.common.EventName.UPDATE_PAY_CHANNEL, this.onChangePayChannel, this);
        cc.director.on(we.common.EventName.STORE_COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.on(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);

        if (!(we.common.userMgr.vipExp.level >= 2)) {
            we.currentUI.show(HallViewId.StoreTipsDlg);
        }
    }

    public beforeUnload() {}

    protected destroy() {
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.onUpdateUserInfo, this);
        cc.director.off(we.common.EventName.UPDATE_PAY_CHANNEL, this.onChangePayChannel, this);
        cc.director.off(we.common.EventName.STORE_COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.off(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: { prefillAmount: number }) {
        this.view.RC_lab_giveAmount.string = we.common.storeMgr.formatPrice(0, true, true);
        if (showData && showData.prefillAmount > 0) {
            we.common.storeMgr.prefillAmount = showData.prefillAmount;
        }
        this.init();
    }

    protected init() {
        this.view.RC_page.index = 0;
        this.view.RC_lab_bankCardTips.node.active = false;

        we.common.storeMgr.getShopConfig(
            (data: ApiProto.ShopConfResp) => {
                if (!data || !this.isValid()) {
                    return;
                }

                const channel = data.rechargeTypeCategory || [];
                if (we.npm.lodash.isEqual(channel, this.channelConf) && channel?.length > 0) {
                    return;
                }

                if (we.common.storeMgr.prefillAmount > 0) {
                    this.setPreFilledAmount(we.common.storeMgr.prefillAmount);
                }

                this.channelConf = channel;
                this.view.RC_list_pay.numItems = channel.length;
                this.setNormalPayChannel();
                this.initSlidArrow();

                let leftTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000) - we.common.storeMgr.shopConf.rechargeGiftExpireTime;
                if (leftTime > 0 && leftTime < 12 * 60 * 60) {
                    this.scheduleOnce(leftTime).then(() => {
                        this.updatePenPenDeliveryRatio();
                    });
                }
            },
            null,
            true
        );

        this.onUpdateUserInfo();
    }

    private initSlidArrow() {
        if (!(this.view.RC_arrowRight && this.view.RC_arrowRight)) {
            return;
        }
        cc.Tween.stopAllByTarget(this.view.RC_arrowRight);
        new cc.Tween(this.view.RC_arrowRight).repeatForever(new cc.Tween().by(1, { position: cc.v2(20, 0) }, { easing: 'quadIn' }).by(1.2, { position: cc.v2(-20, 0) }, { easing: 'quadOut' })).start();
        cc.Tween.stopAllByTarget(this.view.RC_arrowLeft);
        new cc.Tween(this.view.RC_arrowLeft).repeatForever(new cc.Tween().by(1, { position: cc.v2(-20, 0) }, { easing: 'quadIn' }).by(1.2, { position: cc.v2(20, 0) }, { easing: 'quadOut' })).start();

        this.view.RC_arrowLeft.active = false;
        this.view.RC_arrowRight.active = this.view.RC_list_pay.scrollView.content.width > this.view.RC_list_pay.node.width + 5 ? true : false;
    }

    private onScrollingPayList() {
        if (this.view.RC_arrowRight && this.view.RC_arrowRight) {
            const RC_list_pay = this.view.RC_list_pay;
            if (RC_list_pay.scrollView.content.width <= RC_list_pay.node.width + 5) {
                return;
            }
            let offset_max = RC_list_pay.scrollView.getMaxScrollOffset().x;
            let offset_cur = Math.abs(RC_list_pay.scrollView.getScrollOffset().x);
            this.view.RC_arrowLeft.active = offset_cur > 20 ? true : false;
            this.view.RC_arrowRight.active = offset_cur < offset_max - 20 ? true : false;
        }
    }

    private onUpdateUserInfo(): void {
        if (!this.isValid()) {
            return;
        }
        const coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
        this.view.RC_lab_amount.string = we.common.utils.formatAmountCurrency(coin);
    }

    private onInputAmountBegin(): void {
        this.view.RC_edit_amount.placeholderLabel.string = ``;
    }

    private onInputAmountEnd(): void {
        let content = this.view.RC_edit_amount.string;
        let amount = parseInt(content);
        if (amount > 0) {
            this.setEditBoxAmount(amount * we.core.flavor.getPricePrecision());
        } else {
            this.setEditBoxAmount();
        }

        let curPayTypeInfo = this.channelConf[this.channelIndex];
        if (!curPayTypeInfo) {
            return;
        }
        if (curPayTypeInfo.banks && curPayTypeInfo.banks.length > 0) {
            if (amount <= 0) {
                this.setEditBoxAmount();
            }
        } else {
            if (!(this.rechargeAmount >= curPayTypeInfo.minAmount && this.rechargeAmount <= curPayTypeInfo.maxAmount)) {
                this.setEditBoxAmount();
                this.view.RC_edit_amount.placeholderLabel.string = `${we.common.utils.formatPrice(curPayTypeInfo.minAmount, false, false)} ~ ${we.common.utils.formatPrice(curPayTypeInfo.maxAmount, false, false)}`;
                if (content != ``) {
                    let content = we.core.langMgr.getLangText(
                        HallLanguage.SHOP_RECHARGE_18,
                        we.common.utils.formatPrice(curPayTypeInfo.minAmount, false, false),
                        we.common.utils.formatPrice(curPayTypeInfo.maxAmount, false, false)
                    );
                    we.commonUI.showToast(content);
                }
            }
        }

        this.renderGiveAwayAmount(curPayTypeInfo);
    }

    private setEditBoxAmount(amount = 0): void {
        this.rechargeAmount = amount;
        if (amount <= 0) {
            this.view.RC_edit_amount.string = ``;
        } else {
            this.view.RC_edit_amount.string = amount / we.core.flavor.getPricePrecision() + '';
            this.view.RC_edit_amount.textLabel.string = we.common.utils.formatPrice(this.rechargeAmount, true, false);
        }

        let curPayTypeInfo = this.channelConf[this.channelIndex];
        if (!curPayTypeInfo) {
            return;
        }
        this.view.RC_edit_amount.placeholderLabel.string = `${we.common.utils.formatPrice(curPayTypeInfo.minAmount, false, false)} ~ ${we.common.utils.formatPrice(curPayTypeInfo.maxAmount, false, false)}`;
        this.renderGiveAwayAmount(curPayTypeInfo);

        const index = curPayTypeInfo.amounts.findIndex((item) => {
            return item === amount;
        });
        if (this.view.RC_list_goods.selectedId === index) {
            return;
        }
        this.view.RC_list_goods.selectedId = index;
    }

    private renderGiveAwayAmount(payTypeInfo?: ApiProto.RechargeTypeCategory) {
        if (!payTypeInfo) {
            payTypeInfo = this.channelConf[this.channelIndex];
        }
        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(this.rechargeAmount, payTypeInfo);
        let giveAmountStr = we.common.storeMgr.formatPrice(amountScale.amount, true, false);
        this.view.RC_lab_giveAmount.string = giveAmountStr;
    }

    protected setPreFilledAmount(amount = 0) {
        this.setNormalPayChannel();
        this.setEditBoxAmount(amount);

        // 重置预填充充值数量
        we.common.storeMgr.prefillAmount = 0;
    }

    protected onRenderPayItem(node: cc.Node, index: number) {
        const item = node.addComponentUnique(StorePayItem_h);
        const info = this.channelConf[index];
        item.init(info);
    }

    protected onSelectPayItem(node: cc.Node, index: number) {
        const info = this.channelConf[index];
        if (!info) {
            return;
        }
        this.curPayType = info.payType;
        this.view.RC_btnRule.active = false;
        this.view.RC_lab_bankCardTips.node.active = info.payType == we.common.payMgr.PAY_TYPE.BANK_IDR;
        if (info.payType === we.common.payMgr.PAY_TYPE.OFFLINE) {
            this.view.RC_page.index = ViewIndex.OFFLINE;
        } else if (info.payType === we.common.payMgr.PAY_TYPE.VIP_PAY) {
            this.view.RC_page.index = ViewIndex.VIP_PAY;
            this.view.RC_btnRule.active = true;
        } else if (we.common.payMgr.isScratchCardsPay(info.payType)) {
            this.channelIndex = index;
            this.view.RC_page.index = ViewIndex.SCRATCHCARDS_PAY;
            this.view.RC_btnRule.active = true;
            this.view.RC_scratchCardPay?.getComponent(StoreScratchCardsPay_h)?.initData(this.channelConf[this.channelIndex]);
        } else {
            this.channelIndex = index;
            this.view.RC_page.index = ViewIndex.TOP_UP;
            this.view.RC_list_goods.numItems = info.amounts.length;
            /** 选择支付方式时，清空充值金额 */
            this.view.RC_list_goods.selectedId = -1;
            this.setEditBoxAmount();
            this.view.RC_btnRule.active = true;
            if (info.banks && info.banks.length > 0) {
                this.view.RC_btnChoose.active = true;
                this.view.RC_btnRecharge.active = false;
            } else if (info.amounts && info.amounts.length > 0) {
                this.view.RC_btnRecharge.active = true;
                this.view.RC_btnChoose.active = false;
            }
            this.renderGuide();
        }
    }

    public onRenderGoodsItem(node: cc.Node, idx: number) {
        const item = node.addComponentUnique(StoreGoodsItem_h);
        const channel = this.channelConf[this.channelIndex];
        const amount = channel.amounts[idx];
        const isAvailable = channel.minAmount <= amount && amount <= channel.maxAmount;
        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(amount, channel);
        item.renderUI({ amount, isAvailable, amountScale }, idx);
    }

    public onSelectGoodsItem(node: cc.Node, idx: number) {
        const channel = this.channelConf[this.channelIndex];
        if (!channel) {
            return;
        }
        const amount = channel.amounts[idx];
        if (!amount) {
            return;
        }
        this.setEditBoxAmount(amount);
    }

    protected setNormalPayChannel() {
        if (this.channelConf.length <= 0) {
            return;
        }
        let index = 0;
        let prefillAmount = we.common.storeMgr.prefillAmount;
        for (let i = 0; i < this.channelConf.length; i++) {
            let data = this.channelConf[i];
            if (data.payType === we.common.payMgr.PAY_TYPE.OFFLINE) {
                continue;
            }
            if (prefillAmount <= 0) {
                index = i;
                break;
            }
            if (index === 0) {
                index = i;
            }
            if (data.maxAmount >= prefillAmount && data.minAmount <= prefillAmount) {
                index = i;
                break;
            }
        }
        // 限制最低最高值
        const channel = this.channelConf[index];
        if (channel && prefillAmount) {
            if (prefillAmount < channel.minAmount) {
                prefillAmount = channel.minAmount;
            } else if (prefillAmount > channel.maxAmount) {
                prefillAmount = channel.maxAmount;
            }
        }
        this.view.RC_list_pay.selectedId = index;
        this.onSelectPayItem(null, index);
        this.view.RC_edit_amount.placeholderLabel.string = `${we.common.utils.formatPrice(channel.minAmount, false, false)} ~ ${we.common.utils.formatPrice(channel.maxAmount, false, false)}`;

        if (prefillAmount > 0) {
            this.setEditBoxAmount(prefillAmount);
            we.common.storeMgr.prefillAmount = 0;
        }
    }

    // 设置当前支付类型banner展示
    protected renderGuide() {
        let noGuide = [we.common.payMgr.PAY_TYPE.VIP_PAY, we.common.payMgr.PAY_TYPE.OFFLINE];
        if (noGuide.includes(this.curPayType) || we.common.payMgr.isScratchCardsPay(this.curPayType)) {
            this.view.RC_guide.active = false;
            return;
        }

        let loadGuideSpr = () => {
            if (!cc.isValid(this.view.RC_guide) || !this.view.RC_guide.getComponent(cc.Sprite)) {
                return;
            }
            const path = HallRes.texture.guide_type + `${we.common.payMgr.isTestPay(this.curPayType) ? 'test' : this.curPayType}`;
            this.view.RC_guideTitle.active = we.common.payMgr.isTestPay(this.curPayType);
            this.view.RC_guide.active = true;
            we.common.utils.setComponentSprite(this.view.RC_guide, path, () => {
                if (cc.isValid(this.view.RC_guide) && this.view.RC_guide.opacity < 255) {
                    this.tween(this.view.RC_guide).to(0.3, { opacity: 255 }).start();
                }
            });
        };

        let cuSkin = we.core.flavor.getSkinCode();
        switch (cuSkin) {
            case we.core.SkinCode.bg:
            case we.core.SkinCode.ct3:
                loadGuideSpr();
                break;
            default:
                break;
        }
    }

    private onClickRule() {
        if (this.curPayType === we.common.payMgr.PAY_TYPE.VIP_PAY) {
            we.currentUI.show(HallViewId.StoreVipPayRuleDlg);
        } else {
            const payTypeInfo = this.channelConf[this.channelIndex];
            const guideUrl = we.common.storeMgr.shopConf.payTypeGuideUrl;
            if (typeof guideUrl == 'string' && guideUrl.length > 0) {
                const url = guideUrl + `?pay=${payTypeInfo.payType}&lang=${we.core.langMgr.getCurLangCode()}`;
                we.core.nativeUtil.openUrl(url);
            }
        }
    }

    private onClickJump(): void {
        let url: string = null;
        for (let i = 0; i < this.channelConf.length; i++) {
            if (this.channelConf[i].payType == we.common.payMgr.PAY_TYPE.OFFLINE) {
                url = this.channelConf[i].offlinePayH5Url;
                break;
            }
        }

        if (url?.includes('http')) {
            url += `&skin=${we.core.flavor.getSkinCode()}&lang=${we.core.langMgr.getCurLangCode()}&aid=${we.core.nativeUtil.getDeviceId()}`;
            we.core.nativeUtil.openUrl(url);
        } else {
            we.common.commonMgr.openCustomerDialog();
        }
    }

    private updatePenPenDeliveryRatio() {
        let children = this.view.RC_list_pay.content.children || [];
        for (let i = 0; i < children.length; i++) {
            let node = children[i];
            if (!cc.isValid(node)) {
                continue;
            }
            const item = node.addComponentUnique(StorePayItem_h);
            item.updateAddRatio();
        }
        this.onSelectPayItem(null, this.channelIndex);
    }

    private onClickRecharge(): void {
        const payTypeInfo = we.common.storeMgr.getPayChannelConf(this.curPayType);
        if (payTypeInfo) {
            if (payTypeInfo.formalRequired && !we.common.userMgr.isRealName()) {
                we.currentUI.show(HallViewId.UserCenterRealNameDlg);
                return;
            }
            if (payTypeInfo.payType === we.common.payMgr.PAY_TYPE.OFFLINE) {
                // 线下支付
                let url = payTypeInfo.offlinePayH5Url;
                if (url?.includes('http')) {
                    url += `&skin=${we.core.flavor.getSkinCode()}&lang=${we.core.langMgr.getCurLangCode()}&aid=${we.core.nativeUtil.getDeviceId()}`;
                    we.core.nativeUtil.openUrl(url);
                } else {
                    we.common.commonMgr.openCustomerDialog();
                }
            } else {
                // 普通支付
                if (this.rechargeAmount <= 0) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_17));
                    return;
                }
                if (!(this.rechargeAmount >= payTypeInfo.minAmount && this.rechargeAmount <= payTypeInfo.maxAmount)) {
                    const content = we.core.langMgr.getLangText(
                        HallLanguage.SHOP_RECHARGE_18,
                        we.common.utils.formatPrice(payTypeInfo.minAmount, false, false),
                        we.common.utils.formatPrice(payTypeInfo.maxAmount, false, false)
                    );
                    we.commonUI.showToast(content);
                    return;
                }

                we.common.storeMgr.CheckOrder(() => {
                    // 3. 发起订单请求
                    let amount = (this.rechargeAmount / we.core.flavor.getPricePrecision()) * we.core.flavor.getAmountPrecision();
                    we.common.payMgr.getOrderInfo(we.common.storeMgr.goodsId, this.curPayType, ``, amount);
                });
            }
        } else {
            we.warn(`StoreDlg_h onClickRecharge, payTypeInfo is null`);
        }
    }

    private onClickClearAmount() {
        this.setEditBoxAmount(0);
    }

    private onClickChooseBank() {
        HallMgr.openStoreBankSelectDlg(this.curPayType, this.rechargeAmount);
    }

    private onChangePayChannel(channel: number) {
        const index = this.channelConf.findIndex((item) => {
            return item.payType === channel;
        });
        this.onSelectPayItem(null, index);
    }

    private onClickOrder(): void {
        we.common.storeMgr.getOrderList((data: ApiProto.GetOrderListResp) => {
            if (!this.isValid() || !data) {
                return;
            }
            let orderRecord = data.orderList || [];
            if (orderRecord.length > 0) {
                we.currentUI.show(HallViewId.StorePayOrderDlg, data.orderList);
            } else {
                we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.MAIL_NO));
            }
        });
    }

    private onClickService(): void {
        we.common.commonMgr.openCustomerDialog();
    }

    private coinFlyAnim(params: { node: cc.Node; award: number }) {
        HallMgr.coinFlyAnim(params, this.view.uiRoot, this.view.RC_lab_amount.node, false);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(StoreDlg_h, `${HallViewId.StoreDlg}_h`)
class StoreDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(StoreDlg_h, uiBase.addComponent(StoreDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<StoreDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(StoreDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StoreDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(StoreDlg_h).beforeUnload();
    }
}
