const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreGoodsItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_giveBox: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_giveAmount: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        const nodeGray = this.nodeAddComponent(this.node, we.ui.WENodeGray);
        nodeGray.setGrayMaterial(we.common.res.material.gray);
    }

    public init(amount: number, amountScale = { amount: 0, scale: 0 }) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.node.attr({ amount: amount });
        const amountStr = we.common.storeMgr.formatPrice(amount, true, true);
        this.RC_lab_amount1.string = amountStr;
        this.RC_lab_amount2.string = amountStr;
        this.RC_giveBox.active = amountScale.amount > 0;

        const giveAmountStr = we.common.storeMgr.formatPrice(amountScale.amount, false);
        this.RC_lab_giveAmount.string = `+${giveAmountStr}(${amountScale.scale}%)`;
    }

    public renderUI(params: { amount: number; amountScale?: { amount: number; scale: number }; isAvailable?: boolean }, index = 0) {
        this.init(params.amount, params.amountScale);
        const nodeGray = this.nodeAddComponent(this.node, we.ui.WENodeGray);
        nodeGray.setGray(params.isAvailable === false, true);
        const btn = this.nodeAddComponent(this.node, cc.Button);
        btn.interactable = !(params.isAvailable === false);
    }
}
