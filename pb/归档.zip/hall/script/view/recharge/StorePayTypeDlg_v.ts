import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import StoreBankItem_v from './StoreBankItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('StorePayTypeDlgView_v', we.bundles.hall)
class StorePayTypeDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnConfirm: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_pay: we.ui.List = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('StorePayTypeDlg_v', we.bundles.hall)
export class StorePayTypeDlg_v extends we.ui.DlgSystem<StorePayTypeDlgView_v> {
    private productData = null;
    private price = null;
    private payTypeDataList: ApiProto.RechargeTypeCategory[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_list_pay.setRenderEvent(we.core.Func.create(this.onRenderBankItem, this));

        this.view.cc_onBtnClick(this.view.RC_btnConfirm, we.core.Func.create(this.onClickConfirm, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData: { productData: ApiProto.GoodsPackageInfo | ApiProto.NewbieGiftPack; payTypeDataList: ApiProto.RechargeTypeCategory[]; price: number }) {
        this.price = showData.price;
        this.productData = showData.productData;

        // 移除不满足支付区间支付渠道
        let payChnList: ApiProto.RechargeTypeCategory[] = [];
        showData.payTypeDataList.forEach((v) => {
            if (this.price >= v.minAmount) {
                payChnList.push(v);
            }
        });
        payChnList.sort((a, b) => {
            return a.sort - b.sort;
        });
        this.payTypeDataList = payChnList;

        this.view.RC_list_pay.numItems = this.payTypeDataList.length;
        this.view.RC_list_pay.selectedId = 0;
    }

    private onRenderBankItem(node: cc.Node, index: number) {
        const data = this.payTypeDataList[index];
        const item = node.addComponentUnique(StoreBankItem_v);
        item.init(data);
    }

    private onClickConfirm(): void {
        this.jumpPayHandle();
    }

    private jumpPayHandle(): void {
        if (!this.productData) {
            we.warn(`StorePayTypeDlg_v jumpPayHandle, productData is null`);
            return;
        }

        const payInfo = this.payTypeDataList[this.view.RC_list_pay.selectedId];
        // 判断是否已实名认证
        if (payInfo.formalRequired && !we.common.userMgr.isRealName()) {
            we.currentUI.show(HallViewId.UserCenterRealNameDlg);
            return;
        }

        let productId = this.productData.id;
        let curPayType = payInfo.payType;

        if (!curPayType) {
            we.warn(`StorePayTypeDlg_v jumpPayHandle, payType is null`);
            return;
        }

        let bankList = [];

        const rechargeFun = (bank?: string) => {
            if (bankList.length > 0) {
                if (!(typeof bank == `string` && bank.length > 0)) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.SHOP_RECHARGE_15));
                    return;
                }
            }

            we.common.payMgr.getOrderInfo(productId, curPayType, bank);
        };

        for (let i = 0; i < this.payTypeDataList.length; i++) {
            if (curPayType == this.payTypeDataList[i].payType) {
                bankList = this.payTypeDataList[i].banks || [];
                if (bankList.length > 0) {
                    HallMgr.openStoreBankSelectDlg(bankList || [], this.price, rechargeFun);
                } else {
                    rechargeFun();
                }
                break;
            }
        }

        this.closeView();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(StorePayTypeDlg_v, `${HallViewId.StorePayTypeDlg}_v`)
class StorePayTypeDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(StorePayTypeDlg_v, uiBase.addComponent(StorePayTypeDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StorePayTypeDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<StorePayTypeDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(StorePayTypeDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(StorePayTypeDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(StorePayTypeDlg_v).beforeUnload();
    }
}
