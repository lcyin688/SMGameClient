import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreOrderItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnCopy: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnFail: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnSuccess: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnWrap: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_amount: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_order: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_status: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private orderNum: string = ``;

    private orderData: ApiProto.OrderInfo = null;

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClickOrder, this)).setSleepTime(1.5);
        this.onBtnClick(this.RC_btnCopy, we.core.Func.create(this.onClickCopy, this));
        this.onBtnClick(this.RC_btnSuccess, we.core.Func.create(this.onClickSuccessBtn, this)).setSleepTime(1.5);
        this.onBtnClick(this.RC_btnFail, we.core.Func.create(this.onClickFailBtn, this)).setSleepTime(1.5);
    }

    public initUI(data: ApiProto.OrderInfo): void {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.orderNum = data.orderNo;
        this.RC_lab_order.string = data.orderNo;
        this.RC_lab_time.string = we.common.utils.formatDate(new Date(data.ts * 1000), 'DD/MM/YYYY hh:mm');
        // 订单状态 0 等待支付 2 成功 4 失败 3 发货失败
        this.setOrderStatus(data.orderStatus);
        this.RC_lab_amount.string = we.common.utils.formatAmount(data.amount, false);
        if (!we.common.payMgr.isTestPay(data.payType)) {
            let typePath = HallRes.texture.payTypeIcon + data.payType;
            we.common.utils.setComponentSprite(this.RC_spr_icon, typePath);
        } else {
            this.RC_spr_icon.spriteFrame = null;
        }
        this.renderExtra(data.extra);
        this.orderData = data;
    }

    private onClickCopy(): void {
        we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.COMMON_COPY_COMPLETE));
        we.core.nativeUtil.copyText('' + this.orderNum);
    }

    private setOrderStatus(status: number) {
        if (!cc.isValid(this.node)) {
            return;
        }
        // 订单状态 0-等待支付 2-成功 3-发货失败 4-失败 7-支付拒绝
        let index = 0;
        let langKey = ``;
        switch (status) {
            case 0:
                langKey = HallLanguage.SHOP_RECHARGE_11;
                index = we.common.payMgr.ORDER_STATUS.WAIT;
                break;
            case 2:
                langKey = HallLanguage.SHOP_RECHARGE_13;
                index = we.common.payMgr.ORDER_STATUS.SUCCEEDED;
                break;
            case 3:
            case 4:
                langKey = HallLanguage.SHOP_RECHARGE_12;
                index = we.common.payMgr.ORDER_STATUS.FAILED;
                break;
            case 7:
                langKey = HallLanguage.EVENT_RESCUE_FUNDS_20;
                index = we.common.payMgr.ORDER_STATUS.FAILED;
                break;
            default:
                break;
        }

        this.RC_lab_status.string = we.core.langMgr.getLangText(langKey);
        this.RC_lab_status.node.getComponent(we.ui.WENodeColorIndex).setIndex(index);
    }

    public renderExtra(data: ApiProto.OrderUIExtraInfo) {
        if (!cc.isValid(this.node)) {
            return;
        }
        this.RC_btnWrap.active = false;
        this.RC_btnSuccess.active = false;
        this.RC_btnFail.active = false;
        if (data && data.affirmBtn === 10) {
            this.RC_btnWrap.active = true;
            this.RC_btnSuccess.active = true;
        }
        if (data && data.cancelBtn === 10) {
            this.RC_btnWrap.active = true;
            this.RC_btnFail.active = true;
        }
        if (data && data.affirmBtn === 20) {
            this.RC_btnWrap.active = false;
            this.RC_lab_status.string = we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_28);
            this.RC_lab_status.node.getComponent(we.ui.WENodeColorIndex).setIndex(we.common.payMgr.ORDER_STATUS.WAIT);
        }
    }

    public onClickOrder() {
        if (this.orderData.payType != we.common.payMgr.PAY_TYPE.VIP_PAY) {
            return;
        }
        if (!this.orderData || this.orderData.orderStatus !== 0) {
            return;
        }
        if (this.orderData.extra && this.orderData.extra.orderH5Url) {
            we.core.nativeUtil.openUrl(this.orderData.extra.orderH5Url);
            we.currentUI.close(HallViewId.StorePayOrderDlg);
            we.common.storeMgr.orderRecordInfo.lastTime = 0;
        }
    }

    public onClickSuccessBtn() {
        we.commonUI.showConfirm({
            title: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_18),
            content: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_24),
            yesHandler: we.core.Func.create(() => {
                we.common.apiMgr.affirmVipRechargeOrder(
                    { orderNo: this.orderData.orderNo },
                    (data: ApiProto.VIPOrderAffirmResp) => {
                        if (data.errorCode === 20010) {
                            this.onClickOrder();
                        }
                        if (!data.success) {
                            return;
                        }
                        this.refreshOrderData();
                    },
                    () => {
                        this.refreshOrderData();
                    }
                );
            }),
            noHandler: we.core.Func.create(() => {}),
        });
    }

    public onClickFailBtn() {
        we.commonUI.showConfirm({
            title: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_18),
            content: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_25),
            yesHandler: we.core.Func.create(() => {
                we.common.apiMgr.cancelVipRechargeOrder(
                    { orderNo: this.orderData.orderNo },
                    (data: ApiProto.VIPOrderCancelResp) => {
                        if (!data.success) {
                            return;
                        }
                        this.refreshOrderData();
                    },
                    () => {
                        this.refreshOrderData();
                    }
                );
            }),
            noHandler: we.core.Func.create(() => {}),
        });
    }

    // 刷新订单数据
    public refreshOrderData() {
        cc.director.emit(HallEvent.RECHARGE_UPDATE_ORDER_LIST);
    }
}
