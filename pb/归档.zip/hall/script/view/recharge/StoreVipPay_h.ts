import { HallLanguage } from '../../const/HallLanguage';
import { HallViewId } from '../HallViewId';
import StoreBankItem_h from './StoreBankItem_h';
import StoreGoodsItem_h from './StoreGoodsItem_h';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreVipPay_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.List)
    private RC_list_vipBanks: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    private RC_list_vipGoods: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    private RC_btnVipRecharge: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public bankList: ApiProto.VIPRechargeConfig[] = [];

    public goodsList: ApiProto.VIPRechargeAmountInfo[] = [];

    public selectBank = -1;
    public selectGoods = -1;

    protected onLoad() {
        const nodeGray = this.RC_btnVipRecharge.addComponentUnique(we.ui.WENodeGray);
        nodeGray.setGrayMaterial(we.common.res.material.gray);

        this.RC_list_vipBanks.setRenderEvent(we.core.Func.create(this.onRenderVipBankEvent, this));
        this.RC_list_vipBanks.setSelectedEvent(we.core.Func.create(this.onSelectedVipBankEvent, this));

        this.RC_list_vipGoods.setRenderEvent(we.core.Func.create(this.onRenderVipGoodsEvent, this));
        this.RC_list_vipGoods.setSelectedEvent(we.core.Func.create(this.onSelectedVipGoodsEvent, this));

        this.onBtnClick(this.RC_btnVipRecharge, we.core.Func.create(this.onClickRechargeOrder, this)).setSleepTime(1.5);
    }

    protected start(): void {
        this.init();
    }

    private init() {
        if (this.bankList.length) {
            this.renderVipPayUi();
        } else {
            we.common.apiMgr.getVipRechargeConfig(
                (data: ApiProto.VIPRechargeConfigResp) => {
                    if (!data || !cc.isValid(this.node)) {
                        return;
                    }
                    this.bankList = data.rechargeConfig || [];
                    this.renderVipPayUi();
                },
                null,
                true,
                false
            );
        }
    }

    private renderVipPayUi() {
        this.RC_list_vipBanks.numItems = this.bankList.length;
        const selectBank = this.selectBank < 0 ? 0 : this.selectBank;
        this.RC_list_vipBanks.selectedId = selectBank;
    }

    private onRenderVipBankEvent(node: cc.Node, index: number) {
        const data = this.bankList[index];
        const item = node.addComponentUnique(StoreBankItem_h);
        item.renderPay(data);
    }

    private onSelectedVipBankEvent(_: cc.Node, index: number) {
        if (index < 0) {
            return;
        }
        this.selectBank = index;
        this.goodsList = (this.bankList[index] || {}).amountInfo || [];
        this.RC_list_vipGoods.numItems = this.goodsList.length;
        this.RC_list_vipGoods.selectedId = this.goodsList.findIndex((item) => {
            return item.isAvailable;
        });
        // 设置充值按钮是否可点击
        const isAction = this.RC_list_vipGoods.selectedId === -1;
        this.RC_btnVipRecharge.getComponent(we.ui.WENodeGray).setGray(isAction, true);
        this.RC_btnVipRecharge.addComponentUnique(cc.Button).interactable = !isAction;
    }

    private onRenderVipGoodsEvent(node: cc.Node, index: number) {
        const data = this.goodsList[index];
        const item = node.addComponentUnique(StoreGoodsItem_h);
        const payTypeInfo = we.common.storeMgr.getPayChannelConf(we.common.payMgr.PAY_TYPE.VIP_PAY);
        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(data.amount, payTypeInfo);
        item.renderUI(
            {
                amount: data.amount,
                isAvailable: data.isAvailable,
                amountScale,
            },
            index
        );
    }

    private onSelectedVipGoodsEvent(node: cc.Node, index: number) {
        this.selectGoods = index;
    }

    public onClickRechargeOrder() {
        // 判断是否已实名认证
        const payTypeInfo = we.common.storeMgr.getPayChannelConf(we.common.payMgr.PAY_TYPE.VIP_PAY);
        if (payTypeInfo && payTypeInfo.formalRequired && !we.common.userMgr.isRealName()) {
            we.currentUI.show(HallViewId.UserCenterRealNameDlg);
            return;
        }

        const bank = this.bankList[this.selectBank];
        const goods = this.goodsList[this.selectGoods];
        if (!goods) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_23));
            return;
        }
        const amount = (goods.amount / we.core.flavor.getPricePrecision()) * we.core.flavor.getAmountPrecision();
        we.common.apiMgr.createVipRechargeOrder(
            {
                payType: bank.payType,
                bankCode: bank.bankCode,
                rechargeAmount: String(amount),
            },
            (data: ApiProto.CreateVIPOrderResp) => {
                if (data.existsOrder) {
                    if (data.orderData.affirmBtn === 20) {
                        // 判断是否已点击支付按钮
                        we.commonUI.showConfirm({
                            title: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_18),
                            content: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_29),
                            yesHandler: we.core.Func.create(() => {}, this),
                        });
                        return;
                    }
                    this.createExistsOrderDialog(data.orderData.orderNo, data.orderData.orderH5Url);
                    return;
                }
                if (data.success) {
                    if (we.common.storeMgr.orderRecordInfo) {
                        we.common.storeMgr.orderRecordInfo = null;
                    }
                    we.core.nativeUtil.openUrl(data.orderData.orderH5Url);
                } else {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_23));
                }
            },
            (code: number) => {
                if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3022) {
                    we.commonUI.showToast(`${we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_32)}: ${code}`);
                }
            }
        );
    }

    public createExistsOrderDialog(orderNo: string, url: string) {
        we.commonUI.showConfirm({
            title: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_18),
            content: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_19),
            yesHandler: we.core.Func.create(() => {
                we.core.nativeUtil.openUrl(url);
            }, this),
            noHandler: we.core.Func.create(() => {
                we.common.apiMgr.cancelVipRechargeOrder({ orderNo }, null, null);
            }, this),
        });
    }
}
