import { HallRes } from '../../config/HallRes';
import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreSelectItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_active: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_bank: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_icon: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name2: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_ratio: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tag: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_move: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_ratio: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_tag: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_tagPanel: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public isMove = false;

    public data: ApiProto.RechargeTypeCategory = null;

    public selectEvent: we.core.Func<any>;

    public setDefaultStyle(isMove = false) {
        if (!this.isInitRc) {
            this.__initRc();
        }

        this.RC_tag.active = false;
        this.RC_ratio.active = false;
        this.RC_active.active = false;
        this.RC_bank.active = false;
        this.RC_icon.active = false;
        this.RC_move.active = isMove;
        this.RC_lab_name1.node.active = false;
        this.RC_lab_name2.node.active = false;
    }

    public setRecommendTag(payTypeInfo: ApiProto.RechargeTypeCategory): void {
        let tag = payTypeInfo.tag;
        let langKey = null;
        let index = -1;
        // 0 默认 1 推荐 2 大额 3 便捷
        switch (tag) {
            case 1:
                langKey = HallLanguage.RECHARGE_SUB_TJ;
                index = 0;
                break;
            case 2:
                langKey = HallLanguage.RECHARGE_SUB_DE;
                index = 1;
                break;
            case 3:
                langKey = HallLanguage.RECHARGE_SUB_BJ;
                index = 2;
                break;
            default:
                break;
        }

        if (typeof langKey == 'string' && langKey.length > 0) {
            this.RC_lab_tag.string = we.core.langMgr.getLangText(langKey);
            this.RC_tagPanel.getComponent(we.ui.WESpriteIndex).index = index;
            this.RC_lab_tag.getComponent(we.ui.WENodeColorIndex)?.setIndex(index);
            this.RC_tag.active = true;
        } else {
            this.RC_tag.active = false;
        }
    }

    public updateAddRatio() {
        let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
        this.RC_ratio.active = this.data.rechargeGiftScale > 0 && curTime < we.common.storeMgr.shopConf.rechargeGiftExpireTime;
        this.RC_lab_ratio.string = `+${this.data.rechargeGiftScale / 100}%`;
    }

    public renderPayType(data: ApiProto.RechargeTypeCategory | null, isMove = false) {
        this.setDefaultStyle(isMove);
        if (data) {
            this.RC_lab_name1.node.active = !isMove;
            this.RC_lab_name2.node.active = !isMove;
            const { payType, name } = data;
            this.RC_lab_name1.string = name;
            this.RC_lab_name2.string = name;
            // 支付方式
            if (!we.common.payMgr.isTestPay(payType) && payType) {
                this.RC_icon.active = true;
                let payTypeIconPath = HallRes.texture.payTypeIconSmall + payType;
                we.common.utils.setComponentSprite(this.RC_icon, payTypeIconPath);
            }

            this.data = data;
            this.setRecommendTag(data);
            this.updateAddRatio();
        }

        this.isMove = isMove;
    }

    public renderVipBank(data: ApiProto.VIPRechargeConfig, isMove = false) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.setDefaultStyle(isMove);

        if (!isMove) {
            this.RC_bank.active = true;
            let iconPath = '';
            if (data.isBank) {
                iconPath = `${HallRes.texture.channelCode}${data.bankCode}`;
            } else {
                iconPath = `${HallRes.texture.payTypeIcon}${data.payType}`;
            }
            we.common.utils.setComponentSprite(this.RC_bank, iconPath);
        }

        this.isMove = isMove;
    }

    public renderBank(data: ApiProto.Banks, isMove = false) {
        if (!this.isInitRc) {
            this.__initRc();
        }
        this.setDefaultStyle(isMove);
        if (!isMove) {
            this.RC_bank.active = true;
            const bankIconPath = `${HallRes.texture.channelCode}${data.name}`;
            we.common.utils.setComponentSprite(this.RC_bank, bankIconPath);
        }
        this.isMove = isMove;
    }
}
