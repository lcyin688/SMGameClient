import { HallLanguage } from '../../const/HallLanguage';
import StoreSelectItem_v from './StoreSelectItem_v';
import StoreGoodsItem_v from './StoreGoodsItem_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class StoreVipPay_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.List)
    public RC_list_vipBanks: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_vipGoods: we.ui.List = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public bankList: ApiProto.VIPRechargeConfig[] = [];

    public goodsList: ApiProto.VIPRechargeAmountInfo[] = [];

    public selectBank = -1;
    public selectGoods = -1;
    public selectLimit = 9;

    public selectCallback: we.core.Func<any> = null;

    protected onLoad() {
        this.RC_list_vipBanks.scrollView.enabled = false;
        this.RC_list_vipBanks.enabled = false;
        this.RC_list_vipGoods.scrollView.enabled = false;
        this.RC_list_vipGoods.enabled = false;

        this.RC_list_vipBanks.setRenderEvent(we.core.Func.create(this.onRenderVipBankEvent, this));
        this.RC_list_vipBanks.setSelectedEvent(we.core.Func.create(this.onSelectedVipBankEvent, this));

        this.RC_list_vipGoods.setRenderEvent(we.core.Func.create(this.onRenderVipGoodsEvent, this));
        this.RC_list_vipGoods.setSelectedEvent(we.core.Func.create(this.onSelectedVipGoodsEvent, this));
    }

    public init(isRequest = false) {
        if (isRequest) {
            const showLoading = this.bankList.length <= 0;
            we.common.apiMgr.getVipRechargeConfig(
                (data: ApiProto.VIPRechargeConfigResp) => {
                    if (!data || !cc.isValid(this.node)) {
                        return;
                    }
                    this.bankList = data.rechargeConfig || [];
                    this.renderVipPayUi();
                },
                null,
                showLoading,
                false
            );
        } else {
            this.renderVipPayUi();
        }
    }

    public setSelectEvent(callback: we.core.Func<any>) {
        this.selectCallback = callback;
    }

    private renderVipPayUi() {
        if (this.selectLimit && this.selectLimit < this.bankList.length) {
            this.RC_list_vipBanks.numItems = this.selectLimit;
        } else {
            this.RC_list_vipBanks.numItems = this.bankList.length;
        }
        const selectBank = this.selectBank < 0 ? 0 : this.selectBank;
        this.RC_list_vipBanks.selectedId = selectBank;
        this.onSelectedVipBankEvent(null, selectBank);
        this.scheduleOnce(() => {
            this.RC_list_vipBanks.node.height = this.RC_list_vipBanks.content.height;
        }, 0.1);
    }

    private onRenderVipBankEvent(node: cc.Node, index: number) {
        const data = this.bankList[index];
        const isMore = this.selectLimit && index + 1 === this.selectLimit;
        if (isMore) {
            this.nodeAddComponent(node, StoreSelectItem_v).renderVipBank(null, isMore);
        } else {
            this.nodeAddComponent(node, StoreSelectItem_v).renderVipBank(data);
        }
    }

    private onSelectedVipBankEvent(_: cc.Node, index: number) {
        if (index < 0 && index === this.selectBank) {
            this.selectCallback && this.selectCallback.exec();
            return;
        }
        if (this.selectLimit && index + 1 === this.selectLimit) {
            this.selectLimit = 0;
            this.RC_list_vipBanks.numItems = this.bankList.length;
            this.RC_list_vipBanks.selectedId = this.selectBank;

            this.scheduleOnce(() => {
                this.RC_list_vipBanks.node.height = this.RC_list_vipBanks.content.height;
            }, 0.1);
        } else {
            this.selectBank = index;
            this.goodsList = (this.bankList[index] || {}).amountInfo || [];
            this.RC_list_vipGoods.numItems = this.goodsList.length;
            this.RC_list_vipGoods.selectedId = this.goodsList.findIndex((item) => {
                return item.isAvailable;
            });
            this.selectCallback && this.selectCallback.exec();
        }
    }

    private onRenderVipGoodsEvent(node: cc.Node, index: number) {
        const data = this.goodsList[index];
        const payTypeInfo = we.common.storeMgr.getPayChannelConf(we.common.payMgr.PAY_TYPE.VIP_PAY);
        const amountScale = we.common.storeMgr.getGiveAwayAmountScale(data.amount, payTypeInfo);
        this.nodeAddComponent(node, StoreGoodsItem_v).renderUI(
            {
                amount: data.amount,
                isAvailable: data.isAvailable,
                amountScale,
            },
            index
        );
    }

    private onSelectedVipGoodsEvent(node: cc.Node, index: number) {
        this.selectGoods = index;
    }

    public createRechargeOrder() {
        const bank = this.bankList[this.selectBank];
        const goods = this.goodsList[this.selectGoods];
        if (!goods) {
            we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_23));
            return;
        }
        const amount = (goods.amount / we.core.flavor.getPricePrecision()) * we.core.flavor.getAmountPrecision();
        we.common.apiMgr.createVipRechargeOrder(
            {
                payType: bank.payType,
                bankCode: bank.bankCode,
                rechargeAmount: String(amount),
            },
            (data: ApiProto.CreateVIPOrderResp) => {
                if (data.existsOrder) {
                    if (data.orderData.affirmBtn === 20) {
                        // 判断是否已点击支付按钮
                        we.commonUI.showConfirm({
                            title: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_18),
                            content: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_29),
                            yesHandler: we.core.Func.create(() => {}, this),
                        });
                        return;
                    }
                    this.createExistsOrderDialog(data.orderData.orderNo, data.orderData.orderH5Url);
                    return;
                }
                if (data.success) {
                    if (we.common.storeMgr.orderRecordInfo) {
                        we.common.storeMgr.orderRecordInfo = null;
                    }
                    we.core.nativeUtil.openUrl(data.orderData.orderH5Url);
                } else {
                    we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_23));
                }
            },
            (code: number) => {
                if (code === we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3022) {
                    we.commonUI.showToast(`${we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_32)}: ${code}`);
                }
            }
        );
    }

    public createExistsOrderDialog(orderNo: string, url: string) {
        we.commonUI.showConfirm({
            title: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_18),
            content: we.core.langMgr.getLangText(HallLanguage.TOPUP_VIP_LABEL_19),
            yesHandler: we.core.Func.create(() => {
                we.core.nativeUtil.openUrl(url);
            }, this),
            noHandler: we.core.Func.create(() => {
                we.common.apiMgr.cancelVipRechargeOrder({ orderNo }, null, null);
            }, this),
        });
    }
}
