import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('LineConversionTipDlgView_v', we.bundles.common)
class LineConversionTipDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnCancel: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnConfirm: cc.Node = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_desc: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_line1: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_line2: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Toggle)
    public RC_toggle_autoOpen: cc.Toggle = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('LineConversionTipDlg_v', we.bundles.common)
export class LineConversionTipDlg_v extends we.ui.DlgSystem<LineConversionTipDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_btnClose.active = false;
        this.view.RC_btnConfirm.active = true;
        this.view.RC_btnCancel.active = true;

        this.view.RC_toggle_autoOpen.node.on('toggle', this.onClickNoProp, this);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.onCancelClick, this));
        this.view.cc_onBtnClick(this.view.RC_btnCancel, we.core.Func.create(this.onCancelClick, this));
        this.view.cc_onBtnClick(this.view.RC_btnConfirm, we.core.Func.create(this.onConfirmClick, this));
    }

    /** 显示窗口 */
    public async onShow(vendorRatio: number) {
        const str = `1:${vendorRatio / 10000}`;
        this.view.RC_desc.setStringFormat(we.core.langMgr.getLangText(we.common.lang.HALL_CONVERSION_RATIO), str);

        let vendorCredit = we.common.userMgr.userInfo.gold * (vendorRatio / 10000);
        this.view.RC_lab_line2.string = we.common.utils.formatAmount(vendorCredit, false);
        this.view.RC_lab_line1.string = we.common.utils.formatAmount(we.common.userMgr.userInfo.gold, false);

        let isClickNoProp = we.common.storage.getDay('common', 'no_prop_conversion_tip');
        this.view.RC_toggle_autoOpen.isChecked = isClickNoProp === true ? true : false;
    }

    /** 隐藏窗口 */
    public async onHide() {}

    private onConfirmClick(): void {
        this.setReturn(true);
        this.closeView();
    }

    private onCancelClick(): void {
        this.setReturn(false);
        this.closeView();
    }

    private onClickNoProp(toggle: cc.Toggle) {
        we.common.storage.setDay('common', 'no_prop_conversion_tip', toggle.isChecked);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(LineConversionTipDlg_v, `${HallViewId.LineConversionTipDlg}_v`)
class LineConversionTipDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(LineConversionTipDlg_v, uiBase.addComponent(LineConversionTipDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(LineConversionTipDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<LineConversionTipDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(LineConversionTipDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(LineConversionTipDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(LineConversionTipDlg_v).beforeUnload();
    }
}
