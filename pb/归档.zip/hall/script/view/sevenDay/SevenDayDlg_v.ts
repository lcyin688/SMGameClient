import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import JumpModMgr from '../../manager/JumpModMgr';
import SevenDayMgr from '../../manager/SevenDayMgr';
import { HallViewId } from '../HallViewId';
import SevenDayGiftItem_v from './SevenDayGiftItem_v';
import SevenDayMenuItem_v from './SevenDayMenuItem_v';
import SevenDaySignItem_v from './SevenDaySignItem_v';
import SevenDayTaskItem_v from './SevenDayTaskItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('SevenDayDlgView_v', we.bundles.hall)
class SevenDayDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_condition: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_days: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_gift: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_multiple: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_price: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_total: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_uid: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_sign: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_task: we.ui.List = null;

    @we.ui.ccBind(we.ui.WEPageView)
    public RC_page: we.ui.WEPageView = null;

    @we.ui.ccBind(we.ui.WEPageView)
    public RC_page_gift: we.ui.WEPageView = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_days: we.ui.WERichTags = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_recharge: we.ui.WERichTags = null;

    @we.ui.ccBind(SevenDaySignItem_v)
    public RC_sign: SevenDaySignItem_v = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_bind: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_gift: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_shop: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_sign: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_list_task_top: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_page_top: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_pages: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('SevenDayDlg_v', we.bundles.hall)
export class SevenDayDlg_v extends we.ui.DlgSystem<SevenDayDlgView_v> {
    private pages: cc.Node[] = [];
    private index: SevenDayMgr.Page;
    private giftIndex: number;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.pages.push(...this.view.RCN_pages.children);
        this.view.RCN_pages.removeAllChildren(false);

        cc.director.on(HallEvent.SEVEN_DAY_UPDATE_DATA, this.onUpdateData, this);
        this.view.RC_page.setRender(we.core.Func.create(this.onRenderMenu, this));
        this.view.RC_page.pageChanedCallback = this.onMenuSelected.bind(this);
        this.view.cc_onBtnClick(this.view.RCN_btn_close, we.core.Func.create(this.closeView, this)).setTransitionScale();
        // 兼容处理，如果皮肤不存在 RCN_page_top 则表示 RC_page 不需要代码定位
        if (this.view.RCN_page_top) {
            this.view.uiRoot.on(cc.Node.EventType.SIZE_CHANGED, async () => {
                await this.scheduleOnce(0);
                this.updateAlignment(this.view.RC_page.node, this.view.RCN_page_top);
            });
        }

        // #region task
        this.view.RC_list_task.setRenderEvent(we.core.Func.create(this.onRenderTask, this));
        this.view.cc_onBtnClick(this.view.RCN_btn_shop, we.core.Func.create(this.onClickShop, this)).setTransitionScale();
        // 兼容处理，如果皮肤不存在 RCN_list_task_top 则表示 RC_list_task 不需要代码定位
        this.view.RCN_list_task_top?.on(cc.Node.EventType.POSITION_CHANGED, () => {
            this.updateAlignment(this.view.RC_list_task.node, this.view.RCN_list_task_top);
        });
        // #endregion

        // #region sign
        this.view.RC_list_sign.setRenderEvent(we.core.Func.create(this.onRenderSign, this));
        this.view.cc_onBtnClick(this.view.RCN_btn_sign, we.core.Func.create(this.onClickSign, this)).setTransitionScale();
        // #endregion

        // #region gift
        this.view.RC_page_gift.setRender(we.core.Func.create(this.onRenderGift, this));
        this.view.RC_page_gift.pageChanedCallback = this.onGiftSelected.bind(this);
        this.view.cc_onBtnClick(this.view.RCN_btn_gift, we.core.Func.create(this.onClickGift, this)).setTransitionScale();
        // #endregion

        // #region bind
        this.view.cc_onBtnClick(this.view.RCN_btn_bind, we.core.Func.create(this.onClickBind, this)).setTransitionScale();
        // #endregion
    }

    protected destroy(): void {
        cc.director.off(HallEvent.SEVEN_DAY_UPDATE_DATA, this.onUpdateData, this);
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Seven_Day);
    }

    /** 显示窗口 */
    public async onShow(index?: SevenDayMgr.Page) {
        this.index = index ?? SevenDayMgr.Page.Intro;
        this.view.RC_lab_time.string = '';
        await SevenDayMgr.instance.requestData();
    }

    private async onUpdateData() {
        if (!SevenDayMgr.instance.open) {
            HallMgr.activityStatusTips();
            this.closeView();
            return;
        }
        const availableMenu = SevenDayMgr.instance.availableMenu;
        const menu = SevenDayMgr.instance.menu[this.index];
        this.view.RC_page.totalPage = availableMenu.length;
        this.onMenuSelected();
        menu.active && this.view.RC_page.jumpToPage(availableMenu.indexOf(menu), true);
        this.onUpdateBind();
        await this.view.uiRoot.addComponentUnique(we.ui.WETimeCountDown).countDown(0, SevenDayMgr.instance.data.endTime - we.core.TimeHelper.getTimestampS(), '{HH}:{MM}:{SS}', (str, duration, elapsed) => {
            this.view.RC_lab_time.string = `${we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_1)}${we.common.utils.formatSeconds(duration - elapsed)}`;
        });
        SevenDayMgr.instance.requestDataSilent();
    }

    private onRenderMenu(node: cc.Node, index: number) {
        const menu = SevenDayMgr.instance.availableMenu[index];
        const page = this.pages[SevenDayMgr.instance.menu.indexOf(menu)];
        node.removeAllChildren(false);
        page.parent = node;
        page.getComponent(cc.Widget)?.updateAlignment();
        page.getComponentsInChildren(cc.Widget).forEach((widget) => {
            widget.updateAlignment();
        });
        page.getComponentInChildren(SevenDayMenuItem_v)?.init(menu);
    }

    private async onMenuSelected() {
        this.index = SevenDayMgr.instance.menu.indexOf(SevenDayMgr.instance.availableMenu[this.view.RC_page.getCurrentPage()]);
        // 需要等组件初始化
        await this.scheduleOnce(0);
        switch (this.index) {
            case SevenDayMgr.Page.Task:
                this.onUpdateTask();
                break;
            case SevenDayMgr.Page.Sign:
                this.onUpdateSign();
                break;
            case SevenDayMgr.Page.Gift:
                this.onUpdateGift();
                break;
            default:
        }
    }

    /**
     * 根据 top 更新 target 的 widget
     * @param target
     * @param top
     */
    private updateAlignment(target: cc.Node, top: cc.Node) {
        if (!cc.isValid(top)) {
            return;
        }

        const widget = target.addComponentUnique(cc.Widget);
        const parent = widget.target ?? target.parent;
        const pos = parent.convertToNodeSpaceAR(top.convertToWorldSpaceAR(cc.Vec2.ZERO));
        widget.isAlignTop = true;
        widget.top = parent.height / 2 - pos.y;
        target.getComponentsInChildren(cc.Widget).forEach((widget) => {
            widget.updateAlignment();
        });
    }

    // #region task
    private onUpdateTask() {
        const condition = we.common.utils.formatPrice(SevenDayMgr.instance.data.rechargeCondition, true, false);
        const total = we.common.utils.formatPrice(SevenDayMgr.instance.data.rechargeCondition * SevenDayMgr.multiple, true, false);
        // 兼容处理，一些皮肤使用 RC_rich_recharge ，一些皮肤使用 RC_lab_condition 三兄弟
        if (this.view.RC_rich_recharge) {
            this.view.RC_rich_recharge.setStringFormat(we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_14), condition, SevenDayMgr.multiple, total);
        } else {
            this.view.RC_lab_condition.string = condition;
            this.view.RC_lab_multiple.string = `${SevenDayMgr.multiple}`;
            this.view.RC_lab_total.string = total;
        }
        this.view.RCN_btn_shop.active = SevenDayMgr.instance.condition > 0;
        this.view.RC_list_task.numItems = SevenDayMgr.instance.data.betAmount?.length ?? 0;
    }

    private onRenderTask(node: cc.Node, index: number) {
        node.getComponent(SevenDayTaskItem_v)?.init(SevenDayMgr.instance.data.betAmount[index]);
    }

    private onClickShop() {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Recharge);
        this.closeView();
    }
    // #endregion

    // #region sign
    private onUpdateSign() {
        const days = SevenDayMgr.instance.data.dayReward?.length ?? 0;
        // 兼容处理，一些皮肤没有 RC_lab_days
        this.view.RC_lab_days && (this.view.RC_lab_days.string = `${days}`);
        // 兼容处理，一些皮肤没有 RC_rich_days
        this.view.RC_rich_days?.setStringFormat(we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_LOGIN_3), days);
        // 兼容处理，一些皮肤最后一天单独使用 RC_sign
        if (days > 0 && this.view.RC_sign) {
            this.view.RC_list_sign.numItems = days - 1;
            this.view.RC_sign.init(SevenDayMgr.instance.data.dayReward?.[days - 1], true);
        } else {
            this.view.RC_list_sign.numItems = days;
        }
        this.view.RCN_btn_sign.active = SevenDayMgr.instance.data.dayReward?.some((sign) => {
            return sign.state < 2;
        });
        SevenDayMgr.instance.btnAutoGray(
            this.view.RCN_btn_sign.addComponentUnique(cc.Button),
            SevenDayMgr.instance.data.dayReward?.some((sign) => {
                return sign.state === 1;
            })
        );
    }

    private onRenderSign(node: cc.Node, index: number) {
        const dayReward = SevenDayMgr.instance.data.dayReward;
        node.getComponent(SevenDaySignItem_v)?.init(dayReward[index], index === dayReward.length - 1);
    }

    private onClickSign() {
        SevenDayMgr.instance.requestSignAward();
    }
    // #endregion

    // #region gift
    private onUpdateGift() {
        const index =
            this.giftIndex ??
            SevenDayMgr.instance.data.giftState?.findIndex((gift) => {
                return gift.state === 1;
            });
        const immediate = index === this.giftIndex;
        this.view.RC_page_gift.totalPage = SevenDayMgr.instance.data.giftState?.length ?? 0;
        this.onGiftSelected();
        index > 0 && this.view.RC_page_gift.jumpToPage(index, immediate);
    }

    private onRenderGift(node: cc.Node, index: number) {
        node.getComponent(SevenDayGiftItem_v)?.init(SevenDayMgr.instance.data.giftState[index]);
    }

    private onGiftSelected() {
        this.giftIndex = this.view.RC_page_gift.getCurrentPage();
        const gift = SevenDayMgr.instance.data.giftState[this.giftIndex];
        SevenDayMgr.instance.btnAutoGray(this.view.RCN_btn_gift.addComponentUnique(cc.Button), gift.state === 1);
        this.view.RC_lab_price.string = gift.state === 2 ? we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_GIFT_5) : we.common.utils.formatPrice(gift.price, true, false);
        this.view.RC_lab_gift.string = we.core.langMgr.getLangText(gift.state === 0 ? HallLanguage.SEVEN_DAY_GIFT_4 : HallLanguage.SEVEN_DAY_GIFT_3);
    }

    private onClickGift() {
        SevenDayMgr.instance.buyGift(this.giftIndex, this.view);
    }
    // #endregion

    // #region bind
    private onUpdateBind() {
        const award = we.core.projectConfig.settingsConfig?.phoneBindReward[0] ?? 0;
        this.view.RC_lab_award.string = we.common.utils.formatAmountCurrency(award);
        this.view.RC_lab_uid.string = `${we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_BIND_2)}${we.common.userMgr.userInfo.userId}`;
    }

    private onClickBind() {
        we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
    }
    // #endregion
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(SevenDayDlg_v, `${HallViewId.SevenDayDlg}_v`)
class SevenDayDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(SevenDayDlg_v, uiBase.addComponent(SevenDayDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(SevenDayDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<SevenDayDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(SevenDayDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(SevenDayDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(SevenDayDlg_v).beforeUnload();
    }
}
