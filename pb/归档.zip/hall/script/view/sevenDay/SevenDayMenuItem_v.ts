import SevenDayMgr from '../../manager/SevenDayMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDayMenuItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_bg: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_title: cc.Label = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_title: we.ui.WESpriteIndex = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public async init(data: (typeof SevenDayMgr.instance.menu)[0]) {
        this.__initRc();
        this.RC_bg.index = SevenDayMgr.instance.menu.indexOf(data);
        // 兼容处理，一些皮肤没有 RC_lab_title
        this.RC_lab_title && (this.RC_lab_title.string = data.title);
        // 兼容处理，一些皮肤 RC_lab_title 没有 we.ui.WENodeColorIndex
        this.RC_lab_title?.getComponent(we.ui.WENodeColorIndex)?.setIndex(this.RC_bg.index);
        // 兼容处理，一些皮肤没有 RC_title
        this.RC_title?.setIndex(this.RC_bg.index);
        const red = await we.common.redDot.red.appendVRedDotNode(this.node);
        cc.isValid(this.node) && (red.children[0].active = data.red > 0);
    }
}
