import { HallEvent } from '../../config/HallEvent';
import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import JumpModMgr from '../../manager/JumpModMgr';
import SevenDayMgr from '../../manager/SevenDayMgr';
import { HallViewId } from '../HallViewId';
import SevenDayGiftItem_h from './SevenDayGiftItem_h';
import SevenDayMenuItem_h from './SevenDayMenuItem_h';
import SevenDaySignItem_h from './SevenDaySignItem_h';
import SevenDayTaskItem_h from './SevenDayTaskItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('SevenDayDlgView_h', we.bundles.hall)
class SevenDayDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_condition: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_days: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_gift: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_multiple: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_price: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_time: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_total: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_uid: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list: we.ui.List = null;

    /** 皮肤兼容节点，参考ct3 */
    @we.ui.ccBind(we.ui.List)
    public RC_list_sign: we.ui.List = null;

    /** 皮肤兼容节点，参考cm1 */
    @we.ui.ccBind(cc.Node)
    public RC_signs: cc.Node = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_task: we.ui.List = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(we.ui.WEPageView)
    public RC_page_gift: we.ui.WEPageView = null;

    @we.ui.ccBind(we.ui.WERichTags)
    public RC_rich_recharge: we.ui.WERichTags = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_bind: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_gift: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_shop: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_sign: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('SevenDayDlg_h', we.bundles.hall)
export class SevenDayDlg_h extends we.ui.DlgSystem<SevenDayDlgView_h> {
    private index: SevenDayMgr.Page;
    private giftIndex: number;

    /** 注册UI事件 */
    public async registerUIEvent() {
        cc.director.on(HallEvent.SEVEN_DAY_UPDATE_DATA, this.onUpdateData, this);
        this.view.RC_list.setRenderEvent(we.core.Func.create(this.onRenderMenu, this));
        this.view.RC_menu.onSelected = this.onMenuSelected.bind(this);
        this.view.cc_onBtnClick(this.view.RCN_btn_close, we.core.Func.create(this.closeView, this)).setTransitionScale();

        // #region task
        this.view.RC_list_task.setRenderEvent(we.core.Func.create(this.onRenderTask, this));
        this.view.cc_onBtnClick(this.view.RCN_btn_shop, we.core.Func.create(this.onClickShop, this)).setTransitionScale();
        // #endregion

        // #region sign
        if (this.view.RC_list_sign) {
            this.view.RC_list_sign.setRenderEvent(we.core.Func.create(this.onRenderSign, this));
        }
        this.view.cc_onBtnClick(this.view.RCN_btn_sign, we.core.Func.create(this.onClickSign, this)).setTransitionScale();
        // #endregion

        // #region gift
        this.view.RC_page_gift.setRender(we.core.Func.create(this.onRenderGift, this));
        this.view.RC_page_gift.pageChanedCallback = this.onGiftSelected.bind(this);
        this.view.cc_onBtnClick(this.view.RCN_btn_gift, we.core.Func.create(this.onClickGift, this)).setTransitionScale();
        // #endregion

        // #region bind
        this.view.cc_onBtnClick(this.view.RCN_btn_bind, we.core.Func.create(this.onClickBind, this)).setTransitionScale();
        // #endregion
    }

    protected destroy(): void {
        cc.director.off(HallEvent.SEVEN_DAY_UPDATE_DATA, this.onUpdateData, this);
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Seven_Day);
    }

    /** 显示窗口 */
    public async onShow(index?: SevenDayMgr.Page) {
        this.index = index ?? SevenDayMgr.Page.Intro;
        this.view.RC_lab_time.string = '';
        await SevenDayMgr.instance.requestData();
    }

    private async onUpdateData() {
        if (!SevenDayMgr.instance.open) {
            HallMgr.activityStatusTips();
            this.closeView();
            return;
        }
        const index = this.index;
        this.view.RC_list.numItems = SevenDayMgr.instance.menu.length;
        this.view.RC_menu.onSwitchMenu(0);
        SevenDayMgr.instance.menu[index].active && this.view.RC_menu.onSwitchMenu(index);
        this.onUpdateBind();
        await this.view.uiRoot.addComponentUnique(we.ui.WETimeCountDown).countDown(0, SevenDayMgr.instance.data.endTime - we.core.TimeHelper.getTimestampS(), '{HH}:{MM}:{SS}', (str, duration, elapsed) => {
            this.view.RC_lab_time.string = `${we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_1)}${we.common.utils.formatSeconds(duration - elapsed)}`;
        });
        SevenDayMgr.instance.requestDataSilent();
    }

    private onRenderMenu(node: cc.Node, index: number) {
        node.getComponent(SevenDayMenuItem_h)?.init(SevenDayMgr.instance.menu[index]);
        this.view.RC_menu.addMenuBtn(node, index);
    }

    private async onMenuSelected(node: cc.Node, index: number) {
        const listItem = node.getComponent(we.ui.ListItem);
        listItem && (listItem.list.selectedId = index);
        this.index = index;
        // 需要等组件初始化
        await this.scheduleOnce(0);
        switch (index) {
            case SevenDayMgr.Page.Task:
                this.onUpdateTask();
                break;
            case SevenDayMgr.Page.Sign:
                this.onUpdateSign();
                break;
            case SevenDayMgr.Page.Gift:
                this.onUpdateGift();
                break;
            default:
        }
    }

    // #region task
    private onUpdateTask() {
        const condition = we.common.utils.formatPrice(SevenDayMgr.instance.data.rechargeCondition, true, false);
        const total = we.common.utils.formatPrice(SevenDayMgr.instance.data.rechargeCondition * SevenDayMgr.multiple, true, false);
        // 兼容处理，一些皮肤使用 RC_rich_recharge ，一些皮肤使用 RC_lab_condition 三兄弟
        if (this.view.RC_rich_recharge) {
            this.view.RC_rich_recharge.setStringFormat(we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_TASK_14), condition, SevenDayMgr.multiple, total);
        } else {
            this.view.RC_lab_condition.string = condition;
            this.view.RC_lab_multiple.string = `${SevenDayMgr.multiple}`;
            this.view.RC_lab_total.string = total;
        }
        this.view.RCN_btn_shop.active = SevenDayMgr.instance.condition > 0;
        this.view.RC_list_task.numItems = SevenDayMgr.instance.data.betAmount?.length ?? 0;
    }

    private onRenderTask(node: cc.Node, index: number) {
        node.getComponent(SevenDayTaskItem_h)?.init(SevenDayMgr.instance.data.betAmount[index]);
    }

    private onClickShop() {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Recharge);
        this.closeView();
    }
    // #endregion

    // #region sign
    private onUpdateSign() {
        const days = SevenDayMgr.instance.data.dayReward?.length ?? 0;
        // 兼容处理，一些皮肤没有 RC_lab_days
        this.view.RC_lab_days && (this.view.RC_lab_days.string = `${days}`);
        // 兼容处理，一些皮肤使用 RC_list_sign ，一些皮肤使用 RC_signs
        if (this.view.RC_list_sign) {
            this.view.RC_list_sign.numItems = days;
        } else {
            this.view.RC_signs.children.forEach((node: cc.Node, index: number) => {
                this.onRenderSign(node, index);
            });
        }
        this.view.RCN_btn_sign.active = SevenDayMgr.instance.data.dayReward?.some((sign) => {
            return sign.state < 2;
        });
        SevenDayMgr.instance.btnAutoGray(
            this.view.RCN_btn_sign.addComponentUnique(cc.Button),
            SevenDayMgr.instance.data.dayReward?.some((sign) => {
                return sign.state === 1;
            })
        );
    }

    private onRenderSign(node: cc.Node, index: number) {
        const dayReward = SevenDayMgr.instance.data.dayReward;
        // 兼容处理，使用 RC_signs 的皮肤需要判空
        if (dayReward[index]) {
            node.getComponent(SevenDaySignItem_h)?.init(dayReward[index], index === dayReward.length - 1);
        }
    }

    private onClickSign() {
        SevenDayMgr.instance.requestSignAward();
    }
    // #endregion

    // #region gift
    private onUpdateGift() {
        const index = SevenDayMgr.instance.data.giftState?.findIndex((gift) => {
            return gift.state === 1;
        });
        const immediate = index === this.giftIndex;
        this.view.RC_page_gift.totalPage = SevenDayMgr.instance.data.giftState?.length ?? 0;
        this.onGiftSelected();
        index > 0 && this.view.RC_page_gift.jumpToPage(index, immediate);
    }

    private onRenderGift(node: cc.Node, index: number) {
        node.getComponent(SevenDayGiftItem_h)?.init(SevenDayMgr.instance.data.giftState[index]);
    }

    private onGiftSelected() {
        this.giftIndex = this.view.RC_page_gift.getCurrentPage();
        const gift = SevenDayMgr.instance.data.giftState[this.giftIndex];
        SevenDayMgr.instance.btnAutoGray(this.view.RCN_btn_gift.addComponentUnique(cc.Button), gift.state === 1);
        this.view.RC_lab_price.string = gift.state === 2 ? we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_GIFT_5) : we.common.utils.formatPrice(gift.price, true, false);
        this.view.RC_lab_gift.string = we.core.langMgr.getLangText(gift.state === 0 ? HallLanguage.SEVEN_DAY_GIFT_4 : HallLanguage.SEVEN_DAY_GIFT_3);
    }

    private onClickGift() {
        SevenDayMgr.instance.buyGift(this.giftIndex, this.view);
    }
    // #endregion

    // #region bind
    private onUpdateBind() {
        const award = we.core.projectConfig.settingsConfig?.phoneBindReward[0] ?? 0;
        this.view.RC_lab_award.string = we.common.utils.formatAmountCurrency(award);
        this.view.RC_lab_uid.string = `${we.core.langMgr.getLangText(HallLanguage.SEVEN_DAY_BIND_2)}${we.common.userMgr.userInfo.userId}`;
    }

    private onClickBind() {
        we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg);
    }
    // #endregion
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(SevenDayDlg_h, `${HallViewId.SevenDayDlg}_h`)
class SevenDayDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(SevenDayDlg_h, uiBase.addComponent(SevenDayDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(SevenDayDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<SevenDayDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(SevenDayDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(SevenDayDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(SevenDayDlg_h).beforeUnload();
    }
}
