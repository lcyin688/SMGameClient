import SevenDayGiftNode_h from './SevenDayGiftNode_h';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDayGiftItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(SevenDayGiftNode_h)
    public RC_amount: SevenDayGiftNode_h = null;

    @we.ui.ccBind(SevenDayGiftNode_h)
    public RC_award: SevenDayGiftNode_h = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: ApiProto.NewBieSevenDayActivityGiftInfo) {
        this.__initRc();
        this.RC_amount.init(data);
        this.RC_award.init(data, true);
    }
}
