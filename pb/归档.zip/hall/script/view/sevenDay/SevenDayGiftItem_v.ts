import SevenDayGiftNode_v from './SevenDayGiftNode_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDayGiftItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(SevenDayGiftNode_v)
    public RC_amount: SevenDayGiftNode_v = null;

    @we.ui.ccBind(SevenDayGiftNode_v)
    public RC_award: SevenDayGiftNode_v = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(data: ApiProto.NewBieSevenDayActivityGiftInfo) {
        this.__initRc();
        this.RC_amount.init(data);
        this.RC_award.init(data, true);
    }
}
