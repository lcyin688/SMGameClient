import SevenDayMgr from '../../manager/SevenDayMgr';

const { ccclass, property } = cc._decorator;

@ccclass
export default class SevenDayMenuItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_bonus: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_off: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_on: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_tips: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bonus: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_tips: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public async init(data: (typeof SevenDayMgr.instance.menu)[0]) {
        this.__initRc();
        this.node.active = data.active;
        this.RC_lab_off.string = this.RC_lab_on.string = data.title;
        this.RC_lab_tips.string = data.tips;
        this.RC_lab_bonus.string = data.bonus;
        this.RCN_tips.active = data.tips?.length > 0;
        this.RCN_bonus.active = data.bonus?.length > 0;
        const red = await we.common.redDot.red.appendVRedDotNode(this.node);
        cc.isValid(this.node) && (red.children[0].active = data.red > 0);
    }
}
