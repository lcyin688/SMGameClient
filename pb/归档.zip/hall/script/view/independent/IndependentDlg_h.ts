import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import IndependentItem_h from './IndependentItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('IndependentDlgView_h', we.bundles.hall)
class IndependentDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnReceive: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_gray: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_allAward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_progress: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_target: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_timer: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_task: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_over: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_progressBar: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('IndependentDlg_h', we.bundles.hall)
export class IndependentDlg_h extends we.ui.DlgSystem<IndependentDlgView_h> {
    private taskList: ApiProto.TaskProgressDetail[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnReceive, we.core.Func.create(this.onClickReceive, this));
        this.view.cc_onBtnClick(this.view.RC_btnRule, we.core.Func.create(this.onClickRule, this));
        cc.director.on(we.common.EventName.CLOSE_INDEPENDENT_VIEW, this.closeView, this);
        cc.director.on(we.common.EventName.UPDATE_INDEPENDENT_TASK, this.onRefreshUI, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.onRefreshUI();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    protected destroy(): void {
        cc.director.off(we.common.EventName.CLOSE_INDEPENDENT_VIEW, this.closeView, this);
        cc.director.off(we.common.EventName.UPDATE_INDEPENDENT_TASK, this.onRefreshUI, this);
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Independent);
    }

    public beforeUnload() {}

    private onRefreshUI() {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        if (!we.common.independentMgr.isOpenAct()) {
            we.commonUI.showConfirm({
                content: we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7),
                yesHandler: we.core.Func.create(() => {
                    if (cc.isValid(this.view.uiRoot)) {
                        this.closeView();
                    }
                }, this),
            });
            return;
        }

        let data = we.common.independentMgr.actInfo;
        // 任务总进度
        let completeCount = data.completeTaskCount || 0;
        let allCount = this.taskList.length;
        if (completeCount / allCount <= 1) {
            this.view.RC_spr_progressBar.fillRange = completeCount / allCount;
            this.view.RC_lab_progress.string = `${completeCount}`;
            this.view.RC_lab_target.string = ` / ${allCount}`;
        }

        // 刷新活动时间
        let startMs = data.startTime * 1000;
        let endMs = data.endTime * 1000;
        let start = we.common.utils.formatDate(new Date(startMs), 'DD/MM hh:mm');
        let end = we.common.utils.formatDate(new Date(endMs), 'DD/MM hh:mm');
        this.view.RC_lab_timer.string = start + ' - ' + end;
        // 总奖励
        this.view.RC_lab_allAward.string = we.common.utils.formatAmountCurrency(data.ultimateReward);
        // 按钮状态
        this.view.RC_gray.active = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.ONGOING;
        let isCompleted = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.COMPLETED;
        this.view.RC_btnReceive.active = isCompleted;
        this.view.RC_over.active = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
        // 初始化任务列表
        this.taskList = data.independence || [];
        this.addTaskItem();
        // 跳转到可领取任务下标
        this.jumpReceiveTask();
    }

    private addTaskItem(): void {
        this.view.RC_list_task.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list_task.numItems = this.taskList.length;
    }

    protected onRenderEvent(item: cc.Node, i: number) {
        const task: ApiProto.TaskProgressDetail = this.taskList[i];
        let taskItem = item.getComponent(IndependentItem_h);
        taskItem?.init(i, this.taskList.length, task);
    }

    /**
     * 跳转到可领取任务下标
     */
    private jumpReceiveTask(): void {
        if (this.taskList.length < 1) {
            return;
        }
        let receiveIndex = -1;
        for (let i = 0; i < this.taskList.length; i++) {
            if (this.taskList[i].taskStatus == we.common.activityMgr.TaskStatus.COMPLETED) {
                receiveIndex = i;
                break;
            }
        }
        if (receiveIndex > -1) {
            this.view.RC_list_task.scrollTo(receiveIndex);
        }
    }

    private onClickReceive() {
        if (!we.common.independentMgr.isOpenAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
            this.closeView();
            return;
        }

        let param = {} as ApiProto.DrawNewTaskAwardReq;
        param.level = 0; // 总奖励 level 传入 0
        param.taskType = we.common.activityMgr.ActivityType.independence;
        param.typeEnum = we.common.activityMgr.TaskType.ultimate;
        we.common.apiMgr.drawActivityAward(param, (data: ApiProto.DrawNewTaskAwardResp) => {
            if (data.drawAwardStatus == 1) {
                we.common.independentMgr.actInfo.ultimateTaskStatus = we.common.activityMgr.TaskStatus.REWARD_RECEIVED;

                let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.drawAwardNum }];
                HallMgr.openGetAwardsDlg(awardMap);

                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.independent, -1);
                cc.director.emit(we.common.EventName.UPDATE_INDEPENDENT_TASK);
            } else {
                we.common.activityMgr.getTaskAwardErrorHandle(data?.drawAwardStatus);
            }
        });
    }

    private onClickRule() {
        we.currentUI.showSafe(HallViewId.IndependentRuleDlg);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(IndependentDlg_h, `${HallViewId.IndependentDlg}_h`)
class IndependentDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(IndependentDlg_h, uiBase.addComponent(IndependentDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(IndependentDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<IndependentDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(IndependentDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(IndependentDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(IndependentDlg_h).beforeUnload();
    }
}
