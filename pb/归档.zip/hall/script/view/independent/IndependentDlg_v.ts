import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';
import IndependentItem_v from './IndependentItem_v';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('IndependentDlgView_v', we.bundles.hall)
class IndependentDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnReceive: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_allAward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_timer: cc.Label = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_task: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_over: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_gray: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('IndependentDlg_v', we.bundles.hall)
export class IndependentDlg_v extends we.ui.DlgSystem<IndependentDlgView_v> {
    private taskList: ApiProto.TaskProgressDetail[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RC_btnReceive, we.core.Func.create(this.onClickReceive, this));
        this.view.cc_onBtnClick(this.view.RC_btnRule, we.core.Func.create(this.onClickRule, this));

        cc.director.on(we.common.EventName.CLOSE_INDEPENDENT_VIEW, this.closeView, this);
        cc.director.on(we.common.EventName.UPDATE_INDEPENDENT_TASK, this.onRefreshUI, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.onRefreshUI();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    protected destroy(): void {
        cc.director.off(we.common.EventName.CLOSE_INDEPENDENT_VIEW, this.closeView, this);
        cc.director.off(we.common.EventName.UPDATE_INDEPENDENT_TASK, this.onRefreshUI, this);
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Independent);
    }

    public beforeUnload() {}

    private onRefreshUI() {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        if (!we.common.independentMgr.isOpenAct()) {
            we.commonUI.showConfirm({
                content: we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7),
                yesHandler: we.core.Func.create(() => {
                    if (cc.isValid(this.view.uiRoot)) {
                        this.closeView();
                    }
                }, this),
            });
            return;
        }

        let data = we.common.independentMgr.actInfo;
        // 刷新活动时间
        let startMs = data.startTime * 1000;
        let endMs = data.endTime * 1000;
        let start = we.common.utils.formatDate(new Date(startMs), 'DD/MM hh:mm');
        let end = we.common.utils.formatDate(new Date(endMs), 'DD/MM hh:mm');
        this.view.RC_lab_timer.string = start + ' - ' + end;
        // 总奖励
        this.view.RC_lab_allAward.string = we.common.utils.formatAmountCurrency(data.ultimateReward);
        // 按钮状态
        this.view.RCN_gray.active = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.ONGOING;
        let isCompleted = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.COMPLETED;
        this.view.RC_btnReceive.active = isCompleted;
        this.view.RC_over.active = data.ultimateTaskStatus === we.common.activityMgr.TaskStatus.REWARD_RECEIVED;
        // 初始化任务列表
        this.taskList = data.independence || [];
        this.addTaskItem();
        // 跳转到可领取任务下标
        this.jumpReceiveTask();
    }

    private addTaskItem(): void {
        this.view.RC_list_task.setRenderEvent(we.core.Func.create(this.onRenderEvent, this));
        this.view.RC_list_task.numItems = this.taskList.length;
    }

    protected onRenderEvent(item: cc.Node, i: number) {
        const task: ApiProto.TaskProgressDetail = this.taskList[i];
        let taskItem = item.getComponent(IndependentItem_v);
        taskItem?.init(i, this.taskList.length, task);
    }

    /**
     * 跳转到可领取任务下标
     */
    private jumpReceiveTask(): void {
        if (this.taskList.length < 1) {
            return;
        }

        let receiveIndex = -1;
        for (let i = 0; i < this.taskList.length; i++) {
            if (this.taskList[i].taskStatus == we.common.activityMgr.TaskStatus.COMPLETED) {
                receiveIndex = i;
                break;
            }
        }

        if (receiveIndex > -1) {
            this.view.RC_list_task.scrollTo(receiveIndex);
        }
    }

    private onClickReceive() {
        if (!we.common.independentMgr.isOpenAct()) {
            we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang.GET_TASK_AWARD_CODE_7));
            this.closeView();
            return;
        }

        let param = {} as ApiProto.DrawNewTaskAwardReq;
        param.level = 0; // 总奖励 level 传入 0
        param.taskType = we.common.activityMgr.ActivityType.independence;
        param.typeEnum = we.common.activityMgr.TaskType.ultimate;
        we.common.apiMgr.drawActivityAward(param, (data: ApiProto.DrawNewTaskAwardResp) => {
            if (data.drawAwardStatus == 1) {
                we.common.independentMgr.actInfo.ultimateTaskStatus = we.common.activityMgr.TaskStatus.REWARD_RECEIVED;

                let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: data.drawAwardNum }];
                HallMgr.openGetAwardsDlg(awardMap);

                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.independent, -1);
                cc.director.emit(we.common.EventName.UPDATE_INDEPENDENT_TASK);
            } else {
                we.common.activityMgr.getTaskAwardErrorHandle(data?.drawAwardStatus);
            }
        });
    }

    private onClickRule() {
        we.currentUI.showSafe(HallViewId.IndependentRuleDlg);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(IndependentDlg_v, `${HallViewId.IndependentDlg}_v`)
class IndependentDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(IndependentDlg_v, uiBase.addComponent(IndependentDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(IndependentDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<IndependentDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(IndependentDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(IndependentDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(IndependentDlg_v).beforeUnload();
    }
}
