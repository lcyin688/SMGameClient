import { HallRes } from '../../config/HallRes';
import JumpModMgr from '../../manager/JumpModMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('JoinUsDlgView_h', we.bundles.hall)
class JoinUsDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnTodayNoProp: cc.Node = null;

    @we.ui.ccBind(cc.ScrollView)
    public RC_scroll_way: cc.ScrollView = null;

    @we.ui.ccBind(cc.Node)
    public RC_select: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('JoinUsDlg_h', we.bundles.hall)
export class JoinUsDlg_h extends we.ui.DlgSystem<JoinUsDlgView_h> {
    private todayNoPropJoinUs: boolean = false;
    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnTodayNoProp, we.core.Func.create(this.onClickNoProp, this));
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.todayNoPropJoinUs = we.common.storage.get('common', 'no_prop_join_us');
        this.view.RC_select.active = this.todayNoPropJoinUs;
        this.init();
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Join_Us);
    }

    public beforeUnload() {}

    public async init() {
        const waysIcon = await this.loadAsset(HallRes.prefab.joinUsWay, cc.Prefab);
        this.scheduleOnce(0).then(() => {
            this.view.RC_scroll_way.content.removeAllChildren();
            let conf = we.core.projectConfig.settingsConfig?.thirdLinkConf ?? [];
            if (conf?.length > 0) {
                for (let i = 0; i < conf.length; i++) {
                    let node = cc.instantiate(waysIcon);
                    let name = conf[i].name ? conf[i].name : `joinus_way_${i}`;
                    this.view.RC_scroll_way.content.addChild(node, i, name);
                    this.initWayIcon(node, conf[i]);
                }
                we.common.redDot.red.quickSetRedDotData(
                    we.common.redDot.cfg.joinUs,
                    conf.map((_, index) => {
                        return {
                            name: `joinus_way_${index}`,
                            count: Number(!we.common.activityMgr.isClickJoinUs),
                        };
                    })
                );
            }
        });
    }

    private initWayIcon(node: cc.Node, data: ApiProto.ThirdLinkConf): void {
        if (!node || !data) {
            return;
        }

        node['jumpPosition'] = data;
        let icon = cc.find('icon', node)?.getComponent(cc.Sprite);
        if (icon && data.icon?.[we.core.langMgr.getCurLangCode()]) {
            let url = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig?.downloadUrl, data.icon?.[we.core.langMgr.getCurLangCode()]);
            this.loadAssetRemote(url, cc.SpriteFrame, node).then((spriteFrame) => {
                icon.spriteFrame = spriteFrame;
                icon.sizeMode = cc.Sprite.SizeMode.TRIMMED;
                icon.trim = false;
            });
        }
        this.view.cc_offBtnClick(node);
        this.view.cc_onBtnClick(node, we.core.Func.create(this.onClickJump, this));

        // 添加红点元素
        we.common.redDot.red.appendVRedDotNode(node).then((notice) => {
            if (!cc.isValid(node)) {
                return;
            }
            we.common.redDot.red.registeredRedDot({
                paths: we.common.redDot.cfg.joinUs.map((path) => {
                    return `${path}/${node.name}`;
                }),
                node: notice,
            });
        });
    }

    private onClickNoProp(): void {
        this.todayNoPropJoinUs = !this.todayNoPropJoinUs;
        this.view.RC_select.active = this.todayNoPropJoinUs;

        we.common.storage.setById('common', 'no_prop_join_us', this.todayNoPropJoinUs);
    }

    private onClickJump(event): void {
        const node = event.target;

        we.common.activityMgr.isClickJoinUs = true;
        we.common.storage.setById('common', 'click_join_us_jump', true);
        we.common.storage.setById('common', 'no_prop_join_us', this.todayNoPropJoinUs);
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.joinUs, 0);
        this.setNotice();

        let data: ApiProto.ThirdLinkConf = node['jumpPosition'];
        if (!data) {
            return;
        }

        let jumpPos = null;
        // 读取配置缓存加入我们跳转配置
        let jumpRecord = we.common.storage.get('common', 'click_join_us_record') || {};
        if (jumpRecord[node.name]) {
            jumpPos = jumpRecord[node.name];
            if (!data.links?.includes(jumpPos)) {
                // 缓存方式不在下发配置中重置
                jumpPos = null;
                jumpRecord[node.name] = null;
            }
        }

        // 随机跳转地址
        if (!jumpPos) {
            let linksLen = data?.links?.length || 0;
            if (linksLen > 0) {
                let index = Math.floor(Math.random() * (linksLen - 0.001));
                jumpPos = data.links?.[index];
            } else {
                jumpPos = data.link;
            }
        }

        if (jumpPos) {
            jumpRecord[node.name] = jumpPos;
            we.common.storage.setById('common', 'click_join_us_record', jumpRecord);

            JumpModMgr.jumpToModule(jumpPos);
        } else {
            we.warn(`JoinUsDialog_h onClickJump, jumpPos is null`);
        }
    }

    private setNotice(): void {
        let children = this.view.RC_scroll_way.content.children ?? [];
        children.forEach((node) => {
            we.common.redDot.red.updateRedDotCnt([`${we.common.redDot.cfg.joinUs}/${node.name}`], 0, true);
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(JoinUsDlg_h, `${HallViewId.JoinUsDlg}_h`)
class JoinUsDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(JoinUsDlg_h, uiBase.addComponent(JoinUsDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(JoinUsDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<JoinUsDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(JoinUsDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(JoinUsDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(JoinUsDlg_h).beforeUnload();
    }
}
