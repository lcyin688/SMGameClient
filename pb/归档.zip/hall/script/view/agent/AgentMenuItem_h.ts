import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentMenuItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_offDesc: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_onDesc: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_offBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_offIcon: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_onBg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_onIcon: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_line: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(type: number, curIndex: number, listLength: number): void {
        this.__initRc();

        let langKey = null;
        switch (type) {
            case we.common.agentMgr.Detail_Type.INVITE_REBATE:
                langKey = HallLanguage.INVITE_HAll_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.INVITE_REWARD:
                langKey = HallLanguage.INVITE_REWARDS_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.BET_REWARD:
                langKey = HallLanguage.INVITE_BETTING_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.RECHARGE_REWARD:
                langKey = HallLanguage.INVITE_REBATE_Bonus1;
                break;
            case we.common.agentMgr.Detail_Type.VALID_REWARD:
                langKey = HallLanguage.INVITE_QUANTITY_Bonus1;
                break;
            default:
                break;
        }
        if (langKey) {
            let descStr = we.core.langMgr.getLangText(langKey);
            this.RC_lab_offDesc.string = descStr;
            this.RC_lab_onDesc.string = descStr;
        }

        let isShowLine = curIndex < listLength - 1;
        this.RCN_line.active = isShowLine;

        let bgIdx = 0;
        if (curIndex == 0) {
            bgIdx = 0;
        } else if (curIndex > 0 && curIndex < listLength - 1) {
            bgIdx = 1;
        } else if (curIndex == listLength - 1) {
            bgIdx = 2;
        }
        this.RC_offBg.getComponent(we.ui.WESpriteIndex)?.setIndex(bgIdx);
        this.RC_onBg.getComponent(we.ui.WESpriteIndex)?.setIndex(bgIdx);

        this.RC_offIcon.getComponent(we.ui.WESpriteIndex)?.setIndex(type);
        this.RC_onIcon.getComponent(we.ui.WESpriteIndex)?.setIndex(type);
    }
}
