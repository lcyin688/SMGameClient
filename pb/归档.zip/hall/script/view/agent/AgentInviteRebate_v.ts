import { HallLanguage } from '../../const/HallLanguage';
import HallMgr from '../../manager/HallMgr';
import { HallViewId } from '../HallViewId';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentInviteRebate_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnBind: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnCopy: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnInviteDetails: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnReceive: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRewardRecord: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnSave: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_directNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_earningNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_linkHref: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_otherNum: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_superiorId: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_superiorNo: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_qrCode: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_received: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.initData();

        let linkContent = we.common.agentMgr.getAgentLink();
        we.common.utils.generateQrCode(this.RCN_qrCode, linkContent);
        this.RC_lab_linkHref.string = linkContent;

        this.onBtnClick(this.RC_btnBind, we.core.Func.create(this.onClickBindBtn, this));
        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRuleBtn, this));
        this.onBtnClick(this.RC_btnCopy, we.core.Func.create(this.onClickCopyBtn, this));
        this.onBtnClick(this.RC_btnSave, we.core.Func.create(this.onClickSaveBtn, this));
        this.onBtnClick(this.RC_btnInviteDetails, we.core.Func.create(this.onClickInviteDetailsBtn, this));
        this.onBtnClick(this.RC_btnRewardRecord, we.core.Func.create(this.onClickRewardRecordBtn, this));
        this.onBtnClick(this.RC_btnReceive, we.core.Func.create(this.onClickReceiveBtn, this));
    }

    protected onEnable(): void {
        we.common.agentMgr.getInviteInfo(this.initData.bind(this));
    }

    public initData(): void {
        if (!cc.isValid(this.node)) {
            return;
        }

        this.RC_btnReceive.active = false;
        this.RCN_received.active = false;

        let inviteInfo = we.common.agentMgr.inviteInfo;
        if (inviteInfo) {
            this.RC_lab_directNum.string = '' + (inviteInfo.directSub || 0);
            this.RC_lab_otherNum.string = '' + (inviteInfo.otherSub || 0);
            this.RC_lab_earningNum.string = we.common.utils.formatAmountCurrency(inviteInfo.rewardReceived || 0, true);
            this.RC_lab_award.string = inviteInfo.rewardRemaining > 0 ? we.common.utils.formatAmount(inviteInfo.rewardRemaining, false) : '';
            if (inviteInfo.rewardRemaining == 0) {
                this.setReceiveStatus(false);
            } else {
                this.setReceiveStatus(true);
            }
            if (inviteInfo.upId) {
                this.RC_lab_superiorId.node.active = true;
                this.RC_lab_superiorId.string = 'ID ' + inviteInfo.upId;
                this.RC_btnBind.active = false;
                this.RC_lab_superiorNo.node.active = false;
            } else {
                const manualBindSwitch = true && we.common.agentMgr?.agentConfig?.manualBindSwitch;
                this.RC_btnBind.active = manualBindSwitch;
                this.RC_lab_superiorNo.node.active = !manualBindSwitch;
                this.RC_lab_superiorId.node.active = false;
            }
        }
    }

    private onClickCopyBtn(): void {
        we.commonUI.showToast(we.core.langMgr.getLangText(HallLanguage.INVITE_INTRODUCE_TIPS_003));
        let link = we.common.agentMgr.getAgentLink();
        we.core.nativeUtil.copyText(link);
    }

    private onClickInviteDetailsBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentDetailsDlg);
    }

    private onClickRewardRecordBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentRewardRecordDlg);
    }

    private onClickReceiveBtn() {
        we.common.agentMgr.getAgentReward((data: ApiProto.AgentDrawRewardResp) => {
            if (data?.drawStatus) {
                const coin = data.drawNum;
                let awardMap = [{ id: we.common.userMgr.PropId.CoinId, num: coin }];
                HallMgr.openGetAwardsDlg(awardMap);

                we.common.agentMgr.inviteInfo.rewardRemaining = 0;
                we.common.agentMgr.inviteInfo.rewardReceived += coin;

                if (cc.isValid(this.node)) {
                    this.RC_lab_award.string = '';
                    this.setReceiveStatus(false);
                    this.RC_lab_earningNum.string = we.common.utils.formatAmountCurrency(we.common.agentMgr.inviteInfo.rewardReceived || 0, true, 2);
                }
            }
        });
    }

    private setReceiveStatus(value: boolean): void {
        this.RC_btnReceive.active = value;
        this.RCN_received.active = !value;
    }

    private onClickSaveBtn(): void {
        we.currentUI.show(HallViewId.AgentQRDlg);
    }

    private onClickBindBtn(): void {
        we.currentUI.show(HallViewId.AgentManuallyBindDlg, (userId) => {
            if (!cc.isValid(this.node)) {
                return;
            }

            this.RC_btnBind.active = false;
            this.RC_lab_superiorId.string = 'ID ' + userId;
            this.RC_lab_superiorId.node.active = true;
            we.common.agentMgr.inviteInfo.upId = userId;
        });
    }

    private onClickRuleBtn(): void {
        we.currentUI.showSafe(HallViewId.AgentInviteRebateRuleDlg);
    }
}
