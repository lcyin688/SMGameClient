import { HallRes } from '../../config/HallRes';
import { HallViewId } from '../HallViewId';
import AgentDetailsList_v from './prop/AgentDetailsList_v';

const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentCodeRebate_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnRule: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_availableReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_directReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_otherReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_receivedReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_todayReward: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_yesterdayReward: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RCN_details: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    protected onLoad(): void {
        this.initDetails();

        this.onBtnClick(this.RC_btnRule, we.core.Func.create(this.onClickRuleBtn, this));
    }

    protected onEnable(): void {
        this.getRewardData();
    }

    private getRewardData(): void {
        we.common.agentMgr.getBetAmountRewards((data: ApiProto.AgentBetAmountRewardsResp) => {
            if (data && cc.isValid(this.node)) {
                this.RC_lab_yesterdayReward.string = we.common.utils.formatAmountCurrency(data.yesterdayBetRewards);
                this.RC_lab_todayReward.string = we.common.utils.formatAmountCurrency(data.todayBetRewards);
                this.RC_lab_directReward.string = we.common.utils.formatAmountCurrency(data.directBetRewards);
                this.RC_lab_otherReward.string = we.common.utils.formatAmountCurrency(data.otherBetRewards);
                this.RC_lab_receivedReward.string = we.common.utils.formatAmountCurrency(data.receivedRewards);
                this.RC_lab_availableReward.string = we.common.utils.formatAmountCurrency(data.rewardsRemaining);
            }
        });
    }

    private async initDetails(): Promise<void> {
        const itemPrefab = await this.loadAsset(HallRes.prefab.agent.AgentDetailsList, cc.Prefab);
        let node = cc.instantiate(itemPrefab);
        node.getComponent(AgentDetailsList_v)?.setContextData(we.common.agentMgr.Detail_Type.BET_REWARD);
        this.RCN_details.addChild(node);
    }

    private onClickRuleBtn(): void {
        we.currentUI.show(HallViewId.AgentRechargeCodeRuleDlg, we.common.agentMgr.Detail_Type.BET_REWARD);
    }
}
