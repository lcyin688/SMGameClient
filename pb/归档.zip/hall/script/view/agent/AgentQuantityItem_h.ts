const { ccclass, property } = cc._decorator;

@ccclass
export default class AgentQuantityItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_award: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_progress: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_target: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_valid: cc.Label = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_spr_icon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Node)
    public RCN_completed: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_going: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_lightBox: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rightArrow: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    public init(validAgentNum: number, taskIndex: number, taskList: ApiProto.ValidAgentRewardsItem[]): void {
        this.__initRc();

        const task: ApiProto.ValidAgentRewardsItem = taskList[taskIndex];
        this.RC_lab_award.string = we.common.utils.formatAmountCurrency(task.validAgentRewards);

        this.RCN_going.active = false;
        this.RCN_completed.active = false;
        if (validAgentNum < task.validNum) {
            this.RC_lab_progress.string = '' + validAgentNum;
            this.RC_lab_target.string = '/' + task.validNum;
            this.RCN_going.active = true;
        } else {
            this.RC_lab_valid.string = '' + task.validNum;
            this.RCN_completed.active = true;
        }

        let lightIndex = -1;
        for (let i = 0; i < taskList.length; i++) {
            if (validAgentNum < taskList[i].validNum) {
                lightIndex = i;
                break;
            }
        }
        this.RCN_lightBox.active = lightIndex == taskIndex;

        let iconIndex = this.getIconIndex(taskIndex, taskList.length, this.RC_spr_icon.maxIndex);
        this.RC_spr_icon.setIndex(iconIndex);

        let isShowRightArrow = taskIndex < taskList.length - 1;
        this.RCN_rightArrow.active = isShowRightArrow;
    }

    private getIconIndex(taskIndex: number, taskLength: number, iconNum: number): number {
        let iconIndex = -1;
        if (iconNum < 1) {
            return iconIndex;
        }

        if (taskLength <= iconNum) {
            iconIndex = taskIndex;
        } else {
            const quotient = Math.floor(taskLength / iconNum);
            const remainder = taskLength % iconNum;

            let addCount = 0;
            for (let i = 0; i < iconNum; i++) {
                const count = quotient + (i < remainder ? 1 : 0);
                addCount += count;
                if (taskIndex < addCount) {
                    iconIndex = i;
                    break;
                }
            }
        }

        return iconIndex;
    }
}
