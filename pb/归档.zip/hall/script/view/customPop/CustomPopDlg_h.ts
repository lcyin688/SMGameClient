import { HallPopupMgr } from '../../manager/HallPopupMgr';
import JumpModMgr from '../../manager/JumpModMgr';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('CustomPopDlgView_h', we.bundles.hall)
class CustomPopDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WEPageView)
    public RC_banner: we.ui.WEPageView = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('CustomPopDlg_h', we.bundles.hall)
export class CustomPopDlg_h extends we.ui.DlgSystem<CustomPopDlgView_h> {
    private conf: ApiProto.PopupResource[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));

        this.view.RC_banner.setRender(we.core.Func.create(this.onRenderBanner, this));
        this.view.RC_banner.setClick(we.core.Func.create(this.onClickBanner, this));
    }

    /**
     * 显示窗口
     * @param popupOrder 弹出排序
     */
    public async onShow(popupOrder: number = -1) {
        // 设置数据
        let data = HallPopupMgr.Inst.getCustomPopConf();
        if (popupOrder != -1) {
            for (let i = 0; i < data.length; i++) {
                if (data[i].popupOrder == popupOrder) {
                    this.conf = data[i].popupResource || [];
                    break;
                }
            }
        }

        if (this.conf.length < 1) {
            this.conf = HallPopupMgr.Inst.getCustomPopConf()[0]?.popupResource || [];
        }

        this.view.RC_banner.totalPage = this.conf.length;
        this.view.RC_banner.jumpToPage(0);
        this.view.RC_banner.autoLoop(this.conf.length > 1 ? 6 : -1);
    }

    /** 隐藏窗口 */
    public async onHide() {
        cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Custom_Dlg);
    }

    public beforeUnload() {}

    private onRenderBanner(item: cc.Node, idx: number) {
        const data = this.conf[idx];
        const url = data.urls[we.core.langMgr.getCurLangCode()];

        const sprite = item.children[0].getComponent(cc.Sprite);
        if (url && sprite) {
            this.loadAssetRemote(url, cc.SpriteFrame, item).then((spf) => {
                sprite.spriteFrame = spf;
            });
        }
    }

    private onClickBanner(item: cc.Node, idx: number) {
        const data = this.conf[idx];
        if (data) {
            JumpModMgr.jumpToModule(data.jumpPosition);
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(CustomPopDlg_h, `${HallViewId.CustomPopDlg}_h`)
class CustomPopDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(CustomPopDlg_h, uiBase.addComponent(CustomPopDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CustomPopDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<CustomPopDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(CustomPopDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CustomPopDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(CustomPopDlg_h).beforeUnload();
    }
}
