import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallPageEnum } from '../../const/HallConst';
import HallEntryList from '../../extend/hall/HallEntryList';
import DownLoadTouchMove from '../../extend/others/DownLoadTouchMove';
import HallMgr from '../../manager/HallMgr';
import JumpModMgr from '../../manager/JumpModMgr';
import MonthSign from '../../manager/MonthSignMgr';
import WeekCardMgr from '../../manager/WeekCardMgr';
import SevenDayMgr from '../../manager/SevenDayMgr';
import { HallViewId } from '../HallViewId';
import HallMenuDropdown_h from './HallMenuDropdown_h';
import { HallPopupMgr } from '../../manager/HallPopupMgr';

type EntryConfig = { event: string | symbol; condition: () => boolean; path: string; parent: cc.Node; callback?: Function };

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('HallDlgView_h', we.bundles.hall)
class HallDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_download: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_downLoadTouchParent: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_entry_list: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_games: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_id: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_money: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_name: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_quick_start_desc: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vip: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_left_btns: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_left_btns_list: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_quick_start_bg: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_search: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_head: cc.Sprite = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vip: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_top: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_BankEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bottom: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bottomVip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_addCoin: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_android: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_head: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_ios: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_setting: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnLayout: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_CarnivalEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_DailyAwardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_DailyRechargeRewardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_delegate_btn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_event_btn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_IndependentEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_JoinUsEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_mail_btn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_member_btn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_MonthSignEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_MonthSign2Entry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_NewbieGiftBagEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_OfficialPkgAwardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_QuestionNaireEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_quickStart: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rebate_btn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_RedeemCodeEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_RescueFundsEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_rightBtn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_SafeEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_service_btn: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_SevenDayEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_shop: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_topVip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_TurntableEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_VIPEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_WeekCardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_withdraw: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    /** 头像，新增的可以多语言切换提示面板 */
    @we.ui.ccBind(cc.Node)
    public RCN_btn_head_tips: cc.Node = null;
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('HallDlg_h', we.bundles.hall)
export class HallDlg_h extends we.ui.DlgSystem<HallDlgView_h> {
    // /** 是否显示 提现 按钮 */
    // private isShowWithdraw: boolean = false;

    // /** 是否显示搜索游戏界面 */
    // private isOpenSearchGame: boolean = false;

    private mail_tips: cc.Node;
    private service_tips: cc.Node;
    /** 收集活动列表按钮 */
    private dropdownMenu: HallMenuDropdown_h = null;

    private emailCount = 0;

    private entryConfig: EntryConfig[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        we.core.audioMgr.playMusic(we.core.projectConfig.commonConfig.brandBgmUrl);

        this.updateData();

        this.onInitMenuPage();

        this.setUserInfo();

        this.registerRedPoints();

        this.setRightBtns();

        // btns
        this.view.cc_onBtnClick(this.view.RCN_btn_head, we.core.Func.create(this.onClickHead, this)).setTransitionNone();
        this.view.cc_onBtnClick(this.view.RCN_btn_addCoin, we.core.Func.create(this.onClickAddCoin, this)).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_shop, we.core.Func.create(this.onClickAddCoin, this)).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_btn_android, we.core.Func.create(this.onClickDownloadApk, this));
        this.view.cc_onBtnClick(this.view.RCN_btn_ios, we.core.Func.create(this.onClickIconIosBtn, this));
        this.view.cc_onBtnClick(this.view.RCN_member_btn, this.onClickMember).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_topVip, this.onClickVip).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_service_btn, this.onClickService).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_mail_btn, this.onClickEmail).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_rebate_btn, this.onClickRebate).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_delegate_btn, this.onClickDelegate).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_quickStart, this.onClickQuickStart).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_event_btn, this.onClickEventBtn).setTransitionScale();
        if (this.view.RCN_bottomVip) {
            this.view.cc_onBtnClick(this.view.RCN_bottomVip, this.onClickVip).setTransitionScale();
        }
        if (this.view.RCN_btn_setting) {
            this.view.cc_onBtnClick(this.view.RCN_btn_setting, we.core.Func.create(this.onClickHead, this));
        }

        // 红点注册
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.eventCenter, node: this.view.RCN_event_btn.getChildByName('notice') });

        // events
        cc.director.on(we.core.EventName.GAME_SHOW, this.initEntry, this);

        cc.director.on(we.common.EventName.CHECK_PAY_SUCCESS_PUSH, this.checkPaySucNotice, this);
        cc.director.on(we.common.EventName.UPDATE_GOLD_SHOW, this.updateGold, this);
        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.setUserInfo, this);
        cc.director.on(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.on(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.onShowWithdraw, this);
        cc.director.on(we.common.EventName.NOTICE_NEW_CUSTOMER, this.onNoticeCustomerService, this); // 客服红点通知
        cc.director.on(we.common.EventName.NOTICE_EVENT_CENTER, this.onActionNotice, this);
        cc.director.on(we.common.EventName.ACTIVITY_DATA_INIT, this.initEntry, this);
        cc.director.on(we.common.EventName.UPDATE_HALL_TOP_MENU, this.refreshEntry, this);

        cc.director.on(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);
        cc.director.on(HallEvent.SHOW_PLAYER_START_COIN, this.setUserInfo, this);
        cc.director.on(HallEvent.WITHDRAW_UPDATE_GOLD, this.updateGold, this);

        this.registerEntry();

        we.event<we.core.EventMsg>().on('LangChanged', this.updataLabel, this);

        // 是否显示提现按钮
        this.view.RCN_withdraw.active = false;
        we.common.withdrawMgr.judgeIsShowWithdraw();

        // 多语言切换提示
        this.showChangeLangTips();
    }

    protected start(): void {
        this.view.RC_search.active = false;

        this.initEntry();

        HallPopupMgr.Inst.showPopup();
    }

    protected destroy(): void {
        cc.director.off(we.core.EventName.GAME_SHOW, this.initEntry, this);
        cc.director.off(we.common.EventName.CHECK_PAY_SUCCESS_PUSH, this.checkPaySucNotice, this);
        cc.director.off(we.common.EventName.UPDATE_GOLD_SHOW, this.updateGold, this);
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.setUserInfo, this);
        cc.director.off(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.off(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.onShowWithdraw, this);
        cc.director.off(we.common.EventName.NOTICE_NEW_CUSTOMER, this.onNoticeCustomerService, this);
        cc.director.off(we.common.EventName.NOTICE_EVENT_CENTER, this.onActionNotice, this);
        cc.director.off(we.common.EventName.ACTIVITY_DATA_INIT, this.initEntry, this);
        cc.director.off(we.common.EventName.UPDATE_HALL_TOP_MENU, this.refreshEntry, this);
        cc.director.off(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);
        cc.director.off(HallEvent.SHOW_PLAYER_START_COIN, this.setUserInfo, this);
        cc.director.off(HallEvent.WITHDRAW_UPDATE_GOLD, this.updateGold, this);
        this.entryConfig.forEach((config) => {
            config.event && cc.director.off(config.event, config.callback, this);
        });
        this.entryConfig.length = 0;
        we.event<we.core.EventMsg>().off('LangChanged', this.updataLabel, this);
    }

    /** 注册红点显示 */
    private registerRedPoints() {
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vip, node: this.view.RCN_topVip.getChildByName('notice') });
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.server, node: this.view.RCN_service_btn.getChildByName('notice') });
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.rebateCode, node: this.view.RCN_rebate_btn.getChildByName('notice') });
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.agent, node: this.view.RCN_delegate_btn.getChildByName('notice') });
        if (this.view.RCN_bottomVip) {
            we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vip, node: this.view.RCN_bottomVip.getChildByName('notice') });
        }

        this.mail_tips = this.view.RCN_mail_btn.getChildByName('tips');
        this.service_tips = this.view.RCN_service_btn.getChildByName('tips');

        // 邮件红点
        this.emailCount = we.common.redDot.red.getRedDotCnt(we.common.redDot.cfg.mail);
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.mail, node: this.view.RCN_mail_btn.getChildByName('notice'), callback: this.onNoticeMail.bind(this) });
    }

    /** 显示窗口 */
    public async onShow(pageIndex: HallPageEnum = null) {
        switch (pageIndex) {
            case HallPageEnum.shop: {
                we.currentUI.show(HallViewId.StoreDlg);
                break;
            }
            case HallPageEnum.withdraw: {
                we.currentUI.show(HallViewId.WithdrawDlg);
                break;
            }
            case HallPageEnum.games: {
                break;
            }
            case HallPageEnum.event: {
                we.currentUI.show(HallViewId.ActivityDlg);
                break;
            }
            case HallPageEnum.me: {
                we.currentUI.show(HallViewId.UserCenterDlg);
                break;
            }
            default:
                break;
        }

        this.view.RCN_rebate_btn.active = we.core.projectConfig.settingsConfig?.userRebateSwitch;
        this.view.RCN_delegate_btn.active = we.core.projectConfig.settingsConfig?.funcSwitch?.agentSwitch;

        this.setLeftBtns();
        this.setQuickStartDesc();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private onActionNotice() {
        we.common.activityMgr.updateEventCenter();
    }

    private updataLabel() {
        this.setQuickStartDesc();
    }

    /** 刷新数据 */
    private updateData() {
        we.common.VIPConfig.getVipAwardStatus();
        we.common.activityMgr.updateEventCenter();
        this.checkPaySucNotice();

        if (we.common.userMgr.isFirstRegister) {
            we.currentUI.show(HallViewId.PhoneBindScreenshotPromptDlg, null, true);
        }
    }

    /** 初始化分页 */
    private onInitMenuPage() {
        // add games
        const hallMiddleView = this.getAsset(HallRes.prefab.HallGames, cc.Prefab);
        hallMiddleView && this.view.RC_games.addChild(cc.instantiate(hallMiddleView));
    }

    private onShowWithdraw(isShow: boolean) {
        if (!this.isValid()) {
            return;
        }
        if (isShow === true) {
            this.view.RCN_withdraw.active = true;
            we.commonUI.createNode(HallRes.prefab.withdrawEntry, this.view.RCN_withdraw);
        } else {
            this.view.RCN_withdraw.active = false;
        }
        this.view.RCN_bottom.emit('size-changed');
    }

    private checkPaySucNotice(): void {
        if (we.common.pushMsgMgr.pushMsgCacheList) {
            let data: any[] = we.common.pushMsgMgr.pushMsgCacheList.get(we.common.pushMsgMgr.PUSH_TYPE.PAY_SUCCESS) || [];
            if (data.length > 0) {
                let payData = data.shift();
                we.common.pushMsgMgr.onHandleSucNotice(payData);
                we.common.pushMsgMgr.pushMsgCacheList.set(we.common.pushMsgMgr.PUSH_TYPE.PAY_SUCCESS, data);
            }
        }
    }

    private setUserInfo() {
        if (!cc.isValid(this.view.RC_spr_head)) {
            return;
        }

        if (!we.common.userMgr.isShowGiveDialog) {
            let coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
            this.view.RC_lab_money.string = we.common.utils.formatAmountCurrency(coin);
            this.view.RC_lab_money.node['actions_labelNumRoll_value'] = coin; // 刷新金币滚动开始值
        } else {
            // 新用户第一次进入游戏，领取赠送的金币奖励后再显示金币数
            this.view.RC_lab_money.string = we.common.utils.formatAmountCurrency(0);
            this.view.RC_lab_money.node['actions_labelNumRoll_value'] = 0; // 刷新金币滚动开始值
        }

        // 设置玩家头像
        we.common.utils.setAvatarSprite(this.view.RC_spr_head, we.common.userMgr.userInfo.avatar, we.common.userMgr.userInfo.gender, false);

        // 设置玩家昵称
        let showName = we.common.userMgr.userInfo.userName;
        if (we.common.userMgr.userInfo.userName.length > 10) {
            showName = showName.substring(0, 8) + '...';
        }
        // name
        this.view.RC_lab_name.string = showName;

        // vip
        this.view.RC_lab_vip.string = `VIP` + we.common.userMgr.vipExp.level;
        let path = HallRes.texture.VIP_Logo_icon + we.common.userMgr.vipExp.level;
        if (we.core.flavor.getSkinCode() === we.core.SkinCode.ct) {
            path = HallRes.texture.VIP_Lv_icon + we.common.userMgr.vipExp.level;
        }

        // id
        if (this.view.RC_lab_id) {
            this.view.RC_lab_id.string = we.common.userMgr.userInfo.userId + '';
        }

        we.common.utils.setComponentSprite(this.view.RC_spr_vip, path);
    }

    private updateGold(latestCredit?: number) {
        if (!cc.isValid(this.view.RC_lab_money)) {
            return;
        }

        let coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
        if (cc.isValid(latestCredit)) {
            coin = latestCredit;
        }

        this.view.RC_lab_money.string = we.common.utils.formatAmountCurrency(coin);
        this.view.RC_lab_money.node['actions_labelNumRoll_value'] = coin; // 刷新金币滚动开始值
    }

    private coinFlyAnim(params: { node: cc.Node; award: number }): void {
        HallMgr.coinFlyAnim(params, this.view.uiRoot, this.view.RC_lab_money.node);
    }

    private setQuickStartDesc(): void {
        let gameId: we.GameId = -1;
        let gameInfo = we.common.gameMgr.getLastGameInfo();
        if (we.core.gameConfig.isSubGame(gameInfo.gameId)) {
            gameId = gameInfo?.gameId;
        }

        let quickStartDesc = '';
        if (we.core.gameConfig.isSubGame(gameId)) {
            quickStartDesc = we.common.gameMgr.getGameEntryName(gameId);
        }
        this.view.RC_lab_quick_start_desc.string = quickStartDesc;
        this.view.RC_lab_quick_start_desc.node.active = quickStartDesc != '';
        if (this.view.RC_quick_start_bg) {
            this.view.RC_quick_start_bg.active = this.view.RC_lab_quick_start_desc.node.active;
        }
    }

    private onClickQuickStart(): void {
        HallMgr.openRecentGame();
    }

    /** 邮件 */
    private onClickEmail() {
        we.currentUI.show(HallViewId.MailDlg);
    }

    /** 头像 */
    private onClickHead() {
        if (cc.isValid(this.view.RCN_btn_head_tips)) {
            this.view.RCN_btn_head_tips.active = false;
        }
        we.currentUI.show(HallViewId.UserCenterDlg);
    }

    /** vip */
    private onClickVip() {
        we.currentUI.show(HallViewId.VipViewDlg);
    }
    /** 会员中心 */
    private onClickMember() {
        we.currentUI.show(HallViewId.MemberCenterDlg);
    }

    /** 商场 */
    private onClickAddCoin() {
        we.currentUI.show(HallViewId.StoreDlg);
    }

    /** 客服 */
    private onClickService() {
        we.common.commonMgr.openCustomerDialog();
    }

    /** 下载引导 */
    private onClickDownloadApk() {
        HallMgr.clickApkDownloadBtn();
    }

    /** ios收藏引导弹窗 */
    private onClickIconIosBtn() {
        HallMgr.clickIosCollectBtn();
    }

    /** 打码返利 */
    private onClickRebate(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Rebate);
    }

    /** 代理 */
    private onClickDelegate(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Agent);
    }

    private onClickEventBtn(): void {
        HallMgr.openActivity();
    }

    /** 提现 */
    private onClickWithdraw(): void {
        JumpModMgr.jumpToModule(we.common.JumpCmd.Withdraw);
    }

    private setLeftBtns() {
        if (cc.sys.isBrowser) {
            this.view.RCN_btn_android.active = we.common.downloadGuideMgr.isShowApkDownload();
            if (this.view.RCN_btn_android.active) {
                let downLoadTouchMove = this.view.RCN_btn_android.getComponent(DownLoadTouchMove);
                downLoadTouchMove?.initTouchMove(this.view.RC_downLoadTouchParent);
            }
            this.view.RCN_btn_ios.active = we.common.downloadGuideMgr.isShowIosCollect();
            if (this.view.RCN_btn_ios.active) {
                let downLoadTouchMove = this.view.RCN_btn_ios.getComponent(DownLoadTouchMove);
                downLoadTouchMove?.initTouchMove(this.view.RC_downLoadTouchParent);
            }
            this.view.RC_download.active = this.view.RCN_btn_ios.active || this.view.RCN_btn_android.active;
        } else {
            this.view.RC_download.active = false;
        }
    }

    private setRightBtns(): void {
        // 下拉菜单
        const menuDropdown = this.getAsset(HallRes.prefab.hallMenuDropdown, cc.Prefab);
        if (menuDropdown) {
            const menuDropdownNode = cc.instantiate(menuDropdown);
            this.view.RCN_rightBtn.insertChild(menuDropdownNode, 0);
            this.dropdownMenu = menuDropdownNode?.getComponent(HallMenuDropdown_h);
        }
    }

    private async onShowSearchGame(isShow: boolean) {
        this.view.RC_left_btns.active = !isShow;
        this.view.RCN_bottom.active = !isShow;

        if (isShow) {
            if (this.view.RC_search.children.length == 0) {
                const hallSearchGamePb = await this.loadAsset(HallRes.prefab.HallSearchGame, cc.Prefab);
                if (hallSearchGamePb) {
                    this.view.RC_search.addChild(cc.instantiate(hallSearchGamePb));
                }
            }
        }
        this.view.RC_search.active = isShow;
    }

    /** 邮件红点 设置 */
    private onNoticeMail(amount: number, info: any): void {
        if (!cc.isValid(this.mail_tips)) {
            return;
        }

        if (amount <= 0) {
            this.mail_tips.active = false;
            this.emailCount = 0;
            return;
        }

        if (this.emailCount >= amount) {
            this.emailCount = amount;
            return;
        }
        this.emailCount = amount;

        we.core.audioMgr.playEffect(HallRes.audio.ding);

        // 防抖
        if (we.core.utils.isQuickClick(this.mail_tips.uuid, 11000)) {
            return;
        }

        // anim
        this.mail_tips.active = true;
        this.mail_tips.stopAllActions();
        this.tween(this.mail_tips).set({ scale: 0, opacity: 1 }).show().to(0.4, { scale: 1, opacity: 255 }, { easing: 'sineIn' }).delay(10).to(0.2, { scale: 0, opacity: 1 }, { easing: 'sineOut' }).hide().start();
    }

    /** 客服红点 */
    private onNoticeCustomerService(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        let isNewMsg = we.common.storage.get('common', 'customer');
        if (isNewMsg) {
            this.service_tips.active = true;
            this.service_tips.stopAllActions();
            this.service_tips.scale = 0;
            this.service_tips.opacity = 0;
            this.tween(this.service_tips).to(0.4, { scale: 1, opacity: 255 }, { easing: 'sineInOut' }).start();
        } else {
            this.service_tips.active = false;
        }
    }

    // ////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////// 收集活动列表按钮 /////////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////////////////////////

    /** 注册入口 */
    private registerEntry() {
        // 安全绑定
        this.entryConfig.push({
            event: we.common.EventName.HIDE_BIND_ENTRY,
            condition: () => {
                return !we.common.userMgr.isFormal();
            },
            path: HallRes.prefab.SafeEntry,
            parent: this.view.RCN_SafeEntry,
        });

        // 银行
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_BANK,
            condition: () => {
                return we.common.bankMgr.getBankIsAct();
            },
            path: HallRes.prefab.BankEntry,
            parent: this.view.RCN_BankEntry,
        });

        // 问卷调查
        this.entryConfig.push({
            event: we.common.EventName.SHOW_QUESTIONNAIRE,
            condition: () => {
                return we.common.activityMgr.questionNaireConf?.enable;
            },
            path: HallRes.prefab.QuestionNaireEntry,
            parent: this.view.RCN_QuestionNaireEntry,
        });

        // 新手礼包
        this.entryConfig.push({
            event: we.common.EventName.GIFT_BAG_UPDATE,
            condition: () => {
                return we.common.storeMgr.isNewbieGift;
            },
            path: HallRes.prefab.NewbieGiftBagEntry,
            parent: this.view.RCN_NewbieGiftBagEntry,
        });

        // 每日充值
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_DAILY_RECHARGE,
            condition: () => {
                return we.common.dailyRechargeMgr.isOpenAct();
            },
            path: HallRes.prefab.DailyRechargeRewardEntry,
            parent: this.view.RCN_DailyRechargeRewardEntry,
        });

        // 加入我们
        this.entryConfig.push({
            event: null,
            condition: () => {
                return we.core.projectConfig.settingsConfig?.thirdLinkJoinSwitch;
            },
            path: HallRes.prefab.JoinUsEntry,
            parent: this.view.RCN_JoinUsEntry,
        });

        // 开斋节
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_CARNIVAL,
            condition: () => {
                return we.common.carnivalMgr.isOpenAct();
            },
            path: HallRes.prefab.CarnivalEntry,
            parent: this.view.RCN_CarnivalEntry,
        });

        // 独立日
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_INDEPENDENT_TASK,
            condition: () => {
                return we.common.independentMgr.isOpenAct();
            },
            path: HallRes.prefab.IndependentEntry,
            parent: this.view.RCN_IndependentEntry,
        });

        // 转盘
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_TURNTABLE_TASK,
            condition: () => {
                return we.common.turntableMgr.getTurntableIsAct();
            },
            path: HallRes.prefab.TurntableEntry,
            parent: this.view.RCN_TurntableEntry,
        });

        // 每日金币
        this.entryConfig.push({
            event: null,
            condition: () => {
                return !!we.common.activityMgr.dailySignInInfo;
            },
            path: HallRes.prefab.DailyAwardEntry,
            parent: this.view.RCN_DailyAwardEntry,
        });

        // Vip
        this.entryConfig.push({
            event: null,
            condition: () => {
                return true;
            },
            path: HallRes.prefab.VIPEntry,
            parent: this.view.RCN_VIPEntry,
        });

        // 月签到-按天
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_MONTH_MONTH_SIGN,
            condition: () => {
                return MonthSign.month.isActive();
            },
            path: HallRes.prefab.MonthSignEntry,
            parent: this.view.RCN_MonthSignEntry,
        });

        // 月签到-按次
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_MONTH_MONTH_SIGN2,
            condition: () => {
                return MonthSign.month2.isActive();
            },
            path: HallRes.prefab.MonthSign2Entry,
            parent: this.view.RCN_MonthSign2Entry,
        });

        // 救援金
        this.entryConfig.push({
            event: we.common.EventName.RESCUE_FUNDS_SYNC,
            condition: () => {
                return we.common.rescueFundsMgr.getRescueFundsIsAct();
            },
            path: HallRes.prefab.RescueFundsEntry,
            parent: this.view.RCN_RescueFundsEntry,
        });

        // 周卡
        this.entryConfig.push({
            event: HallEvent.WEEK_CARD_SHOW_STATUS,
            condition: () => {
                return WeekCardMgr.isOpenAc();
            },
            path: HallRes.prefab.WeekCardEntry,
            parent: this.view.RCN_WeekCardEntry,
        });

        // 七日福利
        this.entryConfig.push({
            event: HallEvent.SEVEN_DAY_UPDATE_DATA,
            condition: () => {
                return SevenDayMgr.instance.open;
            },
            path: HallRes.prefab.SevenDayEntry,
            parent: this.view.RCN_SevenDayEntry,
        });

        // 兑换码
        this.entryConfig.push({
            event: null,
            condition: () => {
                return true;
            },
            path: HallRes.prefab.RedeemCodeEntry,
            parent: this.view.RCN_RedeemCodeEntry,
        });

        // 落地页包
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_OFFICIAL_BAG_AWARD,
            condition: () => {
                return we.common.activityMgr.getOfficialPkgIsAct();
            },
            path: HallRes.prefab.OfficialPkgAwardEntry,
            parent: this.view.RCN_OfficialPkgAwardEntry,
        });

        this.entryConfig.forEach((config) => {
            if (config.event) {
                config.callback = async () => {
                    await this.checkEntry(config);
                    this.refreshEntry();
                };
                cc.director.on(config.event, config.callback, this);
            }
        });
    }

    /** 初始化入口 */
    private async initEntry() {
        await Promise.all(
            this.entryConfig.map((config) => {
                return this.checkEntry(config);
            })
        );
        this.refreshEntry();
    }

    /**
     * 检查入口
     * @param config
     */
    private checkEntry(config: EntryConfig) {
        if (!cc.isValid(config?.parent)) {
            return;
        }
        if (config.condition?.()) {
            return this.createEntry(config.path, config.parent);
        } else {
            config.parent.removeAllChildren();
        }
    }

    /**
     * 创建入口
     * @param path
     * @param parent
     */
    private async createEntry(path: string, parent: cc.Node) {
        if (parent.childrenCount > 0) {
            return;
        }
        const entry = await we.commonUI.createNode(path, parent);
        entry.setPosition(0, 0);
        parent.setContentSize(entry.getBoundingBox().size);
    }

    /** 刷新入口 */
    private async refreshEntry() {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }
        const leftRefresh = this.view.RC_left_btns_list?.getComponent(HallEntryList)?.refresh();
        const entryRefresh = this.view.RC_entry_list?.getComponent(HallEntryList)?.refresh(this.dropdownMenu?.RC_dropdown_layout);
        await Promise.all([leftRefresh, entryRefresh]);
        this.dropdownMenu?.setDropdowns();
    }

    /**
     * 多语言切换提示
     * @returns
     */
    private showChangeLangTips() {
        if (!cc.isValid(this.view.RCN_btn_head_tips)) {
            return;
        }

        if (!we.common.utils.isFirstOpenToday('ChangeLangTips')) {
            this.view.RCN_btn_head_tips.active = false;
            return;
        }

        // 主动关闭
        if (we.core.flavor.getLangList().length > 1) {
            this.view
                .cc_onBtnClick(
                    this.view.RCN_btn_head_tips,
                    we.core.Func.create(() => {
                        this.view.RCN_btn_head_tips.active = false;
                    }, this)
                )
                .setTransitionNone();
            this.view.RCN_btn_head_tips.active = true;
        } else {
            this.view.RCN_btn_head_tips.active = false;
        }

        // 3min 自动关闭
        this.scheduleOnce(3 * 60, this).then(() => {
            this.view.RCN_btn_head_tips.active = false;
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(HallDlg_h, `${HallViewId.HallDlg}_h`)
class HallDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Normal;
        uiBase.uiConfig.useTween = false;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(HallDlg_h, uiBase.addComponent(HallDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(HallDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<HallDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(HallDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(HallDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(HallDlg_h).beforeUnload();
    }
}
