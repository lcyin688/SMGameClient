import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import { HallPageEnum } from '../../const/HallConst';
import DownLoadTouchMove from '../../extend/others/DownLoadTouchMove';
import HallMgr from '../../manager/HallMgr';
import MonthSign from '../../manager/MonthSignMgr';
import { HallViewId } from '../HallViewId';
import HallEntryList from '../../extend/hall/HallEntryList';
import WeekCardMgr from '../../manager/WeekCardMgr';
import SevenDayMgr from '../../manager/SevenDayMgr';
import { HallPopupMgr } from '../../manager/HallPopupMgr';

type EntryConfig = { event: string | symbol; condition: () => boolean; path: string; parent: cc.Node; callback?: Function };

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('HallDlgView_v', we.bundles.hall)
class HallDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_bg: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Node)
    public RC_bg_other: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnVip: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_content: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_download: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_downLoadTouchParent: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_event: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_games: cc.Node = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_money: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_vip: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_left_btns: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_left_btns_list: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_me: cc.Node = null;

    @we.ui.ccBind(we.ui.WESwitchMenu)
    public RC_menu: we.ui.WESwitchMenu = null;

    @we.ui.ccBind(cc.Node)
    public RC_more: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_more_arrow: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_more_list: cc.Node = null;

    @we.ui.ccBind(we.ui.WESwitchPage)
    public RC_page: we.ui.WESwitchPage = null;

    @we.ui.ccBind(cc.Node)
    public RC_right_btns: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_search: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_shop: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_head: cc.Sprite = null;

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_vip: cc.Sprite = null;

    @we.ui.ccBind(cc.Node)
    public RC_top: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_withdraw: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_BankEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_addCoin: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_android: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_email: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_event: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_games: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_head: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_ios: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_me: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_more: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_service: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_setting: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_shop: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_withdraw: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_CarnivalEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_DailyAwardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_DailyRechargeRewardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_IndependentEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_JoinUsEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_MonthSign2Entry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_MonthSignEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_more_close: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_NewbieGiftBagEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_OfficialPkgAwardEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_QuestionNaireEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_RedeemCodeEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_RescueFundsEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_SafeEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_SevenDayEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_TurntableEntry: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_WeekCardEntry: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('HallDlg_v', we.bundles.hall)
export class HallDlg_v extends we.ui.DlgSystem<HallDlgView_v> {
    /** 是否显示 提现 按钮 */
    private isShowWithdraw: boolean = false;

    /** 是否打开 more 展示块 */
    private isOpenMore: boolean = false;

    /** 记录当前侧边栏位置 */
    private curMoreListW: number = 0;

    /** 是否显示搜索游戏界面 */
    private isOpenSearchGame: boolean = false;

    /** 当前显示 page */
    private curPageEnum: HallPageEnum = null;

    /** 是否是首次加载 */
    private isFirstLoading: boolean = true;

    private entryConfig: EntryConfig[] = [];

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.isFirstLoading = true;
        we.core.audioMgr.playMusic(we.core.projectConfig.commonConfig.brandBgmUrl);

        this.updateData();

        this.onInitMenuPage();

        this.setUserInfo();

        this.registerRedPoints();

        // btns
        this.view.cc_onBtnClick(this.view.RCN_btn_email, we.core.Func.create(this.onClickEmail, this)).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_btn_head, we.core.Func.create(this.onClickHead, this)).setTransitionNone();
        this.view.cc_onBtnClick(this.view.RC_btnVip, we.core.Func.create(this.onClickVip, this)).setTransitionNone();
        this.view.cc_onBtnClick(this.view.RCN_btn_addCoin, we.core.Func.create(this.onClickAddCoin, this)).setTransitionNone();
        this.view.cc_onBtnClick(this.view.RCN_btn_service, we.core.Func.create(this.onClickService, this)).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_btn_setting, we.core.Func.create(this.onClickSetting, this)).setTransitionScale();
        this.view.cc_onBtnClick(this.view.RCN_btn_android, we.core.Func.create(this.onClickDownloadApk, this));
        this.view.cc_onBtnClick(this.view.RCN_btn_ios, we.core.Func.create(this.onClickIconIosBtn, this));

        this.view.cc_onBtnClick(this.view.RCN_more_close, we.core.Func.create(this.onClickOpenMore, this)).setTransitionNone();
        this.view.cc_onBtnClick(this.view.RCN_btn_more, we.core.Func.create(this.onClickOpenMore, this)).setTransitionNone();

        // events
        cc.director.on(we.core.EventName.GAME_SHOW, this.initEntry, this);

        cc.director.on(we.common.EventName.CHECK_PAY_SUCCESS_PUSH, this.checkPaySucNotice, this);
        cc.director.on(we.common.EventName.UPDATE_GOLD_SHOW, this.updateGold, this);
        cc.director.on(we.common.EventName.UPDATE_USER_INFO_SHOW, this.setUserInfo, this);
        cc.director.on(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.on(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.onShowWithdraw, this);
        cc.director.on(we.common.EventName.NOTICE_EVENT_CENTER, this.onActionNotice, this);
        cc.director.on(we.common.EventName.ACTIVITY_DATA_INIT, this.initEntry, this);
        cc.director.on(we.common.EventName.UPDATE_HALL_TOP_MENU, this.refreshEntry, this);

        cc.director.on(HallEvent.SHOW_PLAYER_START_COIN, this.setUserInfo, this);
        cc.director.on(HallEvent.WITHDRAW_UPDATE_GOLD, this.updateGold, this);
        cc.director.on(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);

        this.registerEntry();
        this.preloadAsset();

        // 是否显示提现按钮
        this.view.RCN_btn_withdraw.active = false;
        we.common.withdrawMgr.judgeIsShowWithdraw();
    }

    protected start(): void {
        // init ui
        this.view.RC_more_list && (this.view.RC_more_list.active = true);
        this.view.RC_more_arrow.scaleX = 1;

        this.initEntry();

        this.view.RC_search.active = false;
        this.view.RCN_more_close.active = this.isOpenMore;

        HallPopupMgr.Inst.showPopup();
    }

    protected update(): void {
        if (!cc.isValid(this.view.RC_more_list)) {
            return;
        }
        if (this.isOpenMore === false || this.curMoreListW === this.view.RC_more_list.width) {
            return;
        }
        this.curMoreListW = this.view.RC_more_list.width;
        this.updateMoreListUi();
    }

    protected destroy(): void {
        cc.director.off(we.core.EventName.GAME_SHOW, this.initEntry, this);
        cc.director.off(we.common.EventName.CHECK_PAY_SUCCESS_PUSH, this.checkPaySucNotice, this);
        cc.director.off(we.common.EventName.UPDATE_GOLD_SHOW, this.updateGold, this);
        cc.director.off(we.common.EventName.UPDATE_USER_INFO_SHOW, this.setUserInfo, this);
        cc.director.off(we.common.EventName.COIN_FLY_ANIM, this.coinFlyAnim, this);
        cc.director.off(we.common.EventName.HALL_IS_SHOW_WITHDRAW, this.onShowWithdraw, this);
        cc.director.off(we.common.EventName.NOTICE_EVENT_CENTER, this.onActionNotice, this);
        cc.director.off(we.common.EventName.ACTIVITY_DATA_INIT, this.initEntry, this);
        cc.director.off(we.common.EventName.UPDATE_HALL_TOP_MENU, this.refreshEntry, this);
        cc.director.off(HallEvent.SHOW_PLAYER_START_COIN, this.setUserInfo, this);
        cc.director.off(HallEvent.WITHDRAW_UPDATE_GOLD, this.updateGold, this);
        cc.director.off(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);
        this.entryConfig.forEach((config) => {
            config.event && cc.director.off(config.event, config.callback, this);
        });
        this.entryConfig.length = 0;
    }

    /** 注册红点显示 */
    private registerRedPoints() {
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.activityDropdown, node: this.view.RCN_btn_more.getChildByName('notice') });
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.mail, node: this.view.RCN_btn_email.getChildByName('notice') });
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.eventCenter, node: this.view.RCN_btn_event.getChildByName('notice') });
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.server, node: this.view.RCN_btn_service.getChildByName('notice') });
        we.common.redDot.red.registeredRedDot({ paths: we.common.redDot.cfg.vip, node: this.view.RC_btnVip.getChildByName('notice') });
    }

    private preloadAsset() {
        if (we.common.storeMgr.isNewbieGift) {
            we.core.assetMgr.preloadAsset(HallRes.prefab.newbieGiftBag, cc.Prefab);
        }
    }

    /**
     * 显示窗口
     * @param pageIndex 显示第几页，默认 games
    this.curPageEnum = pageIndex;
     */
    public async onShow(pageIndex: HallPageEnum = HallPageEnum.games) {
        this.view.RC_menu.onSwitchMenu(pageIndex, true);
        this.setLeftBtns();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    /** 获取当前显示页面类型 */
    public getCurPageType(): HallPageEnum {
        return this.curPageEnum;
    }

    private onActionNotice() {
        we.common.activityMgr.updateEventCenter();
    }

    /** 刷新数据 */
    private updateData() {
        we.common.VIPConfig.getVipAwardStatus();
        we.common.activityMgr.updateEventCenter();
        this.checkPaySucNotice();

        if (we.common.userMgr.isFirstRegister) {
            we.currentUI.show(HallViewId.PhoneBindScreenshotPromptDlg, null, true);
        }
    }

    /** 初始化分页 */
    private onInitMenuPage() {
        // add games
        const hallMiddleView = this.getAsset(HallRes.prefab.HallGames, cc.Prefab);
        hallMiddleView && this.view.RC_games.addChild(cc.instantiate(hallMiddleView));
        // init page
        this.view.RC_menu.setMenuStateByNodeName('selected', 'unselected');
        this.view.RC_menu.onSelected = (node: cc.Node, i: number) => {
            if (this.view.RC_menu.isAutoSize == true) {
                node.width = this.view.RC_menu.selectedItemSize.width;
            }

            const isShowTop = i == HallPageEnum.shop || i == HallPageEnum.withdraw || i == HallPageEnum.event;
            const isMainShowSearch = i == HallPageEnum.games && this.isOpenSearchGame == true;

            if (isShowTop || isMainShowSearch) {
                this.view.RC_bg_other.active = false;
                this.view.RC_top.active = false;
                this.view.RC_right_btns.active = false;
            } else {
                this.view.RC_bg_other.active = true;
                this.view.RC_top.active = true;
                this.view.RC_right_btns.active = true;
            }

            if (isMainShowSearch) {
                this.view.RC_search.active = true;
            } else {
                this.view.RC_search.active = false;
            }

            this.view.RC_bg.index = i;
            this.onSelectedIndex(i);
        };
        this.view.RC_menu.onUnselected = (node: cc.Node, i: number) => {
            if (this.view.RC_menu.isAutoSize == true) {
                if (this.isShowWithdraw === true) {
                    node.width = (cc.winSize.width - this.view.RC_menu.selectedItemSize.width) / 4;
                } else {
                    node.width = (cc.winSize.width - this.view.RC_menu.selectedItemSize.width) / 3;
                }
            }
        };
    }

    private onShowWithdraw(isShow: boolean) {
        if (!this.isValid()) {
            return;
        }
        if (isShow === true) {
            this.view.RCN_btn_withdraw.active = true;
        } else {
            this.view.RCN_btn_withdraw.active = false;
        }
        this.isShowWithdraw = this.view.RCN_btn_withdraw.active;
        this.view.RC_menu.updateCallBack();
    }

    private async onSelectedIndex(index: number) {
        if (this.curPageEnum == index) {
            return;
        }

        const viewMap = new Map([
            [HallPageEnum.shop, { name: 'RC_shop', url: HallRes.prefab.shop }],
            [HallPageEnum.withdraw, { name: 'RC_withdraw', url: HallRes.prefab.withdraw.main }],
            [HallPageEnum.games, { name: 'RC_games', url: HallRes.prefab.HallGames }],
            [HallPageEnum.event, { name: 'RC_event', url: HallRes.prefab.event }],
            [HallPageEnum.me, { name: 'RC_me', url: HallRes.prefab.profile }],
        ]);
        const viewInfo = viewMap.get(index);
        if (!viewInfo) {
            this.curPageEnum = index;
            return;
        }

        // 提现打开比较特殊，需要判定账号类型和是否开启了提现下载引导
        if (viewInfo.url === HallRes.prefab.withdraw.main) {
            let open = HallMgr.openWithdraw();
            if (!open) {
                this.onShow(this.curPageEnum);
                return;
            }
        }

        // 首次进入大厅，默认打开更多
        if (this.isFirstLoading && index == HallPageEnum.games && this.isOpenMore == false) {
            this.isFirstLoading = false;
            this.onClickOpenMore();
        }

        this.curPageEnum = index;

        const { name, url } = viewInfo;
        const node = this.view[name];
        if (!cc.isValid(node) || node.children.length > 0) {
            return;
        }
        const itemPrefab = await this.loadAsset(url, cc.Prefab);
        if (!cc.isValid(node) || node.children.length > 0) {
            return;
        }
        node.addChild(cc.instantiate(itemPrefab));
    }

    private onClickOpenMore() {
        this.isOpenMore = !this.isOpenMore;
        this.view.RCN_more_close.active = this.isOpenMore;
        this.updateMoreListUi();
    }

    private updateMoreListUi() {
        if (!cc.isValid(this.view.RC_more_list)) {
            return;
        }
        this.view.RC_more_list.getComponent(cc.Layout)?.updateLayout();
        const w = this.view.RC_more_list.width;
        this.tween(this.view.RC_more)
            .to(0.3, { x: this.isOpenMore ? 360 - w : 360 }, { easing: 'fade' })
            .start();
        this.view.RC_more_arrow.scaleX = this.isOpenMore ? -1 : 1;
    }

    private checkPaySucNotice(): void {
        if (we.common.pushMsgMgr.pushMsgCacheList) {
            let data: any[] = we.common.pushMsgMgr.pushMsgCacheList.get(we.common.pushMsgMgr.PUSH_TYPE.PAY_SUCCESS) || [];
            if (data.length > 0) {
                let payData = data.shift();
                we.common.pushMsgMgr.onHandleSucNotice(payData);
                we.common.pushMsgMgr.pushMsgCacheList.set(we.common.pushMsgMgr.PUSH_TYPE.PAY_SUCCESS, data);
            }
        }
    }

    private setUserInfo() {
        if (!cc.isValid(this.view.RC_spr_head)) {
            return;
        }

        if (!we.common.userMgr.isShowGiveDialog) {
            let coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
            this.view.RC_lab_money.string = we.common.utils.formatAmountCurrency(coin);
            this.view.RC_lab_money.node['actions_labelNumRoll_value'] = coin; // 刷新金币滚动开始值
        } else {
            // 新用户第一次进入游戏，领取赠送的金币奖励后再显示金币数
            this.view.RC_lab_money.string = we.common.utils.formatAmountCurrency(0);
            this.view.RC_lab_money.node['actions_labelNumRoll_value'] = 0; // 刷新金币滚动开始值
        }

        // 设置玩家头像
        we.common.utils.setAvatarSprite(this.view.RC_spr_head, we.common.userMgr.userInfo.avatar, we.common.userMgr.userInfo.gender, false);

        // vip
        this.view.RC_lab_vip.string = `VIP` + we.common.userMgr.vipExp.level;
        let path = HallRes.texture.VIP_Logo_icon + we.common.userMgr.vipExp.level;
        we.common.utils.setComponentSprite(this.view.RC_spr_vip, path);
    }

    private updateGold(latestCredit?: number) {
        if (!cc.isValid(this.view.RC_lab_money)) {
            return;
        }

        let coin = we.common.userMgr.userInfo.gold > 0 ? we.common.userMgr.userInfo.gold : 0;
        if (cc.isValid(latestCredit)) {
            coin = latestCredit;
        }

        this.view.RC_lab_money.string = we.common.utils.formatAmountCurrency(coin);
        this.view.RC_lab_money.node['actions_labelNumRoll_value'] = coin; // 刷新金币滚动开始值
    }

    private coinFlyAnim(params: { node: cc.Node; award: number }): void {
        HallMgr.coinFlyAnim(params, this.view.uiRoot, this.view.RC_lab_money.node);
    }

    private onClickEmail() {
        we.currentUI.show(HallViewId.MailDlg);
    }

    private onClickHead() {
        we.currentUI.show(HallViewId.UserCenterDlg);
    }

    private onClickVip() {
        we.currentUI.show(HallViewId.VipViewDlg);
    }

    private onClickAddCoin() {
        this.view.RC_menu.onSwitchMenu(HallPageEnum.shop, true);
    }

    private onClickService() {
        we.common.commonMgr.openCustomerDialog();
    }

    private onClickSetting() {
        we.currentUI.show(HallViewId.UserCenterSettingDlg);
    }

    // 下载引导弹窗
    private onClickDownloadApk() {
        HallMgr.clickApkDownloadBtn();
    }

    // iOS收藏引导弹窗
    private onClickIconIosBtn() {
        HallMgr.clickIosCollectBtn();
    }

    private setLeftBtns() {
        if (cc.sys.isBrowser) {
            this.view.RCN_btn_android.active = we.common.downloadGuideMgr.isShowApkDownload();
            if (this.view.RCN_btn_android.active) {
                let downLoadTouchMove = this.view.RCN_btn_android.getComponent(DownLoadTouchMove);
                downLoadTouchMove?.initTouchMove(this.view.RC_downLoadTouchParent);
            }
            this.view.RCN_btn_ios.active = we.common.downloadGuideMgr.isShowIosCollect();
            if (this.view.RCN_btn_ios.active) {
                let downLoadTouchMove = this.view.RCN_btn_ios.getComponent(DownLoadTouchMove);
                downLoadTouchMove?.initTouchMove(this.view.RC_downLoadTouchParent);
            }
            this.view.RC_download.active = this.view.RCN_btn_ios.active || this.view.RCN_btn_android.active;
        } else {
            this.view.RC_download.active = false;
        }
    }

    private async onShowSearchGame(isShow: boolean) {
        this.view.RC_top.active = !isShow;
        this.isOpenSearchGame = isShow;

        if (isShow) {
            if (this.view.RC_search.children.length == 0) {
                const hallSearchGamePb = await this.loadAsset(HallRes.prefab.HallSearchGame, cc.Prefab);
                if (hallSearchGamePb) {
                    this.view.RC_search.addChild(cc.instantiate(hallSearchGamePb));
                }
            }
        }
        this.view.RC_search.active = isShow;
    }

    // ////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////// more btns /////////////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////////////////////////

    /** 注册入口 */
    private registerEntry() {
        // 安全绑定
        this.entryConfig.push({
            event: we.common.EventName.HIDE_BIND_ENTRY,
            condition: () => {
                return !we.common.userMgr.isFormal();
            },
            path: HallRes.prefab.SafeEntry,
            parent: this.view.RCN_SafeEntry,
        });

        // 银行
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_BANK,
            condition: () => {
                return we.common.bankMgr.getBankIsAct();
            },
            path: HallRes.prefab.BankEntry,
            parent: this.view.RCN_BankEntry,
        });

        // 问卷调查
        this.entryConfig.push({
            event: we.common.EventName.SHOW_QUESTIONNAIRE,
            condition: () => {
                return we.common.activityMgr.questionNaireConf?.enable;
            },
            path: HallRes.prefab.QuestionNaireEntry,
            parent: this.view.RCN_QuestionNaireEntry,
        });

        // 新手礼包
        this.entryConfig.push({
            event: we.common.EventName.GIFT_BAG_UPDATE,
            condition: () => {
                return we.common.storeMgr.isNewbieGift;
            },
            path: HallRes.prefab.NewbieGiftBagEntry,
            parent: this.view.RCN_NewbieGiftBagEntry,
        });

        // 每日充值
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_DAILY_RECHARGE,
            condition: () => {
                return we.common.dailyRechargeMgr.isOpenAct();
            },
            path: HallRes.prefab.DailyRechargeRewardEntry,
            parent: this.view.RCN_DailyRechargeRewardEntry,
        });

        // 加入我们
        this.entryConfig.push({
            event: null,
            condition: () => {
                return we.core.projectConfig.settingsConfig?.thirdLinkJoinSwitch;
            },
            path: HallRes.prefab.JoinUsEntry,
            parent: this.view.RCN_JoinUsEntry,
        });

        // 开斋节
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_CARNIVAL,
            condition: () => {
                return we.common.carnivalMgr.isOpenAct();
            },
            path: HallRes.prefab.CarnivalEntry,
            parent: this.view.RCN_CarnivalEntry,
        });

        // 独立日
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_INDEPENDENT_TASK,
            condition: () => {
                return we.common.independentMgr.isOpenAct();
            },
            path: HallRes.prefab.IndependentEntry,
            parent: this.view.RCN_IndependentEntry,
        });

        // 转盘
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_TURNTABLE_TASK,
            condition: () => {
                return we.common.turntableMgr.getTurntableIsAct();
            },
            path: HallRes.prefab.TurntableEntry,
            parent: this.view.RCN_TurntableEntry,
        });

        // 每日金币
        this.entryConfig.push({
            event: null,
            condition: () => {
                return !!we.common.activityMgr.dailySignInInfo;
            },
            path: HallRes.prefab.DailyAwardEntry,
            parent: this.view.RCN_DailyAwardEntry,
        });

        // 月签到-按天
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_MONTH_MONTH_SIGN,
            condition: () => {
                return MonthSign.month.isActive();
            },
            path: HallRes.prefab.MonthSignEntry,
            parent: this.view.RCN_MonthSignEntry,
        });

        // 月签到-按次
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_MONTH_MONTH_SIGN2,
            condition: () => {
                return MonthSign.month2.isActive();
            },
            path: HallRes.prefab.MonthSign2Entry,
            parent: this.view.RCN_MonthSign2Entry,
        });

        // 救援金
        this.entryConfig.push({
            event: we.common.EventName.RESCUE_FUNDS_SYNC,
            condition: () => {
                return we.common.rescueFundsMgr.getRescueFundsIsAct();
            },
            path: HallRes.prefab.RescueFundsEntry,
            parent: this.view.RCN_RescueFundsEntry,
        });

        // 周卡
        this.entryConfig.push({
            event: HallEvent.WEEK_CARD_SHOW_STATUS,
            condition: () => {
                return WeekCardMgr.isOpenAc();
            },
            path: HallRes.prefab.WeekCardEntry,
            parent: this.view.RCN_WeekCardEntry,
        });

        // 七日福利
        this.entryConfig.push({
            event: HallEvent.SEVEN_DAY_UPDATE_DATA,
            condition: () => {
                return SevenDayMgr.instance.open;
            },
            path: HallRes.prefab.SevenDayEntry,
            parent: this.view.RCN_SevenDayEntry,
        });

        // 兑换码
        this.entryConfig.push({
            event: null,
            condition: () => {
                return true;
            },
            path: HallRes.prefab.RedeemCodeEntry,
            parent: this.view.RCN_RedeemCodeEntry,
        });

        // 落地页包
        this.entryConfig.push({
            event: we.common.EventName.UPDATE_OFFICIAL_BAG_AWARD,
            condition: () => {
                return we.common.activityMgr.getOfficialPkgIsAct();
            },
            path: HallRes.prefab.OfficialPkgAwardEntry,
            parent: this.view.RCN_OfficialPkgAwardEntry,
        });

        this.entryConfig.forEach((config) => {
            if (config.event) {
                config.callback = async () => {
                    await this.checkEntry(config);
                    this.refreshEntry();
                };
                cc.director.on(config.event, config.callback, this);
            }
        });
    }

    /** 初始化入口 */
    private async initEntry() {
        await Promise.all(
            this.entryConfig.map((config) => {
                return this.checkEntry(config);
            })
        );
        this.refreshEntry();
    }

    /**
     * 检查入口
     * @param config
     */
    private checkEntry(config: EntryConfig) {
        if (!cc.isValid(config?.parent)) {
            return;
        }
        if (config.condition?.()) {
            return this.createEntry(config.path, config.parent);
        } else {
            config.parent.removeAllChildren();
        }
    }

    /**
     * 创建入口
     * @param path
     * @param parent
     */
    private async createEntry(path: string, parent: cc.Node) {
        if (parent.childrenCount > 0) {
            return;
        }
        const entry = await we.commonUI.createNode(path, parent);
        entry.setPosition(0, 0);
        parent.setContentSize(entry.getBoundingBox().size);
    }

    /** 刷新入口 */
    private refreshEntry() {
        this.view.RC_more_list?.getComponent(HallEntryList)?.refresh();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(HallDlg_v, `${HallViewId.HallDlg}_v`)
class HallDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Normal;
        uiBase.uiConfig.useTween = false;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(HallDlg_v, uiBase.addComponent(HallDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(HallDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<HallDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(HallDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(HallDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(HallDlg_v).beforeUnload();
    }
}
