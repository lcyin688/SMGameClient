import { HallLanguage } from '../../const/HallLanguage';

const { ccclass, property } = cc._decorator;

@ccclass
export default class HallGroupItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_selectDesc: cc.Label = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_selectIcon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Label)
    public RC_unselectDesc: cc.Label = null;

    @we.ui.ccBind(we.ui.WESpriteIndex)
    public RC_unselectIcon: we.ui.WESpriteIndex = null;

    @we.ui.ccBind(cc.Node)
    public RC_unselect: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_select: cc.Node = null;

    @we.ui.ccBind(sp.Skeleton)
    public RC_selectAnim: sp.Skeleton = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private langConf: { [key: string]: string } = {};

    private lang: string;

    protected onLoad(): void {
        this.langConf = {
            hot: HallLanguage.HALL_GAME_TYPE_1,
            hundred: HallLanguage.HALL_GAME_TYPE_2,
            slots: HallLanguage.HALL_GAME_TYPE_3,
            poker: HallLanguage.HALL_GAME_TYPE_4,
            myFavorite: HallLanguage.HALL_GAME_TYPE_7,
            all: HallLanguage.HALL_GAME_TYPE_8,
            casual: HallLanguage.HALL_GAME_TYPE_9,
            new: HallLanguage.HALL_GAME_TYPE_10,
            live: HallLanguage.HALL_GAME_TYPE_11,
        };
        we.event<we.core.EventMsg>().on('LangChanged', this.updataLabel, this);
    }

    protected onDestroy(): void {
        we.event<we.core.EventMsg>().off('LangChanged', this.updataLabel, this);
    }

    public init(group: string): void {
        this.RC_selectIcon.setName(group + '_on');
        this.RC_unselectIcon.setName(group + '_off');
        this.lang = this.langConf[group];
        this.updataLabel();
    }

    private updataLabel() {
        if (this.lang) {
            let desc = we.core.langMgr.getLangText(this.lang);
            this.RC_unselectDesc.string = desc;
            this.RC_selectDesc.string = desc;
        }
    }
    public setState(state: boolean) {
        if (this.RC_select) {
            this.RC_select.active = state;
        }
        if (this.RC_unselect) {
            this.RC_unselect.active = !state;
        }
        if (this.RC_selectAnim && state) {
            this.RC_selectAnim.setAnimation(0, 'animation', false);
        }
    }
}
