import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import HallGameListMgr from '../../manager/HallGameListMgr';
import HallGameItem_h from './HallGameItem_h';
import HallGroupItem_h from './HallGroupItem_h';

const { ccclass, property } = cc._decorator;

/** 列表移动速度 */
const ListMoveSpeed: number = 1500;

@ccclass
export default class HallGames_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Button)
    public RC_btn_search: cc.Button = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_group: we.ui.List = null;

    @we.ui.ccBind(we.common.YXCollectionView)
    public RC_listGame: we.common.YXCollectionView = null;

    @we.ui.ccBind(cc.Node)
    public RC_main: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_marquee: cc.Node = null;

    @we.ui.ccBind(we.ui.WEWheelList)
    public RC_wheel_groupCenter: we.ui.WEWheelList = null;

    @we.ui.ccBind(cc.Node)
    public RCN_banner: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_left: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_right: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_withdrawBroadcast: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property(cc.Prefab)
    private hallGameItem: cc.Prefab = null;

    @property({
        tooltip: CC_DEV && '大厅游戏 icon 大图标尺寸',
    })
    public GameItemBigSize: cc.Size = new cc.Size(211, 361);

    @property({
        tooltip: CC_DEV && '大厅游戏 icon 小图标尺寸',
    })
    public GameItemSmallSize: cc.Size = new cc.Size(211, 176);

    @property({
        tooltip: CC_DEV && '元素之间垂直间距',
    })
    public GameItemVerticalSpacing: number = 14;

    @property({
        tooltip: CC_DEV && '元素之间水平间距',
    })
    public GameItemHorizontalSpacing: number = 15;

    /** 当前游戏列表，二维数组 */
    private curGameList: we.GameId[][] = [];

    /** 当前分组列表 */
    private groupList: string[] = [];

    /** 当前分组下标 */
    private curGroupIndex: number = 0;

    protected update(dt: number): void {}

    protected onLoad(): void {
        this.RC_listGame.node.getComponent(cc.Widget)?.updateAlignment();

        this.onBtnClick(this.RC_btn_search.node, we.core.Func.create(this.onClickSearch, this)).setSleepTime(1.5);
        this.onBtnClick(this.RCN_btn_left, we.core.Func.create(this.onClickDropLeft, this)).setTransitionNone();
        this.onBtnClick(this.RCN_btn_right, we.core.Func.create(this.onClickDropRight, this)).setTransitionNone();

        we.event<we.core.EventMsg>().on('WindowResize', this.onUpdateGameListSize, this);
        cc.director.on(we.core.EventName.ENTER_GAME_LIMIT_UPDATE, this.onUpdateEnterLimit, this);
        cc.director.on(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);
        we.event().on('SceneChangeStart', this.onSaveLastEntryLocation, this);
    }

    protected onDestroy(): void {
        we.event<we.core.EventMsg>().offByTarget(this);
        cc.director.off(we.core.EventName.ENTER_GAME_LIMIT_UPDATE, this.onUpdateEnterLimit, this);
        cc.director.off(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);
        we.event().off('SceneChangeStart', this.onSaveLastEntryLocation, this);
    }

    protected start(): void {
        this.initSlidArrow();

        // group list data
        this.curGroupIndex = HallGameListMgr.curGroupIndex;
        this.groupList = HallGameListMgr.getHallGroupList();

        // group list
        if (this.RC_list_group) {
            this.RC_list_group.setRenderEvent(we.core.Func.create(this.onRenderGroupItem, this));
            this.RC_list_group.setSelectedEvent(we.core.Func.create(this.onSelectGroupItem, this));
            this.RC_list_group.numItems = this.groupList.length;
            this.RC_list_group.selectedId = this.curGroupIndex;
        }

        // groupWheel
        this.renderWheelgroupWheelItems();

        // games list
        this.RC_listGame.node.getComponent(cc.Widget)?.updateAlignment();
        this.RC_listGame.node.off(`scrolling`, this.onScrolling, this);
        this.RC_listGame.node.on(`scrolling`, this.onScrolling, this);

        // banner
        const banner = this.getAsset(HallRes.prefab.hall_banner, cc.Prefab);
        if (banner) {
            this.RCN_banner.addChild(cc.instantiate(banner));
        }

        // 公告
        we.commonUI.createNode(HallRes.prefab.withdraw.broadcast, this.RCN_withdrawBroadcast);

        // 闪告
        this.initMarquee();

        // game list
        this.createGameList();

        this.recoverLastEntryLocation();
    }

    protected renderWheelgroupWheelItems() {
        if (this.RC_wheel_groupCenter) {
            this.RC_wheel_groupCenter.init(this.groupList.length, this.curGroupIndex, this.onSelectGroupWheelItem.bind(this));
        }
    }

    private onSelectGroupWheelItem(arr: cc.Node[], c: number) {
        for (let i = 0; i < arr.length; i++) {
            let item = arr[i].getComponent(HallGroupItem_h);
            item.init(this.groupList[i]);
            item.setState(i == c);
        }
        this.onSelectGroupItemFinal(c);
    }

    private async initMarquee() {
        const prefab = await this.loadAsset(HallRes.prefab.marquee, cc.Prefab);
        if (prefab) {
            this.RC_marquee.addChild(cc.instantiate(prefab));
        }
    }

    // ////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////// Group /////////////////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////////////////////////

    private onRenderGroupItem(item: cc.Node, i: number) {
        let itemComp = item.getComponent(HallGroupItem_h);
        itemComp?.init(this.groupList[i]);
    }

    private onSelectGroupItem(item: cc.Node, i: number) {
        this.onSelectGroupItemFinal(i);
    }

    private onSelectGroupItemFinal(i: number) {
        this.RC_listGame.scrollView.stopAutoScroll();
        let scrollTo = 0;
        if (i <= 1) {
            scrollTo = 0;
        } else if (i >= 2) {
            scrollTo = i - 1;
        }
        this.curGroupIndex = i;
        if (this.RC_list_group) {
            this.RC_list_group.scrollTo(scrollTo);
        }
        HallGameListMgr.curGroupIndex = this.curGroupIndex;
        this.curGameList = HallGameListMgr.getHallGameList(this.groupList[this.curGroupIndex]);

        if (this.RC_listGame.layout) {
            this.RC_listGame.numberOfSections = this.curGameList.length;
            this.RC_listGame.reloadData();
        }

        this.resetGameList();
    }

    private onShowSearchGame(isShow: boolean) {
        this.RC_main.active = !isShow;
    }

    // ////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////// game list /////////////////////////////////////////////
    // ////////////////////////////////////////////////////////////////////////////////////////////////

    private initSlidArrow(): void {
        this.RCN_btn_left.children[0].stopAllActions();
        this.RCN_btn_right.children[0].stopAllActions();
        this.RCN_btn_left.children[0].position = cc.v2(0, 0);
        this.RCN_btn_right.children[0].position = cc.v2(0, 0);
        this.tween(this.RCN_btn_left.children[0])
            .repeatForever(cc.sequence(cc.moveBy(0.3, cc.v2(20, 0)), cc.moveBy(0.5, cc.v2(-25, 0)), cc.moveBy(0.2, cc.v2(5, 0))))
            .start();
        this.tween(this.RCN_btn_right.children[0])
            .repeatForever(cc.sequence(cc.moveBy(0.3, cc.v2(-20, 0)), cc.moveBy(0.5, cc.v2(25, 0)), cc.moveBy(0.2, cc.v2(-5, 0))))
            .start();
        this.RCN_btn_left.active = false;
        this.RCN_btn_right.active = this.RC_listGame.scrollView.content.width > this.RC_listGame.node.width + 5 ? true : false;
        this.RCN_btn_left.opacity = 255;
        this.RCN_btn_right.opacity = 255;
    }

    private onClickSearch() {
        cc.director.emit(HallEvent.EVENT_SEARCH_GAME_SHOW, true);
    }

    private onClickDropLeft(): void {
        let offset_cur = Math.abs(this.RC_listGame.scrollView.getScrollOffset().x);
        let time = offset_cur / ListMoveSpeed;
        this.RC_listGame.scrollView.scrollToLeft(time);
    }

    private onClickDropRight(): void {
        let offset_max = this.RC_listGame.scrollView.getMaxScrollOffset().x;
        let offset_cur = Math.abs(this.RC_listGame.scrollView.getScrollOffset().x);
        let time = (offset_max - offset_cur) / ListMoveSpeed;
        this.RC_listGame.scrollView.scrollToRight(time);
    }

    private onUpdateGameListSize() {
        we.core.timer.scheduleOnce(0, this).then(() => {
            if (cc.isValid(this.RC_listGame)) {
                this.RC_listGame.reloadData();
            }
        });
    }

    private resetGameList(): void {
        let offset_cur = Math.abs(this.RC_listGame.scrollView.getScrollOffset().x);
        let time = offset_cur / ListMoveSpeed;
        this.RC_listGame.scrollView.scrollToLeft(time);
        this.RCN_btn_left.active = false;
        this.RCN_btn_right.active = this.RC_listGame.scrollView.content.width > this.RC_listGame.node.width + 5 ? true : false;
    }

    private onUpdateEnterLimit(): void {
        let updateNodes: cc.Node[] = [];
        let children = this.RC_listGame.scrollView.content.children || [];
        for (let i = 0; i < children.length; i++) {
            updateNodes.push(children[i]);
        }
        updateNodes.forEach((node) => {
            node.getComponent(HallGameItem_h)?.setVipLimit();
        });
    }

    private onScrolling(): void {
        if (this.RC_listGame.scrollView.content.width <= this.RC_listGame.node.width + 5) {
            return;
        }
        let offset_max = this.RC_listGame.scrollView.getMaxScrollOffset().x;
        let offset_cur = Math.abs(this.RC_listGame.scrollView.getScrollOffset().x);
        this.RCN_btn_left.active = offset_cur > 120 ? true : false;
        this.RCN_btn_right.active = offset_cur < offset_max - 120 ? true : false;
    }

    private createGameList() {
        if (!cc.isValid(this.RC_listGame)) {
            return;
        }

        // 内容分几个区展示
        this.RC_listGame.numberOfSections = this.curGameList.length;
        this.RC_listGame.register(`cell`, () => {
            return cc.instantiate(this.hallGameItem);
        });
        this.RC_listGame.cellForItemAt = () => {
            return this.RC_listGame.dequeueReusableCell(`cell`);
        };
        this.RC_listGame.onCellDisplay = (cell: cc.Node, indexPath) => {
            this.initEntryItem(cell, indexPath);
        };
        // 每个区对应的要展示多少条内容
        this.RC_listGame.numberOfItems = (section) => {
            return this.curGameList[section].length;
        };

        let layout = new we.common.YXFlowLayout();
        layout.scrollDirection = we.common.YXFlowLayout.ScrollDirection.HORIZONTAL;
        layout.itemSize = (indexPath) => {
            return this.curGameList[indexPath.section].length == 1 ? this.GameItemBigSize : this.GameItemSmallSize;
        };
        layout.sectionInset = (section: number, layout: we.common.YXFlowLayout, collectionView: we.common.YXCollectionView) => {
            const games = this.curGameList[section];
            const skin = we.core.flavor.getSkinCode();
            // 根据皮肤类型和游戏数量获取边缘内边距
            let edgeInsets: we.common.YXEdgeInsets = null;
            switch (skin) {
                case we.core.SkinCode.bg:
                    edgeInsets = new we.common.YXEdgeInsets(0, 10, 0, 10);
                    break;
                case we.core.SkinCode.ct:
                    edgeInsets = games.length > 1 ? new we.common.YXEdgeInsets(-2, 10, 0, 10) : new we.common.YXEdgeInsets(-15, 10, 0, 10);
                    break;
                case we.core.SkinCode.ct2:
                    edgeInsets = new we.common.YXEdgeInsets(10, 10, 0, 10);
                    break;
                case we.core.SkinCode.ct3:
                    edgeInsets = new we.common.YXEdgeInsets(20, 0, 0, 0);
                    break;
                default:
                    edgeInsets = new we.common.YXEdgeInsets(0, 10, 0, 10);
                    break;
            }
            return edgeInsets;
        };
        layout.verticalSpacing = this.GameItemVerticalSpacing;
        layout.horizontalSpacing = this.GameItemHorizontalSpacing;
        this.RC_listGame.layout = layout;

        this.RC_listGame.reloadData();
    }

    private initEntryItem(cell: cc.Node, indexPath: we.common.YXIndexPath): void {
        if (!cc.isValid(cell)) {
            return;
        }

        const games = this.curGameList[indexPath.section];
        const gameId = games[indexPath.item];
        let isBigIcon = games.length < 2 ? true : false;
        const gameCfg = HallGameListMgr.getGameEntryConfig(gameId, isBigIcon);

        cell.getComponent(HallGameItem_h)?.init(gameCfg);
    }

    private onSaveLastEntryLocation() {
        // 记录当前用户操作数据,用于下次进入时显示
        HallGameListMgr.lastGameEnterLocation.hallParams = {
            scrollOffset: this.RC_listGame?.scrollView?.getScrollOffset().clone(),
            groupIndex: this.curGroupIndex,
        };
    }

    private recoverLastEntryLocation() {
        if (we.core.gameConfig.getSceneFrom() !== we.SceneFrom.Game) {
            return;
        }
        const { groupIndex, scrollOffset } = HallGameListMgr.lastGameEnterLocation.hallParams;
        if (this.curGroupIndex != groupIndex) {
            if (this.RC_list_group) {
                this.RC_list_group.selectedId = groupIndex;
            } else if (this.RC_wheel_groupCenter) {
                this.RC_wheel_groupCenter.rotateToIndex(groupIndex);
            }
        }
        if (scrollOffset && scrollOffset.x) {
            this.scheduleOnce(() => {
                const offset_max = this.RC_listGame.scrollView.getMaxScrollOffset().x;
                this.RC_listGame.scrollView.scrollToPercentHorizontal(Math.abs(scrollOffset.x) / offset_max, 0.1);
            }, 0.3);
        }
    }
}
