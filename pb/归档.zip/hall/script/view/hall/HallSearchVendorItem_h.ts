const { ccclass, property } = cc._decorator;

@ccclass
export default class HallSearchVendorItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */
    @we.ui.ccBind(cc.Node)
    public RC_line: cc.Node = null;

    protected onLoad(): void {}

    protected start(): void {}

    public init(url: string, index = 0) {
        if (url) {
            this.loadAssetRemote(url, cc.SpriteFrame).then((spriteFrame) => {
                this.RC_spr_icon.spriteFrame = spriteFrame;
            });
        }

        if (index === 0 && this.RC_line) {
            this.RC_line.active = false;
        }
    }
}
