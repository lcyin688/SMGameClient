const { ccclass, property } = cc._decorator;

@ccclass
export default class HallMenuDropdown_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_dropdown_layout: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_more: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_background: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property({
        tooltip: CC_DEV && '按钮的宽度',
    })
    public buttonWidth: number = 100;

    @property({
        tooltip: CC_DEV && '按钮的高度',
    })
    public buttonHeight: number = 100;

    @property({
        tooltip: CC_DEV && '纵向按钮最大数量',
    })
    public verticalNum: number = 5;

    private items: { node: cc.Node; redDotConfig: string[]; children: cc.Node[] }[] = [];

    private isOpen = false;

    private needOpen: boolean;

    position: cc.Vec2;

    wrapNode: cc.Node;

    protected onLoad(): void {
        this.onToggle(this.node, we.core.Func.create(this.onCheckDropdown, this));

        we.common.redDot.red.appendVRedDotNode(this.node).then((notice) => {
            we.common.redDot.red.registeredRedDot({
                paths: we.common.redDot.cfg.activityDropdown,
                node: notice,
                callback: this.onUpdateDropdownRedDot.bind(this),
            });
        });
        this.node.active = false;
        this.RC_dropdown_layout.active = false;
        this.position = this.RC_dropdown_layout.getPosition();

        // cc.director.on(we.core.EventName.FULL_TOUCH_END, this.onCheckDropdown, this);
    }

    protected onEnable(): void {
        this.setDropdowns();
    }

    protected onDestroy(): void {
        // cc.director.off(we.core.EventName.FULL_TOUCH_END, this.onCheckDropdown, this);
    }

    /**
     * 更新下拉菜单红点
     */
    private onUpdateDropdownRedDot() {
        if (!cc.isValid(this.node) || !this.node.active) {
            return;
        }
        let redDotCnt = 0;
        this.items.forEach((item) => {
            if (item.redDotConfig) {
                redDotCnt += we.common.redDot.red.getRedDotCnt(item.redDotConfig);
            }
        });
        if (redDotCnt === we.common.redDot.red.getRedDotCnt(we.common.redDot.cfg.activityDropdown)) {
            return;
        }
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.activityDropdown, redDotCnt, true);
    }

    /**
     * 设置下拉菜单项
     * @param items
     */
    public setDropdowns() {
        if (!cc.isValid(this.RC_dropdown_layout)) {
            return;
        }
        if (this.isOpen) {
            this.needOpen = true;
            this.hideDropdownWrap();
            return;
        }
        this.RC_dropdown_layout.active = true;
        this.RC_dropdown_layout.opacity = 1;
        // 需要等组件初始化完成之后再获取
        this.scheduleOnce(() => {
            if (!cc.isValid(this.node) || this.isOpen) {
                return;
            }
            this.RC_dropdown_layout.active = false;
            this.RC_dropdown_layout.opacity = 255;
            this.items = this.RC_dropdown_layout.children.map((child) => {
                const node = child.getComponent(we.ui.WEButton) ? child : child.children[0];
                return {
                    node: node,
                    redDotConfig: we.common.redDot.red.getRedDotConfig(node),
                    children: [],
                };
            });
            this.node.active = this.items.length > 0;
            this.onUpdateDropdownRedDot();
            if (this.needOpen) {
                this.needOpen = false;
                this.showDropdownWrap();
                this.nodeAddComponent(this.node, cc.Toggle).isChecked = true;
            }
        });
    }

    /**
     * 切换下拉菜单显示
     */
    private onCheckDropdown(e: cc.Toggle) {
        if (!cc.isValid(this.node)) {
            return;
        }
        const isChecked = Boolean(e && e.isChecked);
        this.RCN_background.active = !isChecked;
        if (this.RC_more) {
            this.RC_more.active = isChecked;
        }
        if (isChecked) {
            this.showDropdownWrap();
        } else {
            this.hideDropdownWrap();
        }
    }

    /**
     * 创建下拉菜单项
     * @param item
     */
    private createDropdownItem(item: (typeof this.items)[number]) {
        const node = new cc.Node('dropdown');
        node.width = this.buttonWidth;
        node.height = this.buttonHeight;
        const btn = node.addComponent(cc.Button);
        btn.transition = cc.Button.Transition.SCALE;
        btn.zoomScale = 1.1;
        btn.duration = 0.1;
        node.on('click', () => {
            this.hideDropdownWrap();
            item.node.getComponent(we.ui.WEButton)?.emitClick();
        });

        item.children = [];
        const len = item.node.children.length;
        for (let index = 0; index < len; index++) {
            const child = item.node.children[0];
            child.parent = node;
            item.children.push(child);
        }
        return node;
    }

    /**
     * 显示下拉框
     */
    private showDropdownWrap() {
        if (this.isOpen) {
            return;
        }
        this.RC_dropdown_layout.removeAllChildren();

        const wrap = this.wrapNode || new cc.Node('DropdownWrap');
        const canvas = we.ui.UILayer.normal;
        wrap.width = 1600;
        wrap.height = 750;
        wrap.on(cc.Node.EventType.TOUCH_END, () => {
            this.onCheckDropdown(null);
        });
        wrap.parent = canvas;
        // 添加入口列表
        const layout = this.nodeAddComponent(this.RC_dropdown_layout, cc.Layout);

        const length = this.items?.length ?? 0;
        if (layout && length > 0) {
            if (length >= this.verticalNum) {
                this.RC_dropdown_layout.height = layout.paddingTop + layout.paddingBottom + this.verticalNum * this.buttonHeight;
            } else {
                this.RC_dropdown_layout.height = layout.paddingTop + layout.paddingBottom + length * this.buttonHeight;
            }
        }

        const pos = we.core.ViewHelper.calculateASpaceToBSpacePos(this.node, wrap, new cc.Vec3(this.position.x, this.position.y, 1));

        this.RC_dropdown_layout.on(cc.Node.EventType.TOUCH_END, () => {
            this.onCheckDropdown(null);
        });
        this.items.forEach((item) => {
            if (!we.core.utils.isValidNode(item.node)) {
                return;
            }
            const node = this.createDropdownItem(item);
            this.RC_dropdown_layout.addChild(node);
        });

        this.RC_dropdown_layout.parent = wrap;
        this.RC_dropdown_layout.setPosition(pos);
        this.wrapNode = wrap;

        this.RC_dropdown_layout.active = true;
        this.isOpen = true;
    }

    /**
     * 隐藏下拉框
     */
    private hideDropdownWrap() {
        if (!this.wrapNode || !this.isOpen) {
            return;
        }

        this.RC_dropdown_layout.parent = this.node;
        this.RC_dropdown_layout.active = false;
        this.nodeAddComponent(this.node, cc.Toggle).isChecked = false;
        this.RCN_background.active = true;
        if (this.RC_more) {
            this.RC_more.active = false;
        }
        this.items.forEach((item) => {
            if (!cc.isValid(item.node)) {
                return;
            }
            item.children.forEach((child) => {
                child.parent = item.node;
            });
        });
        this.RC_dropdown_layout.removeAllChildren();
        this.isOpen = false;
        this.wrapNode.destroy();
        this.wrapNode = null;
        cc.director.emit(we.common.EventName.UPDATE_HALL_TOP_MENU);
    }
}
