import { HallEvent } from '../../config/HallEvent';
import { HallRes } from '../../config/HallRes';
import HallGameListMgr from '../../manager/HallGameListMgr';
import HallGameItem_v from './HallGameItem_v';
import HallGameLine_v from './HallGameLine_v';
import HallGroupItem_v from './HallGroupItem_v';

const { ccclass, property } = cc._decorator;

/** 列表移动速度 */
const ListMoveSpeed: number = 1500;

/** 是否显示大图标 */
const IsShowBigIcon: boolean = false;

@ccclass
export default class HallGames_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Button)
    public RC_btn_search: cc.Button = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_game: we.ui.List = null;

    @we.ui.ccBind(we.ui.List)
    public RC_list_group: we.ui.List = null;

    @we.ui.ccBind(cc.Node)
    public RC_main: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_marquee: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_banner: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_arrow: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_withdrawBroadcast: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    /** RC_list_group 最大自适应个数 */
    @property()
    maxShowListGroupCount: number = 0;

    /** RC_list_group 默认尺寸 */
    private widthListGroup: number = 0;

    /** 当前游戏列表，二维数组 */
    private curGameList: we.GameId[][] = [];

    /** 当前游戏列表 一维数组 */
    private curGameListOne: we.GameId[] = [];

    /** 当前分组列表 */
    private groupList: string[] = [];

    /** 当前分组下标 */
    private curGroupIndex: number = 0;

    /** 是否在 game list 顶部 */
    private isGamesListTop: boolean = true;

    protected onLoad(): void {
        this.widthListGroup = this.RC_list_group.node.width;
        this.RC_list_game.node.getComponent(cc.Widget)?.updateAlignment();

        this.onBtnClick(this.RCN_btn_arrow, we.core.Func.create(this.onClickArrow, this)).setTransitionNone();
        this.onBtnClick(this.RC_btn_search.node, we.core.Func.create(this.onClickSearch, this));

        this.RC_list_game.node.off(`scrolling`, this.onGameListScrolling, this);
        this.RC_list_game.node.on(`scrolling`, this.onGameListScrolling, this);
        cc.director.on(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);
        we.event().on('SceneChangeStart', this.onSaveLastEntryLocation, this);
    }

    protected onDestroy(): void {
        cc.director.off(HallEvent.EVENT_SEARCH_GAME_SHOW, this.onShowSearchGame, this);
        we.event().off('SceneChangeStart', this.onSaveLastEntryLocation, this);
    }

    protected onEnable(): void {
        this.curGroupIndex = HallGameListMgr.curGroupIndex;
        this.RC_list_group.selectedId = this.curGroupIndex;
        this.selectGroupMove(this.curGroupIndex);
    }

    protected start(): void {
        // group list data
        this.curGroupIndex = HallGameListMgr.curGroupIndex;
        this.groupList = HallGameListMgr.getHallGroupList();

        // group list
        this.RC_list_group.setRenderEvent(we.core.Func.create(this.onRenderGroupItem, this));
        this.RC_list_group.setSelectedEvent(we.core.Func.create(this.onSelectGroupItem, this));
        this.RC_list_group.numItems = this.groupList.length;
        this.RC_list_group.selectedId = this.curGroupIndex;

        // games list
        this.RC_list_game.setRenderEvent(we.core.Func.create(this.onRenderGamesEvent, this));

        // banner
        const banner = this.getAsset(HallRes.prefab.hall_banner, cc.Prefab);
        if (banner) {
            this.RCN_banner.addChild(cc.instantiate(banner));
        }
        // 公告
        we.commonUI.createNode(HallRes.prefab.withdraw.broadcast, this.RCN_withdrawBroadcast);

        this.updateGameList();

        // 闪告
        this.initMarquee();

        // 设置列表宽度
        this.setRCListGroupWidth();

        this.recoverLastEntryLocation();
    }

    private setRCListGroupWidth() {
        if (this.maxShowListGroupCount && this.groupList.length > this.maxShowListGroupCount) {
            let viewNode = this.RC_list_group.node.getChildByName('view');
            if (viewNode) {
                viewNode.getComponent(cc.Layout).enabled = false;
                viewNode.width = this.widthListGroup;
                this.RC_list_group.scrollTo(0);
            }
        }
    }

    private async initMarquee() {
        let prefab = null;
        if (we.core.flavor.getSkinCode() === we.core.SkinCode.ct4) {
            prefab = await this.loadAsset(HallRes.prefab.marquee, cc.Prefab);
        } else {
            prefab = await this.loadAsset(HallRes.prefab.marqueePop, cc.Prefab);
        }

        if (prefab) {
            this.RC_marquee.addChild(cc.instantiate(prefab));
        }
    }

    private onRenderGroupItem(item: cc.Node, i: number) {
        let itemComp = item.getComponent(HallGroupItem_v);
        // TODO 状态最好是UI设置的时候
        itemComp?.init(this.groupList, i);
    }

    private onSelectGroupItem(item: cc.Node, i: number) {
        this.RC_list_game.scrollView.stopAutoScroll();
        this.curGroupIndex = i;
        this.selectGroupMove(i);
        HallGameListMgr.curGroupIndex = this.curGroupIndex;
        this.updateGameList();
    }

    private selectGroupMove(i: number) {
        let scrollTo = 0;
        if (i <= 1) {
            scrollTo = 0;
        } else if (i >= 2) {
            scrollTo = i - 1;
        }
        this.RC_list_group.scrollTo(scrollTo);
    }

    private onRenderGamesEvent(item: cc.Node, i: number) {
        if (IsShowBigIcon === true) {
            const gameIds = this.curGameList[i];
            const com = item.getComponent(HallGameLine_v);
            com.init(gameIds);
        } else {
            const gameId = this.curGameListOne[i];
            const gameCfg = HallGameListMgr.getGameEntryConfig(gameId, false, false);
            const com = item.getComponent(HallGameItem_v);
            com?.init(gameCfg);
        }
    }

    private updateGameList() {
        if (!cc.isValid(this.RC_list_game)) {
            return;
        }

        this.RC_list_game.scrollTo(0.5, -1);
        this.RCN_btn_arrow.scaleY = -1;
        this.isGamesListTop = true;

        this.curGameList = HallGameListMgr.getHallGameList(this.groupList[this.curGroupIndex]);
        this.curGameListOne = this.curGameList.flat();

        if (this.curGameList.length < 1 || this.curGameListOne.length < 1) {
            return;
        }

        if (IsShowBigIcon === true) {
            this.RC_list_game.numItems = this.curGameList.length;
        } else {
            this.RC_list_game.numItems = this.curGameListOne.length;
        }

        this.RC_list_game.updateAll();

        this.onGameListScrolling();
    }

    private onUpdateGameListSize() {
        if (!cc.isValid(this.RC_list_game)) {
            return;
        }
        this.RC_list_game.updateAll();
    }

    private onGameListScrolling() {
        if (this.RC_list_game.scrollView.content.height <= this.RC_list_game.node.height + 50) {
            this.RCN_btn_arrow.active = false;
            return;
        }
        let offset_max = this.RC_list_game.scrollView.getMaxScrollOffset().y;
        let offset_cur = Math.abs(this.RC_list_game.scrollView.getScrollOffset().y);
        this.RCN_btn_arrow.active = offset_cur > 240 && offset_cur < offset_max - 240 ? false : true;
        this.RCN_btn_arrow.scaleY = offset_cur < 240 ? -1 : 1;
        this.isGamesListTop = offset_cur < 240 ? true : false;
    }

    private onClickArrow() {
        if (this.isGamesListTop === true) {
            let offset_max = this.RC_list_game.scrollView.getMaxScrollOffset().y;
            let offset_cur = Math.abs(this.RC_list_game.scrollView.getScrollOffset().y);
            let time = (offset_max - offset_cur) / ListMoveSpeed;
            this.RC_list_game.scrollTo(9999, time);
            this.isGamesListTop = false;
        } else {
            let offset_cur = Math.abs(this.RC_list_game.scrollView.getScrollOffset().y);
            let time = offset_cur / ListMoveSpeed;
            this.RC_list_game.scrollTo(0, time);
            this.isGamesListTop = true;
        }
    }

    /** 搜索游戏 */
    private async onClickSearch() {
        cc.director.emit(HallEvent.EVENT_SEARCH_GAME_SHOW, true);
    }

    private onShowSearchGame(isShow: boolean) {
        this.RC_main.active = !isShow;
    }

    private onSaveLastEntryLocation() {
        // 记录当前用户操作数据,用于下次进入时显示
        HallGameListMgr.lastGameEnterLocation.hallParams = {
            scrollOffset: this.RC_list_game?.scrollView?.getScrollOffset().clone(),
            groupIndex: this.curGroupIndex,
        };
    }

    private recoverLastEntryLocation() {
        if (we.core.gameConfig.getSceneFrom() !== we.SceneFrom.Game) {
            return;
        }
        const { groupIndex, scrollOffset } = HallGameListMgr.lastGameEnterLocation.hallParams;
        if (this.curGroupIndex != groupIndex) {
            this.RC_list_group.selectedId = groupIndex;
        }
        if (scrollOffset && scrollOffset.y) {
            this.scheduleOnce(() => {
                this.RC_list_game.scrollView.scrollToOffset(scrollOffset, 0.1);
            }, 0.3);
        }
    }
}
