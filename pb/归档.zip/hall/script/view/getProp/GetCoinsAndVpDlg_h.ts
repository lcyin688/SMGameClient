import { HallRes } from '../../config/HallRes';
import { HallViewId } from '../HallViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('GetCoinsAndVpDlgView_h', we.bundles.hall)
class GetCoinsAndVpDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_lab_awardNum: cc.Label = null;

    @we.ui.ccBind(sp.Skeleton)
    public RC_titleAnim: sp.Skeleton = null;

    @we.ui.ccBind(cc.Node)
    public RCN_awardInfo: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_receive: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('GetCoinsAndVpDlg_h', we.bundles.hall)
export class GetCoinsAndVpDlg_h extends we.ui.DlgSystem<GetCoinsAndVpDlgView_h> {
    private award: number = 0;

    private bClose: boolean = false;

    private openType: string = '';

    /** 注册UI事件 */
    public async registerUIEvent() {
        we.common.apiMgr.getUserCreditReq((data: ApiProto.UserCreditResp) => {
            if (data.credit > we.common.userMgr.userInfo.gold) {
                this.bClose = true;
            }
        });
        this.view.cc_onBtnClick(this.view.RCN_receive, we.core.Func.create(this.closeView, this)).setSleepTime(0.5);
    }

    /** 显示窗口 */
    public async onShow(coins: number, type?: string) {
        if (type) {
            this.openType = type;
        }
        we.core.audioMgr.playEffect(HallRes.audio.award);
        this.award = coins;

        this.view.RC_titleAnim.setAnimation(0, 'animation1', false);
        this.view.RC_titleAnim.setCompleteListener(() => {
            this.view.RC_titleAnim.clearTracks();
            this.view.RC_titleAnim.setAnimation(0, 'animation2', true);
            this.view.RC_titleAnim.setCompleteListener(null);
        });

        this.scheduleOnce(0.75).then(() => {
            if (!cc.isValid(this.view.RCN_receive)) {
                return;
            }
            this.view.RCN_receive.active = true;
            this.tween(this.view.RCN_receive).to(0.3, { scale: 1.1 }, { easing: 'sineOut' }).to(0.08, { scale: 1 }, { easing: 'sineIn' }).start();
        });

        this.view.RC_lab_awardNum.string = we.common.utils.formatAmount(this.award);
    }

    /** 隐藏窗口 */
    public async onHide() {
        if (this.bClose === false) {
            return;
        }

        let normal = we.ui.UILayer.normal;
        if (cc.isValid(normal)) {
            const hasShop = we.currentUI.getDlg(HallViewId.StoreDlg);
            if (hasShop) {
                cc.director.emit(we.common.EventName.STORE_COIN_FLY_ANIM, { node: this.view.RCN_awardInfo, award: this.award });
            } else {
                cc.director.emit(we.common.EventName.COIN_FLY_ANIM, { node: this.view.RCN_awardInfo, award: this.award });
            }
        }
        // 新手礼包领取完毕，开启下一个引导
        if (this.openType == 'first') {
            cc.director.emit(we.common.EventName.HALL_POPUP_QUEUE_CLOSE, we.common.JumpCmd.Newbie_Gift_Bag);
        }
    }

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(GetCoinsAndVpDlg_h, `${HallViewId.GetCoinsAndVpDlg}_h`)
class GetCoinsAndVpDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(GetCoinsAndVpDlg_h, uiBase.addComponent(GetCoinsAndVpDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(GetCoinsAndVpDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<GetCoinsAndVpDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(GetCoinsAndVpDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(GetCoinsAndVpDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(GetCoinsAndVpDlg_h).beforeUnload();
    }
}
