import { HallViewId } from '../../view/HallViewId';
import { EnterGameContext } from './EnterGameFlow';

/**
 * 显示兑换比例
 * 玩家可选择是否关闭或开始游戏，定时自动确认
 * 弹出条件
 * - 1.厂商货币价值与我们一致时，不弹
 * - 2.玩家勾选今日不在弹出时，不弹
 */
export class LineConversionTipTask<T extends EnterGameContext, R> extends we.core.pipeline.IExecutor<T, R> {
    async execute(ctx: T, signal: AbortSignal, taskCtx?: R) {
        const gameCfg = we.core.gameConfig.getGameConfig(ctx.gameId);
        const vendorConfig = we.common.CommonModel.Inst.getVendorConfig(gameCfg?.vendorId);
        const dlg = await we.currentUI.show(HallViewId.LineConversionTipDlg, vendorConfig.vendorRatio).catch((err) => {
            we.error(`LineConversionTipTask execute, err: ${JSON.stringify(err.message || err)}`);
            throw new Error(`LineConversionTipTask execute, show: LineConversionTipDlg failed`);
        });
        const continueGame = (await dlg.waitClose<boolean>()).closeData;
        if (!continueGame) {
            throw new Error(`LineConversionTipTask execute, player cancel enter game`);
        }
    }

    config(): we.core.pipeline.TaskConfig<T, R> {
        return {
            mode: we.core.pipeline.TaskMode.Continue,
            condition: async (ctx: T, taskCtx?: R) => {
                return await this.condition(ctx, taskCtx);
            },
        };
    }

    private async condition(ctx: T, taskCtx?: R): Promise<boolean> {
        // 玩家勾选今日不在弹出时，不弹
        const noPropConversionTip = we.common.storage.getDay('common', 'no_prop_conversion_tip');
        if (noPropConversionTip) {
            return false;
        }

        const gameCfg = we.core.gameConfig.getGameConfig(ctx.gameId);
        const vendorConfig = we.common.CommonModel.Inst.getVendorConfig(gameCfg?.vendorId);
        if (vendorConfig?.vendorRatio != null) {
            // 厂商货币转换比例精度为万分比，10000 表示 1:1（服务器明确不会修改精度，如果存在精度变更，服务器会适配至万分比）
            // 厂商货币与我们货币值一样时，不弹出兑换比例
            return vendorConfig.vendorRatio != 1 * 10000;
        }

        return false;
    }
}
