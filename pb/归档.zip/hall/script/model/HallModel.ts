import { HallMobx } from './mobx/HallMobx';

/**
 * 无需mobx监听触发更新的数据定义
 */
@we.decorator.typeRegister('HallModel', we.bundles.hall)
export class HallModel extends we.core.Entity {
    static Inst: HallModel;
    public store: HallMobx;

    protected awake(): void {
        HallModel.Inst = this;
        this.store = new HallMobx();
        we.mobx.makeAutoObservable(this.store);
    }

    protected destroy(): void {}
}
