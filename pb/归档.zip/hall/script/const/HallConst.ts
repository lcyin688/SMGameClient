export const enum HallPageEnum {
    /** 商城，充值 */
    shop = 0,
    /** 提现 */
    withdraw = 1,
    /** 主界面，游戏列表 */
    games = 2,
    /** 活动，事件中心 */
    event = 3,
    /** 我的，个人中心 */
    me = 4,
}
