const { ccclass, property } = cc._decorator;

@ccclass
export default class DownLoadTouchMove extends cc.Component {
    private _moveParent: cc.Node = null;

    private _gameViewSize: cc.Size = null;

    private startPos: cc.Vec2 = cc.v2(0, 0);

    private isMoveTrue: boolean = false;

    protected onEnable(): void {
        this.updateGameView();

        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
        we.event<we.core.EventMsg>().on('WindowResize', this.updateGameView, this);
    }

    protected onDisable(): void {
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
        we.event<we.core.EventMsg>().offByTarget(this);

        this.node.stopAllActions();
    }

    private updateGameView(): void {
        this.scheduleOnce(() => {
            this._gameViewSize = cc.view.getVisibleSize();

            if (this.node.parent == this._moveParent) {
                let curWPos: cc.Vec2 = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
                let wPosX = Math.min(this._gameViewSize.width - this.node.width * (1 - this.node.anchorX), Math.max(0 + this.node.width * this.node.anchorX, curWPos.x));
                let wPosY = Math.min(this._gameViewSize.height - this.node.height * (1 - this.node.anchorY), Math.max(0 + this.node.height * this.node.anchorY, curWPos.y));
                let localPos = this._moveParent.convertToNodeSpaceAR(cc.v2(wPosX, wPosY));
                this.node.setPosition(localPos);
            }
        });
    }

    public initTouchMove(moveParent: cc.Node): void {
        this._moveParent = moveParent;
    }

    private onTouchStart(event: cc.Event.EventTouch): void {
        if (this.node.parent != this._moveParent) {
            let wPos = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
            let movePos = this._moveParent.convertToNodeSpaceAR(wPos);
            this.node.parent = this._moveParent;
            this.node.setPosition(movePos);
        }
        this.startPos = this.node.getPosition();
        this.isMoveTrue = false;
    }

    private onTouchMove(event: cc.Event.EventTouch): void {
        let pos: cc.Vec2 = this.node.getPosition();
        let addLocalPos = pos.add(event.getDelta());
        let addWPos = this._moveParent.convertToWorldSpaceAR(addLocalPos);
        let wPosX = Math.min(this._gameViewSize.width - this.node.width * (1 - this.node.anchorX), Math.max(0 + this.node.width * this.node.anchorX, addWPos.x));
        let wPosY = Math.min(this._gameViewSize.height - this.node.height * (1 - this.node.anchorY), Math.max(0 + this.node.height * this.node.anchorY, addWPos.y));
        let localPos = this._moveParent.convertToNodeSpaceAR(cc.v2(wPosX, wPosY));
        this.node.setPosition(localPos);

        if (!this.isMoveTrue && this.startPos.sub(localPos).mag() > 30) {
            this.isMoveTrue = true;
            this.node.getComponent(cc.Button).interactable = false;
        }
    }

    private onTouchEnd(event: cc.Event.EventTouch): void {
        if (this.isMoveTrue) {
            this.node.getComponent(cc.Button).interactable = true;
        }
    }

    private onTouchCancel(event: cc.Event.EventTouch): void {
        if (this.isMoveTrue) {
            this.node.getComponent(cc.Button).interactable = true;
        }
    }
}
