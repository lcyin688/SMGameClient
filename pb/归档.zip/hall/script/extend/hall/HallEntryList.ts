const { ccclass, disallowMultiple, menu, property } = cc._decorator;

/** 功能入口枚举，新增入口统一添加到尾部，禁止从中间插入 */
enum Entry {
    /** 0 - 落地页包赠送奖励入口 */
    RCN_OfficialPkgAwardEntry,
    /** 1 - 安全绑定入口 */
    RCN_SafeEntry,
    /** 2 - 银行入口 */
    RCN_BankEntry,
    /** 3 - 问卷调查入口 */
    RCN_QuestionNaireEntry,
    /** 4 - 新手礼包入口 */
    RCN_NewbieGiftBagEntry,
    /** 5 - 每日充值入口 */
    RCN_DailyRechargeRewardEntry,
    /** 6 - 加入我们入口 */
    RCN_JoinUsEntry,
    /** 7 - 开斋节入口 */
    RCN_CarnivalEntry,
    /** 8 - 独立日活动入口 */
    RCN_IndependentEntry,
    /** 9 - 转盘活动入口 */
    RCN_TurntableEntry,
    /** 10 - 礼包码入口 */
    RCN_RedeemCodeEntry,
    /** 11 - 每日金币入口 */
    RCN_DailyAwardEntry,
    /** 12 - Vip入口 */
    RCN_VIPEntry,
    /** 13 - 月签到入口 */
    RCN_MonthSignEntry,
    /** 14 - 救援金入口 */
    RCN_RescueFundsEntry,
    /** 15 - 周卡入口 */
    RCN_WeekCardEntry,
    /** 16 - 七日福利入口 */
    RCN_SevenDayEntry,
}

@ccclass
@disallowMultiple
@menu('hall/HallEntryList(功能入口列表组件)')
export default class HallEntryList extends cc.Component {
    @property({ type: cc.Node, tooltip: CC_DEV && '折叠列表' })
    private collapseList: cc.Node = null;
    @property({ tooltip: CC_DEV && '最大常驻节点数' })
    private limit: number = 0;
    @property({ tooltip: CC_DEV && '是否启用排序' })
    private sort: boolean = true;

    /** 完整节点数组 */
    private btns: cc.Node[] = [];

    protected onLoad(): void {
        // 初始化时将子节点引用全部备份进节点数组
        this.btns.push(...this.node.children);
    }

    /**
     * 根据 limit 配置将溢出的节点收纳进折叠列表，如果没有折叠列表则将全部有效节点放回主节点
     * @param {cc.Node} collapseList
     * @returns {Promise<boolean>} 节点数量是否溢出
     */
    public async refresh(collapseList: cc.Node = this.collapseList): Promise<boolean> {
        let count = 0;
        this.collapseList = collapseList;

        // 如果有失效节点，等下一帧再执行，避免底层报错
        for (let btn of this.btns) {
            if (!we.core.utils.isValidNode(btn)) {
                await new Promise((resolve) => {
                    this.scheduleOnce(resolve);
                });
                break;
            }
        }

        this.node.removeAllChildren();
        this.collapseList?.removeAllChildren();

        if (this.sort) {
            this.btns.sort((a, b) => {
                const indexA = we.core.projectConfig.settingsConfig.activitySort.indexOf(Entry[a.name]);
                const indexB = we.core.projectConfig.settingsConfig.activitySort.indexOf(Entry[b.name]);
                return (indexA === -1 ? cc.macro.MAX_ZINDEX : indexA) - (indexB === -1 ? cc.macro.MAX_ZINDEX : indexB);
            });
        }

        this.btns.forEach((btn) => {
            // 跳过不可见节点
            if (!btn?.active) {
                return;
            }
            // 跳过无效节点
            if (btn.childrenCount === 0 && !btn.getComponent(we.ui.WEButton)) {
                return;
            }
            btn.setPosition(0, 0);
            if (this.collapseList && this.node.childrenCount >= this.limit) {
                btn.setParent(this.collapseList);
            } else {
                btn.setParent(this.node);
            }
            count++;
        });
        // 子节点被全部移除后需要强制刷新布局
        this.getComponent(cc.Layout)?.['_doLayout']?.();
        this.collapseList?.getComponent(cc.Layout)?.['_doLayout']?.();
        return count > this.limit;
    }
}
