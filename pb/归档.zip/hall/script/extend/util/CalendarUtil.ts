import HallSkin from '../../config/HallSkin';
import { CalendarDayType, CalendarCurrentDate, CalendarYearMonthData } from './CalendarModel';

export default class CalendarUtil {
    public static getColorConfig(dayType: CalendarDayType, stCol?: string[]): cc.Color {
        let fromHEX = stCol[dayType] || '#FFFFFF';
        return new cc.Color().fromHEX(fromHEX);
    }

    public static copyDate(date: CalendarCurrentDate): CalendarCurrentDate {
        let ret: CalendarCurrentDate = {
            year: date.year,
            month: date.month,
            day: date.day,
            minutes: date.minutes || 0,
            hours: date.hours || 0,
            seconds: date.seconds || 0,
        };
        return ret;
    }

    // 是否是同一天
    public static isSameDay(date1: CalendarCurrentDate, date2: CalendarCurrentDate) {
        return date1.day === date2.day && date1.month === date2.month && date1.year === date2.year;
    }

    // 是否是今天
    public static isToday(year: number, month: number, day: number, theDate: Date = null): boolean {
        let date = theDate ? theDate : new Date();
        return year === date.getFullYear() && month === date.getMonth() + 1 && day === date.getDate();
    }

    // 是否是闰年
    public static isLeapYear(year: number): boolean {
        return 0 === year % 400 || (0 === year % 4 && 0 !== year % 100);
    }

    // 获取某一年每个月天数的数组
    public static getYearMonthDay(year: number): Array<number> {
        let ret = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        if (this.isLeapYear(year)) {
            ret[1] = 29;
        }
        return ret;
    }

    // 格式话日期
    public static formatDate(date: CalendarCurrentDate): string {
        return `${date.year}-${date.month}-${date.day}`;
    }

    // 获取日期标记用户日期排序
    public static getDateFlag(date: CalendarCurrentDate): number {
        return date.year * (12 * 31) + date.month * 31 + date.day;
    }

    // 获取某个日期是否在给定日期之间
    public static isBetweenDate(start: CalendarCurrentDate, end: CalendarCurrentDate, current: CalendarCurrentDate) {
        let startTime = this.getDateFlag(start);
        let endTime = this.getDateFlag(end);
        let curTime = this.getDateFlag(current);
        return curTime >= startTime && curTime <= endTime;
    }

    // 获取某个日期是否能点击
    public static isClickDate(date: CalendarCurrentDate, earliestDate?: CalendarCurrentDate) {
        let curDate = new Date();
        // 年
        if (curDate.getFullYear() < date.year) {
            return false;
        }
        // 月
        if (curDate.getFullYear() == date.year && curDate.getMonth() + 1 < date.month) {
            return false;
        }
        // 日
        if (curDate.getFullYear() == date.year && curDate.getMonth() + 1 == date.month && curDate.getDate() < date.day) {
            return false;
        }
        if (earliestDate) {
            // 最早日期 年
            if (earliestDate.year > date.year) {
                return false;
            }
            // 最早日期 月
            if (earliestDate.year == date.year && earliestDate.month > date.month) {
                return false;
            }
            // 最早日期 日
            if (earliestDate.year == date.year && earliestDate.month == date.month && earliestDate.day > date.day) {
                return false;
            }
        }
        return true;
    }

    // 获取某个日期是否在给定日期之间
    public static isBetweenDate2(start: CalendarCurrentDate, end: CalendarCurrentDate, seconds: number) {
        let startTime = this.getDateFlag(start);
        let endTime = this.getDateFlag(end);

        let current: CalendarCurrentDate = {
            year: 0,
            month: 0,
            day: 0,
        };

        let nowDate = new Date(seconds * 1000);
        current.year = nowDate.getFullYear();
        current.month = nowDate.getMonth() + 1;
        current.day = nowDate.getDate();

        let curTime = this.getDateFlag(current);
        return curTime >= startTime && curTime <= endTime;
    }

    // 日期大小对比
    public static compareDate(date1: CalendarCurrentDate, date2: CalendarCurrentDate) {
        let date1Flag = this.getDateFlag(date1);
        let date2Flag = this.getDateFlag(date2);
        if (date1Flag === date2Flag) {
            return 0;
        } else if (date1Flag < date2Flag) {
            return -1;
        } else {
            return 1;
        }
    }

    // 日期排序
    public static sortDate(arrays: CalendarCurrentDate[]) {
        let retArray = [];

        arrays.forEach((item) => {
            retArray.push(this.copyDate(item));
        });

        retArray.sort((a, b) => {
            return this.getDateFlag(a) - this.getDateFlag(b);
        });

        return retArray;
    }

    // 获取某年某月某日前或者后x天的日期日期
    public static getYearMonthDayX(currentData: CalendarCurrentDate, count: number): CalendarCurrentDate {
        let targetDate = new Date(currentData.year, currentData.month - 1, currentData.day + count);
        let ret: CalendarCurrentDate = {
            year: 0,
            month: 0,
            day: 0,
        };

        ret.year = targetDate.getFullYear();
        ret.month = targetDate.getMonth() + 1;
        ret.day = targetDate.getDate();

        return ret;
    }

    // 格式化年月
    public static formatYYMM(year: number, month: number): string {
        return `${year}\/${month}`;
    }

    // 获取星期文本描述
    public static getWeek(lang: string): Array<String> {
        let chinese = ['日', '一', '二', '三', '四', '五', '六'];
        let english = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
        let indonesia = ['M', 'S', 'S', 'R', 'K', 'J', 'S'];
        switch (lang) {
            case 'en':
                return english;
            case 'zh':
                return chinese;
            default:
                return indonesia;
        }
    }

    // 某年某天是星期几
    public static getYearMonthWeek(year: number, month: number, day: number): number {
        let date = new Date(year, month - 1, day);
        return date.getDay();
    }

    // 获取某年某月日期数据
    public static getCalendarYearMonthData(year: number, month: number): CalendarYearMonthData {
        let ret: CalendarYearMonthData = {
            days: [],
            splitor: [],
            week: 0,
        };
        let currentYear = year;
        let currentMonth = month;
        let prevYear = year - 1;
        let nextYear = year + 1;
        let lastMonth = currentMonth === 1 ? 12 : currentMonth - 1;
        let nextMonth = currentMonth === 12 ? 1 : currentMonth + 1;

        let lastMonthDay = 0;
        let nextMonthDay = 0;
        let curYearMonth = this.getYearMonthDay(currentYear);

        if (month === 1) {
            let lastYearMonth12 = this.getYearMonthDay(prevYear);
            let month12 = lastYearMonth12[11];

            lastMonthDay = month12;
            nextMonthDay = curYearMonth[nextMonth - 1];
        } else if (month === 12) {
            let nextYearMonth1 = this.getYearMonthDay(nextYear);
            let month1 = nextYearMonth1[0];

            lastMonthDay = curYearMonth[lastMonth - 1];
            nextMonthDay = month1;
        } else {
            lastMonthDay = curYearMonth[lastMonth - 1];
            nextMonthDay = curYearMonth[nextMonth - 1];
        }

        let week = this.getYearMonthWeek(year, month, 1);
        ret.week = week;

        // 上月补位天数
        let lastMonthFillDays = week;
        // 当月天数
        let currMonthFillDays = curYearMonth[currentMonth - 1];
        // 下月补位天数
        let nextMonthFillDays = 42 - lastMonthFillDays - currMonthFillDays;
        for (let i = 0; i < lastMonthFillDays; i++) {
            ret.days.push(lastMonthDay - lastMonthFillDays + 1 + i);
        }
        for (let i = 0; i < currMonthFillDays; i++) {
            ret.days.push(1 + i);
        }
        for (let i = 0; i < nextMonthFillDays; i++) {
            ret.days.push(1 + i);
        }

        ret.splitor.push(week);
        ret.splitor.push(week + currMonthFillDays);
        return ret;
    }
}
