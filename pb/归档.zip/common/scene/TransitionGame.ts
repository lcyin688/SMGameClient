const { ccclass, property } = cc._decorator;

@ccclass
export default class TransitionGame extends cc.Component {
    onLoad() {
        // 设置屏幕方向
        we.core.nativeUtil.setScreenOrientation(we.core.flavor.getSkinOrientation());

        // 动态设置竖版大背景
        if (cc.sys.isBrowser && !cc.sys.isMobile && we.core.flavor.getSkinOrientation() === we.core.ScreenOrientation.PORTRAIT) {
            // 是否使用场景遮罩
            we.ui.UILayer.uiRoot.addComponentUnique(cc.Mask).enabled = true;
            // 动态设置竖版大背景
            let bgCom = we.currentScene.getComponent(we.core.SceneBigBackground);
            if (!bgCom) {
                we.currentScene.addComponentAsync(we.core.SceneBigBackground, we.launcher.res.ctryres.bigBg);
            }
        }
    }
}
