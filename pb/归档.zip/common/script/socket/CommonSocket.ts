import { CommonLanguage } from '../const/CommonLanguage';
import CommonMgr from '../manager/CommonMgr';
import GameManager from '../manager/GameManager';
import UserManager from '../manager/UserManager';
import CommonProtoFile from '../proto/CommonProtoFile';
import { CommonProtoMsg } from '../proto/CommonProtoMsg';
import CommonProtoBuf from './CommonProtoBuf';
import { WsCloseCode } from './SocketCode';

declare global {
    interface ICommon {
        CommonSocket: typeof CommonSocket;
    }

    namespace we {
        namespace common {
            type CommonSocket = InstanceType<typeof CommonSocket>;
        }
    }
}

export default class CommonSocket {
    private gameId: we.GameId;
    private name: string;
    private url: string;

    private messageCallback: (data: ArrayBuffer | { msgId: number; msgData: Object }) => void;
    private openCallback: () => void;
    private closeCallback: () => void;
    private pingCallback: () => void;
    private pongCallback: (msgData: any) => void;

    private webSocket: WebSocket;
    /** protobuf */
    private protoBuf: CommonProtoBuf;
    /** 连接超时时间 */
    private connectTimeoutTime: number;
    /** 连接超时定时器 */
    private connectTimeoutTimer: any;
    /** 连接失败 */
    private connectFailed: boolean;
    /** 心跳间隔 */
    private heartbeatInterval: number;
    /** 心跳定时器 */
    private heartbeatTimer: any;
    /** 心跳超时时间 */
    private heartbeatTimeoutTime: number;
    /** 心跳超时定时器 */
    private heartbeatTimeoutTimer: any;
    /** 是否重连 */
    private reconnectEnabled: boolean;
    /** 重连锁 */
    private reconnectLock: boolean;
    /** 重连次数 */
    private reconnectCount: number;
    /** 加载完成 */
    private loaded: boolean;
    /** 被意外 close 后多少秒开始重连 */
    private closeReconnectTime: number;
    /** 连接被关闭定时重连 */
    private closeReconnectTimer: any;
    /** 消息接收计数 */
    private msgCount: number = 0;
    /** 转圈回话取消 */
    private circleCancelAction: we.core.CancelAction;

    /**
     * 可自定义的回调
     */
    private _handler = {
        onConnectComplete: {
            call: () => {},
            target: null,
        },

        onReconnectedUIChange: {
            call: () => {},
            target: null,
        },
    };

    public constructor(gameId: we.GameId, url: string) {
        if (!(we.GameId[gameId] && url)) {
            we.warn(`CommonSocket constructor, params err, gameId: ${gameId}`);
            return;
        }

        this.gameId = gameId;
        this.name = gameId == we.GameId.NAMING ? 'naming' : we.core.gameConfig.getBundleName(gameId);
        this.url = url;

        this.messageCallback = null;
        this.openCallback = null;
        this.closeCallback = null;
        this.pingCallback = null;
        this.pongCallback = null;

        this.webSocket = null;
        this.protoBuf = new CommonProtoBuf(CommonProtoFile, CommonProtoMsg, { enums: Number });
        this.connectTimeoutTime = 10_000;
        this.connectTimeoutTimer = null;
        this.connectFailed = false;
        this.heartbeatInterval = 5_000;
        this.heartbeatTimer = null;
        this.heartbeatTimeoutTime = 3_000;
        this.heartbeatTimeoutTimer = null;
        this.reconnectEnabled = false;
        this.reconnectLock = false;
        this.reconnectCount = 0;
        this.loaded = false;
        this.closeReconnectTime = 1_000;
        this.closeReconnectTimer = null;
        this.msgCount = 0;

        // 断线重连时的ui默认提示
        this._handler.onReconnectedUIChange.call = () => {
            if (this.loaded) {
                this.circleCancelAction = we.core.CancelAction.create();
                this.circleCancelAction.add(() => {
                    we.commonUI.hideCircleLoading();
                });
                we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(CommonLanguage.TIPS_NET_RECONNECTING), debug: 'CommonSocket constructor' });
            }
        };

        // 连接成功时回调，默认 删除GameLaoding
        this._handler.onConnectComplete.call = () => {
            setTimeout(() => {
                we.currentScene?.getComponent(we.core.ObjectWait).notify(new we.core.EventObjectWait.SceneReady(we.core.WaitTypeError.Success), true);
            }, 100);
        };

        this.createWs();
    }

    public init(
        url?: string,
        messageCallback?: (data: ArrayBuffer | { msgId: number; msgData: Object }) => void,
        openCallback?: () => void,
        closeCallback?: () => void,
        pingCallback?: () => void,
        pongCallback?: (msgData: any) => void,
        heartbeatInterval?: number
    ): void {
        this.messageCallback = messageCallback;
        this.openCallback = openCallback;
        this.closeCallback = closeCallback;
        this.pingCallback = pingCallback;
        this.pongCallback = pongCallback;
        this.heartbeatInterval = heartbeatInterval >= 1_000 && heartbeatInterval <= 5_000 ? heartbeatInterval : this.heartbeatInterval;
        this.reconnectEnabled = true;

        if (!url) {
            if (this.gameId == we.GameId.NAMING) {
                url = we.core.serverMgr.getNamingWs();
            } else {
                url = we.common.gameServerMgr.getGameWs(this.gameId);
            }
        }

        if (url == this.url) {
            if (this.connectFailed) {
                this.createWs();
            } else {
                if (this.isConnected()) {
                    if (typeof this.openCallback == 'function') {
                        this.openCallback();
                    }
                }
            }
        } else {
            this.url = url;
            this.createWs();
        }

        // 内网调试
        if (url.includes('127.0.0.1')) {
            this.heartbeatInterval = 300_000;
        }

        if (we.core.gameConfig.isSubGame(this.gameId)) {
            cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_SERVER_CONNECT_ING));
            cc.director.emit(we.core.EventName.LOAD_PROGRESS_ACTIVE, true);

            let msg = {
                percent: 0,
                loadType: we.core.LoadType.CONNECT,
                bundleName: we.core.gameConfig.getBundleName(this.gameId),
            };
            cc.director.emit(we.core.EventName.LOAD_PROGRESS, msg);
        }
    }

    /**
     * 创建 ws
     */
    private createWs(): void {
        we.log(`CommonSocket name: ${this.name}, createWs, url: ${this.url}, reconnectCount: ${this.reconnectCount}`);

        this.destroyWs(WsCloseCode.New, 'CommonSocket createWs');

        if (!we.core.networkMgr.isNetworkAvailable()) {
            we.log(`CommonSocket name: ${this.name}, createWs, url: ${this.url}, network is invalid`);
            return;
        }

        if (!this.checkLoginStatus('createWs')) {
            return;
        }

        if (!this.url) {
            // 登录态异常时 url 会置空, 登录态校验过了的话理论上不会有 token 为空的情况, 这里做个兜底处理
            we.warn(`CommonSocket name: ${this.name}, createWs, url: ${this.url}, url is invalid`);
            return;
        }

        // 加锁 避免刚开始连接就 onError 触发重连, 时间太短重连成功的可能性不大
        this.reconnectLock = true;

        if (cc.sys.isNative) {
            // https://curl.se/docs/caextract.html
            const caNativeUrl = we.core.assetMgr.getAssetNativeUrl('launcher/ssl/cacert.pem');

            we.log(`CommonSocket name: ${this.name}, createWs, ssl h5_url: ${caNativeUrl}`);
            // TODO 后续调研从 common 中读取的问题，方向-> 下载后，从getCache读取
            // const local_url = cc.assetManager.cacheManager.getCache(caNativeUrl);
            // let url = '/data/user/0/com.fungroup.hw77/files/gamecaches/common/xxxxx.pem';

            // @ts-ignore
            this.webSocket = new WebSocket(this.url, null, caNativeUrl);
        } else {
            this.webSocket = new WebSocket(this.url);
        }

        this.webSocket.binaryType = 'arraybuffer';
        this.webSocket.onopen = this.onOpen.bind(this);
        this.webSocket.onmessage = this.onMessage.bind(this);
        this.webSocket.onerror = this.onError.bind(this);
        this.webSocket.onclose = this.onClose.bind(this);

        this.setConnectTimeout();
    }

    /**
     * 销毁 ws
     */
    private destroyWs(code: WsCloseCode, reason: string) {
        this.clearHeartbeatTimer();
        this.clearConnectTimeoutTimer();
        this.clearCloseReconnectTimer();
        this.msgCount = 0;

        if (this.webSocket) {
            this.webSocket.onopen = () => {};
            this.webSocket.onmessage = () => {};
            this.webSocket.onerror = () => {};
            this.webSocket.onclose = () => {};
            this.webSocket.close(code, reason);
            this.webSocket = null;
            we.info(`CommonSocket name: ${this.name}, destroyWs, code:${code} reason:${reason} close`);
        }
    }

    /**
     * 关闭 ws
     */
    public close(code: WsCloseCode, reason: string): void {
        // 客户端主动断开连接时不需要重连
        this.setReconnectEnabled(false);
        this.destroyWs(code, reason);
    }

    /**
     * 监听GameLoading界面删除时
     * @param call
     * @param target
     */
    public onConnectComplete(call: () => void, target?: any) {
        this._handler.onConnectComplete.call = call;
        this._handler.onConnectComplete.target = target;
    }

    /**
     * 断线重连UI提示自定义回调
     * @param call
     * @param target
     */
    public onReconnectedUIChange(call: () => void, target?: any) {
        this._handler.onReconnectedUIChange.call = call;
        this._handler.onReconnectedUIChange.target = target;
    }

    /**
     * 发送消息
     * @param msg
     */
    public send(msg: string | ArrayBuffer | SharedArrayBuffer | Blob | ArrayBufferView): void {
        if (!this.webSocket) {
            we.warn(`CommonSocket name: ${this.name}, send, webSocket is null`);
            return;
        }

        if (this.webSocket.readyState !== WebSocket.OPEN) {
            we.warn(`CommonSocket name: ${this.name}, send, readyState: ${this.webSocket.readyState}`);
            return;
        }

        if (!this.checkLoginStatus('send')) {
            return;
        }

        this.webSocket.send(msg);
    }

    /**
     * 设置重连是否启用
     * @param enabled
     */
    public setReconnectEnabled(enabled: boolean): void {
        we.log(`CommonSocket name: ${this.name}, setReconnectEnabled, enabled: ${enabled}`);

        this.reconnectEnabled = enabled;
    }

    /**
     * 是否已连接
     */
    public isConnected(): boolean {
        if (!this.webSocket) {
            return false;
        }

        return this.webSocket.readyState === WebSocket.OPEN;
    }

    /**
     * open 回调
     * @param event
     */
    private onOpen(event): void {
        we.log(`CommonSocket name: ${this.name}, onOpen`);

        if (!this.checkLoginStatus('onOpen')) {
            return;
        }

        this.connectFailed = false;
        this.reconnectLock = false;

        this.resetHeartbeat();
        this.clearConnectTimeoutTimer();

        if (typeof this.openCallback == 'function') {
            this.openCallback();
        }

        this.circleCancelAction?.cancel();

        // TODO 后续支持带 tag 的通用弹窗，指定关闭对应的 弹窗
        // we.commonUI.hideConfirm();
    }

    /**
     * message 回调
     * @param event
     */
    private onMessage(event): void {
        let msg = this.protoBuf.decode(event.data);
        if (msg && msg.msgId == CommonProtoMsg.Pong) {
            we.log(`CommonSocket name: ${this.name}, onMessage, Pong`);

            if (typeof this.pongCallback == 'function') {
                this.pongCallback(msg.msgData);
            }
        } else if (msg && msg.msgId == CommonProtoMsg.ErrorST && msg.msgData && msg.msgData['Code'] != null) {
            we.warn(`CommonSocket name: ${this.name}, onMessage, ErrorST \nmsgData: ${JSON.stringify(msg.msgData)}`);

            if (typeof this.messageCallback == 'function') {
                this.messageCallback(msg);
            }
        } else {
            this.msgCount += 1;
            if (typeof this.messageCallback == 'function') {
                this.messageCallback(event.data);
            }
        }

        // 收到第一条消息时重置重连次数, 表示本次连接结束
        if (this.msgCount == 1) {
            this.reconnectCount = 0;
        }

        this.resetHeartbeat();

        if (!this.loaded && !(msg && msg.msgId == CommonProtoMsg.Pong)) {
            this.loaded = true;
            if (we.core.gameConfig.isSubGame(this.gameId)) {
                let msg = {
                    percent: 1,
                    loadType: we.core.LoadType.CONNECT,
                    bundleName: we.core.gameConfig.getBundleName(this.gameId),
                };
                cc.director.emit(we.core.EventName.LOAD_PROGRESS, msg);

                const { call, target } = this._handler.onConnectComplete;
                target ? call.bind(target)() : call();
            }
        }

        this.checkLoginStatus('onMessage');
    }

    /**
     * error 回调
     * @param event
     */
    private onError(event): void {
        we.warn(`CommonSocket name: ${this.name}, onError`);

        this.connectFailed = true;
        this.reconnect('onError');
    }

    /**
     * close 回调
     * @param event
     */
    private onClose(event): void {
        we.warn(`CommonSocket name: ${this.name}, onClose, code: ${event.code}, reason: ${event.reason}, wasClean: ${event.wasClean}`);

        if (typeof this.closeCallback == 'function') {
            this.closeCallback();
        }

        this.connectFailed = true;
        this.closeReconnectTimer = setTimeout(() => {
            this.reconnect('onClose');
        }, this.closeReconnectTime);
    }

    /**
     * 设置连接超时
     */
    private setConnectTimeout(): void {
        this.clearConnectTimeoutTimer();
        this.connectTimeoutTimer = setTimeout(this.onConnectTimeout.bind(this), this.connectTimeoutTime);
    }

    /**
     * 清除连接超时定时器
     */
    private clearConnectTimeoutTimer(): void {
        if (this.connectTimeoutTimer != null) {
            clearTimeout(this.connectTimeoutTimer);
            this.connectTimeoutTimer = null;
        }
    }

    private clearCloseReconnectTimer(): void {
        if (this.closeReconnectTimer != null) {
            clearTimeout(this.closeReconnectTimer);
            this.closeReconnectTimer = null;
        }
    }

    /**
     * 连接超时
     */
    private onConnectTimeout(): void {
        this.connectTimeoutTimer = null;
        this.connectFailed = true;
        this.reconnectLock = false;
        this.reconnect('onConnectTimeout');
    }

    /**
     * 重置心跳
     */
    private resetHeartbeat(): void {
        if (this.gameId == we.GameId.NAMING) {
            return;
        }

        this.clearHeartbeatTimer();
        this.heartbeatTimer = setTimeout(this.onHeartbeat.bind(this), this.heartbeatInterval);
    }

    /**
     * 清除心跳定时器
     */
    private clearHeartbeatTimer(): void {
        if (this.heartbeatTimer != null) {
            clearTimeout(this.heartbeatTimer);
            this.heartbeatTimer = null;
        }

        this.clearHeartbeatTimeoutTimer();
    }

    /**
     * 心跳
     */
    private onHeartbeat(): void {
        we.log(`CommonSocket name: ${this.name}, onHeartbeat, Ping`);

        this.heartbeatTimer = null;
        this.setHeartbeatTimeout();

        let data = {
            Timestamp: new Date().getTime(),
        };
        let msg = this.protoBuf.encode(CommonProtoMsg.Ping, data);
        this.send(msg);

        if (typeof this.pingCallback == 'function') {
            this.pingCallback();
        }
    }

    /**
     * 设置心跳超时
     */
    private setHeartbeatTimeout(): void {
        this.clearHeartbeatTimeoutTimer();
        this.heartbeatTimeoutTimer = setTimeout(this.onHeartbeatTimeout.bind(this), this.heartbeatTimeoutTime);
    }

    /**
     * 清除心跳超时定时器
     */
    private clearHeartbeatTimeoutTimer(): void {
        if (this.heartbeatTimeoutTimer != null) {
            clearTimeout(this.heartbeatTimeoutTimer);
            this.heartbeatTimeoutTimer = null;
        }
    }

    /**
     * 心跳超时
     */
    private onHeartbeatTimeout(): void {
        this.heartbeatTimeoutTimer = null;
        this.connectFailed = true;
        this.reconnect('onHeartbeatTimeout');
    }

    /**
     * 重连
     */
    private reconnect(tag: string = ''): void {
        if (!this.reconnectEnabled) {
            return;
        }

        if (this.reconnectLock) {
            return;
        }

        we.log(`CommonSocket name: ${this.name}, reconnect, tag: ${tag}`);

        this.reconnectCount++;

        if (this.gameId == we.GameId.NAMING) {
            if (this.reconnectCount <= 3) {
                this.switchDomain();
                this.createWs();
            } else {
                this.close(WsCloseCode.Reconnect, 'CommonSocket reconnect naming max');
            }
        } else {
            if (this.reconnectCount <= 3) {
                if (this.reconnectCount == 2) {
                    const { call, target } = this._handler.onReconnectedUIChange;
                    target ? call.bind(target)() : call();
                }
                this.switchDomain();
                this.createWs();
            } else {
                this.close(WsCloseCode.Reconnect, 'CommonSocket reconnect game max');
                this.circleCancelAction?.cancel();

                let tips = we.core.langMgr.getLangText(we.launcher.lang.TIPS_NET_RECONNECT_FAIL);
                if (!this.loaded) {
                    tips = we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_SERVER_CONNECT_FAIL) + `: 230.${this.gameId}`;
                }

                const option = {
                    content: tips,
                    yesHandler: we.core.Func.create(() => {
                        GameManager.runGame(we.GameId.HALL);
                    }),
                    isHideCloseBtn: true,
                } as we.ui.type.ConfirmPopupOptions;

                we.commonUI.showConfirm(option);
            }
        }
    }

    /**
     * 切换域名
     */
    private switchDomain(): void {
        if (this.gameId == we.GameId.NAMING) {
            we.core.serverMgr.switchDomain(this.url);
            this.url = we.core.serverMgr.getNamingWs();
        } else {
            we.common.gameServerMgr.switchDomain(this.url);
            this.url = we.common.gameServerMgr.getGameWs(this.gameId);
        }
    }

    /**
     * 检测登录态
     * @returns
     */
    private checkLoginStatus(track?: string): boolean {
        if (!UserManager.isLogin()) {
            we.warn(`CommonSocket name: ${this.name}, checkLoginStatus, ${track}, login status is invalid`);

            this.close(WsCloseCode.UserNotLogin, 'CommonSocket checkLoginStatus');
            this.circleCancelAction?.cancel();
            CommonMgr.goLogin(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_10), `231.${this.gameId}`);
            return false;
        }
        return true;
    }
}

we.common.CommonSocket = CommonSocket;
