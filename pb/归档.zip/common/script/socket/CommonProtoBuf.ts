const protobuf = require('protobuf');

declare global {
    interface ICommon {
        CommonProtoBuf: typeof CommonProtoBuf;
    }

    namespace we {
        namespace common {
            type CommonProtoBuf = InstanceType<typeof CommonProtoBuf>;
        }
    }
}

export interface IConversionOptions {
    /** 此参数传入无效 */
    defaults?: boolean;
    /** 枚举值转换方式 Stirng 转换成字符串, Number 转成数字 */
    enums: typeof String | typeof Number;
}

export default class CommonProtoBuf {
    /** pb root */
    private protoRoot: any = null;
    /** pb msg */
    private protoMsg: Object = null;

    private opts: IConversionOptions = {
        defaults: true,
        enums: Number,
    };

    public constructor(protoFile: string, protoMsg: Object, opts?: IConversionOptions) {
        if (!protoFile || !protoMsg) {
            we.error(`CommonProtoBuf constructor, params err`);
            return;
        }

        // defaults 参数不会生效
        opts && delete opts.defaults;
        this.opts = Object.assign(this.opts, opts ?? {});

        protobuf.load(protoFile, (err, root) => {
            if (err || !root) {
                we.error(`CommonProtoBuf constructor, load err: ${err}`);
                return;
            }
            this.protoRoot = root;
        });

        this.protoMsg = protoMsg;
    }

    /**
     * 编码
     * @param msgId
     * @param msgData
     */
    public encode(msgId: number, msgData: Object): Uint8Array {
        if (!this.protoRoot) {
            we.error(`CommonProtoBuf encode, protoRoot err, msgId: ${msgId}, msgData: ${JSON.stringify(msgData)}`);
            return null;
        }

        let msgName = this.protoMsg[msgId];
        if (!msgName) {
            we.error(`CommonProtoBuf encode, msgName err, msgId: ${msgId}, msgData: ${JSON.stringify(msgData)}`);
            return null;
        }

        let msgType = this.protoRoot.lookup(msgName);
        if (!msgType) {
            we.error(`CommonProtoBuf encode, msgType err, msgName: ${msgName}, msgData: ${JSON.stringify(msgData)}`);
            return null;
        }

        let errMsg = msgType.verify(msgData);
        if (errMsg) {
            we.warn(`CommonProtoBuf encode, verify err, errMsg: ${errMsg}, msgName: ${msgName}, msgData: ${JSON.stringify(msgData)}`);
        }

        let idBuffer = new ArrayBuffer(2);
        let dv = new DataView(idBuffer);
        dv.setUint16(0, msgId, false);

        let message = msgType.fromObject(msgData);
        let dataBuffer = msgType.encode(message).finish();
        let totalBuffer = new Uint8Array(2 + dataBuffer.byteLength);
        totalBuffer.set(new Uint8Array(idBuffer), 0);
        totalBuffer.set(new Uint8Array(dataBuffer), 2);

        return totalBuffer;
    }

    /**
     * 解码
     * @param arrayBuffer
     */
    public decode(arrayBuffer: ArrayBuffer): { msgId: number; msgData: Object } {
        if (!this.protoRoot) {
            we.error(`CommonProtoBuf decode, protoRoot err`);
            return null;
        }

        let dv = new DataView(arrayBuffer);
        let msgId = dv.getUint16(0, false);
        let msgName = this.protoMsg[msgId];
        if (!msgName) {
            // we.error(`CommonProtoBuf decode, msgName err, msgId: ${msgId}`);
            return null;
        }

        let msgType = this.protoRoot.lookup(msgName);
        if (!msgType) {
            we.error(`CommonProtoBuf decode, msgType err, msgName: ${msgName}`);
            return null;
        }

        if (!Uint8Array.prototype.slice) {
            Object.defineProperty(Uint8Array.prototype, 'slice', {
                value: Array.prototype.slice,
            });
        }

        let totalBuffer = new Uint8Array(arrayBuffer);
        let dataBuffer = totalBuffer.slice(2);
        let message = msgType.decode(dataBuffer);
        let msgData = msgType.toObject(message, this.opts);
        let msg = {
            msgId: msgId,
            msgData: msgData,
        };

        return msg;
    }

    /**
     * 解析消息对象
     * @param dataBuffer
     * @param msgName
     * @returns
     */
    public decodeObject(dataBuffer: ArrayBuffer, msgName: string) {
        let msgType = this.protoRoot.lookup(msgName);
        if (!msgType) {
            we.error(`CommonProtoBuf decodeObject, msgType err, msgName: ${msgName}`);
            return null;
        }

        let message = msgType.decode(dataBuffer);
        let msgObject = msgType.toObject(message, this.opts);

        return msgObject;
    }
}

we.common.CommonProtoBuf = CommonProtoBuf;
