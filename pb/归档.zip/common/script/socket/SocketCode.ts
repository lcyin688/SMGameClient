import { CODE, giCode } from '../proto/CommonProto';

declare global {
    interface ICommon {
        /** ws 公共 code */
        WsCode: typeof WsCode;
        /** 游戏互动 code */
        GiCode: typeof GiCode;
        /** websocket 关闭业务 code 定义 */
        WsCloseCode: typeof WsCloseCode;
    }

    interface TCommon {
        /** websocket 关闭业务 code 定义 */
        WsCloseCode: WsCloseCode;
    }

    namespace we {
        namespace common {
            type WsCode = CODE;
            type GiCode = giCode;
            type WsCloseCode = TCommon['WsCloseCode'];
        }
    }
}

/** ws 公共 code */
export const WsCode = CODE;
we.common.WsCode = CODE;

/** 游戏互动 code */
export const GiCode = giCode;
we.common.GiCode = giCode;

/** websocket 关闭业务 code 定义 */
export enum WsCloseCode {
    /** 创建时关闭上一次的连接，避免重复创建ws */
    New = 4000,

    /** 断线重连关闭 */
    Reconnect = 4001,
    /** 用户登录无效，主动断开当前ws */
    UserNotLogin = 4002,
    /** 退出游戏主动关闭 */
    GameExit = 4003,
    /** 测试断开 */
    Test = 4004,
    /** 游戏切后台 */
    GameHide = 4005,
    /** 网络掉线 */
    NetOffline = 4006,
    /** 服务器错误触发关闭连接 */
    ServerError = 4007,
    /** 请求超时关闭连接 */
    ReqTimeout = 4008,
    /** 客户端错误，触发关闭连接 */
    ClientError = 4009,
    /** 重复登录 */
    DupLogin = 4010,
    /** 退出登录 */
    ExitLogin = 4011,
    /** 强更退出游戏关闭连接 */
    ForceUpdate = 4012,
}
we.common.WsCloseCode = WsCloseCode;
