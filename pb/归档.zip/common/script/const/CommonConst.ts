declare global {
    interface ICommon {
        /** 跳转 cmd */
        JumpCmd: typeof JumpCmd;
        /** 账号验证方式 */
        AccountVerifyType: typeof AccountVerifyType;
        /** 账号验证开关 */
        AccountVerifySwitch: typeof AccountVerifySwitch;
    }
}

/** 跳转枚举 */
export const JumpCmd = {
    // --------------------------- 不支持跳转配置 ---------------------------
    /** 通知授权 */
    Notice_Permission: 'notice.permission',
    /** 系统维护弹窗 */
    System_Maintain: 'system.maintain',
    /** naming token 错误 */
    Naming_Token_Error: 'naming.tokenError',
    /** 未完成游戏 */
    Uncompleted_Game: 'uncompleted.game',
    /** 游戏返回大厅弹窗检查,主要用于在线热更 */
    Game_Back_Hall: 'game.backHall',
    /** 新手赠送 */
    Newbie_Give: 'newbie.give',
    /** app 启动跳转 */
    App_Launcher_Jump: 'app.launcherJump',
    /** 功能模块引导 (后续支持其它模块引导时，需要对此做扩展) */
    Module_Guide: 'module_guide',
    /** 下载引导 */
    Download_Guide: 'download.guide',

    // ------------------- 支持跳转配置，不支持弹出排序 -----------------------
    /** 最近游戏 */
    Recent_Game: 'recent.game',
    /** 官网包 */
    Official_Pkg: 'official.pkg',
    /** 官网落地页 */
    Official_Web: 'official.web',
    /** 设置 */
    Setting: 'setting',
    /** 个人中心 */
    User_center: 'userCenter',
    /** 充值 */
    Recharge: 'store.shop',
    /** 充值 跳转外部充值引导 */
    Recharge_Guide: 'store.guide',
    /** 提现 */
    Withdraw: 'activity.withdrawal',
    /** 客服 */
    Customer: 'customer',
    /** 账号信息截屏 */
    Screen_Shot: 'account.screenShot',
    /** 绑定手机 */
    Bind_Phone: 'bind.phone',
    /** 活动-兑换码 */
    Gift_Code: 'activity.giftCode',
    /** vip */
    Vip: 'vip',
    /** 邮件 */
    Mail: 'mail',
    /** 代理 */
    Agent: 'agent',
    /** 打码返利 */
    Rebate: 'rebate',
    /** 活动-账号绑定 */
    Account_Bind: 'activity.accountBind',
    /** 下载 apk */
    Download_apk: 'download.apk',
    /** 银行 */
    Bank: 'activity.bank',

    // ------------------- 支持跳转配置，支持弹出排序 -----------------------
    /** 自定义弹窗 */
    Custom_Dlg: 'custom.dlg',
    /** 新手礼包  */
    Newbie_Gift_Bag: 'pay.first',
    /** 活动中心 */
    Activity: 'activity.activity',
    /** 每日累充 */
    Daily_Recharge: 'activity.dailyRecharge',
    /** 狂欢活动 */
    Carnival: 'activity.carnival',
    /** 独立日活动 */
    Independent: 'activity.independent',
    /** 加入官方频道 */
    Join_Us: 'activity.joinUs',
    /** 转盘活动 */
    Turntable: 'activity.turntable',
    /** 月签到，按天计算 */
    Month_Sign: 'activity.monthSign',
    /** 月签到2，按次数计算 */
    Month_Sign2: 'activity.monthSign2',
    /** 每日签到 (仅部分皮肤支持) */
    Daily_Sign: 'activity.dailySign',
    /** 七日福利 */
    Seven_Day: 'activity.sevenDay',
    /** 周卡 */
    Week_Card: 'activity.weekCard',
    /** 救援金 */
    Rescue_Funds: 'activity.rescueFunds',
    /** 官网包奖励弹窗 */
    Official_Award: 'official.award',
};

/** 账号验证方式 */
export enum AccountVerifyType {
    /** 0 短信 */
    SMS,
    /** 1 语音 */
    Voice,
    /** 2 whatsapp */
    WhatsApp,
    /** 3 email */
    Email,
}

/** 账号验证开关 */
export enum AccountVerifySwitch {
    /** 手机 */
    Phone = 'bind_phone',
    /** 邮箱 */
    Email = 'bind_mail',
}

we.common.JumpCmd = JumpCmd;
we.common.AccountVerifyType = AccountVerifyType;
we.common.AccountVerifySwitch = AccountVerifySwitch;
