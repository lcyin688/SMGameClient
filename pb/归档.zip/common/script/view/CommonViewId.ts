/**
 * 自动生成，修改无效
 * UI view id
 */
export const CommonViewId = {
    AgreementWebViewDlg: 'common/dyn/prefab/others/AgreementWebViewDlg',
    CustomerWebDlg: 'common/dyn/prefab/customer/CustomerWebDlg',
    DeviceLimitDlg: 'common/dyn/prefab/others/DeviceLimitDlg',
    PhoneBindHighDlg: 'common/dyn/prefab/account/PhoneBindHighDlg',
    PhoneLoginDlg: 'common/dyn/prefab/account/PhoneLoginDlg',
    PhonePasswordForgetDlg: 'common/dyn/prefab/account/PhonePasswordForgetDlg',
    WebViewBrowserDlg: 'common/dyn/prefab/others/WebViewBrowserDlg',
};
