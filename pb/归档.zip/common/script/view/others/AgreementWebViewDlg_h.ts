import { CommonLanguage } from '../../const/CommonLanguage';
import CommonMgr from '../../manager/CommonMgr';
import { CommonViewId } from '../CommonViewId';

enum AGREEMENT_TYPE {
    /** 用户协议 */
    USER_AGREEMENT,
    /** 隐私协议 */
    PRIVACY_AGREEMENT,
}

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('AgreementWebViewDlgView_h', we.bundles.common)
class AgreementWebViewDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Label)
    public RC_title: cc.Label = null;

    @we.ui.ccBind(cc.WebView)
    public RC_webView: cc.WebView = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btn_close: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('AgreementWebViewDlg_h', we.bundles.common)
export class AgreementWebViewDlg_h extends we.ui.DlgSystem<AgreementWebViewDlgView_h> {
    private agreementUrl: string = '';
    private loadTimer: any = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_title.string = '';
        this.view.RC_webView.node.on('loading', this.onWebViewLoading, this);
        this.view.RC_webView.node.on('loaded', this.onWebViewLoaded, this);
        this.view.RC_webView.node.on('error', this.onWebViewError, this);
        this.view.RC_webView.node.opacity = 1;
        this.view.RC_webView.node.active = true;

        // @ts-ignore
        this.view.RC_webView.setBackgroundTransparent(true);

        this.view.cc_onBtnClick(this.view.RCN_btn_close, we.core.Func.create(this.closeView, this));
    }

    /**
     * 隐私条款弹窗
     * @param type 隐私条款弹窗 0-用户协议 1-隐私协议
     */
    public async onShow(type: number) {
        let languageCode = we.core.langMgr.getCurLangCode();
        let path = '';
        if (languageCode === we.core.LangCode.ur) {
            // TODO 乌尔都语写死英语，web暂不支持乌尔都语
            languageCode = we.core.LangCode.en;
        }
        switch (type) {
            case AGREEMENT_TYPE.USER_AGREEMENT:
                this.view.RC_title.string = we.core.langMgr.getLangText(CommonLanguage.USER_AGREEMENT_1);
                path = `/terms-${languageCode}.html`;
                break;
            case AGREEMENT_TYPE.PRIVACY_AGREEMENT:
                this.view.RC_title.string = we.core.langMgr.getLangText(CommonLanguage.PRIVACY_AGREEMENT_1);
                path = `/privacy-${languageCode}.html`;
                break;
            default:
                break;
        }

        let curTime = new Date().getTime();
        path += `?ts=${curTime}&skin=${we.core.flavor.getSkinCode()}`;
        this.agreementUrl = we.core.utils.joinUrl(we.core.projectConfig.commonConfig.privacyPolicyUrl, path);
        we.log(`AgreementWebViewDlgView_h onShow, url: ${this.agreementUrl}`);

        this.loadAgreementUrl();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    protected destroy(): void {
        this.clearLoadTimer();
    }

    public beforeUnload() {
        this.view.RC_webView.node.active = false;
    }

    private loadAgreementUrl(): void {
        if (!this.agreementUrl) {
            return;
        }

        this.view.RC_webView.url = this.agreementUrl;
        this.clearLoadTimer();
        this.loadTimer = setTimeout(this.onWebViewTimeout.bind(this), 10 * 1000);
    }

    clearLoadTimer() {
        if (this.loadTimer != null) {
            clearTimeout(this.loadTimer);
            this.loadTimer = null;
        }

        CommonMgr.removeRemoteLoading(this.view.uiRoot);
    }

    onWebViewLoading(event: cc.Event) {
        we.log(`AgreementWebView_h onWebViewLoading`);
        CommonMgr.createRemoteLoading(this.view.uiRoot);
    }

    onWebViewLoaded(event: cc.Event) {
        we.log(`AgreementWebView_h onWebViewLoaded`);

        this.view.RC_webView.node.opacity = 255;
        this.clearLoadTimer();
    }

    onWebViewError(event: cc.Event) {
        we.log(`AgreementWebView_h onWebViewError`);

        this.clearLoadTimer();
        we.commonUI.showToast(we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT) + ': ' + 20002);
    }

    onWebViewTimeout() {
        we.log(`AgreementWebView_h onWebViewTimeout`);

        this.clearLoadTimer();
        we.commonUI.showToast(we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT) + ': ' + 20003);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(AgreementWebViewDlg_h, `${CommonViewId.AgreementWebViewDlg}_h`)
class AgreementWebViewDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(AgreementWebViewDlg_h, uiBase.addComponent(AgreementWebViewDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgreementWebViewDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<AgreementWebViewDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(AgreementWebViewDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(AgreementWebViewDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(AgreementWebViewDlg_h).beforeUnload();
    }

    async onShowAnimation(uiBase: we.ui.UIBase): Promise<void> {
        uiBase.uiRoot.active = true;
        uiBase.uiRoot.opacity = 255;
    }

    async onHideAnimation(uiBase: we.ui.UIBase): Promise<void> {
        uiBase.uiRoot.active = false;
    }
}
