import { CommonViewId } from '../CommonViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('DeviceLimitDlgView_v', we.bundles.common)
class DeviceLimitDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */
    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('DeviceLimitDlg_v', we.bundles.common)
export class DeviceLimitDlg_v extends we.ui.DlgSystem<DeviceLimitDlgView_v> {
    /** 注册UI事件 */
    public async registerUIEvent() {}

    /** 显示窗口 */
    public async onShow(showData?: any) {}

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(DeviceLimitDlg_v, `${CommonViewId.DeviceLimitDlg}_v`)
class DeviceLimitDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Top;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(DeviceLimitDlg_v, uiBase.addComponent(DeviceLimitDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DeviceLimitDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<DeviceLimitDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(DeviceLimitDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DeviceLimitDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(DeviceLimitDlg_v).beforeUnload();
    }
}
