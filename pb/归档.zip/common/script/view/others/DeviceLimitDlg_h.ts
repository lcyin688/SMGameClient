import { CommonViewId } from '../CommonViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('DeviceLimitDlgView_h', we.bundles.common)
class DeviceLimitDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */
    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('DeviceLimitDlg_h', we.bundles.common)
export class DeviceLimitDlg_h extends we.ui.DlgSystem<DeviceLimitDlgView_h> {
    /** 注册UI事件 */
    public async registerUIEvent() {}

    /** 显示窗口 */
    public async onShow(showData?: any) {}

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(DeviceLimitDlg_h, `${CommonViewId.DeviceLimitDlg}_h`)
class DeviceLimitDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Top;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(DeviceLimitDlg_h, uiBase.addComponent(DeviceLimitDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DeviceLimitDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<DeviceLimitDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(DeviceLimitDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(DeviceLimitDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(DeviceLimitDlg_h).beforeUnload();
    }
}
