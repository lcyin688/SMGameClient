import { CommonViewId } from '../CommonViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('WebViewBrowserDlgView_v', we.bundles.common)
class WebViewBrowserDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnExit: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoBack: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnGoForward: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_btnReload: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RC_loading: cc.Node = null;

    @we.ui.ccBind(cc.WebView)
    public RC_webView: any = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('WebViewBrowserDlg_v', we.bundles.common)
export class WebViewBrowserDlg_v extends we.ui.DlgSystem<WebViewBrowserDlgView_v> {
    private url: string = '';
    private loadTimer: any = null;
    private curGameOrientation: we.core.ScreenOrientation;

    /** 注册UI事件 */
    public async registerUIEvent() {
        we.core.audioMgr.setResumeEnabled(false);
        we.core.audioMgr.pauseAll();
    }

    protected destroy(): void {
        we.core.audioMgr.setResumeEnabled(true);
        we.core.audioMgr.resumeAll();
        this.clearLoadTimer();
    }

    /** 显示窗口 */
    public async onShow(url: string, orientation: we.core.ScreenOrientation) {
        this.curGameOrientation = we.core.projectConfig.orientation;

        we.core.nativeUtil.setScreenOrientation(orientation);

        this.tween(this.view.RC_loading).repeatForever(cc.rotateBy(1, 360)).start();

        this.view.RC_webView.node.on('loading', this.onWebLoading, this);
        this.view.RC_webView.node.on('loaded', this.onWebLoaded, this);
        this.view.RC_webView.node.on('error', this.onWebError, this);
        this.view.RC_webView.node.opacity = 0;

        this.view.cc_onBtnClick(this.view.RC_btnExit, we.core.Func.create(this.onTouchExit, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnGoBack, we.core.Func.create(this.onTouchGoBack, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnGoForward, we.core.Func.create(this.onTouchGoForward, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RC_btnReload, we.core.Func.create(this.onTouchReload, this)).setSleepTime(2);

        this.url = url;
        this.loadUrl();
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private loadUrl() {
        if (!this.url) {
            return;
        }

        this.view.RC_webView.url = this.url;
        this.clearLoadTimer();
        this.loadTimer = setTimeout(this.onLoadTimeout.bind(this), 10 * 1000);
    }

    private clearLoadTimer() {
        if (this.loadTimer != null) {
            clearTimeout(this.loadTimer);
            this.loadTimer = null;
        }
    }

    private onWebLoading(event: cc.Event) {
        we.log(`WebViewBrowser onWebLoading, url: ${this.view.RC_webView.url}`);

        this.setBtnInteractable(this.view.RC_btnGoBack, this.view.RC_webView.canGoBack());
        this.setBtnInteractable(this.view.RC_btnGoForward, this.view.RC_webView.canGoForward());
        this.setBtnInteractable(this.view.RC_btnReload, false);
    }

    private onWebLoaded(event: cc.Event) {
        we.log(`WebViewBrowser onWebLoaded, url: ${this.view.RC_webView.url}`);

        this.setBtnInteractable(this.view.RC_btnGoBack, this.view.RC_webView.canGoBack());
        this.setBtnInteractable(this.view.RC_btnGoForward, this.view.RC_webView.canGoForward());
        this.setBtnInteractable(this.view.RC_btnReload, true);

        this.view.RC_loading.active = false;
        this.view.RC_webView.node.opacity = 255;
        this.clearLoadTimer();
    }

    private onWebError(event: cc.Event) {
        we.log(`WebViewBrowser onWebError, url: ${this.view.RC_webView.url}`);

        this.clearLoadTimer();

        this.setBtnInteractable(this.view.RC_btnGoBack, this.view.RC_webView.canGoBack());
        this.setBtnInteractable(this.view.RC_btnGoForward, this.view.RC_webView.canGoForward());
        this.setBtnInteractable(this.view.RC_btnReload, true);
    }

    private onLoadTimeout() {
        we.log(`WebViewBrowser onLoadTimeout`);

        this.clearLoadTimer();
    }

    private onTouchExit(event: cc.Event) {
        we.currentUI.close(CommonViewId.WebViewBrowserDlg, true);
    }

    private onTouchGoBack(event: cc.Event) {
        if (this.view.RC_webView.canGoBack()) {
            this.view.RC_webView.goBack();
        }
    }

    private onTouchGoForward(event: cc.Event) {
        if (this.view.RC_webView.canGoForward()) {
            this.view.RC_webView.goForward();
        }
    }

    private onTouchReload(event: cc.Event) {
        if (cc.sys.isNative) {
            this.view.RC_webView.reload();
        } else {
            this.loadUrl();
        }
    }

    private setBtnInteractable(node: cc.Node, interactable: boolean) {
        let btn = node.getComponent(cc.Button);
        btn.interactable = interactable;
        let icon = node.getChildByName('icon');
        icon.color = interactable ? new cc.Color().fromHEX('#FFFFFF') : new cc.Color().fromHEX('#7F7F7F');
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(WebViewBrowserDlg_v, `${CommonViewId.WebViewBrowserDlg}_v`)
class WebViewBrowserDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Top;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(WebViewBrowserDlg_v, uiBase.addComponent(WebViewBrowserDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WebViewBrowserDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<WebViewBrowserDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(WebViewBrowserDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(WebViewBrowserDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(WebViewBrowserDlg_v).beforeUnload();
    }
}
