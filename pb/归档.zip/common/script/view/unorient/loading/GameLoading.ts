import { CommonEvent } from '../../../config/CommonEvent';

const { ccclass, property } = cc._decorator;

@ccclass
export default class GameLoading extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    private RC_btnClose: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */

    @property(cc.Prefab)
    private loadingProgress: cc.Prefab = null;

    private completeCb: Function = null;

    protected onLoad() {
        // 动态设置竖版大背景
        if (cc.sys.isBrowser && !cc.sys.isMobile && we.core.flavor.getSkinOrientation() === we.core.ScreenOrientation.PORTRAIT) {
            // 是否使用场景遮罩
            we.ui.UILayer.uiRoot.addComponentUnique(cc.Mask).enabled = true;
            // 动态设置竖版大背景
            let bgCom = we.currentScene.getComponent(we.core.SceneBigBackground);
            if (!bgCom) {
                we.currentScene.addComponentAsync(we.core.SceneBigBackground, we.launcher.res.ctryres.bigBg);
            }
        }

        this.node.opacity = 255;
        this.RC_btnClose.active = false;

        this.RC_btnClose.on('click', this.onTouchClose, this);

        cc.director.on(we.core.EventName.HOT_UPDATE_START, this.onHotStart, this);
        cc.director.on(we.core.EventName.HOT_UPDATE_END, this.onHotEnd, this);
        cc.director.on(CommonEvent.HIDE_GAME_LOADING, this.onHide, this);
    }

    protected start(): void {
        we.core.nativeUtil.setScreenOrientation(we.core.flavor.getSkinOrientation());
    }

    protected onDestroy() {
        cc.director.off(CommonEvent.HIDE_GAME_LOADING, this.onHide, this);
        cc.director.off(we.core.EventName.HOT_UPDATE_START, this.onHotStart, this);
        cc.director.off(we.core.EventName.HOT_UPDATE_END, this.onHotEnd, this);
    }

    private onTouchClose() {
        cc.director.emit(we.core.EventName.HOT_UPDATE_STOP);
    }

    private onHotStart() {
        this.RC_btnClose.active = true;
    }

    private onHotEnd() {
        this.RC_btnClose.active = false;
    }

    private onHide() {
        this.node.destroy();
    }

    public init(gameId: number, completeCallback: Function = null): void {
        if (gameId < 0) {
            return;
        }
        this.completeCb = completeCallback;
        this.setStyle();
    }

    private setStyle() {
        // 设置进度条风格
        let loadingProgress = this.node.getChildByName('LoadingProgress');
        if (!cc.isValid(loadingProgress)) {
            loadingProgress = cc.instantiate(this.loadingProgress);
            loadingProgress.parent = this.node;
        }
        this.node.opacity = 255;
        typeof this.completeCb == 'function' && this.completeCb();
    }
}
