import GameManager from '../../../manager/GameManager';

const { ccclass, property } = cc._decorator;

/** 进度条类型 */
const enum ProgressType {
    /** 实际进度 */
    LOADING = 1,
    /** 虚拟进度 */
    VIRTUAL = 2,
}

@ccclass
export default class LoadingProgress extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    private RC_progressRoot: cc.Node = null;

    @we.ui.ccBind(cc.Sprite)
    private RC_spr_progress: cc.Sprite = null;

    @we.ui.ccBind(cc.Label)
    private RC_lab_progress: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    private RC_lab_status: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    private RC_lab_tips: cc.Label = null;

    /* =========================== AUTO CODE TOEND =========================== */

    // 进度条大于 50%
    @property(cc.Color)
    private afterFillCol: cc.Color = null;

    @property(cc.Color)
    private afterOutlineCol: cc.Color = null;

    private tipsTime: number;
    private tipsIndex: number;
    private tipsContent: string[];
    private startLoading: boolean;
    private percent: number;
    private setPercentStyle: boolean = false;

    /** 当前进度类型，默认为真实进度类型 */
    private progressType: ProgressType = ProgressType.LOADING;

    protected onLoad() {
        this.tipsTime = 0;
        this.tipsIndex = 0;
        this.tipsContent = [];
        this.startLoading = false;
        this.percent = 0;

        this.RC_spr_progress.fillRange = 0;

        this.initTipsContent();
        this.RC_lab_progress.node.active = false;

        cc.director.on(we.core.EventName.LOAD_STATUS, this.onLoadStatus, this);
        cc.director.on(we.core.EventName.LOAD_PROGRESS_ACTIVE, this.onLoadProgressActive, this);
        cc.director.on(we.core.EventName.LOAD_PROGRESS, this.onLoadProgress, this);
        cc.director.on(we.core.EventName.LOAD_VIRTUAL_PROGRESS_START, this.onVirtualProgressStart, this);
        cc.director.on(we.core.EventName.LOAD_VIRTUAL_PROGRESS_END, this.onVirtualProgressEnd, this);
    }

    protected onEnable(): void {
        let curGameInfo = GameManager.getCurGameInfo();
        if (curGameInfo.gameId <= we.GameId.LAUNCHER) {
            this.onLoadProgressActive(true);
        }
    }

    protected update(dt) {
        if (this.startLoading) {
            this.tipsTime += dt;
            if (this.tipsTime >= 2) {
                this.tipsTime = 0;
                this.showTips();
            }
        }
    }

    protected onDestroy() {
        cc.director.off(we.core.EventName.LOAD_STATUS, this.onLoadStatus, this);
        cc.director.off(we.core.EventName.LOAD_PROGRESS_ACTIVE, this.onLoadProgressActive, this);
        cc.director.off(we.core.EventName.LOAD_PROGRESS, this.onLoadProgress, this);
        cc.director.off(we.core.EventName.LOAD_VIRTUAL_PROGRESS_START, this.onVirtualProgressStart, this);
        cc.director.off(we.core.EventName.LOAD_VIRTUAL_PROGRESS_END, this.onVirtualProgressEnd, this);
    }

    private initTipsContent() {
        this.tipsTime = 0;
        this.tipsIndex = 0;
        this.tipsContent = [we.core.langMgr.getLangText(we.launcher.lang.TIPS_LOAD_1)];
    }

    private showTips() {
        if (this.tipsIndex >= this.tipsContent.length) {
            this.tipsIndex = 0;
        }

        let tips = this.tipsContent[this.tipsIndex];
        this.RC_lab_tips.string = tips;
        this.tipsIndex += 1;
    }

    private onLoadStatus(msg) {
        if (!(typeof msg == 'string')) {
            return;
        }

        we.core.utils.labelPointBounce(this.RC_lab_status, msg);
    }

    private onLoadProgressActive(active: boolean) {
        this.startLoading = active;
        this.RC_progressRoot.active = active;
        this.RC_lab_tips.node.active = active;
        this.percent = active ? this.percent : 0;
        this.RC_lab_status.node.active = active;

        if (active) {
            this.showTips();
            this.onVirtualProgressStart();
        } else {
            this.unscheduleAllCallbacks();
            this.percent = 0;
            this.setProgressUI();
        }
    }

    private onLoadProgress(msg) {
        if (!(msg && typeof msg.percent == 'number' && !isNaN(msg.percent))) {
            return;
        }

        if (msg.bundleName !== we.bundles.hall) {
            return;
        }

        let percent: number = msg.percent;
        if (percent < 0) {
            percent = 0;
        } else if (percent > 1) {
            percent = 1;
        }

        let loadType: number = msg.loadType;
        if (loadType == we.core.LoadType.PRELOAD) {
            percent = percent * 0.8;
        }

        if (percent <= this.percent) {
            return;
        } else {
            this.progressType = ProgressType.LOADING;
        }

        this.percent = percent;
        this.setProgressUI();
    }

    private onVirtualProgressStart(start: number = 0, end: number = 0.5, duration: number = 10): void {
        this.progressType = ProgressType.VIRTUAL;
        this.setVirtualProgress(start, end, duration);
    }

    private onVirtualProgressEnd(): void {
        this.unscheduleAllCallbacks();
    }

    private setPercent(fillColor: cc.Color, outlineColor: cc.Color): void {
        if (fillColor && outlineColor) {
            this.RC_lab_progress.node.color = fillColor;
            if (this.RC_lab_progress.node.getComponent(cc.LabelOutline)) {
                this.RC_lab_progress.node.getComponent(cc.LabelOutline).color = outlineColor;
            }
        }
    }

    /**
     * 设置虚拟进度条
     * @param start 0 < start < 0.98
     * @param end  <0.98
     * @param duration 持续时长 单位: s
     * @returns
     */
    private setVirtualProgress(start: number = 0, end: number = 0.5, duration: number = 10) {
        if (end < this.percent || start > end) {
            this.progressType = ProgressType.LOADING;
            return;
        } else {
            this.unscheduleAllCallbacks();
            this.progressType = ProgressType.VIRTUAL;
        }

        const loadDec = we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOCAL_ING);
        this.onLoadStatus(loadDec);

        if (this.percent != start) {
            start = this.percent;
        }

        if (!this.RC_progressRoot.active) {
            this.onLoadProgressActive(true);
        }

        start *= 1000;
        end *= 1000;

        const loopNum = Math.ceil(end - start);
        const interval = duration / loopNum;

        this.schedule(
            () => {
                if (this.progressType != ProgressType.VIRTUAL) {
                    this.progressType = ProgressType.LOADING;
                    this.unscheduleAllCallbacks();
                    return;
                } else {
                    start += 1;
                    if (start >= end) {
                        this.percent = end / 1000;
                        this.progressType = ProgressType.LOADING;
                        this.unscheduleAllCallbacks();
                    } else {
                        this.percent = start / 1000;
                    }

                    this.setProgressUI();
                }
            },
            interval,
            loopNum
        );
    }

    private setProgressUI(): void {
        this.RC_spr_progress.fillRange = this.percent;

        let progressValue = this.percent * 100;
        if (progressValue < 1) {
            progressValue = 1;
        }

        this.RC_lab_progress.node.active = progressValue > 0;
        this.RC_lab_progress.string = progressValue.toFixed(2) + '%';

        // 设置进度条百分比大于50%时，加载百分比风格
        if (this.percent >= 0.5 && !this.setPercentStyle) {
            this.setPercentStyle = true;

            if (this.afterFillCol && this.afterOutlineCol) {
                this.setPercent(this.afterFillCol, this.afterOutlineCol);
            }
        }
    }
}
