import ApiManager from '../../api/ApiManager';
import { CommonEvent } from '../../config/CommonEvent';
import { CommonType } from '../../config/CommonType';
import { AccountVerifySwitch, AccountVerifyType, JumpCmd } from '../../const/CommonConst';
import { CommonLanguage } from '../../const/CommonLanguage';
import ActivityMgr from '../../manager/ActivityMgr';
import DownloadGuideMgr from '../../manager/DownloadGuideMgr';
import LoginManager from '../../manager/LoginManager';
import UserManager from '../../manager/UserManager';
import CommonUtils from '../../utils/CommonUtils';
import { CommonViewId } from '../CommonViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('PhoneBindHighDlgView_h', we.bundles.common)
class PhoneBindHighDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_code: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_email: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_phone: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_pwd: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_pwdConfirm: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_awardLab: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_coolingTime: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_countId: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_currencySymbol: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phoneCode: cc.Label = null;

    @we.ui.ccBind(we.ui.WESkeleton)
    public RC_skeleton_content: we.ui.WESkeleton = null;

    @we.ui.ccBind(cc.Node)
    public RCN_accountType: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_bound: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnBind: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnContinue: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnCooling: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnGetCode: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_code: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_codeSelect: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_codeTips: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_email: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_password: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_password_confirm: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_points: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_pwd_status: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_pwdConfirmStatus: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

enum ACCOUNT_TYPE {
    /** 手机 */
    PHONE = 0,
    /** 邮箱 */
    EMAIL = 1,
}

enum SHOW_TYPE {
    NONE = -1,
    BIND = 0,
    REGISTER = 1,
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('PhoneBindHighDlg_h', we.bundles.common)
export class PhoneBindHighDlg_h extends we.ui.DlgSystem<PhoneBindHighDlgView_h> {
    private coolTime: number = 60;
    private isCooling: boolean = false;
    private curType = SHOW_TYPE.NONE;

    private phoneEnabled: boolean = false;
    private emailEnabled: boolean = false;
    private isVerifyPhone: boolean = false;
    private isVerifyEmail: boolean = false;

    /** 当前选择验证获取方式 */
    private curCodeType: AccountVerifyType = AccountVerifyType.SMS;
    private bindPhoneVerifyType: number[] = [];
    private errorNum: number = 0;
    private accountType: ACCOUNT_TYPE = ACCOUNT_TYPE.PHONE;
    private phoneVerifyCode: string = '';
    private emailVerifyCode: string = '';

    /** 注册UI事件 */
    public async registerUIEvent() {
        cc.director.on(we.core.EventName.GAME_SHOW, this.onEventGameShow, this);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_btnBind, we.core.Func.create(this.onClickBind, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_btnContinue, we.core.Func.create(this.onClickContinue, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_btnGetCode, we.core.Func.create(this.onClickGetCode, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_codeTips, we.core.Func.create(this.onClickCodeTips, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_pwd_status, we.core.Func.create(this.onChangePwdShow, this));
        this.view.cc_onBtnClick(this.view.RCN_pwdConfirmStatus, we.core.Func.create(this.onChangePwdConfirmShow, this));
        // 单选按钮事件
        this.view.RCN_accountType.addComponentUnique(we.ui.WEToggleGroup)
            .setGroupMode(we.ui.ToggleGroupMode.SingleOne)
            .setToggleStatus(this.accountType, true)
            .onListener(
                we.core.Func.create((_: number, isChecked: boolean, index: number) => {
                    if (isChecked) {
                        this.accountType = index;
                        this.setUI(this.accountType);
                        this.inputShow();
                        this.onEventGameShow();
                    }
                }, this)
            );
        // phoneEditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidBegan', we.core.Func.create(this.onPhoneInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'textChanged', we.core.Func.create(this.onPhoneInputChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidEnded', we.core.Func.create(this.onPhoneInputEnd, this));
        // emailEditbox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_email.node, 'editingDidBegan', we.core.Func.create(this.onEmailInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_email.node, 'editingDidEnded', we.core.Func.create(this.onEmailInputEnd, this));
        // codeEditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_code.node, 'editingDidBegan', we.core.Func.create(this.onCodeInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_code.node, 'editingDidEnded', we.core.Func.create(this.onCodeInputEnd, this));
        // pwdEditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwd.node, 'editingDidBegan', we.core.Func.create(this.onPwdInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwd.node, 'editingDidEnded', we.core.Func.create(this.onPwdInputEnd, this));
        // pwdConfirmEditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwdConfirm.node, 'editingDidBegan', we.core.Func.create(this.onConfirmPwdInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwdConfirm.node, 'editingDidEnded', we.core.Func.create(this.onConfirmPwdInputend, this));
    }

    /**
     * 显示窗口
     * @param type 0-绑定 1-注册
     * @param account 预填账号
     */
    public async onShow(type = SHOW_TYPE.BIND, account?: string, isEmail?: boolean) {
        this.initUI();
        this.init(type, account, isEmail);
    }

    /** 隐藏窗口 */
    public async destroy() {
        cc.director.off(we.core.EventName.GAME_SHOW, this.onEventGameShow, this);
    }

    public beforeUnload() {}

    protected update(): void {
        if (this.isCooling) {
            this.coolTime -= this.deltaTime;
            if (this.coolTime > 0) {
                this.view.RC_lab_coolingTime.string = `(${Math.ceil(this.coolTime)})`;
            } else {
                this.isCooling = false;
                this.view.RCN_btnCooling.active = false;
                this.view.RCN_btnGetCode.active = true;
            }
        }
    }

    private initUI(): void {
        this.view.RCN_btnGetCode.active = true;
        this.view.RCN_btnCooling.active = false;

        let award = we.core.projectConfig.settingsConfig?.phoneBindReward[0] || 0;
        if (award > 0) {
            this.view.RC_lab_awardLab.string = CommonUtils.formatAmountCurrency(award, false);
            this.view.RC_lab_awardLab.node.active = true;
        } else {
            this.view.RC_lab_awardLab.node.active = false;
        }

        this.view.RC_lab_currencySymbol && (this.view.RC_lab_currencySymbol.string = we.core.flavor.getCurrencySymbol());

        this.view.RC_lab_phoneCode.string = `+${we.core.flavor.getCountryNum()} `;
        this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER1_TIPS);
        this.view.RC_edit_email.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.BIND_EMAIL_4);
        this.view.RC_edit_code.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER2_TIPS);
        this.view.RC_edit_pwd.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
        this.view.RC_edit_pwdConfirm.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
    }

    private inputShow() {
        this.view.RCN_bound.active = this.accountType === ACCOUNT_TYPE.PHONE ? UserManager.userInfo.phone.length > 0 : UserManager.userInfo.emailAccount.length > 0;
        if (this.view.RCN_bound.active) {
            this.view.RCN_btnBind.active = false;
            this.view.RCN_password.active = false;
            this.view.RCN_password_confirm.active = false;
            this.view.RCN_btnContinue.active = false;
            this.view.RCN_code.active = false;
            this.view.RCN_codeSelect.active = false;
            return;
        }

        const status = this.accountType === ACCOUNT_TYPE.PHONE ? this.isVerifyPhone && this.view.RC_edit_phone.enabled : this.isVerifyEmail && this.view.RC_edit_email.enabled;
        this.view.RCN_btnBind.active = !status;
        this.view.RCN_password.active = !status;
        this.view.RCN_password_confirm.active = !status;
        this.view.RCN_btnContinue.active = status;
        this.view.RCN_code.active = status;
        this.view.RCN_codeSelect.active = status;
    }

    /**
     * 初始化绑定界面
     * @param type 0-绑定 1-注册
     * @param account
     */
    public init(type = SHOW_TYPE.BIND, account?: string, isEmail?: boolean): void {
        this.curType = type;
        if (type === SHOW_TYPE.BIND) {
            this.phoneEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(AccountVerifySwitch.Phone);
            this.emailEnabled = we.core.projectConfig.settingsConfig?.funcSwitch?.upNormalUserSwitch?.includes(AccountVerifySwitch.Email);
            this.isVerifyPhone = we.core.projectConfig.settingsConfig?.funcSwitch?.needPhoneVerify;
            this.isVerifyEmail = we.core.projectConfig.settingsConfig?.funcSwitch?.needEmailVerify;
            this.bindPhoneVerifyType = we.core.projectConfig.settingsConfig?.funcSwitch?.bindPhoneVerifyType || [];
            this.view.RC_lab_countId.string = `ID: ${UserManager.userInfo.userId}`;
        } else {
            this.phoneEnabled = we.core.projectConfig.commonConfig?.upNormalUserSwitch?.includes(AccountVerifySwitch.Phone);
            this.emailEnabled = we.core.projectConfig.commonConfig?.upNormalUserSwitch?.includes(AccountVerifySwitch.Email);
            this.isVerifyPhone = we.core.projectConfig.commonConfig?.needPhoneVerify;
            this.isVerifyEmail = we.core.projectConfig.commonConfig?.needEmailVerify;
            this.bindPhoneVerifyType = we.core.projectConfig.commonConfig?.bindPhoneVerifyType || [];
            this.view.RC_lab_countId.node.active = false;
        }

        const phoneBound = UserManager.userInfo.phone.length > 0;
        const emailBound = UserManager.userInfo.emailAccount.length > 0;
        if (this.emailEnabled && !emailBound && (isEmail || CommonUtils.isEmail(account) || phoneBound)) {
            this.accountType = ACCOUNT_TYPE.EMAIL;
            CommonUtils.isEmail(account) && (this.view.RC_edit_email.string = account);
        } else if (this.phoneEnabled) {
            this.accountType = ACCOUNT_TYPE.PHONE;
            CommonUtils.isPhoneNumber(account) && (this.view.RC_edit_phone.string = account);
        } else {
            this.accountType = ACCOUNT_TYPE.EMAIL;
        }
        if (phoneBound) {
            this.view.RC_edit_phone.string = UserManager.userInfo.phone;
            this.view.RC_edit_phone.enabled = false;
        } else if (emailBound) {
            this.view.RC_edit_email.string = UserManager.userInfo.emailAccount;
            this.view.RC_edit_email.enabled = false;
        }
        this.view.RCN_accountType.active = this.phoneEnabled && this.emailEnabled;
        this.view.RCN_accountType.getComponent(we.ui.WEToggleGroup)?.setToggleStatus(this.accountType, true);
        this.setUI(this.accountType);

        // 如果启用密码隐藏功能，则根据设置状态显示/隐藏密码
        if (this.view.RCN_pwd_status.active) {
            let children = this.view.RCN_pwd_status.children || [];
            if (children.length == 2) {
                this.view.RC_edit_pwd.inputFlag = children[0].active ? cc.EditBox.InputFlag.DEFAULT : cc.EditBox.InputFlag.PASSWORD;
            }
        }

        if (this.view.RCN_pwdConfirmStatus.active) {
            let children = this.view.RCN_pwdConfirmStatus.children || [];
            if (children.length == 2) {
                this.view.RC_edit_pwdConfirm.inputFlag = children[0].active ? cc.EditBox.InputFlag.DEFAULT : cc.EditBox.InputFlag.PASSWORD;
            }
        }

        this.inputShow();

        if (this.isVerifyPhone) {
            // 默认使用第一个方式获取验证码
            this.curCodeType = UserManager.bindPhone.type ?? this.bindPhoneVerifyType[0] ?? AccountVerifyType.SMS;
        }

        this.onEventGameShow();
        // 设置获取验证码方式排序
        this.setCodeGetType();

        this.show();
    }

    private onEventGameShow(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }
        if (this.curType == SHOW_TYPE.BIND) {
            const codeType = this.getCodeType();
            if (codeType >= 0) {
                const timestamp = UserManager.bindPhone.timestamps[codeType] || 0;
                const coolTime = 60 - (new Date().getTime() - timestamp) / 1000;
                this.setCoolTime(coolTime);
                if (this.accountType === ACCOUNT_TYPE.PHONE) {
                    // 回显手机号
                    const phone = UserManager.bindPhone.phones[codeType];
                    if (phone) {
                        this.view.RC_edit_phone.string = phone;
                    }
                }
            }
            this.accountType === ACCOUNT_TYPE.PHONE && (UserManager.bindPhone.type = codeType);
        } else {
            const coolTime = 60 - (new Date().getTime() - UserManager.getCodeTimestamp.phoneRegister) / 1000;
            this.setCoolTime(coolTime);
        }
    }

    private getAccount() {
        if (this.accountType === ACCOUNT_TYPE.PHONE && CommonUtils.isPhoneNumber(this.view.RC_edit_phone.string)) {
            return `+${we.core.flavor.getCountryNum()}${this.view.RC_edit_phone.string}`;
        }
        if (this.accountType === ACCOUNT_TYPE.EMAIL && CommonUtils.isEmail(this.view.RC_edit_email.string)) {
            return this.view.RC_edit_email.string;
        }
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_INVALIDPHONE));
    }

    private getCodeType() {
        return this.accountType === ACCOUNT_TYPE.PHONE ? this.curCodeType : we.common.AccountVerifyType.Email;
    }

    private onClickContinue() {
        const account = this.getAccount();
        if (!account) {
            return;
        }

        if (!CommonUtils.checkUserCode(this.view.RC_edit_code.string)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.COMMON_INVALID_CODE));
            return;
        }

        const sucCb = (data: ApiProto.PhoneVerifyResp | ApiProto.EmailVerifyResp) => {
            if (data.suc) {
                if (this.accountType === ACCOUNT_TYPE.PHONE) {
                    this.phoneVerifyCode = this.view.RC_edit_code.string;
                    this.view.RC_edit_phone.enabled = false;
                } else {
                    this.emailVerifyCode = this.view.RC_edit_code.string;
                    this.view.RC_edit_email.enabled = false;
                }
                this.view.RC_edit_code.string = '';
                this.inputShow();
            } else {
            }
        };

        const errCb = () => {
            this.errorNum += 1;
            if (this.errorNum > 3) {
                we.commonUI.showConfirm({
                    title: we.core.langMgr.getLangText(CommonLanguage.VERIFY_ERROR_2),
                    content: we.core.langMgr.getLangText(CommonLanguage.VERIFY_ERROR_1),
                    yesButtonName: we.core.langMgr.getLangText(we.launcher.lang.NEW_HALL_TOP_SERVICE),
                    yesHandler: we.core.Func.create(() => {
                        we.common.commonMgr.openCustomerDialog();
                    }, this),
                    noButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CANCEL),
                });
            }
        };

        if (this.accountType === ACCOUNT_TYPE.PHONE) {
            let param = {} as ApiProto.PhoneVerifyReq;
            param.phone = account;
            param.verifyCode = this.view.RC_edit_code.string;
            ApiManager.checkVerifyCode(param, sucCb, errCb);
        } else {
            let param = {} as ApiProto.EmailVerifyReq;
            param.email = account;
            param.verifyCode = this.view.RC_edit_code.string;
            ApiManager.verifyEmailCode(param, sucCb, errCb);
        }
    }

    private onClickBind(): void {
        const account = this.getAccount();
        if (!account) {
            return;
        }
        if (this.accountType === ACCOUNT_TYPE.PHONE ? this.isVerifyPhone && !CommonUtils.checkUserCode(this.phoneVerifyCode) : this.isVerifyEmail && !CommonUtils.checkUserCode(this.emailVerifyCode)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.COMMON_INVALID_CODE));
            return;
        }
        if (!(CommonUtils.checkUserPassword(this.view.RC_edit_pwd.string) && CommonUtils.checkUserPassword(this.view.RC_edit_pwdConfirm.string))) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_WRONGPS2));
            return;
        }
        if (this.view.RC_edit_pwd.string != this.view.RC_edit_pwdConfirm.string) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_WRONGPS));
            return;
        }

        const sucCb = (resulted: ApiProto.LoginResp) => {
            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }

            let accountInfo = {} as CommonType.IAccountInfo;
            accountInfo.userId = UserManager.userInfo.userId;
            if (this.accountType === ACCOUNT_TYPE.PHONE) {
                accountInfo.phoneNum = this.view.RC_edit_phone.string;
                accountInfo.email = LoginManager.getLastAccount()?.email;
            } else {
                accountInfo.phoneNum = LoginManager.getLastAccount()?.phoneNum;
                accountInfo.email = this.view.RC_edit_email.string;
            }
            accountInfo.password = this.view.RC_edit_pwd.string;
            LoginManager.saveAccountToLocal(accountInfo);

            if (this.curType == SHOW_TYPE.REGISTER) {
                UserManager.isFirstRegister = true;
                this.closeView();
            } else {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.ACCOUNT_BINDING_TIPS));
                UserManager.refreshUserInfo();
                cc.director.emit(CommonEvent.HIDE_BIND_ENTRY);
                if (DownloadGuideMgr.forceGuideConf?.forceLeadSwitch) {
                    cc.director.emit(we.common.EventName.OPEN_DOWNLOAD_USER_INFO_GUIDE);
                } else {
                    let param: Record<string, string> = {
                        pwd: this.view.RC_edit_pwd.string,
                    };
                    if (this.accountType === ACCOUNT_TYPE.PHONE) {
                        param.phone = account;
                    } else {
                        param.email = account;
                    }
                    cc.director.emit(CommonEvent.JUMP_ACTION_CMD, JumpCmd.Screen_Shot, param, true);

                    if (resulted?.rewardAmount > 0) {
                        if (ActivityMgr.safeBindConfig) {
                            ActivityMgr.safeBindConfig.phoneBindReceiveStatus = true;
                        }
                        let awardMap = [{ id: UserManager.PropId.CoinId, num: resulted?.rewardAmount }];
                        cc.director.emit(CommonEvent.AWARD_RECEIVE_SUC_DLG, awardMap);
                    }
                }
                this.closeView();
            }
        };

        const errCb = () => {
            cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
        };

        if (this.accountType === ACCOUNT_TYPE.PHONE) {
            let data: ApiProto.PhonRegisterReq = {} as ApiProto.PhonRegisterReq;
            data.phone = account;
            data.passwordMd5 = this.view.RC_edit_pwd.string;
            data.verifyCode = this.phoneVerifyCode;
            data.autoReceiveReward = this.curType == 0;
            LoginManager.phoneRegister(data, sucCb, errCb);
        } else {
            let data: ApiProto.EmailRegisterReq = {} as ApiProto.EmailRegisterReq;
            data.email = account;
            data.passwordMd5 = this.view.RC_edit_pwd.string;
            data.verifyCode = this.emailVerifyCode;
            data.autoReceiveReward = this.curType == 0;
            LoginManager.emailRegister(data, sucCb, errCb);
        }

        cc.director.emit(we.core.EventName.LOGIN_VIEW_HIDE);
    }

    private onClickGetCode(): void {
        if (this.isCooling) {
            return;
        }

        const account = this.getAccount();
        if (!account) {
            return;
        }

        const codeType = this.getCodeType();
        const sucCb = () => {
            UserManager.getCodeTimestamp.phoneRegister = new Date().getTime();
            UserManager.bindPhone.timestamps[codeType] = new Date().getTime();
            this.accountType === ACCOUNT_TYPE.PHONE && (UserManager.bindPhone.phones[codeType] = this.view.RC_edit_phone.string);
            let langKey = CommonLanguage.LOGIN_FORGETFRAME_VERCODE_SUCCESS;
            switch (codeType) {
                case AccountVerifyType.SMS:
                    langKey = CommonLanguage.VER_TIP_CHECK_TEXT;
                    break;
                case AccountVerifyType.Voice:
                    langKey = CommonLanguage.VER_TIP_CHECK_VOICE;
                    break;
                case AccountVerifyType.WhatsApp:
                    langKey = CommonLanguage.VER_TIP_CHECK_WHATSAPP;
                    break;
                default:
                    break;
            }
            we.commonUI.showToast(we.core.langMgr.getLangText(langKey));

            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }
            this.setCoolTime(60);
        };

        if (this.accountType === ACCOUNT_TYPE.PHONE) {
            let param = {} as ApiProto.VerifyCodeReq;
            param.phone = account;
            param.codeType = 0;
            param.verifyType = codeType;
            ApiManager.getNewPhoneCode(param, sucCb, null);
        } else {
            let param = {} as ApiProto.VerifyEmailCodeReq;
            param.email = account;
            param.codeType = 0;
            param.verifyType = codeType;
            ApiManager.getEmailCode(param, sucCb, null);
        }
    }

    private onClickCodeTips(): void {
        we.common.commonMgr.openCustomerDialog();
    }

    private onChangePwdShow(): void {
        this.view.RC_edit_pwd.inputFlag = this.view.RC_edit_pwd.inputFlag == cc.EditBox.InputFlag.DEFAULT ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
        let children = this.view.RCN_pwd_status.children || [];
        if (children.length == 2) {
            children[0].active = this.view.RC_edit_pwd.inputFlag == cc.EditBox.InputFlag.DEFAULT;
            children[1].active = this.view.RC_edit_pwd.inputFlag == cc.EditBox.InputFlag.PASSWORD;
        }
    }

    private onChangePwdConfirmShow(): void {
        this.view.RC_edit_pwdConfirm.inputFlag = this.view.RC_edit_pwdConfirm.inputFlag == cc.EditBox.InputFlag.DEFAULT ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
        let children = this.view.RCN_pwdConfirmStatus.children || [];
        if (children.length == 2) {
            children[0].active = this.view.RC_edit_pwdConfirm.inputFlag == cc.EditBox.InputFlag.DEFAULT;
            children[1].active = this.view.RC_edit_pwdConfirm.inputFlag == cc.EditBox.InputFlag.PASSWORD;
        }
    }

    private onPhoneInputStart(): void {
        this.view.RC_edit_phone.placeholderLabel.string = ``;
    }

    private onPhoneInputChanged(value: string, editBox: cc.EditBox): void {
        let numArr = [];
        for (let i = 0; i <= 9; i++) {
            numArr.push('' + i);
        }
        let values = value.split('');

        let newValues = values.map((item) => {
            let idx = numArr.includes(item);
            if (idx) {
                return item;
            } else {
                return '';
            }
        });

        let val = newValues.join('');
        editBox.string = val;
        // @ts-ignore
        if (editBox && editBox._impl && editBox._impl._elem) {
            // @ts-ignore
            editBox._impl._elem.value = val;
        }
    }

    private onPhoneInputEnd(): void {
        if (this.view.RC_edit_phone.string == '') {
            this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER1_TIPS);
        }
    }

    private onEmailInputStart(): void {
        this.view.RC_edit_email.placeholderLabel.string = ``;
    }

    private onEmailInputEnd(): void {
        if (this.view.RC_edit_email.string == '') {
            this.view.RC_edit_email.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.BIND_EMAIL_4);
        }
    }

    private onCodeInputStart(): void {
        this.view.RC_edit_code.placeholderLabel.string = ``;
    }

    private onCodeInputEnd(): void {
        if (this.view.RC_edit_code.string == '') {
            this.view.RC_edit_code.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER2_TIPS);
        }
    }

    private onPwdInputStart(): void {
        this.view.RC_edit_pwd.placeholderLabel.string = ``;
    }

    private onPwdInputEnd(): void {
        if (this.view.RC_edit_pwd.string == '') {
            this.view.RC_edit_pwd.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
        }
    }

    private onConfirmPwdInputStart() {
        this.view.RC_edit_pwdConfirm.placeholderLabel.string = ``;
    }

    private onConfirmPwdInputend() {
        if (this.view.RC_edit_pwdConfirm.string == '') {
            this.view.RC_edit_pwdConfirm.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
        }
    }

    private onClickCodeType(event: cc.Event): void {
        if (!this.view.RCN_code.active) {
            return;
        }

        let node: cc.Node = event.target;
        this.curCodeType = parseInt(node.name);
        this.view.RCN_codeSelect.children.forEach((item) => {
            const i = item === node ? 0 : 1;
            item.getChildByName('page')?.getComponent(we.ui.WESwitchPage)?.setEventIndex(null, i);
            item.getChildByName('icon')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);
            item.getChildByName('desc')?.getComponent(we.ui.WENodeColorIndex)?.setIndex(i);
            item.getChildByName('dot')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);
        });
        // 绑定手机时允许切换验证方式
        this.isCooling = false;
        this.onEventGameShow();
    }

    private setCoolTime(time: number): void {
        this.coolTime = time;
        this.view.RC_lab_coolingTime.string = `(${this.coolTime})`;
        this.view.RCN_btnGetCode.active = time <= 0;
        this.view.RCN_btnCooling.active = time > 0;
        this.isCooling = time > 0;
    }

    private setUI(type: ACCOUNT_TYPE): void {
        this.view.RCN_phone.active = type === ACCOUNT_TYPE.PHONE;
        this.view.RCN_email.active = type === ACCOUNT_TYPE.EMAIL;
    }

    // 显示弹框
    private show(): void {
        const sk = this.view.RC_skeleton_content;
        sk.node.active = true;

        const points = [...this.view.RCN_points.children];
        points?.forEach((point) => {
            const offset = point.getChildByName('offset');
            if (offset) {
                sk.addMount(point.name, point, { x: offset.position.x, y: offset.position.y });
            }
        });

        const skeletonComp = sk.getComponent(sp.Skeleton);
        const animations = skeletonComp?.skeletonData.getRuntimeData().animations;
        const animationList: string[] = animations.map((anim) => {
            return anim.name;
        });
        this.playAnimations(sk, animationList, 0);
    }

    private playAnimations(sk: we.ui.WESkeleton, animationList: string[], index: number): void {
        if (!sk || !Array.isArray(animationList) || animationList.length === 0 || index < 0 || index >= animationList.length) {
            return;
        }

        const currentAnimation = animationList[index];

        if (index === animationList.length - 1) {
            sk.playLoop(currentAnimation);
        } else {
            sk.playOnce(currentAnimation, {
                onComplete: () => {
                    this.playAnimations(sk, animationList, index + 1);
                },
            });
        }
    }

    private setCodeGetType(): void {
        if (!this.isVerifyPhone) {
            return;
        }

        let children = this.view.RCN_codeSelect.children;
        for (let i = 0; i < children.length; i++) {
            const element = children[i];
            let code = parseInt(element.name);
            let index = this.bindPhoneVerifyType.indexOf(code);
            element.active = index > -1;
            if (index > -1) {
                this.view.cc_onBtnClick(element, we.core.Func.create(this.onClickCodeType, this));
                element.zIndex = index;

                const i = this.curCodeType === code ? 0 : 1;
                element.getChildByName('page')?.getComponent(we.ui.WESwitchPage)?.setEventIndex(null, i);
                element.getChildByName('icon')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);
                element.getChildByName('desc')?.getComponent(we.ui.WENodeColorIndex)?.setIndex(i);
                element.getChildByName('dot')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);

                const tips = element.getChildByName('tips');
                if (tips) {
                    if (this.curType === SHOW_TYPE.BIND) {
                        tips.active = we.core.projectConfig.settingsConfig?.funcSwitch?.bindPhoneRecommendType?.includes(code);
                    } else {
                        tips.active = we.core.projectConfig.commonConfig?.bindPhoneRecommendType?.includes(code);
                    }
                }
            }
        }
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(PhoneBindHighDlg_h, `${CommonViewId.PhoneBindHighDlg}_h`)
class PhoneBindHighDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
        uiBase.uiConfig.useTween = false;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(PhoneBindHighDlg_h, uiBase.addComponent(PhoneBindHighDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhoneBindHighDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<PhoneBindHighDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(PhoneBindHighDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhoneBindHighDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(PhoneBindHighDlg_h).beforeUnload();
    }
}
