import ApiManager from '../../api/ApiManager';
import { AccountVerifySwitch, AccountVerifyType } from '../../const/CommonConst';
import { CommonLanguage } from '../../const/CommonLanguage';
import LoginManager from '../../manager/LoginManager';
import UserManager from '../../manager/UserManager';
import CommonUtils from '../../utils/CommonUtils';
import { CommonViewId } from '../CommonViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('PhonePasswordForgetDlgView_v', we.bundles.common)
class PhonePasswordForgetDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_code: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_email: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_phone: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_pwd: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_pwdConfirm: cc.EditBox = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_coolingTime: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phoneCode: cc.Label = null;

    @we.ui.ccBind(cc.Label)
    public RC_lab_phoneNum: cc.Label = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_accountType: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnChange: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnCooling: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnGetCode: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_codeSelect: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_codeTips: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_email: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phone: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phoneInput: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_pwdConfirmStatus: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_pwdStatus: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

enum ACCOUNT_TYPE {
    /** 手机 */
    PHONE = 0,
    /** 邮箱 */
    EMAIL = 1,
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('PhonePasswordForgetDlg_v', we.bundles.common)
export class PhonePasswordForgetDlg_v extends we.ui.DlgSystem<PhonePasswordForgetDlgView_v> {
    private phoneCode: string = ``;
    private account: string = '';
    private phoneEditable = false;
    private coolTime: number = 60;
    private isCooling: boolean = false;
    /** 错误计数 */
    private errorNum = 0;
    private accountType: ACCOUNT_TYPE = ACCOUNT_TYPE.PHONE;
    /** 当前选择验证获取方式 */
    private curCodeType: AccountVerifyType = AccountVerifyType.SMS;

    /** 注册UI事件 */
    public async registerUIEvent() {
        cc.director.on(we.core.EventName.GAME_SHOW, this.onEventGameShow, this);
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_btnChange, we.core.Func.create(this.onClickConfirm, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_btnGetCode, we.core.Func.create(this.onClickGetCode, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_codeTips, we.core.Func.create(this.onClickCodeTips, this)).setSleepTime(1.5);
        this.view.cc_onBtnClick(this.view.RCN_pwdStatus, we.core.Func.create(this.onChangePwdShow, this));
        this.view.cc_onBtnClick(this.view.RCN_pwdConfirmStatus, we.core.Func.create(this.onChangePwdConfirmShow, this));
        // 单选按钮事件
        this.view.RCN_accountType.addComponentUnique(we.ui.WEToggleGroup)
            .setGroupMode(we.ui.ToggleGroupMode.SingleOne)
            .setToggleStatus(this.accountType, true)
            .onListener(
                we.core.Func.create((_: number, isChecked: boolean, index: number) => {
                    if (isChecked) {
                        this.accountType = index;
                        this.setUI(this.accountType);
                    }
                }, this)
            );
        // phoneEditbox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidBegan', we.core.Func.create(this.onPhoneInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_phone.node, 'editingDidEnded', we.core.Func.create(this.onPhoneInputEnd, this));
        // emailEditbox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_email.node, 'editingDidBegan', we.core.Func.create(this.onEmailInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_email.node, 'editingDidEnded', we.core.Func.create(this.onEmailInputEnd, this));
        // codeEditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_code.node, 'editingDidBegan', we.core.Func.create(this.onCodeInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_code.node, 'editingDidEnded', we.core.Func.create(this.onCodeInputEnd, this));
        // pwdEditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwd.node, 'editingDidBegan', we.core.Func.create(this.onPwdInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwd.node, 'editingDidEnded', we.core.Func.create(this.onPwdInputEnd, this));
        // pwdConfirmEditBox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwdConfirm.node, 'editingDidBegan', we.core.Func.create(this.onConfirmPwdInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_pwdConfirm.node, 'editingDidEnded', we.core.Func.create(this.onConfirmPwdInputend, this));
    }

    /** 显示窗口 */
    public async onShow(phoneCode: string, phoneNum: string, phoneInput = false) {
        this.view.RCN_btnGetCode.active = true;
        this.view.RCN_btnCooling.active = false;
        this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER1_TIPS);
        this.view.RC_edit_email.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.BIND_EMAIL_4);
        this.view.RC_edit_code.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER2_TIPS);
        this.view.RC_edit_pwd.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
        this.view.RC_edit_pwdConfirm.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
        this.init(phoneCode, phoneNum, phoneInput);
    }

    /** 隐藏窗口 */
    public async destroy() {
        cc.director.off(we.core.EventName.GAME_SHOW, this.onEventGameShow, this);
    }

    public beforeUnload() {}

    protected update(): void {
        if (this.isCooling) {
            this.coolTime -= this.deltaTime;
            if (this.coolTime > 0) {
                this.view.RC_lab_coolingTime.string = `(${Math.ceil(this.coolTime)})`;
            } else {
                this.isCooling = false;
                this.view.RCN_btnCooling.active = false;
                this.view.RCN_btnGetCode.active = true;
            }
        }
    }

    public init(phoneCode: string, account: string, editable = false): void {
        const phoneEnabled = we.core.projectConfig.commonConfig?.upNormalUserSwitch?.includes(AccountVerifySwitch.Phone);
        const emailEnabled = we.core.projectConfig.commonConfig?.upNormalUserSwitch?.includes(AccountVerifySwitch.Email);
        this.phoneEditable = true;
        this.view.RC_lab_phoneNum.node.active = false;
        this.view.RCN_phoneInput.active = true;
        this.view.RC_edit_email.enabled = true;
        if (phoneCode == null) {
            phoneCode = `+${we.core.flavor.getCountryNum()}`;
            if (emailEnabled) {
                this.accountType = ACCOUNT_TYPE.EMAIL;
                this.view.RC_edit_email.enabled = editable;
                this.view.RC_edit_email.string = account;
            } else {
                this.accountType = ACCOUNT_TYPE.PHONE;
                this.view.RC_edit_phone.string = '';
            }
        } else if (phoneEnabled) {
            this.accountType = ACCOUNT_TYPE.PHONE;
            this.phoneEditable = editable;
            this.view.RC_lab_phoneNum.node.active = !editable;
            this.view.RCN_phoneInput.active = editable;
            if (editable) {
                this.view.RC_edit_phone.string = account;
            } else {
                this.view.RC_lab_phoneNum.string = phoneCode + ` ` + account;
            }
        } else {
            this.accountType = ACCOUNT_TYPE.EMAIL;
            this.view.RC_edit_email.string = '';
        }
        this.view.RCN_accountType.active = phoneEnabled && emailEnabled;
        this.view.RCN_accountType.getComponent(we.ui.WEToggleGroup)?.setToggleStatus(this.accountType, true);
        this.setUI(this.accountType);

        this.phoneCode = phoneCode;
        this.view.RC_lab_phoneCode.string = phoneCode;
        this.account = account;

        const coolTime = 60 - (new Date().getTime() - UserManager.getCodeTimestamp.phoneResetPassword) / 1000;
        this.setCoolTime(coolTime);

        // 默认使用第一个方式获取验证码
        this.curCodeType = we.core.projectConfig.commonConfig?.passwordRecoveryVerifyType?.[0] ?? AccountVerifyType.SMS;

        // 设置获取验证码方式排序
        this.setCodeGetType();
    }

    private onEventGameShow(): void {
        if (!cc.isValid(this.view.uiRoot)) {
            return;
        }

        let coolTime = 60 - (new Date().getTime() - UserManager.getCodeTimestamp.phoneResetPassword) / 1000;
        this.setCoolTime(coolTime);
    }

    private getAccount() {
        return this.accountType === ACCOUNT_TYPE.PHONE ? `${this.phoneCode}${this.account}` : this.account;
    }

    private getCodeType() {
        return this.accountType === ACCOUNT_TYPE.PHONE ? this.curCodeType : we.common.AccountVerifyType.Email;
    }

    private onClickConfirm(): void {
        if (!CommonUtils.checkUserCode(this.view.RC_edit_code.string)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.COMMON_INVALID_CODE));
            return;
        }
        if (!(CommonUtils.checkUserPassword(this.view.RC_edit_pwd.string) && CommonUtils.checkUserPassword(this.view.RC_edit_pwdConfirm.string))) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_WRONGPS2));
            return;
        }
        if (this.view.RC_edit_pwd.string != this.view.RC_edit_pwdConfirm.string) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_WRONGPS));
            return;
        }

        const sucCb = () => {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_VERPASS));

            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }
            this.closeView();
        };

        const errCb = () => {
            this.errorNum += 1;
            if (this.errorNum > 3) {
                we.commonUI.showConfirm({
                    title: we.core.langMgr.getLangText(CommonLanguage.VERIFY_ERROR_2),
                    content: we.core.langMgr.getLangText(CommonLanguage.VERIFY_ERROR_1),
                    yesButtonName: we.core.langMgr.getLangText(we.launcher.lang.NEW_HALL_TOP_SERVICE),
                    yesHandler: we.core.Func.create(() => {
                        we.common.commonMgr.openCustomerDialog();
                    }, this),
                    noButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CANCEL),
                });
            } else {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.COMMON_INVALID_CODE));
            }
        };

        if (this.accountType === ACCOUNT_TYPE.PHONE) {
            let data = {} as ApiProto.ResetPasswordReq;
            data.phone = this.getAccount();
            data.passwordMd5 = this.view.RC_edit_pwd.string;
            data.vCode = this.view.RC_edit_code.string;
            LoginManager.phoneLoginResetPwd(data, sucCb, errCb);
        } else {
            let data = {} as ApiProto.ResetEmailPasswordReq;
            data.email = this.getAccount();
            data.passwordMd5 = this.view.RC_edit_pwd.string;
            data.verifyCode = this.view.RC_edit_code.string;
            LoginManager.resetPasswordEmail(data, sucCb, errCb);
        }
    }

    private onClickGetCode(): void {
        if (this.isCooling) {
            return;
        }

        const codeType = this.getCodeType();
        const sucCb = () => {
            UserManager.getCodeTimestamp.phoneResetPassword = new Date().getTime();
            let langKey = CommonLanguage.LOGIN_FORGETFRAME_VERCODE_SUCCESS;
            switch (codeType) {
                case AccountVerifyType.SMS:
                    langKey = CommonLanguage.VER_TIP_CHECK_TEXT;
                    break;
                case AccountVerifyType.Voice:
                    langKey = CommonLanguage.VER_TIP_CHECK_VOICE;
                    break;
                case AccountVerifyType.WhatsApp:
                    langKey = CommonLanguage.VER_TIP_CHECK_WHATSAPP;
                    break;
                default:
                    break;
            }
            we.commonUI.showToast(we.core.langMgr.getLangText(langKey));

            if (!cc.isValid(this.view.uiRoot)) {
                return;
            }
            this.setCoolTime(60);
        };

        if (this.accountType === ACCOUNT_TYPE.PHONE) {
            if (this.phoneEditable) {
                // 输入手机号时，验证是否正确
                const phone = this.view.RC_edit_phone.string;
                if (!CommonUtils.isPhoneNumber(phone)) {
                    return;
                }
                this.account = phone;
            }
            let param = {} as ApiProto.VerifyCodeReq;
            param.phone = this.getAccount();
            param.codeType = 1;
            param.verifyType = codeType;
            ApiManager.getNewPhoneCode(param, sucCb, null);
        } else {
            if (!CommonUtils.isEmail(this.view.RC_edit_email.string)) {
                return;
            }
            this.account = this.view.RC_edit_email.string;
            let param = {} as ApiProto.VerifyEmailCodeReq;
            param.email = this.getAccount();
            param.codeType = 1;
            param.verifyType = codeType;
            ApiManager.getEmailCode(param, sucCb, null);
        }
    }

    private onClickCodeTips(): void {
        we.common.commonMgr.openCustomerDialog();
    }

    private onPhoneInputStart(): void {
        this.view.RC_edit_phone.placeholderLabel.string = ``;
    }

    private onPhoneInputEnd(): void {
        let str = this.view.RC_edit_phone.string;
        if (str.trim() == '') {
            this.view.RC_edit_phone.string = '';
            this.view.RC_edit_phone.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER1_TIPS);
        } else {
            if (str.length > 0 && !CommonUtils.isPhoneNumber(this.view.RC_edit_phone.string)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_INVALIDPHONE));
            }
        }
    }

    private onEmailInputStart(): void {
        this.view.RC_edit_email.placeholderLabel.string = ``;
    }

    private onEmailInputEnd(): void {
        let str = this.view.RC_edit_email.string;
        if (str.trim() == '') {
            this.view.RC_edit_email.string = '';
            this.view.RC_edit_email.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.BIND_EMAIL_4);
        } else {
            if (str.length > 0 && !CommonUtils.isEmail(this.view.RC_edit_email.string)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_INVALIDPHONE));
            }
        }
    }

    private onChangePwdShow(): void {
        this.view.RC_edit_pwd.inputFlag = this.view.RC_edit_pwd.inputFlag == cc.EditBox.InputFlag.DEFAULT ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
        let children = this.view.RCN_pwdStatus.children || [];
        if (children.length == 2) {
            children[0].active = this.view.RC_edit_pwd.inputFlag == cc.EditBox.InputFlag.DEFAULT;
            children[1].active = this.view.RC_edit_pwd.inputFlag == cc.EditBox.InputFlag.PASSWORD;
        }
    }

    private onChangePwdConfirmShow(): void {
        this.view.RC_edit_pwdConfirm.inputFlag = this.view.RC_edit_pwdConfirm.inputFlag == cc.EditBox.InputFlag.DEFAULT ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
        let children = this.view.RCN_pwdConfirmStatus.children || [];
        if (children.length == 2) {
            children[0].active = this.view.RC_edit_pwdConfirm.inputFlag == cc.EditBox.InputFlag.DEFAULT;
            children[1].active = this.view.RC_edit_pwdConfirm.inputFlag == cc.EditBox.InputFlag.PASSWORD;
        }
    }

    private onCodeInputStart(): void {
        this.view.RC_edit_code.placeholderLabel.string = ``;
    }

    private onCodeInputEnd(): void {
        if (this.view.RC_edit_code.string == '') {
            this.view.RC_edit_code.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER2_TIPS);
        }
    }

    private onPwdInputStart(): void {
        this.view.RC_edit_pwd.placeholderLabel.string = ``;
    }

    private onPwdInputEnd(): void {
        if (this.view.RC_edit_pwd.string == '') {
            this.view.RC_edit_pwd.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
        }
    }

    private onConfirmPwdInputStart() {
        this.view.RC_edit_pwdConfirm.placeholderLabel.string = ``;
    }

    private onConfirmPwdInputend() {
        if (this.view.RC_edit_pwdConfirm.string == '') {
            this.view.RC_edit_pwdConfirm.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_FORGETFRAME_ENTER3_TIPS);
        }
    }

    private setCoolTime(time: number): void {
        this.coolTime = time;
        this.view.RC_lab_coolingTime.string = `(${this.coolTime})`;
        this.view.RCN_btnGetCode.active = time <= 0;
        this.view.RCN_btnCooling.active = time > 0;
        this.isCooling = time > 0;
    }

    private setUI(type: ACCOUNT_TYPE): void {
        this.view.RCN_phone.active = type === ACCOUNT_TYPE.PHONE;
        this.view.RCN_email.active = type === ACCOUNT_TYPE.EMAIL;
    }

    private setCodeGetType(): void {
        let children = this.view.RCN_codeSelect.children;
        for (let i = 0; i < children.length; i++) {
            const element = children[i];
            let code = parseInt(element.name);
            let index = we.core.projectConfig.commonConfig?.passwordRecoveryVerifyType?.indexOf(code);
            element.active = index > -1;
            if (index > -1) {
                this.view.cc_onBtnClick(element, we.core.Func.create(this.onClickCodeType, this));
                element.zIndex = index;

                const i = this.curCodeType === code ? 0 : 1;
                element.getChildByName('page')?.getComponent(we.ui.WESwitchPage)?.setEventIndex(null, i);
                element.getChildByName('icon')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);
                element.getChildByName('desc')?.getComponent(we.ui.WENodeColorIndex)?.setIndex(i);
                element.getChildByName('dot')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);

                const tips = element.getChildByName('tips');
                tips && (tips.active = we.core.projectConfig.commonConfig?.passwordRecoveryRecommendType?.includes(code));
            }
        }
        this.view.RCN_codeSelect.active = children.some((child) => {
            return child.active;
        });
    }

    private onClickCodeType(event: cc.Event): void {
        let node: cc.Node = event.target;
        this.curCodeType = parseInt(node.name);
        this.view.RCN_codeSelect.children.forEach((item) => {
            const i = item === node ? 0 : 1;
            item.getChildByName('page')?.getComponent(we.ui.WESwitchPage)?.setEventIndex(null, i);
            item.getChildByName('icon')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);
            item.getChildByName('desc')?.getComponent(we.ui.WENodeColorIndex)?.setIndex(i);
            item.getChildByName('dot')?.getComponent(we.ui.WESpriteIndex)?.setIndex(i);
        });
        // 绑定手机时允许切换验证方式
        this.isCooling = false;
        this.onEventGameShow();
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(PhonePasswordForgetDlg_v, `${CommonViewId.PhonePasswordForgetDlg}_v`)
class PhonePasswordForgetDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(PhonePasswordForgetDlg_v, uiBase.addComponent(PhonePasswordForgetDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhonePasswordForgetDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<PhonePasswordForgetDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(PhonePasswordForgetDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhonePasswordForgetDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(PhonePasswordForgetDlg_v).beforeUnload();
    }
}
