import { CommonType } from '../../config/CommonType';
import { CommonLanguage } from '../../const/CommonLanguage';
import LoginManager from '../../manager/LoginManager';
import UserManager from '../../manager/UserManager';
import CommonUtils from '../../utils/CommonUtils';
import { CommonViewId } from '../CommonViewId';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('PhoneLoginDlgView_v', we.bundles.common)
class PhoneLoginDlgView_v extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_account: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_password: cc.EditBox = null;

    @we.ui.ccBind(cc.EditBox)
    public RC_edit_userId: cc.EditBox = null;

    @we.ui.ccBind(cc.Node)
    public RC_title: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnForget: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnLogin: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_btnRegister: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_loginType: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_phoneRoot: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_pwdStatus: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_userIdRoot: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

enum LOGIN_TYPE {
    /** 账号 */
    ACCOUNT = 0,
    /** 用户id */
    USER_ID = 1,
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('PhoneLoginDlg_v', we.bundles.common)
export class PhoneLoginDlg_v extends we.ui.DlgSystem<PhoneLoginDlgView_v> {
    private phoneCode = ``;
    private loginType: LOGIN_TYPE = LOGIN_TYPE.ACCOUNT;

    /** 注册UI事件 */
    public async registerUIEvent() {
        // 按钮事件
        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.closeView, this));
        this.view.cc_onBtnClick(this.view.RCN_btnForget, we.core.Func.create(this.onJumpFindPassword, this));
        this.view.cc_onBtnClick(this.view.RCN_btnRegister, we.core.Func.create(this.onClickRegister, this));
        this.view.cc_onBtnClick(this.view.RCN_btnLogin, we.core.Func.create(this.onPasswordLogin, this));
        this.view.cc_onBtnClick(this.view.RCN_pwdStatus, we.core.Func.create(this.onChangePwdShow, this)).setSleepTime(0.1);
        // 单选按钮事件
        this.view.RCN_loginType.addComponentUnique(we.ui.WEToggleGroup)
            .setGroupMode(we.ui.ToggleGroupMode.SingleOne)
            .setToggleStatus(this.loginType, true)
            .onListener(
                we.core.Func.create((_: number, isChecked: boolean, index: number) => {
                    if (isChecked) {
                        this.loginType = index;
                        this.setUI(this.loginType);
                    }
                }, this)
            );
        // phoneEditbox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidBegan', we.core.Func.create(this.onAccountInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_account.node, 'editingDidEnded', we.core.Func.create(this.onAccountInputEnd, this));
        // passwordEditbox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_password.node, 'editingDidBegan', we.core.Func.create(this.onPwdInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_password.node, 'textChanged', we.core.Func.create(this.onPwdTextChanged, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_password.node, 'editingDidEnded', we.core.Func.create(this.onPwdInputend, this));
        // userIdEditbox
        this.view.cc_onEditBoxEvent(this.view.RC_edit_userId.node, 'editingDidBegan', we.core.Func.create(this.onUserIDInputStart, this));
        this.view.cc_onEditBoxEvent(this.view.RC_edit_userId.node, 'editingDidEnded', we.core.Func.create(this.onUserIDInputEnd, this));
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        this.phoneCode = `+${we.core.flavor.getCountryNum()}`;
        this.view.RC_edit_account.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_ENTER_TIPS_1);
        this.view.RC_edit_password.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_PHONENM_ENTER2_TIPS);
        this.view.RC_edit_userId.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_ID_ENTER1_TIPS);

        this.setUI(this.loginType);
    }

    /** 隐藏窗口 */
    public async onHide() {}

    public beforeUnload() {}

    private initAccount(): void {
        let cacheAccount = LoginManager.getLastAccount();
        if (cacheAccount) {
            if (!this.view.RC_edit_account.string) {
                if (CommonUtils.isPhoneNumber(cacheAccount.phoneNum + '')) {
                    this.view.RC_edit_account.string = cacheAccount.phoneNum;
                    this.loginType == LOGIN_TYPE.ACCOUNT && (this.view.RC_edit_password.string = cacheAccount.password);
                } else if (CommonUtils.isEmail(cacheAccount.email)) {
                    this.view.RC_edit_account.string = cacheAccount.email;
                    this.loginType == LOGIN_TYPE.ACCOUNT && (this.view.RC_edit_password.string = cacheAccount.password);
                }
            }
            if (CommonUtils.isUserIdNumber(cacheAccount.userId + '') && !this.view.RC_edit_userId.string) {
                this.view.RC_edit_userId.string = cacheAccount.userId + '';
                this.loginType == LOGIN_TYPE.USER_ID && (this.view.RC_edit_password.string = cacheAccount.password);
            }
        }
    }

    private onAccountInputStart(): void {
        this.view.RC_edit_account.placeholderLabel.string = ``;
    }

    private onAccountInputEnd(): void {
        let str = this.view.RC_edit_account.string;
        if (str.trim() == '') {
            this.view.RC_edit_account.string = '';
            this.view.RC_edit_account.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_ENTER_TIPS_1);
        } else if (!CommonUtils.isPhoneWithTCC(str) && !CommonUtils.isEmail(str)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_INVALIDPHONE));
        }
    }

    private onUserIDInputStart() {
        this.view.RC_edit_userId.placeholderLabel.string = ``;
    }

    private onUserIDInputEnd(): void {
        let str = this.view.RC_edit_userId.string;
        if (str.trim() == '') {
            this.view.RC_edit_userId.string = '';
            this.view.RC_edit_userId.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_ID_ENTER1_TIPS);
        } else {
            if (str.length > 0 && !CommonUtils.isUserIdNumber(this.view.RC_edit_userId.string)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_ID_ERROR_TIPS2));
            }
        }
    }

    private onPwdInputStart() {
        this.view.RC_edit_password.placeholderLabel.string = ``;
    }

    private onPwdInputend() {
        if (this.view.RC_edit_password.string == '') {
            this.view.RC_edit_password.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_PHONENM_ENTER2_TIPS);
        }
    }

    private onPwdTextChanged() {}

    private onChangePwdShow(): void {
        this.view.RC_edit_password.inputFlag = this.view.RC_edit_password.inputFlag == cc.EditBox.InputFlag.DEFAULT ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
        let children = this.view.RCN_pwdStatus.children || [];
        if (children.length == 2) {
            children[0].active = this.view.RC_edit_password.inputFlag == cc.EditBox.InputFlag.DEFAULT;
            children[1].active = this.view.RC_edit_password.inputFlag == cc.EditBox.InputFlag.PASSWORD;
        }
    }

    // 点击密码登录事件
    private async onPasswordLogin() {
        const account = this.view.RC_edit_account.string;
        let userPassword = this.view.RC_edit_password.string;
        if (this.loginType == LOGIN_TYPE.ACCOUNT) {
            if (!CommonUtils.isPhoneWithTCC(account) && !CommonUtils.isEmail(account)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_INVALIDPHONE));
                return;
            }

            if (!CommonUtils.checkUserPassword(userPassword)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_PHONENM_WRONGPW));
                return;
            }
        } else if (this.loginType == LOGIN_TYPE.USER_ID) {
            if (!CommonUtils.isUserIdNumber(this.view.RC_edit_userId.string)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_ID_ERROR_TIPS2));
                return;
            }

            if (!CommonUtils.checkUserPassword(userPassword)) {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_ID_ERROR_TIPS3));
                return;
            }
        }

        let successCallBack = () => {
            let data = {} as CommonType.IAccountInfo;
            data.userId = UserManager.userInfo.userId;
            data.password = userPassword;
            // userId 登录的时候，account 为空，需要去用户数据中读取账号信息缓存
            let account = UserManager.userInfo.phone?.replace(this.phoneCode, '');
            data.phoneNum = account;
            data.email = UserManager.userInfo.emailAccount;
            LoginManager.saveAccountToLocal(data);
        };

        let errorCallBack = async () => {
            const status = await we.launcher.maintainMgr.getServerStatus();
            if (status === 0) {
                cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
            }
        };

        switch (this.loginType) {
            case LOGIN_TYPE.ACCOUNT:
                if (CommonUtils.isEmail(account)) {
                    let sendData = {} as ApiProto.EmailLoginReq;
                    sendData.email = account;
                    sendData.passwordMd5 = userPassword;
                    LoginManager.emailLogin(sendData, successCallBack, errorCallBack);
                } else {
                    let sendData = {} as ApiProto.PhoneLoginReq;
                    if (CommonUtils.isPhoneWithTCC(account, true)) {
                        // 如果用户输入了区号，需要改成 +区号 格式
                        sendData.phone = account.replace(/^(0+)?(\d+)$/, '+$2');
                    } else {
                        sendData.phone = `${this.phoneCode}${account}`;
                    }
                    sendData.passwordMd5 = userPassword;
                    LoginManager.phoneLogin(sendData, successCallBack, errorCallBack);
                }
                break;
            case LOGIN_TYPE.USER_ID:
                {
                    let sendData = {} as ApiProto.IdLoginReq;
                    sendData.userId = parseInt(this.view.RC_edit_userId.string);
                    sendData.passwordMd5 = userPassword;
                    LoginManager.userIdLogin(sendData, successCallBack, errorCallBack);
                }
                break;
            default:
                break;
        }

        cc.director.emit(we.core.EventName.LOGIN_VIEW_HIDE);
        this.closeView();
    }

    // 点击跳转找回密码事件
    private async onJumpFindPassword() {
        let account = this.view.RC_edit_account.string;
        if (this.loginType === LOGIN_TYPE.ACCOUNT && !CommonUtils.isPhoneWithTCC(account) && !CommonUtils.isEmail(account)) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.LOGIN_INVALIDPHONE));
            return;
        }
        const status = await we.launcher.maintainMgr.getServerStatus();
        if (status !== 0) {
            this.closeView();
            return;
        }
        if (CommonUtils.isEmail(account)) {
            this.createForgetPassword(null, account);
        } else {
            // 需要剔除用户输入的区号
            this.createForgetPassword(this.phoneCode, account.replace(RegExp(`^(\\+|0+|\\+0+)${we.core.flavor.getCountryNum()}`), ''));
        }
    }

    private async onClickRegister() {
        const status = await we.launcher.maintainMgr.getServerStatus();
        if (status !== 0) {
            this.closeView();
            return;
        }

        let callBack = () => {
            let account = this.view.RC_edit_account.string;
            if (we.core.projectConfig.deviceAccSt?.status != 2 && !we.core.projectConfig.deviceAccSt?.isBindPhone) {
                if (!CommonUtils.isEmail(account)) {
                    if (CommonUtils.isPhoneWithTCC(account)) {
                        // 需要剔除用户输入的区号
                        account = account.replace(RegExp(`^(\\+|0+|\\+0+)${we.core.flavor.getCountryNum()}`), '');
                    } else {
                        account = null;
                    }
                }

                we.currentUI.show(we.common.CommonViewId.PhoneBindHighDlg, 1, account);
                this.closeView();
            } else {
                we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.SETTING_BOUND_TIPS));
            }
        };

        if (we.core.projectConfig.deviceAccSt) {
            callBack();
        } else {
            LoginManager.getGuestStatus((data: ApiProto.DeviceAccountStatusResp) => {
                if (!cc.isValid(this.view.uiRoot)) {
                    return;
                }
                callBack();
            }, true);
        }
    }

    private setUI(type: LOGIN_TYPE): void {
        this.view.RCN_phoneRoot.active = type == LOGIN_TYPE.ACCOUNT;
        this.view.RCN_userIdRoot.active = type == LOGIN_TYPE.USER_ID;
        this.view.RC_edit_password.placeholderLabel.string = we.core.langMgr.getLangText(CommonLanguage.LOGIN_PHONENM_ENTER2_TIPS);
        this.initAccount();
    }

    private createForgetPassword(phoneCode: string, account: string): void {
        we.currentUI.show(CommonViewId.PhonePasswordForgetDlg, phoneCode, account, this.loginType === LOGIN_TYPE.USER_ID);
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(PhoneLoginDlg_v, `${CommonViewId.PhoneLoginDlg}_v`)
class PhoneLoginDlgHandler_v extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Popup;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(PhoneLoginDlg_v, uiBase.addComponent(PhoneLoginDlgView_v));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhoneLoginDlg_v).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<PhoneLoginDlg_v['onShow']>): Promise<void> {
        await uiBase.getComponent(PhoneLoginDlg_v).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(PhoneLoginDlg_v).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(PhoneLoginDlg_v).beforeUnload();
    }
}
