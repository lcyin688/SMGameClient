const { ccclass, property } = cc._decorator;

@ccclass
export default class CustomerTableItem_h extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private link: string = '';

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));
    }

    public init(data: { link: string; icon: Object }): void {
        this.__initRc();

        this.link = data?.link;
        let iconPath: string = data?.icon && data?.icon[we.core.langMgr.getCurLangCode()];
        if (this.link && iconPath) {
            iconPath = we.core.utils.joinUrl(we.core.projectConfig.commonConfig?.downloadUrl, iconPath);
            this.loadAssetRemote(iconPath, cc.SpriteFrame).then((spf) => {
                this.RC_spr_icon.spriteFrame = spf;
                this.autoAdaptive();
            });
        } else {
            we.warn(`CustomerTableItem_h init, data is error. data:${JSON.stringify(data)}`);
            this.node.destroy();
        }
    }

    private onClick(): void {
        if (typeof this.link == 'string' && this.link.length > 0) {
            we.core.nativeUtil.openUrl(this.link);
        }
    }

    private autoAdaptive(): void {
        this.scheduleOnce(() => {
            if (this.RC_spr_icon.node.width > this.node.width || this.RC_spr_icon.node.height > this.node.height) {
                const ratio_w = this.RC_spr_icon.node.width / this.node.width;
                const ratio_h = this.RC_spr_icon.node.height / this.node.height;
                const ratio = ratio_w > ratio_h ? ratio_w : ratio_h;
                const scale_des = 0.8 / ratio;
                this.RC_spr_icon.node.scale = scale_des;
            }
        });
    }
}
