const { ccclass, property } = cc._decorator;

@ccclass
export default class CustomerTableItem_v extends we.ui.NodeBase {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Sprite)
    public RC_spr_icon: cc.Sprite = null;

    /* =========================== AUTO CODE TOEND =========================== */

    private link: string = '';

    protected onLoad(): void {
        this.onBtnClick(this.node, we.core.Func.create(this.onClick, this));
    }

    public init(data: { link: string; icon: Object }): void {
        this.__initRc();

        this.link = data?.link;
        let iconPath: string = data?.icon && data?.icon[we.core.langMgr.getCurLangCode()];
        if (this.link && iconPath) {
            iconPath = we.core.utils.joinUrl(we.core.projectConfig.commonConfig?.downloadUrl, iconPath);
            this.loadAssetRemote(iconPath, cc.SpriteFrame).then((spf) => {
                this.RC_spr_icon.spriteFrame = spf;
                this.autoAdaptive();
            });
        } else {
            we.warn(`CustomerTableItem_v init, data is error. data:${JSON.stringify(data)}`);
            this.node.destroy();
        }
    }

    private onClick(): void {
        if (typeof this.link == 'string' && this.link.length > 0) {
            we.core.nativeUtil.openUrl(this.link);
        }
    }

    private autoAdaptive(): void {
        this.scheduleOnce(() => {
            if (this.RC_spr_icon.node.width > this.node.width || this.RC_spr_icon.node.height > this.node.height) {
                let proportion = 1;
                if (this.RC_spr_icon.node.width - this.node.width >= this.RC_spr_icon.node.height - this.node.height) {
                    proportion = this.RC_spr_icon.node.width / (this.node.width - 20);
                } else {
                    proportion = this.RC_spr_icon.node.height / (this.node.height - 20);
                }

                this.RC_spr_icon.node.scale = 1 / proportion;
            }
        });
    }
}
