import { CommonEvent } from '../../config/CommonEvent';
import { CommonRes } from '../../config/CommonRes';
import { CommonType } from '../../config/CommonType';
import UserManager from '../../manager/UserManager';
import { CommonViewId } from '../CommonViewId';
import CustomerTableItem_h from './CustomerTableItem_h';

/**
 * 自动生成 UIView 代码
 */
@we.decorator.typeRegister('CustomerWebDlgView_h', we.bundles.common)
class CustomerWebDlgView_h extends we.ui.UIView {
    /* =========================== AUTO CODE START =========================== */

    @we.ui.ccBind(cc.Node)
    public RC_btnClose: cc.Node = null;

    @we.ui.ccBind(cc.ScrollView)
    public RC_scroll_list: cc.ScrollView = null;

    @we.ui.ccBind(cc.WebView)
    public RC_webView: cc.WebView = null;

    @we.ui.ccBind(cc.Node)
    public RCN_customLayout: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_facebook: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_instagram: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_megawin: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_telegram: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_twitter: cc.Node = null;

    @we.ui.ccBind(cc.Node)
    public RCN_whatsapp: cc.Node = null;

    /* =========================== AUTO CODE TOEND =========================== */
}

/**
 * 自定义逻辑代码
 */
@we.decorator.typeRegister('CustomerWebDlg_h', we.bundles.common)
export class CustomerWebDlg_h extends we.ui.DlgSystem<CustomerWebDlgView_h> {
    private customerScheme: string = 'customerservice';
    private customerUrl: string = '';
    private enableExit: boolean = true;
    private loadTimer: any = null;

    /** 注册UI事件 */
    public async registerUIEvent() {
        this.view.RC_webView.node.active = true;
        this.view.RC_webView.node.on('loading', this.onWebViewLoading, this);
        this.view.RC_webView.node.on('loaded', this.onWebViewLoaded, this);
        this.view.RC_webView.node.on('error', this.onWebViewError, this);

        this.view.cc_onBtnClick(this.view.RC_btnClose, we.core.Func.create(this.onClickBack, this));
        this.view.cc_onBtnClick(this.view.RCN_whatsapp, we.core.Func.create(this.onClickWhatsapp, this));
        this.view.cc_onBtnClick(this.view.RCN_facebook, we.core.Func.create(this.onClickFacebook, this));
        this.view.cc_onBtnClick(this.view.RCN_twitter, we.core.Func.create(this.onClickTwitter, this));
        this.view.cc_onBtnClick(this.view.RCN_instagram, we.core.Func.create(this.onClickInstagram, this));
        this.view.cc_onBtnClick(this.view.RCN_megawin, we.core.Func.create(this.onClickMegawin, this));
        this.view.cc_onBtnClick(this.view.RCN_telegram, we.core.Func.create(this.onClickTelegram, this));

        // TODO 取消这几个客服
        this.view.RCN_whatsapp.active = false;
        this.view.RCN_facebook.active = false;
        this.view.RCN_twitter.active = false;
        this.view.RCN_instagram.active = false;
        this.view.RCN_telegram.active = false;

        // TODO 默认开启的客服
        this.view.RCN_megawin.active = true;

        this.view.RC_webView.node.opacity = 0;

        this.initCustomerUrl();
        this.addTableItem();

        cc.director.on(we.core.EventName.WINDOW_MESSAGE, this.onWebViewMessageWeb, this);
        cc.director.on(we.core.EventName.KEYBOARD_HEIGHT_CHANGED, this.onKeyboardHeightChanged, this);
    }

    /** 显示窗口 */
    public async onShow(showData?: any) {
        // @ts-ignore
        this.view.RC_webView.setBackgroundTransparent(true);
        this.view.RC_webView.setJavascriptInterfaceScheme(this.customerScheme);
        this.view.RC_webView.setOnJSCallback(this.onWebViewMessageNative.bind(this));
        this.loadCustomerUrl();
    }

    /** 隐藏窗口 */
    public async onHide() {
        this.clearLoadTimer();
    }

    public destroy() {
        this.clearLoadTimer();
        cc.director.off(we.core.EventName.WINDOW_MESSAGE, this.onWebViewMessageWeb, this);
        cc.director.off(we.core.EventName.KEYBOARD_HEIGHT_CHANGED, this.onKeyboardHeightChanged, this);
    }

    public beforeUnload() {
        this.releaseAsset(CommonRes.prefab.CustomerTableItem, cc.Prefab);
    }

    private initCustomerUrl() {
        let url = we.core.projectConfig.commonConfig.customerUrl;
        if (!url) {
            we.error(`CustomerWebDlg_h initCustomerUrl, url:${url}`);

            we.launcher.maintainMgr.getCommonConfig(
                () => {
                    if (!cc.isValid(this)) {
                        return;
                    }

                    if (we.core.projectConfig.commonConfig.customerUrl) {
                        this.initCustomerUrl();
                        this.loadCustomerUrl();
                    } else {
                        we.commonUI.showToast(we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT) + ': ' + 20000);
                    }

                    this.addTableItem();
                },
                () => {
                    we.commonUI.showToast(we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT) + ': ' + 20001);
                }
            );
            return;
        }

        if (!(url && typeof url == 'string' && url.startsWith('http'))) {
            we.warn(`CustomerWebDlg_h initCustomerUrl, url error, url: ${url}`);

            we.commonUI.showToast(we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT) + ': ' + 20001);
            return;
        }

        let isPlatformCustomer = we.core.projectConfig.isPlatformCustomer();
        if (isPlatformCustomer) {
            let ts = new Date().getTime();
            let platform = encodeURIComponent(we.core.nativeUtil.getPlatform());
            let aid = encodeURIComponent(we.core.nativeUtil.getDeviceId());
            let channel = encodeURIComponent(we.core.nativeUtil.getChannel());
            let dmo = encodeURIComponent(we.core.nativeUtil.getDeviceModel());
            let dbr = encodeURIComponent(we.core.nativeUtil.getDeviceBrand());
            let dst = encodeURIComponent(we.core.nativeUtil.getSensorType());
            let language = encodeURIComponent(we.core.langMgr.getCurLangCode());
            let uid = encodeURIComponent(we.kit.storageUtil.readUserId());
            let nick = encodeURIComponent(UserManager.userInfo.userName);
            let country = encodeURIComponent(UserManager.userInfo.country);
            let adaptEditbox = encodeURIComponent(cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID ? 1 : 0);
            let cvf_enabled = 1;

            let params = [
                `ts=${ts}`,
                `platform=${platform}`,
                `aid=${aid}`,
                `channel=${channel}`,
                `dmo=${dmo}`,
                `dbr=${dbr}`,
                `dst=${dst}`,
                `language=${language}`,
                `user_id=${uid}`,
                `user_name=${nick}`,
                `skin=${we.core.flavor.getSkinCode()}`,
                `country=${country}`,
                `adapt_editbox=${adaptEditbox}`,
                `cvf_enabled=${cvf_enabled}`,
            ];

            for (let i = 0; i < params.length; i++) {
                let key = params[i].split('=')[0];
                if (url.includes(key + '=')) {
                    // 参数重复时跳过
                    continue;
                }

                url = url + (url.includes('?') ? '&' : '?') + params[i];
            }
        }

        we.log(`CustomerWebView_h start, url: ${url}`);
        this.customerUrl = url;
    }

    loadCustomerUrl() {
        if (!this.customerUrl) {
            return;
        }

        this.view.RC_webView.url = this.customerUrl;
        this.clearLoadTimer();
        this.loadTimer = setTimeout(this.onWebViewTimeout.bind(this), 10 * 1000);
        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'CustomerWebDlgView_h loadCustomerUrl' });
    }

    clearLoadTimer() {
        if (this.loadTimer != null) {
            clearTimeout(this.loadTimer);
            this.loadTimer = null;
        }
    }

    onWebViewLoading(event: cc.Event) {
        we.log(`CustomerWebView_h onWebViewLoading`);
    }

    onWebViewLoaded(event: cc.Event) {
        we.log(`CustomerWebView_h onWebViewLoaded`);

        this.view.RC_webView.node.opacity = 255;
        this.clearLoadTimer();
        we.commonUI.hideCircleLoading();

        CommonType.storage.setById('common', 'customer', false);
        cc.director.emit(CommonEvent.NOTICE_NEW_CUSTOMER);
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.server, 0, true);
    }

    onWebViewError(event: cc.Event) {
        we.log(`CustomerWebView_h onWebViewError`);

        this.clearLoadTimer();
        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT) + ': ' + 20002);
    }

    onWebViewTimeout() {
        we.log(`CustomerWebView_h onWebViewTimeout`);

        this.clearLoadTimer();
        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT) + ': ' + 20003);
    }

    onWebViewMessageNative(target: cc.WebView, url: string) {
        this.parseMessage(url);
    }

    onWebViewMessageWeb(data: any) {
        if (data) {
            this.parseMessage(data.url);
        }
    }

    onKeyboardHeightChanged(keyboardHeight: number, screenHeight: number) {
        this.view.RC_webView.evaluateJS(`onNotifyKeyboardHeight(${keyboardHeight}, ${screenHeight})`);
    }

    private onClickBack(event: cc.Event): void {
        if (this.enableExit) {
            this.closeView();
        }
    }

    private onClickFacebook(event: cc.Event): void {
        we.core.nativeUtil.openFacebookFansPage(we.core.projectConfig.commonConfig.fbFansUrl);
    }

    private onClickTwitter(event: cc.Event): void {
        we.core.nativeUtil.openUrl(we.core.projectConfig.commonConfig.twitterFansUrl);
    }

    private onClickInstagram(event: cc.Event): void {
        we.core.nativeUtil.openInstagramFansPage(we.core.projectConfig.commonConfig.instagramFansUrl);
    }

    private onClickMegawin(event: cc.Event): void {
        let url = null;
        if (we.core.projectConfig.commonConfig) {
            url = we.core.projectConfig.commonConfig.officialWebsiteDownAddress;
        } else {
            we.warn(`CustomerWebDlg_h onClickMegawin, officialWebsiteDownAddress is null`);
            return;
        }
        we.core.nativeUtil.openUrl(url);
    }

    private onClickWhatsapp(event: cc.Event): void {
        we.core.nativeUtil.openWhatsApp(we.core.projectConfig.commonConfig.whatsappNumber);
    }

    private onClickTelegram(event: cc.Event): void {
        // we.core.nativeUtil.openWhatsApp(we.core.projectConfig.commonConfig.telegram);
    }

    parseMessage(url: string) {
        if (!(url && typeof url == 'string')) {
            we.error(`CustomerWebDlg_h parseMessage, url error url:${url}`);
            return;
        }

        let scheme = url.substring(0, url.indexOf('://'));
        if (scheme != this.customerScheme) {
            return;
        }

        let message = {};
        let fields = url.substring((scheme + '://').length).split('&');
        for (let i = 0; i < fields.length; i++) {
            let kvs = fields[i].split('=');
            if (kvs && kvs.length == 2) {
                message[kvs[0]] = decodeURIComponent(kvs[1]);
            }
        }

        let cmd = message['cmd'];
        switch (cmd) {
            case 'editbox_show':
                if (cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID) {
                    this.enableExit = false;
                }
                break;
            case 'editbox_hide':
                if (cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID) {
                    this.enableExit = true;
                }
                break;
            default:
                break;
        }
    }

    private async addTableItem() {
        this.view.RCN_customLayout.removeAllChildren();

        const prefab = await this.loadAsset(CommonRes.prefab.CustomerTableItem, cc.Prefab);

        let conf = we.core.projectConfig.commonConfig?.customerConfig || [];
        conf.forEach((v, i) => {
            if (v.link) {
                let node = cc.instantiate(prefab);
                this.view.RCN_customLayout.addChild(node, i + 1);
                node.getComponent(CustomerTableItem_h).init(v);
            }
        });
    }
}

/**
 * 组件生命周期注册
 */
@we.decorator.eventUI(CustomerWebDlg_h, `${CommonViewId.CustomerWebDlg}_h`)
class CustomerWebDlgHandler_h extends we.ui.UIEventHandler {
    onInitCoreData(uiBase: we.ui.UIBase): void {
        uiBase.uiConfig.viewType = we.ui.type.UIViewType.Top;
        uiBase.uiConfig.closeType = we.ui.type.UICloseType.Destroy;
    }

    onInitComponent(uiBase: we.ui.UIBase): void {
        uiBase.addComponent(CustomerWebDlg_h, uiBase.addComponent(CustomerWebDlgView_h));
    }

    async onRegisterUIEvent(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CustomerWebDlg_h).registerUIEvent();
    }

    async onShow(uiBase: we.ui.UIBase, ...args: Parameters<CustomerWebDlg_h['onShow']>): Promise<void> {
        await uiBase.getComponent(CustomerWebDlg_h).onShow(...args);
    }

    async onHide(uiBase: we.ui.UIBase): Promise<void> {
        await uiBase.getComponent(CustomerWebDlg_h).onHide();
    }

    beforeUnload(uiBase: we.ui.UIBase): void {
        uiBase.getComponent(CustomerWebDlg_h).beforeUnload();
    }

    async onHideAnimation(uiBase: we.ui.UIBase): Promise<void> {
        uiBase.uiRoot.active = false;
    }
}
