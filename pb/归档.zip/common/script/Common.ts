import { Bundles } from './const/Bundles'; // Bundles 第一个初始化确保 we.bundles 赋值
import { CommonType } from './config/CommonType';
import GameManager from './manager/GameManager';
import ApiManager from './api/ApiManager';
import { CommonViewId } from './view/CommonViewId';
import { gameList } from './const/GameList';
import { GameId } from './const/GameId';
import { GameEventTask } from './task/GameEventTask';

declare global {
    interface IWe {
        /** 客户端公共模块 */
        common: ICommon;
        /** bundle 包名常量定义 */
        bundles: typeof Bundles;
    }
    interface TWe {
        ICommonDialog: ICommonDialog;
    }
    interface ICommon {
        /** common 缓存 table，根据用户 id 存储 */
        storage: we.kit.Storage<CommonType.StorageTable>;
        /** 系统Storage扩展 */
        sys: we.kit.Storage<CommonType.StorageSysTable>;
        CommonViewId: typeof CommonViewId;
        CommonBoot: typeof CommonBoot;
    }

    namespace we {
        type ICommonDialog = TWe['ICommonDialog'];
        namespace common {
            type CommonBoot = InstanceType<typeof CommonBoot>;
        }
    }
}

/**
 * 公共弹窗 CommonDialog CommonInfoDialog 数据格式
 * 注意：需要显示按钮必须，按钮文本和按钮事件回调不能全为空，可合理组合
 * positiveText 为空，positiveCb 不为空，按钮文本默认显示：确定 多语言文本
 * negativeText 为空，negativeCb 不为空，按钮文本默认显示：取消 多语言文本
 */
interface ICommonDialog {
    /** 弹窗标题 */
    title?: string;
    /** 提示内容 */
    content: string;
    /** 积极按钮文本为空时 positiveCb 不为空，默认显示：确定 多语言文本 */
    positiveText?: string;
    /** 积极点击回掉 */
    positiveCb?: Function;
    /** 消极按钮文本为空时 negativeCb 不为空，默认显示：取消 多语言文本 */
    negativeText?: string;
    /** 消极按钮点击回掉 */
    negativeCb?: Function;
    /** 是否隐藏关闭按钮 */
    isHideClose?: boolean;
    /** 调整按钮排序 */
    btnExchange?: boolean;
}

(function () {
    GameManager.init();
    // TODO api 配置化后，删除
    // 设置游戏列表
    we.core.gameConfig.appendGameList(gameList);
    we.core.gameConfig.gameId = GameId;
    ApiManager.init();
    we.common.sys = <we.kit.Storage<CommonType.StorageSysTable>>we.kit.storage;
})();

@we.decorator.typeSingleton('OnceBoot')
export class CommonBoot extends we.core.Entity {
    static Inst: CommonBoot;
    protected awake(): void {
        we.clientScene.addComponent(we.common.CommonModel);
        we.clientScene.addComponent(GameEventTask);
        we.common.CommonViewId = CommonViewId;
    }
}

we.common.CommonBoot = CommonBoot;

/**
 * 语言上报
 */
@we.decorator.eventInvoke(we.core.eventInvoke.ReportLanguage)
export class ReportLanguageHandler extends we.core.AInvokeHandler<we.core.eventInvoke.ReportLanguage, void> {
    async handle(args: we.core.eventInvoke.ReportLanguage): Promise<void> {
        const params = {} as ApiProto.accountLangBindReq;
        params.lang = args.langCode;
        we.common?.apiMgr.reportLanguage(params, null, null);
    }
}
