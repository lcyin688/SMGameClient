import { CommonType } from './CommonType';

declare global {
    interface ICommon {
        /** ecs事件定义 */
        EventType: typeof EventType;
        /** 事件名常量定义 */
        EventName: typeof CommonEvent;
    }
    interface TCommon {
        EventMsg: EventMsg;
    }
    namespace we {
        namespace common {
            type EventMsg = TCommon['EventMsg'];
        }
    }
}

export const CommonEvent = {
    /** 更新用户数据变动后对应UI显示 */
    UPDATE_USER_INFO_SHOW: Symbol('UPDATE_USER_INFO_SHOW'),
    /** 新的客服消息通知 */
    NOTICE_NEW_CUSTOMER: Symbol('NOTICE_NEW_CUSTOMER'),
    /** 更新每日签到奖励 */
    UPDATE_DAILY_FREE_AWARD: Symbol('UPDATE_DAILY_FREE_AWARD'),
    /** 隐藏绑定入口 */
    HIDE_BIND_ENTRY: Symbol('HIDE_BIND_ENTRY'),
    /** 检查是否充值成功提示推送消息 */
    CHECK_PAY_SUCCESS_PUSH: Symbol('CHECK_PAY_SUCCESS_PUSH'),
    /** 支付成功 */
    PAY_SUCCESS: Symbol('PAY_SUCCESS'),
    /** 显示问券调查 */
    SHOW_QUESTIONNAIRE: Symbol('SHOW_QUESTIONNAIRE'),
    /** 每日充值任务 刷新 */
    UPDATE_DAILY_RECHARGE: Symbol('UPDATE_DAILY_RECHARGE'),
    /** 隐藏游戏加载界面 */
    HIDE_GAME_LOADING: Symbol('HIDE_GAME_LOADING'),
    /** 更新邮件列表 */
    UPDATE_MAIL_LIST: Symbol('UPDATE_MAIL_LIST'),
    /** 关闭首冲界面 */
    CLOSE_FIRST_RECHARGE_DIALOG: Symbol('CLOSE_FIRST_RECHARGE_DIALOG'),
    /** 首冲推送 */
    GIFT_BAG_UPDATE: Symbol('GIFT_BAG_UPDATE'),
    /** 隐藏新手引导 */
    ON_HIDE_GUIDE: Symbol('ON_HIDE_GUIDE'),
    /** 更新大厅顶部UI */
    UPDATE_HALL_TOP_MENU: Symbol('UPDATE_HALL_TOP_MENU'),
    /** 飞金币动画 */
    COIN_FLY_ANIM: Symbol('COIN_FLY_ANIM'),
    /** 飞金币动画 */
    STORE_COIN_FLY_ANIM: Symbol('STORE_COIN_FLY_ANIM'),
    /** 提现更新打码量 */
    WITHDRAW_UPDATE_BET_NUM: Symbol('WITHDRAW_UPDATE_BET_NUM'),
    /** 刷新提现 */
    WITHDRAW_UPDATE_VIEW: Symbol('WITHDRAW_UPDATE_VIEW'),
    /** 更新支付类型选择 */
    UPDATE_PAY_CHANNEL: Symbol(`UPDATE_PAY_CHANNEL`),
    /** 大厅是否显示提现入口 */
    HALL_IS_SHOW_WITHDRAW: Symbol('HALL_IS_SHOW_WITHDRAW'),
    /** 更新Banner */
    UPDATE_BANNER_SHOW: Symbol('UPDATE_BANNER_SHOW'),
    /** 提现播报 */
    WITHDRAW_BROAD: Symbol('WITHDRAW_BROAD'),
    /** 救援金数据获取成功 */
    RESCUE_FUNDS_SYNC: Symbol('RESCUE_FUNDS_SYNC'),
    /** 事件中心通知 */
    NOTICE_EVENT_CENTER: Symbol('NOTICE_EVENT_CENTER'),
    /** 关闭独立日活动界面 */
    CLOSE_INDEPENDENT_VIEW: Symbol('CLOSE_INDEPENDENT_VIEW'),
    /** 更新独立日活动 */
    UPDATE_INDEPENDENT_TASK: Symbol('UPDATE_INDEPENDENT_TASK'),
    /** vip exp变化 */
    VIP_EXP_CHANGE: Symbol('VIP_EXP_CHANGE'),
    /** 更新狂欢活动 */
    UPDATE_CARNIVAL: Symbol('UPDATE_CARNIVAL'),
    /** 关闭狂欢活动界面 */
    CLOSE_CARNIVAL_VIEW: Symbol('CLOSE_CARNIVAL_VIEW'),
    /** 更新落地页包使用奖励按钮状态 */
    UPDATE_OFFICIAL_BAG_AWARD: Symbol('UPDATE_OFFICIAL_BAG_AWARD'),
    /** 更新必弹队列 */
    HALL_POPUP_QUEUE_UPDATE: Symbol('HALL_POPUP_QUEUE_UPDATE'),
    /** 关闭弹窗弹窗队列 */
    HALL_POPUP_QUEUE_CLOSE: Symbol('HALL_POPUP_QUEUE_CLOSE'),
    /** 跳转命令 */
    JUMP_ACTION_CMD: Symbol('JUMP_ACTION_CMD'),

    // ///////////////////// 新增的 /////////////////////

    /** 显示引导 */
    SHOW_GUIDE: Symbol('SHOW_GUIDE'),

    /** 更新引导步骤 */
    UPDATE_GUIDE_STEP: Symbol('UPDATE_GUIDE_STEP'),

    /** 同步刷新大厅金币显示 */
    UPDATE_GOLD_SHOW: Symbol('UPDATE_GOLD_SHOW'),

    /** 退出子游戏 */
    EVENT_OUT_GAME: Symbol('EVENT_OUT_GAME'),

    /** 更新转盘活动 */
    UPDATE_TURNTABLE_TASK: Symbol('UPDATE_TURNTABLE_TASK'),

    /** 充值成功奖励弹窗 */
    AWARD_RECHARGE_SUC_DLG: Symbol('AWARD_RECHARGE_SUC_DLG'),

    /** 领取奖励弹框 */
    AWARD_RECEIVE_SUC_DLG: Symbol('AWARD_RECEIVE_SUC_DLG'),

    /** 活动数据初始化完成 */
    ACTIVITY_DATA_INIT: Symbol('ACTIVITY_DATA_INIT'),

    /** 打开下载引导 */
    OPEN_DOWNLOAD_GUIDE: Symbol('OPEN_DOWNLOAD_GUIDE'),

    /** 打开下载引导个人信息界面 */
    OPEN_DOWNLOAD_USER_INFO_GUIDE: Symbol('OPEN_DOWNLOAD_USER_INFO_GUIDE'),

    /** naming alter 推送消息 */
    NAMING_ALTER_PUSH_MSG_HANDLE: Symbol('NAMING_ALTER_PUSH_MSG_HANDLE'),

    /** naming jackpot 推送消息 */
    NAMING_JACKPOT_PUSH_MSG_HANDLE: Symbol('NAMING_JACKPOT_PUSH_MSG_HANDLE'),

    /** 刷新银行界面 */
    UPDATE_BANK: Symbol('UPDATE_BANK'),
    /** 刷新银行个人帐户信息 */
    UPDATE_BANK_INFO: Symbol('UPDATE_BANK_INFO'),

    /** 刷新月签到-按天 */
    UPDATE_MONTH_MONTH_SIGN: Symbol('UPDATE_MONTH_MONTH_SIGN'),
    /** 刷新月签到-按次 */
    UPDATE_MONTH_MONTH_SIGN2: Symbol('UPDATE_MONTH_MONTH_SIGN2'),

    /** 打开实名制弹窗 */
    OPEN_USER_REAl_NAME_DLG: Symbol('OPEN_USER_REAl_NAME_DLG'),

    /** 充值完成事件 */
    RECHARGE_FINISH: Symbol('RECHARGE_FINISH'),

    /** 跨天推送事件 */
    CROSS_DAY_PUSH: Symbol('CROSS_DAY_PUSH'),

    /** 购买周卡成功 */
    WEEK_CARD_BUY_SUCCESS: Symbol('WEEK_CARD_BUY_SUCCESS'),

    /** 购买七日福利礼包成功 */
    SEVEN_DAY_BUY_SUCCESS: Symbol('SEVEN_DAY_BUY_SUCCESS'),
};

we.common.EventName = CommonEvent;

/**
 * Ecs事件定义
 */
export namespace EventType {
    /**
     * 场景加载，初始化
     */
    @we.decorator.typeRegister('PrepareScene')
    export class PrepareScene {
        constructor(public gameId: we.GameId) {}
    }
}

we.common.EventType = EventType;

export interface EventMsg extends we.core.EventMsg {
    /** 被顶号 */
    RemoteLogin: boolean;
    /** 游戏事件 */
    GameEvent: CommonType.GameEvent;
}
