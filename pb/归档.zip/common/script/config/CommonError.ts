declare global {
    interface ICommon {
        ClientError: typeof we.core.ClientError;
        ClientErrorType: typeof we.core.ClientErrorType;
        isClientError(err: any): err is we.core.ClientError;
    }

    namespace we {
        namespace common {
            type ClientError = InstanceType<typeof we.core.ClientError>;
            type ClientErrorType = TCore['ClientErrorType'];
        }
    }
}

// 兼容保留
we.common.ClientErrorType = we.core.ClientErrorType;
we.common.ClientError = we.core.ClientError;
we.common.isClientError = we.core.isClientError;

export {};
