import ApiManager from '../api/ApiManager';
import UserManager from '../manager/UserManager';
import { CommonEvent } from './CommonEvent';

declare global {
    interface ICommon {
        /** vip相关配置，状态 */
        VIPConfig: typeof VIPConfig;
    }
}

interface IVipAwardStatus {
    /** 上次请求时间戳 */
    timestamp: number;
    /** vip奖励领取状态 */
    data: ApiProto.VipSysRewardStatusResp;
}

export default class VIPConfig {
    /** vip相关奖励状态 */
    public static readonly VipAwardStatus = cc.Enum({
        /** 不能领取 */
        CANNOT_RECEIVE: 0,
        /** 可领取 */
        CAN_RECEIVE: 1,
        /** 已领取 */
        RECEIVED: 2,
    });

    /** Vip加成类型 */
    public static readonly VIP_ADDITION_TYPE = cc.Enum({
        /**  道具卡 */
        gameItemAdd: 0,
        /** 最大好友数 */
        maxFriendNum: 1,
        /** 充值 */
        coinAdd: 2,
        /** 礼盒赠送 */
        shareGiftMaxNum: 3,
        /** 签到 */
        signAdd: 4,
        /** 转账额度 */
        dailyTransferLimit: 5,
        /** 黄金转轮 */
        onlineBonusAdd: 6,
        /** 分享 */
        shareAdd: 7,
        /** 任务 */
        taskAdd: 8,
        /** 幸运轮盘 */
        prizeWheelMaxNum: 9,
        /** 好友数量 */
        friendsNum: 10,
        /** 生日奖励 */
        birthday: 11,
        /** vip升级奖励 */
        upgrade: 15,
    });

    /** Vip配置 */
    public static vipLevelConfig: ApiProto.VipSysRewardInfo[] = [];
    private static vipLevelConfigTime = 0;
    /** vip奖励领取状态 */
    public static vipAwardStatus: IVipAwardStatus = {} as IVipAwardStatus;
    /** 最大Vip等级 */
    public static spe_user_vip_limit = 10;
    /** 经验类型 0: 打码量 1: 充值金额 */
    public static experienceType = 0;

    public static init(sucCallBack?: Function) {
        const curTime = new Date().getTime();
        const fns: Promise<any>[] = [];
        if (curTime - (this.vipLevelConfigTime || 0) > 5000) {
            fns.push(
                new Promise((resolve) => {
                    we.common.userMgr.getVipInfo(() => {
                        resolve(true);
                    });
                })
            );
            fns.push(
                new Promise((resolve) => {
                    ApiManager.getVipLevelAwardList((data: ApiProto.VipSysRewardInfoResp) => {
                        this.vipLevelConfig = data.vipSysRewardInfo || [];
                        this.experienceType = data.experienceType || 0;
                        this.spe_user_vip_limit = this.vipLevelConfig.length - 1 > 0 ? this.vipLevelConfig.length - 1 : 0;
                        this.vipLevelConfigTime = curTime;
                        resolve(true);
                    }, null);
                })
            );
            fns.push(
                new Promise((resolve) => {
                    this.getVipAwardStatus(() => {
                        resolve(true);
                    });
                })
            );
        } else {
            fns.push(
                new Promise((resolve) => {
                    this.getVipAwardStatus(() => {
                        resolve(true);
                    });
                })
            );
        }

        Promise.all(fns).then(() => {
            sucCallBack?.();
        });
    }

    /**
     * 获取vip加成数据
     * @param key 加成类型 key
     * @param isCurrent 当前加成 false-获取vip最大等级加成
     * @returns
     */
    public static getVipEquityAdd(key: string, isCurrent: boolean = true) {
        let addition = 0;
        if (this.vipLevelConfig.length > 0) {
            if (isCurrent) {
                let vipLv = UserManager.vipExp.level;
                if (vipLv >= this.vipLevelConfig.length) {
                    return addition;
                }
                addition = this.vipLevelConfig[vipLv][key] || 0;
            } else {
                addition = this.vipLevelConfig[this.vipLevelConfig.length - 1][key] || 0;
            }
        }

        return addition;
    }

    /**
     * 获取vip奖励接口
     * @param params
     * @param sucCallBack
     * @param errCallback
     */
    public static getVipSysAward(params: { awardType: 1 | 2; vipSalaryDay?: number }, sucCallBack?: Function, errCallback?: Function): void {
        ApiManager.getVipSysAward(
            params as any,
            (data: ApiProto.ReceiveVipSysRewardResp) => {
                typeof sucCallBack == 'function' && sucCallBack(data);
            },
            (code) => {
                typeof errCallback == 'function' && errCallback(code);
            }
        );
    }

    /**
     * 获取vip奖励领取状态
     * @param sucCallBack
     * @param errCallback
     */
    public static getVipAwardStatus(sucCallBack?: Function, errCallback?: Function, isShowLoading: boolean = false): void {
        if (this.vipAwardStatus) {
            let timestamp = new Date().getTime() - this.vipAwardStatus.timestamp;
            if (timestamp < 3000) {
                typeof sucCallBack == 'function' && sucCallBack(this.vipAwardStatus.data);
                return;
            }
        }

        ApiManager.getVipAwardStatus(
            (data: ApiProto.VipSysRewardStatusResp) => {
                if (!this.vipAwardStatus) {
                    this.vipAwardStatus = {} as IVipAwardStatus;
                }
                this.vipAwardStatus.timestamp = new Date().getTime();
                this.vipAwardStatus.data = data;

                // 刷新红点
                const birthAwardStatus = we.common.VIPConfig.vipAwardStatus.data?.birthAwardStatus;
                if (birthAwardStatus === we.common.VIPConfig.VipAwardStatus.CAN_RECEIVE) {
                    we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.vipBirthdayAward, 1, true);
                }
                const vipSalary = we.common.VIPConfig.vipAwardStatus.data?.vipSalary || {};
                for (const key in vipSalary) {
                    if (vipSalary[key] === we.common.VIPConfig.VipAwardStatus.CAN_RECEIVE) {
                        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.vipSalary, 1, true);
                        break;
                    }
                }

                typeof sucCallBack == 'function' && sucCallBack(data);
            },
            (code) => {
                typeof errCallback == 'function' && errCallback(code);
            },
            isShowLoading
        );
    }

    /**
     * 刷新vp数据
     * @param vpAdd
     * @returns
     */
    public static addVPByPay(vpAdd: number) {
        if (vpAdd <= 0) {
            return;
        }

        UserManager.vipExp.exp += vpAdd;
        for (let i = UserManager.vipExp.level + 1; i <= this.spe_user_vip_limit; i++) {
            let maxLvExp = this.vipLevelConfig[i].minBetAmount;
            if (UserManager.vipExp.exp < maxLvExp) {
                UserManager.vipExp.level = i - 1;
                break;
            }
            if (i == this.spe_user_vip_limit) {
                UserManager.vipExp.level = this.spe_user_vip_limit;
            }
        }
        // 刷新商城vp显示
        cc.director.emit(CommonEvent.UPDATE_USER_INFO_SHOW);
        cc.director.emit(CommonEvent.VIP_EXP_CHANGE);
    }

    /**
     * 获取Vip是否有红点
     * @returns
     */
    public static getVipReadNotice(): boolean {
        let awardData = (this.vipAwardStatus?.data || {}) as ApiProto.VipSysRewardStatusResp;
        if (awardData) {
            if (awardData.birthAwardStatus == this.VipAwardStatus.CAN_RECEIVE) {
                return true;
            }
            const vipSalary = awardData.vipSalary || {};
            for (const key in vipSalary) {
                if (vipSalary[key] === we.common.VIPConfig.VipAwardStatus.CAN_RECEIVE) {
                    return true;
                }
            }
        }

        return false;
    }
}

we.common.VIPConfig = VIPConfig;
