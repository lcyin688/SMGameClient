import { Bundles } from '../const/Bundles';

declare global {
    interface ICommon {
        /** 资源配置 */
        res: typeof CommonRes;
    }
}

const materialDyn = 'common/dyn/material/';
const textureDyn = 'common/dyn/texture/';
const prefabDyn = 'common/dyn/prefab/';
const audioDyn = 'common/dyn/audio/';
const aniDyn = 'common/dyn/animation/';
const share = 'common/share/';

export const CommonRes = {
    animation: {},

    audio: {},

    prefab: {
        /** 红点 */
        RedItem: prefabDyn + 'others/RedItem',

        /** 进入子游戏加载界面 */
        gameLoading: prefabDyn + 'loading/GameLoading',

        /** 客服类型按钮Item */
        CustomerTableItem: prefabDyn + 'customer/CustomerTableItem',
    },

    texture: {
        /** 单个金币 */
        coin: textureDyn + 'common/coin',
        /** 头像边框 */
        avatar_frame: textureDyn + 'common/avatar_2',
        /** 用户头像 */
        userHead: textureDyn + 'userheader/',
        /** 默认头像 */
        defaultHead: textureDyn + 'userheader/head_default',
    },

    material: {
        /** 圆形裁剪 */
        Glowing: share + 'material/Glowing',
        /** 置灰 */
        gray: share + 'material/gray',
    },

    /** 游戏公共包 */
    gameComBundles: [Bundles.combase, Bundles.comwbg, Bundles.comslotv2, Bundles.comslot, Bundles.comfight, Bundles.comsingle, Bundles.commulti, Bundles.comfish],
};

we.common.res = CommonRes;
