declare global {
    interface ICommon {
        type: typeof CommonType;
    }
    namespace we {
        namespace common {
            /** 游戏次数记录 */
            type IGameTimesInfo = CommonType.IGameTimesInfo;
            /** 最近游戏配置 */
            type IGameInfo = CommonType.IGameInfo;
            /** 邮件缓存信息 */
            type IMailCacheInfo = CommonType.IMailCacheInfo;
            /** 账号信息 */
            type IAccountInfo = CommonType.IAccountInfo;
        }
    }
}

export namespace CommonType {
    interface StorageTableInfo {
        /** 登录时间 */
        login_date: number;
        /** 客服新消息 */
        customer: boolean;
        /** 上级代理 */
        agent_superior: string;
        /** 缓存邮件 */
        mail_cache: IMailCacheInfo;
        /** 推送回执记录 */
        push_msg_receipt_record: { [key: string]: string[] };

        /** 充值失败计数 */
        recharge_fail_count: number;
        /** 商城最近充值金额纪录 */
        recharge_store_last_record: { payType: number; amount: number }[];

        /** 活动点击记录 */
        click_event_center_record: number[];
        /** 加入我们点击 */
        click_join_us_jump: boolean;
        /** 记录加入我们跳转记录 */
        click_join_us_record: {};

        /** 不弹 加入官方 */
        no_prop_join_us: boolean;
        /** 不弹 狂欢活动 */
        no_prop_carnival: boolean;
        /** 不弹 每日充值任务 */
        no_prop_daily_recharge: boolean;

        /** 不弹 活动弹窗 */
        no_prop_activity: boolean;

        /** 不弹 Api 游戏比例弹窗（仅当天生效） */
        no_prop_conversion_tip: boolean;

        /** 缓存游戏次数与最近时间 */
        game_play_times: CommonType.IGameTimesInfo[];
        /** 引导模块 */
        game_guide_modules: {};
        /** 是否首次使用视讯 */
        game_guide_first_play_video: number;
        /** 最近一次游戏信息 */
        game_last_info: CommonType.IGameInfo;

        /** 记录功能点，打开时间 */
        first_open_timestamp: { [type: string]: number };
    }

    /** 邮件缓存信息 */
    export interface IMailCacheInfo {
        /** 请求时间 */
        timestamp: number;
        /** 系统邮件 */
        system: ApiProto.MailDetailItem[];
    }

    /** 游戏次数记录 */
    export interface IGameTimesInfo {
        /** 游戏 id */
        gameId: we.GameId;
        /** 最近一次记录时间 */
        lastTime: number;
        /** 次数 */
        times: number;
    }

    /** 最近游戏配置 */
    export interface IGameInfo {
        /** 游戏id */
        gameId: we.GameId;
        /** 房间类别(初中高) */
        roomKind: number;
        /** 额外数据 */
        extraData: any;
    }

    /** common 缓存 table */
    export interface StorageTable {
        common: StorageTableInfo;
    }

    export let storage: we.kit.Storage<StorageTable>;

    /** 扩展sys Storeage 类型定义 */
    export interface StorageSysTable extends we.core.StorageTable {
        sys: we.core.StorageTable['sys'] & {
            /** 账号记录 */
            user_account_record: IAccountInfo[];
        };
    }

    /**
     * UI锁类型定义
     */
    export class CoroutineLockType {
        static readonly CoroutineLockType_Min = 41001;
        /**
         * Scene 入口锁
         */
        static readonly SceneEntry = 41002;

        static readonly CoroutineLockType_Max = 42000;
    }

    export enum GameEvent {
        /** 余额不足，提示用户是否充值 */
        Recharge = 1,
    }

    /** 登陆账号信息 */
    export interface IAccountInfo {
        /** 用户 id */
        userId: number;
        /** 电话号码 */
        phoneNum: string;
        /** 邮箱 */
        email: string;
        /** 密码 */
        password: string;
    }
}

// 默认初始化 default, 登录成功后重新赋值为 userid
CommonType.storage = new we.kit.Storage<CommonType.StorageTable>(`${we.bundles.common}:default`);
we.common.storage = CommonType.storage;

we.common.type = CommonType;
