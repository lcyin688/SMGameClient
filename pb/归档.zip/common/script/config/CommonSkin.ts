declare global {
    interface ICommon {
        /** 皮肤 */
        skin: typeof CommonSkin;
    }
}

/**
 * 皮肤差异配置
 */
interface ICommonSkinConfig {
    /** 默认缺省值 */
    template?: string;
    /** 提示内容特殊标注颜色 */
    color: {
        /** 提示 */
        tips: string;
        /** 警告 */
        warn: string;
        /** 禁止 */
        ban: string;
    };
    /** 其余自定义配置 */
    [key: string]: any;
}

const skin_cfg_bg: ICommonSkinConfig = {
    color: {
        tips: '#ffd802',
        warn: '#faa326',
        ban: '#ee8c5b',
    },
};

const skin_cfg_bg2: ICommonSkinConfig = {
    color: {
        tips: '#ffd802',
        warn: '#faa326',
        ban: '#ee8c5b',
    },
};

const skin_cfg_ct: ICommonSkinConfig = {
    color: {
        tips: '#ffd802',
        warn: '#ffa00b',
        ban: '#ff6d34',
    },
};

const skin_cfg_ct2: ICommonSkinConfig = {
    color: {
        tips: '#f6ff02',
        warn: '#8ff23f',
        ban: '#ffdc73',
    },
};

const skin_cfg_ct3: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};

const skin_cfg_ct4: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};

const skin_cfg_cm1: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};

const skin_cfg_cm2: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};

const skin_cfg_cm3: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};

const skin_cfg_cm4: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};
const skin_cfg_cm5: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};
const skin_cfg_cm6: ICommonSkinConfig = {
    color: {
        tips: '#f79c31',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};

const skin_cfg_as: ICommonSkinConfig = {
    color: {
        tips: '#ff772a',
        warn: '#ff772a',
        ban: '#e92a55',
    },
};

const skin_cfg_rs: ICommonSkinConfig = {
    color: {
        tips: '#f79c31',
        warn: '#06afaf',
        ban: '#e92a55',
    },
};

const CommonSkinConfig: Readonly<{ [key in keyof typeof we.core.SkinCode]: ICommonSkinConfig }> = {
    [we.core.SkinCode.bg]: skin_cfg_bg,
    [we.core.SkinCode.bg2]: skin_cfg_bg2,
    [we.core.SkinCode.ct]: skin_cfg_ct,
    [we.core.SkinCode.ct2]: skin_cfg_ct2,
    [we.core.SkinCode.ct3]: skin_cfg_ct3,
    [we.core.SkinCode.ct4]: skin_cfg_ct4,
    [we.core.SkinCode.cm1]: skin_cfg_cm1,
    [we.core.SkinCode.cm2]: skin_cfg_cm2,
    [we.core.SkinCode.cm3]: skin_cfg_cm3,
    [we.core.SkinCode.cm4]: skin_cfg_cm4,
    [we.core.SkinCode.cm5]: skin_cfg_cm5,
    [we.core.SkinCode.cm6]: skin_cfg_cm6,
    [we.core.SkinCode.as]: skin_cfg_as,
    [we.core.SkinCode.rs]: skin_cfg_rs,
};

export default class CommonSkin {
    /**
     * 皮肤差异配置
     */
    public static get config(): ICommonSkinConfig {
        return CommonSkinConfig[we.core.flavor.getSkinCode()];
    }
}

we.common.skin = CommonSkin;
