/** 背景资源 uuid */
const backGroundSPFUuid = '0496bffe-7565-4a06-8d87-e90d42b9ecc8';

/** 输入后 label 节点字体 uuid */
const textFontUuid = '451e04f1-11e0-4633-9ee8-4ca76f704b19';

/** 输入后 label 节点颜色 #ffffff */
const textFromHEX = '#ffffff';

/** 预填充 label 节点字体 uuid */
const placeholderFontUuid = '451e04f1-11e0-4633-9ee8-4ca76f704b19';

/** 预填充 label 节点颜色 #ffffff */
const placeholderFromHEX = '#81c2ff';

const { ccclass, disallowMultiple, executeInEditMode, property, menu, requireComponent } = cc._decorator;

@ccclass()
@executeInEditMode
@disallowMultiple
@requireComponent(cc.EditBox)
@menu('皮肤样式/cm3 输入框')
export class Cm3EditBox extends cc.Component {
    private _editBox: cc.EditBox = null;

    private backGroundSpr: cc.Sprite = null;
    private textLabel: cc.Label = null;
    private placeholderLabel: cc.Label = null;

    private isInit: boolean = false;

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        cc.warn('设置成功后 请删除此组建 Cm3EditBox ！！！');
    }

    protected onFocusInEditor(): void {
        if (CC_EDITOR) {
            this.updateStyle();
        }
    }

    onRestore(): void {
        if (CC_EDITOR) {
            this.updateStyle();
        }
    }

    private updateStyle(): void {
        if (!this.isInit) {
            this.isInit = true;

            this._editBox = this.node.getComponent(cc.EditBox);
            if (this._editBox) {
                this.backGroundSpr = this._editBox.background;
                this.textLabel = this._editBox.textLabel;
                this.placeholderLabel = this._editBox.placeholderLabel;

                this.setStyle();
            }
        } else {
            this.setStyle();
        }
    }

    private async setStyle() {
        // 设置背景
        if (this.backGroundSpr) {
            this.backGroundSpr.type == cc.Sprite.Type.SLICED;
            this.backGroundSpr.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            this.backGroundSpr.spriteFrame = await this.loadAssets(backGroundSPFUuid);
        }

        // 设置输入后风格
        if (this.textLabel) {
            this.textLabel.font = await this.loadAssets(textFontUuid);
            this.textLabel.node.color = new cc.Color().fromHEX(textFromHEX);
        }

        //  预览字体风格
        if (this.placeholderLabel) {
            this.placeholderLabel.font = await this.loadAssets(placeholderFontUuid);
            this.placeholderLabel.node.color = new cc.Color().fromHEX(placeholderFromHEX);
        }
    }

    private async loadAssets<T extends cc.Asset>(uuid: string): Promise<T> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                if (err) {
                    cc.error(`loadAssets with uuid(${uuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }
}
