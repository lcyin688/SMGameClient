const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

const FontUuid = '4a5c0e70-bfc3-406b-85b7-bba1ea315c58';

const CloseUuid = '54f0cc0c-5dcd-4a69-8975-4e3e46f81c58';

const ContentUuid = '46c2c869-a2b3-4aea-9ccc-c10f8b37a757';

class DialogStyleData {
    spriteUuid: string = '';
    /** 图片标题位置 */
    @property({ type: cc.Vec2 })
    sprTitlePos?: cc.Vec2 = null;
    /** 文字标题位置 */
    @property({ type: cc.Vec2 })
    labTitlePos?: cc.Vec2 = null;
    /** 关闭按钮位置 */
    @property({ type: cc.Vec2 })
    closePos?: cc.Vec2 = null;
    /** content_bg 大小 */
    @property({ type: cc.Size })
    content_size: cc.Size = null;
    /** contebt_bg 位置 */
    @property({ type: cc.Vec2 })
    content_pos: cc.Vec2 = null;
}

enum BG_SIZE {
    small = 0,
    middle = 1,
    big = 2,
}

enum TITLE_TYPE {
    sprite = 0,
    lable = 1,
}

const DialogStyle: { [key: number]: DialogStyleData } = {
    [BG_SIZE.small]: {
        spriteUuid: 'eb033e79-ac92-4d3a-8258-07eb0171b31a',
        sprTitlePos: cc.v2(0, 230),
        labTitlePos: cc.v2(0, 230),
        closePos: cc.v2(0, -340),
        content_size: cc.size(640, 304),
        content_pos: cc.v2(0, -25),
    },
    [BG_SIZE.middle]: {
        spriteUuid: '8ed5134f-4339-45e8-9f4f-f1f602a18b66',
        sprTitlePos: cc.v2(0, 330),
        labTitlePos: cc.v2(0, 330),
        closePos: cc.v2(0, -435),
        content_size: cc.size(640, 400),
        content_pos: cc.v2(0, -25),
    },
    [BG_SIZE.big]: {
        spriteUuid: 'c3d50cbb-7165-4fbd-920c-b2ed3bccf420',
        sprTitlePos: cc.v2(0, 520),
        labTitlePos: cc.v2(0, 520),
        closePos: cc.v2(0, -560),
        content_size: cc.size(640, 968),
        content_pos: cc.v2(0, -25),
    },
};

const LableTitleStyle = {
    fontSize: 60,
    coverEnableOutline: true,
    coverOutlineSize: 2,
    coverOutlineColor: cc.color().fromHEX('#250060'),
    GradientColors: [cc.color().fromHEX('#fffbfe'), cc.color().fromHEX('#fffbfe')],
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm4 弹窗')
export class Cm4Dialog extends cc.Component {
    @property
    private _size: BG_SIZE = BG_SIZE.small;
    @property({ type: cc.Enum(BG_SIZE), tooltip: CC_DEV && '背景大小' })
    get size(): BG_SIZE {
        return this._size;
    }
    set size(size: BG_SIZE) {
        if (this._size === size) {
            return;
        }
        this._size = size;
        this.updateBg();
    }

    @property
    private _titleType: TITLE_TYPE = TITLE_TYPE.lable;
    @property({ type: cc.Enum(TITLE_TYPE), tooltip: CC_DEV && '标题类型：sprite｜lable' })
    get titleType(): TITLE_TYPE {
        return this._titleType;
    }
    set titleType(type: TITLE_TYPE) {
        if (this._titleType === type) {
            return;
        }
        this._titleType = type;
        this.updateTitle();
    }

    onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        cc.warn('设置成功后 请删除此组建 Cm4Dialog ！！！');
    }

    async updateBg() {
        if (!CC_EDITOR) {
            return;
        }

        // bg
        this.node.setPosition(0, 0);
        const bg = this.nodeAddComponent(this.node, cc.Sprite);
        bg.spriteFrame = await this.loadSpriteFrame(DialogStyle[this._size].spriteUuid);
        bg.type = cc.Sprite.Type.SLICED;
        bg.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // RC_btn_close
        let btnClose = this.node.getChildByName('RC_btnClose');
        let btnButton = null;
        let icon = null;
        if (!btnClose) {
            btnClose = new cc.Node('RC_btnClose');
            btnButton = btnClose.addComponent(cc.Button);
            icon = new cc.Node('icon');
            icon.addComponent(cc.Sprite);
            icon.parent = btnClose;
        } else {
            btnButton = btnClose.getComponent(cc.Button);
            icon = btnClose.getChildByName('icon');
        }
        btnClose.setContentSize(new cc.Size(80, 80));
        icon.getComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(CloseUuid);
        btnButton.transition = cc.Button.Transition.SCALE;
        btnButton.zoomScale = 0.9;
        btnClose.parent = this.node;
        btnClose.setPosition(DialogStyle[this._size].closePos);

        // content bg
        let content_bg: cc.Node | null = null;
        if (!this.node.getChildByName('content_bg')) {
            content_bg = new cc.Node('content_bg');
        } else {
            content_bg = this.node.getChildByName('content_bg');
        }
        const content_bg_sp = content_bg.addComponentUnique(cc.Sprite);
        content_bg_sp.spriteFrame = await this.loadSpriteFrame(ContentUuid);
        content_bg_sp.type = cc.Sprite.Type.SLICED;
        content_bg_sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        content_bg.setPosition(DialogStyle[this._size].content_pos);
        content_bg.setContentSize(DialogStyle[this._size].content_size);
        content_bg.parent = this.node;

        let title = this.node.getChildByName('RC_title');
        if (title) {
            title.setPosition(DialogStyle[this._size].labTitlePos);
        }
    }

    async updateTitle() {
        let title = this.node.getChildByName('RC_title');
        if (title) {
            this.node.removeChild(title);
        }
        title = new cc.Node('RC_title');
        if (this._titleType == TITLE_TYPE.sprite) {
            const title_spr = title.addComponent(cc.Sprite);
            title.addComponent(we.ui.WEI18nSprite);
            title.setPosition(DialogStyle[this._size].sprTitlePos);
            title.parent = this.node;
        } else {
            title.removeAllChildren();
            const title_label = title.addComponent(cc.Label);
            title_label.fontSize = LableTitleStyle.fontSize;
            title_label.lineHeight = LableTitleStyle.fontSize;
            title_label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            title_label.font = await this.loadFont(FontUuid);
            title_label.cacheMode = cc.Label.CacheMode.BITMAP;
            const title_outline = title.addComponent(cc.LabelOutline);
            title_outline.width = LableTitleStyle.coverOutlineSize;
            title_outline.color = LableTitleStyle.coverOutlineColor;
            const title_outline_color = title_outline.addComponent(we.ui.WEColorAssembler);
            title_outline_color.colors = LableTitleStyle.GradientColors;

            title.parent = this.node;
            title.setPosition(DialogStyle[this._size].labTitlePos);
            title_label.addComponent('WEI18nLabelFull');
            title_label.string = 'Dlg Title';
        }
    }

    async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.updateBg();
        this.updateTitle();
    }
}
