const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255.255);
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 红色样式 */
    Red,
}

enum ButtonSizeStyleEnum {
    Small,
    Medium,
    Big,
}

const fontUuid = 'ebd308da-0f0e-44cd-8c13-a9891413824c';
const fontSize = [24, 28, 36];
const outlineSize = 3;

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['a46dd99c-1bc6-4cc7-8e2a-ab18d0c6405a', 'f3ed2ccb-cb84-43b8-aba8-f65a6c040e0a', 'adb7ab86-cc09-49b4-8ec7-48494caedf85'],
        fontColor: cc.color().fromHEX('#ffffff'),
        outlineColor: cc.color().fromHEX('#1730a4'),
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['12ee59ff-df55-4d27-9cae-6d33543d0faa', '19832a1d-90d2-4230-b509-00fe9b9d09f6', '9ea020c0-4b51-4781-8775-446ee232dc23'],
        fontColor: cc.color().fromHEX('#ffffff'),
        outlineColor: cc.color().fromHEX('#136100'),
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['06a3542e-8908-420e-aca8-acaa655c8d1a', '2015f80b-43b3-43ac-b020-71f9a6a07e4a', '7f5d99f4-7c59-442f-89db-ae4dc326794a'],
        fontColor: cc.color().fromHEX('#ece0e0'),
        outlineColor: cc.color().fromHEX('#582038'),
    },
    [ButtonColorStyleEnum.Red]: {
        spriteUuid: ['90e1008b-6f97-416c-ada6-8ef99991941f', 'ac08cb1f-49f4-48b8-a415-b3c70bd3e9f1', '906f52d1-8af5-43af-95a6-3a6eadc0d60f'],
        fontColor: cc.color().fromHEX('#ffffff'),
        outlineColor: cc.color().fromHEX('#61002e'),
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct2 按钮')
export class Ct2Button extends cc.Component {
    static readonly Styles = ButtonColorStyleEnum;

    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    private sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    private label: cc.Label = null;

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        visible: function () {
            return !this._useCustomStyle;
        },
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }

        this._style = style;
        this.updateStyle();
    }

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        visible: function () {
            return !this._useCustomStyle;
        },
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }

        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  //////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        if (!CC_EDITOR) {
            return;
        }

        this.sprite = this.node.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.node.addComponent(cc.Sprite);
        }

        this.label = this.node.getComponentInChildren(cc.Label);
        if (!this.label) {
            let label = new cc.Node('desc');
            label.parent = this.node;
            this.label = label.addComponent(cc.Label);
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        const conf = ButtonStyles[this._style];

        // sprite
        this.sprite.spriteFrame = await this.loadSpriteFrame(conf);
        this.sprite.type = cc.Sprite.Type.SIMPLE;
        this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // label
        this.label.font = await this.loadFont();
        this.label.node.setPosition(0, 3);
        this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.label.overflow = cc.Label.Overflow.SHRINK;
        this.label.enableWrapText = false;
        this.label.node.width = this.sprite.node.width - 36;
        this.label.node.height = this.sprite.node.height - 20;

        const size = fontSize[this.size];
        this.label.fontSize = size;
        this.label.lineHeight = size + 6;

        this.label.node.color = conf.fontColor;
        const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
        outLine.width = outlineSize;
        outLine.color = conf.outlineColor;
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }
}
