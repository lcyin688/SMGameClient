const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

const FontUuid = '5a864013-6a00-457d-8804-1ee0e52599ef';

const CloseUuid = '587e73ec-b2ff-411e-9a1e-09d0e701a89c';

const CommonUuid = '59925d3d-e8fb-47eb-a7ad-532d77d9ebd5';

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/as 弹窗')
export class Ct4Dialog extends cc.Component {
    onLoad() {
        cc.warn('设置成功后 请删除此组建 AsDialog ！！！');
    }

    async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        // bg
        this.node.setPosition(0, 0);
        const nodesToRemove: cc.Node[] = [];
        let i = 0;
        let isContent = false;
        const traverseAndCheck = (node: cc.Node) => {
            if (node.getComponent(cc.Sprite)) {
                nodesToRemove.push(node);
                if (i === 0) {
                    isContent = true;
                }
                i++;
            }
            node.children.forEach(traverseAndCheck);
        };
        traverseAndCheck(this.node);
        nodesToRemove.forEach((node) => {
            if (nodesToRemove.indexOf(node) === 0 && isContent) {
                isContent = false;
            } else {
                node.parent?.removeChild(node);
            }
        });
        let bg = null;
        if (this.node.getComponent(cc.Sprite)) {
            bg = this.node.getComponent(cc.Sprite);
        } else {
            bg = this.node.addComponent(cc.Sprite);
        }

        bg.spriteFrame = await this.loadSpriteFrame(CommonUuid);
        bg.type = cc.Sprite.Type.SLICED;
        bg.sizeMode = cc.Sprite.SizeMode.TRIMMED;
        bg.node.width = 681;

        // RC_title
        let title = this.node.getChildByName('RC_title');
        if (title) {
            this.node.removeChild(title);
        }
        title = new cc.Node('RC_title');
        title.scale = 0.77;
        const title_label = title.addComponent(cc.Label);
        title_label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        title_label.font = await this.loadFont(FontUuid);
        title_label.fontSize = 52;
        title_label.overflow = cc.Label.Overflow.SHRINK;
        title.width = 800;
        title.height = 108;
        title.parent = this.node;
        title_label.string = 'Dlg Title';
        const title_w = title.addComponent(cc.Widget);
        title_w.isAlignTop = true;
        title_w.top = 10;

        // RC_btn_close
        let btnClose = this.node.getChildByName('RC_btnClose');
        if (btnClose) {
            this.node.removeChild(btnClose);
        }
        btnClose = new cc.Node('RC_btnClose');
        btnClose.setContentSize(new cc.Size(85, 85));
        btnClose.parent = this.node;
        const icon = new cc.Node('icon');
        icon.addComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(CloseUuid);
        icon.parent = btnClose;
        const close_w = btnClose.addComponent(cc.Widget);
        close_w.isAlignTop = true;
        close_w.isAlignRight = true;
        close_w.right = 10;
        close_w.top = 10;
    }

    async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.updateStyle();
    }
}
