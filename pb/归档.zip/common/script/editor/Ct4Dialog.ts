const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

const FontUuid = '7c169ac7-6d08-4e78-9838-3e5380eb4c9c';

const CloseUuid = 'ac75e4c6-e35b-4b94-b241-17dfa455eea4';

const CommonUuid = 'a771989c-53c5-46a2-86d3-24830e79ba23';

const TopLineBg = '33a9a8f5-6635-4399-8728-366f3c2d5a8f';

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct4 弹窗')
export class Ct4Dialog extends cc.Component {
    onLoad() {
        cc.warn('设置成功后 请删除此组建 Ct4Dialog ！！！');
    }

    async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        if (this.node.getChildByName('top_bg')) {
            return;
        }

        // bg
        this.node.setPosition(0, 0);
        const bg = this.nodeAddComponent(this.node, cc.Sprite);
        bg.spriteFrame = await this.loadSpriteFrame(CommonUuid);
        bg.type = cc.Sprite.Type.SLICED;
        bg.sizeMode = cc.Sprite.SizeMode.TRIMMED;
        bg.node.width = 681;

        // top_bg
        const topBg = new cc.Node('top_bg');
        topBg.addComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(TopLineBg);
        const top_bg_w = topBg.addComponent(cc.Widget);
        top_bg_w.isAlignTop = true;
        top_bg_w.top = 0;
        top_bg_w.updateAlignment();
        topBg.parent = this.node;
        topBg.zIndex = 0;
        topBg.setSiblingIndex(0);

        // RC_title
        const title = new cc.Node('RC_title');
        title.scale = 0.77;
        const title_label = title.addComponent(cc.Label);
        title_label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        title_label.font = await this.loadFont(FontUuid);
        title_label.fontSize = 78;
        title_label.overflow = cc.Label.Overflow.SHRINK;
        title.width = 800;
        title.height = 108;
        const title_shader = title.addComponent(cc.LabelShadow);
        title_shader.blur = 2;
        title_shader.offset = new cc.Vec2(0, -3);
        title_shader.color = cc.color().fromHEX('#914be7');
        const title_color = title.addComponent(we.ui.WEColorAssembler);
        title_color.colors = [cc.color().fromHEX('#fef5c2'), cc.color().fromHEX('#ffe751')];
        title.parent = topBg;
        title_label.string = 'Dlg Title';

        // RC_btn_close
        const btnClose = new cc.Node('RC_btnClose');
        btnClose.setPosition(292, -4);
        btnClose.setContentSize(new cc.Size(50, 50));
        btnClose.parent = topBg;

        const icon = new cc.Node('icon');
        icon.addComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(CloseUuid);
        icon.parent = btnClose;
    }

    async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.updateStyle();
    }
}
