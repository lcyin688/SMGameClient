const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字号 */
    @property()
    fontSize: number[] = [24, 28, 36];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255, 255);
    /** 文字描边 */
    @property()
    enableOutline: boolean = true;
    /** 描边 */
    @property()
    outlineSize: number = 3;
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字排版模式 */
    @property({ type: cc.Enum(cc.Label.Overflow) })
    Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
}

enum ButtonColorStyleEnum {
    /** 暗灰样式 */
    DarkGrey,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Yellow,
}

enum ButtonSizeStyleEnum {
    Big,
    Medium,
    Small,
}

/** 按钮统一字体 */
const fontUuid = '5a864013-6a00-457d-8804-1ee0e52599ef';
/** 按钮统一字体大小 */
const fontSize = [32, 34, 24];
/** 字体颜色统一 index: 0:黑色，1:白色，2:暗灰色*/
const fontColor: cc.Color[] = [cc.color().fromHEX('#101c13'), cc.color().fromHEX('#ffffff'), cc.color().fromHEX('#54595e')];
/** 是否启用描边 */
const enableOutline: boolean = false;
/** 描边大小 */
const outlineSize: number = 0;
/** 描边颜色 */
const outlineColor: cc.Color = cc.color(0, 0, 0, 0);
/** 字体类型 */
const Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
/** 渐变色（无渐变） */
const GradientColors: cc.Color[] = [];

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.DarkGrey]: {
        spriteUuid: ['108c2ed3-f6ef-476b-9aaa-573f2313044b', '19470077-7a0c-453f-804e-1d61db8f4440', '8b0bb74c-a446-45dc-bf1c-52307db085ba'],
        fontUuid: fontUuid,
        fontColor: fontColor[1],
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: outlineColor,
        Overflow: Overflow,
        GradientColors: GradientColors,
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['16ab0797-fe9e-440e-87f4-f1ab8e092568', '226d0332-c812-4c18-b6e1-f18c000693d0', 'b8ed7534-c8a5-499c-a9cd-aad3090a7256'],
        fontUuid: fontUuid,
        fontColor: fontColor[0],
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: outlineColor,
        Overflow: Overflow,
        GradientColors: GradientColors,
    },
    [ButtonColorStyleEnum.Yellow]: {
        spriteUuid: ['cccf2ae9-2123-4d55-b8a8-462810b53d34', '9047de39-8114-400e-8964-9171f26ac9d8', 'd8478678-a488-4b42-b4d2-b630472e83ed'],
        fontUuid: fontUuid,
        fontColor: fontColor[0],
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: outlineColor,
        Overflow: Overflow,
        GradientColors: GradientColors,
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['a9382154-cf22-4ed6-a7d9-3448f354e247', 'e1781a28-9a51-49c0-b87e-d3a0bff878dd', '6ecbd4a7-16e9-4b59-813d-562c2200d152'],
        fontUuid: fontUuid,
        fontColor: fontColor[2],
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: outlineColor,
        Overflow: Overflow,
        GradientColors: GradientColors,
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/as 按钮')
export class AsButton extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Yellow;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        this.sprite = this.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.getComponentInChildren(cc.Sprite);
            if (!this.sprite) {
                this.sprite = this.node.addComponent(cc.Sprite);
            }
        }

        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let lab = new cc.Node();
            lab.name = 'label';
            lab.parent = this.node;
            this.label = lab.addComponent(cc.Label);
            this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        cc.warn('设置成功后 请删除此组建 AsButton ！！！');

        if (!CC_EDITOR && this.label && this.label.node.scale == this.labelScale) {
            return;
        }

        const styleData = ButtonStyles[this._style];

        // bg
        if (CC_EDITOR && this.sprite) {
            this.sprite.type == cc.Sprite.Type.SIMPLE;
            this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.sprite.spriteFrame = await this.loadSpriteFrame(styleData);
        }

        // label
        if (this.label) {
            if (CC_EDITOR) {
                this.label.font = await this.loadFont(styleData);
            }

            this.label.node.setPosition(0, 0);
            this.label.node.scale = this.labelScale;
            this.label.enableWrapText = false;

            if (styleData.fontColor) {
                this.label.node.color = styleData.fontColor;
            }

            if (styleData.fontSize) {
                const fontSize = Math.ceil(styleData.fontSize[this.size] / this.labelScale);
                this.label.fontSize = fontSize;
                this.label.lineHeight = fontSize + 2;
            }

            if (styleData.enableOutline) {
                const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
                if (styleData.outlineSize) {
                    outLine.width = styleData.outlineSize;
                }
                if (styleData.outlineColor) {
                    outLine.color = styleData.outlineColor;
                }
            } else {
                this.label.node.removeComponent(cc.LabelOutline);
            }

            if (styleData.GradientColors?.length > 0) {
                const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
                colorAssembler.colors = styleData.GradientColors;
            } else {
                this.label.node.removeComponent(we.ui.WEColorAssembler);
            }

            // 移除阴影效果
            this.label.node.removeComponent(cc.LabelShadow);

            this.label.overflow = styleData.Overflow;
            if (styleData.Overflow === cc.Label.Overflow.SHRINK) {
                this.label.node.width = (this.sprite.node.width - 50) * 1.65;
                this.label.node.height = (this.sprite.node.height - 30) * 1.65;
            }
        }
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${style.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }
}
