const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class DialogStyleData {
    font_size: number;
    title_pos: cc.Vec2;
    // outLine_width: number;
    close_pos: cc.Vec2;
    uuid_bg: string;
    uuid_close: string;
    uuid_font: string;
    content_size: cc.Size;
    content_pos: cc.Vec2;
}

enum SizeStyleEnum {
    Small,
    Medium,
    Big,
}

const ButtonStyles: { [key: number]: DialogStyleData } = {
    [SizeStyleEnum.Small]: {
        font_size: 56,
        title_pos: cc.v2(0, 206),
        close_pos: cc.v2(375, 194),
        uuid_bg: '4f3fd95c-b320-4fa8-bd88-0dbfc48c9cf9',
        uuid_close: 'ffac4762-a29b-4d3b-9f98-61a6deced6d4',
        uuid_font: '34b2847e-d5f8-427f-ba71-a17370c4830f',
        content_size: cc.size(678, 321),
        content_pos: cc.v2(0, -34),
    },
    [SizeStyleEnum.Medium]: {
        font_size: 61,
        title_pos: cc.v2(0, 245),
        close_pos: cc.v2(477, 234),
        uuid_bg: '32042078-90a2-49b1-84bb-8e70490613c6',
        uuid_close: 'ffac4762-a29b-4d3b-9f98-61a6deced6d4',
        uuid_font: '34b2847e-d5f8-427f-ba71-a17370c4830f',
        content_size: cc.size(864, 400),
        content_pos: cc.v2(0, -44),
    },
    [SizeStyleEnum.Big]: {
        font_size: 64,
        title_pos: cc.v2(0, 255),
        close_pos: cc.v2(604, 247),
        uuid_bg: '6142b52d-6d5c-4ac3-9b27-1f816a3e3291',
        uuid_close: 'ffac4762-a29b-4d3b-9f98-61a6deced6d4',
        uuid_font: '34b2847e-d5f8-427f-ba71-a17370c4830f',
        content_size: cc.size(1111, 420),
        content_pos: cc.v2(0, -32),
    },
};

const uuid_content_bg = '6663826e-b90c-4f4b-83eb-7e8f1af1defd';

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm6 弹窗')
export class Cm6Dialog extends cc.Component {
    /** 使用哪种内置大小 */
    @property
    private _size: SizeStyleEnum = SizeStyleEnum.Small;
    @property({ type: cc.Enum(SizeStyleEnum), tooltip: CC_DEV && '弹窗尺寸' })
    get size(): SizeStyleEnum {
        return this._size;
    }
    set size(style: SizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    protected onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        cc.warn('设置成功后 请删除此组建 Cm6Dialog ！！！');
    }

    async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        const data = ButtonStyles[this._size];

        // bg
        this.node.setPosition(0, 0);
        const bg = this.node.addComponentUnique(cc.Sprite);
        bg.spriteFrame = await this.loadSpriteFrame(data.uuid_bg);
        bg.type = cc.Sprite.Type.SLICED;
        bg.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // RC_title
        let title: cc.Node | null = null;
        if (this.node.getChildByName('RC_title')) {
            title = this.node.getChildByName('RC_title');
        } else {
            title = new cc.Node('RC_title');
        }
        title.setAnchorPoint(0.5, 0.5);
        const title_color = title.addComponentUnique(we.ui.WEColorAssembler);

        const title_label = title.addComponentUnique(cc.Label);
        const title_shadow = title.addComponentUnique(cc.LabelShadow);
        title_label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        title_label.overflow = cc.Label.Overflow.NONE;
        title_label.fontSize = data.font_size;
        title_label.lineHeight = 60;
        title_label.font = await this.loadFont(data.uuid_font);
        title_color.colors = [cc.color().fromHEX('#ddbc6d'), cc.color().fromHEX('#fafacc')];
        title_shadow.color = cc.color().fromHEX('#000000');
        title_shadow.offset = cc.v2(0, -3);
        title_shadow.blur = 3;

        title.setPosition(data.title_pos);
        title.parent = this.node;
        title.setSiblingIndex(0);

        title_label.string = 'Dlg Title';

        // content bg
        let content_bg: cc.Node | null = null;
        if (!this.node.getChildByName('content_bg')) {
            content_bg = new cc.Node('content_bg');
        } else {
            content_bg = this.node.getChildByName('content_bg');
        }
        const content_bg_sp = content_bg.addComponentUnique(cc.Sprite);
        content_bg_sp.spriteFrame = await this.loadSpriteFrame(uuid_content_bg);
        content_bg_sp.type = cc.Sprite.Type.SLICED;
        content_bg_sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        content_bg.setPosition(data.content_pos);
        content_bg.setContentSize(data.content_size);
        content_bg.parent = this.node;
        title.setSiblingIndex(2);

        // RC_btnClose
        let btnClose: cc.Node | null = null;
        if (this.node.getChildByName('RC_btnClose')) {
            btnClose = this.node.getChildByName('RC_btnClose');
        } else {
            btnClose = new cc.Node('RC_btnClose');
        }
        btnClose.setPosition(data.close_pos);
        btnClose.setContentSize(new cc.Size(100, 100));
        btnClose.parent = this.node;
        btnClose.setSiblingIndex(1);

        btnClose.removeAllChildren();

        // close icon
        const closeIcon = new cc.Node('icon');
        closeIcon.addComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(data.uuid_close);
        closeIcon.setPosition(0, 0);
        closeIcon.parent = btnClose;
    }

    // //////////////////////////////////////////// 其他方法 ////////////////////////////////////////////

    async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.updateStyle();
    }
}
