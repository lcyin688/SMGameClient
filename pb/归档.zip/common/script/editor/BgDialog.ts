const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

/**
 * 内容根节点: content
 * 关闭按钮: RC_btnClose
 *
 */

enum BG_SIZE {
    Small = 0,
    Middle = 1,
    Big = 2,
}

class DialogStyleData {
    contentBgUuid: string = '';
    /** 文字标题位置 */
    @property({ type: cc.Vec2 })
    titlePos?: cc.Vec2 = null;
    /** 关闭按钮位置 */
    @property({ type: cc.Vec2 })
    closePos?: cc.Vec2 = null;
}

/** 字体 uuid */
const fontUuid = '012b5c6f-a284-4d5b-8b75-5c45c2822f94';
/** 关闭按钮 icon uuid */
const closeUuid = '2cd6cb25-3988-413e-a4b6-0c41b52340aa';

/** title label */
const titleStyleConf = {
    fontSize: 30,
    contentSize: new cc.Size(290, 54),
    outlineSize: 2,
    outlineColor: cc.color().fromHEX('#bb7a0a'),
    shadowBlur: 14,
    shadowOffsetXY: [0, 0],
    shadowColor: cc.color().fromHEX('#000000'),
};

/** 弹窗配置 */
const dialogStyleConf: { [key: number]: DialogStyleData } = {
    [BG_SIZE.Small]: {
        titlePos: cc.v2(0, 154),
        closePos: cc.v2(286, 152),
        contentBgUuid: '560361ef-9287-4775-b1c3-84d418f72b6b',
    },
    [BG_SIZE.Middle]: {
        titlePos: cc.v2(0, 236),
        closePos: cc.v2(396, 234),
        contentBgUuid: 'b718fa4d-ab98-4fb5-8e72-14d2862761c4',
    },
    [BG_SIZE.Big]: {
        titlePos: cc.v2(0, 296),
        closePos: cc.v2(522, 296),
        contentBgUuid: '2057106c-c5ed-461e-ad9a-828cdf98989f',
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/bg 弹窗')
export class BgDialog extends cc.Component {
    @property
    private _size: BG_SIZE = BG_SIZE.Small;
    @property({ type: cc.Enum(BG_SIZE), tooltip: CC_DEV && '背景大小' })
    get size(): BG_SIZE {
        return this._size;
    }
    set size(size: BG_SIZE) {
        if (this._size === size) {
            return;
        }
        this._size = size;
        this.updateStyle();
    }

    private content: cc.Sprite = null;
    private btnClose: cc.Node = null;
    private closeIcon: cc.Sprite = null;
    private title: cc.Node = null;

    protected async onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);
        cc.warn('设置成功后 请删除此组建 BgDialog ！！！');

        this.content = this.node.getComponent(cc.Sprite);
        if (!this.content) {
            this.content = this.node.addComponent(cc.Sprite);
        }

        // close
        this.btnClose = this.node.getChildByName('RC_btnClose');
        if (!this.btnClose) {
            this.btnClose = new cc.Node('RC_btnClose');
            this.btnClose.addComponent(cc.Button);
        }
        this.btnClose.parent = this.node;
        this.btnClose.setContentSize(new cc.Size(60, 60));
        let btnButton = this.btnClose.getComponent(cc.Button);
        if (!btnButton) {
            btnButton = this.btnClose.addComponent(cc.Button);
        }
        btnButton.transition = cc.Button.Transition.SCALE;
        btnButton.zoomScale = 1.1;

        // close icon
        let icon = this.btnClose.getChildByName('icon');
        if (!icon) {
            icon = new cc.Node('icon');
            this.closeIcon = icon.addComponent(cc.Sprite);
            icon.parent = this.btnClose;
        }
        this.closeIcon = icon.getComponent(cc.Sprite);
        if (!this.closeIcon) {
            this.closeIcon = icon.addComponent(cc.Sprite);
        }

        // title
        this.title = this.node.getChildByName('title');
        if (!this.title) {
            this.title = new cc.Node('title');
            this.title.parent = this.node;
        }
        let titleLabel = this.title.getComponent(cc.Label);
        if (!titleLabel) {
            titleLabel = this.title.addComponent(cc.Label);
            titleLabel.string = 'Label';
        }
        titleLabel.font = await this.loadFont(fontUuid);
        titleLabel.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        titleLabel.verticalAlign = cc.Label.VerticalAlign.CENTER;
        titleLabel.overflow = cc.Label.Overflow.SHRINK;
        titleLabel.enableWrapText = true;
        titleLabel.fontSize = titleStyleConf.fontSize;
        titleLabel.lineHeight = titleStyleConf.fontSize + 2;
        this.title.setContentSize(titleStyleConf.contentSize);

        let outLine = this.title.getComponent(cc.LabelOutline);
        if (!outLine) {
            outLine = this.title.addComponent(cc.LabelOutline);
        }
        outLine.color = titleStyleConf.outlineColor;
        outLine.width = titleStyleConf.outlineSize;

        let shadow = this.title.getComponent(cc.LabelShadow);
        if (!shadow) {
            shadow = this.title.addComponent(cc.LabelShadow);
        }
        shadow.blur = titleStyleConf.shadowBlur;
        shadow.color = titleStyleConf.shadowColor;
        shadow.offset.x = titleStyleConf.shadowOffsetXY[0];
        shadow.offset.y = titleStyleConf.shadowOffsetXY[1];

        this.updateStyle();
    }

    private async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        let conf = dialogStyleConf[this.size];

        // bg
        this.node.setPosition(0, 0);
        this.content.spriteFrame = await this.loadSpriteFrame(conf.contentBgUuid);
        this.content.type = cc.Sprite.Type.SIMPLE;
        this.content.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // RC_btnClose
        this.btnClose.setPosition(conf.closePos);
        this.closeIcon.spriteFrame = await this.loadSpriteFrame(closeUuid);

        // title
        this.title.setPosition(conf.titlePos);
    }

    private async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    private async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }
}
