const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class DialogStyleData {
    spriteUuid: string = '';
    /** 文字标题位置 */
    @property({ type: cc.Vec2 })
    titlePos?: cc.Vec2 = null;
    /** 关闭按钮位置 */
    @property({ type: cc.Vec2 })
    closePos?: cc.Vec2 = null;
    /** content_bg 大小 */
    @property({ type: cc.Size })
    content_size: cc.Size = null;
    /** content_bg 位置 */
    @property({ type: cc.Vec2 })
    content_pos: cc.Vec2 = null;
}

enum BG_SIZE {
    Small = 0,
    Middle = 1,
    Big = 2,
}

const fontUuid = 'f67d0f8e-ad33-4746-a019-bea077216c52';
const closeUuid = 'b56af525-8f58-4cbb-8af2-d18b6c30af93';
const contentUuid = 'a7a1df59-1d06-4d03-abd9-669dd06ec9e0';

const DialogStyle: { [key: number]: DialogStyleData } = {
    [BG_SIZE.Small]: {
        spriteUuid: '9958beb3-ff80-4770-b359-3b14c17a6d7a',
        titlePos: cc.v2(0, 221),
        closePos: cc.v2(336, 220),
        content_size: cc.size(700, 300),
        content_pos: cc.v2(0, -25),
    },
    [BG_SIZE.Middle]: {
        spriteUuid: '9aedb727-629f-4719-9fef-4e81e667b738',
        titlePos: cc.v2(0, 269),
        closePos: cc.v2(424, 269),
        content_size: cc.size(900, 340),
        content_pos: cc.v2(0, -25),
    },
    [BG_SIZE.Big]: {
        spriteUuid: '514c5a2e-9e4c-40c1-95b2-9c3dd08af1c2',
        titlePos: cc.v2(0, 280),
        closePos: cc.v2(504, 280),
        content_size: cc.size(1000, 400),
        content_pos: cc.v2(0, -25),
    },
};

const LabelTitleStyle = {
    fontSize: 50,
    coverOutlineSize: 4,
    coverOutlineColor: cc.color().fromHEX('#4769d4'),
    GradientColors: [cc.color().fromHEX('#ffffff'), cc.color().fromHEX('#dbf4ff')],
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm3 弹窗')
export class Cm3Dialog extends cc.Component {
    @property
    private _size: BG_SIZE = BG_SIZE.Small;
    @property({ type: cc.Enum(BG_SIZE), tooltip: CC_DEV && '背景大小' })
    get size(): BG_SIZE {
        return this._size;
    }
    set size(size: BG_SIZE) {
        if (this._size === size) {
            return;
        }
        this._size = size;
        this.updateStyle();
    }

    private content: cc.Sprite = null;
    private content_bg: cc.Sprite = null;
    private btnClose: cc.Button = null;
    private title: cc.Label = null;

    protected onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);
        if (!CC_EDITOR) {
            return;
        }

        this.content = this.nodeAddComponent(this.node, cc.Sprite);
        let content_bg = this.node.getChildByName('content_bg');
        if (!content_bg) {
            content_bg = new cc.Node('content_bg');
            content_bg.parent = this.node;
        }
        this.content_bg = this.nodeAddComponent(content_bg, cc.Sprite);

        let btnClose = this.node.getChildByName('RC_btnClose');
        if (!btnClose) {
            btnClose = new cc.Node('RC_btnClose');
            btnClose.parent = this.node;
        }
        this.btnClose = this.nodeAddComponent(btnClose, cc.Button);

        let title = this.node.getChildByName('RC_title');
        if (!title) {
            title = new cc.Node('RC_title');
            title.parent = this.node;
            title.addComponentUnique(cc.Label).string = 'Dlg Title';
        }
        this.title = this.nodeAddComponent(title, cc.Label);

        this.updateStyle();
    }

    private async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }
        cc.warn('设置成功后 请删除此组建 Cm3Dialog ！！！');

        // bg
        this.node.setPosition(0, 0);
        this.content.spriteFrame = await this.loadSpriteFrame(DialogStyle[this._size].spriteUuid);
        this.content.type = cc.Sprite.Type.SIMPLE;
        this.content.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // content bg
        this.content_bg.type = cc.Sprite.Type.SLICED;
        this.content_bg.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.content_bg.spriteFrame = await this.loadSpriteFrame(contentUuid);
        this.content_bg.node.setPosition(DialogStyle[this._size].content_pos);
        this.content_bg.node.setContentSize(DialogStyle[this._size].content_size);

        // RC_btnClose
        this.btnClose.node.setPosition(DialogStyle[this._size].closePos);
        this.btnClose.node.setContentSize(new cc.Size(90, 70));
        this.btnClose.transition = cc.Button.Transition.SCALE;
        this.btnClose.zoomScale = 0.9;
        let icon = this.btnClose.node.getChildByName('icon');
        if (!icon) {
            icon = new cc.Node('icon');
            icon.parent = this.btnClose.node;
        }
        let iconSpr = this.nodeAddComponent(icon, cc.Sprite);
        iconSpr.type = cc.Sprite.Type.SIMPLE;
        iconSpr.sizeMode = cc.Sprite.SizeMode.TRIMMED;
        iconSpr.spriteFrame = await this.loadSpriteFrame(closeUuid);

        // title
        this.title.font = await this.loadFont(fontUuid);
        this.title.node.setPosition(DialogStyle[this._size].titlePos);
        this.title.fontSize = LabelTitleStyle.fontSize;
        this.title.lineHeight = LabelTitleStyle.fontSize;
        this.title.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.title.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.title.cacheMode = cc.Label.CacheMode.BITMAP;

        const title_outline = this.nodeAddComponent(this.title.node, cc.LabelOutline);
        title_outline.width = LabelTitleStyle.coverOutlineSize;
        title_outline.color = LabelTitleStyle.coverOutlineColor;

        const title_outline_color = this.nodeAddComponent(this.title.node, we.ui.WEColorAssembler);
        title_outline_color.colors = LabelTitleStyle.GradientColors;
    }

    private async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    private async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }
}
