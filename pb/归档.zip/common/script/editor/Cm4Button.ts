const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字号 */
    @property()
    fontSize: number[] = [24, 28, 36];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字描边 */
    @property()
    enableOutline: boolean = true;
    /** 描边 */
    @property()
    outlineSize: number = 3;
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字排版模式 */
    @property({ type: cc.Enum(cc.Label.Overflow) })
    Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 红色样式 */
    Red,
}

enum ButtonSizeStyleEnum {
    Big,
    Medium,
    Small,
    X_Small,
}

/** 按钮使用字体统一 */
const fontUuid = '4a5c0e70-bfc3-406b-85b7-bba1ea315c58';
/** 预览效果实际大小 */
const fontSize = [42, 36, 28, 24];
/** 描边 */
const enableOutline = true;
const outlineSize = 2;

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['932ecadc-9e51-4467-838f-e0b696bec745', '5541cfcb-c75b-49f5-9cf4-a261bd8a6da5', 'd892c5e4-1583-467e-975a-11e46abe50c1', '80fda876-8eed-45b5-8f94-b9da0262ace2'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#170bab'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['3ff49181-a8d3-4be5-a64e-30a03a308ebe', 'f40fbee9-1598-41bb-9407-3a910fab551a', 'debe5bfe-b7c2-4c87-90c2-50a0fffcd029', 'e3313632-8fbb-4f84-b2b1-c30b64467789'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#193906'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['64c03dec-98ec-47df-b64c-816080072a3f', '1ab546c9-b154-4a8d-a487-07ce869ff338', '3f445758-8781-482d-aeee-2dc8eb4db92b', '6d16a7a6-79a8-4a00-814f-ff49ce36e22e'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#464646'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Red]: {
        spriteUuid: ['b24c744d-52c8-4943-a1b7-472a119d9c84', 'e14a5f12-d2cd-4733-a00b-f435906a003b', '4d02b93f-5989-4a95-a7ad-9e8eab1a5fba', 'fea382cb-a4de-42ad-90bf-24d5146eea53'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#590272'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm4 按钮')
export class Cm4Button extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        this.sprite = this.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.getComponentInChildren(cc.Sprite);
            if (!this.sprite) {
                this.sprite = this.node.addComponent(cc.Sprite);
            }
        }

        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let lab = new cc.Node();
            lab.name = 'label';
            lab.parent = this.node;
            this.label = lab.addComponent(cc.Label);
            this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        cc.warn('设置成功后 请删除此组建 Cm4Button ！！！');

        if (!CC_EDITOR && this.label && this.label.node.scale == this.labelScale) {
            return;
        }

        const styleData = ButtonStyles[this._style];

        // bg
        if (CC_EDITOR && this.sprite) {
            this.sprite.type == cc.Sprite.Type.SIMPLE;
            this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.sprite.spriteFrame = await this.loadSpriteFrame(styleData);
        }

        // label
        if (this.label) {
            if (CC_EDITOR) {
                this.label.font = await this.loadFont(styleData);
            }

            this.label.node.setPosition(0, 5);
            this.label.node.scale = this.labelScale;
            this.label.enableWrapText = false;

            if (styleData.fontColor) {
                this.label.node.color = styleData.fontColor;
            }

            if (styleData.fontSize) {
                const fontSize = Math.ceil(styleData.fontSize[this.size] / this.labelScale);
                this.label.fontSize = fontSize;
                this.label.lineHeight = fontSize + 2;
            }

            if (styleData.enableOutline) {
                const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
                if (styleData.outlineSize) {
                    outLine.width = styleData.outlineSize;
                }
                if (styleData.outlineColor) {
                    outLine.color = styleData.outlineColor;
                }
            }

            if (styleData.GradientColors?.length > 0) {
                const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
                colorAssembler.colors = styleData.GradientColors;
            }

            // 移除阴影效果
            this.label.node.removeComponent(cc.LabelShadow);

            this.label.overflow = styleData.Overflow;
            if (styleData.Overflow === cc.Label.Overflow.SHRINK) {
                this.label.node.width = (this.sprite.node.width - 50) * 1.65;
                this.label.node.height = (this.sprite.node.height - 30) * 1.65;
            }
        }
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${style.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }
}
