const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字号 */
    @property()
    fontSize: number[] = [24, 28, 36];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字描边 */
    @property()
    enableOutline: boolean = true;
    /** 描边 */
    @property()
    outlineSize: number[] = [3, 2];
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字排版模式 */
    @property({ type: cc.Enum(cc.Label.Overflow) })
    Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 紫色样式 */
    Purple,
    /** 红色样式 */
    Red,
}

enum ButtonSizeStyleEnum {
    Big,
    Small,
}

/** 按钮使用字体统一 */
const fontUuid = '012b5c6f-a284-4d5b-8b75-5c45c2822f94';
/** 预览效果实际大小 */
const fontSize = [36, 24];
/** 描边 */
const enableOutline = true;
const outlineSize = [3, 2];

const styleConf: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['2faa1f42-a803-4bd5-b84c-f0dac7b5b33d', 'cd3fee18-84fe-4e16-b8f3-711c892bac56'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#09366e'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['251550bd-9f50-4f8c-a073-bc72d504b5a9', '251550bd-9f50-4f8c-a073-bc72d504b5a9'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#336316'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Purple]: {
        spriteUuid: ['b1db82a4-c6fd-4f16-8192-2b1d2b42e2dc', '95c4fc26-957f-4cff-b102-c870b9a4e073'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#650570'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Red]: {
        spriteUuid: ['8b6a3b80-696a-4098-9126-169bb7fe58fa', 'ccfa3d0b-4c7f-4a82-a951-2898c1bbecdf'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#701305'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['3f08fdff-157c-4c75-8691-0fe06b6dbbc3', '8ab807ab-4505-4434-b377-518dbf588221'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#474a4d'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/bg 按钮')
export class BgButton extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Big;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        this.sprite = this.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.getComponentInChildren(cc.Sprite);
            if (!this.sprite) {
                this.sprite = this.node.addComponent(cc.Sprite);
            }
        }

        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let lab = new cc.Node();
            lab.name = 'label';
            lab.parent = this.node;
            this.label = lab.addComponent(cc.Label);
            this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        cc.warn('设置成功后 请删除此组建 BgButton ！！！');

        if (!CC_EDITOR && this.label && this.label.node.scale == this.labelScale) {
            return;
        }

        const styleData = styleConf[this._style];

        // bg
        if (CC_EDITOR && this.sprite) {
            this.sprite.type == cc.Sprite.Type.SIMPLE;
            this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.sprite.spriteFrame = await this.loadSpriteFrame(styleData);
        }

        // label
        if (this.label) {
            if (CC_EDITOR) {
                this.label.font = await this.loadFont(styleData);
            }

            this.label.node.setPosition(0, 0);
            this.label.node.scale = this.labelScale;
            this.label.enableWrapText = false;

            if (styleData.fontColor) {
                this.label.node.color = styleData.fontColor;
            }

            if (styleData.fontSize) {
                const fontSize = Math.ceil(styleData.fontSize[this.size] / this.labelScale);
                this.label.fontSize = fontSize;
                this.label.lineHeight = fontSize + 2;
            }

            if (styleData.enableOutline) {
                const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
                if (styleData.outlineSize) {
                    outLine.width = styleData.outlineSize[this._size];
                }
                if (styleData.outlineColor) {
                    outLine.color = styleData.outlineColor;
                }
            }

            if (styleData.GradientColors?.length >= 2) {
                const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
                colorAssembler.colors = styleData.GradientColors;
            }

            // 移除阴影效果
            this.label.node.removeComponent(cc.LabelShadow);

            this.label.overflow = styleData.Overflow;
            if (styleData.Overflow === cc.Label.Overflow.SHRINK) {
                this.label.node.width = (this.sprite.node.width - 20) * 1.65;
                this.label.node.height = (this.sprite.node.height - 30) * 1.65;
            }
        }
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${style.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }
}
