const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字号 */
    @property()
    fontSize: number[] = [44, 40, 30];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字描边 */
    @property()
    enableOutline: boolean = false;
    /** 描边 */
    @property()
    outlineSize: number = 3;
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字阴影 */
    @property()
    enableShadow: boolean = false;
    /** 阴影颜色 */
    @property()
    shadowColor: cc.Color = cc.color(255, 255, 255.255);
    /** 阴影方向 */
    @property()
    shadowPos: cc.Vec2 = cc.v2(0, 0);
    /** 阴影扩散 */
    @property()
    shadowBlur: number = 2;
    /** 文字排版模式 */
    @property({ type: cc.Enum(cc.Label.Overflow) })
    Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Orange,
    /** 红色样式 */
    Red,
}

enum ButtonSizeStyleEnum {
    Big,
    Medium,
    Small,
}

/** 按钮使用字体统一 */
const fontUuid = '6ec50e43-f8b9-4bf6-981b-33f9ce5cc32c';
/** 预览效果实际大小 */
const fontSize = [44, 40, 30];
/** 描边 */
const enableOutline = false;
const outlineSize = 2;
const shadowBlur = 1;
const enableShadow = true;
const shadowPos = cc.v2(0, -2);

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['501bfa91-568b-46a2-8b86-13cdb6ffcce7', '5dfba665-bff2-453c-bcc4-c30eb2c7f245', 'cc19b232-ff7e-4e62-8625-ef05088bf42c'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#1c3a75'),
        enableShadow: enableShadow,
        shadowColor: cc.color().fromHEX('#1c3a75'),
        shadowBlur: shadowBlur,
        shadowPos: shadowPos,
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['53214eb0-65a8-4360-adc7-716504b4cb87', 'df20f24d-ca69-48d3-a72a-d2226e144f46', '130b782f-860f-4ca0-be9c-8c5720a510b5'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#134d26'),
        enableShadow: enableShadow,
        shadowColor: cc.color().fromHEX('#134d26'),
        shadowBlur: shadowBlur,
        shadowPos: shadowPos,
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Orange]: {
        spriteUuid: ['af2092aa-fde9-4b27-8c04-a65e5d08f9f1', '6f58c574-2230-4496-89ad-98375264d7c2', '6dfef2ae-ba32-4e5b-994f-7367f7f17a7e'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#8c4613'),
        enableShadow: enableShadow,
        shadowColor: cc.color().fromHEX('#8c4613'),
        shadowBlur: shadowBlur,
        shadowPos: shadowPos,
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['a2ea6c05-d5c7-407c-9400-c4278661377d', '8f098fce-83c5-42d5-92c5-1419441de55c', '2d9cf796-0a73-419f-bdc9-71c971baecf0'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#3e4550'),
        enableShadow: enableShadow,
        shadowColor: cc.color().fromHEX('#3e4550'),
        shadowBlur: shadowBlur,
        shadowPos: shadowPos,
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
    [ButtonColorStyleEnum.Red]: {
        spriteUuid: ['2cd33907-1642-4d66-8282-dd31e26b89ec', '77ed1fc2-e608-476a-8397-a8329044334e', '7c18b196-319d-4752-9012-4723f913d3f9'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#8e1d5d'),
        enableShadow: enableShadow,
        shadowColor: cc.color().fromHEX('#8e1d5d'),
        shadowBlur: shadowBlur,
        shadowPos: shadowPos,
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm5 按钮')
export class Cm5Button extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        this.sprite = this.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.getComponentInChildren(cc.Sprite);
            if (!this.sprite) {
                this.sprite = this.node.addComponent(cc.Sprite);
            }
        }

        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let lab = new cc.Node();
            lab.name = 'label';
            lab.parent = this.node;
            this.label = lab.addComponent(cc.Label);
            this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        cc.warn('设置成功后 请删除此组建 Cm5Button ！！！');

        if (!CC_EDITOR && this.label && this.label.node.scale == this.labelScale) {
            return;
        }
        const styleData = ButtonStyles[this._style];

        // bg
        if (CC_EDITOR && this.sprite) {
            this.sprite.type == cc.Sprite.Type.SIMPLE;
            this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.sprite.spriteFrame = await this.loadSpriteFrame(styleData);
        }
        // label
        if (this.label) {
            if (CC_EDITOR) {
                this.label.font = await this.loadFont(styleData);
            }
            switch (this._size) {
                case ButtonSizeStyleEnum.Small:
                    this.label.node.setPosition(0, 5);
                    break;
                case ButtonSizeStyleEnum.Medium:
                case ButtonSizeStyleEnum.Big:
                default:
                    this.label.node.setPosition(0, 7);
                    break;
                    
            }
            this.label.node.scale = this.labelScale;
            this.label.enableWrapText = false;

            if (styleData.fontColor) {
                this.label.node.color = styleData.fontColor;
            }

            if (styleData.fontSize) {
                const fontSize = Math.ceil(styleData.fontSize[this.size] / this.labelScale);
                this.label.fontSize = fontSize;
                this.label.lineHeight = fontSize + 2;
            }

            if (styleData.enableOutline) {
                const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
                if (styleData.outlineSize) {
                    outLine.width = styleData.outlineSize;
                }
                if (styleData.outlineColor) {
                    outLine.color = styleData.outlineColor;
                }
            }else{
                // 移除描边效果
                this.label.node.removeComponent(cc.LabelOutline);
            }

            if (styleData.GradientColors.length > 0) {
                const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
                colorAssembler.colors = styleData.GradientColors;
            }else{
                // 移除渐变效果
                this.label.node.removeComponent(we.ui.WEColorAssembler);
            }

            if (styleData.enableShadow) {
                const shadow = this.nodeAddComponent(this.label.node, cc.LabelShadow);
                shadow.color = styleData.shadowColor;
                shadow.offset = styleData.shadowPos;
                shadow.blur = styleData.shadowBlur;
            } else {
                // 移除阴影效果
                this.label.node.removeComponent(cc.LabelShadow);
            }

            this.label.overflow = styleData.Overflow;
            if (styleData.Overflow === cc.Label.Overflow.SHRINK) {
                this.label.node.width = (this.sprite.node.width - 50) * 1.65;
                this.label.node.height = (this.sprite.node.height - 30) * 1.65;
            }
        }
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${style.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }
}
