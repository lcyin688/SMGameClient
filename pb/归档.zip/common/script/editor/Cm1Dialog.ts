const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class DialogStyleData {
    font_size: number;
    title_pos: cc.Vec2;
    outLine_width: number;
    close_pos: cc.Vec2;
    uuid_bg: string;
    uuid_close: string;
    uuid_font: string;
    content_size: cc.Size;
    content_pos: cc.Vec2;
}

enum SizeStyleEnum {
    Small,
    Medium,
    Big,
}

const ButtonStyles: { [key: number]: DialogStyleData } = {
    [SizeStyleEnum.Small]: {
        font_size: 52,
        outLine_width: 3,
        title_pos: cc.v2(-260, 210),
        close_pos: cc.v2(345, 208),
        uuid_bg: '783b8e89-ede2-4d98-9cf4-eb44ecfdba8e',
        uuid_close: 'ffdd68f5-38f7-4884-9890-7d827c03e0a6',
        uuid_font: '72a2c134-ca5d-4bee-9345-f2a220c6d2e5',
        content_size: cc.size(731, 312),
        content_pos: cc.v2(0, 0),
    },
    [SizeStyleEnum.Medium]: {
        font_size: 58,
        outLine_width: 3,
        title_pos: cc.v2(-325, 262),
        close_pos: cc.v2(433, 263),
        uuid_bg: 'f3b23ee3-a75d-4c7b-8f64-9627bf8bdd29',
        uuid_close: 'ffdd68f5-38f7-4884-9890-7d827c03e0a6',
        uuid_font: '72a2c134-ca5d-4bee-9345-f2a220c6d2e5',
        content_size: cc.size(914, 390),
        content_pos: cc.v2(0, 0),
    },
    [SizeStyleEnum.Big]: {
        font_size: 68,
        outLine_width: 3,
        title_pos: cc.v2(-450, 268),
        close_pos: cc.v2(565, 270),
        uuid_bg: '9bf64c09-3447-4920-84aa-e53d39649dbb',
        uuid_close: 'ffdd68f5-38f7-4884-9890-7d827c03e0a6',
        uuid_font: '72a2c134-ca5d-4bee-9345-f2a220c6d2e5',
        content_size: cc.size(1160, 400),
        content_pos: cc.v2(0, 0),
    },
};

const uuid_content_bg = 'd67653c4-0412-471b-b4ce-bbe8110554e5';

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm1 弹窗')
export class Cm1Dialog extends cc.Component {
    /** 使用哪种内置大小 */
    @property
    private _size: SizeStyleEnum = SizeStyleEnum.Small;
    @property({ type: cc.Enum(SizeStyleEnum), tooltip: CC_DEV && '弹窗尺寸' })
    get size(): SizeStyleEnum {
        return this._size;
    }
    set size(style: SizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    protected onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        cc.warn('设置成功后 请删除此组建 Cm1Dialog ！！！');
    }

    async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        const data = ButtonStyles[this._size];

        // bg
        this.node.setPosition(0, 0);
        const bg = this.node.addComponentUnique(cc.Sprite);
        bg.spriteFrame = await this.loadSpriteFrame(data.uuid_bg);
        bg.type = cc.Sprite.Type.SLICED;
        bg.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // RC_title
        let title: cc.Node | null = null;
        if (this.node.getChildByName('RC_title')) {
            title = this.node.getChildByName('RC_title');
        } else {
            title = new cc.Node('RC_title');
        }
        title.setAnchorPoint(0, 0.5);
        const title_Outline = title.addComponentUnique(cc.LabelOutline);

        title.removeComponent(we.ui.WELabelShadow);

        const title_color = title.addComponentUnique(we.ui.WEColorAssembler);
        const title_label = title.addComponentUnique(cc.Label);
        title_label.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        title_label.overflow = cc.Label.Overflow.NONE;
        title_label.fontSize = data.font_size;
        title_label.lineHeight = 80;
        title_label.font = await this.loadFont(data.uuid_font);
        title_color.colors = [cc.color().fromHEX('#7FEBFF'), cc.color().fromHEX('#7B2AFF')];
        title_Outline.color = cc.Color.WHITE;
        title_Outline.width = data.outLine_width;

        title.removeAllChildren();
        const title_value = new cc.Node('value');
        title_value.setAnchorPoint(0, 0.5);
        const title_value_label = title_value.addComponentUnique(cc.Label);
        title_value_label.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        title_value_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        title_value_label.overflow = cc.Label.Overflow.NONE;
        title_value_label.fontSize = data.font_size;
        title_value_label.lineHeight = 80;
        title_value_label.font = await this.loadFont(data.uuid_font);
        title_value.setPosition(3, 0);
        title_value.color = cc.Color.WHITE;
        title.addChild(title_value);

        title.setPosition(data.title_pos);
        title.parent = this.node;
        title.setSiblingIndex(0);

        title_label.string = 'Dlg Title';
        title.addComponentUnique(we.ui.WELabelShadow);

        // content bg
        let content_bg: cc.Node | null = null;
        if (!this.node.getChildByName('content_bg')) {
            content_bg = new cc.Node('content_bg');
        } else {
            content_bg = this.node.getChildByName('content_bg');
        }
        const content_bg_sp = content_bg.addComponentUnique(cc.Sprite);
        content_bg_sp.spriteFrame = await this.loadSpriteFrame(uuid_content_bg);
        content_bg_sp.type = cc.Sprite.Type.SLICED;
        content_bg_sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        content_bg.setPosition(data.content_pos);
        content_bg.setContentSize(data.content_size);
        content_bg.parent = this.node;
        title.setSiblingIndex(2);

        // RC_btnClose
        let btnClose: cc.Node | null = null;
        if (this.node.getChildByName('RC_btnClose')) {
            btnClose = this.node.getChildByName('RC_btnClose');
        } else {
            btnClose = new cc.Node('RC_btnClose');
        }
        btnClose.setPosition(data.close_pos);
        btnClose.setContentSize(new cc.Size(60, 60));
        btnClose.parent = this.node;
        btnClose.setSiblingIndex(1);

        btnClose.removeAllChildren();

        // close icon
        const closeIcon = new cc.Node('icon');
        closeIcon.addComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(data.uuid_close);
        closeIcon.setPosition(0, 0);
        closeIcon.parent = btnClose;
    }

    // //////////////////////////////////////////// 其他方法 ////////////////////////////////////////////

    async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.updateStyle();
    }
}
