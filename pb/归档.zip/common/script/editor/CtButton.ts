const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255, 255);
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255, 255);
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Yellow,
}

enum ButtonSizeStyleEnum {
    Small,
    Medium,
    Big,
}

const fontConf = {
    fontUuid: 'fb7522ae-5723-4b27-ba56-59f4e09a8518',
    fontSize: [24, 33, 40],
    labelPos: cc.v2(0, 3),
    outlineSize: 3,
};

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['563313b2-8d16-425d-b076-7384219c8b5d', '47a3744e-bf9f-4644-828e-f5706a022a20', 'c536a89d-8174-47d7-a23e-e491fc7baa25'],
        fontColor: cc.color().fromHEX('#ecf7fb'),
        outlineColor: cc.color().fromHEX('#205cb6'),
    },
    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['ed3e87a6-a3eb-4a3d-8741-4b4713d23699', '7da192b1-4f08-4a82-8777-d0e509d8cf81', '83c1987b-822f-4605-a000-d5bf589f1033'],
        fontColor: cc.color().fromHEX('#f2fbec'),
        outlineColor: cc.color().fromHEX('#0b8000'),
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['4f02b419-11d2-4389-bd90-be681322cd3d', '052f9a94-86bc-4824-9a0c-580879c4eac9', '6fe901e8-01e5-4ce6-8f86-d1295423b062'],
        fontColor: cc.color().fromHEX('#ffffff'),
        outlineColor: cc.color().fromHEX('#575757'),
    },
    [ButtonColorStyleEnum.Yellow]: {
        spriteUuid: ['8dd4f230-69b5-4e67-a5d2-b9328e824e6e', '98ecdb9d-f00c-42a9-8572-5b2804a3e0e4', '1f63a07d-eb18-4133-90c9-94ecb9297b89'],
        fontColor: cc.color().fromHEX('#fbf3ec'),
        outlineColor: cc.color().fromHEX('#be540e'),
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct 按钮')
export class CtButton extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    private sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    private label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);
        cc.warn('设置成功后 请删除此组建 CtButton ！！！');

        this.sprite = this.nodeAddComponent(this.node, cc.Sprite);
        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let node = new cc.Node('desc');
            node.parent = this.node;
            this.label = this.nodeAddComponent(node, cc.Label);
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    public async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        const conf = ButtonStyles[this._style];

        // bg
        this.sprite.spriteFrame = await this.loadSpriteFrame(conf);
        this.sprite.type == cc.Sprite.Type.SIMPLE;
        this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // label
        this.label.font = await this.loadFont();
        this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.label.cacheMode = cc.Label.CacheMode.BITMAP;
        this.label.node.setPosition(fontConf.labelPos);

        // 移除阴影效果
        this.label.node.removeComponent(cc.LabelShadow);

        // 添加多语言字体组件
        this.label.node.addComponentUnique(we.ui.WEI18nFont);

        this.label.node.color = conf.fontColor;
        const size = Math.ceil(fontConf.fontSize[this.size] / this.labelScale);
        this.label.fontSize = size;
        this.label.lineHeight = size + 8;

        const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
        outLine.width = fontConf.outlineSize;
        outLine.color = conf.outlineColor;

        this.label.overflow = cc.Label.Overflow.SHRINK;
        this.label.enableWrapText = false;
        this.label.node.setContentSize(cc.size((this.sprite.node.width - 40) * 1.65, (this.sprite.node.height - 10) * 1.65));

        this.label.node.scale = this.labelScale;
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(fontConf.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${fontConf.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }
}
