const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

/**
 * RC_title
 * RC_btn_close
 */

class DialogStyleData {
    bgUuid: string;
    bgPos: cc.Vec2;
    fontSize: number;
    titlePos: cc.Vec2;
    titleSize: cc.Size;
    outLineColor: cc.Color;
    shadowColor: cc.Color;
    assemblerColor: cc.Color[];
    closePos: cc.Vec2;
}

enum SizeStyleEnum {
    Small,
    Medium,
    Big,
}

const fontUuid = 'e9802072-1921-4f27-9e71-a89bee78511a';

const closeUuid = '9b65ce7f-a549-4252-8b26-6a28155ae638';

const dlgStyles: { [key: number]: DialogStyleData } = {
    [SizeStyleEnum.Small]: {
        bgUuid: 'e2d681d1-1ef1-42fc-a75c-6dad57b3d14d',
        bgPos: cc.v2(0, 0),
        fontSize: 72,
        titlePos: cc.v2(0, 237),
        titleSize: cc.size(600, 104),
        outLineColor: cc.color().fromHEX('#079EF6'),
        shadowColor: new cc.Color().fromHEX('#015CA5'),
        assemblerColor: [cc.color().fromHEX('#bfffff'), cc.color().fromHEX('#deffff'), cc.color().fromHEX('#f7fffe')],
        closePos: cc.v2(344.5, 219),
    },
    [SizeStyleEnum.Medium]: {
        bgUuid: 'e119ce16-9037-40df-a5aa-372145054cb8',
        bgPos: cc.v2(0, 0),
        fontSize: 90,
        titlePos: cc.v2(0, 301),
        titleSize: cc.size(776, 126),
        outLineColor: cc.color().fromHEX('#079EF6'),
        shadowColor: new cc.Color().fromHEX('#015CA5'),
        assemblerColor: [cc.color().fromHEX('#bfffff'), cc.color().fromHEX('#deffff'), cc.color().fromHEX('#f7fffe')],
        closePos: cc.v2(443, 279),
    },
    [SizeStyleEnum.Big]: {
        bgUuid: '088df1c0-714c-47c0-8eaa-7164a8b52702',
        bgPos: cc.v2(0, -16),
        fontSize: 90,
        titlePos: cc.v2(0, 317),
        titleSize: cc.size(1020, 126),
        outLineColor: cc.color().fromHEX('#079EF6'),
        shadowColor: new cc.Color().fromHEX('#015CA5'),
        assemblerColor: [cc.color().fromHEX('#bfffff'), cc.color().fromHEX('#deffff'), cc.color().fromHEX('#f7fffe')],
        closePos: cc.v2(566, 298.5),
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct3 弹窗')
export class Ct3Dialog extends cc.Component {
    /** 弹窗背景 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '背景' })
    private content: cc.Sprite = null;

    /** 弹窗标题 */
    @property({ type: cc.Label, tooltip: CC_DEV && '弹窗标题' })
    private title: cc.Label = null;

    /** 关闭按钮 */
    @property({ type: cc.Node, tooltip: CC_DEV && '关闭按钮' })
    private close: cc.Node = null;

    /** 使用哪种内置大小 */
    @property
    private _size: SizeStyleEnum = SizeStyleEnum.Small;
    @property({ type: cc.Enum(SizeStyleEnum), tooltip: CC_DEV && '弹窗尺寸' })
    get size(): SizeStyleEnum {
        return this._size;
    }
    set size(style: SizeStyleEnum) {
        if (this._size === style) {
            return;
        }

        this._size = style;
        this.updateStyle();
    }

    protected onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        this.content = this.node.getComponent(cc.Sprite);
        if (!this.content) {
            this.content = this.nodeAddComponent(this.node, cc.Sprite);
        }
        this.content.type = cc.Sprite.Type.SIMPLE;
        this.content.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        this.title = this.node.getChildByName('RC_title')?.getComponent(cc.Label);
        if (!this.title) {
            let node = new cc.Node('RC_title');
            node.parent = this.content.node;
            this.title = this.nodeAddComponent(node, cc.Label);
            this.title.string = 'label';
        }

        this.close = this.content.node.getChildByName('RC_btnClose');
        if (!this.close) {
            let node = new cc.Node('RC_btnClose');
            node.parent = this.content.node;
            this.close = node;
        }

        this.updateStyle();
    }

    private async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }
        cc.warn('设置成功后 请删除此组建 Ct3Dialog ！！！');

        const conf = dlgStyles[this._size];

        // bg
        this.content.spriteFrame = await this.loadSpriteFrame(conf.bgUuid);
        this.content.type = cc.Sprite.Type.SIMPLE;
        this.content.sizeMode = cc.Sprite.SizeMode.TRIMMED;
        this.content.trim = true;
        this.content.node.setPosition(conf.bgPos);

        // title
        await this.nodeAddComponent(this.title.node, we.ui.WELabelShadow);
        this.title.font = await this.loadFont(fontUuid);
        let weShadowLabel = this.title.node.getComponentInChildren(cc.Label);
        weShadowLabel.font = await this.loadFont(fontUuid);

        this.title.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        weShadowLabel.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.title.verticalAlign = cc.Label.VerticalAlign.CENTER;
        weShadowLabel.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.title.cacheMode = cc.Label.CacheMode.BITMAP;
        weShadowLabel.cacheMode = cc.Label.CacheMode.BITMAP;

        this.title.fontSize = conf.fontSize;
        this.title.lineHeight = conf.fontSize + 2;
        weShadowLabel.fontSize = conf.fontSize;
        weShadowLabel.lineHeight = conf.fontSize + 2;
        this.title.node.setPosition(conf.titlePos);
        weShadowLabel.node.setPosition(cc.v2(0, 6));

        this.title.node.color = conf.shadowColor;
        const outLine = this.nodeAddComponent(this.title.node, cc.LabelOutline);
        outLine.color = conf.shadowColor;
        outLine.width = 5;
        let weShadowLabelOutLi = this.nodeAddComponent(weShadowLabel.node, cc.LabelOutline);
        weShadowLabelOutLi.color = conf.outLineColor;
        weShadowLabelOutLi.width = 5;
        const assembler = this.nodeAddComponent(weShadowLabel.node, we.ui.WEColorAssembler);
        assembler.colors = conf.assemblerColor;

        this.title.node.addComponentUnique(we.ui.WEI18nFont);
        weShadowLabel.node.addComponentUnique(we.ui.WEI18nFont);

        this.title.overflow = cc.Label.Overflow.SHRINK;
        this.title.enableWrapText = false;
        this.title.node.setContentSize(conf.titleSize);
        weShadowLabel.overflow = cc.Label.Overflow.SHRINK;
        weShadowLabel.enableWrapText = false;
        weShadowLabel.node.setContentSize(conf.titleSize);

        // close
        let icon = this.close.getComponentInChildren(cc.Sprite);
        if (!icon) {
            let node = new cc.Node('icon');
            node.parent = this.close;
            icon = this.nodeAddComponent(node, cc.Sprite);
        }
        icon.type = cc.Sprite.Type.SIMPLE;
        icon.sizeMode = cc.Sprite.SizeMode.TRIMMED;
        icon.node.setPosition(new cc.Vec2(0, 0));
        icon.spriteFrame = await this.loadSpriteFrame(closeUuid);

        this.close.setPosition(conf.closePos);
        this.close.setContentSize(new cc.Size(70, 70));
    }

    private async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    private async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }
}
