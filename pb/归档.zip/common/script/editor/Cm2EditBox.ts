/** 背景资源 uuid */
const backGroundSPFUuid = '81bcddd3-45d3-4689-bc78-fa9e16042def';

/** 输入后 label 节点字体 uuid */
const textFontUuid = '13153632-666b-4d92-87bf-19bc3a04efb4';

/** 输入后 label 节点颜色 #ffffff */
const textFromHEX = '#945d38';

/** 预填充 label 节点字体 uuid */
const placeholderFontUuid = '7560d59f-9293-40fa-8a76-706a8724f2b7';

/** 预填充 label 节点颜色 #ffffff */
const placeholderFromHEX = '#d6986e';

const { ccclass, disallowMultiple, executeInEditMode, property, menu, requireComponent } = cc._decorator;

@ccclass()
@executeInEditMode
@disallowMultiple
@requireComponent(cc.EditBox)
@menu('皮肤样式/cm2 输入框')
export class Cm2EditBox extends cc.Component {
    private _editBox: cc.EditBox = null;

    private backGroundSpr: cc.Sprite = null;
    private textLabel: cc.Label = null;
    private placeholderLabel: cc.Label = null;

    private isInit: boolean = false;

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        cc.warn('设置成功后 请删除此组建 Cm2EditBox ！！！');
    }

    protected onFocusInEditor(): void {
        if (CC_EDITOR) {
            this.updateStyle();
        }
    }

    onRestore(): void {
        if (CC_EDITOR) {
            this.updateStyle();
        }
    }

    private updateStyle(): void {
        if (!this.isInit) {
            this.isInit = true;

            this._editBox = this.node.getComponent(cc.EditBox);
            if (this._editBox) {
                this.backGroundSpr = this._editBox.background;
                this.textLabel = this._editBox.textLabel;
                this.placeholderLabel = this._editBox.placeholderLabel;

                this.setStyle();
            }
        } else {
            this.setStyle();
        }
    }

    private async setStyle() {
        // 设置背景
        if (this.backGroundSpr) {
            this.backGroundSpr.type == cc.Sprite.Type.SLICED;
            this.backGroundSpr.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            this.backGroundSpr.spriteFrame = await this.loadAssets(backGroundSPFUuid);
        }

        // 设置输入后风格
        if (this.textLabel) {
            this.textLabel.font = await this.loadAssets(textFontUuid);
            this.textLabel.node.color = new cc.Color().fromHEX(textFromHEX);
        }

        //  预览字体风格
        if (this.placeholderLabel) {
            this.placeholderLabel.font = await this.loadAssets(placeholderFontUuid);
            this.placeholderLabel.node.color = new cc.Color().fromHEX(placeholderFromHEX);
        }
    }

    private async loadAssets<T extends cc.Asset>(uuid: string): Promise<T> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                if (err) {
                    cc.error(`loadAssets with uuid(${uuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }
}
