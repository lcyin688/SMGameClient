const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字号 */
    @property()
    fontSize: number[] = [24, 28, 36];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字描边 */
    @property()
    enableOutline: boolean = true;
    /** 描边 */
    @property()
    outlineSize: number = 3;
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字排版模式 */
    @property({ type: cc.Enum(cc.Label.Overflow) })
    Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Orange,
    /** 红色样式 */
    Red,
}

enum ButtonSizeStyleEnum {
    Big,
    Medium,
    Small,
}

/** 按钮使用字体统一 */
const fontUuid = '72a2c134-ca5d-4bee-9345-f2a220c6d2e5';
/** 预览效果实际大小 */
const fontSize = [36, 32, 26];
/** 描边 */
const enableOutline = true;
const outlineSize = 2;

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['bd797f45-59cd-4f11-88bd-e53f5e3d221d', 'b88f0276-a959-4610-9e18-2ddbffd4d6bd', 'be969ac5-c863-4606-90e2-e15e7f55bea0'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#2070b3'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#deffff'), cc.color().fromHEX('#cdecff')],
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['f0eb154c-7671-4a98-9126-cfb933b365d9', '4a04e176-8fde-43a5-b1fa-520c0ba3c02e', '36500ee0-3ed9-49e3-b70e-49ed81a74c59'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#127962'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#e3fff3'), cc.color().fromHEX('#a0ffce')],
    },
    [ButtonColorStyleEnum.Orange]: {
        spriteUuid: ['9ef0fca7-91f1-43ed-89c8-46992d042385', 'c211775d-4b58-463f-bfe3-75a4d943a5d9', '932cc9a1-4e79-4579-b3ec-c8f53fff0821'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#db6904'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#fffbe1'), cc.color().fromHEX('#fff390')],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['42446bcb-2797-432b-8b7c-af342de96702', 'eb12161c-690a-4371-9494-cf7421b1e020', '918c6c84-be25-4bbf-a5ad-126f202d1875'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#4a5170'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#f4f4f4'), cc.color().fromHEX('#c1cbe9')],
    },
    [ButtonColorStyleEnum.Red]: {
        spriteUuid: ['8aab8f16-21c6-45dc-93ea-a43ed62b2cc9', '8f6f4c10-da0f-40f6-ad8f-7dcabe436303', '13682765-2033-4c04-ac75-b7ab8cdd3267'],
        fontUuid: fontUuid,
        fontColor: cc.color().fromHEX('#ffffff'),
        fontSize: fontSize,
        enableOutline: enableOutline,
        outlineSize: outlineSize,
        outlineColor: cc.color().fromHEX('#9e083e'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#fdfeff'), cc.color().fromHEX('#ffdeea')],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm1 按钮')
export class Cm1Button extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        this.sprite = this.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.getComponentInChildren(cc.Sprite);
            if (!this.sprite) {
                this.sprite = this.node.addComponent(cc.Sprite);
            }
        }

        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let lab = new cc.Node();
            lab.name = 'label';
            lab.parent = this.node;
            this.label = lab.addComponent(cc.Label);
            this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        cc.warn('设置成功后 请删除此组建 Cm1Button ！！！');

        if (!CC_EDITOR && this.label && this.label.node.scale == this.labelScale) {
            return;
        }

        const styleData = ButtonStyles[this._style];

        // bg
        if (CC_EDITOR && this.sprite) {
            this.sprite.type == cc.Sprite.Type.SIMPLE;
            this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.sprite.spriteFrame = await this.loadSpriteFrame(styleData);
        }

        // label
        if (this.label) {
            if (CC_EDITOR) {
                this.label.font = await this.loadFont(styleData);
            }

            this.label.node.setPosition(0, 3);
            this.label.node.scale = this.labelScale;
            this.label.enableWrapText = false;

            if (styleData.fontColor) {
                this.label.node.color = styleData.fontColor;
            }

            if (styleData.fontSize) {
                const fontSize = Math.ceil(styleData.fontSize[this.size] / this.labelScale);
                this.label.fontSize = fontSize;
                this.label.lineHeight = fontSize + 2;
            }

            if (styleData.enableOutline) {
                const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
                if (styleData.outlineSize) {
                    outLine.width = styleData.outlineSize;
                }
                if (styleData.outlineColor) {
                    outLine.color = styleData.outlineColor;
                }
            }

            if (styleData.GradientColors) {
                const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
                colorAssembler.colors = styleData.GradientColors;
            }

            // 移除阴影效果
            this.label.node.removeComponent(cc.LabelShadow);

            this.label.overflow = styleData.Overflow;
            if (styleData.Overflow === cc.Label.Overflow.SHRINK) {
                this.label.node.width = (this.sprite.node.width - 50) * 1.65;
                this.label.node.height = (this.sprite.node.height - 30) * 1.65;
            }
        }
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${style.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }
}
