const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

const FontUuid = '959e40cd-95d2-42f8-ba63-c649a21a5719';

const CloseUuid = '0a6774eb-f5bf-4219-b978-21abb7115fac';

class DialogStyleData {
    spriteUuid: string = '';
    /** 图片标题位置 */
    @property({ type: cc.Vec2 })
    sprTitlePos?: cc.Vec2 = null;
    /** 文字标题位置 */
    @property({ type: cc.Vec2 })
    labTitlePos?: cc.Vec2 = null;
    /** 关闭按钮位置 */
    @property({ type: cc.Vec2 })
    closePos?: cc.Vec2 = null;
}

enum BG_SIZE {
    small = 0,
    middle = 1,
    big = 2,
}

enum TITLE_TYPE {
    sprite = 0,
    lable = 1,
}

const DialogStyle: { [key: number]: DialogStyleData } = {
    [BG_SIZE.small]: {
        spriteUuid: '4bab9301-e4dd-435b-a114-e3b8e9f840b6',
        sprTitlePos: cc.v2(0, 220),
        labTitlePos: cc.v2(0, 220),
        closePos: cc.v2(336, 213.5),
    },
    [BG_SIZE.middle]: {
        spriteUuid: 'bb00a4cd-7c9c-4a51-b6f3-c90b694e3a65',
        sprTitlePos: cc.v2(0, 264),
        labTitlePos: cc.v2(0, 264),
        closePos: cc.v2(430, 264),
    },
    [BG_SIZE.big]: {
        spriteUuid: 'ea2be658-62ae-4e76-b25c-e60f9cfa8846',
        sprTitlePos: cc.v2(0, 274),
        labTitlePos: cc.v2(0, 274),
        closePos: cc.v2(510, 274),
    },
};

const LableTitleStyle = {
    fontSize: 68,
    bgFontColor: cc.color(255, 254, 254, 255),
    bgEnableOutline: true,
    bgOutlineSize: 4,
    bgOutlineColor: cc.color().fromHEX('#ff5a00'),
    coverEnableOutline: true,
    coverOutlineSize: 4,
    coverOutlineColor: cc.color().fromHEX('#620404'),
    GradientColors: [cc.color().fromHEX('#f9a92a'), cc.color().fromHEX('#ffe34a')],
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm2 弹窗')
export class Cm2Dialog extends cc.Component {
    @property
    private _size: BG_SIZE = BG_SIZE.small;
    @property({ type: cc.Enum(BG_SIZE), tooltip: CC_DEV && '背景大小' })
    get size(): BG_SIZE {
        return this._size;
    }
    set size(size: BG_SIZE) {
        if (this._size === size) {
            return;
        }
        this._size = size;
        this.updateBg();
    }

    @property
    private _titleType: TITLE_TYPE = TITLE_TYPE.sprite;
    @property({ type: cc.Enum(TITLE_TYPE), tooltip: CC_DEV && '标题类型：sprite｜lable' })
    get titleType(): TITLE_TYPE {
        return this._titleType;
    }
    set titleType(type: TITLE_TYPE) {
        if (this._titleType === type) {
            return;
        }
        this._titleType = type;
        this.updateTitle();
    }

    onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        cc.warn('设置成功后 请删除此组建 Cm2Dialog ！！！');
    }

    async updateBg() {
        if (!CC_EDITOR) {
            return;
        }

        // bg
        this.node.setPosition(0, 0);
        const bg = this.nodeAddComponent(this.node, cc.Sprite);
        bg.spriteFrame = await this.loadSpriteFrame(DialogStyle[this._size].spriteUuid);
        bg.type = cc.Sprite.Type.SLICED;
        bg.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // RC_btn_close
        let btnClose = this.node.getChildByName('RC_btnClose');
        if (!btnClose) {
            btnClose = new cc.Node('RC_btnClose');
            btnClose.setPosition(DialogStyle[this._size].closePos);
            btnClose.setContentSize(new cc.Size(80, 80));
            let btnButton = btnClose.addComponent(cc.Button);
            btnButton.transition = cc.Button.Transition.SCALE;
            btnButton.zoomScale = 0.9;
            btnClose.parent = this.node;
            const icon = new cc.Node('icon');
            icon.addComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(CloseUuid);
            icon.parent = btnClose;
        }
        btnClose.setPosition(DialogStyle[this._size].closePos);

        let title = this.node.getChildByName('RC_title');
        if (title) {
            title.setPosition(DialogStyle[this._size].labTitlePos);
        }
    }

    async updateTitle() {
        let title = this.node.getChildByName('RC_title');
        if (title) {
            this.node.removeChild(title);
        }
        title = new cc.Node('RC_title');
        if (this._titleType == TITLE_TYPE.sprite) {
            const title_spr = title.addComponent(cc.Sprite);
            title.addComponent(we.ui.WEI18nSprite);
            title.setPosition(DialogStyle[this._size].sprTitlePos);
            title.parent = this.node;
        } else {
            title.color = LableTitleStyle.bgFontColor;
            const title_label = title.addComponent(cc.Label);
            title_label.fontSize = LableTitleStyle.fontSize;
            title_label.lineHeight = LableTitleStyle.fontSize;
            title_label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            title_label.font = await this.loadFont(FontUuid);
            title_label.cacheMode = cc.Label.CacheMode.BITMAP;
            const title_outline = title.addComponent(cc.LabelOutline);
            title_outline.width = LableTitleStyle.bgOutlineSize;
            title_outline.color = LableTitleStyle.bgOutlineColor;

            let cover_title = new cc.Node('content');
            const cover_title_label = cover_title.addComponent(cc.Label);
            cover_title_label.fontSize = LableTitleStyle.fontSize;
            cover_title_label.lineHeight = LableTitleStyle.fontSize;
            cover_title_label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            cover_title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
            cover_title_label.font = await this.loadFont(FontUuid);
            cover_title_label.cacheMode = cc.Label.CacheMode.BITMAP;
            const cover_title_outline = cover_title.addComponent(cc.LabelOutline);
            cover_title_outline.width = LableTitleStyle.coverOutlineSize;
            cover_title_outline.color = LableTitleStyle.coverOutlineColor;
            const cover_title_color = cover_title_label.addComponent(we.ui.WEColorAssembler);
            cover_title_color.colors = LableTitleStyle.GradientColors;

            title.parent = this.node;
            cover_title.parent = title;
            cover_title.setPosition(cc.v2(0, 3));
            title.setPosition(DialogStyle[this._size].labTitlePos);
            title_label.addComponent('WEI18nLabelFull');
            cover_title_label.addComponent('WEI18nLabelFull');
            title_label.string = 'Dlg Title';
            cover_title_label.string = 'Dlg Title';
        }
    }

    async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.updateBg();
    }
}
