const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字号 */
    @property()
    fontSize: number[] = [24, 28, 36];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字描边 */
    @property()
    enableOutline: boolean = true;
    /** 描边 */
    @property()
    outlineSize: number = 3;
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字排版模式 */
    @property({ type: cc.Enum(cc.Label.Overflow) })
    Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
    /** 按钮文本宽度 */
    labelWidth: number[] = [];
    /** 按钮文本高度 */
    labelHeight: number[] = [];
    /** 按钮文本位置 */
    labelPos: cc.Vec2[] = [];
}

enum ButtonColorStyleEnum {
    /** 红色样式 */
    Red,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Yellow,
    /** 绿色边框 */
    Green_frame,
    /** 灰色边框 */
    Gray_frame,
    /** 黄色边框 */
    Yellow_frame,
}

enum ButtonSizeStyleEnum {
    Medium,
    Big,
}

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Red]: {
        spriteUuid: ['c1330a5b-94fd-4e54-8e66-04d09eac6b29', '6080f276-e64f-4922-9cf7-cb1d7fbcb1b5'],
        fontUuid: '3050b8a3-4b1b-4b89-b22e-d23e4138fbd3',
        fontColor: cc.color(255, 254, 254, 255),
        fontSize: [42, 52],
        enableOutline: true,
        outlineSize: 3,
        outlineColor: cc.color().fromHEX('#ad481c'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#ffffff'), cc.color().fromHEX('#ffdece')],
        labelWidth: [210, 260],
        labelHeight: [70, 70],
        labelPos: [cc.v2(0, 3), cc.v2(0, 3)],
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['ff2ae0dc-818e-48b9-9011-02ad171ef626', '03214174-0aca-4995-8d48-d99c4992c038'],
        fontUuid: '3050b8a3-4b1b-4b89-b22e-d23e4138fbd3',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [42, 52],
        enableOutline: true,
        outlineSize: 3,
        outlineColor: cc.color().fromHEX('#107f3e'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#ffffff'), cc.color().fromHEX('#d5ffdc')],
        labelWidth: [210, 260],
        labelHeight: [70, 70],
        labelPos: [cc.v2(0, 3), cc.v2(0, 3)],
    },
    [ButtonColorStyleEnum.Yellow]: {
        spriteUuid: ['67da45f3-dc48-4632-bac7-fa91fad291f0', '0887ef62-b396-49de-a595-86a49dd6b45d'],
        fontUuid: '3050b8a3-4b1b-4b89-b22e-d23e4138fbd3',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [42, 52],
        enableOutline: true,
        outlineSize: 3,
        outlineColor: cc.color().fromHEX('#ad481c'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#FFFFFF'), cc.color().fromHEX('#fff280')],
        labelWidth: [210, 260],
        labelHeight: [70, 70],
        labelPos: [cc.v2(0, 3), cc.v2(0, 3)],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['0760bed7-b5af-406e-90cc-40cc2b6d0275', 'da25a624-7684-48d9-b99a-54007d3f78f4'],
        fontUuid: '3050b8a3-4b1b-4b89-b22e-d23e4138fbd3',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [42, 52],
        enableOutline: true,
        outlineSize: 3,
        outlineColor: cc.color().fromHEX('#444745'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#ffffff'), cc.color().fromHEX('#9e9e9e')],
        labelWidth: [210, 260],
        labelHeight: [70, 70],
        labelPos: [cc.v2(0, 3), cc.v2(0, 3)],
    },
    [ButtonColorStyleEnum.Green_frame]: {
        spriteUuid: ['868f6e34-9237-4175-8568-fabc01034921', '3c5bc7cf-2b50-42c0-8b94-81776c1e816a'],
        fontUuid: '3050b8a3-4b1b-4b89-b22e-d23e4138fbd3',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [52, 52],
        enableOutline: true,
        outlineSize: 3,
        outlineColor: cc.color().fromHEX('#004c00'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#fffebe'), cc.color().fromHEX('#ffdd33')],
        labelWidth: [220, 310],
        labelHeight: [60, 70],
        labelPos: [cc.v2(0, 9), cc.v2(0, 9)],
    },
    [ButtonColorStyleEnum.Gray_frame]: {
        spriteUuid: ['5e1d0a77-7f2b-4cc3-b471-2a6c49d7c22d', 'e0917772-8bb8-481a-99fc-ed5b98e88e5b'],
        fontUuid: '3050b8a3-4b1b-4b89-b22e-d23e4138fbd3',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [52, 52],
        enableOutline: true,
        outlineSize: 3,
        outlineColor: cc.color().fromHEX('#444745'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#ffffff'), cc.color().fromHEX('#9e9e9e')],
        labelWidth: [220, 310],
        labelHeight: [60, 70],
        labelPos: [cc.v2(0, 9), cc.v2(0, 9)],
    },
    [ButtonColorStyleEnum.Yellow_frame]: {
        spriteUuid: ['ef45019d-2890-413a-8ed9-7e1bf039356f', '41251497-6634-4c6c-839d-4bb111f2e65d'],
        fontUuid: '3050b8a3-4b1b-4b89-b22e-d23e4138fbd3',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [52, 52],
        enableOutline: true,
        outlineSize: 3,
        outlineColor: cc.color().fromHEX('#573100'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#fffebe'), cc.color().fromHEX('#ffdd33')],
        labelWidth: [220, 310],
        labelHeight: [60, 70],
        labelPos: [cc.v2(0, 9), cc.v2(0, 9)],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm2 按钮')
export class Cm2Button extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Red;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        this.sprite = this.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.getComponentInChildren(cc.Sprite);
        }
        this.label = this.getComponentInChildren(cc.Label);
        this.updateStyle();
    }

    async updateStyle() {
        cc.warn('设置成功后 请删除此组建 Cm2Button ！！！');

        if (!CC_EDITOR) {
            return;
        }

        const styleData = ButtonStyles[this._style];

        // bg
        if (CC_EDITOR && this.sprite) {
            this.sprite.type == cc.Sprite.Type.SIMPLE;
            this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.sprite.spriteFrame = await this.loadSpriteFrame(styleData);
        }

        // label
        if (this.label) {
            if (CC_EDITOR) {
                this.label.font = await this.loadFont(styleData);
            }
            this.label.enableWrapText = false;

            if (styleData.fontColor) {
                this.label.node.color = styleData.fontColor;
            }

            if (styleData.fontSize) {
                const fontSize = styleData.fontSize[this.size];
                this.label.fontSize = fontSize;
                this.label.lineHeight = fontSize + 8;
            }

            if (styleData.enableOutline) {
                const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
                if (styleData.outlineSize) {
                    outLine.width = styleData.outlineSize;
                }
                if (styleData.outlineColor) {
                    outLine.color = styleData.outlineColor;
                }
            }

            if (styleData.GradientColors) {
                const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
                colorAssembler.colors = styleData.GradientColors;
            }

            // 移除阴影效果
            this.label.node.removeComponent(cc.LabelShadow);

            this.label.overflow = styleData.Overflow;
            if (styleData.Overflow === cc.Label.Overflow.SHRINK) {
                this.label.node.setContentSize(cc.size(styleData.labelWidth[this._size] * 1.5, styleData.labelHeight[this._size] * 1.5));
                this.label.node.setPosition(styleData.labelPos[this._size]);
            }

            this.label.node.scale = 0.65;
        }
    }

    nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${style.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }
}
