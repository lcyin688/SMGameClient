const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 按钮文本宽度 */
    labelWidth: number[] = [];
    /** 按钮文本高度 */
    labelHeight: number[] = [];
}

enum ButtonColorStyleEnum {
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Yellow,
    /** 蓝色样式 */
    Blue,
}

enum ButtonSizeStyleEnum {
    Small,
    Medium,
    Big,
}

const fontConf = {
    fontUuid: 'f67d0f8e-ad33-4746-a019-bea077216c52',
    fontColor: cc.color(255, 255, 255, 255),
    fontSize: [42, 52, 72],
    labelPos: cc.v2(-3, 3),
    outlineSize: 3,
};

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['1b08f6a5-af74-4f56-b1c2-14681a40d990', '7494601f-c111-4206-9e69-4d9830cd0e42', 'bf7f0682-cd78-4626-a93c-6e82af2e5197'],
        outlineColor: cc.color().fromHEX('#0c903f'),
        labelWidth: [220, 254, 328],
        labelHeight: [70, 70, 80],
    },
    [ButtonColorStyleEnum.Yellow]: {
        spriteUuid: ['8a1825eb-f038-463b-95ed-c0ab72c212a8', 'b1616d72-c218-49b4-a642-9e437fce99db', '8fbbcb49-8ec3-48d1-ba64-201539adf199'],
        outlineColor: cc.color().fromHEX('#d1743d'),
        labelWidth: [220, 254, 328],
        labelHeight: [70, 70, 80],
    },
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['cd66560a-8b57-4a1f-b653-16a46cd64c7c', 'e6ced06b-f695-4ae6-aa0e-003a4a6671c4', 'd8b6ce6f-a1b9-465e-bfdb-0a9858064682'],
        outlineColor: cc.color().fromHEX('#1c6ab3'),
        labelWidth: [220, 254, 328],
        labelHeight: [70, 70, 80],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['c2bca0db-bfb2-4dfe-b557-ab31fbdcb194', '497d3e92-e60e-46ec-a346-acc7b1613e41', '2c4262c1-0d9e-4bd1-bf5b-4f6fff70f5bb'],
        outlineColor: cc.color().fromHEX('#414141'),
        labelWidth: [220, 254, 328],
        labelHeight: [70, 70, 80],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/cm3 按钮')
export class Cm3Button extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Green;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Small;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);
        cc.warn('设置成功后 请删除此组建 Cm3Button ！！！');

        this.sprite = this.nodeAddComponent(this.node, cc.Sprite);

        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let label = new cc.Node('desc');
            label.parent = this.node;
            this.label = this.nodeAddComponent(label, cc.Label);
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        const conf = ButtonStyles[this._style];

        // bg
        this.sprite.spriteFrame = await this.loadSpriteFrame(conf);
        this.sprite.type == cc.Sprite.Type.SIMPLE;
        this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        this.label.font = await this.loadFont();
        this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.label.enableWrapText = false;

        // 清理优化前多余组件
        let WEColorAssembler = this.label.node.getComponent(we.ui.WEColorAssembler);
        if (WEColorAssembler) {
            this.label.node.removeComponent(we.ui.WEColorAssembler);
        }

        // 移除阴影效果
        this.label.node.removeComponent(cc.LabelShadow);

        // label
        this.label.node.color = fontConf.fontColor;
        const size = fontConf.fontSize[this.size];
        this.label.fontSize = size;
        this.label.lineHeight = size + 8;

        const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
        outLine.width = fontConf.outlineSize;
        outLine.color = conf.outlineColor;

        this.label.overflow = cc.Label.Overflow.SHRINK;
        this.label.node.setContentSize(cc.size(conf.labelWidth[this._size] * 1.5, conf.labelHeight[this._size] * 1.5));
        this.label.node.setPosition(fontConf.labelPos);
        this.label.cacheMode = cc.Label.CacheMode.BITMAP;

        this.label.node.scale = 0.65;
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    private async loadFont(): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(fontConf.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${fontConf.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }
}
