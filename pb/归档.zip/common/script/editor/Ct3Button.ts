const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255, 255);
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255, 255);
    /** 阴影颜色 */
    @property()
    shadowColor: cc.Color = cc.color(255, 255, 255, 255);
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Yellow,
    /** 红色样式 */
    Red,
}

enum ButtonSizeStyleEnum {
    Small,
    Medium,
    Big,
}

const fontUuid = 'e9802072-1921-4f27-9e71-a89bee78511a';
const fontSize = [29, 32, 35];
const outlineSize = 4;

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['25f938b8-5898-47a0-a306-f00fa01259f2', '713d1824-4800-4209-bd77-f4654a952a77', 'b41ae11f-2bc2-402d-9b60-6a59c097525b'],
        fontUuid: fontUuid,
        outlineColor: cc.color().fromHEX('#0469db'),
        shadowColor: cc.color().fromHEX('#0e9ef9'),
        GradientColors: [cc.color().fromHEX('#deffff'), cc.color().fromHEX('#cdecff')],
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['13b1d60e-c065-46e9-a8f9-a95a4d4a4e2f', '379c97b2-8a3a-4dd2-b26d-91cdc6690657', '51ed03ef-36b2-443f-afe3-ca2f833e1daa'],
        fontUuid: fontUuid,
        outlineColor: cc.color().fromHEX('#06674d'),
        shadowColor: cc.color().fromHEX('#15b16d'),
        GradientColors: [cc.color().fromHEX('#e3fff3'), cc.color().fromHEX('#a0ffce')],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['5fd1baed-968d-4b7b-964e-1fec9f8cfba0', '384ace4a-92e8-4659-953d-45feb9899e1f', '47c125cb-5e06-4db2-8e4a-be16e5c690db'],
        fontUuid: fontUuid,
        outlineColor: cc.color().fromHEX('#70604a'),
        shadowColor: cc.color().fromHEX('#a39179'),
        GradientColors: [cc.color().fromHEX('#f4f4f4'), cc.color().fromHEX('#e9d8c1')],
    },
    [ButtonColorStyleEnum.Yellow]: {
        spriteUuid: ['cd634329-b41e-4d64-86c7-27ff6d89bdf3', 'cb8371a4-0b9a-4c6c-b580-6123af1d9e40', '2f311159-f58b-4d85-ad20-553cf872f20d'],
        fontUuid: fontUuid,
        outlineColor: cc.color().fromHEX('#db6904'),
        shadowColor: cc.color().fromHEX('#ffa326'),
        GradientColors: [cc.color().fromHEX('#fffbe1'), cc.color().fromHEX('#fff390')],
    },
    [ButtonColorStyleEnum.Red]: {
        spriteUuid: ['3105123e-d524-4517-b5bc-cfe4a9d60d45', '37547f2f-94b5-46d0-b8c8-d701330e2bba', 'f495589c-33f7-4275-9ff5-01ad4db742a4'],
        fontUuid: fontUuid,
        outlineColor: cc.color().fromHEX('#9e083e'),
        shadowColor: cc.color().fromHEX('#cb115d'),
        GradientColors: [cc.color().fromHEX('#fdfeff'), cc.color().fromHEX('#ffdeea')],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct3 按钮')
export class Ct3Button extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    private sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    private label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    protected onLoad(): void {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);
        cc.warn('设置成功后 请删除此组建 Ct3Button ！！！');

        this.sprite = this.nodeAddComponent(this.node, cc.Sprite);
        this.label = this.getComponentInChildren(cc.Label);
        if (!this.label) {
            let node = new cc.Node('desc');
            node.parent = this.node;
            this.label = this.nodeAddComponent(node, cc.Label);
            this.label.string = 'Label';
        }

        this.updateStyle();
    }

    public async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        const conf = ButtonStyles[this._style];

        // bg
        this.sprite.type == cc.Sprite.Type.SIMPLE;
        this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
        this.sprite.spriteFrame = await this.loadSpriteFrame(conf);

        // label
        this.label.font = await this.loadFont(conf);
        this.label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.label.cacheMode = cc.Label.CacheMode.BITMAP;
        this.label.node.setPosition(0, 3);

        const font_size = Math.floor(fontSize[this.size] / this.labelScale + 0.5);
        this.label.fontSize = font_size;
        this.label.lineHeight = font_size + 8;

        const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
        outLine.width = outlineSize;
        outLine.color = conf.outlineColor;

        const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
        colorAssembler.colors = conf.GradientColors;

        const shadow = this.nodeAddComponent(this.label.node, cc.LabelShadow);
        shadow.blur = 2;
        shadow.offset = new cc.Vec2(0, -3);
        shadow.color = conf.shadowColor;

        // 添加多语言字体组件
        this.label.node.addComponentUnique(we.ui.WEI18nFont);

        this.label.overflow = cc.Label.Overflow.SHRINK;
        this.label.enableWrapText = false;
        this.label.node.width = (this.sprite.node.width - 50) * 1.65;
        this.label.node.height = (this.sprite.node.height - 20) * 1.65;

        this.label.node.scale = this.labelScale;
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    private async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                resolve(asset);
            });
        });
    }

    private async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                resolve(asset);
            });
        });
    }
}
