const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

/**
 * 内容根节点: content
 * 关闭按钮: RC_btnClose
 * title : RC_title
 */

enum BG_SIZE {
    Small = 0,
    Middle = 1,
    Big = 2,
}

class DialogStyleData {
    contentUuid: string = '';
    /** 内容填充背景大小 */
    @property({ type: cc.Size })
    contentBgSize?: cc.Size = null;
    /** 文字标题位置 */
    @property({ type: cc.Vec2 })
    titlePos?: cc.Vec2 = null;
    /** 关闭按钮位置 */
    @property({ type: cc.Vec2 })
    closePos?: cc.Vec2 = null;
}

/** 字体 uuid */
const fontUuid = 'ac59bcf9-f1c4-4718-a585-34eba4727037';
/** 关闭按钮 icon uuid */
const closeUuid = '6c6ddff1-8555-476a-9465-4bf7ba896c3a';
/** 弹窗内容 bg */
const contentBgUid = '6d84771c-5b93-4413-a86a-ddf293573c4c';

/** 字体大小 小 -> 大 */
const fontSize = [40, 48, 56];

/** title label */
const titleStyleConf = {
    outlineSize: 3,
    outlineColor: cc.color().fromHEX('#6C1029'),
    colorAssembler: [cc.color().fromHEX('#fbc300'), cc.color().fromHEX('#fff792')],
};

/** 弹窗配置 */
const dialogStyleConf: { [key: number]: DialogStyleData } = {
    [BG_SIZE.Small]: {
        titlePos: cc.v2(0, 190),
        closePos: cc.v2(350, 220),
        contentBgSize: new cc.Size(680, 290),
        contentUuid: '08fb82d9-b330-4e53-9cb8-0ef6b3b643b6',
    },
    [BG_SIZE.Middle]: {
        titlePos: cc.v2(0, 244),
        closePos: cc.v2(452, 282),
        contentBgSize: new cc.Size(880, 386),
        contentUuid: 'd550a1b1-275f-4c32-83ca-b99336d30274',
    },
    [BG_SIZE.Big]: {
        titlePos: cc.v2(0, 282),
        closePos: cc.v2(566, 306),
        contentBgSize: new cc.Size(1124, 406),
        contentUuid: '4059f02e-d661-4660-8926-d990d6b3e980',
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct2 弹窗')
export class Ct2Dialog extends cc.Component {
    @property
    private _size: BG_SIZE = BG_SIZE.Small;
    @property({ type: cc.Enum(BG_SIZE), tooltip: CC_DEV && '背景大小' })
    get size(): BG_SIZE {
        return this._size;
    }
    set size(size: BG_SIZE) {
        if (this._size === size) {
            return;
        }
        this._size = size;
        this.updateStyle();
    }

    private content: cc.Sprite = null;
    private content_bg: cc.Sprite = null;
    private closeBtn: cc.Node = null;
    private closeIcon: cc.Sprite = null;
    private title: cc.Label = null;

    protected onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);
        cc.warn('设置成功后 请删除此组建 Ct2Dialog ！！！');

        this.content = this.node.getComponent(cc.Sprite);
        if (!this.content) {
            this.content = this.node.addComponent(cc.Sprite);
        }

        let content_bg = this.content.node.getChildByName('content_bg');
        if (!content_bg) {
            content_bg = new cc.Node('content_bg');
            content_bg.parent = this.content.node;
        }
        this.content_bg = content_bg.getComponent(cc.Sprite);
        if (!this.content_bg) {
            this.content_bg = content_bg.addComponent(cc.Sprite);
        }

        // close
        this.closeBtn = this.node.getChildByName('RC_btnClose');
        if (!this.closeBtn) {
            this.closeBtn = new cc.Node('RC_btnClose');
            this.closeBtn.addComponent(cc.Button);
        }
        this.closeBtn.parent = this.node;
        this.closeBtn.setContentSize(new cc.Size(80, 80));
        let btnButton = this.closeBtn.getComponent(cc.Button);
        if (!btnButton) {
            btnButton = this.closeBtn.addComponent(cc.Button);
        }
        btnButton.transition = cc.Button.Transition.SCALE;
        btnButton.zoomScale = 1.1;

        // close icon
        let icon = this.closeBtn.getChildByName('icon');
        if (!icon) {
            icon = new cc.Node('icon');
            this.closeIcon = icon.addComponent(cc.Sprite);
            icon.parent = this.closeBtn;
        }
        this.closeIcon = icon.getComponent(cc.Sprite);
        if (!this.closeIcon) {
            this.closeIcon = icon.addComponent(cc.Sprite);
        }

        // title
        let title = this.node.getChildByName('RC_title');
        if (!title) {
            title = new cc.Node('RC_title');
            title.parent = this.node;
        }
        this.title = title.getComponent(cc.Label);
        if (!this.title) {
            this.title = title.addComponent(cc.Label);
            this.title.string = 'Label';
        }

        this.updateStyle();
    }

    private async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        let conf = dialogStyleConf[this.size];

        // bg
        this.node.setPosition(0, 0);
        this.content.spriteFrame = await this.loadSpriteFrame(conf.contentUuid);
        this.content.type = cc.Sprite.Type.SIMPLE;
        this.content.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // content_bg
        this.content_bg.node.setPosition(0, 0);
        this.content_bg.spriteFrame = await this.loadSpriteFrame(contentBgUid);
        this.content_bg.type = cc.Sprite.Type.SLICED;
        this.content_bg.node.setContentSize(conf.contentBgSize);

        // RC_btnClose
        this.closeBtn.setPosition(conf.closePos);
        this.closeIcon.spriteFrame = await this.loadSpriteFrame(closeUuid);

        // title
        this.title.font = await this.loadFont(fontUuid);
        this.title.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.title.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.title.overflow = cc.Label.Overflow.NONE;

        this.title.node.setPosition(conf.titlePos);
        this.title.fontSize = fontSize[this.size];
        this.title.lineHeight = fontSize[this.size] + 6;
        let outLine = this.title.getComponent(cc.LabelOutline);
        if (!outLine) {
            outLine = this.title.addComponent(cc.LabelOutline);
        }
        outLine.color = titleStyleConf.outlineColor;
        outLine.width = titleStyleConf.outlineSize;

        let colorAssembler = this.title.getComponent(we.ui.WEColorAssembler);
        if (!colorAssembler) {
            colorAssembler = this.title.addComponent(we.ui.WEColorAssembler);
        }
        colorAssembler.colors = titleStyleConf.colorAssembler;
    }

    private async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    private async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                if (err) {
                    cc.error(`Ct2Dialog loadSpriteFrame with uuid(${fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }
}
