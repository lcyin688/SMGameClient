const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class DialogStyleData {
    spriteUuid: string = '';
    /** 文字标题位置 */
    @property({ type: cc.Vec2 })
    titlePos: cc.Vec2 = null;
    /** 文字标题大小 */
    @property({ type: cc.Size })
    titleSize: cc.Size = null;
    /** 关闭按钮位置 */
    @property({ type: cc.Vec2 })
    closePos: cc.Vec2 = null;
    /** content_bg 大小 */
    @property({ type: cc.Size })
    contentSize: cc.Size = null;
    /** content_bg 位置 */
    @property({ type: cc.Vec2 })
    contentPos: cc.Vec2 = null;
}

enum BG_SIZE {
    Small = 0,
    Middle = 1,
    Big = 2,
}

const fontUuid = '8ab09ceb-79a0-4bbc-be2b-c050ddba9204';
const closeUuid = 'bf7a2b24-a0b9-4a76-89fe-684a29933da9';
const contentUuid = '465980d1-e723-4a84-a202-e1a70bb052b8';

const DialogStyle: { [key: number]: DialogStyleData } = {
    [BG_SIZE.Small]: {
        spriteUuid: '30abc9d9-d23d-40cd-8c1f-43a0ec8bc167',
        titlePos: cc.v2(-6, 208),
        titleSize: cc.size(250, 50),
        closePos: cc.v2(361, 212),
        contentSize: cc.size(678, 370),
        contentPos: cc.v2(-4.5, -17),
    },
    [BG_SIZE.Middle]: {
        spriteUuid: '5a7fe7f8-60dc-46e8-9cbf-1ba98af3f683',
        titlePos: cc.v2(30, 274),
        titleSize: cc.size(230, 50),
        closePos: cc.v2(482, 265),
        contentSize: cc.size(870, 476),
        contentPos: cc.v2(17.5, -30.5),
    },
    [BG_SIZE.Big]: {
        spriteUuid: '4d626664-c8f7-4e58-9d25-13dcc2329333',
        titlePos: cc.v2(-6, 292),
        titleSize: cc.size(250, 50),
        closePos: cc.v2(566, 288),
        contentSize: cc.size(1077, 468),
        contentPos: cc.v2(-2, 4.5),
    },
};

const LabelTitleStyle = {
    fontSize: 36,
    titleColor: cc.color().fromHEX('#fffbdc'),
    shadowColor: cc.color().fromHEX('#1E060680'),
    outlineSize: 2,
    outlineColor: cc.color().fromHEX('#d76f13'),
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct 弹窗')
export class CtDialog extends cc.Component {
    @property
    private _size: BG_SIZE = BG_SIZE.Small;
    @property({ type: cc.Enum(BG_SIZE), tooltip: CC_DEV && '背景大小' })
    get size(): BG_SIZE {
        return this._size;
    }
    set size(size: BG_SIZE) {
        if (this._size === size) {
            return;
        }
        this._size = size;
        this.updateStyle();
    }

    private content: cc.Sprite = null;
    private content_bg: cc.Sprite = null;
    private btnClose: cc.Button = null;
    private title: cc.Label = null;

    protected onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);
        if (!CC_EDITOR) {
            return;
        }

        this.content = this.nodeAddComponent(this.node, cc.Sprite);
        let content_bg = this.node.getChildByName('content_bg');
        if (!content_bg) {
            content_bg = new cc.Node('content_bg');
            content_bg.parent = this.node;
        }
        this.content_bg = this.nodeAddComponent(content_bg, cc.Sprite);

        let btnClose = this.node.getChildByName('RC_btnClose');
        if (!btnClose) {
            btnClose = new cc.Node('RC_btnClose');
            btnClose.parent = this.node;
        }
        this.btnClose = this.nodeAddComponent(btnClose, cc.Button);

        let title = this.node.getChildByName('RC_title');
        if (!title) {
            title = new cc.Node('RC_title');
            title.parent = this.node;
            title.addComponentUnique(cc.Label).string = 'Dlg Title';
        }
        this.title = this.nodeAddComponent(title, cc.Label);

        this.updateStyle();
    }

    private async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }
        cc.warn('设置成功后 请删除此组建 CtDialog ！！！');

        // bg
        this.node.setPosition(0, 0);
        this.content.type = cc.Sprite.Type.SIMPLE;
        this.content.sizeMode = cc.Sprite.SizeMode.RAW;
        this.content.trim = false;
        this.content.spriteFrame = await this.loadSpriteFrame(DialogStyle[this._size].spriteUuid);

        // content bg
        this.content_bg.type = cc.Sprite.Type.SLICED;
        this.content_bg.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.content_bg.spriteFrame = await this.loadSpriteFrame(contentUuid);
        this.content_bg.node.setPosition(DialogStyle[this._size].contentPos);
        this.content_bg.node.setContentSize(DialogStyle[this._size].contentSize);

        // RC_btnClose
        this.btnClose.node.setPosition(DialogStyle[this._size].closePos);
        this.btnClose.node.setContentSize(cc.size(80, 80));
        this.btnClose.target = this.btnClose.node;
        this.btnClose.transition = cc.Button.Transition.SCALE;
        this.btnClose.zoomScale = 0.9;
        let icon = this.btnClose.node.getChildByName('icon');
        if (!icon) {
            icon = new cc.Node('icon');
            icon.parent = this.btnClose.node;
        }
        let iconSpr = this.nodeAddComponent(icon, cc.Sprite);
        iconSpr.type = cc.Sprite.Type.SIMPLE;
        iconSpr.sizeMode = cc.Sprite.SizeMode.TRIMMED;
        iconSpr.spriteFrame = await this.loadSpriteFrame(closeUuid);

        // title
        this.title.font = await this.loadFont(fontUuid);
        this.title.node.color = LabelTitleStyle.titleColor;
        this.title.node.setPosition(DialogStyle[this._size].titlePos);
        this.title.fontSize = LabelTitleStyle.fontSize;
        this.title.lineHeight = LabelTitleStyle.fontSize;
        this.title.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.title.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.title.cacheMode = cc.Label.CacheMode.BITMAP;

        this.title.node.addComponentUnique(we.ui.WEI18nFont);

        const title_outline = this.nodeAddComponent(this.title.node, cc.LabelOutline);
        title_outline.width = LabelTitleStyle.outlineSize;
        title_outline.color = LabelTitleStyle.outlineColor;

        const title_shadow = this.nodeAddComponent(this.title.node, cc.LabelShadow);
        title_shadow.blur = 2;
        title_shadow.offset = new cc.Vec2(0, -2);
        title_shadow.color = LabelTitleStyle.shadowColor;

        this.title.overflow = cc.Label.Overflow.SHRINK;
        this.title.enableWrapText = false;
        this.title.node.setContentSize(DialogStyle[this._size].titleSize);
    }

    private async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    private nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    private async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }
}
