const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class DialogStyleData {
    font_size: number;
    title_pos: cc.Vec2;
    outLine_width: number;
    close_pos: cc.Vec2;
    uuid_bg: string;
    uuid_close: string;
    uuid_font: string;
    content_size: cc.Size;
    content_pos: cc.Vec2;
}

enum SizeStyleEnum {
    Small,
    Medium,
    Big,
}

const ButtonStyles: { [key: number]: DialogStyleData } = {
    [SizeStyleEnum.Small]: {
        font_size: 44,
        title_pos: cc.v2(3, 207),
        outLine_width: 3,
        close_pos: cc.v2(376, 223),
        uuid_bg: '9f42f0f7-4b9d-4d99-a013-ec106eaed060',
        uuid_close: '00da7355-9a25-4d7f-9098-4f853b8f4db6',
        uuid_font: '6e3630c8-17e9-4790-9fb7-8f54355fbd25',
        content_size: cc.size(706, 320),
        content_pos: cc.v2(0, 10),
    },
    [SizeStyleEnum.Medium]: {
        font_size: 52,
        title_pos: cc.v2(-5, 264),
        outLine_width: 3,
        close_pos: cc.v2(472, 284),
        uuid_bg: '4de6de00-abb2-485f-9b82-9e9e3d29b90e',
        uuid_close: '00da7355-9a25-4d7f-9098-4f853b8f4db6',
        uuid_font: '6e3630c8-17e9-4790-9fb7-8f54355fbd25',
        content_size: cc.size(900, 434),
        content_pos: cc.v2(0, 6),
    },
    [SizeStyleEnum.Big]: {
        font_size: 60,
        title_pos: cc.v2(-5, 266),
        outLine_width: 3,
        close_pos: cc.v2(600, 284),
        uuid_bg: 'd3cf2e6d-8029-4dc4-92d4-571250d6978e',
        uuid_close: '00da7355-9a25-4d7f-9098-4f853b8f4db6',
        uuid_font: '6e3630c8-17e9-4790-9fb7-8f54355fbd25',
        content_size: cc.size(1160, 434),
        content_pos: cc.v2(0, 0),
    },
};

const uuid_content_bg = '7e1e4187-bdba-4cc2-8be0-0be73befce93';

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/rs 弹窗')
export class RsDialog extends cc.Component {
    /** 使用哪种内置大小 */
    @property
    private _size: SizeStyleEnum = SizeStyleEnum.Small;
    @property({ type: cc.Enum(SizeStyleEnum), tooltip: CC_DEV && '弹窗尺寸' })
    get size(): SizeStyleEnum {
        return this._size;
    }
    set size(style: SizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    protected onLoad() {
        CC_PREVIEW && alert(`⚠️ ${cc.js.getClassName(this)} 未删除干净，请排查 ！！！`);

        cc.warn('设置成功后 请删除此组建 RsDialog ！！！');
    }

    async updateStyle() {
        if (!CC_EDITOR) {
            return;
        }

        const data = ButtonStyles[this._size];

        // bg
        this.node.setPosition(0, 0);
        const bg = this.node.addComponentUnique(cc.Sprite);
        bg.spriteFrame = await this.loadSpriteFrame(data.uuid_bg);
        bg.type = cc.Sprite.Type.SLICED;
        bg.sizeMode = cc.Sprite.SizeMode.TRIMMED;

        // RC_title
        let title: cc.Node | null = null;
        if (this.node.getChildByName('RC_title')) {
            title = this.node.getChildByName('RC_title');
        } else {
            title = new cc.Node('RC_title');
        }
        title.setAnchorPoint(0.5, 0.5);
        const title_color = title.addComponentUnique(we.ui.WEColorAssembler);

        const title_label = title.addComponentUnique(cc.Label);
        const title_outline = title.addComponentUnique(cc.LabelOutline);
        title_label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        title_label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        title_label.overflow = cc.Label.Overflow.NONE;
        title_label.fontSize = data.font_size;
        title_label.lineHeight = 62;
        title_label.font = await this.loadFont(data.uuid_font);
        title_color.colors = [cc.color().fromHEX('#d0a347'), cc.color().fromHEX('#fbff99')];
        title_outline.color = cc.color().fromHEX('#104138');
        title_outline.width = data.outLine_width;

        title.setPosition(data.title_pos);
        title.parent = this.node;
        title.setSiblingIndex(0);

        title_label.string = 'Bagaimana Cara Bermain?';

        if (title.getComponent(cc.LabelShadow)) {
            title.removeComponent(cc.LabelShadow);
        }
        // content bg
        let content_bg: cc.Node | null = null;
        if (!this.node.getChildByName('content_bg')) {
            content_bg = new cc.Node('content_bg');
        } else {
            content_bg = this.node.getChildByName('content_bg');
        }
        const content_bg_sp = content_bg.addComponentUnique(cc.Sprite);
        content_bg_sp.spriteFrame = await this.loadSpriteFrame(uuid_content_bg);
        content_bg_sp.type = cc.Sprite.Type.SLICED;
        content_bg_sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        content_bg.setPosition(data.content_pos);
        content_bg.setContentSize(data.content_size);
        content_bg.parent = this.node;
        title.setSiblingIndex(2);

        // RC_btnClose
        let btnClose: cc.Node | null = null;
        if (this.node.getChildByName('RC_btnClose')) {
            btnClose = this.node.getChildByName('RC_btnClose');
        } else {
            btnClose = new cc.Node('RC_btnClose');
        }
        btnClose.setPosition(data.close_pos);
        btnClose.setContentSize(new cc.Size(100, 100));
        btnClose.parent = this.node;
        btnClose.setSiblingIndex(1);

        btnClose.removeAllChildren();

        // close icon
        const closeIcon = new cc.Node('icon');
        closeIcon.addComponent(cc.Sprite).spriteFrame = await this.loadSpriteFrame(data.uuid_close);
        closeIcon.setPosition(0, 0);
        closeIcon.parent = btnClose;
    }

    // //////////////////////////////////////////// 其他方法 ////////////////////////////////////////////

    async loadFont(uuid: string): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    async loadSpriteFrame(uuid: string): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(uuid, (err, asset) => {
                resolve(asset);
            });
        });
    }

    resetInEditor(): void {
        this.updateStyle();
    }
}
