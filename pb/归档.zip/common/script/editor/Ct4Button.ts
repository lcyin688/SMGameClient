const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

class ButtonStyleData {
    spriteUuid: string[] = [];
    /** 字体uuid */
    fontUuid: string = '';
    /** 贴图 */
    @property({ type: cc.SpriteFrame })
    spriteFrame?: cc.SpriteFrame = null;
    /** 贴图颜色叠加 */
    @property()
    sfColor?: cc.Color = cc.color(255, 255, 255.255);
    /** 字号 */
    @property()
    fontSize: number[] = [24, 28, 36];
    /** 字体颜色 */
    @property()
    fontColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字描边 */
    @property()
    enableOutline: boolean = true;
    /** 描边 */
    @property()
    outlineSize: number = 3;
    /** 描边颜色 */
    @property()
    outlineColor: cc.Color = cc.color(255, 255, 255.255);
    /** 文字排版模式 */
    @property({ type: cc.Enum(cc.Label.Overflow) })
    Overflow: cc.Label.Overflow = cc.Label.Overflow.SHRINK;
    /** 渐变色 */
    @property()
    GradientColors: cc.Color[] = [cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];
}

enum ButtonColorStyleEnum {
    /** 蓝色样式 */
    Blue,
    /** 绿色样式 */
    Green,
    /** 灰色样式 */
    Gray,
    /** 黄色样式 */
    Yellow,
}

enum ButtonSizeStyleEnum {
    x_Small,
    Small,
    Medium,
    Big,
}

const ButtonStyles: { [key: number]: ButtonStyleData } = {
    [ButtonColorStyleEnum.Blue]: {
        spriteUuid: ['8f6c5961-8b2d-441a-835b-78253c15d792', '8f6c5961-8b2d-441a-835b-78253c15d792', '0385a004-48c9-4246-9aaa-5b2793979dae', '9077d30b-65a0-4ee9-80c6-1137e3d61faa'],
        fontUuid: '7c169ac7-6d08-4e78-9838-3e5380eb4c9c',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [42, 42, 48, 54],
        enableOutline: true,
        outlineSize: 2.5,
        outlineColor: cc.color().fromHEX('#0469db'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#cdecff'), cc.color().fromHEX('#deffff')],
    },

    [ButtonColorStyleEnum.Green]: {
        spriteUuid: ['11d8687c-e678-4c15-ae79-9558aa22b679', '11d8687c-e678-4c15-ae79-9558aa22b679', '11d8687c-e678-4c15-ae79-9558aa22b679', '13826305-da1e-438a-a852-edb0de80db06'],
        fontUuid: '7c169ac7-6d08-4e78-9838-3e5380eb4c9c',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [48, 48, 48, 54],
        enableOutline: true,
        outlineSize: 2.5,
        outlineColor: cc.color().fromHEX('#076d53'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#cdecff'), cc.color().fromHEX('#deffff')],
    },
    [ButtonColorStyleEnum.Yellow]: {
        spriteUuid: ['d5eeab61-94e8-4e0c-936d-567866305768', '33f47b3a-3571-4323-a79f-5f9a27113e18', '0fc154ab-0f76-4aa1-a1c5-128b035cebfb', '81772eb1-a904-4ead-9e1f-04c7e8e56bf9'],
        fontUuid: '7c169ac7-6d08-4e78-9838-3e5380eb4c9c',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [36, 42, 48, 54],
        enableOutline: true,
        outlineSize: 2.5,
        outlineColor: cc.color().fromHEX('#d55500'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#FFF390'), cc.color().fromHEX('#fffbe1')],
    },
    [ButtonColorStyleEnum.Gray]: {
        spriteUuid: ['281bfc28-e859-4242-bba7-ff21cc3ffc1d', 'eddfc2e0-6af3-40d6-8487-a053f04655e0', '024a8c98-632a-4662-a8d0-59ccc1981266', 'e0a03a8b-71b4-411d-9e45-ad42fdc3c1f8'],
        fontUuid: '7c169ac7-6d08-4e78-9838-3e5380eb4c9c',
        fontColor: cc.color(255, 255, 255, 255),
        fontSize: [36, 42, 48, 54],
        enableOutline: true,
        outlineSize: 2.5,
        outlineColor: cc.color().fromHEX('#534784'),
        Overflow: cc.Label.Overflow.SHRINK,
        GradientColors: [cc.color().fromHEX('#d7d1ef'), cc.color().fromHEX('#f3f2f9')],
    },
};

@ccclass()
@executeInEditMode
@disallowMultiple
@menu('皮肤样式/ct4 按钮')
export class Ct4Button extends cc.Component {
    /** 按钮图片 */
    @property({ type: cc.Sprite, tooltip: CC_DEV && '按钮图片' })
    sprite: cc.Sprite = null;

    /** 按钮文本 */
    @property({ type: cc.Label, tooltip: CC_DEV && '按钮文本' })
    label: cc.Label = null;

    // label 缩放倍数
    readonly labelScale: number = 0.65;

    // /////////////////////////////////////////////////////////////// 按钮风格

    @property
    private _style: ButtonColorStyleEnum = ButtonColorStyleEnum.Blue;
    @property({
        type: cc.Enum(ButtonColorStyleEnum),
        tooltip: CC_DEV && '按钮风格',
    })
    get style(): ButtonColorStyleEnum {
        return this._style;
    }
    set style(style: ButtonColorStyleEnum) {
        if (this._style === style) {
            return;
        }
        this._style = style;
        this.updateStyle();
    }

    // /////////////////////////////////////////////////////////////// 按钮尺寸

    /** 使用哪种内置大小 */
    @property
    private _size: ButtonSizeStyleEnum = ButtonSizeStyleEnum.Medium;
    @property({
        type: cc.Enum(ButtonSizeStyleEnum),
        tooltip: CC_DEV && '按钮尺寸',
    })
    get size(): ButtonSizeStyleEnum {
        return this._size;
    }
    set size(style: ButtonSizeStyleEnum) {
        if (this._size === style) {
            return;
        }
        this._size = style;
        this.updateStyle();
    }

    // ////////////////////////////////////////////////////////////////
    // //////////////////////  按钮  ///////////////////////////////////
    // ////////////////////////////////////////////////////////////////

    onLoad(): void {
        this.sprite = this.getComponent(cc.Sprite);
        if (!this.sprite) {
            this.sprite = this.getComponentInChildren(cc.Sprite);
        }
        this.label = this.getComponentInChildren(cc.Label);
        this.updateStyle();
    }

    async updateStyle() {
        cc.warn('设置成功后 请删除此组建 Ct4Button ！！！');

        if (!CC_EDITOR && this.label && this.label.node.scale == this.labelScale) {
            return;
        }

        const styleData = ButtonStyles[this._style];

        // bg
        if (CC_EDITOR && this.sprite) {
            this.sprite.type == cc.Sprite.Type.SIMPLE;
            this.sprite.sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.sprite.spriteFrame = await this.loadSpriteFrame(styleData);
        }

        // label
        if (this.label) {
            if (CC_EDITOR) {
                this.label.font = await this.loadFont(styleData);
            }

            this.label.node.setPosition(0, 3);
            this.label.node.scale = this.labelScale;
            this.label.enableWrapText = false;

            if (styleData.fontColor) {
                this.label.node.color = styleData.fontColor;
            }

            if (styleData.fontSize) {
                const fontSize = styleData.fontSize[this.size];
                this.label.fontSize = fontSize;
                this.label.lineHeight = fontSize + 8;
            }

            if (styleData.enableOutline) {
                const outLine = this.nodeAddComponent(this.label.node, cc.LabelOutline);
                if (styleData.outlineSize) {
                    outLine.width = styleData.outlineSize;
                }
                if (styleData.outlineColor) {
                    outLine.color = styleData.outlineColor;
                }
            }

            if (styleData.GradientColors) {
                const colorAssembler = this.nodeAddComponent(this.label.node, we.ui.WEColorAssembler);
                colorAssembler.colors = styleData.GradientColors;
            }

            // 移除阴影效果
            this.label.node.removeComponent(cc.LabelShadow);

            this.label.overflow = styleData.Overflow;
            if (styleData.Overflow === cc.Label.Overflow.SHRINK) {
                this.label.node.width = (this.sprite.node.width - 30) * 1.65;
                this.label.node.height = (this.sprite.node.height - 20) * 1.65;
            }
        }
    }

    nodeAddComponent<T extends cc.Component>(node: cc.Node, CLASS: new () => T): T {
        if (!node) {
            return;
        }
        return node.getComponent(CLASS) ?? node.addComponent(CLASS);
    }

    async loadSpriteFrame(style: ButtonStyleData): Promise<cc.SpriteFrame> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.spriteUuid[this.size], (err, asset) => {
                if (err) {
                    cc.error(`load sprite frame with uuid(${style.spriteUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }

    async loadFont(style: ButtonStyleData): Promise<cc.Font> {
        return new Promise((resolve) => {
            cc.assetManager.loadAny(style.fontUuid, (err, asset) => {
                if (err) {
                    cc.error(`load Font with uuid(${style.fontUuid}) error: ${err}`);
                }
                resolve(asset);
            });
        });
    }
}
