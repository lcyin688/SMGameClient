import { CommonEvent } from '../config/CommonEvent';
import VIPConfig from '../config/VIPConfig';
import { CommonLanguage } from '../const/CommonLanguage';
import NamingServiceMgr, { ReceiptName } from '../naming/NamingServiceMgr';
import ActivityMgr from './ActivityMgr';
import CarnivalMgr from './CarnivalMgr';
import WithdrawMgr from './WithdrawMgr';
import CommonMgr from './CommonMgr';
import DailyRechargeMgr from './DailyRechargeMgr';
import DownloadGuideMgr from './DownloadGuideMgr';
import GameOverEventMgr from './GameOverEventMgr';
import IndependentMgr from './IndependentMgr';
import RebateCodeMgr from './RebateCodeMgr';
import StoreMgr from './StoreMgr';
import UserManager from './UserManager';
import { CommonType } from '../config/CommonType';
import ApiManager from '../api/ApiManager';
import { EventMsg } from '../config/CommonEvent';
import { RedDot } from './RedDotMgr';
import { CommonViewId } from '../view/CommonViewId';
import RescueFundsMgr from './RescueFundsMgr';
import PayManager from './PayManager';

declare global {
    interface ICommon {
        /** Naming 推送消息管理类 */
        pushMsgMgr: PushMsgMgr;
    }
}

class PushMsgMgr {
    /** 推送类型 */
    public PUSH_TYPE = {
        /** 顶号消息 */
        REMOTE_LOGIN: -1,
        /** 红点 新消息 */
        NEW_NOTICE: 1,
        /** 新手礼包 */
        FIRST_RECHARGE: 2,
        /** 问券调查 */
        ACTIVITY_QUESTIONNAIRE: 4,
        /** 支付成功 */
        PAY_SUCCESS: 5,
        /** 系统维护的通知(大厅) */
        SYS_MAINTENANCE: 6,
        /** 恢复上次未结束的游戏 */
        RECOVER_LAST_GAME: 7,
        /** 问卷调查完成 */
        QUESTIONNAIRE_FINISH: 12,
        /** 道具刷新 */
        PROP_UPDATE: 13,
        /** 跨天推送 */
        ACROSS_DAY_UPDATE: 14,
        /** 封禁推送 */
        USER_BAN: 15,
        /** 对局任务进度更新 */
        GAME_TASK_PROGRESS: 16,
        /** VIP等级变化 */
        VIP_LEVEL_CHANGE: 18,
        /** Vip经验值变化 */
        VIP_EXP_CHANGE: 19,
        /** 在线热更 */
        ONLINE_UPDATE_VERSION: 20,
        /** 官网充值成功推送 */
        OFFICIAL_WEB_RECHARGE: 21,
        /** 提现播报推送*/
        BROAD_BANK_WITHDRAW: 27,
        /** 提现成功 */
        WITHDRAW_SUCCESS: 31,
        /** 每日签到配置更新 */
        DAILY_FREE_CONF_UPDATE: 32,
        /** 月签到配置更新 */
        BONUS_CHECK_IN_CONF_UPDATE: 33,
        /** 三方充值上报推送 */
        THIRD_PARTY_PAY_REPORT: 34,
    };

    /** 推送消息缓存列表 */
    public pushMsgCacheList: Map<number, any[]> = new Map<number, any[]>();

    public init(): void {
        if (this.pushMsgCacheList) {
            this.pushMsgCacheList.clear();
        } else {
            this.pushMsgCacheList = new Map<number, any[]>();
        }
    }

    /**
     * 处理 naming 推送消息
     * @param msg
     */
    public pushMessageHandle(msg: NamingProto.UserNoticeNT): void {
        if (!msg || typeof msg != 'object') {
            return;
        }

        let initData = null;
        if (msg.Data != '') {
            try {
                initData = JSON.parse(msg['Data']);
            } catch (error) {
                we.error(`PushMsgMgr pushMessageHandle, msg.Data JSON.parse error, msg: ${JSON.stringify(msg)}`);
            }
        }

        switch (msg.Type) {
            case this.PUSH_TYPE.REMOTE_LOGIN:
                if (initData.user_id == UserManager.userInfo.userId) {
                    UserManager.clearLoginData(true, `PUSH_TYPE.REMOTE_LOGIN`);
                    CommonMgr.goLogin(we.core.langMgr.getLangText(we.launcher.lang.TIPS_LOG_DEVICE));
                    // 触发远程登录事件
                    we.event<EventMsg>().emit('RemoteLogin', true);
                }
                break;
            case this.PUSH_TYPE.NEW_NOTICE:
                this.handleRedNoticeMsg(initData);
                break;
            case this.PUSH_TYPE.FIRST_RECHARGE:
                StoreMgr.isNewbieGift = initData.enable ? initData.enable : false;
                if (StoreMgr.isNewbieGift) {
                    StoreMgr.initNewbieGiftBag();
                }
                break;
            case this.PUSH_TYPE.ACTIVITY_QUESTIONNAIRE:
                if (typeof initData == 'object') {
                    ActivityMgr.questionNaireConf.enable = initData.enable;
                    ActivityMgr.questionNaireConf.url = initData.url;
                    cc.director.emit(CommonEvent.SHOW_QUESTIONNAIRE, initData);
                }
                break;
            case this.PUSH_TYPE.PAY_SUCCESS:
                this.onPaySucNotice(initData);
                break;
            case this.PUSH_TYPE.SYS_MAINTENANCE:
                UserManager.clearLoginData(false, `PUSH_TYPE.SYS_MAINTENANCE`);
                CommonMgr.servicesMaintainDialog();
                break;
            case this.PUSH_TYPE.RECOVER_LAST_GAME:
                this.pushMsgCacheList.set(this.PUSH_TYPE.RECOVER_LAST_GAME, [initData]);
                cc.director.emit(CommonEvent.HALL_POPUP_QUEUE_UPDATE);
                break;
            case this.PUSH_TYPE.QUESTIONNAIRE_FINISH:
                ActivityMgr.questionNaireConf.enable = false;
                cc.director.emit(CommonEvent.SHOW_QUESTIONNAIRE);
                break;
            case this.PUSH_TYPE.ACROSS_DAY_UPDATE:
                this.handleAcrossDayData();
                break;
            case this.PUSH_TYPE.USER_BAN:
                UserManager.clearLoginData(true, `PUSH_TYPE.USER_BAN`);
                CommonMgr.goLogin(we.core.langMgr.getLangText(CommonLanguage.ERROR_USUAL_TYPE_1003));
                we.event<EventMsg>().emit('RemoteLogin', true);
                break;
            case this.PUSH_TYPE.GAME_TASK_PROGRESS:
                break;
            case this.PUSH_TYPE.VIP_LEVEL_CHANGE:
                this.handleVipChange(initData);
                break;
            case this.PUSH_TYPE.VIP_EXP_CHANGE:
                VIPConfig.addVPByPay(initData['vp_exp_change'] || 0);
                break;
            case this.PUSH_TYPE.ONLINE_UPDATE_VERSION:
                this.handleOnlineHotUpdate(initData);
                break;
            case this.PUSH_TYPE.OFFICIAL_WEB_RECHARGE:
                break;
            case this.PUSH_TYPE.BROAD_BANK_WITHDRAW:
                WithdrawMgr.onNewBroadArrived(initData);
                break;
            case this.PUSH_TYPE.WITHDRAW_SUCCESS:
                DownloadGuideMgr.getDownloadGuideConf();
                break;
            case this.PUSH_TYPE.DAILY_FREE_CONF_UPDATE:
                ActivityMgr.dataUpdateFlags[ActivityMgr.ActivityType.dailyFreeAward] = false;
                break;
            case this.PUSH_TYPE.BONUS_CHECK_IN_CONF_UPDATE:
                cc.director.emit(CommonEvent.CROSS_DAY_PUSH);
                break;
            case this.PUSH_TYPE.THIRD_PARTY_PAY_REPORT:
                this.onThirdPartyPayReport(initData);
                break;
            default:
                break;
        }
    }

    /**
     * 红点通知处理
     * @param data
     * @returns
     */
    private handleRedNoticeMsg(data: any): void {
        if (!data || typeof data != 'object') {
            return;
        }

        // 客服新消息通知
        if (data.customer_type) {
            let isOpen = we.currentUI.isViewVisible(CommonViewId.CustomerWebDlg);
            if (isOpen) {
                return;
            }

            if (data.customer_type.count > 0) {
                CommonType.storage.setById('common', 'customer', true);
                cc.director.emit(CommonEvent.NOTICE_NEW_CUSTOMER);
                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.server, 1);
            }
        }
        // 邮件新消息通知
        if (data.mail) {
            RedDot.red.updateRedDotCnt(RedDot.cfg.mail, data.mail.count, true);
        }
    }

    /**
     * 在线热更
     * @param data
     * @returns
     */
    private handleOnlineHotUpdate(data: any) {
        if (data?.channel != we.core.nativeUtil.getChannel()) {
            return;
        }

        let gameId = we.core.gameConfig.curGameId;
        // 如果更新子游戏并且当前不在该子游戏内忽略掉
        if (we.core.gameConfig.isSubGame(data.gameId) && gameId != data.gameId) {
            return;
        }

        GameOverEventMgr.updateHotOnlineData.gameId = data.gameId == 0 ? we.GameId.HALL : data.gameId;
        GameOverEventMgr.updateHotOnlineData.version = data.version;
        if (gameId == we.GameId.HALL) {
            GameOverEventMgr.updateHotOnline();
        }
    }

    /**
     * Vip 等级变化处理
     * @param data
     * @returns
     */
    private handleVipChange(data: any): void {
        if (!data || typeof data != 'object') {
            return;
        }

        VIPConfig.getVipAwardStatus();
        UserManager.getVipInfo();
        RebateCodeMgr.getRebateConfig();

        DailyRechargeMgr.getActivityInfo();
        CarnivalMgr.getActivityInfo();
        IndependentMgr.getActivityInfo();
    }

    /**
     * 跨天推送 更新每日刷新数据
     */
    private handleAcrossDayData(): void {
        // 随机跨天数据请求时间节点，避免同一时间发起大量请求
        // 根据玩家ID最后一位，用5求余获取最小随机分钟数，再加上一分钟随机数，为最终请求数据时间
        let minutes = (UserManager.userInfo.userId % 10) % 5;
        let randomTime = Math.ceil(minutes * 60 + 60 * Math.random());
        we.log(`PushMsgMgr handleAcrossDayData, randomTime: ${randomTime}`);

        UserManager.crossDayTimeout = setTimeout(() => {
            UserManager.crossDayTimeout = null;
            if (!we.common.userMgr.isLogin()) {
                return;
            }

            ApiManager.getConfCrossDay(
                (data: ApiProto.ConfCrossDayResp) => {
                    // 活动中心
                    ActivityMgr.formatActivityConf(data?.activityConf, false);
                    // 每日
                    ActivityMgr.dailyFreeAward = data?.dailyFreeAward;
                    // 七日福利
                    ActivityMgr.sevenDayInfo = data?.newbieSevenDayActivityResp;
                    // 救援金
                    if (data.reliefFundApplyList) {
                        RescueFundsMgr.syncData(data.reliefFundApplyList);
                    }
                    // VIP奖励状态
                    VIPConfig.vipAwardStatus.data = data?.vipSysRewardStatusResp;

                    // 每日充值活动
                    if (data.rechargeTaskProgressResp) {
                        DailyRechargeMgr.syncData(data.rechargeTaskProgressResp);
                    }
                    // 狂欢活动
                    if (data.carnivalTaskProgressResp) {
                        CarnivalMgr.syncData(data.carnivalTaskProgressResp);
                    }
                    // 独立日活动
                    if (data.independenceTaskProgressResp) {
                        IndependentMgr.syncData(data.independenceTaskProgressResp);
                    }

                    cc.director.emit(CommonEvent.NOTICE_EVENT_CENTER);
                },
                (code) => {
                    we.error(`PushMsgMgr handleAcrossDayData getConfCrossDay, code:${code}`);
                }
            );

            // 马甲包查询下载引导配置
            DownloadGuideMgr.getDownloadGuideConf();
        }, randomTime * 1000);
    }

    /**
     * 用于充值成功通知 充值成功回执/上报/奖励弹窗/活动相关数据刷新
     * @param data
     * @returns
     */
    private onPaySucNotice(data: any): void {
        if (!data || typeof data != 'object') {
            return;
        }
        if (!data.enable) {
            we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.ROULETTE_PAY));
            return;
        }

        // 由于任务进度更新可能延迟，所以延迟刷新
        ActivityMgr.refreshRechargeTask();
        setTimeout(() => {
            if (!UserManager.isLogin()) {
                return;
            }

            // 下载引导
            DownloadGuideMgr.getDownloadGuideConf(() => {
                if (DownloadGuideMgr.isOpenGuide(DownloadGuideMgr.Type.Recharge)) {
                    if (UserManager.isLogin() && !we.core.gameConfig.isSubGame(we.core.gameConfig.curGameId)) {
                        cc.director.emit(CommonEvent.OPEN_DOWNLOAD_GUIDE);
                    }
                }
            });
        }, 1500);

        // 充值成功推送回执
        NamingServiceMgr.reportReq(data.order_id);

        if (we.common.userMgr.isLogin()) {
            if (we.core.gameConfig.curGameId == we.GameId.HALL) {
                this.onHandleSucNotice(data);
            } else {
                let originalData = this.pushMsgCacheList.get(this.PUSH_TYPE.PAY_SUCCESS) || [];
                this.pushMsgCacheList.set(this.PUSH_TYPE.PAY_SUCCESS, originalData.concat(data));
            }
        }
    }

    /**
     * 充值成功弹窗和内部消息广播
     * @param data
     * @returns
     */
    public onHandleSucNotice(data: any): void {
        if (!data || typeof data != 'object') {
            return;
        }

        let propId = data.prod_id;
        let goodsNameArr: string[] = propId.split('_');
        if (goodsNameArr.length < 1) {
            return;
        }

        // 商品 id 格式: P-{product_type}-{level}, P- 开头是新商品格式
        let productPrefix = goodsNameArr[0];
        switch (productPrefix) {
            case 'first':
                StoreMgr.isNewbieGift = false;
                cc.director.emit(CommonEvent.CLOSE_FIRST_RECHARGE_DIALOG, false);
                cc.director.emit(CommonEvent.GIFT_BAG_UPDATE);
                StoreMgr.initNewbieGiftBag();
                break;
            case 'waka': // 缓存商城商品充值数值记录
                this.cacheStoreRechargeInfo(data);
                break;
            default:
                if (productPrefix.startsWith(`P-${PayManager.PRODUCT_TYPE.WEEKLY_CARD}`)) {
                    cc.director.emit(CommonEvent.WEEK_CARD_BUY_SUCCESS, true);
                } else if (productPrefix.startsWith(`P-${PayManager.PRODUCT_TYPE.SEVEN_DAY_WELFARE}`)) {
                    cc.director.emit(CommonEvent.SEVEN_DAY_BUY_SUCCESS);
                }
                break;
        }

        // 奖励弹窗
        let propData: any = data.package;
        for (let key in propData) {
            let id = parseInt(key);
            const award = id == UserManager.PropId.CoinId ? propData[key] + data.activity_add_gold : propData[key];
            if (award > 0) {
                cc.director.emit(CommonEvent.AWARD_RECHARGE_SUC_DLG, award, productPrefix);
                cc.director.emit(CommonEvent.CHECK_PAY_SUCCESS_PUSH);
            } else {
                we.warn(`PushMsgMgr onHandleSucNotice, award `);
            }
        }

        cc.director.emit(CommonEvent.PAY_SUCCESS);
    }

    /**
     * 用于处理三方充值上报推送
     * @param data
     */
    private onThirdPartyPayReport(data: any): void {
        const report_trace_id = data.report_trace_id;

        // 过滤重复上报
        const receiptRecord = CommonType.storage.get('common', 'push_msg_receipt_record') || {};
        const purchaseRec: string[] = receiptRecord[ReceiptName.payReport] || [];
        if (purchaseRec.includes(report_trace_id)) {
            const printData = {
                chn: we.core.nativeUtil.getChannel(),
                userId: we.kit.storageUtil.readUserId(),
                data: data,
            };
            we.info(`PushMsgMgr onThirdPartyPayReport, push repeated data: ${JSON.stringify(printData)}`);
        } else {
            purchaseRec.push(report_trace_id);
            if (purchaseRec.length > 100) {
                purchaseRec.splice(0, purchaseRec.length - 100);
            }
            receiptRecord[ReceiptName.payReport] = purchaseRec;
            CommonType.storage.setById('common', 'push_msg_receipt_record', receiptRecord);

            // 充值上报
            this.paySucTrackEvent(data);
        }

        // 上报完成 http 回执
        ApiManager.clientReportAdjustCallback({ reportTraceId: report_trace_id }, null, (code) => {
            we.info(`PushMsgMgr onThirdPartyPayReport, clientReportAdjustCallback err code: ${code} data: ${JSON.stringify(data)}`);
        });
    }

    /**
     * 充值上报 First_Purchase / New_Purchase / Total_Purchase
     * @param data
     * @returns
     */
    private paySucTrackEvent(data: any): void {
        let currency: string = data.currency;

        // TODO 兼容 price + amount字段，优先使用 price 字段，后续废弃 amount 字段
        let price: number = 0;
        if (data.price) {
            price = data.price;
        } else if (data.amount) {
            price = data.amount;
        }

        const printData = {
            cchn: we.kit.storage.get('sys', 'user_create_channel'),
            data: data,
        };

        if (price < 0) {
            we.info(`PushMsgMgr paySucTrackEvent price < 0, printData: ${JSON.stringify(printData)}`);
            price = 0;
        }

        we.info(`PushMsgMgr paySucTrackEvent, printData: ${JSON.stringify(printData)}`);
        let priceNum = price / we.core.flavor.getPricePrecision();
        if (we.core.trackMgr.isClientReport) {
            let revenue = {
                currency: currency,
                revenue: priceNum + '',
            };
            if (data.is_first_purchase) {
                we.core.trackMgr.trackEvent(we.core.trackConfig.purchase.first, null, revenue);
            }
            if (data.is_new_purchase) {
                we.core.trackMgr.trackEvent(we.core.trackConfig.purchase.new, null, revenue);
            }
            if (data.is_repeat_purchase) {
                we.core.trackMgr.trackEvent(we.core.trackConfig.purchase.repeat, null, revenue);
            }
            if (data.is_2nd_purchase) {
                we.core.trackMgr.trackEvent(we.core.trackConfig.purchase.second, null, revenue);
            }
            if (data.is_5th_purchase) {
                we.core.trackMgr.trackEvent(we.core.trackConfig.purchase.fifth, null, revenue);
            }
        }

        let revenueEx = {
            currency: currency,
            value: priceNum,
        };
        if (data.is_first_purchase) {
            we.core.trackMgr.trackEventEx(we.core.trackConfig.purchase.firstEx, revenueEx);
        }
        if (data.is_new_purchase) {
            we.core.trackMgr.trackEventEx(we.core.trackConfig.purchase.newEx, revenueEx);
        }
        if (data.is_repeat_purchase) {
            we.core.trackMgr.trackEventEx(we.core.trackConfig.purchase.repeatEX, revenueEx);
        }
        if (data.is_2nd_purchase) {
            we.core.trackMgr.trackEventEx(we.core.trackConfig.purchase.secondEx, revenueEx);
        }
        if (data.is_5th_purchase) {
            we.core.trackMgr.trackEventEx(we.core.trackConfig.purchase.fifthEx, revenueEx);
        }
    }

    /**
     * 充值成功金额缓存本地
     * @param data
     * @returns
     */
    private cacheStoreRechargeInfo(data: any): void {
        if (!data) {
            return;
        }

        let propId = data.prod_id;
        // 商城道具 Id
        if (propId != StoreMgr.goodsId) {
            return;
        }

        let cacheData = CommonType.storage.get('common', 'recharge_store_last_record') || [];
        let payType = data.pay_type;
        let isExist = false;
        if (cacheData.length > 0) {
            for (let i = 0; i < cacheData.length; i++) {
                if (cacheData[i].payType == payType) {
                    cacheData[i].amount = data.price;
                    isExist = true;
                    break;
                }
            }
        }

        if (!isExist) {
            let tempData = {
                payType: payType,
                amount: data.price,
            };
            cacheData.push(tempData);
        }

        CommonType.storage.setById('common', 'recharge_store_last_record', cacheData);
    }
}

export default we.common.pushMsgMgr = new PushMsgMgr();
