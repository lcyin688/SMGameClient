import ApiManager from '../api/ApiManager';
import { CommonLanguage } from '../const/CommonLanguage';
import HttpProtoError from '../http/HttpProtoError';

declare global {
    interface ICommon {
        /** 打码返利 管理类 */
        rebateCodeMgr: RebateCodeMgr;
    }
}

class RebateCodeMgr {
    /** 游戏类型枚举，顺序和命名不可修改，下标与 UI 资源绑定有关联 */
    public readonly groupKey = ['bet', 'slot', 'card', 'single', 'fish', 'live'];

    /** 分组多语言 key, 在 HallLanguage 中 */
    public readonly groupLangKey = {
        bet: 'HALL_GAME_TYPE_2',
        slot: `HALL_GAME_TYPE_3`,
        card: `HALL_GAME_TYPE_4`,
        single: `HALL_GAME_TYPE_5`,
        fish: `HALL_GAME_TYPE_6`,
        live: `HALL_GAME_TYPE_11`,
    };

    /** 可领取的返利值 */
    public availableNum: number = -1;

    /** 所有返利信息汇总数据 */
    public rebateInfo: ApiProto.UserRebateInfoNewResp = null;

    /** 返利基础配置 开关 / vip 返利比率 */
    public baseConfig: ApiProto.UserRebateConfNewResp = null;

    /**
     * 游戏打码返利比例配置
     * key: slot bet card fish single
     * 特殊 bet->百人场, card->对战类, slot->老虎机, fish->捕鱼, single->单机休闲
     */
    public gameRatioMap: Map<string, ApiProto.GameRebateRatioConfig[]> = new Map<string, ApiProto.GameRebateRatioConfig[]>();

    public init(): void {
        this.availableNum = -1;
        this.rebateInfo = null;
        this.baseConfig = null;
        this.gameRatioMap.clear();
    }

    public syncData(data: ApiProto.UserRebateConfNewResp) {
        if (data) {
            this.baseConfig = data;

            // 获取返利汇总信息
            this.getRebateInfo();
        }
    }

    /**
     * 获取打码返利的基础配置
     * @param sucCb
     */
    public getRebateConfig(sucCb?: Function) {
        ApiManager.userRebateConfig((data: ApiProto.UserRebateConfNewResp) => {
            this.baseConfig = data;
            sucCb?.();
        });
    }

    /**
     * 获取用户返利信息的汇总
     * @param sucCb
     */
    public getRebateInfo(sucCb?: Function) {
        this.availableNum = -1;
        ApiManager.userRebateALLRecode((data: ApiProto.UserRebateInfoNewResp) => {
            let isUpdate = false;
            if (data.unGetRebate != this.availableNum || this.rebateInfo.currentCircleBetAmount != data.currentCircleBetAmount || this.rebateInfo.predictRebateAmount != data.predictRebateAmount) {
                isUpdate = true;
            }

            this.rebateInfo = data;
            this.availableNum = data.unGetRebate;
            if (this.availableNum >= this.baseConfig?.minRebateAmount && this.baseConfig?.minRebateAmount > 0) {
                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.rebateCodeReceive, 1, true);
            }

            sucCb?.(isUpdate);
        }, null);
    }

    /**
     * 获取用户返利记录
     * @param sucCb
     */
    public getRebateRecord(sucCb?: Function) {
        let reqData: ApiProto.UserRebateRecordReq = {
            begin: 0,
            limit: 30,
        };

        ApiManager.RebateRecord(reqData, (data: ApiProto.UserRebateRecordResp) => {
            sucCb?.(data);
        });
    }

    /**
     * 获取用户领取返利记录
     * @param reqData
     * @param sucCb
     * @returns
     */
    public getReceiveRecode(reqData: ApiProto.UserRebateGetRecordReq, sucCb?: Function) {
        if (!reqData) {
            we.error(`RebateCodeManager getReceiveRecode, param error`);
            return;
        }

        ApiManager.ReceiveRecode(reqData, (data: ApiProto.UserRebateGetRecordResp) => {
            sucCb?.(data);
        });
    }

    /**
     * 获取游戏的具体打码返利比例
     */
    public getGameRebateRatioConfig() {
        ApiManager.userRebateRatioConfig((data: ApiProto.GameRebateRatioConfigResp) => {
            let map: Map<string, ApiProto.GameRebateRatioConfig[]> = new Map<string, ApiProto.GameRebateRatioConfig[]>();
            data.gameRebateRatioConfig.forEach((item) => {
                // 未开放游戏不展示
                if (we.core.projectConfig.gameListMap.has(item.gameId) && item.gameType) {
                    let type = item.gameType?.toLocaleLowerCase();
                    let tem = map.get(type) || [];
                    tem.push(item);
                    map.set(type, tem);
                }
            });

            // 按需缩减配置
            map.forEach((value, key) => {
                let result = this.formatRebateRatioCfg(key, value);
                map.set(key, result);
            });

            this.gameRatioMap = map;
        });
    }

    /**
     * 格式化游戏返比比列
     * 针对相同分组相同比列的数据最多的整合至一起使用该组通用 icon 展示
     * @param type 分组
     * @param data 分组数据
     * @returns
     */
    private formatRebateRatioCfg(type: string, data: ApiProto.GameRebateRatioConfig[]) {
        let result = [0, 0];
        for (let i = 0; i < data.length; i++) {
            let count = 0;
            for (let j = 0; j < data.length; j++) {
                if (data[i].rebateRatio == data[j].rebateRatio) {
                    ++count;
                }
            }
            if (count > result[0]) {
                result[0] = count;
                result[1] = data[i].rebateRatio;
            } else if (count == result[0] && result[1] < data[i].rebateRatio) {
                result[1] = data[i].rebateRatio;
            }
        }
        let resultArr: ApiProto.GameRebateRatioConfig[] = [];
        for (let i = 0; i < data.length; i++) {
            if (data[i].rebateRatio != result[1]) {
                resultArr.push(data[i]);
            }
        }
        resultArr.sort((a, b) => {
            return b.rebateRatio - a.rebateRatio;
        });

        // 是否支持缩减展示
        let index = this.groupKey.indexOf(type);
        if (index != -1) {
            resultArr.unshift({
                gameId: index,
                rebateRatio: result[1],
                gameType: type,
            });
        }

        return resultArr;
    }

    /**
     * 领取返利奖励
     * @param sucCb
     * @param errCb
     */
    public userReceiveRebate(sucCb?: Function, errCb?: Function) {
        ApiManager.ReceiveRebate(
            (data: ApiProto.UserRebateGetResp) => {
                this.availableNum = 0;
                this.rebateInfo.unGetRebate = 0;

                we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.rebateCodeReceive, 0, true);
                sucCb?.(data);
            },
            (code) => {
                if (code == HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3023) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.ERROR_USUAL_TYPE_3023));
                }
                errCb?.(code);
            },
            true
        );
    }
}

export default we.common.rebateCodeMgr = new RebateCodeMgr();
