import ApiManager from '../api/ApiManager';

declare global {
    interface ICommon {
        /** 邮件管理类 */
        mailMgr: MailMgr;
    }
}

class MailMgr {
    /** 邮件类型 */
    public MailType = {
        /** 系统邮件 */
        System: 0,
        PrivateMsg: 1,
        AgentGift: 2,
        TransferMoney: 3,
    };

    /** 邮件状态 */
    public MailStatus = {
        /** 未读 */
        Unread: 0,
        /** 已读（无附件） */
        Read: 1,
        /** 已读未领取（有附件） */
        ReadUnDraw: 2,
        /** 已领取 */
        ReadAndDraw: 3,
    };

    /**
     * 每页显示数量，暂定 50 条
     * 能容括大部分玩家所有的邮件数量，方便处理 新邮件数量 和 一键领取按钮展示逻辑
     * 较少邮件接口请求次数
     */
    private pageSize: number = 50;

    /** 分页下标 */
    private pageIndex: number = 1;

    /** 是否最后一页 */
    private isLastPage: boolean = false;

    /** 邮件列表请求锁 */
    private reqLock: boolean = false;

    /** 新邮件数 */
    public newMailNum: number = 0;

    /** 红点数 未读+未领取附件 */
    public mailNoticeNum: number = 0;

    /** 是否存在已读邮件 */
    public isExistReadMail: boolean = false;

    /** 邮件数据 */
    public mailList: ApiProto.MailDetailItem[] = [];

    public init() {
        // TODO 移除老邮件本地缓存数据
        // CommonType.storage.setById('common', 'mail_cache', this.curMailCaches);
    }

    /**
     * 获取邮件列表数据
     * @param realtime 实时数据
     * @param isShowLoading
     */
    public getMailList(realtime: boolean = true, isShowLoading: boolean = false): Promise<ApiProto.MailDetailItem[]> {
        if (realtime) {
            this.pageIndex = 1;
            this.isLastPage = false;
            this.isLastPage = false;
            this.reqLock = false;
        }

        // 请求锁或未登录，直接返回
        if (this.reqLock || !we.common.userMgr.isLogin()) {
            return;
        }

        return new Promise((resolve, reject) => {
            if (this.isLastPage) {
                resolve(this.mailList);
                return;
            }

            this.reqLock = true;

            let req = {} as ApiProto.GetMailListReq;
            req.pageIndex = this.pageIndex;
            req.pageSize = this.pageSize;
            ApiManager.getMailList(
                req,
                (data: ApiProto.GetMailListResp) => {
                    this.isLastPage = data?.items?.length < this.pageSize;
                    if (realtime) {
                        this.mailList = [];
                    }

                    this.mailList.push(...data.items);
                    !this.isLastPage && this.pageIndex++;

                    this.formatMailData();

                    resolve(this.mailList);
                    cc.director.emit(we.common.EventName.UPDATE_MAIL_LIST);

                    this.reqLock = false;
                },
                (code: number) => {
                    this.reqLock = false;
                    reject(code);
                },
                isShowLoading
            );
        });
    }

    /**
     * 读单个邮件
     * @param mailId
     * @returns
     */
    public readMail(mailId: string): Promise<ApiProto.ReadMailResp | null> {
        return new Promise((resolve, reject) => {
            let req = {} as ApiProto.ReadMailReq;
            req.mailId = mailId;
            ApiManager.readMail(
                mailId,
                (data: ApiProto.ReadMailResp) => {
                    let mailData = this.mailList.find((item) => {
                        return item.mailId == mailId;
                    });
                    let isExistAttachment = we.common.mailMgr.isExistAttachment(mailData);
                    let status = isExistAttachment ? we.common.mailMgr.MailStatus.ReadUnDraw : we.common.mailMgr.MailStatus.Read;
                    we.common.mailMgr.updateMailStatus([mailId], status);

                    resolve(data);
                },
                (code) => {
                    this.handleErrorCode(code);
                    reject(code);
                }
            );
        });
    }

    /**
     * 邮件 领取奖励
     * @param mailIds 有值时，领取指定邮件; 无值时，读所有邮件和领取有附件邮件
     * @returns
     */
    public getMailAward(mailIds?: string[]): Promise<ApiProto.ReadAllMailResp | null> {
        return new Promise((resolve, reject) => {
            // 默认领取成功，领取失败 code 时会重新刷新数据
            if (mailIds?.length > 0) {
                this.updateMailStatus(mailIds, we.common.mailMgr.MailStatus.ReadAndDraw);
            }

            ApiManager.getMailAward(
                mailIds,
                (data: ApiProto.ReadAllMailResp) => {
                    this.updateMailStatus(mailIds, we.common.mailMgr.MailStatus.ReadAndDraw);

                    resolve(data);
                },
                (code) => {
                    this.handleErrorCode(code);
                    reject(code);
                }
            );
        });
    }

    /**
     * 邮件 删除
     * @param mailIds 有值时，删除指定邮件; 无值时，删除所有已读已领取邮件
     * @returns
     */
    public deleteMail(mailIds?: string[]): Promise<ApiProto.DeleteAllMailResp | null> {
        return new Promise((resolve, reject) => {
            // 默认删除成功，删除失败 code 时会重新刷新数据
            if (mailIds?.length > 0) {
                mailIds.forEach((item) => {
                    this.deleteMailById(item);
                });
            }

            ApiManager.deleteMails(
                mailIds,
                (data: ApiProto.DeleteAllMailResp) => {
                    resolve(data);
                },
                (code) => {
                    this.handleErrorCode(code);
                    reject(code);
                }
            );
        });
    }

    /**
     * 获取有效时间
     * @param data
     * @returns s
     */
    public getMailValidTime(data: ApiProto.MailDetailItem): number {
        if (!data) {
            return -1;
        }

        let curTime = we.core.TimeInfo.Inst.serverNow();
        let validTime = data.expireTime - curTime;
        return Math.floor(validTime / 1000);
    }

    /**
     * 更新邮件状态
     * @param mailId
     * @param status
     */
    public updateMailStatus(mailId: string[], status: number): void {
        let mailList = this.mailList || [];
        for (let i = 0; i < mailList.length; i++) {
            let data = mailList[i];
            if (mailId?.includes(data.mailId)) {
                data.status = status;
            }
        }

        this.formatMailData();
    }

    /**
     * 删除临时数据中邮件
     * @param mailId
     */
    public deleteMailById(mailId: string): void {
        this.mailList = this.mailList.filter((item) => {
            return item.mailId != mailId;
        });
    }

    /**
     * 获取邮件是否存在可领取附件
     * @param data
     * @returns
     */
    public isExistAttachment(data: ApiProto.MailDetailItem): boolean {
        if (!data) {
            return false;
        }

        let attachment = data.attachment;
        if (Object.keys(attachment || {}).length > 0) {
            if (data.status != this.MailStatus.ReadAndDraw) {
                return true;
            }
        }

        return false;
    }

    /**
     * 按照需求排序，同等状态按照时间收到时间顺序排序
     * 1.有附件可领取
     * 2.未读
     * 3.已读
     *
     * 红点数据 + 新邮件数据 + 已读邮件数据 初始化
     */
    private formatMailData(): void {
        this.isExistReadMail = false;
        this.newMailNum = 0;

        let unRead = [];
        let read = [];
        let unDraw = [];
        for (let mail of this.mailList) {
            if (Object.keys(mail.attachment).length > 0) {
                switch (mail.status) {
                    case this.MailStatus.Unread:
                        this.newMailNum += 1;
                        unDraw.push(mail);
                        break;
                    case this.MailStatus.ReadUnDraw:
                        unDraw.push(mail);
                        break;
                    default:
                        this.isExistReadMail = true;
                        read.push(mail);
                        break;
                }
            } else {
                if (this.MailStatus.Unread == mail.status) {
                    this.newMailNum += 1;
                    unRead.push(mail);
                } else {
                    this.isExistReadMail = true;
                    read.push(mail);
                }
            }
        }

        unRead.sort((a, b) => {
            return b.receiveTime - a.receiveTime;
        });
        read.sort((a, b) => {
            return b.receiveTime - a.receiveTime;
        });
        unDraw.sort((a, b) => {
            return b.receiveTime - a.receiveTime;
        });

        // 有奖励邮件、未读邮件、已读邮件
        this.mailList = [...unDraw, ...unRead, ...read];

        // 红点数
        this.mailNoticeNum = unDraw.length + unRead.length;
        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.mail, this.mailNoticeNum, true);
    }

    /**
     * 处理邮件错误 code
     * @param code
     */
    private handleErrorCode(code: number): void {
        switch (code) {
            case we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40001:
            case we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40004:
            case we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40005:
            case we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40009:
                // 异常后更新邮件列表数据
                this.getMailList();
                we.commonUI.showToast(we.core.langMgr.getLangText(we.common.lang[`ERROR_USUAL_TYPE_${code}`]));
                break;
            default:
                break;
        }
    }
}

export default we.common.mailMgr = new MailMgr();
