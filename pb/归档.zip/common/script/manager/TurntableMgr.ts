/**
 * 转盘活动管理类
 */

import { CommonEvent } from '../config/CommonEvent';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 转盘活动模块 */
        turntableMgr: TurntableMgr;
    }
}

class TurntableMgr {
    public turntableData: ApiProto.RodaActivityInfoResp = {} as ApiProto.RodaActivityInfoResp;

    private coolingReq = false;

    private static _ins: TurntableMgr = null;
    public static ins(): TurntableMgr {
        if (!this._ins) {
            this._ins = new TurntableMgr();
        }

        return this._ins;
    }

    init() {
        this.turntableData = {} as any;
    }

    /**
     * 获取转盘活动是否开始
     * @returns
     */
    getTurntableIsAct() {
        const data = this.turntableData;
        return Boolean(data.status);
    }

    /**
     * 获取红点数
     */
    getTurntableRedCount(isUpdate = true) {
        let count = 0;
        if (this.turntableData.userData && this.turntableData.userData.cnt > 0) {
            count = 1;
        }
        if (isUpdate) {
            we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.turntable, count, true);
        }
        return count;
    }

    /**
     * 获取转盘活动数据
     */
    getTurntableData(showLoading = false): Promise<ApiProto.RodaActivityInfoResp> {
        return new Promise((resolve, reject) => {
            if (this.coolingReq) {
                resolve(null);
                return;
            }
            this.coolingReq = true;
            we.common.apiMgr.getRodaUndianActivityInfo(
                (res: ApiProto.RodaActivityInfoResp) => {
                    this.turntableData = res;
                    this.clearLock();
                    cc.director.emit(we.common.EventName.UPDATE_TURNTABLE_TASK);
                    resolve(res);
                },
                () => {
                    this.clearLock();
                    resolve(null);
                },
                showLoading
            );
        });
    }

    /**
     * 获取转动转盘后的结果
     */
    getRodaUndianAward(): Promise<ApiProto.RodaActivityAwardResp> {
        return new Promise((resolve, reject) => {
            if (this.turntableData.userData.cnt <= 0) {
                reject(new Error('Insufficient frequency'));
                return;
            }
            we.common.apiMgr.getRodaUndianAward((res: ApiProto.RodaActivityAwardResp) => {
                this.turntableData.userData.cnt = res.remainNum;
                resolve(res);
            });
        });
    }

    /**
     * 获取历史记录
     */
    getRodaUndianUpPage(params: ApiProto.RodaActivityUpPageReq, showLoading = false): Promise<ApiProto.RodaActivityUpPageResp> {
        return new Promise((resolve, reject) => {
            we.common.apiMgr.getRodaUndianUpPage(
                params,
                (res: ApiProto.RodaActivityUpPageResp) => {
                    resolve(res);
                },
                null,
                showLoading
            );
        });
    }

    /**
     * 同步转盘活动数据
     * @param data
     * @returns
     */
    public syncData(data: ApiProto.RodaActivityInfoResp): void {
        if (!data || !UserManager.isLogin()) {
            return;
        }

        this.turntableData = data;
        this.clearLock();
        this.getTurntableRedCount();
        cc.director.emit(CommonEvent.UPDATE_TURNTABLE_TASK);
    }

    /** 清理转盘活动请求状态锁 */
    public clearLock(): void {
        this.coolingReq = false;
    }
}

export default we.common.turntableMgr = TurntableMgr.ins();
