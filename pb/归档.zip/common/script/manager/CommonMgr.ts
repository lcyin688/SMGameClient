import { CommonEvent } from '../config/CommonEvent';
import { CommonRes } from '../config/CommonRes';
import { CommonLanguage } from '../const/CommonLanguage';
import GameManager from './GameManager';
import { RedDot } from './RedDotMgr';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        commonMgr: CommonMgr;
    }
}

class CommonMgr {
    private gameEntryCancel: we.core.CancelAction;
    /**
     * 播放通用按钮音效
     */
    public playBtnMusic(): void {
        we.core.audioMgr.playEffect(we.core.projectConfig.audioCfg.click);
    }

    /**
     * 计算到下一个跨天的时间间隔
     * @param {number} timestamp - 给定时间的时间戳（毫秒），默认为当前服务器时间戳
     * @param {number} hours - 跨天时间点 h 点，默认：6:00
     * @param {number} random - 向上随机时间范围（s），避免请求密集，默认：300s
     * @returns {number} 到下一个跨天点的毫秒数 ms
     */
    public getCrossDayInterval(timestamp: number = we.core.TimeInfo.Inst.serverNow(), hours: number = 6, random: number = 300) {
        const date = new Date(timestamp);
        const nextSix = new Date(date);
        nextSix.setHours(hours, 0, 0, 0);
        // 如果给定时间已经过了今天的 6:00，或者恰好是今天的 6:00，调整到明天的 6:00
        if (date.getHours() >= hours) {
            nextSix.setDate(nextSix.getDate() + 1);
        }
        const timeDiff = nextSix.getTime() - date.getTime();
        return Math.max(timeDiff, 0) + Math.random() * random * 1000;
    }

    /**
     * 远端资源加载Loading
     * @param loadingParent
     * @param timeout
     * @returns
     */
    public createRemoteLoading(loadingParent: cc.Node, timeout: number = 10) {
        const option = {
            parent: loadingParent,
            timeout: timeout,
            debug: 'CommonMgr createRemoteLoading',
        } as we.ui.type.CircleLoadingInfo;
        we.commonUI.showCircleLoading(option);
    }

    /**
     * 移除远端资源加载Loading
     * @param loadingParent
     */
    public removeRemoteLoading(loadingParent: cc.Node) {
        if (!cc.isValid(loadingParent)) {
            return;
        }
        we.commonUI.hideCircleLoading(loadingParent);
    }

    /**
     * 退回登录界面提示弹窗
     * @param content 提示内容
     * @param code 异常 code
     */
    public goLogin(content: string, code?: string): void {
        we.commonUI.showConfirm({
            content: code ? `${content}: ${code}` : content,
            isHideCloseBtn: true,
            yesHandler: we.core.Func.create(() => {
                UserManager.exitLogin();
            }),
            forceShow: true,
            cover: false,
        });
    }

    /** 游戏维护弹窗 */
    public servicesMaintainDialog(callBack?: Function): Promise<void> {
        const option = {
            title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1),
            content: we.core.langMgr.getLangText(we.launcher.lang.GAME_MAINTENANCE),
            yesHandler: we.core.Func.create(() => {
                typeof callBack == 'function' && callBack();
                UserManager.exitLogin();
            }),
            isHideCloseBtn: true,
        } as we.ui.type.ConfirmPopupOptions;

        return we.commonUI.showConfirm(option);
    }

    /**
     * 未完成游戏弹窗
     * @param gameId
     * @param roomKind
     * @param cancelCb 取消回掉
     */
    public unfinishedGameDialog(gameId: number, roomKind: number, cancelCb?: Function): Promise<void> {
        const option = {
            title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_NOTICE_1),
            content: we.core.langMgr.getLangText(CommonLanguage.DUANXIAN_1),
            yesHandler: we.core.Func.create(() => {
                GameManager.runGame(
                    gameId,
                    roomKind,
                    () => {
                        cc.director.emit(we.core.EventName.LOGIN_SUCCESS);
                    },
                    false,
                    { quickStart: true }
                );
            }),
            noHandler: we.core.Func.create(() => {
                typeof cancelCb == 'function' && cancelCb();
            }),
            isHideCloseBtn: true,
        } as we.ui.type.ConfirmPopupOptions;

        return we.commonUI.showConfirm(option);
    }

    /**
     * 移除切场加载界面
     * TODO 等待 GameLauncher 移除使用后移除并更新上线后移除
     * @deprecated
     */
    public removeGameEntryLoading() {
        this.gameEntryCancel?.cancel();
    }

    /**
     * 打开客服对话框
     */
    public openCustomerDialog() {
        if (we.core.projectConfig.commonConfig.customerType === 'platform') {
            return we.currentUI.show(we.common.CommonViewId.CustomerWebDlg);
        } else {
            return we.core.nativeUtil.openUrl(we.core.projectConfig.commonConfig.customerUrl);
        }
    }
}

export default we.common.commonMgr = new CommonMgr();
