import CommonSocket from '../socket/CommonSocket';
import { WsCloseCode } from '../socket/SocketCode';

declare global {
    interface ICommon {
        socketMgr: typeof SocketManager;
    }
}

export default class SocketManager {
    private static sockets: Map<we.GameId, CommonSocket> = new Map<we.GameId, CommonSocket>();

    /**
     * 预加载
     * @param gameId
     */
    public static preload(gameId: we.GameId): void {
        this.create(gameId);
    }

    /**
     * 创建 socket
     * @param gameId
     * @returns
     */
    private static create(gameId: we.GameId): CommonSocket {
        if (!we.GameId[gameId]) {
            we.warn(`SocketManager create, gameId err: ${gameId}`);
            return null;
        }

        let socket = this.sockets.get(gameId);
        if (socket) {
            socket.close(WsCloseCode.New, 'SocketManager create');
            socket = null;
            this.sockets.delete(gameId);
        }

        let url = '';
        if (gameId == we.GameId.NAMING) {
            url = we.core.serverMgr.getNamingWs();
        } else {
            url = we.common.gameServerMgr.getGameWs(gameId);
        }

        socket = new CommonSocket(gameId, url);
        this.sockets.set(gameId, socket);

        return socket;
    }

    /**
     * 获取 socket
     * @param gameId
     * @returns
     */
    public static get(gameId: we.GameId): CommonSocket {
        if (!we.GameId[gameId]) {
            we.warn(`SocketManager get, gameId err: ${gameId}`);
            return null;
        }

        let socket = this.sockets.get(gameId);
        if (!socket) {
            socket = this.create(gameId);
        }

        return socket;
    }

    /**
     * 销毁 socket
     * @param gameId
     * @returns
     */
    public static destroy(gameId: we.GameId): void {
        if (!we.GameId[gameId]) {
            we.warn(`SocketManager destroy, gameId err: ${gameId}`);
            return null;
        }

        let socket = this.sockets.get(gameId);
        if (socket) {
            socket = null;
            this.sockets.delete(gameId);
        }
    }
}

we.common.socketMgr = SocketManager;
