import { CommonEvent } from '../config/CommonEvent';
import VIPConfig from '../config/VIPConfig';
import { CommonLanguage } from '../const/CommonLanguage';
import HttpProtoError from '../http/HttpProtoError';
import NamingServiceMgr from '../naming/NamingServiceMgr';
import ActivityMgr from './ActivityMgr';
import AgentMgr from './AgentMgr';
import CarnivalMgr from './CarnivalMgr';
import WithdrawMgr from './WithdrawMgr';
import DailyRechargeMgr from './DailyRechargeMgr';
import DownloadGuideMgr from './DownloadGuideMgr';
import IndependentMgr from './IndependentMgr';
import RebateCodeMgr from './RebateCodeMgr';
import { RedDot } from './RedDotMgr';
import StoreMgr from './StoreMgr';
import UserManager from './UserManager';
import GameManager from './GameManager';
import { CommonType } from '../config/CommonType';
import ApiManager from '../api/ApiManager';
import GameServerMgr from './GameServerMgr';
import TurntableMgr from './TurntableMgr';
import BankMgr from './BankMgr';
import RescueFundsMgr from './RescueFundsMgr';
import { CommonViewId } from '../view/CommonViewId';
import { CommonModel } from '../model/CommonModel';
import CommonUtils from '../utils/CommonUtils';

declare global {
    interface ICommon {
        /** 登录管理 */
        loginMgr: LoginManager;
    }

    namespace we {
        namespace common {
            type LoginManager = typeof LoginManager;
        }
    }
}

class LoginManager {
    /** 上报服务器数据 timer */
    public reportTimer: any = -1;

    /**
     * 换包免密临时登录初始化，仅在自动登录时触发
     * @returns
     */
    private initTempLogin(): void {
        if (cc.sys.isNative) {
            // 判定当前包是否请求过临时登录 token，如果存在取消读去粘贴板，防止本包使用临时登录 token 修改粘贴板数据
            let getTmpTokenTag = we.kit.storage.get('sys', 'user_get_tmp_token_login_tag') > 0;
            if (getTmpTokenTag) {
                return;
            }

            let chipText = we.core.nativeUtil.getClipboardText();
            if (!chipText) {
                return;
            }
            try {
                chipText = we.core.utils.base64Decode(chipText);
                if (!chipText) {
                    return;
                }
                try {
                    let data = JSON.parse(chipText);
                    if (!data || typeof data != 'object') {
                        return;
                    }
                    // 临时登录 token 失效仅一个小时
                    if (new Date().getTime() / 1000 - (data.ts || 0) >= 60 * 60) {
                        return;
                    }

                    if (data.userId && data.tmpToken) {
                        we.kit.storage.setById('sys', 'user_id', data.userId);
                        we.kit.storage.setById('sys', 'user_token', data.tmpToken);
                        we.kit.storage.setById('sys', 'user_tmp_token_login_tag', 1);

                        // 清空粘贴板，防止影响下次登录
                        we.core.nativeUtil.copyText('.');
                    }
                } catch (error) {
                    chipText = null;
                }
            } catch (error) {
                chipText = null;
            }
        }
    }

    /** 自动登录 */
    public autoLogin() {
        this.initTempLogin();

        if (we.kit.storageUtil.isLogin()) {
            UserManager.initAccount();
            this.tokenLogin();
        } else {
            this.getGuestStatus(async (data: ApiProto.DeviceAccountStatusResp) => {
                if (data.status == 0 || data.status == 1) {
                    this.guestLogin(false);
                } else {
                    this.loginFailure();
                }
            });
        }
    }

    /** token登录 */
    public tokenLogin() {
        ApiManager.tokenLogin(
            (data: ApiProto.TokenLoginResp, tmpTokenLogin) => {
                if (this.checkBrandStop(data)) {
                    return;
                }
                this.syncUserData(data, 'tokenLogin' + (tmpTokenLogin ? '-tmp' : ''));
                this.reportAccountData(data);
                this.loginComplete();
            },
            (code) => {
                this.loginFailure(code);
            }
        );

        cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOGIN_ING));
    }

    /** 游客登录 */
    public guestLogin(loading: boolean) {
        ApiManager.guestLogin(
            (data: ApiProto.AnonymousLoginResp) => {
                if (this.checkBrandStop(data)) {
                    return;
                }
                this.syncUserData(data, 'guestLogin');
                this.reportAccountData(data);
                this.loginComplete();
            },
            (code) => {
                this.loginFailure(code);
            },
            loading
        );

        cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOGIN_ING));
    }

    /**
     * facebook 登录
     * @param authInfo
     */
    public facebookLogin(authInfo) {
        try {
            authInfo = JSON.parse(authInfo);
        } catch (error) {
            authInfo = null;
        }

        if (authInfo) {
            let params = {} as ApiProto.FacebookLoginReq;
            params.accessToken = authInfo.access_token;

            if (UserManager.isLogin() && UserManager.userInfo.fbAccount.length < 1) {
                ApiManager.facebookBind(
                    params,
                    (data: ApiProto.LoginResp) => {
                        this.reportAccountData(data);
                        UserManager.refreshUserInfo();
                        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.ACCOUNT_BINDING_TIPS));
                    },
                    (code) => {}
                );
            } else {
                ApiManager.facebookLogin(
                    params,
                    (data: ApiProto.LoginResp) => {
                        this.syncUserData(data);
                        this.reportAccountData(data);
                        this.loginComplete();
                    },
                    (code) => {
                        this.loginFailure(code);
                    }
                );
            }
        }

        cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOGIN_ING));
    }

    /**
     * 谷歌登录
     * @param authInfo
     */
    public googleLogin(authInfo) {
        try {
            authInfo = JSON.parse(authInfo);
        } catch (error) {
            authInfo = null;
        }

        if (authInfo) {
            let params = {} as ApiProto.GoogleLoginReq;
            params.clientId = authInfo.clientId;
            params.idToken = authInfo.token;

            if (UserManager.isLogin() && UserManager.userInfo.googleAccount.length < 1) {
                ApiManager.googleBind(
                    params,
                    (data: ApiProto.LoginResp) => {
                        this.reportAccountData(data);
                        UserManager.refreshUserInfo();
                        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.ACCOUNT_BINDING_TIPS));
                    },
                    (code) => {}
                );
            } else {
                ApiManager.googleLogin(
                    params,
                    (data: ApiProto.LoginResp) => {
                        this.syncUserData(data);
                        this.reportAccountData(data);
                        this.loginComplete();
                    },
                    (code) => {
                        this.loginFailure(code);
                    }
                );
            }
        }

        cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOGIN_ING));
    }

    /**
     * 苹果登录
     * @param authInfo
     */
    public appleLogin(authInfo) {
        try {
            authInfo = JSON.parse(authInfo);
        } catch (error) {
            authInfo = null;
        }

        if (authInfo) {
            let params = {} as ApiProto.AppleLoginReq;
            params.appleUserId = authInfo.userId;
            params.authorizationCode = authInfo.authorizationCode;
            params.email = authInfo.email;
            params.fullName = authInfo.fullName;
            params.identityToken = authInfo.identityToken;

            if (UserManager.isLogin() && UserManager.userInfo.appleAccount.length < 1) {
                ApiManager.appleBind(
                    params,
                    (data: ApiProto.LoginResp) => {
                        this.reportAccountData(data);
                        UserManager.refreshUserInfo();
                        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.ACCOUNT_BINDING_TIPS));
                    },
                    (code) => {}
                );
            } else {
                ApiManager.appleLogin(
                    params,
                    (data: ApiProto.LoginResp) => {
                        this.syncUserData(data);
                        this.reportAccountData(data);
                        this.loginComplete();
                    },
                    (code) => {
                        this.loginFailure(code);
                    }
                );
            }
        }

        cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOGIN_ING));
    }

    /**
     * 电话号码登录
     * @param req
     * @param successCallBack
     * @param errorCallBack
     */
    public phoneLogin(req: ApiProto.PhoneLoginReq, successCallBack?: Function, errorCallBack?: Function): void {
        ApiManager.phoneLogin(
            req,
            (data: ApiProto.LoginResp) => {
                if (this.checkBrandStop(data)) {
                    return;
                }
                this.syncUserData(data, 'phoneLogin');
                this.reportAccountData(data);

                successCallBack?.();
                this.loginComplete();
            },
            (code) => {
                typeof errorCallBack === 'function' && errorCallBack();
            }
        );

        cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOGIN_ING));
    }

    /**
     * userId登录
     * @param req
     * @param successCallBack
     * @param errorCallBack
     */
    public userIdLogin(req: ApiProto.IdLoginReq, successCallBack?: Function, errorCallBack?: Function): void {
        ApiManager.userIdLogin(
            req,
            (data: ApiProto.LoginResp) => {
                if (this.checkBrandStop(data)) {
                    return;
                }
                this.syncUserData(data, 'userIdLogin');
                this.reportAccountData(data);
                successCallBack?.();
                this.loginComplete();
            },
            (code) => {
                typeof errorCallBack === 'function' && errorCallBack();
            }
        );

        cc.director.emit(we.core.EventName.LOAD_STATUS, we.core.langMgr.getLangText(we.launcher.lang.LOAD_STATUS_LOGIN_ING));
    }

    /**
     * 邮箱登录
     * @param req
     * @param successCallBack
     * @param errorCallBack
     */
    public emailLogin(req: ApiProto.EmailLoginReq, successCallBack?: Function, errorCallBack?: Function): void {
        ApiManager.emailLogin(
            req,
            (data: ApiProto.LoginResp) => {
                if (this.checkBrandStop(data)) {
                    return;
                }
                this.syncUserData(data, 'emailLogin');
                this.reportAccountData(data);
                successCallBack?.();
                this.loginComplete();
            },
            (code) => {
                typeof errorCallBack === 'function' && errorCallBack();
            }
        );
    }

    /**
     * 电话号码注册
     * @param req
     * @param successCallBack
     * @param errorCallBack
     */
    public phoneRegister(req: ApiProto.PhonRegisterReq, successCallBack?: Function, errorCallBack?: Function): void {
        let callBack = (data: ApiProto.LoginResp) => {
            this.reportAccountData(data);
            successCallBack?.(data);
        };

        if (UserManager.isLogin() && !UserManager.userInfo?.phone) {
            ApiManager.phonBind(
                req,
                (data: ApiProto.LoginResp) => {
                    callBack(data);
                },
                (code) => {
                    typeof errorCallBack === 'function' && errorCallBack();
                }
            );
        } else {
            ApiManager.phoneRegister(
                req,
                (data: ApiProto.LoginResp) => {
                    if (this.checkBrandStop(data)) {
                        return;
                    }
                    this.syncUserData(data, 'phoneRegister');
                    callBack(data);

                    this.loginComplete();
                },
                (code) => {
                    typeof errorCallBack === 'function' && errorCallBack();
                }
            );
        }
    }

    /**
     * 邮箱注册账号
     * @param req
     * @param successCallBack
     * @param errorCallBack
     */
    public emailRegister(req: ApiProto.EmailRegisterReq, successCallBack?: Function, errorCallBack?: Function): void {
        let callBack = (data: ApiProto.LoginResp) => {
            this.reportAccountData(data);
            successCallBack?.(data);
        };

        if (UserManager.isLogin() && !UserManager.userInfo?.emailAccount) {
            ApiManager.emailBind(
                req,
                (data: ApiProto.LoginResp) => {
                    callBack(data);
                },
                (code) => {
                    typeof errorCallBack === 'function' && errorCallBack();
                }
            );
        } else {
            ApiManager.emailRegister(
                req,
                (data: ApiProto.LoginResp) => {
                    if (this.checkBrandStop(data)) {
                        return;
                    }
                    this.syncUserData(data, 'emailRegister');
                    callBack(data);

                    this.loginComplete();
                },
                (code) => {
                    typeof errorCallBack === 'function' && errorCallBack();
                }
            );
        }
    }

    /**
     * 手机登录密码重置
     * @param req
     * @param successCallBack
     * @param errorCallBack
     */
    public phoneLoginResetPwd(req: ApiProto.ResetPasswordReq, successCallBack?: Function, errorCallBack?: Function): void {
        ApiManager.resetPasswordReq(
            req,
            (data: ApiProto.ResetPasswordResp) => {
                typeof successCallBack == `function` && successCallBack(data);
            },
            (code) => {
                typeof errorCallBack === 'function' && errorCallBack(code);
            }
        );
    }

    /**
     * 邮箱修改密码
     * @param req
     * @param successCallBack
     * @param errorCallBack
     */
    public resetPasswordEmail(req: ApiProto.ResetEmailPasswordReq, successCallBack?: Function, errorCallBack?: Function): void {
        ApiManager.resetPasswordEmail(
            req,
            (data: ApiProto.ResetEmailPasswordResp) => {
                typeof successCallBack == `function` && successCallBack(data);
            },
            (code) => {
                typeof errorCallBack === 'function' && errorCallBack(code);
            }
        );
    }

    /**
     * 同步用户信息
     * @param data
     */
    private syncUserData(data: ApiProto.LoginResp | ApiProto.AnonymousLoginResp | ApiProto.TokenLoginResp, track: string = ''): void {
        // 添加登录日志追踪
        let loginData = {
            userId: data?.userId,
            userId_mem: UserManager.userInfo.userId,
            userId_cache: we.kit.storageUtil.readUserId(),
            token: data?.token,
            token_mem: UserManager.token,
            token_cache: we.kit.storageUtil.readUserToken(),
            tokenV2: data?.loginInfo?.tokenV2,
            isNew: data?.isNew,
        };
        // 校正 user_id 字段, 不破环缓存 user_id 真实性
        let exData = {
            custom: true,
            user_id: data?.userId,
        };
        we.info(`LoginManager syncUserData, loginData: ${JSON.stringify(loginData)}, track: ${track}`, exData);

        if (!data) {
            we.error(`LoginManager syncUserData, data err`);
            return;
        }

        if (data.userId > 0) {
            we.kit.storage.setById('sys', 'user_id', data.userId);
        }

        // @ts-ignore
        let token: string = data.token;
        if (token) {
            we.kit.storage.setById('sys', 'user_token', token);
        }

        UserManager.initAccount();

        if (data.loginInfo?.tokenV2) {
            UserManager.tokenV2 = data.loginInfo.tokenV2;
        } else {
            we.error(`LoginManager syncUserData, tokenV2 err`);
        }

        /** 根据用户 id 获取缓存 table */
        let tableName = `${we.bundles.common}:${we.kit.storageUtil.readUserId()}`;
        CommonType.storage = new we.kit.Storage<CommonType.StorageTable>(tableName);
        we.common.storage = CommonType.storage;

        // 用户基本信息
        if (data.loginInfo?.userInfoResp) {
            UserManager.initUser(data.loginInfo?.userInfoResp);

            if (data.isNew) {
                AgentMgr.autoBindAgent();
                // 移除 PWA referid 本地缓存
                if (we.core.nativeUtil.isPlatformPWA()) {
                    we.kit.storageUtil.saveHideBrowserKey(we.core.BrowserParamKey.referid, '');
                }
            }
        } else {
            we.error(`LoginManager syncUserData, userInfoResp err`);
        }

        UserManager.isNewbie = data.isNew;
        UserManager.isShowGiveDialog = data.isNew;

        // 功能配置
        if (data.loginInfo?.settingsResp) {
            we.core.projectConfig.settingsConfig = data.loginInfo.settingsResp;

            // TODO api 测试打开点1
            // let layout = JSON.parse(we.core.projectConfig.settingsConfig.funcSwitch.layout);
            // layout.hot.unshift(['20001']);
            // we.core.projectConfig.settingsConfig.funcSwitch.layout = JSON.stringify(layout);
            // data.loginInfo.settingsResp.gameDetails[1] = {
            //     gameId: 20001,
            //     orientation: we.core.ScreenOrientation.LANDSCAPE_RIGHT,
            //     nameText: {},
            // };
            // TODO end

            we.core.projectConfig.setVisibleGame();

            we.core.gameConfig.appendServerGameList(data.loginInfo.settingsResp.gameDetails);
            CommonModel.Inst.setVendorConfig(data.loginInfo.settingsResp.vendorDetails);

            let cchn = we.kit.storage.get('sys', 'user_create_channel') || we.core.nativeUtil.getChannel();
            we.kit.storage.setById('sys', 'user_create_channel', data.loginInfo?.settingsResp.cchn);
            if (data.loginInfo.settingsResp?.cchn != cchn) {
                we.launcher.maintainMgr.getCommonConfig();
            }

            if (data.loginInfo.settingsResp?.funcSwitch?.downloadLeadInfo) {
                DownloadGuideMgr.syncData(data.loginInfo.settingsResp.funcSwitch.downloadLeadInfo);
            }
        } else {
            we.error(`LoginManager syncUserData, settingsResp err`);
        }

        this.reportUserExtraInfo();
    }

    /**
     * 上报账号数据
     * @param data
     */
    private reportAccountData(data: any): void {
        if (!data) {
            we.error(`LoginManager reportAccountData, param is null`);
            return;
        }

        if (data.isNew) {
            we.core.trackMgr.trackEvent(we.core.trackConfig.account.activate);
            we.core.trackMgr.trackEventEx(we.core.trackConfig.account.activateEx);
        }

        if (data.isBind) {
            we.core.trackMgr.trackEvent(we.core.trackConfig.account.register);
            we.core.trackMgr.trackEventEx(we.core.trackConfig.account.registerEx);
            // 清理游客账号状态
            we.kit.storage.del('sys', 'user_account_guest_status');
        }
    }

    /**
     * 登录完成
     */
    public loginComplete() {
        cc.director.emit(we.core.EventName.LOGIN_VIEW_HIDE);

        NamingServiceMgr.init();
        RedDot.red.setRedDotData();
        GameServerMgr.init();

        // 登录完成回掉
        const completeCallback = () => {
            we.core.projectConfig.isLoginComplete = true;
            cc.director.emit(we.core.EventName.LOGIN_SUCCESS);
        };

        let gameId = parseInt(we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.gameid));
        if (we.GameId[gameId] && we.core.gameConfig.isSubGame(gameId)) {
            let roomKind = parseInt(we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.roomkind));
            if (!(roomKind >= 0 && roomKind <= 3)) {
                roomKind = 0;
            }
            GameManager.runGame(gameId, roomKind, completeCallback, false);
        } else {
            GameManager.runGame(we.GameId.HALL, -1, completeCallback);
        }
        this.initLoginData();
    }

    /**
     * 登录失败
     * @param code
     */
    public loginFailure(code?: number): void {
        UserManager.exitLogin();

        switch (code) {
            case HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1026: // 设备限制登录
                we.currentUI.show(CommonViewId.DeviceLimitDlg);
                break;
            case HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1003: // 封号提示
                we.commonUI.showConfirm({
                    content: we.core.langMgr.getLangText(CommonLanguage[HttpProtoError.ERROR_CODE[code]]) + ': ' + code,
                    isHideCloseBtn: true,
                    yesHandler: we.core.Func.create(() => {}),
                });
                break;
            default:
                break;
        }
    }

    /**
     * 初始化登录数据
     */
    private initLoginData(): void {
        GameManager.initLastGameInfo();
        StoreMgr.init();
        ActivityMgr.init();
        RebateCodeMgr.init();
        BankMgr.init();
        RescueFundsMgr.init();
        // we.core.langMgr.reportLanguage();

        this.getLobbyStaticConf(() => {
            this.getLobbyDynamicConf();
        });
        WithdrawMgr.init();
    }

    private getLobbyStaticConf(sucCb?: Function) {
        ApiManager.getLobbyStaticConf((data: ApiProto.LobbyStaticConfigResp) => {
            if (data && UserManager.isLogin()) {
                // 大厅 Banner 配置
                ActivityMgr.formatBannerConf(data.bannerConfResp);
                // 事件中心
                ActivityMgr.formatActivityConf(data.activityConfResp, false);
                // 账号绑定状态和奖励
                ActivityMgr.safeBindConfig = data.activityBannerResp?.bindActivity;
                // 首次使用指定app奖励
                if (data.getBonusConfResp) {
                    ActivityMgr.officialPkgAward = data.getBonusConfResp;
                    cc.director.emit(CommonEvent.UPDATE_OFFICIAL_BAG_AWARD);
                }
                // VIP 配置
                if (data.vipSysRewardInfoResp) {
                    VIPConfig.vipLevelConfig = data.vipSysRewardInfoResp?.vipSysRewardInfo || [];
                    VIPConfig.experienceType = data.vipSysRewardInfoResp?.experienceType || 0;
                    VIPConfig.spe_user_vip_limit = VIPConfig.vipLevelConfig.length - 1 > 0 ? VIPConfig.vipLevelConfig.length - 1 : 0;
                }
                // 入场限制
                if (data.gameEnterLimitResp) {
                    GameManager.gameEnterLimitConf = data.gameEnterLimitResp;
                    cc.director.emit(we.core.EventName.ENTER_GAME_LIMIT_UPDATE);
                }
                // 银行配置
                if (data.bankConfResp) {
                    BankMgr.syncData(data.bankConfResp);
                }

                cc.director.emit(CommonEvent.HALL_POPUP_QUEUE_UPDATE);
                this.reqLobbyFailedConf(data.aggregationRespStatus);
                sucCb && sucCb();
            }
        });
    }

    private getLobbyDynamicConf(sucCb?: Function): void {
        if (!UserManager.isLogin()) {
            return;
        }

        ApiManager.getLobbyDynamicConf((data: ApiProto.LobbyDynamicConfigResp) => {
            if (data && UserManager.isLogin()) {
                // VIP 奖励状态
                if (data.vipAwardStatusResp) {
                    VIPConfig.vipAwardStatus.data = data.vipSysRewardStatusResp;
                    VIPConfig.vipAwardStatus.timestamp = new Date().getTime();
                }

                // 新手礼包
                if (data.firstRechargeConfResp) {
                    StoreMgr.updateNewbieGiftBag(data.firstRechargeConfResp);
                }
                // 七日福利
                if (data.newbieSevenDayActivityResp) {
                    ActivityMgr.sevenDayInfo = data.newbieSevenDayActivityResp;
                    cc.director.emit(CommonEvent.NOTICE_EVENT_CENTER);
                }
                // 每日签到
                if (data.dailyFreeAwardConfResp) {
                    ActivityMgr.dailyFreeAward = data.dailyFreeAwardConfResp;
                    cc.director.emit(CommonEvent.NOTICE_EVENT_CENTER);
                    cc.director.emit(CommonEvent.UPDATE_DAILY_FREE_AWARD);
                }
                // 大厅游戏入口 Jackpot
                // 打码返利
                RebateCodeMgr.syncData(data.userRebateConfResp);
                // 代理
                AgentMgr.syncData(data.agentInviteRewardInfoResp);

                // 每日充值活动
                if (data.rechargeTaskProgressResp) {
                    DailyRechargeMgr.syncData(data.rechargeTaskProgressResp);
                }
                // 狂欢活动
                if (data.carnivalTaskProgressResp) {
                    CarnivalMgr.syncData(data.carnivalTaskProgressResp);
                }
                // 独立日活动
                if (data.independenceTaskProgressResp) {
                    IndependentMgr.syncData(data.independenceTaskProgressResp);
                }
                // 转盘活动
                if (data.rodaUndianTaskProgressResp) {
                    TurntableMgr.syncData(data.rodaUndianTaskProgressResp);
                }
                // 救援金活动
                if (data.reliefFundApplyListResp) {
                    RescueFundsMgr.syncData(data.reliefFundApplyListResp);
                }

                cc.director.emit(CommonEvent.HALL_POPUP_QUEUE_UPDATE);
                this.reqLobbyFailedConf(data.aggregationRespStatus);
                sucCb && sucCb();
            }
        });
    }

    /**
     * 再次请求 聚合接口获取数据失败的配置
     * @param data
     * @returns
     */
    private reqLobbyFailedConf(data: ApiProto.AggregationRespStatus[]): void {
        if (!(data instanceof Array && data.length > 0)) {
            return;
        }

        data.forEach((v) => {
            if (v.status) {
                return;
            }

            let isNeedReq = true;
            switch (v.aggregationRespField) {
                case 'activityBannerResp':
                    ActivityMgr.getAccountBindAwardConf();
                    break;
                case 'vipSysRewardInfoResp':
                    VIPConfig.init();
                    break;
                    break;
                case 'GameEnterLimitResp':
                    GameManager.getGameEnterLimitConf();
                    break;
                case 'BannerConfResp':
                    ActivityMgr.getBannerConf();
                    break;
                case 'ActivityConfResp':
                    ActivityMgr.getActivityConf();
                    break;
                case 'GetBonusConfResp':
                    ActivityMgr.getOfficialPkgBonusConf();
                    break;
                case 'FirstRechargeConfResp':
                    StoreMgr.initNewbieGiftBag();
                    break;
                case 'RechargeTaskProgressResp':
                    DailyRechargeMgr.getActivityInfo();
                    break;
                case 'CarnivalTaskProgressResp':
                    CarnivalMgr.getActivityInfo();
                    break;
                case 'IndependenceTaskProgressResp':
                    IndependentMgr.getActivityInfo();
                    break;
                case 'BankConfResp':
                    BankMgr.clearLock();
                    BankMgr.getBankConf();
                    break;
                case 'ReliefFundApplyListResp':
                    RescueFundsMgr.clearLock();
                    RescueFundsMgr.getUserApplyList();
                    break;
                default:
                    isNeedReq = false;
                    break;
            }
            isNeedReq && we.warn(`LoginManager reqLobbyFailedConf, ${v.aggregationRespField} is null`);
        });
    }

    /**
     * 登陆账号缓存至本地
     * @param data
     */
    public saveAccountToLocal(data: CommonType.IAccountInfo): void {
        let newAccounts = [];
        let tempData = we.npm.lodash.cloneDeep(data);
        if (data) {
            // 密码 base64 加密
            tempData.password = we.core.utils.base64Encode(tempData.password);
        } else {
            return;
        }
        newAccounts.push(tempData);

        let historyAccounts = CommonUtils.readAccountRecord();
        if (historyAccounts) {
            for (let i = 0; i < historyAccounts.length; i++) {
                let account = historyAccounts[i];
                if (account.userId != data.userId) {
                    newAccounts.push(account);
                } else {
                    // 防止 userId 登录时，清理掉账号信息
                    if (!newAccounts[0].phoneNum) {
                        newAccounts[0].phoneNum = account.phoneNum;
                    }
                }
            }
        }

        we.common.sys.setById('sys', 'user_account_record', newAccounts);
    }

    /**
     * 上一次登录的账号
     * @returns
     */
    public getLastAccount(): CommonType.IAccountInfo {
        let historyAccounts = CommonUtils.readAccountRecord();
        if (historyAccounts.length < 1) {
            return null;
        }

        if (typeof historyAccounts[0] == 'object') {
            historyAccounts[0].password = we.core.utils.base64Decode(historyAccounts[0].password);
            return historyAccounts[0];
        }

        return null;
    }

    /**
     * 获取当前登录账号
     * @returns
     */
    public getCurLoginAccount(): CommonType.IAccountInfo {
        let curAccount: CommonType.IAccountInfo = null;
        if (!UserManager.isLogin()) {
            return curAccount;
        }

        let historyAccounts = CommonUtils.readAccountRecord();
        if (historyAccounts.length < 1) {
            return curAccount;
        }

        for (let i = 0; i < historyAccounts.length; i++) {
            if (historyAccounts[i].userId == UserManager.userInfo.userId) {
                curAccount = historyAccounts[i];
                break;
            }
        }

        // 密码 base64 解密
        if (curAccount) {
            curAccount.password = we.core.utils.base64Decode(curAccount.password);
        }

        return curAccount;
    }

    /**
     * 获取拥有游客账号状态
     * @param callback status:0-没有绑定账户 1-只有游客账户 2-只有正式账户 3-游客账户正式账户都有
     * @param isRealTime 是否实时数据
     */
    public getGuestStatus(callback: (data: ApiProto.DeviceAccountStatusResp) => void, isRealTime: boolean = false): void {
        let tempData = {} as ApiProto.DeviceAccountStatusResp;
        let guestAccountStatus = we.kit.storage.get('sys', 'user_account_guest_status');
        if (typeof guestAccountStatus == `number` && !isRealTime) {
            tempData.status = guestAccountStatus;
            callback(tempData);
        } else {
            ApiManager.getDeviceAccountStatus(
                (data: ApiProto.DeviceAccountStatusResp) => {
                    if (!(data?.status >= 0)) {
                        tempData.status = 0;
                        callback(tempData);
                        return;
                    }

                    we.core.projectConfig.deviceAccSt = data;
                    we.kit.storage.setById('sys', 'user_account_guest_status', data.status);
                    callback(data);
                },
                () => {
                    tempData.status = 0;
                    callback(tempData);
                }
            );
        }
    }

    /**
     * 上报服务器需要收集数据，已有数据如下
     * 1. PWA 模式下 adjust web sdk 广告 id
     */
    private reportUserExtraInfo(): void {
        if (this.reportTimer > -1) {
            clearInterval(this.reportTimer);
            this.reportTimer = -1;
        }

        let reportFun = () => {
            let data = {} as ApiProto.UpdateExtraInfoReq;
            let reportCampaign = we.isH5PWA && we.kit.storage.get('sys', 'app_adjust_campaign_tag');
            if (!reportCampaign) {
                clearInterval(we.common.loginMgr.reportTimer);
                we.common.loginMgr.reportTimer = -1;
                return;
            } else {
                data.campaignName = we.core.trackMgr.getAdjustCampaign();
            }

            // adjust 广告 id，可扩展参数判定
            if (data.campaignName) {
                ApiManager.reportUserExtraInfo(
                    data,
                    () => {
                        if (we.isH5PWA) {
                            we.kit.storage.setById('sys', 'app_adjust_campaign_tag', false);
                        }
                    },
                    (code) => {
                        // 接口异常停止上报
                        clearInterval(we.common.loginMgr.reportTimer);
                    }
                );
            }
        };

        this.reportTimer = setInterval(reportFun, 10 * 1000);
        reportFun();
    }

    /**
     * 检查品牌是否停运
     * @param data
     */
    private checkBrandStop(data: any): boolean {
        if (!data?.brandLimit?.isBrandStop) {
            return false;
        }

        // 正在大厅或子游戏时不弹
        const curGameId = we.core.gameConfig.curGameId;
        if (curGameId == we.GameId.HALL || we.core.gameConfig.isSubGame(curGameId)) {
            return true;
        }

        const brandLimit = data.brandLimit;

        // 隐藏登录视图和进度条
        cc.director.emit(we.core.EventName.LOGIN_VIEW_HIDE);
        cc.director.emit(we.core.EventName.LOAD_PROGRESS_ACTIVE, false);

        UserManager.clearLoginData(false);

        we.commonUI.showConfirm({
            content: brandLimit.notice[we.core.langMgr.getCurLangCode()] || we.core.langMgr.getLangText(we.launcher.lang.GAME_MAINTENANCE),
            cover: false,
            priority: we.ui.type.PopupPriority.System,
            yesHandler: we.core.Func.create(() => {
                cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
            }),
        });

        return true;
    }
}

export default we.common.loginMgr = new LoginManager();
