declare global {
    interface ICommon {
        /** 闪告 管理类 */
        marqueeMgr: MarqueeMgr;
    }
    interface TCommon {
        IMarqueeData: IMarqueeData;
    }
    namespace we {
        namespace common {
            /** 闪告内容 */
            type IMarqueeData = TCommon['IMarqueeData'];
        }
    }
}

/** 闪告内容 */
interface IMarqueeData {
    /** id */
    UserId: number;
    /** 昵称 */
    UserName: string;
    /** 头像 */
    Avatar: string;
    /** vip 等级 */
    VipLevel: number;

    /** 奖励 */
    Award: number;
    /** 倍数 */
    Odds: number;
}

class MarqueeMgr {
    /** 隐藏跑马灯展示 */
    public hideMarquee: boolean = false;
    /** 闪告队列 */
    private marqueeQueue = [];

    public init(): void {
        this.marqueeQueue = [];
    }

    /**
     * 缓存闪告推送数据
     * @param data
     * @returns
     */
    public onPushNewMessage(data: NamingProto.BroadCastNT): void {
        // 不在大厅不需要缓存闪告播报
        let curGameId = we.core.gameConfig.curGameId;
        if (we.core.gameConfig.isSubGame(curGameId)) {
            return;
        }

        if (!we.core.projectConfig.gameListMap.has(data.BroadCastType)) {
            return;
        }

        const template: IMarqueeData = JSON.parse(data.Template);
        // 没有头像或奖励不展示
        if (!template && !template.Award && !template.Avatar) {
            return;
        }

        // 子游戏已移除闪告，所以触发闪告均非本地玩家，移除本地玩家判定逻辑
        this.marqueeQueue.length >= 10 && this.marqueeQueue.shift();
        this.marqueeQueue.push(data);
    }

    /**
     * 获取下一条闪告数据
     * @returns
     */
    public getMarqueeMsg(): NamingProto.BroadCastNT {
        return this.marqueeQueue.shift();
    }
}

export default we.common.marqueeMgr = new MarqueeMgr();
