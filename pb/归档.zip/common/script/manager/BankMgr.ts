import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 银行 管理类 */
        bankMgr: BankMgr;
        BankRecordEventType: typeof BankRecordEventType;
        BankStockCode: typeof BankStockCode;
    }
}

interface IBankConfig extends ApiProto.BankConfResp {
    ts: number;
    coolingReq: boolean;
    data: ApiProto.BankConfResp;
}

const StoredTimeFormat: string = 'YYYY/MM/DD hh';

/** 记录事件类型 */
enum BankRecordEventType {
    /** 所有 */
    all = 'all',
    /** 存入 */
    stockIn = 'stockIn',
    /** 取出 */
    stockOut = 'stockOut',
    /** 利息 */
    interest = 'interest',
}

we.common.BankRecordEventType = BankRecordEventType;

/** 状态 */
enum BankStockCode {
    /** 成功 */
    success = 10,
    /** 失败 */
    failed = 20,
}

we.common.BankStockCode = BankStockCode;

class BankMgr {
    /** 快速点击tag */
    public readonly quickClickTag: string = 'bankQuickClickTag';
    /** 快速点击, 防抖时间, 单位毫秒*/
    public readonly quickClickTiem: number = 30000;
    /** 银行配置 */
    public bankConfig: IBankConfig = {} as IBankConfig;
    /** 银行个人帐户信息 */
    public bankInfo: ApiProto.BankInfoResp = null;
    /** 记录缓存, 避免频繁请求, key: RecordEventType */
    private recordDataMap: Map<string, ApiProto.BankRecord[]> = new Map<string, ApiProto.BankRecord[]>();
    /** key: RecordEventType, value: YYYY/MM/DD hh */
    private recordTimeMap: Map<string, string> = new Map<string, string>();

    public init(): void {
        this.clearRecordData();
        this.bankConfig = {} as IBankConfig;
        this.bankConfig.coolingReq = true;

        this.bankInfo = null;
    }

    /**
     * 清理记录数据
     * 1.登录或子游戏返回大厅
     * 2.整点，整点不需要手动调用
     * 3.存/取操作成功
     */
    public clearRecordData(): void {
        this.recordDataMap.clear();
        this.recordTimeMap.clear();
    }

    /**
     * 获取缓存记录
     * @param eventType
     * @returns
     */
    public getLocalRecordData(eventType: string): ApiProto.BankRecord[] | null {
        let date = new Date();
        let curTimeStr = we.common.utils.formatDate(date, StoredTimeFormat);
        let storedTimeStr = this.recordTimeMap.get(eventType);

        if (storedTimeStr === curTimeStr) {
            const recordData = this.recordDataMap.get(eventType);
            if (!this.isNullOrUndefined(recordData)) {
                return we.npm.lodash.cloneDeep(recordData);
            }
        }

        return null;
    }

    /**
     * 设置缓存记录
     * @param eventType
     * @param recordData
     */
    public setLocalRecordData(eventType: string, recordData: ApiProto.BankRecord[]): void {
        if (this.isNullOrUndefined(recordData)) {
            return;
        }

        let date = new Date();
        let timeStr = we.common.utils.formatDate(date, StoredTimeFormat);
        this.recordTimeMap.set(eventType, timeStr);
        this.recordDataMap.set(eventType, recordData);
    }

    private isNullOrUndefined(value: any): boolean {
        return value === null || value === undefined;
    }

    /** 获取银行是否开启 */
    public getBankIsAct(): boolean {
        // TODO 银行暂时没有功能开关，通过bankSwitch判断入口是否开启，有功能开关后删除
        if (this.bankConfig?.data?.bankSwitch) {
            return true;
        }

        return false;
    }

    /**
     * 获取银行配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     * @returns
     */
    public getBankConf(showLoading: boolean = false): void {
        if (this.bankConfig?.data) {
            if (new Date().getTime() - this.bankConfig.ts < 2 * 1000) {
                return;
            }
        }

        if (this.bankConfig?.coolingReq) {
            return;
        }
        this.bankConfig.coolingReq = true;

        ApiManager.getBankConf(
            (data: ApiProto.BankConfResp) => {
                this.bankConfig.ts = new Date().getTime();
                this.syncData(data);
            },
            (code) => {
                this.bankConfig.coolingReq = false;
            },
            showLoading
        );
    }

    /**
     * 获取银行个人帐户信息
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public getBankInfo(showLoading: boolean = false): void {
        ApiManager.getBankInfo(
            (data: ApiProto.BankInfoResp) => {
                this.bankInfo = data;

                cc.director.emit(CommonEvent.UPDATE_BANK_INFO);
            },
            (code) => {},
            showLoading
        );
    }

    /**
     * 银行存款
     * @param param
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public bankStockIn(param: ApiProto.BankStockInReq, sucCb?: Function, errCb?: Function, showLoading: boolean = true): void {
        ApiManager.bankStockIn(
            param,
            (data: ApiProto.BankStockInResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            },
            showLoading
        );
    }

    /**
     * 银行取款
     * @param param
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public bankStockOut(param: ApiProto.BankStockOutReq, sucCb?: Function, errCb?: Function, showLoading: boolean = true): void {
        ApiManager.bankStockOut(
            param,
            (data: ApiProto.BankStockOutResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            },
            showLoading
        );
    }

    /**
     * 获取银行流水记录
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public getBankRecord(param: ApiProto.BankRecordReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        ApiManager.getBankRecord(
            param,
            (data: ApiProto.BankRecordResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            },
            showLoading
        );
    }

    /**
     * 获取Vip等级对应的利率数组
     * 利率，服务器传过来就是百分数，50就是50%
     * @param isSort 是否排序
     * @returns
     */
    public getVipRateList(isSort: boolean = true): ApiProto.BankVipInterest[] {
        let curList = this.bankConfig?.data?.vipInterests || [];

        if (!isSort) {
            return curList;
        }

        curList.sort((a, b) => {
            return a.vipLevel - b.vipLevel;
        });

        return curList;
    }

    /**
     * 获取当前Vip等级对应的利率
     * 利率，服务器传过来就是百分数，50就是50%
     * @param vipLevel
     */
    public getVipRate(vipLevel: number): number {
        let rate = 0;

        let curList = this.getVipRateList(false);
        for (let i = 0; i < curList.length; i++) {
            const curVipRate = curList[i];
            if (curVipRate.vipLevel == vipLevel) {
                rate = curVipRate.interestRate;
                break;
            }
        }

        return rate;
    }

    /**
     * 同步 银行 数据
     * @param data
     * @returns
     */
    public syncData(data: ApiProto.BankConfResp): void {
        if (!data || !UserManager.isLogin()) {
            return;
        }

        this.bankConfig.data = data;
        this.bankConfig.coolingReq = false;

        cc.director.emit(CommonEvent.UPDATE_BANK);
    }

    /** 清理银行请求状态锁 */
    public clearLock(): void {
        this.bankConfig.ts = 0;
        this.bankConfig.coolingReq = false;
    }
}

export default we.common.bankMgr = new BankMgr();
