import { CommonRes } from '../config/CommonRes';

declare global {
    interface ICommon {
        /** 红点管理 */
        redDot: typeof RedDot;
    }
}

/**
 * 红点注册参数
 */
type RegisteredRedDotOptions = Partial<{
    /** 配置组 */
    paths: string[];
    /** 红点显示父 Node 节点 */
    node: cc.Node;
    /** 红点显示类型 */
    type?: RedDotType;
    /** 更新回调 */
    callback?: (count?: number, info?: RedDotParameter) => void;
}>;

/**
 *  虚拟红点数据配置
 */
const RedDotConfig = {
    /** 根节点 */
    root: ['root'],
    /** 邮件 */
    mail: ['root/mail'],
    mailItem: ['root/mail/mailItem'],
    /** 客服 */
    server: ['root/server'],
    /** 代理红点 */
    agent: ['root/agent'],
    /** 事件中心 */
    eventCenter: ['root/eventCenter'],

    // ////////////////////////////// vip ////////////////////////////////
    /** vip */
    vip: ['root/vip'],
    vipToggleItem: ['root/vip/toggleItem'],
    vipBirthdayAward: ['root/vip/toggleItem/birthdayAward'],
    vipReachAward: ['root/vip/toggleItem/reachAward'],
    vipSalary: ['root/vip/toggleItem/vipSalary'],

    // ////////////////////////////// activity ////////////////////////////////

    /** 活动下拉菜单 */
    activityDropdown: ['root/activity'],
    /** 狂欢红点 */
    carnival: ['root/activity/carnival'],
    /** 独立日活动 */
    independent: ['root/activity/independent'],
    /** 每日充值 */
    dailyRecharge: ['root/activity/dailyRecharge'],
    /** 打码返利 */
    rebateCode: ['root/rebateCode'],
    rebateCodeReceive: ['root/rebateCode/rebateCodeReceive'],
    /** 加入我们 */
    joinUs: ['root/activity/joinUs'],
    /** 转盘活动 */
    turntable: ['root/activity/turntable'],

    /** 周卡活动 */
    weekCard: ['root/activity/weekCard'],
    /** 救援金 */
    rescueFunds: ['root/activity/rescueFunds'],
    /** 每日金币 */
    dailyAward: ['root/activity/dailyAward'],

    /** 每月签到，按天计算 */
    monthSign: ['root/activity/monthSign'],
    /** 每月签到2，按次数计算 */
    monthSign2: ['root/activity/monthSign2'],
    /** 七日福利 */
    sevenDay: ['root/activity/sevenDay'],
};

/**
 * 红点管理系统
 */
class RedDotMgr {
    /**
     * 私有静态实例
     */
    private static _instance: RedDotMgr;

    /**
     * 树结构分隔符号
     */
    private static readonly separator = '/';

    /**
     * 通用红点节点名称
     */
    private static readonly redDotName = 'RedItem';

    static get Instance(): RedDotMgr {
        if (!RedDotMgr._instance) {
            RedDotMgr._instance = new RedDotMgr();
            // 设置内部红点数据
            RedDotMgr._instance.setRedDotData();
        }
        return RedDotMgr._instance;
    }

    /**
     * 红点树结构数据
     */
    private redTreeData: { [key: string]: string[] } = null;

    /**
     * 红点数据
     */
    private map: Map<string, RedDotParameter>;

    /**
     * 获取红点定义的节点名称
     * 可以采用外部导入方式，也可以直接内置数据
     */
    public getRedNodeName() {
        return RedDotMgr.redDotName;
    }

    /**
     * 设置红点数据，会清空原有数据
     * 可以采用外部导入方式，也可以直接内置数据
     */
    public setRedDotData(data: { [key: string]: string[] } = RedDotConfig) {
        if (data === null) {
            we.warn('RedDotMgr setRedDotData invalid data:', data, we.noup);
            return;
        }

        if (this.hasDuplicateValues(data)) {
            return;
        }

        this.redTreeData = null;
        if (this.map) {
            this.map.clear();
        } else {
            this.map = new Map<string, RedDotParameter>();
        }

        this.redTreeData = data;

        // 重复配置检查
        const keys = Object.keys(this.redTreeData);
        for (const key of keys) {
            const name2 = this.getSortedStringArray(this.redTreeData[key]);
            const info: RedDotParameter = { paths: this.redTreeData[key], count: 0, cfgs: [] };
            this.map.set(name2, info);
        }
    }

    /**
     * 查询红点，返回红点数据
     */
    public findRedDot(name: string | string[]): RedDotParameter | undefined {
        let name2 = '';
        if (typeof name === 'string') {
            name2 = name;
        } else {
            name2 = this.getSortedStringArray(name);
        }

        if (!name2) {
            we.warn('RedDotMgr findRedDot invalid name:', name, we.noup);
            return undefined;
        }

        const info = this.map.get(name2);
        if (!info) {
            we.log('RedDotMgr findRedDot unfound name:', name);
            return undefined;
        }

        return info;
    }

    /**
     * 获取红点数量
     */
    public getRedDotCnt(paths: string[]): number {
        const info = this.findRedDot(paths);
        if (!info) {
            we.log('RedDotMgr getRedDotCnt unfound paths:', paths);
            return 0;
        }
        return info.count;
    }

    private findCfg(cfgs: RedDotParameter['cfgs'], node: cc.Node) {
        return cfgs.find((cfg) => {
            return cfg.node === node;
        });
    }

    /** 获取红点配置 */
    public getRedDotConfig(node: cc.Node): string[] {
        if (!cc.isValid(node)) {
            return null;
        }
        const iterator = this.map.values();
        let next: IteratorResult<RedDotParameter, RedDotParameter>;
        while (((next = iterator.next()), !next.done)) {
            const func = (node: cc.Node) => {
                return !!this.findCfg(next.value.cfgs, node) || node.children.some(func);
            };
            if (func(node)) {
                return next.value.paths;
            }
        }
    }

    /**
     * 注册红点
     * @param options 注册红点参数
     */
    public async registeredRedDot(options: RegisteredRedDotOptions) {
        if (!cc.isValid(options.node)) {
            we.warn('RedDotMgr registeredRedDot, invalid options:', options, we.noup);
            return;
        }

        options = Object.assign({ type: RedDotType.PURE, callback: null }, options);

        const info = this.findRedDot(options.paths);
        if (!info) {
            we.log('RedDotMgr registeredRedDot, unfound paths:', options.paths);
            return;
        }

        let redDotNode = options.node.getChildByPath(`notice/${RedDotMgr.redDotName}`) ?? options.node.getChildByName(RedDotMgr.redDotName);
        let cfg = this.findCfg(info.cfgs, redDotNode);
        // 节点重复注册检查
        if (cfg) {
            we.log('RedDotMgr registeredRedDot duplicate options:', options);
        } else {
            // 动态创建红点节点
            if (!redDotNode) {
                let prefab = await we.core.assetMgr.loadAsset(CommonRes.prefab.RedItem, cc.Prefab, options.node);
                if (!prefab) {
                    we.warn(`RedDotMgr registeredRedDot, register failed, paths: ${options?.paths}`, we.noup);
                    return;
                }

                redDotNode = cc.instantiate(prefab);
                redDotNode.name = RedDotMgr.redDotName;
                (options.node.getChildByName('notice') ?? options.node).addChild(redDotNode);
            }

            redDotNode.parent.active = true;
            cfg = { node: redDotNode, type: RedDotType.PURE, callback: null };
            info.cfgs.push(cfg);
        }

        cfg.type = options.type;
        cfg.callback = options.callback;

        // 设置时先主动触发一次
        this.updateRedDotCnt(options.paths, info.count, true);
    }

    /**
     * 更新红点数量
     * @param paths 更新红点配置名称
     * @param dt 红点数量 / 红点数量变化量
     * @param bAssign 是否直接赋值：false:变化量，true:直接赋值，默认false，
     */
    public updateRedDotCnt(paths: string[], dt: number, bAssign: boolean = false) {
        // 检查值是否为字符串数组
        const isStringArray =
            Array.isArray(paths) &&
            paths.every((item) => {
                return typeof item === 'string';
            });

        if (!isStringArray) {
            we.warn('RedDotMgr updateRedDotCnt invalid paths:', paths, we.noup);
            return;
        }
        if (typeof dt !== 'number') {
            we.warn('RedDotMgr updateRedDotCnt invalid dt:', dt, we.noup);
            return;
        }

        const info = this.findRedDot(paths);
        if (!info) {
            we.log('RedDotMgr updateRedDotCnt unfound paths:', paths);
            return;
        }

        if (bAssign) {
            dt -= info.count;
        }
        if (dt < 0 && info.count + dt < 0) {
            dt = -info.count;
        }

        // 更新红点树
        const names = this.splitString(paths);
        names.forEach((i) => {
            const item = this.findRedDot([i]);
            if (item) {
                item.count += dt;
                this.setCountBadgeValue(item);
                item.cfgs.forEach((cfg) => {
                    cc.isValid(cfg.node) && cfg.callback?.(item.count, item);
                });
            } else {
                we.log('RedDotMgr updateRedDotCnt unfound paths:', paths, names, i);
            }
        });
    }

    /**
     * 计算红点数量
     * @param paths 根节点
     */
    computeRedDotCnt(paths: string[]) {
        if (!paths) {
            we.warn('RedDotMgr computeRedDotCnt invalid paths:', paths, we.noup);
        }
        let count = 0;
        const name2 = this.getSortedStringArray(paths);
        this.map.forEach((item, key) => {
            if (key === name2) {
                return;
            }
            if (key.includes(name2)) {
                count += item.count;
            }
        });
        this.updateRedDotCnt(paths, count, true);
    }

    /**
     * 组合路径
     */
    private splitString(inputString: string[]): string[] {
        // ['root/chat/group1', 'root/chat_group/group1']

        const result: string[] = [];
        let name2 = this.getSortedStringArray(inputString);
        result.push(name2);

        for (let i = 0; i < inputString.length; i++) {
            const str = inputString[i];
            const segments = str.split(RedDotMgr.separator);

            let accumulatedString = '';
            for (let k = 0; k < segments.length - 1; k++) {
                accumulatedString += segments[k];
                result.push(accumulatedString);
                if (k < segments.length - 1) {
                    accumulatedString += RedDotMgr.separator;
                }
            }
        }
        // 使用 Set 去重
        const uniqueSet = new Set(result);
        return Array.from(uniqueSet);
    }

    /**
     * TODO 红点自定义显示方案
     * 红点显示规则，按照当前项目需求自行扩充
     */
    private async setCountBadgeValue(info: RedDotParameter) {
        const cfgs = info.cfgs;
        const count = info.count;

        if (cfgs.length == 0) {
            return;
        }

        for (let i = 0; i < cfgs.length; i++) {
            let cfg = cfgs[i];
            if (!cc.isValid(cfg.node)) {
                cfgs.splice(i--, 1);
                continue;
            }

            // TODO 自定义红点显示方案 ，这里只是简单的显示红点数量
            cfg.node.getChildByName('icon')?.getComponent(we.ui.WESpriteIndex)?.setIndex(cfg.type);
            cfg.node.active = count > 0;

            const labelComponent = cfg.node.getChildByName('value')?.getComponent(cc.Label);
            if (!labelComponent) {
                continue;
            }

            // TODO 超过99 的显示为 99+
            if (cfg.type == RedDotType.DEFAULT) {
                labelComponent.node.active = true;
                labelComponent.string = count < 100 ? count.toString() : '99+';
            } else {
                labelComponent.node.active = false;
            }
        }
    }

    /**
     * 检查对象中是否存在重复的字符串数组值，忽略数组元素的顺序。
     * @param obj - 要检查的对象。
     * @returns 如果存在重复值则返回 true，否则返回 false。
     */
    private hasDuplicateValues(obj: any): boolean {
        const valuesSet = new Set<string>();
        for (const key in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, key)) {
                const value = obj[key];
                // 检查值是否为字符串数组
                const isStringArray =
                    Array.isArray(value) &&
                    value.every((item) => {
                        return typeof item === 'string';
                    });
                if (isStringArray) {
                    // 将字符串数组转换为字符串表示形式，并进行排序
                    const sortedValue = this.getSortedStringArray(value);
                    if (valuesSet.has(sortedValue)) {
                        we.log('RedDotMgr hasDuplicateValues duplicate value:', value);
                        return true;
                    }
                    valuesSet.add(sortedValue);
                } else {
                    we.warn('RedDotMgr hasDuplicateValues invalid value:', value, we.noup);
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * 通过字符串数组，获取排序后的数组字符串
     */
    public getSortedStringArray(value: string[]): string {
        if (!Array.isArray(value)) {
            we.warn('RedDotMgr getSortedStringArray invalid value:', value, we.noup);
            return '';
        }
        return value.slice().sort().join('-');
    }

    /** 动态添加树数据 */
    public setRedDotTreeData(paths: string[], count = 0) {
        const name2 = this.getSortedStringArray(paths);
        if (this.map.get(name2)) {
            we.log('RedDotMgr setRedDotTreeData duplicate paths:', paths);
            return this.map.get(name2);
        }
        const data: RedDotParameter = { paths, count, cfgs: [] };
        this.map.set(name2, data);
        return data;
    }

    /**
     * 添加红点显示节点
     * @param parent 红点父元素
     */
    public appendVRedDotNode(parent: cc.Node): Promise<cc.Node> {
        let noticeNode: cc.Node = null;
        if (parent.children.length <= 0) {
            noticeNode = parent;
        } else {
            const redItem = parent.getChildByName('RedItem');
            if (redItem) {
                noticeNode = parent;
                noticeNode.active = true;
                return Promise.resolve(noticeNode);
            }
            noticeNode = parent.getChildByName('notice');
            if (!noticeNode) {
                we.warn('RedDotMgr appendVRedDotNode: parent node has no notice node');
                return;
            }
            noticeNode.removeAllChildren();
        }
        return we.commonUI.createNode(CommonRes.prefab.RedItem, noticeNode).then((node) => {
            node.active = false;
            noticeNode.active = true;
            return noticeNode;
        });
    }

    /**
     * 快捷动态设置子红点数据
     * @param paths
     * @param data
     */
    public quickSetRedDotData(paths: string[], data: { name: string | number; count: number | boolean }[]) {
        data.forEach(({ name, count }) => {
            RedDot.red.setRedDotTreeData(
                paths.map((path) => {
                    return `${path}/${name}`;
                }),
                Number(count)
            );
            // 重新计算root值
            RedDot.red.computeRedDotCnt(paths);
        });
    }
}

/**
 * 红点参数
 */
class RedDotParameter {
    /** 配置组 */
    paths: string[];
    /** 数量 */
    count: number;
    /** 节点配置 */
    cfgs: {
        /** 红点Node节点 */
        node: cc.Node;
        /** 显示方式 */
        type: RedDotType;
        /** 更新回调 */
        callback: RegisteredRedDotOptions['callback'] | null;
    }[];
}

/**
 * 红点显示类型
 */
enum RedDotType {
    /**  默认值：带数字红点 */
    DEFAULT,
    /** 纯红点 */
    PURE,
    /** 感叹号，提示 */
    NOTE,
    /** Flog：满，例如：背包满了 */
    FULL,
    /** Flog：new，例如：新功能开放 */
    NEW,
    /** Flog：up，例如：装备可升级提示 */
    UPGRADE,
}

/**
 * 红点系统相关配置
 */
export const RedDot = {
    /** 红点管理系统 */
    red: RedDotMgr.Instance,
    /** 红点参数 */
    parameter: RedDotParameter,
    /** 红点类型 */
    type: RedDotType,
    /** 红点配置 */
    cfg: RedDotConfig,
};

// 导出红点管理系统
export default we.common.redDot = RedDot;

/**
 *
 * 红点节点配置
 * root 更节点（必须）
 * 红带按照层级结构命名，形成树形结构。
 * 只有叶子节点才有且必须有自己判断逻辑。
 * 非叶子节点的红点显示状态取决于他的子节点的显示状态。
 * 业务层只需要关心每个子节点的判断逻辑，何时刷新，刷新时是否需要传参数即可。
 *
 * 内部设置数据: RedDotMgr._instance.setRedDotData(RedDotConfig);
 *
 * 可以外接数据，在项目初始化时设置: RedDot.red.setRedDotData(RedDotConfig);
 *
 * 注册红点节点  ｜  重点：无须关心红点注销，系统自动管理
 * RedDot.red.registeredRedDot(RedDot.cfg.mail, btnNode, RedDotType.NEW);
 *
 * 更新红点数据，例如：邮箱
 * RedDot.red.updateRedDotCnt(RedDot.cfg.mail, count, true);
 *
 * 红点节点规范
 * btn_node  按钮节点
 *    --notice  统一的红点节点，即点即范围（ notice 名称在红点系统中配置: RedItem）
 *       --icon    红点背景
 *       --value   红点数字
 */
