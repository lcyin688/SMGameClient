import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import ActivityMgr from './ActivityMgr';
import RedDotMgr from './RedDotMgr';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 独立日活动 管理类 */
        independentMgr: IndependentMgr;
    }
}

interface IIndependentData extends ApiProto.IndependenceTaskProgressResp {
    /** 上一次请求数据时间戳 ms */
    lastTs: number;
    /** 配置接口正在请求数据 */
    requesting: boolean;
}

class IndependentMgr {
    /** 独立日活动数据 */
    public actInfo: IIndependentData = null;

    /**
     * 是否开启 独立日活动
     */
    public isOpenAct(): boolean {
        if (this.actInfo) {
            let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
            if (this.actInfo.startTime <= curTime && this.actInfo.endTime > curTime) {
                return true;
            }
        }

        return false;
    }

    /**
     * 独立日活动数据
     * @param errCb 失败
     * @param showLoading 显示 loading
     */
    public getActivityInfo(errCb?: Function, showLoading: boolean = false): Promise<void> {
        return new Promise((resolve, reject) => {
            if (this.actInfo) {
                if (new Date().getTime() - this.actInfo.lastTs < 2 * 1000) {
                    resolve();
                    return;
                }
            } else {
                this.actInfo = {} as IIndependentData;
            }

            if (this.actInfo.requesting) {
                resolve();
                return;
            }
            this.actInfo.requesting = true;

            ApiManager.getIndependenceActivityInfo(
                (data: ApiProto.IndependenceTaskProgressResp) => {
                    this.syncData(data);
                    resolve();
                },
                (code) => {
                    this.actInfo.lastTs = 0;
                    this.actInfo.requesting = false;
                    errCb?.(code);
                    reject(code);
                },
                showLoading
            );
        });
    }

    /**
     * 同步独立日活动数据
     * @param data
     */
    public syncData(data: ApiProto.IndependenceTaskProgressResp): void {
        if (!data || !UserManager.isLogin()) {
            return;
        }

        this.actInfo = data as IIndependentData;
        this.actInfo.requesting = false;
        this.actInfo.lastTs = new Date().getTime();
        this.syncRedDotData();

        cc.director.emit(CommonEvent.UPDATE_INDEPENDENT_TASK);
    }

    /**
     * 计算独立日红点数量
     */
    private syncRedDotData() {
        // 总任务奖励
        const isShowAll = this.actInfo?.ultimateTaskStatus == ActivityMgr.TaskStatus.COMPLETED;
        let count = isShowAll ? 1 : 0;

        // 任务列表
        let taskList = this.actInfo?.independence || [];
        taskList = taskList.filter((item) => {
            return item.taskStatus == ActivityMgr.TaskStatus.COMPLETED;
        });
        count = count + taskList.length;

        RedDotMgr.red.updateRedDotCnt(RedDotMgr.cfg.independent, count, true);
    }
}

export default we.common.independentMgr = new IndependentMgr();
