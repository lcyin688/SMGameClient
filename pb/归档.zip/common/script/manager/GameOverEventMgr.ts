import GameManager from './GameManager';

declare global {
    interface ICommon {
        /** 子游戏返回大厅后业务处理 */
        gameOverEventMgr: GameOverEventMgr;
    }
}

class GameOverEventMgr {
    // 在线热更的信息
    public updateHotOnlineData = {
        gameId: -1,
        version: null,
    };

    public gameOverCommonEventHandle(): boolean {
        if (this.updateHotOnline()) {
            return true;
        }
        return false;
    }

    // 在线热更
    public updateHotOnline(): boolean {
        let gameId = this.updateHotOnlineData.gameId;
        let version = this.updateHotOnlineData.version;

        let createAlert = (callback: Function) => {
            we.commonUI.showConfirm({
                title: we.core.langMgr.getLangText(we.launcher.lang.TIPS_HOT_UPDATE1),
                content: we.core.langMgr.getLangText(we.launcher.lang.TIPS_HOT_UPDATE2),
                yesHandler: we.core.Func.create(() => {
                    this.updateHotOnlineData.gameId = -1;
                    this.updateHotOnlineData.version = null;
                    callback?.();
                }, this),
                priority: we.ui.type.PopupPriority.System,
            });
        };

        if (gameId >= 0 && version) {
            let localVersion = we.core.gameConfig.getModuleVersion(we.core.gameConfig.getBundleName(gameId));
            if (gameId == we.GameId.HALL) {
                if (we.core.utils.compareVersion(localVersion, version) < 0) {
                    createAlert(() => {
                        cc.game.restart();
                    });
                    return true;
                }
            } else {
                if (we.core.gameConfig.curGameId === gameId && we.core.utils.compareVersion(localVersion, version) < 0) {
                    createAlert(() => {
                        GameManager.runGame(we.GameId.HALL, -1, () => {
                            GameManager.runGame(gameId);
                        });
                    });
                    return true;
                }
            }
        }

        return false;
    }
}

export default we.common.gameOverEventMgr = new GameOverEventMgr();
