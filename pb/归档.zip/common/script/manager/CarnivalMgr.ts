import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import { CommonLanguage } from '../const/CommonLanguage';
import ActivityMgr from './ActivityMgr';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 狂欢活动 管理类 */
        carnivalMgr: CarnivalMgr;
    }
}

interface ICarnivalData extends ApiProto.CarnivalTaskProgressResp {
    /** 上一次请求数据时间戳 ms */
    lastTs: number;
    /** 配置接口正在请求数据 */
    requesting: boolean;
}

class CarnivalMgr {
    /** 活动支持任务类型 */
    public taskType: string[] = [];

    /** 狂欢活动数据 */
    public actInfo: ICarnivalData = {} as ICarnivalData;

    public init(): void {
        this.taskType = [ActivityMgr.TaskType.recharge, ActivityMgr.TaskType.betAmount];

        this.actInfo = null;
    }

    /**
     * 是否开启 狂欢活动
     * @returns
     */
    public isOpenAct(): boolean {
        if (this.actInfo) {
            let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
            if (this.actInfo.startTime <= curTime && this.actInfo.endTime > curTime) {
                return true;
            }
        }

        return false;
    }

    /**
     * 狂欢活动数据
     * @param errCb 失败
     * @param showLoading 显示 loading
     */
    public getActivityInfo(errCb?: Function, showLoading: boolean = false): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            if (this.actInfo) {
                if (new Date().getTime() - this.actInfo.lastTs < 5 * 1000) {
                    cc.director.emit(CommonEvent.UPDATE_CARNIVAL);
                    resolve();
                    return;
                }
            } else {
                this.actInfo = {} as ICarnivalData;
            }

            if (this.actInfo.requesting) {
                resolve();
                return;
            }
            this.actInfo.requesting = true;

            ApiManager.getCarnivalActivityInfo(
                (data: ApiProto.CarnivalTaskProgressResp) => {
                    this.syncData(data);

                    cc.director.emit(CommonEvent.HALL_POPUP_QUEUE_UPDATE);
                    resolve();
                },
                (code) => {
                    this.actInfo.lastTs = 0;
                    this.actInfo.requesting = false;
                    errCb?.(code);
                    reject(code);
                },
                showLoading
            );
        });
    }

    /**
     * 更新单个任务状态
     * @param taskType 任务类型
     * @param level 任务阶段
     * @param status 默认修改为奖励已领取状态 ActivityMgr.TaskStatus.REWARD_RECEIVED
     * @returns
     */
    public updateSingleTaskSt(taskType: string, level: number, status: number = ActivityMgr.TaskStatus.REWARD_RECEIVED): void {
        if (!(typeof taskType == 'string' && taskType.length > 0) || level < 0) {
            return;
        }

        let taskList: ApiProto.TaskProgressDetail[] = this.actInfo?.[taskType] || [];
        if (taskList.length > 0) {
            for (let i = 0; i < taskList.length; i++) {
                if (taskList[i]?.level == level) {
                    taskList[i].taskStatus = status;
                    break;
                }
            }
        }
    }

    /**
     * 狂欢活动已关闭
     */
    public activityClose(): void {
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.GET_TASK_AWARD_CODE_7));
        cc.director.emit(CommonEvent.CLOSE_CARNIVAL_VIEW);
    }

    /**
     * 同步活动数据
     * @param data
     * @returns
     */
    public syncData(data: ApiProto.CarnivalTaskProgressResp): void {
        if (!data || !UserManager.isLogin()) {
            return;
        }

        this.actInfo = data as ICarnivalData;
        this.actInfo.lastTs = new Date().getTime();
        this.actInfo.requesting = false;
        this.syncRedData();

        cc.director.emit(CommonEvent.UPDATE_CARNIVAL);
    }

    /**
     * 同步红点数据
     */
    public syncRedData(): void {
        let redCount = 0;

        if (this.actInfo) {
            // 累计任务
            if (this.actInfo?.ultimateTaskStatus == ActivityMgr.TaskStatus.COMPLETED) {
                redCount += 1;
            }

            // 充值任务
            let rechargeTask: ApiProto.TaskProgressDetail[] = this.actInfo.recharge || [];
            rechargeTask = rechargeTask.filter((item) => {
                return item.taskStatus == ActivityMgr.TaskStatus.COMPLETED;
            });
            redCount += rechargeTask.length;

            // 打码任务
            let betAmount: ApiProto.TaskProgressDetail[] = this.actInfo.betAmount || [];
            betAmount = betAmount.filter((item) => {
                return item.taskStatus == ActivityMgr.TaskStatus.COMPLETED;
            });
            redCount += betAmount.length;
        }

        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.carnival, redCount, true);
    }

    /**
     * 根据任务类型返回是否展示红点
     * @param type 任务类型 CarnivalMgr.taskType
     * @returns
     */
    public isShowRedPointByType(type: string): boolean {
        let taskList: ApiProto.TaskProgressDetail[] = this.actInfo?.[type] || [];
        taskList = taskList.filter((item) => {
            return item.taskStatus == ActivityMgr.TaskStatus.COMPLETED;
        });

        return taskList.length > 0;
    }
}

export default we.common.carnivalMgr = new CarnivalMgr();
