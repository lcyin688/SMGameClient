import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import { AccountVerifyType } from '../const/CommonConst';
import NamingServiceMgr from '../naming/NamingServiceMgr';
import AppleLogin from '../platform/AppleLogin';
import Facebook from '../platform/Facebook';
import GoogleLogin from '../platform/GoogleLogin';
import { WsCloseCode } from '../socket/SocketCode';
import GameManager from './GameManager';

declare global {
    interface ICommon {
        /** 用户信息模块 */
        userMgr: UserManager;
    }
}

/** 常用道具 id 映射 */
const PropId = {
    /** 金币 */
    CoinId: 0,
    /** 钻石 */
    GemId: 1,
    /** Rp 兑换劵 */
    RpId: 2,
    /** 代理 */
    AgentId: 11,
    /** 扭蛋币 */
    GashaponId: 101,
    /** Vip 表情 */
    VIPEmojiBuffId: 1302,
    /** 捕鱼炮台 */
    FishCannonId: 14100,
};

class UserManager {
    /** 常用道具 id 映射 */
    public readonly PropId = PropId;

    /** 验证Token */
    public token = '';
    public tokenV2 = '';
    /** 最近一次获取验证码时间戳 单位:ms */
    public getCodeTimestamp = {
        /** 手机 注册/绑定 */
        phoneRegister: 0,
        /** 手机 重置密码 */
        phoneResetPassword: 0,
        /** 手机 绑定银行卡 */
        phoneBindBank: 0,
        /** 邮件 注册/绑定 */
        emailRegister: 0,
        /** 邮件 重置密码 */
        emailResetPassword: 0,
        /** 邮件 绑定银行卡 */
        emailBindBank: 0,
    };
    /** 跨天timeout */
    public crossDayTimeout: any = null;
    /** 玩家Vip等级信息 */
    public vipExp: ApiProto.VipExp = null;
    /** 用户信息 */
    public userInfo: ApiProto.UserInfoResp = {
        userId: -1,
        userName: '',
        phone: '',
        bio: '',
        gender: -1,
        avatar: '',
        gold: 0,
        exp: null,
        isFormal: 0,
        fbAccount: '',
        gameCount: 0,
        maxWinAmount: 0,
        lastLoginTime: 0,
        vipExp: 0,
        diamond: 0,
        prizeWheelNum: 0,
        remainSendGiftNum: 0,
        rechargeCount: 0,
        totalWinAmount: 0,
        country: '',
        isAgent: false,
        appleAccount: '',
        emailAccount: '',
        whatsappNumber: '',
        privacy: 3,
        googleAccount: '',
        vp: null,
        zoneCode: '',
        rpAmount: 0,
        googleEmail: '',
        fbEmail: '',
        appleEmail: '',
        bankInfo: null,
        tgNumber: '',
        birthday: 0,
        agentGold: 0,
        checkContact: 0,
    } as ApiProto.UserInfoResp;

    /** 绑定手机信息 */
    public bindPhone = {
        /** 绑定验证方式 */
        type: null as AccountVerifyType,
        /** 绑定的手机号 */
        phones: {} as Record<number | string, string>,
        /** 绑定的时间戳 */
        timestamps: {} as Record<number | string, number>,
    };

    /** 是否显示新号赠送金币弹窗 */
    public isShowGiveDialog = false;
    /** 是否为新用户 */
    public isNewbie: boolean = false;
    /** 是否注册成功（一次性的） */
    public isFirstRegister: boolean = false;
    /** 玩家详情缓存 */
    public userInfoCacheMap: Map<number, ApiProto.UserProfileResp> = new Map<number, ApiProto.UserProfileResp>();

    /** 头像资源名配置 */
    public avatarArr: Array<string> = [
        'head_boy1',
        'head_boy2',
        'head_boy3',
        'head_boy4',
        'head_boy5',
        'head_boy6',
        'head_boy7',
        'head_boy8',
        'head_boy9',
        'head_boy10',
        'head_girl1',
        'head_girl2',
        'head_girl3',
        'head_girl4',
        'head_girl5',
        'head_girl6',
        'head_girl7',
        'head_girl8',
        'head_girl9',
        'head_girl10',
    ];
    /** 实名认证信息 */
    public realName: ApiProto.GetUserContactResp = {
        userContacts: [],
        account: '',
        name: '',
    };

    /** 初始化玩家数据 */
    public initUser(data: ApiProto.UserInfoResp): void {
        this.userInfo = data;
        this.vipExp = data.vp;

        we.core.nativeUtil.oneSignalSetUserId(data.userId.toString());
        we.core.nativeUtil.oneSignalSetTag('channel', we.core.nativeUtil.getChannel());
        we.core.nativeUtil.oneSignalSetTag('country', data.country);

        we.core.userStatusInfo.setProvider(this);
    }

    /** 缓存玩家信息到本地 */
    public initAccount(): void {
        this.userInfo.userId = we.kit.storageUtil.readUserId();
        this.token = we.kit.storageUtil.readUserToken();
        we.core.nativeUtil.setAppsFlyerUserId(this.userInfo.userId.toString());
    }

    /** 清理玩家ID和Token缓存 */
    private clearAccount(): void {
        this.userInfo.userId = -1;
        this.token = '';
        this.tokenV2 = '';
    }

    /**
     * 是否已经登录
     */
    public isLogin(): boolean {
        return this.userInfo.userId > -1 && !!this.token && !!this.tokenV2;
    }

    /**
     * 是否实名
     */
    public isRealName(): boolean {
        return this.userInfo.checkContact == 1 || this.realName?.account?.length > 0;
    }

    /**
     * 退出登录
     * @param clearCache
     * @param exitCallback
     */
    public exitLogin(clearCache: boolean = false, track: string = '') {
        this.clearLoginData(clearCache, track);
        GameManager.runGame(we.GameId.LAUNCHER);
    }

    /**
     * 清除用户数据
     * @param clearCache 是否清除登录态缓存
     */
    public clearLoginData(clearCache: boolean, track: string = '') {
        if (track) {
            we.info(`UserManager clearLoginData, clearCache: ${clearCache}, track: ${track}`);
        }

        if (clearCache) {
            // we.kit.localStorageUtil.clearUserID();
            we.kit.storage.del('sys', 'user_token');
            we.kit.storageUtil.clearUserToken();
            Facebook.logout();
            AppleLogin.logout();
            GoogleLogin.logout();
        }

        // 清理跨天数据请求
        if (this.crossDayTimeout) {
            clearTimeout(this.crossDayTimeout);
            this.crossDayTimeout = null;
        }

        this.clearAccount();
        we.core.projectConfig.autoLogin = false;
        NamingServiceMgr.close(WsCloseCode.ExitLogin, 'UserManager clearLoginData');

        this.isShowGiveDialog = false;
        this.userInfoCacheMap.clear();
    }

    /** 是否为正式账户 */
    public isFormal(): boolean {
        return this.userInfo.isFormal == 1;
    }

    public pushUserInfoInCache(id: number, data: ApiProto.UserProfileResp) {
        if (!id || !data) {
            we.warn('UserManager pushUserInfoInCache, params is null');
        }
        this.userInfoCacheMap.set(id, data);
    }

    /**
     * 同步用户货币(金币 保险柜金币 代理金币)
     * @param sucCb
     * @param errCb
     */
    public onSyncUserCoinInfo(sucCb?: Function, errCb?: Function): void {
        ApiManager.getUserCreditReq(
            (data: ApiProto.UserCreditResp) => {
                if (!this.isLogin()) {
                    return;
                }

                this.userInfo.gold = data.credit;
                this.userInfo.agentGold = data.agentGold;
                cc.director.emit(CommonEvent.UPDATE_USER_INFO_SHOW);

                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取Vip信息 等级/经验
     * @param sucCb
     * @param errCb
     */
    public getVipInfo(sucCb?: Function, errCb?: Function): void {
        ApiManager.getVipInfo(
            (data: ApiProto.UserVipInfoResp) => {
                if (!this.isLogin()) {
                    return;
                }
                if (this.userInfo.userId == -1 || !data) {
                    return;
                }

                let needUpdate = this.userInfo?.vp?.level != data.vp?.level || this.userInfo?.vp?.exp != data.vp?.exp;
                this.userInfo.vp = data.vp;
                this.vipExp = data.vp;

                if (needUpdate) {
                    cc.director.emit(CommonEvent.VIP_EXP_CHANGE);
                    cc.director.emit(CommonEvent.UPDATE_USER_INFO_SHOW);
                }

                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 刷新用户数据
     * @param sucCb
     * @param errCb
     */
    public refreshUserInfo(sucCb?: Function, errCb?: Function): void {
        this.initAccount();

        let sendData = {} as ApiProto.UserInfoReq;
        sendData.userId = this.userInfo.userId;
        ApiManager.getUserInfo(
            sendData,
            (data: ApiProto.UserInfoResp) => {
                this.initUser(data);
                cc.director.emit(CommonEvent.UPDATE_USER_INFO_SHOW);

                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 统一发送玩家信息变动
     * @param info 传入修改的玩家信息内容
     * @param sucCb
     * @param errCb
     */
    public updateChangeUserInfo(info: ApiProto.ModifyUserReq, sucCb?: Function, errCb?: Function): void {
        // 签名和 whatsapp 可以传空重置 特殊处理
        info.bio = info.bio == undefined ? this.userInfo.bio : info.bio;
        info.whatsappNumber = info.whatsappNumber == undefined ? this.userInfo.whatsappNumber : info.whatsappNumber;
        info.tgNumber = info.tgNumber == undefined ? this.userInfo.tgNumber : info.tgNumber;
        info.birthday = info.birthday == undefined ? this.userInfo.birthday : info.birthday;

        ApiManager.changeUserInfo(info, sucCb, errCb);
    }

    /**
     * 通过玩家Id获取玩家信息
     * @param userId
     * @param sucCb
     * @param isCache
     * @param errCb
     * @param isShowLoading
     */
    public getUserProfileById(userId: number, sucCb?: Function, isCache: boolean = false, errCb?: Function, isShowLoading: boolean = false): void {
        if (isCache && this.userInfoCacheMap && this.userInfoCacheMap.size > 0) {
            let data = this.userInfoCacheMap.get(userId);
            if (data) {
                sucCb?.(data);
                return;
            }
        }

        let sendData = {} as ApiProto.UserProfileReq;
        userId && (sendData.userId = userId);
        ApiManager.getUserProfileById(
            sendData,
            (data: ApiProto.UserProfileResp) => {
                if (this.isLogin() && data && data.profile) {
                    // 暂存读缓存不影响显示的玩家数据
                    this.pushUserInfoInCache(data.profile.userId, data);
                    sucCb?.(data);
                }
            },
            (code) => {
                errCb?.(code);
            },
            isShowLoading
        );
    }

    /**
     * 获取实名认证信息
     */
    public getRealNameData(sucCb?: we.core.Func<() => void>) {
        we.common.apiMgr.getUserContact((data: ApiProto.GetUserContactResp) => {
            this.realName = data;
            sucCb?.exec();
        }, null);
    }

    /**
     * 更新实名认证信息
     */
    public updateRealNameData(params: ApiProto.UpdateUserContactReq, sucCb?: we.core.Func<() => void>) {
        if (this.realName.userContacts && this.realName.userContacts.length > 0) {
            we.common.apiMgr.updateUserContact(
                params,
                (data: ApiProto.UpdateUserContactResp) => {
                    this.realName = data;
                    sucCb?.exec();
                },
                null
            );
        } else {
            we.common.apiMgr.addUserContact(
                params,
                (data: ApiProto.UserContactResp) => {
                    this.realName = data;
                    sucCb?.exec();
                },
                null
            );
        }
    }

    /**
     * 获取当前国家实名身份证长度
     */
    public getRealNameKTPLength() {
        const lens = {
            [we.core.CountryCode.vn]: 12,
            [we.core.CountryCode.in]: 12,
            [we.core.CountryCode.pk]: 13,
        };
        return lens[we.core.flavor.getCountryCode()] || 16;
    }

    /**
     * 是否为实名身份证号码
     */
    public isRealNameKTP(ktp: string) {
        return new RegExp(`^\\d{${we.common.userMgr.getRealNameKTPLength()}}$`).test(ktp);
    }
}

export default we.common.userMgr = new UserManager();
