import ApiManager from '../api/ApiManager';
import { CommonType } from '../config/CommonType';
import { CommonLanguage } from '../const/CommonLanguage';
import HttpProtoError from '../http/HttpProtoError';
import { RedDot } from './RedDotMgr';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 代理 管理类 */
        agentMgr: AgentMgr;
    }
}

class AgentMgr {
    /** 详情分类 */
    public readonly Detail_Type = {
        /** 邀请返利 */
        INVITE_REBATE: 0,
        /** 邀请奖励 */
        INVITE_REWARD: 1,
        /** 打码奖励 */
        BET_REWARD: 2,
        /** 充值奖励 */
        RECHARGE_REWARD: 3,
        /** 有效人数奖励 */
        VALID_REWARD: 4,
    };

    /** 配置和开关信息 */
    public agentConfig: ApiProto.AgentConfRebateRewardResp = null;

    /** 邀请奖励总览 */
    public inviteInfo: ApiProto.AgentInviteRewardInfoResp = null;

    public init() {
        this.agentConfig = null;
        this.inviteInfo = null;
    }

    /**
     * 活动配置说明接口
     * @param sucCb
     * @param errCb
     */
    public getConfig(sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentRewardConfig(
            (data: ApiProto.AgentConfRebateRewardResp) => {
                this.agentConfig = data;
                sucCb?.();
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 邀请总览接口
     * @param sucCb
     * @param errCb
     */
    public getInviteInfo(sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentInviteRewardInfo(
            (data: ApiProto.AgentInviteRewardInfoResp) => {
                this.syncData(data);

                sucCb?.();
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取邀请人数及奖励
     * @param sucCb
     * @param errCb
     */
    public getInvitationRewards(sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentInvitationRewards(
            (data: ApiProto.AgentInvitationRewardsResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取邀请打码及奖励
     * @param sucCb
     * @param errCb
     */
    public getBetAmountRewards(sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentBetAmountRewards(
            (data: ApiProto.AgentBetAmountRewardsResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取邀请充值及奖励
     * @param sucCb
     * @param errCb
     */
    public getRechargeRewards(sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentRechargeRewards(
            (data: ApiProto.AgentRechargeRewardsResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取邀请详情
     * @param param
     * @param sucCb
     * @param errCb
     */
    public getInviteRewardDetail(param: ApiProto.AgentInviteRewardDetailReq, sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentInviteRewardDetail(
            param,
            (data: ApiProto.AgentInviteRewardDetailResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取邀请人头奖励详情
     * @param param
     * @param sucCb
     * @param errCb
     */
    public getInvitationRewardsDetail(param: ApiProto.AgentInvitationRewardsDetailReq, sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentInvitationRewardsDetail(
            param,
            (data: ApiProto.AgentInvitationRewardsDetailResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取邀请打码奖励详情
     * @param param
     * @param sucCb
     * @param errCb
     */
    public getBetAmountRewardsDetail(param: ApiProto.AgentBetAmountRewardsDetailReq, sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentBetAmountRewardsDetail(
            param,
            (data: ApiProto.AgentBetAmountRewardsDetailResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取邀请充值奖励详情
     * @param param
     * @param sucCb
     * @param errCb
     */
    public getRechargeRewardsDetail(param: ApiProto.AgentRechargeRewardsDetailReq, sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentRechargeRewardsDetail(
            param,
            (data: ApiProto.AgentRechargeRewardsDetailResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取有效邀请人数奖励总览
     * @param sucCb
     * @param errCb
     */
    public getValidAgentRewards(sucCb?: Function, errCb?: Function) {
        ApiManager.getValidAgentRewards(
            (data: ApiProto.ValidAgentRewardsResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取有效邀请人数详情
     * @param param
     * @param sucCb
     * @param errCb
     */
    public getValidAgentRewardsDetail(param: ApiProto.ValidAgentRewardsDetailReq, sucCb?: Function, errCb?: Function) {
        ApiManager.getValidAgentRewardsDetail(
            param,
            (data: ApiProto.ValidAgentRewardsDetailResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 获取领取奖励记录
     * @param sucCb
     * @param errCb
     */
    public getDrawRewardRecord(sucCb?: Function, errCb?: Function) {
        ApiManager.getDrawRewardRecord(
            (data: ApiProto.AgentDrawRewardRecordResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 领取代理奖励
     * @param sucCb
     * @param errCb
     */
    public getAgentReward(sucCb?: Function, errCb?: Function) {
        ApiManager.getAgentAward(
            (data: ApiProto.AgentDrawRewardResp) => {
                RedDot.red.updateRedDotCnt(RedDot.cfg.agent, -1);

                sucCb?.(data);
            },
            (code) => {
                if (code == HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3024) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.ERROR_USUAL_TYPE_3024));
                }
                errCb?.(code);
            }
        );
    }

    /**
     * 手动绑定上级
     * @param userId
     * @param sucCb
     * @param errCb
     */
    public bindUpAgent(userId: number, sucCb?: Function, errCb?: Function) {
        let param: ApiProto.BindAgentReq = {
            upId: userId,
        };
        ApiManager.bindUpAgent(
            param,
            (data: ApiProto.BindAgentResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 自动绑定上级代理人
     */
    public autoBindAgent(): void {
        let userId = CommonType.storage.get('common', 'agent_superior');
        if (userId) {
            return;
        }

        if (cc.sys.isNative) {
            userId = we.core.nativeUtil.getClipboardText();
            if (!userId) {
                return;
            }
        } else {
            userId = we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.id);
            if (!userId) {
                return;
            }
        }

        try {
            userId = we.core.utils.base64Decode(userId);
            // 4.6.1 开始改为 json 字符串
            try {
                userId = JSON.parse(userId).userId;
            } catch (err) {}
        } catch (err) {
            return;
        }

        let localUserId = we.kit.storageUtil.readUserId();
        if (parseInt(userId) > 0 && parseInt(userId) != localUserId) {
            let data = {} as ApiProto.BindAgentReq;
            data.upId = parseInt(userId);
            ApiManager.bindUpAgent(
                data,
                (data: ApiProto.BindAgentResp) => {
                    if (data.code == 0) {
                        CommonType.storage.setById('common', 'agent_superior', parseInt(userId) + '');
                        we.log('AgentMgr autoBindAgent, auto bind success!');
                    }
                },
                null
            );
        }
    }

    /**
     * 获取代理邀请链接
     * @returns
     */
    public getAgentLink(): string {
        let link = we.core.projectConfig.settingsConfig?.officialUrlWithUid || '';
        if (link.length > 0) {
            let cchn = we.core.projectConfig.settingsConfig?.cchn || '';
            let chnData = we.core.utils.base64Encode(cchn);
            let uid = we.core.utils.base64Encode(UserManager.userInfo.userId.toString());
            let params = [`chn=${chnData}`, `id=${uid}`];
            for (let i = 0; i < params.length; i++) {
                let key = params[i].split('=')[0];
                if (link.includes(key + '=')) {
                    continue;
                }
                let oneParam = (link.includes('?') ? '&' : '?') + params[i];
                if (i === 0 && link.includes('?')) {
                    oneParam = params[i];
                }
                link = link + oneParam;
            }
        }

        return link;
    }

    /**
     * 同步邀请奖励信息
     * @param data
     * @returns
     */
    public syncData(data: ApiProto.AgentInviteRewardInfoResp): void {
        if (!data || !UserManager.isLogin()) {
            return;
        }

        this.inviteInfo = data;
        this.syncRedDotData();
    }

    /**
     * 同步红点数据
     */
    private syncRedDotData(): void {
        let count = 0;
        if (this.inviteInfo) {
            count = this.inviteInfo.rewardRemaining > 0 ? 1 : 0;
        }

        RedDot.red.updateRedDotCnt(RedDot.cfg.agent, count, true);
    }
}

export default we.common.agentMgr = new AgentMgr();
