import ApiManager from '../api/ApiManager';
import { CommonEvent, EventMsg } from '../config/CommonEvent';
import { CommonRes } from '../config/CommonRes';
import { CommonType } from '../config/CommonType';
import { JumpCmd } from '../const/CommonConst';
import { CommonLanguage } from '../const/CommonLanguage';
import { CommonModel } from '../model/CommonModel';
import CommonMgr from './CommonMgr';
import SocketManager from './SocketManager';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        gameMgr: typeof GameManager;
    }
    interface TCommon {
        IOngoingGameResp: IOngoingGameResp;
    }
    namespace we {
        type IOngoingGameResp = TCommon['IOngoingGameResp'];
    }
}

interface IRoomInfo extends ApiProto.RoomInfoResp {
    timestamp: number;
}

interface IOngoingGameResp extends ApiProto.OngoingGameResp {
    timestamp: number;
    /** 正在请求中 */
    requesting: boolean;
    /** 完成回调 */
    completeCallBack: Function;
}

/** 阻断进入子游戏情况枚举 */
enum StopEnterSubGameCode {
    /** 配置异常 */
    CONFIG_ERROR = 0,
    /** 子游戏维护中 */
    MAINTAIN = 1,
    /** 未完成游戏 */
    UNFINISHED_GAME = 2,
}

export default class GameManager {
    private static gameEntryCancel: we.core.CancelAction;

    /** 当前游戏信息 */
    private static curGameInfo: CommonType.IGameInfo = {
        gameId: null,
        roomKind: -1,
        extraData: null,
    };
    /** 上次游戏信息 */
    public static lastGameInfo: CommonType.IGameInfo = {
        gameId: null,
        roomKind: -1,
        extraData: null,
    };

    /** 进入游戏限制配置 */
    public static gameEnterLimitConf: ApiProto.GameEnterLimitResp = null;

    /** 未完成游戏 */
    public static unfinishedGame: IOngoingGameResp = null;

    public static init(): void {
        we.core.gameConfig.curGameId = we.GameId.LAUNCHER;
        this.unfinishedGame = {} as IOngoingGameResp;
        this.unfinishedGame.timestamp = 0;
        this.unfinishedGame.requesting = false;

        we.event<we.core.EventMsg>().on(
            'LaunchScene',
            (gameId) => {
                this.runGame(gameId);
            },
            this
        );
    }

    /**
     * 进入游戏
     * @param gameId 游戏id
     * @param roomKind 房间级别, 默认 -1
     * @param completeCallback 完成回调, 默认 null
     * @param isLimit 是否检查房间限制, 默认 true
     * @param extraData 额外数据, 默认 null
     * @param isGameToHall 是否是从子游戏回大厅
     */
    public static async runGame(gameId: we.GameId, roomKind: number = -1, completeCallback: () => void = null, isLimit: boolean = true, extraData: any = null, isGameToHall: boolean = false) {
        we.log(`GameManager runGame, gameId: ${gameId}, roomKind: ${roomKind}`);

        if (we.core.gameConfig.curGameId === gameId) {
            if (gameId == we.GameId.LAUNCHER) {
                cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
            }

            if (gameId != we.GameId.HALL) {
                return;
            }
        }

        if (we.core.gameConfig.isSubGame(gameId)) {
            if (!this.gameEnterLimitConf) {
                this.getGameEnterLimitConf();
            }

            // VIP等级限制
            const vipLimit = this.gameEnterLimitConf?.enterVipLimit?.[gameId] ?? 0;
            if (isLimit && UserManager.vipExp.level < vipLimit) {
                we.commonUI.showConfirm({
                    content: we.core.langMgr.getLangText(we.launcher.lang.NEW_ENTER_TIPS4),
                    isHideCloseBtn: true,
                    yesButtonName: we.core.langMgr.getLangText(CommonLanguage.NEW_ENTER_BTN_BECOMEVIP),
                    yesHandler: we.core.Func.create(() => {
                        cc.director.emit(CommonEvent.JUMP_ACTION_CMD, JumpCmd.Vip);
                    }),
                });
                return;
            }
        }

        we.event<EventMsg>().emit('SceneChangeStart', true);

        let _runGame = (_roomKind: number, isEnterGame?: boolean) => {
            if (we.core.gameConfig.isSubGame(we.core.gameConfig.curGameId)) {
                // 从子游戏退出后停止对应子游戏的预加载
                let bundleName = we.core.gameConfig.getBundleName(we.core.gameConfig.curGameId);
                cc.director.emit(we.core.EventName.PRELOAD_ASSET_STOP, bundleName);
            }

            this.loadBundle(
                gameId,
                () => {
                    this.curGameInfo.gameId = gameId;
                    this.curGameInfo.roomKind = _roomKind;
                    this.curGameInfo.extraData = extraData;

                    if (we.core.gameConfig.isSubGame(gameId)) {
                        this.saveGameTimesInfo(this.curGameInfo.gameId);
                        this.lastGameInfo.gameId = this.curGameInfo.gameId;
                        this.lastGameInfo.roomKind = this.curGameInfo.roomKind;
                        this.lastGameInfo.extraData = this.curGameInfo.extraData;
                        CommonType.storage?.setById('common', 'game_last_info', this.lastGameInfo);
                    }

                    this.loadScene(gameId).then(() => {
                        this.removeGameEntryLoading();
                        if (!we.core.gameConfig.isSubGame(gameId)) {
                            this.removeGameLoading();
                        }
                        completeCallback?.();
                    });
                },
                isEnterGame
            );
        };

        // 是否进入子游戏
        let isEnterGame = we.core.gameConfig.isSubGame(gameId);

        // loading 只有和子游戏相关的切场才显示
        if (isEnterGame) {
            // 从任意场景到子游戏, 子游戏自定义 loading
            if (UserManager.isLogin()) {
                isEnterGame = true;
            }
        } else if (we.core.gameConfig.isSubGame(we.core.gameConfig.curGameId) && gameId == we.GameId.HALL) {
            // 从子游戏到大厅, 大厅通用 loading
            if (UserManager.isLogin()) {
                await this.createGameLoading(gameId);
            }
        }

        if (!isEnterGame) {
            // 不是进入子游戏，则直接启动
            _runGame(roomKind);
            return;
        }

        // 进入子游戏，需要关闭入口转圈、获取房间配置
        this.createGameEntryLoading();

        try {
            const roomInfo: IRoomInfo = await this.getRoomConfig(gameId, false);
            if (!roomInfo) {
                return;
            }

            if (roomInfo.underMaintenance) {
                // 维护提示弹窗
                this.enterSceneError(gameId, StopEnterSubGameCode.MAINTAIN);
                return;
            }

            const ongoingGame = parseInt(roomInfo.lastGame);
            if (we.core.gameConfig.isSubGame(ongoingGame) && ongoingGame != gameId) {
                roomKind = roomInfo.roomIndex;
                this.enterSceneError(gameId, StopEnterSubGameCode.UNFINISHED_GAME, { ongoingGame: ongoingGame, roomIndex: roomInfo?.roomIndex });
                return;
            }

            if (ongoingGame === gameId) {
                roomKind = roomInfo.roomIndex;
                isLimit = false;
            }

            if (roomKind == -1) {
                roomKind = this.getDefaultRoomKind(gameId);
                if (this.lastGameInfo.gameId === gameId && this.lastGameInfo.roomKind >= 0) {
                    roomKind = this.lastGameInfo.roomKind;
                }
            }

            if (isLimit && we.core.gameConfig.isSDSubGame(gameId)) {
                let roomInfo = this.getRoomInfo(gameId, roomKind);
                if (!roomInfo) {
                    // CommonMgr.removeGameLoading();
                    this.removeGameEntryLoading();
                    // TODO 提示信息
                    return;
                }
            }

            _runGame(roomKind, isEnterGame);
        } catch (err) {
            we.error(`GameManager runGame, err: ${JSON.stringify(err.message || err)}`);
            this.enterSceneError(gameId, StopEnterSubGameCode.CONFIG_ERROR);
        }
    }

    /**
     * 加载分包 TODO 删除这个回调
     * @param gameId
     * @param completeCallback
     */
    private static async loadBundle(gameId: we.GameId, completeCallback: () => void, isEnterGame?: boolean) {
        // 先显示缓存版本号
        cc.director.emit(we.core.EventName.LOAD_BUNDLE_VERSION, we.core.gameConfig.getGameVersion(gameId));

        let bundleName = we.core.gameConfig.getBundleName(gameId);
        let _loadBundle = async () => {
            const loadModuleComplete = (success: boolean) => {
                if (!success) {
                    this.removeGameEntryLoading();
                    return;
                }

                completeCallback();

                // 加载完 bundle 后再刷新版本号
                cc.director.emit(we.core.EventName.LOAD_BUNDLE_VERSION, we.core.gameConfig.getGameVersion(gameId));
            };

            if (isEnterGame) {
                try {
                    // TODO 进入子游戏前，保证 combase 加载成功，让combase按需修改GameList，满足老游戏翻新阶段,子游戏独立发布版本
                    if (we.core.gameConfig.isSDSubGame(gameId)) {
                        await we.core.assetMgr.loadCommonBundle(we.bundles.combase);
                    }
                    we.core.assetMgr.loadModule(bundleName, 'entry', we.core.Func.create(we.core.AssetErrorHandler.onLoadModuleError, we.core.AssetErrorHandler, gameId), loadModuleComplete);
                } catch (err) {
                    we.error(`GameManager loadBundle _loadBundle, err: ${JSON.stringify(err.message || err)}`, we.noup);
                    this.enterSceneError(gameId, StopEnterSubGameCode.CONFIG_ERROR);
                }
            } else {
                we.core.assetMgr.loadModule(bundleName, 'sta', we.core.Func.create(we.core.AssetErrorHandler.onLoadModuleError, we.core.AssetErrorHandler, gameId), loadModuleComplete);
            }
        };

        if (we.core.gameConfig.isSubGame(gameId)) {
            try {
                await _loadBundle();
                if (we.core.gameConfig.isSDSubGame(gameId)) {
                    SocketManager.preload(gameId);
                }
            } catch (err) {
                we.error(`GameManager loadBundle, err: ${JSON.stringify(err.message || err)}`, we.noup);
                this.enterSceneError(gameId, StopEnterSubGameCode.CONFIG_ERROR);
            }
        } else {
            await _loadBundle();
        }
    }

    /**
     * 加载场景
     * locker 加锁保证了场景切换串行执行
     * @param gameId
     */
    @we.core.coroutine.locker({ lockType: CommonType.CoroutineLockType.SceneEntry, timeout: 60 })
    private static async loadScene(gameId: we.GameId) {
        const isSubGame = we.core.gameConfig.isSubGame(gameId);
        if (isSubGame && !UserManager.isLogin()) {
            // 登录态异常时不处理子游戏切换场景，异常处理在 CommonSocket
            return;
        }
        const lastGameId = (we.core.gameConfig.preGameId = we.core.gameConfig.curGameId);
        we.core.gameConfig.curGameId = gameId;
        let lastScene = we.currentScene;
        if (lastGameId === gameId) {
            // 减少不必要的切换调用
            return;
        }

        let isRemove = false;
        if (lastScene?.gameId != gameId) {
            // 默认所有 bundle 释放
            isRemove = true;
            if (lastGameId == we.GameId.HALL && this.isRamGreat2G()) {
                // 内存 >= 2G 时不释放 hall 资源
                isRemove = false;
            }
        }

        try {
            let gameCfg = we.core.gameConfig.getGameConfig(gameId);
            let roomInfo = we.core.gameConfig.roomInfoMap.get(gameId);

            const vendorCustomized = CommonModel.Inst.getVendorConfig(gameCfg.vendorId)?.customized;
            const sceneName = we.core.gameConfig.toBundleName(gameId) ?? gameId.toString();
            // 创建逻辑场景
            const currentScene = await we.core.SceneFactory.createCurrentScene(sceneName, gameId);
            const invokeType = we.core.gameConfig.genSceneInvokeType(gameId, gameCfg.vendorId, vendorCustomized);

            // 进入场景
            await we.core.eventSystem.invokeAsync(
                // 场景loading界面显示完成
                new we.core.eventInvoke.SceneEnter(
                    currentScene,
                    async () => {
                        this.removeGameEntryLoading();
                        await this.destroyScene(lastScene, isRemove);
                        if (isSubGame) {
                            // 子游戏显示出加载界面后，要停止之前的背景音乐
                            // 如果子游戏没有背景音乐，这里不停止的话，会导致子游戏播放大厅的背景音乐
                            we.core.audioMgr.stopAll();
                        }
                        lastScene = null;
                        we.core.SceneHelper.setSceneUI(currentScene);
                    },
                    roomInfo?.h5Url
                ),
                invokeType
            );

            // 广播场景切换事件
            we.event<EventMsg>().emit('SceneChangeEnd', true);
        } catch (err) {
            we.error(`GameManager loadScene, enter scene gameId: ${gameId} err: ${JSON.stringify(err.message || err)}`);
            let extraData = null;
            if (we.common.isClientError(err) && err.type == we.common.ClientErrorType.ConfirmError) {
                extraData = { content: err.message };
            }
            this.enterSceneError(gameId, StopEnterSubGameCode.CONFIG_ERROR, extraData);
        } finally {
            if (lastScene) {
                // 销毁当前打开失败的场景
                await this.destroyScene(we.currentScene, true);
                // 回退到上一个场景
                we.currentScene = lastScene;
                we.core.SceneHelper.setSceneUI(lastScene);
            }
        }
    }

    private static async destroyScene(scene: we.core.Scene, isRemove: boolean) {
        if (!scene) {
            return;
        }

        if (scene) {
            let lastGameCfg = we.core.gameConfig.getGameConfig(scene.gameId);
            const vendorCustomized = CommonModel.Inst.getVendorConfig(lastGameCfg.vendorId)?.customized;
            // 关闭上一个场景的UI,是否内存
            // 离开场景
            const invokeType = we.core.gameConfig.genSceneInvokeType(scene.gameId, lastGameCfg.vendorId, vendorCustomized);
            await we.core.eventSystem.invokeAsync(new we.core.eventInvoke.SceneLeave(scene), invokeType);

            // 自动释放场景手动管理资源
            we.core.AssetAutoRelease.Inst.releaseAssets(scene.gameId);

            if (we.core.gameConfig.isApiSubGame(scene.gameId)) {
                ApiManager.exitApiGame(scene.gameId);
            }
            // 销毁场景
            scene.dispose();
        }

        if (isRemove) {
            // 默认所有 bundle 释放
            let lastBundleName = we.core.gameConfig.getBundleName(scene.gameId);
            let dependBundles = we.core.gameConfig.getDependBundles(scene.gameId);
            dependBundles.push(lastBundleName);
            // 按依赖顺序反向释放
            for (let i = dependBundles.length - 1; i >= 0; i--) {
                we.core.assetMgr.removeModule(dependBundles[i], lastBundleName === dependBundles[i]);
            }
        }
    }

    /**
     * 创建游戏加载界面【子游戏回到大厅专属】
     * @param gameId
     */
    private static async createGameLoading(gameId: we.GameId) {
        const defer = we.core.PromiseHelper.defer();
        we.commonUI.createNodeAddInit({
            path: CommonRes.prefab.gameLoading,
            parent: we.ui.UILayer.top,
            componentName: 'GameLoading',
            args: [
                gameId,
                () => {
                    defer.resolve();
                },
            ],
            zIndex: cc.macro.MAX_ZINDEX,
        });

        await defer.promise();
    }

    /**
     * 移除游戏加载界面
     */
    private static removeGameLoading() {
        cc.director.emit(CommonEvent.HIDE_GAME_LOADING);
    }

    /**
     * 切场加载界面
     * @param timeOut
     */
    private static createGameEntryLoading(timeOut: number = 60) {
        this.gameEntryCancel = we.core.CancelAction.create();
        this.gameEntryCancel.add(() => {
            we.commonUI.hideCircleLoading();
        });
        we.commonUI.showCircleLoading({ timeout: timeOut, delay: 0.1, cancel: this.gameEntryCancel, debug: 'GameManager createGameEntryLoading' });
    }

    /**
     * 移除切场加载界面
     */
    private static removeGameEntryLoading() {
        this.gameEntryCancel?.cancel();
    }

    /**
     * 进入场景失败
     * 处理失败后的业务
     * @param gameId
     * @param code
     */
    public static enterSceneError(gameId: we.GameId, code: StopEnterSubGameCode, extraData?: any): void {
        this.removeGameEntryLoading();

        if (!we.common.userMgr.isLogin()) {
            we.core.gameConfig.curGameId = -1;
            CommonMgr.goLogin(extraData?.content ?? we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_10), `10.2`);
            return;
        }

        let content = null;
        switch (code) {
            case StopEnterSubGameCode.CONFIG_ERROR:
                content = we.core.langMgr.getLangText(we.launcher.lang.TIPS_CONNECT_SERVER_TIMEOUT);
                break;
            case StopEnterSubGameCode.MAINTAIN:
                content = we.core.langMgr.getLangText(CommonLanguage.GAME_MAINTENANCE_SUBGAME) + ` : ${gameId}`;
                break;
            case StopEnterSubGameCode.UNFINISHED_GAME:
                CommonMgr.unfinishedGameDialog(extraData?.ongoingGame, extraData?.roomIndex, () => {
                    we.core.gameConfig.curGameId = -1;
                    this.runGame(we.GameId.HALL);
                });
                break;
            default:
                break;
        }

        if (content) {
            we.commonUI.showConfirm({
                content: extraData?.content ?? content,
                isHideCloseBtn: true,
                yesHandler: we.core.Func.create(() => {
                    we.core.gameConfig.curGameId = -1;
                    this.runGame(we.GameId.HALL);
                }),
            });
        }

        cc.director.emit(we.core.EventName.LOAD_VIRTUAL_PROGRESS_END);
    }

    /**
     * 当前游戏id
     * TODO 子游戏解除使用依赖后移除
     * @deprecated 请使用 we.core.gameConfig.curGameId
     */
    public static getCurGameId(): we.GameId {
        return we.core.gameConfig.curGameId;
    }

    /**
     * 当前游戏信息
     * @returns
     */
    public static getCurGameInfo(): CommonType.IGameInfo {
        return this.curGameInfo;
    }

    /**
     * 设置当前游戏信息
     * @param gameInfo
     */
    public static setCurGameInfo(gameInfo: CommonType.IGameInfo) {
        this.curGameInfo = gameInfo;
    }

    /**
     * 上次游戏信息
     * @returns
     */
    public static getLastGameInfo(): CommonType.IGameInfo {
        return this.lastGameInfo;
    }

    /**
     * 设置上次游戏信息
     * @returns
     */
    public static setLastGameInfo(gameInfo: CommonType.IGameInfo) {
        this.lastGameInfo = gameInfo;
    }

    /**
     * 初始化上次游戏信息
     */
    public static initLastGameInfo(): void {
        let lastGameInfo: CommonType.IGameInfo = CommonType.storage.get('common', 'game_last_info');
        if (lastGameInfo) {
            lastGameInfo.gameId = +lastGameInfo.gameId;
            if (we.npm.lodash.isNaN(lastGameInfo.gameId)) {
                lastGameInfo.gameId = null;
            }
            this.setLastGameInfo(lastGameInfo);
        }
    }

    public static async getRoomConfig(gameId: we.GameId, isShowLoading: boolean = true): Promise<IRoomInfo | null> {
        const data: ApiProto.RoomInfoResp | ApiProto.GetApiRoomConfResp = we.core.gameConfig.isSDSubGame(gameId)
            ? await ApiManager.getRoomConfigAsync(gameId, isShowLoading)
            : await ApiManager.getApiRoomConfigAsync(gameId, isShowLoading);

        we.core.gameConfig.updateBundleInfo(data.bundleInfo);

        // 原生 / h5(非开发版) 进子游戏时需要检测 main common 是否有更新, 如果有更新需要更新才可以进子游戏
        if (cc.sys.isNative || (cc.sys.isBrowser && !CC_DEV)) {
            // let dependBundles = [we.bundles.main, we.bundles.common];
            // 临时处理 子游戏 com 全部加入重启更新列表
            let dependBundles = we.core.gameConfig.getDependBundles(gameId);
            for (let i = 0; i < dependBundles.length; i++) {
                let dependBundle = dependBundles[i];
                let localVersion = we.core.gameConfig.getLocalVersion(dependBundle);
                let remoteVersion = we.core.gameConfig.getRemoteVersion(dependBundle);
                if (localVersion != we.core.type.VersionDefault && we.core.utils.compareVersion(localVersion, remoteVersion) < 0) {
                    // 版本不一致，需要更新
                    let updateRecord = we.kit.storage.get('sys', 'app_bundle_update_record') || {};
                    let record = updateRecord[dependBundle] == remoteVersion;

                    we.log('GameManager getRoomConfig, need update bundle: ', dependBundle, remoteVersion, updateRecord);

                    if (!record) {
                        updateRecord[dependBundle] = remoteVersion;
                        we.kit.storage.setById('sys', 'app_bundle_update_record', updateRecord);

                        // 游戏已更新，请重启游戏以继续
                        we.commonUI.showConfirm({
                            content: we.core.langMgr.getLangText(we.launcher.lang.LOAD_NEED_UPDATE_HALL),
                            isHideCloseBtn: true,
                            yesHandler: we.core.Func.create(() => {
                                cc.game.restart();
                            }),
                        });

                        this.removeGameEntryLoading();

                        cc.director.emit(we.core.EventName.LOAD_VIRTUAL_PROGRESS_END);
                        return;
                    }
                }
            }
        }

        if (this.gameEnterLimitConf && data.roomInfoList?.length > 0) {
            // 更新入口vip等级限制
            this.gameEnterLimitConf.enterVipLimit[gameId] = data.roomInfoList[0].minVipLevel;
        }

        data.roomInfoList.sort((a, b) => {
            return a.id - b.id;
        });

        for (let i = 0; i < data.roomInfoList.length; i++) {
            if (i != data.roomInfoList[i].id) {
                we.error(`GameManager getRoomConfig, data.roomInfoList[${i}].id err, gameId: ${gameId}`);
            }
        }

        let roomInfo = data as IRoomInfo;
        roomInfo.timestamp = new Date().getTime();
        // TODO api 测试打开点5
        // TODO api 临时方案，等待大厅api接入
        // roomInfo.h5Url = `https://res.tluwebtest.com/?gameId=5117`;

        if (we.core.gameConfig.isApiSubGame(gameId) && !we.core.utils.isValidUrl(roomInfo.h5Url)) {
            // api 游戏，未获取到有戏游戏链接，则直接中断流程
            throw new Error(`GameManager getRoomConfig, gameId: ${gameId} roomInfo.h5Url: ${roomInfo.h5Url} err`);
        }

        we.core.gameConfig.roomInfoMap.set(gameId, roomInfo);

        return roomInfo;
    }

    /**
     * 获取进入游戏限制配置
     */
    public static getGameEnterLimitConf(completeCallBack: Function = null, errorCallback: Function = null, isShowLoading: boolean = false): void {
        if (this.gameEnterLimitConf) {
            typeof completeCallBack == 'function' && completeCallBack(this.gameEnterLimitConf);
            return;
        }

        ApiManager.getGameEnterLimitConf(
            (data: ApiProto.GameEnterLimitResp) => {
                this.gameEnterLimitConf = data;
                cc.director.emit(we.core.EventName.ENTER_GAME_LIMIT_UPDATE);

                typeof completeCallBack == 'function' && completeCallBack(data);
            },
            (code) => {
                typeof errorCallback == 'function' && errorCallback(code);
            },
            isShowLoading
        );
    }

    /**
     * 获取房间信息列表
     * @param gameId
     * @returns
     */
    public static getRoomInfoList(gameId: we.GameId): ApiProto.RoomInfo[] {
        let roomInfo = we.core.gameConfig.roomInfoMap.get(gameId);
        if (roomInfo) {
            return roomInfo.roomInfoList;
        }

        return [];
    }

    /**
     * 获取游戏版本信息
     * @param gameId
     * @returns
     */
    public static getVersionInfo(gameId: we.GameId): ApiProto.SubGameVersion {
        let roomInfo = we.core.gameConfig.roomInfoMap.get(gameId);
        if (roomInfo) {
            return roomInfo.versionInfo;
        }

        return null;
    }

    /**
     * 获取默认房间类别
     * @param gameId
     * @returns 返回-1表示不存在房间信息
     */
    private static getDefaultRoomKind(gameId: we.GameId): number {
        let roomInfoList = this.getRoomInfoList(gameId);
        if (roomInfoList.length > 0) {
            return roomInfoList[0].id;
        }

        return -1;
    }

    /**
     * 获取房间信息
     * @param gameId 游戏id
     * @param roomKind 房间类别(初中高)
     * @returns
     */
    public static getRoomInfo(gameId: we.GameId, roomKind: number): ApiProto.RoomInfo {
        let roomInfoList = this.getRoomInfoList(gameId);
        for (let i = 0; i < roomInfoList.length; i++) {
            if (roomInfoList[i].id == roomKind) {
                return roomInfoList[i];
            }
        }

        return null;
    }

    /**
     * 获取游戏当前房间信息
     * @returns
     */
    public static getCurRoomInfo(): ApiProto.RoomInfo {
        let gameId = this.curGameInfo.gameId;
        let roomKind = this.curGameInfo.roomKind;
        if (roomKind == -1) {
            roomKind = this.getDefaultRoomKind(gameId);
        }

        return this.getRoomInfo(gameId, roomKind);
    }

    /**
     * 内存是否 >= 2G
     */
    private static isRamGreat2G(): boolean {
        let ram = we.core.nativeUtil.getMemory();
        if (ram < 2048) {
            return false;
        }
        return true;
    }

    /**
     * 存储游戏信息，次数，时间
     * @param gameId
     * @returns
     */
    public static saveGameTimesInfo(gameId: we.GameId) {
        let localGameTimes: CommonType.IGameTimesInfo[] = CommonType.storage?.get('common', 'game_play_times') || [];
        for (let i = 0; i < localGameTimes.length; i++) {
            let curGameTimesInfo: CommonType.IGameTimesInfo = localGameTimes[i];
            if (curGameTimesInfo.gameId === gameId) {
                curGameTimesInfo.times += 1;
                curGameTimesInfo.lastTime = new Date().getTime();
                CommonType.storage?.setById('common', 'game_play_times', localGameTimes);
                return;
            }
        }

        let gameTimesInfo: CommonType.IGameTimesInfo = {} as CommonType.IGameTimesInfo;
        gameTimesInfo.gameId = gameId;
        gameTimesInfo.times = 1;
        gameTimesInfo.lastTime = new Date().getTime();
        localGameTimes.push(gameTimesInfo);
        CommonType.storage?.setById('common', 'game_play_times', localGameTimes);
    }

    /**
     * 获取游戏名称
     * @param gameId
     * @param isFormat 是否格式化 主要是移除多语言中的换行符
     * @returns
     */
    public static getGameEntryName(gameId: we.GameId, isFormat: boolean = true): string {
        if (we.core.gameConfig.isSubGame(gameId)) {
            // 优先使用后台配置的多语言游戏名字
            const gameDetail = we.core.projectConfig.settingsConfig.gameDetails?.[gameId];
            if (gameDetail) {
                let curLangCode = we.core.langMgr.getCurLangCode();
                if (gameDetail.nameText[curLangCode] && gameDetail.nameText[curLangCode].length > 0) {
                    return gameDetail.nameText[curLangCode];
                }
            }

            let entryName = we.core.langMgr.getLangText(CommonLanguage[`GAME_${gameId.toString().replace('.', '_')}`]) || '';
            if (isFormat) {
                entryName = entryName.replace(/\n/gm, ' ');
            }

            return entryName;
        } else {
            we.warn(`GameManager getGameEntryName, params err, gameId: ${gameId}`);
        }

        return '';
    }
}

we.common.gameMgr = GameManager;
