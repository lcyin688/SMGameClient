import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 救援金 管理类 */
        rescueFundsMgr: RescueFundsMgr;
        RescueFundsAbleToApply: typeof RescueFundsAbleToApply;
        RescueFundsDataType: typeof RescueFundsDataType;
        RescueFundsApplyStatus: typeof RescueFundsApplyStatus;
    }
}

interface IRescueFundsData extends ApiProto.ReliefFundApplyListResp {
    ts: number;
    coolingReq: boolean;
    confData: ApiProto.ReliefFundApplyListResp;
}

/** 申请救援金标识 */
enum RescueFundsAbleToApply {
    /** 可以申请 */
    apply = 0,
    /** 已申请 */
    applied = 1,
    /** 不能申请 */
    notApply = 2,
}

we.common.RescueFundsAbleToApply = RescueFundsAbleToApply;

/** 救援金数据类型 */
enum RescueFundsDataType {
    /** 昨天 */
    yesterday = 0,
    /** 今天 */
    today = 1,
}

we.common.RescueFundsDataType = RescueFundsDataType;

/** 救援金申请状态 */
enum RescueFundsApplyStatus {
    /** 申请成功 */
    success = 1,
    /** 活动关闭 */
    activityClose = 2,
    /** 服务异常 */
    serverError = 3,
    /** 重复申请 */
    repeatApply = 4,
    /** 其他 */
    other = 5,
}

we.common.RescueFundsApplyStatus = RescueFundsApplyStatus;

class RescueFundsMgr {
    /** 救援金数据 */
    public rescueFundsData: IRescueFundsData = {} as IRescueFundsData;

    public init(): void {
        this.rescueFundsData = {} as IRescueFundsData;
        this.rescueFundsData.coolingReq = true;
    }

    /** 获取救援金是否开启 */
    public getRescueFundsIsAct(): boolean {
        if (we.core.projectConfig.settingsConfig?.funcSwitch?.reliefActivitySwitch && (!this.rescueFundsData?.confData || this.rescueFundsData.confData.reliefActivitySwitch)) {
            return true;
        }

        return false;
    }

    /**
     * 更新红点
     */
    private updateRedDot(): void {
        let isShow = this.rescueFundsData?.confData?.data[RescueFundsDataType.yesterday]?.ableToApply == RescueFundsAbleToApply.apply;

        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.rescueFunds, isShow ? 1 : 0, true);
    }

    /**
     * 获取救援金数据
     * @param showLoading
     */
    public getUserApplyList(showLoading: boolean = false): Promise<void> {
        if (this.rescueFundsData?.confData) {
            if (new Date().getTime() - this.rescueFundsData.ts < 2 * 1000) {
                return;
            }
        }

        if (this.rescueFundsData?.coolingReq) {
            return;
        }
        this.rescueFundsData.coolingReq = true;

        return new Promise((resolve, reject) => {
            ApiManager.getUserApplyList(
                (msgData: ApiProto.ReliefFundApplyListResp) => {
                    this.rescueFundsData.ts = new Date().getTime();
                    this.syncData(msgData);
                    resolve();
                },
                (code) => {
                    this.rescueFundsData.coolingReq = false;
                    reject(code);
                },
                showLoading
            );
        });
    }

    /**
     * 用户申请救济金
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public userApplyRescueFunds(sucCb?: Function, errCb?: Function, showLoading: boolean = true): void {
        ApiManager.userApplyRescueFunds(
            (data: ApiProto.ReliefFundApplyResp) => {
                switch (data.applyStatus) {
                    case we.common.RescueFundsApplyStatus.success:
                        if (this.rescueFundsData?.confData?.data[RescueFundsDataType.yesterday]) {
                            this.rescueFundsData.confData.data[RescueFundsDataType.yesterday].ableToApply = RescueFundsAbleToApply.applied;
                            this.updateRedDot();
                        }
                        break;
                    case we.common.RescueFundsApplyStatus.activityClose:
                        if (this.rescueFundsData?.confData) {
                            this.rescueFundsData.confData.reliefActivitySwitch = false;
                            cc.director.emit(CommonEvent.RESCUE_FUNDS_SYNC);
                        }
                        break;
                    default:
                        break;
                }
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            },
            showLoading
        );
    }

    /**
     * 获取救援金记录
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public getRescueFundsRecord(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        we.common.apiMgr.getRescueFundsRecord(
            (data: ApiProto.ReliefFundApplyRecordResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            },
            showLoading
        );
    }

    /**
     * 获取救援金活动分vip数值列表
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public getRescueFundsVipConfig(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        we.common.apiMgr.getRescueFundsVipConfig(
            (data: ApiProto.UserVipLevelConfResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            },
            showLoading
        );
    }

    /**
     * 同步 救援金 数据
     * @param data
     * @returns
     */
    public syncData(data: ApiProto.ReliefFundApplyListResp): void {
        if (!data || !UserManager.isLogin()) {
            return;
        }

        this.rescueFundsData.confData = data;
        this.rescueFundsData.coolingReq = false;
        this.updateRedDot();

        cc.director.emit(CommonEvent.RESCUE_FUNDS_SYNC);
    }

    /** 清理救援金请求状态锁 */
    public clearLock(): void {
        this.rescueFundsData.ts = 0;
        this.rescueFundsData.coolingReq = false;
    }
}

export default we.common.rescueFundsMgr = new RescueFundsMgr();
