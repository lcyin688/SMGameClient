import { CommonEvent } from '../config/CommonEvent';
import { CommonLanguage } from '../const/CommonLanguage';
import CarnivalMgr from './CarnivalMgr';
import WithdrawMgr from './WithdrawMgr';
import DailyRechargeMgr from './DailyRechargeMgr';
import IndependentMgr from './IndependentMgr';
import UserManager from './UserManager';
import { CommonType } from '../config/CommonType';
import ApiManager from '../api/ApiManager';
import { RedDot } from './RedDotMgr';
import { JumpCmd } from '../const/CommonConst';
import TurntableMgr from './TurntableMgr';
import RescueFundsMgr from './RescueFundsMgr';

declare global {
    interface ICommon {
        /** 事件中心/Banner 管理类 */
        activityMgr: ActivityMgr;
    }

    namespace we {
        namespace common {
            /** 活动配置数据 */
            interface IActivityConf {
                /** 活动id */
                _id: number;
                /** 活动名称 */
                activity_name: { [k: string]: string };
                /** 结束时间 */
                expire_time?: number;
                /** 活动类型 */
                type: number;
                /** 排序 */
                sort: number;
                /** 活动是否开启 */
                enabled?: boolean;
                /** 活动有效期 is_term ? '限时' : '永久' */
                is_term?: number;
                /** 跳转类型 0: 不跳转， 1: 游戏内， 2: 游戏外 */
                is_jump?: number;
                /** 跳转位置 */
                jump_position?: string;
                /** 图片活动图片路径 */
                activity_picture?: { [k: string]: string };
            }
        }
    }
}

/** Banner */
enum BANNER_TYPE {
    /** 大厅 */
    HALL = 0,
    /** Slots二级大厅 */
    SLOTS = 1,
    /** 代理界面 */
    AGENT = 2,
}

interface QuestionNaireConf {
    enable: boolean;
    url: string;
}

class ActivityMgr {
    /** 活动类型 */
    public ActivityType = cc.Enum({
        /** 每日累充任务 */
        recharge: 'recharge',
        /** 狂欢活动 */
        carnival: 'carnival',
        /** 独立日活动 */
        independence: 'independence',
        /** 每日签到奖励 */
        dailyFreeAward: 'dailyFreeAward',
    });

    /** 任务类型 */
    public TaskType = cc.Enum({
        /** 充值 */
        recharge: 'recharge',
        /** 打码 */
        betAmount: 'betAmount',
        /** 登录 */
        login: 'login',
        /** 最终奖励 */
        ultimate: 'ultimate',
    });

    /** 任务状态 */
    public TaskStatus = {
        /** 等待 */
        WAITING: 0,
        /** 进行中 */
        ONGOING: 1,
        /** 完成奖励未领取 */
        COMPLETED: 2,
        /** 已完成且奖励已发放 */
        REWARD_RECEIVED: 3,
    };

    /** 领取奖励状态 */
    public GET_AWARD_CODE = {
        /** 成功 */
        SUCCESS: 1,
        /** 活动关闭 */
        ACTIVITY_CLOSE: 2,
        /** 服务器异常 */
        SERVICE_ERROR: 3,
        /** 重复领取 */
        REPEAT_DRAW: 4,
        /** 未完成任务 */
        NOT_COMPLETE: 5,
        /** 其他 */
        OTHER: 6,
    };

    /** 活动类型枚举 */
    public SubActivity = {
        NULL: 0,
        /** 通用富文本 */
        COMMON_NOTICE: 1,
        /** 通用图片 */
        COMMON_PREVIEW: 2,
        /** 首次提现 */
        FIRST_WITHDRAW: 11,
        /** 每日签到活动 */
        DAILY_SIGN_IN: 10098,
        /** 周卡活动 */
        WEEKLY_CARD: 10099,
        /** 代理活动 */
        AGENT: 10100,
        /** 笔笔送活动 */
        PEN_PEN_DELIVERY: 10101,
        /** 账号绑定 */
        ACCOUNT_SAFE: 10102,
    };

    /** 开启节日活动 */
    public isOpenFestival: boolean = false;
    /** 活动配置 */
    public activityConf: we.common.IActivityConf[] = [];
    /** Banner配置 大厅海报/Slots二级大厅/代理 */
    public bannerConfig: ApiProto.BannerConfResp = null;
    /** 安全账户绑定配置 */
    public safeBindConfig: ApiProto.BindActivityInfo = null;
    /** 问卷调查 */
    public questionNaireConf: QuestionNaireConf = null;
    /** 事件中心按钮点击红点 */
    public clickRecord: number[] = [];
    /** 今日不在弹出狂欢活动 */
    public todayNoPropCarnival: boolean = false;
    /** 今日不在弹出狂欢活动 */
    public todayNoPropDailyRecharge: boolean = false;
    public dailySignInInfo: we.common.IActivityConf = null;
    /** 签到奖励状态 */
    public dailyFreeAward: ApiProto.DailyFreeAwardConfResp = null;
    /** 七日福利 */
    public sevenDayInfo: ApiProto.NewBieSevenDayActivityInfoResp = null;
    /** 首次使用指定app奖励 */
    public officialPkgAward: ApiProto.GetBonusConfResp = null;
    /** 是否已点击官方频道 */
    public isClickJoinUs: boolean = false;
    /** 今日不在弹出加入官方频道 */
    public todayNoPropJoinUs: boolean = false;
    /** 数据是否有更新表示 */
    public dataUpdateFlags: Record<string, boolean> = {};

    /** 清除活动配置 */
    public init(): void {
        this.activityConf = [];
        this.safeBindConfig = null;
        this.questionNaireConf = { enable: false, url: null };
        this.dailyFreeAward = null;
        this.officialPkgAward = null;
        this.bannerConfig = null;

        let loginDate = CommonType.storage.get('common', 'login_date');
        let todayDate = this.getSpeDateOfTS(we.core.TimeInfo.Inst.serverNow());
        if (loginDate && loginDate == todayDate) {
            this.clickRecord = CommonType.storage.get('common', 'click_event_center_record') || [];
            this.todayNoPropCarnival = !!CommonType.storage.get('common', 'no_prop_carnival');
            this.todayNoPropDailyRecharge = !!CommonType.storage.get('common', 'no_prop_daily_recharge');

            this.isClickJoinUs = !!CommonType.storage.get('common', 'click_join_us_jump');
            this.todayNoPropJoinUs = !this.isClickJoinUs && !!CommonType.storage.get('common', 'no_prop_join_us');
        } else {
            CommonType.storage.setById('common', 'login_date', todayDate);

            this.clickRecord = [];
            CommonType.storage.setById('common', 'click_event_center_record', this.clickRecord);

            this.todayNoPropCarnival = false;
            CommonType.storage.setById('common', 'no_prop_carnival', false);

            this.todayNoPropDailyRecharge = false;
            CommonType.storage.setById('common', 'no_prop_daily_recharge', false);

            this.isClickJoinUs = false;
            CommonType.storage.setById('common', 'click_join_us_jump', false);
            this.todayNoPropJoinUs = false;
            CommonType.storage.setById('common', 'no_prop_join_us', false);
        }

        DailyRechargeMgr.init();
        CarnivalMgr.init();
    }

    /**
     * 获取账号绑定奖励
     * @param sucCallBack
     * @param errCallback
     * @param showLoading
     */
    public getAccountBindAwardConf(sucCallBack: Function = null, errCallback: Function = null, showLoading: boolean = false): void {
        ApiManager.queryActivityBannerConf(
            (data: ApiProto.activityBannerResp) => {
                this.safeBindConfig = data.bindActivity; // 安全账户绑定配置
                sucCallBack?.(data);
            },
            (code) => {
                errCallback?.(code);
            },
            showLoading
        );
    }

    /**
     * 获取 Banner配置 大厅海报/Slots二级大厅/代理
     * @param showLoading
     */
    public getBannerConf(showLoading: boolean = false): void {
        ApiManager.getBannerConfReq(
            (data: ApiProto.BannerConfResp) => {
                this.formatBannerConf(data);
            },
            null,
            showLoading
        );
    }

    /**
     * 同步/格式化 Banner 配置
     * @param data
     */
    public formatBannerConf(data: ApiProto.BannerConfResp): void {
        if (!data) {
            return;
        }

        this.bannerConfig = data;

        // 格式化 banner 图片完整下载地址
        this.bannerConfig?.banners?.forEach((item) => {
            for (let country in item.banner) {
                let url = item.banner[country];
                if (url) {
                    url = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, url);
                    item.banner[country] = url;
                }
            }
        });

        // 通知 UI 层更新
        cc.director.emit(CommonEvent.UPDATE_BANNER_SHOW);
    }

    /**
     * 获取大厅活动中心配置
     * @param sucCallBack
     * @param errCallback
     * @param isShowLoading
     */
    public getActivityConf(sucCallBack: Function = null, errCallback: Function = null, isShowLoading: boolean = false): void {
        ApiManager.getActivityConf(
            (data: ApiProto.ActivityConfResp) => {
                this.formatActivityConf(data);
                cc.director.emit(CommonEvent.HALL_POPUP_QUEUE_UPDATE);
                sucCallBack?.(data);
            },
            (code) => {
                errCallback?.(code);
            },
            isShowLoading
        );
    }

    /**
     * 格式化活动数据
     * @param data
     */
    public formatActivityConf(data: ApiProto.ActivityConfResp, freshData: boolean = true): void {
        if (!data?.conf) {
            return;
        }

        let conf = null;
        try {
            conf = JSON.parse(data.conf);
        } catch (err) {
            we.error(`ActivityMgr getActivityConf, JSON.parse: ${err}`);
        }

        this.activityConf = conf ? conf : [];
        let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
        let chnActivities = we.core.projectConfig.settingsConfig?.funcSwitch?.activitys || [];
        let validActConf = [];
        let curLangCode = we.core.langMgr.getCurLangCode();
        for (let i = 0; i < this.activityConf.length; i++) {
            let data = this.activityConf[i];
            if (!data) {
                continue;
            }

            let isMoveAct = true;
            if (chnActivities.indexOf(data._id) < 0) {
                // 剔除渠道未开放选择活动
            } else if (data.type == this.SubActivity.FIRST_WITHDRAW && WithdrawMgr.config?.activityStatus == 2) {
                // 参加首次提现不显示
            } else if (data._id == 26 && UserManager.isFormal()) {
                // 参加绑定手机活动则不显示
            } else {
                //  筛选活动 已过期 或 不展示  活动有效期 is_term  ? '限时' : '永久'
                if (data.enabled && !(data.is_term && data.expire_time < curTime)) {
                    if (freshData) {
                        this.getFixActivityConf(data.type);
                    }

                    if (data.type == this.SubActivity.COMMON_PREVIEW && data.activity_picture) {
                        // 格式化活动图片完整下载地址
                        for (let country in data.activity_picture) {
                            let url = data.activity_picture[country];
                            if (url) {
                                url = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, url);
                                data.activity_picture[country] = url;
                            }
                        }

                        // 预加载当前语言活动图片
                        we.core.assetMgr.loadAssetRemote(data.activity_picture[curLangCode], cc.SpriteFrame);
                    } else if (data.type == this.SubActivity.DAILY_SIGN_IN) {
                        // 新增月卡签到，屏蔽每日签到
                        this.dailySignInInfo = data;
                    } else if (data.type == this.SubActivity.WEEKLY_CARD) {
                        // 取消老版本周卡在活动中心展示
                        isMoveAct = true;
                    }
                    isMoveAct = false;
                }
            }

            if (!isMoveAct) {
                validActConf.push(data);
            }
        }
        this.activityConf = validActConf;
        this.activityConf.sort((actA, actB) => {
            return actA.sort - actB.sort;
        });

        setTimeout(() => {
            cc.director.emit(CommonEvent.ACTIVITY_DATA_INIT);
            this.updateEventCenter();
        }, 2500);
    }

    public updateEventCenter(): void {
        const redDotData = this.activityConf
            // .filter((item) => {
            //     // 过滤掉每日签到
            //     return item._id !== 115;
            // })
            .map((item) => {
                return {
                    name: item._id,
                    count: this.getNoticeStatus(item) ? 1 : 0,
                };
            })
            .filter((item) => {
                return item.count > 0;
            });

        if (redDotData.length > 0) {
            RedDot.red.quickSetRedDotData(RedDot.cfg.eventCenter, redDotData);
        }
    }

    public getNoticeStatus(config: we.common.IActivityConf): boolean {
        if (!config) {
            return false;
        }

        let showNotice = this.clickRecord.indexOf(config._id) >= 0 ? false : true;

        // 红点皮肤兼容处理
        switch (config.type) {
            case this.SubActivity.DAILY_SIGN_IN:
                // 每日签到
                showNotice = this.dailyFreeAward && !this.dailyFreeAward.isGet;
                if (we.core.flavor.isSkinVertical() || we.core.flavor.getSkinCode() === we.core.SkinCode.cm5) {
                    we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.dailyAward, showNotice == true ? 1 : 0, true);
                    showNotice = false;
                }
                break;
            default:
                break;
        }

        switch (config.jump_position) {
            case JumpCmd.Turntable:
                // 活动转盘
                showNotice = Boolean(TurntableMgr.getTurntableRedCount());
                break;
            case JumpCmd.Month_Sign:
                showNotice = we.common.redDot.red.getRedDotCnt(we.common.redDot.cfg.monthSign) > 0 ? true : false;
                break;
            case JumpCmd.Month_Sign2:
                showNotice = we.common.redDot.red.getRedDotCnt(we.common.redDot.cfg.monthSign2) > 0 ? true : false;
                break;
            case JumpCmd.Rescue_Funds:
                showNotice = we.common.redDot.red.getRedDotCnt(we.common.redDot.cfg.rescueFunds) > 0 ? true : false;
                break;
            default:
                break;
        }

        return showNotice;
    }

    /** 获取大厅Banner */
    public getHallBanner(): ApiProto.BannerConf[] {
        return this.getBannerConfigure(BANNER_TYPE.HALL);
    }

    /**
     * 获取指定界面Banner配置
     * @param type
     * @returns
     */
    private getBannerConfigure(type: BANNER_TYPE): ApiProto.BannerConf[] {
        if (!this.bannerConfig || !Array.isArray(this.bannerConfig.banners) || this.bannerConfig.banners.length < 1) {
            return [];
        }

        let banner = this.bannerConfig.banners;
        banner.sort((a, b) => {
            return a.sort - b.sort;
        });

        let config: ApiProto.BannerConf[] = [];
        banner.forEach((value) => {
            if (value.area == type) {
                config.push(value);
            }
        });

        return config;
    }

    /**
     * 获取日期唯一数字 格式:YYMMDD-211026
     * @param times
     * @returns
     */
    private getSpeDateOfTS(times: number) {
        let date = new Date();
        date.setTime(times);
        let month = date.getMonth() + 1;
        let day = date.getDate();
        let speDate = (date.getFullYear() % 2000) + (month < 10 ? '0' + month : month.toString()) + (day < 10 ? '0' + day : day.toString());

        return parseInt(speDate);
    }

    /**
     * 获取固定活动相关配置
     * @param actType 活动类型
     */
    private getFixActivityConf(actType: number): void {
        switch (actType) {
            case this.SubActivity.DAILY_SIGN_IN:
                this.dataUpdateFlags[this.ActivityType.dailyFreeAward] = false;
                break;
            case this.SubActivity.AGENT:
                // AgentMgr.getAgentRebateConf();
                break;
            default:
                break;
        }
    }

    /**
     * 通过活动类型，获取活动信息
     * @param type 活动类型
     * @returns
     */
    public getActivityByType(type: number): any[] {
        let result = [];
        if (!this.activityConf) {
            return result;
        }

        for (let i = 0; i < this.activityConf.length; i++) {
            if (this.activityConf[i].type == type) {
                result.push(this.activityConf[i]);
            }
        }
        return result;
    }

    /** 获取每日签到奖励配置 */
    public getDailyFreeAwardConf(): Promise<boolean> {
        return new Promise((resolve, reject) => {
            const flag = this.dataUpdateFlags[this.ActivityType.dailyFreeAward];
            if (this.dailyFreeAward && flag !== false) {
                resolve(true);
                return;
            }
            ApiManager.getDailyFreeAwardConf(
                (data: ApiProto.DailyFreeAwardConfResp) => {
                    this.dailyFreeAward = data;
                    this.dataUpdateFlags[this.ActivityType.dailyFreeAward] = true;
                    cc.director.emit(CommonEvent.NOTICE_EVENT_CENTER);
                    this.updateEventCenter();
                    resolve(true);
                },
                (code) => {
                    resolve(false);
                }
            );
        });
    }

    /**
     * 获取首次使用指定app奖励配置
     * @param isShowLoading
     */
    public async getOfficialPkgBonusConf(isShowLoading: boolean = false): Promise<ApiProto.GetBonusConfResp | null> {
        return new Promise((resolve, reject) => {
            ApiManager.getOfficialBagBonusConf(
                (data: ApiProto.GetBonusConfResp) => {
                    this.officialPkgAward = data;
                    cc.director.emit(CommonEvent.UPDATE_OFFICIAL_BAG_AWARD);
                    resolve(data);
                },
                () => {
                    this.officialPkgAward = null;
                    resolve(null);
                },
                isShowLoading
            );
        });
    }

    /**
     * 领取首次使用指定app奖励
     * @param sucCallBack
     * @param errCallback
     * @param isShowLoading
     */
    public getOfficialPkgAward(sucCallBack?: Function, errCallback?: Function, isShowLoading: boolean = true): void {
        ApiManager.getOfficialBagAward(
            (data: ApiProto.ReceiveBonusResp) => {
                sucCallBack?.(data);
            },
            (code) => {
                errCallback?.();
            },
            isShowLoading
        );
    }

    /**
     * 首次使用指定app奖励是否开启
     */
    public getOfficialPkgIsAct(): boolean {
        return !!this.officialPkgAward?.officialAppBonusSwitch;
    }

    /** 刷新充值相关任务 */
    public refreshRechargeTask(): void {
        setTimeout(() => {
            if (!UserManager.isLogin()) {
                return;
            }

            cc.director.emit(CommonEvent.RECHARGE_FINISH);

            // ，每日签到转盘充值任务
            let dailyAward = this.getActivityByType(this.SubActivity.DAILY_SIGN_IN) || [];
            if (dailyAward.length > 0 && !this.dailyFreeAward?.rateWheelConf?.unlocked) {
                this.dataUpdateFlags[this.ActivityType.dailyFreeAward] = false;
            }
            //  每日充值任务
            DailyRechargeMgr.getActivityInfo();
            // 狂欢活动充值任务
            if (CarnivalMgr.isOpenAct() && CarnivalMgr.actInfo?.[this.TaskType.recharge]) {
                CarnivalMgr.getActivityInfo();
            }
            // 独立日活动充值任务
            if (IndependentMgr.isOpenAct()) {
                IndependentMgr.getActivityInfo();
            }
            // 救援金
            if (RescueFundsMgr.getRescueFundsIsAct()) {
                RescueFundsMgr.getUserApplyList();
            }
        }, 1500);
    }

    /**
     * 活动重构后 奖励领取状态 code 处理
     * @param code 领取奖励状态
     */
    public getTaskAwardErrorHandle(code: number): void {
        let langKey = null;
        switch (code) {
            case this.GET_AWARD_CODE.ACTIVITY_CLOSE:
                langKey = CommonLanguage.GET_TASK_AWARD_CODE_2;
                break;
            case this.GET_AWARD_CODE.SERVICE_ERROR:
                langKey = CommonLanguage.GET_TASK_AWARD_CODE_3;
                break;
            case this.GET_AWARD_CODE.REPEAT_DRAW:
                langKey = CommonLanguage.GET_TASK_AWARD_CODE_4;
                break;
            case this.GET_AWARD_CODE.NOT_COMPLETE:
                langKey = CommonLanguage.GET_TASK_AWARD_CODE_5;
                break;
            case this.GET_AWARD_CODE.OTHER:
                langKey = CommonLanguage.GET_TASK_AWARD_CODE_6;
                break;
            default:
                break;
        }

        if (langKey) {
            we.commonUI.showToast(we.core.langMgr.getLangText(langKey));
        }
    }

    /**
     * 按照任务状态排序 完成未领取奖励 > 进行中 > 等待未开始 > 完成已领取奖励
     * @param data
     * @returns
     */
    public sortTask(data: ApiProto.TaskProgressDetail[]): ApiProto.TaskProgressDetail[] {
        let result = [];

        if (data?.length > 0) {
            let completed = [];
            let going = [];
            let wait = [];
            let received = [];
            data.forEach((v) => {
                switch (v.taskStatus) {
                    case this.TaskStatus.WAITING:
                        wait.push(v);
                        break;
                    case this.TaskStatus.ONGOING:
                        going.push(v);
                        break;
                    case this.TaskStatus.COMPLETED:
                        completed.push(v);
                        break;
                    case this.TaskStatus.REWARD_RECEIVED:
                        received.push(v);
                        break;
                    default:
                        break;
                }
            });
            result = [...completed, ...going, ...wait, ...received];
        }

        return result;
    }
}

export default we.common.activityMgr = new ActivityMgr();
