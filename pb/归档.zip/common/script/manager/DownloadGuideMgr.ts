import ApiManager from '../api/ApiManager';
import WithdrawMgr from './WithdrawMgr';

declare global {
    interface ICommon {
        /** 下载引导管理类 */
        downloadGuideMgr: DownloadGuideMgr;
    }
}

class DownloadGuideMgr {
    /** 下载引导类型 */
    public readonly Type = {
        Normal: 0,
        /** 充值 */
        Recharge: 1,
        /** 提现 */
        Withdraw: 2,
    };

    /** 强制引导配置 */
    public forceGuideConf: ApiProto.ForceLeadDownloadRewardResp = null;

    /**
     * 获取下载引导开关信息
     * @param sucCb
     */
    public getDownloadGuideInfo(sucCb?: Function): void {
        ApiManager.getDownloadGuideInfo((data: ApiProto.OfficialUserDetailResp) => {
            sucCb?.(data);
        });
    }

    /**
     * 充值/提现 下载引导配置
     * @param sucCb
     */
    public getDownloadGuideConf(sucCb?: Function) {
        if (!this.isVestAndroid()) {
            return;
        }

        ApiManager.getDownloadGuideConf((data: ApiProto.ForceLeadDownloadRewardResp) => {
            this.syncData(data);
            sucCb?.(data);
        });
    }

    /**
     * 获取下载引导界面 二维码 地址
     * @param data
     * @returns
     */
    public getDownloadQRUrl(data: ApiProto.OfficialUserDetailResp): string {
        let url = '';
        let settingsConfig = we.core.projectConfig.settingsConfig;

        // 如果是代理，则走代理下载地址
        if (settingsConfig.funcSwitch.agentSwitch) {
            url = settingsConfig.officialUrlWithUid == undefined ? '' : settingsConfig.officialUrlWithUid;
        } else {
            url = data.downloadUrl;
        }

        // 拼接必要参数 创建渠道 用户ID
        if (url) {
            let cchn = settingsConfig.cchn;
            let chnData = we.core.utils.base64Encode(cchn);
            let uidData = we.core.utils.base64Encode(data.userId.toString());
            let params = [`chn=${chnData}`, `id=${uidData}`];
            for (let i = 0; i < params.length; i++) {
                let key = params[i].split('=')[0];
                if (url.includes(key + '=')) {
                    continue;
                }
                let oneParams = (url.includes('?') ? '&' : '?') + params[i];
                if (0 === i && url.includes('?')) {
                    oneParams = params[i];
                }
                url = url + oneParams;
            }
        }

        return url;
    }

    /**
     * 组装外跳转 PWA url 需要携带参数
     * @param url
     * @returns
     */
    public getPWAInstallUrl(): string {
        let url = we.core.projectConfig.settingsConfig?.pwaUrl;
        if (!url) {
            we.error(`DownloadGuideMgr getPWAInstallUrl, pwaUrl is null`);
            return '';
        }

        let browserParamKey = [
            we.core.BrowserParamKey.fbpxid,
            we.core.BrowserParamKey.kwpxid,
            we.core.BrowserParamKey.ttpxid,
            we.core.BrowserParamKey.adjid,
            we.core.BrowserParamKey.adjust_referrer,
            we.core.BrowserParamKey.referid,
        ];

        // 隐藏参数携带 we.core.HideBrowserParamKey
        for (let i = 0; i < browserParamKey.length; i++) {
            const urlParam = browserParamKey[i];
            if (url.includes(urlParam + '=')) {
                // 参数重复时跳过
                continue;
            }

            let value = we.core.utils.getLocationUrlParam(urlParam);
            if (value) {
                url = url + (url.includes('?') ? '&' : '?') + `${urlParam}=${value}`;
            }
        }

        // 渠道
        if (!url.includes(we.core.BrowserParamKey.chn)) {
            let base64Chn = we.core.utils.base64Encode(we.core.nativeUtil.getChannel());
            url = url + (url.includes('?') ? '&' : '?') + `${we.core.BrowserParamKey.chn}=${base64Chn}`;
        }

        // pwa 标识
        if (!url.includes(we.core.BrowserParamKey.pwa)) {
            url = url + (url.includes('?') ? '&' : '?') + `${we.core.BrowserParamKey.pwa}=${1}`;
        }

        // 自动登录信息
        let loginInfo = {
            userId: we.common.userMgr.userInfo.userId,
            token: we.common.userMgr.token,
            deviceId: we.core.nativeUtil.getDeviceId(),
        };
        let base64LoginInfo = we.core.utils.base64Encode(JSON.stringify(loginInfo));
        url = url + (url.includes('?') ? '&' : '?') + `${we.core.BrowserParamKey.auth}=${base64LoginInfo}`;

        return url;
    }

    /**
     * 同步 下载引导配置
     * @param data
     */
    public syncData(data: ApiProto.ForceLeadDownloadRewardResp) {
        // 数据空或是马甲包 则不需要同步数据
        if (!data || !this.isVestAndroid()) {
            return;
        }

        this.forceGuideConf = data;

        // 补全 icon 下载地址，方便 UI 层直接使用
        let iconPath = this.forceGuideConf?.downloadGuideQuickJumpIcon;
        if (iconPath) {
            iconPath = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, iconPath);
            this.forceGuideConf.downloadGuideQuickJumpIcon = iconPath;
        }
    }

    /**
     * 是否开启下载引导提示
     * @param type  we.common.downloadGuideMgr.Type
     */
    public isOpenGuide(type: number = this.Type.Normal): boolean {
        if (!this.isVestAndroid()) {
            return false;
        }

        let isOpen = true;
        let isOpenPWA = we.core.projectConfig.settingsConfig.isPwa;
        if (cc.sys.isBrowser && isOpenPWA) {
            let installPWAStatus = we.core.h5PWA.getInstallStatus();
            switch (installPWAStatus) {
                case we.core.PWAInstallStatus.Installed: // 已安装 PWA 不需要下载引导
                    isOpen = false;
                    break;
                case we.core.PWAInstallStatus.NotInstallable:
                    isOpen = !we.isH5PWA;
                    break;
                default:
                    break;
            }

            if (!isOpen) {
                return false;
            }
        }

        switch (type) {
            case this.Type.Recharge: // 充值触发引导
                isOpen = this.forceGuideConf?.forceDownloadRechargeUser;
                break;
            case this.Type.Withdraw: // 提现引导
                {
                    let conf = WithdrawMgr.config;
                    if (conf?.downloadLeadSwitch) {
                        isOpen = conf.downloadLeadCount - conf.userWithdrawCount <= 0;
                    } else {
                        isOpen = false;
                    }
                }
                break;
            default: // 默认引导
                isOpen = this.forceGuideConf?.forceLeadSwitch;
                break;
        }

        return isOpen;
    }

    /**
     * 是否强制下载引导
     */
    public isForceGuide(): boolean {
        if (!this.isVestAndroid()) {
            return false;
        }

        return this.forceGuideConf?.forceDownloadLeadStatus;
    }

    /**
     * 是否显示 apk 下载入口
     * @returns
     */
    public isShowApkDownload(): boolean {
        // 浏览器 非落地页包
        if (cc.sys.isBrowser && !we.core.nativeUtil.isPlatformLand()) {
            // 下载入口显示状态开关
            let show = we.core.projectConfig.settingsConfig.h5HallDownloadButtonSwitch;
            if (!show) {
                return false;
            }

            // 所有苹果设备均 隐藏
            if (cc.sys.os == cc.sys.OS_IOS || we.core.nativeUtil.isPlatformMac()) {
                return false;
            }

            // 判定是否开 PWA 安装，如果开启并切已安装也需要隐藏
            let isOpenPwa = we.core.projectConfig.settingsConfig?.isPwa;
            if (isOpenPwa) {
                let installPWAStatus = we.core.h5PWA.getInstallStatus();
                switch (installPWAStatus) {
                    case we.core.PWAInstallStatus.Installed:
                        show = false;
                        break;
                    case we.core.PWAInstallStatus.NotInstallable:
                        show = !we.isH5PWA;
                        break;
                    default:
                        break;
                }
            }

            return show;
        }

        return false;
    }

    /** 是否显示 ios 收藏引导入口 */
    public isShowIosCollect(): boolean {
        // 浏览器 非落地页包
        if (cc.sys.isBrowser && !we.core.nativeUtil.isPlatformLand()) {
            // 下载入口显示状态开关
            let show = we.core.projectConfig.settingsConfig.h5HallDownloadButtonSwitch;
            if (!show) {
                return false;
            }

            // 所有非苹果设备 隐藏
            if (cc.sys.os == cc.sys.OS_ANDROID || we.core.nativeUtil.isPlatformWindows()) {
                return false;
            }

            // 判定是否开 PWA 安装，如果开启并切已安装也需要隐藏
            let isOpenPwa = we.core.projectConfig.settingsConfig?.isPwa;
            if (isOpenPwa) {
                let installPWAStatus = we.core.h5PWA.getInstallStatus();
                switch (installPWAStatus) {
                    case we.core.PWAInstallStatus.Installed:
                        show = false;
                        break;
                    case we.core.PWAInstallStatus.NotInstallable:
                        show = !we.isH5PWA;
                        break;
                    default:
                        break;
                }
            }

            return show;
        }

        return false;
    }

    /**
     * 是否是 android 马甲包设备或者 windows 设备
     * @returns
     */
    public isVestAndroid(): boolean {
        if (cc.sys.isNative) {
            return false;
        }
        if (we.core.nativeUtil.isPlatformLand()) {
            return false;
        }
        if (we.core.nativeUtil.isPlatformWindows() || we.core.nativeUtil.isPlatformAndroid()) {
            return true;
        }

        return false;
    }

    /**
     * 是否显示 iOS 马甲包或者 mac 设备
     * @returns
     */
    public isVestIos(): boolean {
        if (cc.sys.isNative) {
            return false;
        }
        if (we.core.nativeUtil.isPlatformLand()) {
            return false;
        }
        if (we.core.nativeUtil.isPlatformIos() || we.core.nativeUtil.isPlatformMac()) {
            return true;
        }

        return false;
    }
}

export default we.common.downloadGuideMgr = new DownloadGuideMgr();
