import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 每日累充活动 管理类 */
        dailyRechargeMgr: DailyRechargeMgr;
    }
}

interface IDailyRechargeData extends ApiProto.RechargeTaskProgressResp {
    /** 上一次请求数据时间戳 ms */
    lastTs: number;
    /** 配置接口正在请求数据 */
    requesting: boolean;
}

class DailyRechargeMgr {
    /** 每日累冲活动 数据 */
    public actInfo: IDailyRechargeData = null;

    public init(): void {
        this.actInfo = null;
    }

    /**
     * 是否开启 每日充值活动
     * @returns
     */
    public isOpenAct(): boolean {
        if (this.actInfo) {
            let curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
            if (this.actInfo.startTime <= curTime && this.actInfo.endTime > curTime) {
                return true;
            }
        }

        return false;
    }

    /**
     * 每日累充数据
     * @param errCb
     * @param showLoading
     */
    public getActivityInfo(errCb?: Function, showLoading: boolean = false): Promise<void> {
        return new Promise((resolve, reject) => {
            if (this.actInfo) {
                if (new Date().getTime() - this.actInfo.lastTs < 5 * 1000) {
                    resolve();
                    return;
                }
            } else {
                this.actInfo = {} as IDailyRechargeData;
            }

            if (this.actInfo.requesting) {
                resolve();
                return;
            }
            this.actInfo.requesting = true;

            ApiManager.getDailyRechargeInfo(
                (data: ApiProto.RechargeTaskProgressResp) => {
                    this.syncData(data);

                    cc.director.emit(CommonEvent.HALL_POPUP_QUEUE_UPDATE);
                    resolve();
                },
                (code) => {
                    this.actInfo.lastTs = 0;
                    this.actInfo.requesting = false;
                    errCb?.(code);
                    reject(code);
                },
                showLoading
            );
        });
    }

    /**
     * 同步活动数据
     * @param data
     * @returns
     */
    public syncData(data: ApiProto.RechargeTaskProgressResp): void {
        if (!data || !UserManager.isLogin()) {
            return;
        }

        this.actInfo = data as IDailyRechargeData;
        this.actInfo.lastTs = new Date().getTime();
        this.actInfo.requesting = false;
        this.syncRedDotData();

        // 对数据排序
        let list = we.common.dailyRechargeMgr.actInfo.recharge || [];
        we.common.dailyRechargeMgr.actInfo.recharge = list.sort((a, b) => {
            return a.level - b.level;
        });

        cc.director.emit(CommonEvent.UPDATE_DAILY_RECHARGE);
    }

    /**
     * 同步红点数据
     * 该活动红点计算方式比较特别，存在 已完成奖励未领取 和 进行中任务 都会提示红点数
     */
    private syncRedDotData(): void {
        let redAmount = 0;
        if (this.actInfo) {
            let taskList = this.actInfo.recharge || [];
            taskList = taskList.filter((item) => {
                return item.taskStatus == we.common.activityMgr.TaskStatus.COMPLETED || item.taskStatus == we.common.activityMgr.TaskStatus.ONGOING;
            });

            redAmount = taskList.length;
        }

        we.common.redDot.red.updateRedDotCnt(we.common.redDot.cfg.dailyRecharge, redAmount, true);
    }

    /**
     * 计算回回报率比例
     * @returns {string}
     */
    public computeRation(): string {
        let result = '+0%';

        if (this.actInfo) {
            let taskList = this.actInfo.recharge || [];
            let maxTargetScore = 0;
            let allReward = 0;

            for (let i = 0; i < taskList.length; i++) {
                let award = taskList[i].reward;
                allReward += award;

                if (taskList[i].target > maxTargetScore) {
                    maxTargetScore = taskList[i].target;
                }
            }

            if (taskList.length > 0 && maxTargetScore > 0 && allReward > 0) {
                // 百分比显示并保留两位小数
                result = '+' + Math.round((allReward / we.common.utils.priceToAmount(maxTargetScore)) * 100 * 100) / 100 + '%';
            }
        }

        return result;
    }
}

export default we.common.dailyRechargeMgr = new DailyRechargeMgr();
