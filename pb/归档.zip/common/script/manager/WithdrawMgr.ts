import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 提现 管理类 */
        withdrawMgr: WithdrawMgr;
    }
}

interface IWithdrawConf extends ApiProto.WithdrawInfoQueryResp {
    timestamp: number;
}

interface IWithdrawSupportChannel extends ApiProto.ConfWithDrawTypeResp {
    timestamp: number;
}

class WithdrawMgr {
    /** 基础配置请求锁，防止频繁请求 */
    public configReqLock: boolean = false;

    /** 选择提现渠道账号信息 */
    public selectAccountInfo: ApiProto.UserBankInfo = null;
    /** 提现配置 */
    public config: IWithdrawConf = null;
    /** 提现渠道 */
    public supportChannel: IWithdrawSupportChannel = null;
    /** 可用提现账号 */
    public accountList: ApiProto.WithdrawAccountInfo[] = [];
    /** 提现区间支持最小值 金币 */
    public minRangNum: number = 0;
    /** 提现区间支持最大值 金币 */
    public maxRangNum: number = 0;
    /** 开启 VIP 提现通道 */
    public openVipChn: boolean = false;
    /** 开启普通提现通道 */
    public openNormalChn: boolean = false;

    /** 提现播报 */
    public recordEachPageCount = 10;
    /** 提现播报 */
    public broadArray: ApiProto.BankWithdrawBroadItem[] = [];

    /** 提现分类 */
    public WithdrawType = {
        /** 普通 */
        Normal: 1,
        /** vip */
        Vip: 2,
    };

    /** 绑卡验证token */
    public bindCardToken: string = '';

    public bindCardTokenType = cc.Enum({
        /** 绑定银行卡 */
        bindCard: 'withdraw_bind_bank_card',
    });

    public init(): void {
        this.configReqLock = false;
        this.config = null;
        this.supportChannel = null;
        this.accountList = [];
        this.openVipChn = false;
        this.openNormalChn = false;
        this.selectAccountInfo = null;

        this.getBankWithdrawConf();
    }

    /**
     * 获取提现配置
     * @returns
     */
    public getBankWithdrawConf(): void {
        if (this.configReqLock) {
            return;
        }

        if (this.config) {
            let timeOffset = new Date().getTime() - this.config.timestamp;
            if (timeOffset < 2 * 1000) {
                return;
            }
        }

        this.configReqLock = true;
        ApiManager.getBankWithdrawConf(
            (data: ApiProto.WithdrawInfoQueryResp) => {
                this.config = data as IWithdrawConf;
                this.config.timestamp = new Date().getTime();

                // 兜底处理，非法配置，处理配置为 1
                if (this.config.minWithdrawUnit <= 0) {
                    this.config.minWithdrawUnit = 1;
                }

                // 防止每次拉取数据刷新客户端临时选中提现方式
                if (!this.selectAccountInfo) {
                    this.selectAccountInfo = data.lastUse;
                }

                // 获取提现渠道，判断是否展示入口
                this.getWithdrawChannel(() => {
                    let showEntry = this.judgeIsShowWithdraw();
                    if (showEntry) {
                        cc.director.emit(CommonEvent.WITHDRAW_UPDATE_BET_NUM);
                        cc.director.emit(CommonEvent.WITHDRAW_UPDATE_VIEW);
                    }
                });

                this.configReqLock = false;
            },
            () => {
                this.configReqLock = false;
            }
        );
    }

    /**
     * 提现通道，服务器与支付接偶所以单独提现渠道接口
     * @param sucCb
     * @returns
     */
    public getWithdrawChannel(sucCb?: Function): void {
        if (this.supportChannel) {
            let timeOffset = new Date().getTime() - this.supportChannel.timestamp;
            if (timeOffset < 2 * 1000) {
                sucCb?.();
                return;
            }
        }

        ApiManager.getWithdrawChannel((data: ApiProto.ConfWithDrawTypeResp) => {
            this.supportChannel = data as IWithdrawSupportChannel;
            this.supportChannel.timestamp = new Date().getTime();
            this.openVipChn = data.vipWithdrawState;
            this.openNormalChn = data.normalWithdrawState;
            this.sortSupportChannel();
            this.formatAccountData();

            sucCb?.();
            cc.director.emit(CommonEvent.WITHDRAW_UPDATE_VIEW);
        });
    }

    /**
     * 获取提现记录
     * @param data
     * @param sucCb
     * @param errCb
     */
    public getBankWithdrawRecord(data: ApiProto.BankWithdrawRecordReq, sucCb?: Function, errCb?: Function): void {
        ApiManager.getBankWithdrawRecord(
            data,
            (data: ApiProto.BankWithdrawRecordResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            },
            true
        );
    }

    /**
     * 获取提现播报记录
     * @param sucCb
     * @param errCb
     */
    public getWithdrawBroad(sucCb?: Function, errCb?: Function): void {
        ApiManager.getWithdrawBroad(
            (data: ApiProto.BankWithdrawBroadResp) => {
                this.broadArray = data.items || [];
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 发起提现
     * @param data
     * @param sucCb
     * @param errCb
     */
    public sendWithdrawReq(data: ApiProto.UserBankWithdrawReq, sucCb?: Function, errCb?: Function): void {
        ApiManager.sendWithdrawReq(
            data,
            (data: ApiProto.UserBankWithdrawResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 修改提现卡号绑定信息
     * @param sucCb
     * @param errCb
     */
    public modifyWithdrawBindInfo(data: ApiProto.UserBankWithdrawUpdateReq, sucCb?: Function, errCb?: Function): void {
        ApiManager.modifyWithdrawBindInfo(
            data,
            (data: ApiProto.UserBankWithdrawUpdateResp) => {
                sucCb?.(data);
            },
            (code: number) => {
                if ([we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1029, we.common.httpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1030].includes(code)) {
                    this.bindCardToken = '';
                }
                errCb?.(code);
            }
        );
    }

    /**
     * 提现 确认收款
     * @param orderId
     * @param sucCb
     * @param errCb
     */
    public vipWithdrawReceivedReq(orderId: string, sucCb: Function, errCb: Function) {
        let param = {} as ApiProto.VIPWithdrawReceivedReq;
        param.orderId = orderId;
        ApiManager.vipWithdrawReceivedReq(
            param,
            (data: ApiProto.VIPWithdrawReceivedResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 提现 未收款
     * @param orderId
     * @param sucCb
     * @param errCb
     */
    public vipWithdrawNotReceivedReq(orderId: string, sucCb: Function, errCb: Function) {
        let param = {} as ApiProto.VIPWithdrawNotReceivedReq;
        param.orderId = orderId;
        ApiManager.vipWithdrawNotReceivedReq(
            param,
            (data: ApiProto.VIPWithdrawNotReceivedResp) => {
                sucCb?.(data);
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 通过 channel_code 获取提现渠道支持的详细信息
     * @param channelCode
     * @returns
     */
    public getChannelInfoByCode(channelCode: string): ApiProto.WithDrawTypeList {
        let info: ApiProto.WithDrawTypeList = null;
        if (!channelCode) {
            return info;
        }

        let supportChannel = this.supportChannel?.withDrawType || [];
        for (let i = 0; i < supportChannel.length; i++) {
            const element = supportChannel[i];
            if (element.channelCode == channelCode) {
                info = element;
                break;
            }
        }

        return info;
    }

    /**
     * 获取默认绑定账户信息
     * @returns
     */
    public getNormalAccountInfo(): ApiProto.UserBankInfo {
        if (this.supportChannel?.withDrawType?.length < 1) {
            return;
        }
        if (this.accountList.length < 1) {
            return;
        }

        let bindInfo: ApiProto.UserBankInfo = null;
        let withDrawTypeList = this.getChannelInfoByCode(this.selectAccountInfo?.channelCode);
        // 不为空 表明上次使用提现渠道还存在
        if (withDrawTypeList) {
            bindInfo = this.selectAccountInfo;
        } else {
            // 上次默认账号不能使用或者为空时，从已有支持账号中选取
            for (let i = 0; i < this.accountList.length; i++) {
                const element = this.accountList[i];
                withDrawTypeList = this.getChannelInfoByCode(element.info?.channelCode);
                if (withDrawTypeList) {
                    bindInfo = element.info;
                    break;
                }
            }
        }

        we.common.withdrawMgr.selectAccountInfo = bindInfo;

        return bindInfo;
    }

    /**
     * 获取最大能够提现金币数量
     * @returns
     */
    public getCanWithdrawAmount(): number {
        let amount = 0;
        if (this.config) {
            let canOperationAmount = we.common.userMgr.userInfo.gold - this.config.remain;
            amount = canOperationAmount <= 0 ? 0 : Math.floor(canOperationAmount / this.config.minWithdrawUnit) * this.config.minWithdrawUnit;
            if (amount > this.maxRangNum) {
                amount = this.maxRangNum;
            }

            if (amount < this.minRangNum) {
                amount = 0;
            }
        } else {
            we.warn(`WithdrawMgr getCanWithdrawAmount, Withdraw conf is null`);
        }

        return amount;
    }

    /**
     * 根据选择提现渠道，获取渠道支持快捷额度
     * @param channelCode
     * @returns
     */
    public geFastSupportAmounts(channelCode: string): number[] {
        let minNum = this.config?.withdrawLower || 0;
        let maxNum = this.config?.withdrawUpper || 0;
        let info = this.getChannelInfoByCode(channelCode);
        if (info) {
            minNum = Math.max(minNum, we.common.utils.priceToAmount(info.minAmount));
            maxNum = Math.min(maxNum, we.common.utils.priceToAmount(info.maxAmount));
        }

        let supportAmounts = [];
        let amounts = this.config?.amounts || [];
        for (let i = 0; i < amounts.length; i++) {
            let amount = amounts[i];
            if (amount >= minNum && amount <= maxNum) {
                supportAmounts.push(amount);
            }
        }
        supportAmounts.sort((a, b) => {
            return a - b;
        });

        return supportAmounts;
    }

    /**
     * 判定提现入口是否显示
     * @returns
     */
    public judgeIsShowWithdraw(): boolean {
        let showEntry = false;
        if (we.core.projectConfig.settingsConfig && this.config) {
            let switchCtr = we.core.projectConfig.settingsConfig.funcSwitch?.withdrawSwitch; // 提现总开关
            let isBlack = this.config.isBlack; // 提现黑名单
            if (switchCtr && !isBlack) {
                let guestShowCtr = we.core.projectConfig.settingsConfig.funcSwitch?.guestShowWithdraw; // 游客可见开关
                showEntry = guestShowCtr || 1 === UserManager.userInfo.isFormal;
            }
        }
        if (!this.openNormalChn && !this.openVipChn) {
            // 全部提现通道已关闭
            showEntry = false;
        }

        cc.director.emit(CommonEvent.HALL_IS_SHOW_WITHDRAW, showEntry);

        return showEntry;
    }

    /**
     * 判断是否能够参加首次提现活动
     * @returns
     */
    public judgeEnableWithdrawAc(): boolean {
        let enable = false;
        if (this.config) {
            // activityStatus 0-未参与提现活动; 1-提现活动进行中; 2-已参与提现活动; 3-活动未开启
            // 0-表示有提现免手续费次数并且没有参与提现免手续费订单
            // 1-表示有提现免手续费订单进行中
            // 2-表示玩提现免手续费活动开启并且免费提现次数已使用完
            // 3-表示提现免手续费活动未开启
            enable = this.config.activityStatus == 0 && this.config.activityParticipationLimit > 0;
        }

        return enable;
    }

    /**
     * 判断是否能够提现，仅判断提现次数，提现保留金，提现每日数量限制
     * @param amount 提现数量
     * @returns
     */
    public judgeEnableWithdraw(amount: number = 0): boolean {
        let conf = this.config;
        if (conf) {
            // 当日剩余提现次数<=0
            if (conf.dailyWithdrawTimeLimit <= conf.dailyWithdrawTime) {
                return false;
            }
            // 玩家拥有金币 >= 最小提现限制+保留金
            let minAmount = this.minRangNum + conf.remain;
            minAmount = amount + conf.remain > minAmount ? amount + conf.remain : minAmount;
            if (UserManager.userInfo.gold < minAmount) {
                return false;
            }
            // 可以用于提现的金币 < 单日最小提现额度
            if (conf.dailyWithdrawAmountLimit - conf.dailyWithdrawNum < minAmount) {
                return false;
            }
        }

        return true;
    }

    /**
     * 判断是否能绑定新账号
     * @param channelCode
     * @returns
     */
    public judgeEnableNewAccount(channelCode: string): boolean {
        let enable = false;
        if (!channelCode) {
            return enable;
        }
        if (this.supportChannel?.withDrawType?.length < 1) {
            return enable;
        }

        let count = 0;
        let accounts = this.config?.infos || [];
        for (let i = 0; i < accounts.length; i++) {
            const account = accounts[i];
            if (account.info.channelCode == channelCode) {
                count++;
            }
        }

        let conf = this.getChannelInfoByCode(channelCode);
        if (conf) {
            enable = count < conf?.bindCount;
        }

        return enable;
    }

    /**
     * 计算提现需要收取手续费
     * @param amount 提现数量
     * @returns
     */
    public calculateWithdrawFee(amount: number): number {
        if (!(typeof amount == 'number') || amount < 0) {
            return 0;
        }

        // 满足以下条件 不收取提现手续费
        // 1.存在首提活动次数
        // 2.提现金额大于等于参与活动门槛数值
        if (this.judgeEnableWithdrawAc() && amount >= this.config?.activityMinWithDraw) {
            return 0;
        }

        let free: number = 0;
        let conf = this.config;
        if (!conf) {
            return free;
        }

        let calculateFee = (num: number) => {
            let result: number = 0;
            // 最低手续费触发条件，>= 配置数值直接收取固定手续费
            if (num > conf.minFeeCondition) {
                result = Math.floor(num * (conf.rate / 10000));
                result = Math.max(result, conf.minFee);
            } else {
                result = conf.minFee;
            }

            return result;
        };

        // 开启大额免手续费
        if (conf.freeFeeSwitch) {
            if (amount < conf.freeFeeAmount) {
                free = calculateFee(amount);
            }
        } else {
            free = calculateFee(amount);
        }

        return free;
    }

    public onNewBroadArrived(data): void {
        this.broadArray = this.broadArray.slice(0, 19);
        let newDate = {
            userId: data.user_id,
            userName: data.user_name,
            money: data.money,
            currency: data.currency,
            finishTime: data.finish_time,
            costTime: data.cost_time,
        };
        this.broadArray.unshift(newDate);
        this.broadArray = this.broadArray.sort((a: ApiProto.BankWithdrawBroadItem, b: ApiProto.BankWithdrawBroadItem) => {
            return b.finishTime - a.finishTime;
        });
        cc.director.emit(CommonEvent.WITHDRAW_BROAD, newDate);
    }

    /**
     * 更新临时缓存中提现账号信息
     * @param data
     * @param oldData 更新前账号信息
     */
    public updateAccountInfo(data: ApiProto.UserBankInfo, oldData: ApiProto.UserBankInfo): void {
        if (!this.config) {
            return;
        }

        if (!data) {
            we.warn(`WithdrawMgr updateBindInfo, data is null`);
            return;
        }

        let supportChannel = this.supportChannel.withDrawType || [];
        for (let i = 0; i < supportChannel?.length; i++) {
            const e = supportChannel[i];
            if (e.channelCode == data.channelCode && e.code == data.channelType) {
                let tempData = {} as ApiProto.WithdrawAccountInfo;
                tempData.info = data;
                tempData.channelLimitAmount = e.channelLimitAmount;
                tempData.channelUseAmount = e.channelUseAmount;

                if (oldData) {
                    // 更新当前选中账号信息
                    if (this.selectAccountInfo?.account == oldData.account && this.selectAccountInfo?.channelType == oldData.channelType) {
                        this.selectAccountInfo = data;
                    }

                    // 更新缓存中账号信息
                    let accounts = this.config.infos || [];
                    for (let i = 0; i < accounts.length; i++) {
                        let account = accounts[i];
                        if (account.info?.account == oldData.account && account.info?.channelType == oldData.channelType) {
                            accounts[i].info = data;
                            break;
                        }
                    }
                } else {
                    // 新增新账号配置至缓存
                    this.config.infos.push(tempData);
                }
                break;
            }
        }

        this.formatAccountData();
    }

    /**
     * 格式化银行卡号
     * @param accountStr 银行账号
     * @param places 分割位数
     * @returns
     */
    public formatBankAccount(accountStr: string, places: number = 4): string {
        if (!accountStr) {
            return '';
        }

        let str: string = accountStr.replace(/\s*/g, '');
        let strArr = [];
        for (let i = 0; i < Math.ceil(str.length / places); i++) {
            strArr.push(str.substring(i * places, i * places + places));
        }
        str = strArr.join(' ');

        return str;
    }

    /**
     * 更新提现支持区间
     * @param data
     * @returns
     */
    public updateSupportRange(data: ApiProto.UserBankInfo): void {
        if (!this.config) {
            return;
        }

        this.minRangNum = this.config.withdrawLower;
        this.maxRangNum = this.config.withdrawUpper;

        let conf = this.getChannelInfoByCode(data?.channelCode);
        if (!conf) {
            return;
        }

        this.maxRangNum = Math.min(this.maxRangNum, we.common.utils.priceToAmount(conf.maxAmount));
        // 根据选择提现渠道，取提现渠道支持交集
        let openWithdrawAct = this.judgeEnableWithdrawAc();
        let chnMin = we.common.utils.priceToAmount(conf.minAmount);
        if (!openWithdrawAct) {
            this.minRangNum = Math.max(this.minRangNum, chnMin);
            return;
        }

        // 判定 提现活动配置数值 >= 渠道支持最小额度 结果 A
        // 结果 A false: 取值 渠道支持最小额度和提现最低下限 取大
        // 结果 A true: 判定 提现活动配置数值 >= 提现最低下限 结果 B
        // 结果 B false: 取值 提现活动配置数值
        // 结果 B true: 取值 渠道支持最小额度和提现最低下限 取大
        if (this.config.activityMinWithDraw >= chnMin) {
            if (this.config.activityMinWithDraw >= this.config.withdrawLower) {
                this.minRangNum = Math.max(chnMin, this.config.withdrawLower);
            } else {
                this.minRangNum = this.config.activityMinWithDraw;
            }
        } else {
            this.minRangNum = Math.max(chnMin, this.config.withdrawLower);
        }
    }

    /**
     * 提现支持渠道排序，根据推荐标识默认排序
     * 初始化是否开启 vip 提现通道赋值
     * @returns
     */
    private sortSupportChannel(): void {
        let supportChannel = this.supportChannel?.withDrawType || [];
        if (supportChannel.length < 1) {
            return;
        }

        let recommendChn = [];
        let normalChn = [];
        for (let i = 0; i < supportChannel.length; i++) {
            let element = supportChannel[i];
            if (element.tag) {
                recommendChn.push(element);
            } else {
                normalChn.push(element);
            }
        }

        this.supportChannel.withDrawType = recommendChn.concat(normalChn).sort((item1, item2) => {
            if (item1.withdrawTypeSort === item2.withdrawTypeSort) {
                return item1.withdrawBankSort - item2.withdrawBankSort;
            } else {
                return item1.withdrawTypeSort - item2.withdrawTypeSort;
            }
        });
    }

    /**
     * 格式化已绑定提现账号，不支持方式屏蔽并排序
     *
     * 排序规则
     * 1.正在使用账号排在最前
     * 2.未使用账号按照添加顺序排列
     * @returns
     */
    public formatAccountData(): void {
        let infos = this.config?.infos;
        if (!infos) {
            return;
        }

        let support = [];
        for (let i = 0; i < infos.length; i++) {
            let bindInfo = infos[i];
            let supportChannel = this.getChannelInfoByCode(bindInfo.info.channelCode);
            if (supportChannel && supportChannel.code == bindInfo.info.channelType) {
                support.push(bindInfo);
            }
        }
        this.accountList = support;

        // 排序
        this.accountList.reverse();
        if (this.selectAccountInfo) {
            for (let i = 0; i < this.accountList.length; i++) {
                const e = this.accountList[i];
                if (e.info?.account == this.selectAccountInfo.account && e.info?.channelType == this.selectAccountInfo.channelType) {
                    this.accountList.splice(i, 1);
                    this.accountList = [e, ...this.accountList];
                    break;
                }
            }
        }
    }

    /**
     * 专用
     * @param cardStr
     * @returns
     */
    public formatBankCardNum(cardStr: string): string {
        let str = '******';
        if (typeof cardStr == 'string' && cardStr.length > 0) {
            let length = cardStr.length;
            // 1. 字符数：1-3，显示最后一位，其余隐藏，如只有1位，则全部隐藏
            // 2. 字符数：4-6，显示前1后1，隐藏中间字符
            // 3. 字符数：7-9，显示前2后2，隐藏中间字符
            // 4. 字符数大于9，显示前3后3，隐藏中间字符
            let frontLen = 0;
            let afterLen = 0;
            if (length <= 3) {
                afterLen = length == 1 ? 0 : 1;
            } else if (length > 3 && length <= 6) {
                frontLen = 1;
                afterLen = frontLen;
            } else if (length > 6 && length <= 9) {
                frontLen = 2;
                afterLen = frontLen;
            } else if (length > 9) {
                frontLen = 3;
                afterLen = frontLen;
            }

            str = (frontLen > 0 ? cardStr.slice(0, frontLen) : '') + '******' + (afterLen > 0 ? cardStr.slice(-afterLen) : '');
        } else {
            we.warn(`WithdrawMgr formatBankCardNum, param is null`);
        }

        return str;
    }

    /**
     * 提现专用 格式化快捷金币
     * @param amount 金币数
     * @param useSymbol 使用货币符号 默认: true
     * @param useAbbr 使用缩写 默认:true
     * @param decimalPlace 保留小数点位数 默认: 与当前所在地区一致
     * @param useComma 是否使用逗号 默认: true
     * @returns
     */
    public formatAmount(amount: number, useSymbol: boolean = true, useAbbr: boolean = true, decimalPlace: number = we.core.flavor.getDecimalPlace(), useComma: boolean = true): string {
        if (typeof amount != 'number' && isNaN(amount)) {
            we.warn('WithdrawMgr formatAmount, params is invalid');
            return '';
        }

        let symbol = useSymbol ? we.core.flavor.getCurrencySymbol() : '';
        decimalPlace = typeof decimalPlace == 'number' && !isNaN(decimalPlace) ? Math.abs(decimalPlace) : 0;

        let precision = we.core.flavor.getAmountPrecision();
        let amountReal = Math.abs(amount) / precision;

        let unit = '';
        if (useAbbr) {
            let unitDivisor = 1;
            if (amountReal >= 1_000_000) {
                // 百万
                unit = 'K';
                unitDivisor = 1_000;
            }

            // 缩写单位保留小数位数和国家无关，固定 3 位
            let decimalUnit = 3;
            amountReal = amountReal / unitDivisor;
            amountReal = parseFloat(amountReal.toFixed(decimalUnit));
        }

        let strNum = amountReal.toString();
        let str = symbol + (useComma ? we.common.utils.formatComma(strNum) : strNum) + unit;
        return str;
    }

    /**
     * 检查账号是否合法
     * @param type 渠道类型
     * @param account 账号
     * @returns
     */
    public checkAccountFormat(type: number, account: string): boolean {
        let valid = false;
        let patten: RegExp = null;
        switch (type) {
            case we.common.payMgr.PAY_TYPE.EB_PAY:
                // EB_PAY 账号长度 10-40
                patten = /^[A-Za-z0-9]{10,40}$/;
                break;
            case we.common.payMgr.PAY_TYPE.MT_PAY:
                // MT_PAY 账号长度 12
                patten = /^[A-Za-z0-9]{12}$/;
                break;
            default:
                break;
        }

        if (patten) {
            valid = patten.test(account);
        }

        return valid;
    }
}

export default we.common.withdrawMgr = new WithdrawMgr();
