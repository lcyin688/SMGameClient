import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import { CommonLanguage } from '../const/CommonLanguage';
import { CommonViewId } from '../view/CommonViewId';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 商城模块 */
        storeMgr: StoreMgr;
    }
}

interface OrderRecord {
    /** 上次请求时间 */
    lastTime: number;
    /** 订单记录信息 */
    orderRecordInfo: ApiProto.GetOrderListResp;
}

interface NewbieGift {
    gbData: ApiProto.FirstRechargeConfResp;
    ptData: ApiProto.payTypeResp;
}

class StoreMgr {
    /** 商城商品 id 不可修改 不可修改 不可修改 */
    public readonly goodsId: string = 'waka_common_goods';
    /** 商城配置 */
    public shopConf: ApiProto.ShopConfResp = null;
    /** 上次订单记录 */
    public orderRecordInfo: OrderRecord = null;
    /** 新手礼包是否开启 */
    public isNewbieGift = false;
    /** 新手礼包数据 */
    public newbieGift: NewbieGift = { gbData: null, ptData: null };
    /** 预填值 */
    public prefillAmount = 0;

    public init(): void {
        this.shopConf = null;
        this.orderRecordInfo = null;
        this.isNewbieGift = false;
        this.newbieGift = { gbData: null, ptData: null };
    }

    /**
     * 获取商城商品配置
     * @param isVipShop
     * @param sucCallBack
     * @param errCallback
     */
    public getShopConfig(sucCallBack: Function = null, errCallback: Function = null, showLoading: boolean = true): void {
        ApiManager.getShopConfig(
            false,
            (data: ApiProto.ShopConfResp) => {
                // 按照sort排序 从小到打
                data.rechargeTypeCategory = (data.rechargeTypeCategory || []).sort((a, b) => {
                    return a.sort - b.sort;
                });

                this.shopConf = data;
                typeof sucCallBack == 'function' && sucCallBack(data);
            },
            (code) => {
                typeof errCallback == 'function' && errCallback();
            },
            showLoading
        );
    }

    /**
     * 新手礼包
     * @param func
     * @param showLoading
     */
    public initNewbieGiftBag(func?: Function, showLoading: boolean = false): Promise<void> {
        return new Promise((resolve, reject) => {
            ApiManager.getNewbieGiftBagCfg(
                (data: ApiProto.FirstRechargeConfResp) => {
                    if (!UserManager.isLogin()) {
                        return;
                    }

                    this.updateNewbieGiftBag(data);
                    if (!data.isBuy) {
                        func?.();
                    }
                    resolve();
                },
                (code) => {
                    reject(code);
                },
                showLoading
            );
        });
    }

    /**
     * 更新新手礼包数据
     * @param data
     */
    public updateNewbieGiftBag(data: ApiProto.FirstRechargeConfResp): void {
        this.newbieGift.gbData = data;
        this.isNewbieGift = data.switch && !data.isBuy;

        // 活动未开启
        if (!this.isNewbieGift) {
            cc.director.emit(we.common.EventName.CLOSE_FIRST_RECHARGE_DIALOG);
        } else {
            cc.director.emit(CommonEvent.HALL_POPUP_QUEUE_UPDATE);
        }
        cc.director.emit(CommonEvent.GIFT_BAG_UPDATE);
    }

    /** 获取充值订单记录 */
    public getOrderList(sucCallBack: Function = null, errCallback: Function = null): void {
        if (this.orderRecordInfo) {
            let curDate = new Date().getTime();
            if (curDate - this.orderRecordInfo.lastTime <= 3000) {
                typeof sucCallBack == 'function' && sucCallBack(this.orderRecordInfo.orderRecordInfo);
                return;
            }
        } else {
            this.orderRecordInfo = {} as OrderRecord;
        }

        ApiManager.getOrderListReq(
            (data: ApiProto.GetOrderListResp) => {
                this.orderRecordInfo.lastTime = new Date().getTime();
                this.orderRecordInfo.orderRecordInfo = data;

                typeof sucCallBack == 'function' && sucCallBack(data);
            },
            (code) => {
                typeof errCallback == 'function' && errCallback();
            }
        );
    }

    /**
     * 获取商城支付类型配置
     * @param payType 支付类型
     */
    public getPayChannelConf(payType: number): ApiProto.RechargeTypeCategory {
        let conf: ApiProto.RechargeTypeCategory = null;
        if (this.shopConf) {
            let payChannel = this.shopConf.rechargeTypeCategory || [];
            for (let i = 0; i < payChannel.length; i++) {
                if (payChannel[i].payType == payType) {
                    conf = payChannel[i];
                    break;
                }
            }
        }

        return conf;
    }

    /**
     * 下订单前检查
     * @param sucCb
     * @param errCb
     */
    public CheckOrder(sucCb: Function, errCb?: Function) {
        ApiManager.checkOrderReq(
            (data: ApiProto.CheckOrderResp) => {
                if (data.isSupport) {
                    sucCb?.();
                } else {
                    we.commonUI.showConfirm({
                        content: we.core.langMgr.getLangText(CommonLanguage.RECHARGE_TIPS_001),
                        yesButtonName: we.core.langMgr.getLangText(we.launcher.lang.NEW_HALL_TOP_SERVICE),
                        yesHandler: we.core.Func.create(() => {
                            we.common.commonMgr.openCustomerDialog();
                        }, this),
                        noButtonName: we.core.langMgr.getLangText(CommonLanguage.RECHARGE_BTN_002),
                        noHandler: we.core.Func.create(() => {
                            sucCb?.();
                        }, this),
                    });
                }
            },
            (code) => {
                errCb?.(code);
            }
        );
    }

    /**
     * 充值专用 格式化价格
     * @param price 价格
     * @param useSymbol 使用货币单位
     * @param useAbbr 缩写
     * @param useComma
     * @returns
     */
    public formatPrice(price: number, useSymbol: boolean = true, useAbbr: boolean = false, useComma: boolean = true): string {
        if (typeof price != 'number' && isNaN(price)) {
            we.warn('StoreMgr formatPrice, params is error');
            return '';
        }

        let symbol = useSymbol ? we.core.flavor.getCurrencySymbol() : '';

        let precision = we.core.flavor.getPricePrecision();
        let amountReal = Math.abs(price) / precision;

        // 真实数量根据地区保留 amount 小数位配置保留小数位
        let decimalPlace = we.core.flavor.getDecimalPlace();
        amountReal = parseFloat(amountReal.toFixed(decimalPlace));

        let unit = '';
        if (useAbbr) {
            let unitDivisor = 1;
            if (amountReal >= 1_000_000) {
                // 百万
                unit = 'K';
                unitDivisor = 1_000;
            }

            // 缩写单位保留小数位数和国家无关，固定 3 位
            let decimalUnit = 3;
            amountReal = amountReal / unitDivisor;
            amountReal = parseFloat(amountReal.toFixed(decimalUnit));
        }

        let strNum = amountReal.toString();
        let str = symbol + (useComma ? we.common.utils.formatComma(strNum) : strNum) + unit;
        return str;
    }

    /**
     * 获取 实际到账 与 手续费描述
     * @param amount 价格
     * @param channelConf
     * @returns
     */
    public getScratchCardsFees(amount: number, channelConf: ApiProto.RechargeTypeCategory): { realAmount: number; feesDesc: string } {
        let realAmount = amount;
        let feesDesc = '';
        // 万分比手续费
        const feesRate = channelConf.feeRate;
        if (feesRate && feesRate > 0) {
            feesDesc += `${feesRate / 100}% + `;
            realAmount = Math.max(realAmount - Math.ceil((amount * feesRate) / 10000), 0);
        }
        // 固定手续费
        const fixFees = channelConf.feeAmount;
        if (fixFees && fixFees > 0) {
            feesDesc += `${we.common.utils.formatPrice(fixFees, true, false)}`;
            realAmount = Math.max(realAmount - fixFees, 0);
        } else if (feesRate && feesRate > 0) {
            feesDesc = `${feesRate / 100}%`;
        }

        if (we.core.flavor.getCountryCode() === we.core.CountryCode.id) {
            // id取整
            realAmount = Math.floor(realAmount / we.core.flavor.getPricePrecision()) * we.core.flavor.getPricePrecision();
        }

        return { realAmount, feesDesc };
    }

    /**
     * 计算当前价格比比送金额
     * @param amountScale
     * @returns
     */
    public getGiveAwayAmountScale(amount: number, payInfo: ApiProto.RechargeTypeCategory) {
        let amountScale: ApiProto.AmountScale = null;
        const curTime = Math.floor(we.core.TimeInfo.Inst.serverNow() / 1000);
        if (!(payInfo.rechargeGiftScale > 0 && curTime < we.common.storeMgr.shopConf.rechargeGiftExpireTime)) {
            return { amount: 0, scale: 0 };
        }

        for (let item of payInfo.rechargeGiftScaleArray || []) {
            if (amount >= item.amount) {
                amountScale = item;
            }
        }
        if (!amountScale) {
            // 没找到对应配置,不展示笔笔送
            amountScale = { amount: 0, scale: 0 };
        }
        // 笔笔送赠送比例万分位
        amount = Math.floor((amount * amountScale.scale) / 10000);
        if (amount < 0) {
            amount = 0;
        }
        return { amount, scale: amountScale.scale / 100 };
    }
}

export default we.common.storeMgr = new StoreMgr();
