import ApiManager from '../api/ApiManager';
import { CommonEvent } from '../config/CommonEvent';
import { CommonType } from '../config/CommonType';
import { CommonLanguage } from '../const/CommonLanguage';
import HttpProtoError from '../http/HttpProtoError';
import ApplePay from '../platform/ApplePay';
import GooglePay from '../platform/GooglePay';
import CommonUtils from '../utils/CommonUtils';
import StoreMgr from './StoreMgr';
import UserManager from './UserManager';

declare global {
    interface ICommon {
        /** 支付模块 */
        payMgr: PayManager;
    }
}

export interface PurchaseInfo {
    payType: number; // 充值类型
    productId: string; // 商品id
    orderId: string; // 订单id
    payload: PurchasePayload; // 透传参数
    token: string; // 鉴权token
}

interface PurchasePayload {
    uid: string; // 玩家id
    oid: string; // 内部订单号
}

class PayManager {
    /** 商品类型枚举 可用于充值成功后推送判定 */
    public readonly PRODUCT_TYPE = {
        /** 周卡 */
        WEEKLY_CARD: 1000,
        /** 七日福利 */
        SEVEN_DAY_WELFARE: 2000,
    };

    /** 支付类型 */
    public readonly PAY_TYPE = {
        /** 无效 */
        NULL: -1,
        /** 苹果支付: 0 */
        APPLE: 0,
        /** 谷歌支付: 1 */
        GOOGLE: 1,
        /** WebBank: 2 */
        /** ZaloQR: 3 */
        /** MomoQR: 4 */
        /** SMS: 6 */
        /** 印尼支付: 7(聚合支付) */
        IDP: 7,
        /** QR：银行扫码 */
        NET_BANK_IDR: 8,
        /** 银行卡转帐 */
        BANK_IDR: 9,
        DOKU_IDR: 10,
        /** 印尼支付: 11(聚合支付) */
        UNIPIN: 11,
        BANK_VA_IDR: 12,
        DANA_IDR: 13,
        OVO_IDR: 14,
        STORE_IDR: 15,
        QRIS_IDR: 16,
        /** 印尼考拉支付: 17(聚合支付) */
        KOALA: 17,
        LINKAJA_IDR: 18,
        SHOPEEPAY_IDR: 19,
        GO_PAY: 20,
        ALFAMART: 21,
        /** 墨西哥支付 */
        SPEL_MXN: 22,
        /** 墨西哥提现 */
        BANK_MXN: 25,
        /** 尼日利亚支付 */
        KEYSTONE_BANK_NGN: 26,
        /** 尼日利亚 VA 支付 */
        BANK_VA_NGN: 28,
        /** 巴西 CPF_BRL 提现 */
        CPF_BRL: 30,
        /** 巴西 CNPJ_BRL 提现 */
        CNPJ_BRL: 31,
        /** 巴西 EMAIL_BRL 提现 */
        EMAIL_BRL: 32,
        /** 巴西 PHONE_BRL 提现 */
        PHONE_BRL: 33,
        /** 印度支付: 34(二维码收款) */
        UPI_QR_INR: 34,
        /** 印度支付/提现: 35(聚合支付/提现) */
        UPI_INR: 35,
        /** 印度 BANK_INR 提现: 36 */
        BANK_INR: 36,
        /** 印尼支付: 37(扫码支付) */
        EB_PAY: 37,
        /** 菲律宾 MAYA */
        MAYA: 39,
        /** 菲律宾 GRAB */
        GRAB: 40,
        /** 菲律宾 GCASH */
        GCASH: 41,
        /** 菲律宾 GOTYME */
        GOTYME: 42,
        /** 印度支付/提现: 43 */
        INRUPAY: 43,
        /** 印度支付/提现: 44 */
        RUPEELINK: 44,
        /** 菲律宾 QRPh */
        QRPh: 45,
        /** 越南momo扫码 */
        MOMO_QR_VND: 46,
        /** 越南zalo扫码 */
        ZALO_QR_VND: 47,
        /** 越南VN扫码 */
        VN_QR_VND: 48,
        /** 越南moca扫码 */
        MOCA_QR_VND: 49,
        /** 越南shopee扫码 */
        SHOPEEPAY_QR_VND: 50,
        /** 越南viettel扫码 */
        VIETTEL_QR_VND: 51,
        /** 越南payoo扫码 */
        PAYOO_QR_VND: 52,
        /** 越南viet扫码 */
        VIET_QR_VND: 53,
        /** 越南银行 */
        BANK_VND: 54,
        /** 巴基斯坦银行 */
        BANK_PKR: 55,
        /** 巴基斯坦EasyPaisa扫码 */
        EASY_QR_PKR: 56,
        /** 巴基斯坦JazzCash扫码 */
        JAZZ_QR_PKR: 57,
        /** 巴基斯坦Upaisa扫码 */
        UP_QR_PKR: 58,
        /** 巴基斯坦Payoneer扫码 */
        PAYONEER_QR_PKR: 59,
        /** 巴基斯坦GoLootLo扫码 */
        GOLOOTLO_QR_PKR: 60,
        /** 巴基斯坦PayPak扫码 */
        PAYPAK_QR_PKR: 61,
        /** 巴基斯坦Moneygram扫码 */
        MONEYGRAM_QR_PKR: 62,
        /** 巴基斯坦SadaPay扫码 */
        SADA_QR_PKR: 63,
        /** 越南刮刮卡支付 */
        THECAO_VND: 64,
        /** 印度 UPI_H5 支付 */
        UPI_H5_INR: 65,
        /** 孟加拉国银行 */
        BANK_BDT: 66,
        /** BKASH */
        BKASH_QR_BDT: 67,
        /** NAGAD */
        NAGAD_QR_BDT: 68,
        /** ROCKET */
        ROCKET_QR_BDT: 69,
        /** BAJAJ_FINSERV 钱包 */
        BAJAJ_FINSERV_QR_BDT: 70,
        /** UPAY */
        UPAY_BDT: 71,
        /** SURECASH */
        SURECASH_BDT: 72,
        /** IPAY */
        IPAY_BDT: 73,
        /** PAYPAL */
        PAYPAL_BDT: 74,
        /** FB小游戏支付 */
        FBINSTANT: 300,
        /** 自研钱包 MTPay */
        MT_PAY: 301,
        /** 线下支付 */
        OFFLINE: 400,
        /** 虚拟币支付合集 */
        CRYPTO_PAY: 500,
        /** VIP 支付 撮合交易通道 */
        VIP_PAY: 900,
        /** 测试支付: >= 1000 */
        TEST: 1000,
        /** 孟加拉国 */
        TEST_BDT: 1011,
    };

    /** Bank */
    public readonly BANK = {
        /** 印尼银行卡 */
        CENA: 'CENA',
        BRIN: 'BRIN',
        BMRI: 'BMRI',
        BNIN: 'BNIN',
        BNIA: 'BNIA',
        IBBK: 'IBBK',
        BBBA: 'BBBA',
        PINB: 'PINB',
        BDIN: 'BDIN',
        OCBC: 'OCBC',
        BSIB: 'BSIB',
        BNCB: 'BNCB',
        /** 墨西哥银行卡 */
        AFIRME: 'AFIRME',
        AZTECA: 'AZTECA',
        BANAMEX: 'BANAMEX',
        BANOBRAS: 'BANOBRAS',
        BANORTE: 'BANORTE',
        BANREGIO: 'BANREGIO',
        BBVAMEXICO: 'BBVAMEXICO',
        COMPARTAMOS: 'COMPARTAMOS',
        HSBC: 'HSBC',
        INBURSA: 'INBURSA',
        SANTANDER: 'SANTANDER',
        /** 尼日利亚银行卡枚举 */
        FIDELITY_BANK_PLC: 'FIDELITY_BANK_PLC',
        FIRST_BANK_OF_NIGERIA_PLC: 'FIRST_BANK_OF_NIGERIA_PLC',
        FIRST_CITY_MONUMENT_BANK_PLC: 'FIRST_CITY_MONUMENT_BANK_PLC',
        GUARANTY_TRUST_BANK_PLC: 'GUARANTY_TRUST_BANK_PLC',
        STANBIC_IBTC_BANK_PLC: 'STANBIC_IBTC_BANK_PLC',
        UNION_BANK_OF_NIGERIA_PLC: 'UNION_BANK_OF_NIGERIA_PLC',
        UNITED_BANK_FOR_AFRICA_PLC: 'UNITED_BANK_FOR_AFRICA_PLC',
        ZENITH_BANK_PLC: 'ZENITH_BANK_PLC',
        ECOBANK_MOBILE: 'ECOBANK_MOBILE',
        ACCESS_BANK_PLC: 'ACCESS_BANK_PLC',
        KEYSTONE_BANK_PLC: 'KEYSTONE_BANK_PLC',
        STANDARD_CHARTERED_BANK_PLC: 'STANDARD_CHARTERED_BANK_PLC',
        STERLING_BANK_PLC: 'STERLING_BANK_PLC',
        PAYCOM: 'PAYCOM',
        UNITY_BANK_PLC: 'UNITY_BANK_PLC',
        /** 菲律宾银行卡 */
        GCASH: 'GCASH',
        MAYA: 'MAYA',
        GRAB: 'GRAB',
        GOTYME: 'GOTYME',
        METROBANK: 'METROBANK',
        MB: 'MB',
        SECURITY: 'SECURITY',
        PNB: 'PNB',
        BDO: 'BDO',
        LBP: 'LBP',
        /** 越南银行 */
        VCB: 'VCB',
        BIDV: 'BIDV',
        CTB: 'CTB',
        TCB: 'TCB',
        ACB: 'ACB',
        MBVN: 'MBVN',
        STB: 'STB',
        AGB: 'AGB',
        VPB: 'VPB',
        EIB: 'EIB',
        /** 巴基斯坦银行 */
        NBP: 'NBP',
        HBL: 'HBL',
        UBL: 'UBL',
        MCB: 'MCB',
        ASK: 'ASK',
        ALFA: 'ALFA',
        FAY: 'FAY',
        SCB: 'SCB',
        BOP: 'BOP',
        AIBB: 'AIBB',
        /** 孟加拉国银行 */
        BB: 'Bangladesh Bank',
        AB: 'Agrani Bank PLC',
        BRAC: 'BRAC Bank PLC',
        DBBL: 'Dutch-Bangla Bank PLC',
        IBBL: 'Islami Bank Bangladesh PLC',
        DBL: 'Dhaka Bank Limited',
        IFIC: 'IFIC Bank Limited',
        CBC: 'Commercial Bank of Ceylon Limited',
        BCB: 'Bangladesh Commerce Bank',
    };

    /** 订单状态颜色映射（仅用于区分UI颜色，不是真正的订单状态） */
    public readonly ORDER_STATUS = {
        WAIT: 0,
        SUCCEEDED: 1,
        FAILED: 2,
    };

    /** 聚合支付方式 */
    private readonly IntegrationPay = [this.PAY_TYPE.NET_BANK_IDR, this.PAY_TYPE.BANK_IDR, this.PAY_TYPE.IDP, this.PAY_TYPE.UNIPIN, this.PAY_TYPE.KOALA, this.PAY_TYPE.BANK_BDT];

    /** 银行支付方式 */
    private readonly BankPay = [this.PAY_TYPE.NET_BANK_IDR, this.PAY_TYPE.BANK_IDR, this.PAY_TYPE.BANK_VA_IDR, this.PAY_TYPE.KEYSTONE_BANK_NGN, this.PAY_TYPE.BANK_BDT];

    /** 数字货币支付方式 */
    private readonly DigitalPay = [this.PAY_TYPE.EB_PAY, this.PAY_TYPE.MT_PAY];

    /** 刮刮卡支付方式 */
    private readonly ScratchCardsPay = [this.PAY_TYPE.THECAO_VND];

    /** 订单发起位置 */
    public trackFrom: string = '';

    /**
     * 获取订单信息
     * @param productId 商品id
     * @param payType 支付类型
     * @param bankCode 银行编码
     * @param amount 商品数量  (仅用在购买不定额金币数量商品)
     * @returns
     */
    public getOrderInfo(productId: string, payType: number, bankCode: string = '', amount?: number): void {
        if (!productId) {
            we.warn('PayManager getOrderInfo params invalid');
            return;
        }

        let promise = new Promise<string>((resolve, reject) => {
            ApiManager.getQueryOrder(
                productId,
                payType,
                bankCode,
                amount,
                this.trackFrom,
                (data: ApiProto.QueryOrderResp) => {
                    // 透传参数
                    let payload = {} as PurchasePayload;
                    payload.uid = UserManager.userInfo.userId.toString();
                    payload.oid = data.orderNo;

                    let payloadEncode = we.core.utils.base64Encode(JSON.stringify(payload));

                    switch (data.payType) {
                        case this.PAY_TYPE.APPLE:
                            ApplePay.purchaseInApp(data.productId, payloadEncode);
                            // let purchaseInfo = '{"productId":"store_coin_1","orderId":"2000000035694078","payload":"eyJ1aWQiOiIxMDgyMDQiLCJvaWQiOiIyMjA0MTkxNDI4MjQ4MjA0MTEifQ==","token":"xxx"}';
                            // //@ts-ignore
                            // cc.onApplePayPurchaseSuccess(purchaseInfo);
                            break;
                        case this.PAY_TYPE.GOOGLE:
                            GooglePay.purchaseInApp(data.productId, payloadEncode);
                            // let purchaseInfo = '{"productId":"store_coin_1","orderId":"GPA.3356-4647-3166-12631","payload":"eyJ1aWQiOiIyNjIxNzkwIiwib2lkIjoiMjIwNDE5MTQxNjQ0MTc5MDU1In0=","token":"xxx"}';
                            // //@ts-ignore
                            // cc.onGooglePayPurchaseSuccess(purchaseInfo);
                            break;
                        default:
                            if (data.contentType == 'url') {
                                resolve(data.content);
                            }
                            break;
                    }
                },
                (code) => {
                    this.queryOrderErrorHandle(code);
                }
            );
        });

        promise.then((url: string) => {
            if (cc.sys.isBrowser && cc.sys.browserType == cc.sys.BROWSER_TYPE_SAFARI) {
                // safari 打开新窗口必须要交互
                const opts: we.ui.type.ConfirmPopupOptions = {
                    content: we.core.langMgr.getLangText(CommonLanguage.RECHARGE_TIPS_002),
                    yesHandler: we.core.Func.create(() => {
                        we.core.nativeUtil.openUrl(url);
                    }),
                    isHideCloseBtn: false,
                };
                we.commonUI.showConfirm(opts);
            } else {
                we.core.nativeUtil.openUrl(url);
            }
        });
        // we.core.nativeUtil.openUrl(promise);
    }

    /**
     * 验证支付信息
     * @param purchaseInfo
     */
    public authPurchaseInfo(purchaseInfo: PurchaseInfo): void {
        if (!purchaseInfo) {
            we.warn('PayManager authPurchaseInfo, params invalid');
            return;
        }

        let payload = {} as PurchasePayload;
        payload.uid = '';
        payload.oid = '';

        if (purchaseInfo.payload) {
            let payloadDecode = we.core.utils.base64Decode(<any>purchaseInfo.payload);
            try {
                payload = JSON.parse(payloadDecode);
            } catch (err) {
                we.error(`PayManager authPurchaseInfo, payload parse err: ${JSON.stringify(err.message || err)}`);
            }
        }

        purchaseInfo.payload = payload;

        let userId = purchaseInfo.payload.uid || '';
        if (userId && UserManager.userInfo.userId > 0 && userId != UserManager.userInfo.userId.toString()) {
            // 补单时用户切换了账号
            we.info(`PayManager authPurchaseInfo, userId invalid, userId: ${userId}, uid: ${UserManager.userInfo.userId}, purchaseInfo: ${JSON.stringify(purchaseInfo)}`);

            UserManager.getUserProfileById(parseInt(userId), (data: ApiProto.UserProfileResp) => {
                we.commonUI.showConfirm({
                    content: we.core.langMgr.getLangText(CommonLanguage.PURCHASE_ERROR_ACCOUNT, data.profile.userName, data.profile.userId),
                    yesButtonName: we.core.langMgr.getLangText(we.launcher.lang.BTN_CONFIRM),
                });
            });
            return;
        }

        let req = {} as ApiProto.RechargeAuthReq;
        req.payType = purchaseInfo.payType;
        req.productId = purchaseInfo.productId;
        req.storeOrderId = purchaseInfo.orderId;
        req.sign = purchaseInfo.token;
        req.orderNo = purchaseInfo.payload.oid || '';

        we.info(`PayManager authPurchaseInfo, payAuthInfo request, req: ${JSON.stringify(req)}`);
        ApiManager.payAuthInfo(
            req,
            (data: ApiProto.RechargeAuthResp) => {
                we.info(`PayManager authPurchaseInfo, payAuthInfo success, req: ${JSON.stringify(req)}, data: ${JSON.stringify(data)}`);

                // 0 OK, 1 订单无效, 2 订单已发放（已使用）, 3 凭据无效, 4 凭据已发放（已使用）,-1 其他错误
                if (data.respCode == 0) {
                    we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.PURCHASE_SUCCESS));
                } else {
                    we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.PURCHASE_FAILURE) + ': ' + data.respCode);
                }

                // 消耗商品
                switch (data.payType) {
                    case this.PAY_TYPE.APPLE:
                        ApplePay.consumeInApp(purchaseInfo.productId, purchaseInfo.orderId);
                        break;
                    case this.PAY_TYPE.GOOGLE:
                        GooglePay.consumeInApp(purchaseInfo.productId, purchaseInfo.orderId);
                        break;
                    default:
                        break;
                }

                // 刷新玩家信息
                UserManager.refreshUserInfo();
            },
            (code) => {
                we.info(`PayManager authPurchaseInfo, payAuthInfo error, req: ${JSON.stringify(req)}, code: ${code}`);
            }
        );
    }

    /**
     * 处理未完成交易
     * @param productId 商品id
     */
    public processUncompleteTransaction(productId: string = ''): void {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                GooglePay.processUncompleteTransaction(productId);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                ApplePay.processUncompleteTransaction(productId);
            }
        }
    }

    /**
     * 是否商店支付
     * @param payType
     */
    public isStorePay(payType: number): boolean {
        if (payType == this.PAY_TYPE.APPLE || payType == this.PAY_TYPE.GOOGLE || payType == this.PAY_TYPE.FBINSTANT) {
            return true;
        }
        return false;
    }

    /**
     * 是否聚合支付
     * @param payType
     */
    public isIntegrationPay(payType: number): boolean {
        if (this.IntegrationPay.indexOf(payType) > -1) {
            return true;
        }
        return false;
    }

    /**
     * 是否银行支付 (转账/扫码)
     * @param payType
     */
    public isBankPay(payType: number): boolean {
        if (this.BankPay.indexOf(payType) > -1) {
            return true;
        }
        return false;
    }

    /**
     * 是否数字货币支付
     * @param payType
     */
    public isDigitalPay(payType: number): boolean {
        if (this.DigitalPay.indexOf(payType) > -1) {
            return true;
        }
        return false;
    }

    /**
     * 是否刮刮卡支付
     * @param payType
     */
    public isScratchCardsPay(payType: number): boolean {
        if (this.ScratchCardsPay.indexOf(payType) > -1) {
            return true;
        }
        return false;
    }

    /**
     * 是否测试支付
     * @param payType
     */
    public isTestPay(payType: number): boolean {
        if (payType >= this.PAY_TYPE.TEST) {
            return true;
        }
        return false;
    }

    /**
     * 订单创建错误code处理
     * @param code
     */
    private queryOrderErrorHandle(code: number): void {
        switch (code) {
            case HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3007:
                StoreMgr.isNewbieGift = false;
                cc.director.emit(CommonEvent.CLOSE_FIRST_RECHARGE_DIALOG);
                cc.director.emit(CommonEvent.GIFT_BAG_UPDATE);
                break;
            case HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_4005:
                cc.director.emit(CommonEvent.OPEN_USER_REAl_NAME_DLG);
                break;
            default:
                break;
        }
        this.rechargeFailCountAdd();
    }

    public rechargeFailCountAdd() {
        let value = CommonType.storage.get('common', 'recharge_fail_count');
        let count = 0;
        if (!value) {
            count = value;
        }
        count++;
        if (count >= 3) {
            // 充值失败提示 引导弹窗
            count = 0;
        }

        CommonType.storage.setById('common', 'recharge_fail_count', count);
    }

    /**
     * 获取价格 优先展示默认支付渠道的现价
     * @param goodInfo
     * @param defaultPT
     * @param isFormat  是否格式化 默认格式化
     * @returns
     */
    public getGoodPriceStr(goodInfo: ApiProto.GoodsPackageInfo, defaultPT: number, isFormat: boolean = true) {
        let primaryCurrency = we.core.projectConfig.settingsConfig.primaryCurrency;
        let price = null;
        let priceStr = null;
        for (let key in goodInfo.payTypePrice) {
            if (parseInt(key) == defaultPT) {
                price = goodInfo.payTypePrice[key];
            }
        }
        if (price) {
            if (isFormat) {
                priceStr = CommonUtils.formatPrice(price[primaryCurrency], false, false);
            } else {
                priceStr = price[primaryCurrency];
            }
        } else {
            if (isFormat) {
                priceStr = CommonUtils.formatPrice(goodInfo.price[primaryCurrency], false, false);
            } else {
                priceStr = goodInfo.price[primaryCurrency];
            }
        }
        return priceStr;
    }

    /**
     * 获取价格 优先展示默认支付渠道的原始价格
     * @param goodInfo
     * @param defaultPT
     * @param isFormat  是否格式化 默认格式化
     * @returns
     */
    public getGoodOriginPriceStr(goodInfo: ApiProto.GoodsPackageInfo, defaultPT: number, isFormat: boolean = true) {
        let primaryCurrency = we.core.projectConfig.settingsConfig.primaryCurrency;
        let originPrice = null;
        let originPriceStr = null;
        for (let key in goodInfo.payTypeOriginalPrice) {
            if (parseInt(key) == defaultPT) {
                originPrice = goodInfo.payTypeOriginalPrice[key];
            }
        }
        if (originPrice) {
            if (isFormat) {
                originPriceStr = CommonUtils.formatPrice(originPrice[primaryCurrency], false, false);
            } else {
                originPriceStr = originPrice[primaryCurrency];
            }
        } else {
            if (isFormat) {
                originPriceStr = CommonUtils.formatPrice(goodInfo.originalPrice[primaryCurrency], false, false);
            } else {
                originPriceStr = goodInfo.originalPrice[primaryCurrency];
            }
        }
        return originPriceStr;
    }

    public setPayTrackFrom(): void {
        let curGameId = we.core.gameConfig.curGameId;
        let position = '';
        if (we.core.gameConfig.isSubGame(curGameId)) {
            position = `${curGameId}`;
        } else {
            position = 'hall';
        }
        this.trackFrom = position;
    }
}

export default we.common.payMgr = new PayManager();
