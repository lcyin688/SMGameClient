declare global {
    interface ICommon {
        gameServerMgr: typeof GameServerMgr;
    }
}

/**
 * 子游戏域名列表
 * 格式和大厅预埋预名一样
 * 优先读取子游戏配置, 没有则读取大厅配置, 和大厅预埋预名一样的话可以缺省
 */
const GameDomains = {
    vn: {
        prod: ['gvmland.com', 'gtmlast.com', 'gimlong.com', 'gvnline.com'],
    },
    pk: {
        prod: ['galabym.com', 'gamissm.com', 'gafreem.com', 'gacourm.com'],
    },
    bd: {
        prod: ['grantim.com', 'gconfom.com', 'gruntam.com'],
    },
};

export default class GameServerMgr {
    /** 域名列表 */
    private static domains: string[] = [];
    /** 域名切换记录 */
    private static domainSwitchRecord: string[] = [];

    public static init(): void {
        let domains = GameDomains?.[we.core.flavor.getCountryCode()]?.[we.core.flavor.getEnvType()];
        if (domains == undefined) {
            domains = we.core.flavor.getDomains();
        } else {
            if (!Array.isArray(domains)) {
                domains = domains[we.core.flavor.getCountryRegion()];
            }
        }
        this.domains = this.filterDomains(domains);
    }

    /**
     * 更新域名
     * @param domains
     * @returns
     */
    public static updateDomains(domains: string[]): void {
        if (!(domains instanceof Array && domains.length > 0)) {
            return;
        }

        this.domains = this.filterDomains(domains);
    }

    /**
     * 切换域名
     * @param url
     * @returns
     */
    public static switchDomain(url: string): boolean {
        we.warn(`GameServerMgr switchDomain, url: ${url}`, we.noup);

        for (let i = 0; i < this.domainSwitchRecord.length; i++) {
            if (url?.includes(this.domainSwitchRecord[i])) {
                return false;
            }
        }

        let currentDomain = this.getDomain();

        // 并发限制
        this.domainSwitchRecord.push(currentDomain);
        if (this.domainSwitchRecord.length >= this.domains.length) {
            this.domainSwitchRecord = [];
        }

        // 当前域名移到最后
        this.domains.push(currentDomain);
        this.domains.shift();

        return true;
    }

    /**
     * 游戏 ws
     * @param gameId
     * @returns
     */
    public static getGameWs(gameId: we.GameId): string {
        if (!we.core.gameConfig.isSubGame(gameId)) {
            we.warn(`GameServerMgr getGameWs, gameId: ${gameId}`);
            return '';
        }

        let idx = 0;
        let userId = we.core.userStatusInfo.userId;
        if (userId > 0) {
            let last = Number(userId.toString().slice(-1));
            idx = Math.floor(last % 10);
        }

        let protocol = 'wss';
        let subdomain = this.getSubdomain();
        let path = 'game';
        let url = `${protocol}://${subdomain}.${this.getDomain()}/${path}/${gameId}/${idx}`;

        // 调试
        let svug = we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.svug);
        if (svug == '1') {
            url = `ws://127.0.0.1:50${gameId}`;
        }
        const svugObj = we.core.utils.convertToKeyValue(svug);
        if (svugObj[`${gameId}`]) {
            url = svugObj[`${gameId}`];
        }
        return url;
    }

    /**
     * 获取当前域名
     * @returns
     */
    private static getDomain(): string {
        return this.domains[0];
    }

    /**
     * 获取子域名
     * @returns
     */
    private static getSubdomain(): string {
        let subdomain = 'api';
        if (
            // id-test
            (we.core.flavor.getCountryCode() == we.core.CountryCode.id && we.core.flavor.isTestEnv()) ||
            // vn
            we.core.flavor.getCountryCode() == we.core.CountryCode.vn ||
            // pk
            we.core.flavor.getCountryCode() == we.core.CountryCode.pk ||
            // bd
            we.core.flavor.getCountryCode() == we.core.CountryCode.bd
        ) {
            subdomain = 'game';
        }
        return subdomain;
    }

    /**
     * 过滤域名
     * @param domains
     * @returns
     */
    private static filterDomains(domains: string[]): string[] {
        if (!(domains instanceof Array)) {
            return [];
        }

        // 校验
        domains = domains.filter((value) => {
            if (/[\w-]+(\.[\w-]+){1,3}/.test(value)) {
                return true;
            }
        });

        // 去重
        domains = domains.filter((value, index) => {
            if (domains.indexOf(value) == index) {
                return true;
            }
        });

        return domains;
    }
}

we.common.gameServerMgr = GameServerMgr;
