const { ccclass, property, menu, disallowMultiple } = cc._decorator;

declare global {
    interface IUI {
        WEToggle: typeof WEToggle;
    }

    namespace we {
        namespace ui {
            type WEToggle = InstanceType<typeof WEToggle>;
        }
    }
}

/**
 * Toggle按钮组件
 */
@ccclass
@disallowMultiple
@menu('we/button/WEToggle(WEToggle按钮组件)')
export class WEToggle extends we.ui.WEButton {
    /**
     * toggle状态，是否选中
     */
    private _isChecked: boolean = false;

    private _toggleListener: we.core.Func<(isChecked: boolean) => void>;

    @property({
        type: [cc.Node],
        tooltip: CC_DEV && '普通节点列表',
    })
    private normalNodeList: cc.Node[] = []; // 普通节点列表
    @property({
        type: [cc.Node],
        tooltip: CC_DEV && '选中的节点列表',
    })
    private selectNodeList: cc.Node[] = []; // 选中的节点列表

    @property({
        tooltip: CC_DEV && '手柄是否需要播放移动的动画',
    })
    private thumbAni: boolean = true;
    @property({
        type: cc.Node,
        tooltip: CC_DEV && '手柄',
        visible() {
            return this.thumbAni;
        },
    })
    private thumbNode: cc.Node = null; // 手柄
    @property({
        tooltip: CC_DEV && '普通状态下手柄的位置',
        visible() {
            return this.thumbAni;
        },
    })
    private thumbNormalPos: cc.Vec2 = new cc.Vec2(0, 0); // 普通状态下手柄的位置
    @property({
        tooltip: CC_DEV && '选中状态下手柄的位置',
        visible() {
            return this.thumbAni;
        },
    })
    private thumbSelectPos: cc.Vec2 = new cc.Vec2(0, 0); // 选中状态下手柄的位置

    @property({
        type: cc.Float,
        tooltip: CC_DEV && '手柄移动的时间',
        visible() {
            return this.handleAni;
        },
    })
    private moveThumbTime: number = 0.1; // 手柄移动的时间

    protected onLoad(): void {
        super.onLoad();
        this.onListener(we.core.Func.create(this.onSwitch, this));
        this.updateUI(false);
    }

    public set toggleListener(handler: we.core.Func<(isChecked: boolean) => void>) {
        this._toggleListener = handler;
    }

    public set isChecked(value: boolean) {
        if (this._isChecked == value) {
            return;
        }
        this._isChecked = value;
        this.updateUI(false);
    }

    public get isChecked(): boolean {
        return this._isChecked;
    }

    private onSwitch() {
        this._isChecked = !this._isChecked;
        this.selectChanged();
    }

    private selectChanged(): void {
        this._toggleListener?.exec(this._isChecked);
        this.updateUI(true);
    }

    private updateUI(thumbAni: boolean): void {
        const descPos = this._isChecked ? this.thumbSelectPos : this.thumbNormalPos;
        for (const node of this.normalNodeList) {
            node.active = !this._isChecked;
        }
        for (const node of this.selectNodeList) {
            node.active = this._isChecked;
        }
        if (this.thumbNode) {
            if (this.thumbAni && thumbAni) {
                cc.tween(this.thumbNode).to(this.moveThumbTime, { x: descPos.x, y: descPos.y }).start();
            } else {
                this.thumbNode.setPosition(descPos);
            }
        }
    }
}

we.ui.WEToggle = WEToggle;
