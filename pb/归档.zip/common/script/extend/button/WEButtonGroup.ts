const { ccclass, menu, disallowMultiple } = cc._decorator;

declare global {
    interface IUI {
        /**
         * 按钮组组件
         */
        WEButtonGroup: typeof WEButtonGroup;
    }

    namespace we {
        namespace ui {
            type WEButtonGroup = InstanceType<typeof WEButtonGroup>;
        }
    }
}

/**
 * 管理按钮组
 * 默认加载当前节点下所有自节点的WEButton
 * 支持动态添加/删除WEButton
 */
@ccclass
@disallowMultiple
@menu('we/button/WEButtonGroup(继承按钮组)')
export class WEButtonGroup extends cc.Component {
    private _buttons: we.ui.WEButton[] = [];

    private isAsync = false;

    handler: we.core.Func<(contextData: any, index: number) => void> | we.core.FuncAsync<(contextData: any, index: number) => Promise<void>>;

    get buttons() {
        if (this._buttons.length > 0) {
            return this._buttons;
        }

        const btns = this.getComponentsInChildren(cc.Button);
        btns.forEach((btn) => {
            const button = btn.node.addComponentUnique(we.ui.WEButton);
            if (button) {
                this._buttons.push(button);
            }
        });

        return this._buttons;
    }

    /**
     * 动态添加按钮到组
     * @param button 按钮
     */
    addButton(button: we.ui.WEButton) {
        if (this.buttons.includes(button)) {
            return;
        }
        this.buttons.push(button);

        if (this.isAsync) {
            button.onListenerAsync(
                we.core.FuncAsync.create(async () => {
                    await this.handler.exec(button.getContextData() ?? button.node.name, this.buttons.indexOf(button));
                }, this)
            );
        } else {
            button.onListener(
                we.core.Func.create(() => {
                    this.handler.exec(button.getContextData() ?? button.node.name, this.buttons.indexOf(button));
                }, this)
            );
        }
    }

    /**
     * 动态移除按钮
     * @param button
     */
    delButton(button: we.ui.WEButton) {
        this._buttons = this.buttons.removeOne(button);
        button.offListener();
    }

    /**
     * 设置按钮组Context数据
     * @param datas
     */
    setContextDatas(datas: any[]) {
        for (let i = 0; i < this.buttons.length; ++i) {
            if (datas[i] != null) {
                this.buttons[i].setContextData(datas[i]);
            }
        }

        return this;
    }

    onListener<T>(handler: we.core.Func<(contextData: T, index: number) => void>) {
        this.buttons.forEach((btn) => {
            btn.onListener(
                we.core.Func.create(() => {
                    handler.exec(btn.getContextData() ?? btn.node.name, this.buttons.indexOf(btn));
                }, this)
            );
        });
        this.handler = handler;
        this.isAsync = false;

        return this;
    }

    onListenerAsync<T>(handler: we.core.FuncAsync<(contextData: T, index: number) => Promise<void>>) {
        this.buttons.forEach((btn) => {
            btn.onListenerAsync(
                we.core.FuncAsync.create(async () => {
                    await handler.exec(btn.getContextData() ?? btn.node.name, this.buttons.indexOf(btn));
                }, this)
            );
        });
        this.handler = handler;
        this.isAsync = true;

        return this;
    }

    offListener() {
        this.buttons.forEach((btn) => {
            btn.offListener();
        });
    }

    setEnableAudio(v: boolean, audioUrl?: string) {
        this.buttons.forEach((btn) => {
            btn.setEnableAudio(v, audioUrl);
        });
        return this;
    }

    setEnableClick(v: boolean, bUseGrayScale: boolean = false) {
        this.buttons.forEach((btn) => {
            btn.setEnableClick(v, bUseGrayScale);
        });
        return this;
    }

    /**
     * 无效果交互模式
     */
    setTransitionNone() {
        this.buttons.forEach((btn) => {
            btn.setTransitionNone();
        });
        return this;
    }

    /**
     * 图片模式
     * @param conf
     * @returns
     */
    setTransitionSprite(conf: { normal: cc.SpriteFrame; pressed?: cc.SpriteFrame; hover?: cc.SpriteFrame; disabled?: cc.SpriteFrame }) {
        this.buttons.forEach((btn) => {
            btn.setTransitionSprite(conf);
        });
        return this;
    }

    /**
     * 颜色变化模式
     * @param conf
     * @returns
     */
    setTransitionColor(conf: { normal: cc.Color; pressed?: cc.Color; hover?: cc.Color; disabled?: cc.Color }) {
        this.buttons.forEach((btn) => {
            btn.setTransitionColor(conf);
        });

        return this;
    }

    /**
     * 缩放模式
     * @param conf
     * @returns
     */
    setTransitionScale(conf?: { zoomScale: number; duration?: number }) {
        this.buttons.forEach((btn) => {
            btn.setTransitionScale(conf);
        });

        return this;
    }
}

we.ui.WEButtonGroup = WEButtonGroup;
