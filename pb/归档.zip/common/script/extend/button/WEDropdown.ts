/* eslint-disable @typescript-eslint/no-non-null-assertion */
const { ccclass, menu, property, disallowMultiple } = cc._decorator;

declare global {
    interface IUI {
        WEDropdown: typeof WEDropdown;
    }

    namespace we {
        namespace ui {
            type WEDropdown = InstanceType<typeof WEDropdown>;
        }
    }
}

@ccclass
@disallowMultiple
@menu('we/button/WEDropdown(下拉选择框)')
export class WEDropdown<T extends { desc: string; value?: any }> extends cc.Component {
    private _itemsTextArray: T[] = [];

    private _openSign: string = 'v';
    private _closeSign: string = '<';
    private _currentLabel: cc.Node = new cc.Node();
    private _btnSign: cc.Node = new cc.Node();
    private _scrollView: cc.Node = new cc.Node();
    private _content: cc.Node = new cc.Node();
    private _item: cc.Node = new cc.Node();

    public selectedEventHandler: we.core.Func<any>;
    public renderEventHandler: we.core.Func<any>;

    private selectItem: T = null;
    private oldSelectItemNode: cc.Node = null;

    onLoad() {
        this._init();
    }

    start() {}

    private _init() {
        this._initChildNode();
        this._initEvent();
    }

    private _initChildNode() {
        this._currentLabel = this.node.children[0];
        this._btnSign = this.node.children[1];
        this._scrollView = this.node.children[2];
        this._content = this._scrollView.children[0].children[0];
        this._item = cc.instantiate(this._content.children[0]);
        this._content.removeAllChildren();
    }

    private _initEvent() {
        we.ui.UIViewHelper.onBtnClick(this.node, () => {
            // 点击空白处收起下拉框
            this._openCloseComboBox();
        });
    }

    setSelectedEvent(handler: we.core.Func<(item: T) => void>) {
        this.selectedEventHandler = handler;
    }

    setRenderEvent(handler: we.core.Func<(item: Node, data: T) => void>) {
        this.renderEventHandler = handler;
    }

    setItems(stringArray: T[], selectItem?: T) {
        this._recycle();
        this._itemsTextArray = stringArray;

        this.selectItem = selectItem ??= this._itemsTextArray[0];

        this.setCurrentText(this.selectItem);
        this._spawnItems();

        if (this._scrollView.opacity !== 0) {
            this._openCloseComboBox();
        }
    }

    private _recycle() {
        /*
        Delete all children of _content node.
        */
        this._itemsTextArray = [];
        this._content.removeAllChildren();
    }

    private _spawnItems() {
        for (let i = 0; i < this._itemsTextArray.length; i++) {
            const itemInfo = this._itemsTextArray[i];
            let item = new cc.Node();
            item = cc.instantiate(this._item);
            this._content.addChild(item);
            we.ui.UIViewHelper.onBtnClick(item, () => {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                const currentLabel = this._currentLabel.getComponent(cc.Label)!;
                currentLabel.string = itemInfo.desc;
                this.selectItem = itemInfo;
                this._openCloseComboBox();
                this.selectedEventHandler.exec(itemInfo, item, this.oldSelectItemNode);
                this.oldSelectItemNode = item;
            });

            if (this.renderEventHandler) {
                this.renderEventHandler.exec(item, itemInfo);
            } else {
                this._setItemText(item, itemInfo);
            }
        }
    }

    private _setItemText(item: cc.Node, data: T) {
        const label = item.getComponentInChildren(cc.Label);
        label.string = data.desc;
    }

    private _openCloseComboBox() {
        const uiOpacity = this._scrollView;
        const btnSign = this._btnSign;
        if (uiOpacity.opacity !== 0) {
            uiOpacity.opacity = 0;

            this._scrollView.active = false;

            if (btnSign.getComponent(cc.Label)) {
                let label = new cc.Label();
                label = btnSign.getComponent(cc.Label)!;
                label.string = this._closeSign;
            } else if (btnSign.getComponent(we.ui.WESpriteIndex)) {
                btnSign.getComponent(we.ui.WESpriteIndex).setIndex(0);
            } else if (btnSign.getComponent(cc.Sprite)) {
                btnSign.scaleY *= -1;
            }
        } else {
            uiOpacity.opacity = 255;
            this._scrollView.active = true;

            this._content.getComponent(cc.Layout).updateLayout();

            if (btnSign.getComponent(cc.Label)) {
                let label = new cc.Label();
                label = btnSign.getComponent(cc.Label)!;
                label.string = this._openSign;
            } else if (btnSign.getComponent(we.ui.WESpriteIndex)) {
                btnSign.getComponent(we.ui.WESpriteIndex).setIndex(1);
            } else if (btnSign.getComponent(cc.Sprite)) {
                btnSign.scaleY *= -1;
            }
        }
    }

    getCurrentText() {
        return this._currentLabel.getComponent(cc.Label)?.string;
    }

    setCurrentText(text: T) {
        let label = new cc.Label();
        label = this._currentLabel.getComponent(cc.Label)!;
        label.string = text.desc;
    }

    setOpenSign(sign: string) {
        this._openSign = sign;
    }

    setClosedSign(sign: string) {
        this._closeSign = sign;
    }
}

we.ui.WEDropdown = WEDropdown;
