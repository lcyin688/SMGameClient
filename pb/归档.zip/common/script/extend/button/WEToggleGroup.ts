import { WEToggle } from './WEToggle';

const { ccclass, menu, disallowMultiple } = cc._decorator;

declare global {
    interface IUI {
        /**
         * Toggle Group组件
         */
        WEToggleGroup: typeof WEToggleGroup;
        /**
         * Toggle组模式
         */
        ToggleGroupMode: typeof ToggleGroupMode;
    }
    interface TUI {
        ToggleGroupMode: ToggleGroupMode;
    }
    namespace we {
        namespace ui {
            type WEToggleGroup = InstanceType<typeof WEToggleGroup>;
            /**
             * Toggle组模式
             */
            type ToggleGroupMode = TUI['ToggleGroupMode'];
        }
    }
}

/**
 * Toggle组模式
 */
export enum ToggleGroupMode {
    /** 单选模式：0个或者1个选中, 默认选中0个 */
    Single = 1,
    /** 单选模式：必须保证1个选中，默认选中第一个 */
    SingleOne = 2,
    /** 多选模式:0个或者多个选中，默认一个都不选 */
    Multi = 3,
}

we.ui.ToggleGroupMode = ToggleGroupMode;

/**
 * 管理Toggle组
 * 默认加载当前节点下所有自节点的WEToggle
 * 支持动态添加/删除WEToggle
 */
@ccclass
@disallowMultiple
@menu('we/button/WEToggleGroup(管理WEToggle组)')
export class WEToggleGroup extends cc.Component {
    private _toggles: WEToggle[] = [];

    /** toggle组模式 */
    private mode: ToggleGroupMode = ToggleGroupMode.SingleOne;

    private handler: we.core.Func<(contextData: any, isChecked: boolean, index: number) => void>;

    protected onLoad(): void {
        if (this.toggles.length == 0) {
            return;
        }

        this.initToggleGroupStatus();

        this.toggles.forEach((toggle) => {
            this.setToggleListener(toggle);
        });
    }

    public get toggles() {
        if (this._toggles.length > 0) {
            return this._toggles;
        }

        const toggles = this.getComponentsInChildren(WEToggle);
        toggles.forEach((toggle) => {
            const weToggle = toggle.node.addComponentUnique(WEToggle);
            if (weToggle) {
                this._toggles.push(weToggle);
            }
        });

        return this._toggles;
    }

    /**
     * 选定结果信息
     */
    public get selectedResults(): { index: number; isChecked: boolean; contextData?: any }[] {
        return this.toggles
            .filter((item) => {
                return item.isChecked;
            })
            .map((toggle) => {
                return {
                    index: this.toggles.indexOf(toggle),
                    isChecked: toggle.isChecked,
                    contextData: toggle.getContextData(),
                };
            });
    }

    /**
     * 动态添加按钮到组
     * @param toggle 按钮
     */
    public addToggle(toggle: WEToggle) {
        if (this.toggles.includes(toggle)) {
            return;
        }

        this.toggles.push(toggle);
        this.setToggleListener(toggle);
    }

    /**
     * 动态移除按钮
     * @param toggle
     */
    public delToggle(toggle: WEToggle) {
        this._toggles = this.toggles.removeOne(toggle);
        toggle.toggleListener = null;
    }

    /**
     * 设置Toggle组Context数据
     * @param datas
     */
    public setContextDatas(datas: any[]) {
        for (let i = 0; i < this.toggles.length; ++i) {
            if (datas[i] != null) {
                this.toggles[i].setContextData(datas[i]);
            }
        }

        return this;
    }

    /**
     * 设置组模式
     * @param mode
     * @returns
     */
    public setGroupMode(mode: ToggleGroupMode) {
        this.mode = mode;
        this.initToggleGroupStatus();
        return this;
    }

    /**
     * 设置toggle状态
     * @param index
     * @param isChecked
     * @returns
     */
    public setToggleStatus(index: number, isChecked: boolean) {
        if (!this.toggles[index]) {
            return;
        }
        this.setToggleGroupStatus(isChecked, index);
        return this;
    }

    public setToggleStatusByContext<T>(contextData: T, isChecked: boolean) {
        let index = this.toggles.findIndex((v) => {
            return v.getContextData() === contextData;
        });

        if (index === -1) {
            return;
        }

        this.toggles[index].isChecked = isChecked;
        this.setToggleStatus(index, isChecked);
    }

    public onListener<T>(handler: we.core.Func<(contextData: T, isChecked: boolean, index: number) => void>) {
        this.handler = handler;
        this.toggles.forEach((toggle) => {
            this.setToggleListener(toggle);
        });
        return this;
    }

    public offListener() {
        this.handler = null;
        this.toggles.forEach((toggle) => {
            toggle.toggleListener = null;
        });
    }

    public setEnableAudio(v: boolean, audioUrl?: string) {
        this.toggles.forEach((toggle) => {
            toggle.setEnableAudio(v, audioUrl);
        });
        return this;
    }

    public setEnableClick(v: boolean, bUseGrayScale: boolean = false) {
        this.toggles.forEach((toggle) => {
            toggle.setEnableClick(v, bUseGrayScale);
        });
        return this;
    }

    private setToggleGroupStatus(isChecked: boolean, index: number) {
        switch (this.mode) {
            case ToggleGroupMode.Single:
                this.toggles.forEach((toggle, i) => {
                    if (i !== index) {
                        toggle.isChecked = false;
                    }
                });
                break;
            case ToggleGroupMode.SingleOne:
                if (!isChecked) {
                    this.toggles[index].isChecked = true;
                    return;
                }

                this.toggles.forEach((toggle, i) => {
                    toggle.isChecked = i !== index ? false : true;
                });
                break;
            case ToggleGroupMode.Multi:
                break;
            default:
                break;
        }
    }

    private initToggleGroupStatus() {
        switch (this.mode) {
            case ToggleGroupMode.Single:
                this.toggles.forEach((toggle, i) => {
                    toggle.isChecked = false;
                });
                break;
            case ToggleGroupMode.SingleOne:
                this.toggles.forEach((toggle, i) => {
                    // 第一个按钮默认选中
                    toggle.isChecked = i === 0 ? true : false;
                });
                break;
            case ToggleGroupMode.Multi:
                this.toggles.forEach((toggle, i) => {
                    toggle.isChecked = false;
                });
                break;
            default:
                break;
        }
    }

    private setToggleListener(toggle: WEToggle) {
        toggle.toggleListener = we.core.Func.create(() => {
            let toggleIndex = this.toggles.indexOf(toggle);
            this.setToggleGroupStatus(toggle.isChecked, toggleIndex);
            this.handler?.exec(toggle.getContextData() ?? toggle.node.name, toggle.isChecked, toggleIndex);
        }, this);
    }
}

we.ui.WEToggleGroup = WEToggleGroup;
