const { ccclass, property, menu } = cc._decorator;

declare global {
    interface IUI {
        WERichTags: typeof WERichTags;
    }
    namespace we {
        namespace ui {
            type WERichTags = InstanceType<typeof WERichTags>;
        }
    }
}
/**
 * 富文本扩展组件，皮肤差异 prefab 化
 * @type 按照富文本参数，和tags标签，对应解析设置
 * @type 编辑器可预览效果，设置 sampleText 属性
 */

@ccclass
@menu('we/label/WERichTags(富文本tags)')
export class WERichTags extends cc.RichText {
    @property({ tooltip: CC_DEV && '外层标签，包裹整个内容' })
    useOuterTag: boolean = false;

    @property({
        tooltip: CC_DEV && '外层标签，包裹整个内容。例如：<outline color=#ffffff width=2>',
        visible() {
            return this.useOuterTag === true;
        },
    })
    outerTag: string = '';

    @property({ type: [cc.String], tooltip: CC_DEV && '嵌套标签组，每个{x}对应一组标签' })
    innerTags: string[] = [];

    @property
    _sampleText: string = '';
    @property({ type: cc.String, tooltip: CC_DEV && '编辑器测试值，预览效果' })
    get sampleText() {
        return this._sampleText;
    }
    set sampleText(value: string) {
        if (CC_EDITOR) {
            this._sampleText = value;
            let arr = Array(this.innerTags.length).fill(' ??? ');
            this.setStringFormat(this._sampleText, ...arr);
        }
    }

    /** 剩余参数 */
    private _otherArgs: any[] = [];

    /**
     * 设置文本，支持格式化参数
     * @param text 原始文本
     * @param args 格式化参数列表
     */
    public setStringFormat(text: string, ...args: any[]) {
        this._otherArgs = args;
        this.replaceValue(text);
    }

    private replaceValue(rawValue: string) {
        let value = '';
        const isRTL = we.core.utils.containsCommonRTLLanguage(rawValue);
        if (isRTL && we.core.langMgr.getCurLangCode() === we.core.LangCode.ur) {
            value = this.replaceTagsIntoString(rawValue, this.innerTags);
        } else {
            value = this.insertTagsIntoString(rawValue, this.innerTags);
            if (this.useOuterTag) {
                value = this.wrapWithTags(value, this.outerTag);
            }
        }
        value = we.core.utils.stringFormat(value, ...this._otherArgs);
        this.string = value;
    }

    private insertTagsIntoString(str: string, tags: string[]): string {
        let result = str;
        for (let i = 0; i < tags.length; i++) {
            let place = `{${i}}`;
            if (result.includes(place)) {
                let tag = this.wrapWithTags(place, tags[i]);
                result = result.replace(place, tag);
            }
        }
        return result;
    }

    /**
     * 替换参数，为其套上标签
     */
    private replaceTagsIntoString(str: string, tags: string[]): string {
        let finalTags: string[] = [];
        let parts = str.split(/\{\d+\}/);
        let len = Math.max(parts.length, tags.length);

        for (let i = 0; i < len - 1; i++) {
            let place = '{' + i + '}';
            if (str.includes(place)) {
                let tag = this.wrapWithTags(place, tags[i]);
                finalTags.push(tag);
            }
        }

        // ur 换行方案
        let ret = '';
        for (let i = 0; i < len; i++) {
            if (finalTags[i]) {
                ret += finalTags[i];
            }
            if (parts[i]) {
                ret += parts[i];
                if (i < len - 1 && parts[i + 1]?.trim()?.length > 0) {
                    ret += '\n';
                }
            }
        }
        return ret;
    }

    /**
     * 根据给定的内容字符串和富文本前置标签字符串，返回一个包含内容和闭合标签的富文本字符串。
     * @param {string} str - 内容字符串，作为富文本标签之间的文本。
     * @param {string} tagString - 前置富文本标签字符串
     * @returns {string}
     */
    wrapWithTags(str: string, tagString: string): string {
        if (!tagString) {
            return str;
        }
        const tagRegex = /<([a-zA-Z0-9]+)([^>]*)>/g;
        let closingTags = tagString.replace(tagRegex, (match, tagName) => {
            return `</${tagName}>`;
        });
        return `${tagString}${str}${closingTags}`;
    }
}

we.ui.WERichTags = WERichTags;
