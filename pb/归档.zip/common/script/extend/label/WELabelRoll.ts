import CommonUtils from '../../utils/CommonUtils';

const { ccclass, property, menu } = cc._decorator;

declare global {
    interface IUI {
        WELabelRoll: typeof WELabelRoll;
    }

    namespace we {
        namespace ui {
            type WELabelRoll = InstanceType<typeof WELabelRoll>;
        }
    }
}

@ccclass
@menu('we/label/WELabelRoll')
export class WELabelRoll extends cc.Component {
    @property(cc.Label)
    private _label: cc.Label = null;

    @property(cc.Label)
    private set label(label: cc.Label) {
        if (label.node.uuid !== this.node.uuid) {
            return;
        }
        this._label = label;
    }

    private get label() {
        if (!this._label) {
            this._label = this.node.getComponent(cc.Label);
        }
        return this._label;
    }

    private _value: number = 0;

    private _newValue: number = 0;

    private _step: number = 0;

    private _duration = 0;

    private _elapsed = 0;

    private _distance = 0;

    private _onValueUpdateHandler: Map<(v: number) => void, any> = new Map();

    private _decimal = 0;

    private _handler = {
        format: (v: number, decimal: number) => {
            return {
                value: CommonUtils.formatAmount(v, false, decimal),
                isAmount: true,
            };
        },
    };

    private resolve: () => void = null;

    /**
     * 设置滚动值
     * @param v
     * @param time
     * @param isUpdateZero
     * @returns
     */
    public async setValue(v: number, time: number = 0, isUpdateZero = false) {
        if (this._value == v) {
            if (v == 0 && isUpdateZero) {
                this.label.string = v + '';
                this._value = 0;
                this._newValue = 0;
            }
            return;
        }

        if (v == null || isNaN(v) || v == undefined) {
            this._label.string = '';
            this._value = 0;
            this._newValue = 0;
            return;
        }

        this._decimal = CommonUtils.getRollFormatDecimal(v, this._value, time);
        // 结束上一次的滚动
        if (this._duration != this._elapsed) {
            this._duration = this._elapsed = 0;
            this._value = this._newValue;
            this.updateLabel(this._value);
            this.runResolve();
        }

        // time = 0 直接设置值
        if (time <= 0) {
            this._value = v;
            this._newValue = v;
            this.updateLabel(v);
            return;
        }

        this._duration = time;
        this._elapsed = 0;

        this._distance = v - this._value;

        this._newValue = v;

        return new Promise((resolve) => {
            this.resolve = resolve as () => void;
        });
    }

    /**
     * 格式化数字
     * @param format (v: 当前滚动值, decimal:如果是金额单位，需要传入保留小数位数): {value: 格式化后的结果, isAmount: 是否是金额}
     */
    public format(format: (v: number, decimal: number) => { value: string; isAmount: boolean }) {
        this._handler.format = format;
    }

    /**
     * 监听数值变化
     * @param handler
     * @param target
     * @returns
     */
    public onValueUpdate(handler: (v: number) => void, target?: any) {
        if (this._onValueUpdateHandler.has(handler)) {
            return;
        }
        target = target ?? null;
        this._onValueUpdateHandler.set(handler, target);
    }

    protected updateLabel(v: number) {
        const isLast = this._value == this._newValue;
        if (isLast) {
            this._decimal = we.core.flavor.getDecimalPlace();
        }

        // 格式化数值，并检查小数位
        const fromatResult = this._handler.format(v, this._decimal);
        const formatStr = fromatResult.isAmount && !isLast ? CommonUtils.completingDecimal(fromatResult.value, this._decimal) : fromatResult.value;
        this.label.string = formatStr;

        this._onValueUpdateHandler.forEach((target, fn) => {
            this.runCall(fn, target, v);
        });
    }

    protected update(dt: number): void {
        if (this._elapsed == this._duration) {
            return;
        }

        const oldV = Math.floor((this._elapsed / this._duration) * this._distance + this._value);

        this._elapsed += dt;

        if (this._elapsed >= this._duration) {
            this._elapsed = this._duration;
        }

        const ratio = this._elapsed / this._duration;

        const v = Math.floor(this._value + this._distance * ratio);

        if (oldV != v) {
            this.updateLabel(v);
        }

        if (this._elapsed == this._duration) {
            this._elapsed = this._duration = 0;
            this._value = this._newValue;
            this.updateLabel(this._newValue);
            this.runResolve();
        }
    }

    private runResolve() {
        const resolve = this.resolve;
        this.resolve = null;
        resolve?.();
    }

    public async runCall<T extends (...args: any[]) => any>(call: T, target?: any, ...args: Parameters<T>): Promise<ReturnType<T>> {
        call = target ? call.bind(target) : call;
        const res = await call(...args);
        return res;
    }
}

we.ui.WELabelRoll = WELabelRoll;
