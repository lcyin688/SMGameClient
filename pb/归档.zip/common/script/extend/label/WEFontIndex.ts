const { ccclass, property, executeInEditMode, requireComponent, menu } = cc._decorator;

declare global {
    interface IUI {
        WEFontIndex: typeof WEFontIndex;
    }

    namespace we {
        namespace ui {
            type WEFontIndex = InstanceType<typeof WEFontIndex>;
        }
    }
}

/**
 * 多字体切换支持
 * 支持多语言字体
 */
@ccclass
@executeInEditMode
@requireComponent(cc.Label)
@menu('we/label/WEFontIndex(字体改变)')
export default class WEFontIndex extends cc.Component {
    @property({
        type: [cc.Font],
        tooltip: CC_DEV && 'Label将会用到的字体库',
    })
    fonts: Array<cc.Font> = [null];

    @property({
        tooltip: CC_DEV && '当前使用的字体',
        override: true,
    })
    get index() {
        return this._index;
    }
    set index(value: number) {
        this.setIndex(value);
    }

    @property
    private _index: number = 0;

    /**
     * 设置字体，通过字体文件名字
     * @param fontName
     * @returns
     */
    setFont(fontName: string) {
        const fontIndex = this.fonts.findIndex((font) => {
            return font.name === fontName;
        });
        if (!fontIndex) {
            we.warn(`WEFontIndex setFont, font is non-existent, fontName: ${fontName}`);
            return;
        }

        this.setIndex(fontIndex);
    }

    public setIndex(value: number) {
        if (value < 0) {
            return;
        }
        this._index = value % this.fonts.length;
        const label = this.node.getComponent(cc.Label);

        if (CC_EDITOR || !this.getComponent(we.ui.WEI18nFont)) {
            label.font = this.fonts[this._index];
        } else {
            if (this.getComponent(we.ui.WEI18nFont)) {
                this.getComponent(we.ui.WEI18nFont).setFont(this.fonts[this._index]);
            }
        }
    }
}

we.ui.WEFontIndex = WEFontIndex;
