const { ccclass, property, menu } = cc._decorator;

/**
 * 单纯的滚动文字
 */
@ccclass()
@menu('we/label/WELabelSlide(字体滑动)')
export default class WELabelSlide extends cc.Component {
    @property({ type: cc.Node, tooltip: CC_DEV && '容器节点' })
    private view: cc.Node = null;

    @property({ type: cc.Label, tooltip: CC_DEV && '文本组件' })
    private label: cc.Label = null;

    @property({ type: cc.Integer, tooltip: CC_DEV && '每帧移动的像素' })
    private speed: number = 2;

    @property({ type: cc.Integer, tooltip: CC_DEV && '超过（包含）多少字符开始滚动' })
    private long: number = 12;

    @property({ type: cc.Integer, tooltip: CC_DEV && '内容显示长度超过多少开始滚动' })
    private str_width: number = 200;

    start() {
        this.label.node.setAnchorPoint(0, 0.5);
    }

    protected update(dt: number) {
        if (this.label.string.length >= this.long || this.label.node.width > this.str_width) {
            this.node.getComponent(cc.Mask).enabled = true;
            this.label.node.x -= this.speed;
            if (this.label.node.x <= -this.label.node.width - this.node.width) {
                this.label.node.x = this.view.width;
            }
        } else {
            this.node.getComponent(cc.Mask).enabled = false;
            this.label.node.setPosition(0, 0);
        }
    }
}
