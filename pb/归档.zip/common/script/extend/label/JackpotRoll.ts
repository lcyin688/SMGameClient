import { WELabelRoll } from './WELabelRoll';

declare global {
    interface IUI {
        JackpotRoll: typeof JackpotRoll;
    }

    namespace we {
        namespace ui {
            type JackpotRoll = InstanceType<typeof JackpotRoll>;
        }
    }
}

const { ccclass, property, menu, requireComponent } = cc._decorator;

@ccclass
@requireComponent(WELabelRoll)
@menu('we/feat/JackpotRoll(数字滚动)')
export class JackpotRoll extends cc.Component {
    @property({ tooltip: CC_DEV && '是否是滚动值，子游戏中有些jackpot奖池不会滚动直接设置值' })
    public isRoll: boolean = false;

    @property({ tooltip: CC_DEV && '滚动时间' })
    public rollTime: number = 0;

    private _labelRoll: WELabelRoll = null;
    protected get labelRoll() {
        if (!this._labelRoll) {
            this._labelRoll = this.node.getComponent(WELabelRoll);
        }

        return this._labelRoll;
    }

    /** 本次的滚动值 */
    private _currValue = 0;

    /** 滚动门槛，0 无门槛 */
    private _threshold = 0;

    private _baseBet = 0;

    private _betIsChange = false;

    /**
     * 设置滚动门槛,basBet必须 >= 此门槛才会滚动
     * @param v 滚动门槛
     */
    public setThreshold(v: number) {
        this._threshold = v;
    }

    /**
     * 更新基础押注，判断是否达到投注门槛
     * @param v
     */
    public updateBaseBet(v: number) {
        this._baseBet = v;
        this._betIsChange = true;
    }

    public setValue(v: number) {
        const prevValue = this._currValue;

        this._currValue = v;

        const diff = v - prevValue;

        // 不变则不滚动
        if (diff == 0) {
            return;
        }

        // 押注减小并且达到押注滚动门槛
        if (this._betIsChange && this.isRoll && this._threshold > 0 && this._baseBet >= this._threshold) {
            this.roll(diff);
            return;
        }

        // 	没到门槛或者不滚或者池变小直接设置值
        if ((this._threshold > 0 && this._baseBet < this._threshold) || !this.isRoll || diff < 0) {
            this.labelRoll.setValue(v, 0);
            return;
        }

        this.roll(diff);
    }

    /**
     * 按照滚动规则滚动
     * @param diff
     * @returns
     */
    private roll(diff: number) {
        // 滚动值达到100000时的滚动方法
        if (this._currValue >= this.alignPreci(100000)) {
            if (diff < this.alignPreci(1000) && diff > 0) {
                this.labelRoll.setValue(this._currValue, this.rollTime);
                return;
            }

            // 达到门槛并且可以滚动则只滚动后三位
            this.labelRoll.setValue(this._currValue - this.alignPreci(999), 0);
            this.labelRoll.setValue(this._currValue, this.rollTime);
            return;
        }

        // 值 >= 10000
        if (this._currValue >= this.alignPreci(10000)) {
            if (diff < this.alignPreci(100) && diff > 0) {
                this.labelRoll.setValue(this._currValue, this.rollTime);
                return;
            }
            // 达到门槛并且可以滚动则只滚动后三位
            this.labelRoll.setValue(this._currValue - this.alignPreci(99), 0);
            this.labelRoll.setValue(this._currValue, this.rollTime);
            return;
        }

        if (diff < 0) {
            this.labelRoll.setValue(this._currValue, 0);
            return;
        }
        this.labelRoll.setValue(this._currValue, this.rollTime);
    }

    /**
     * 对齐价格进度，对于有加减固定 元来作为滚动单位
     */
    private alignPreci(amout: number) {
        return we.core.flavor.getAmountPrecision() * amout;
    }
}

we.ui.JackpotRoll = JackpotRoll;
