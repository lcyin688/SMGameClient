const { ccclass, property, menu, requireComponent, executeInEditMode } = cc._decorator;

declare global {
    interface IUI {
        WELabelLongLimit: typeof WELabelLongLimit;
    }
    namespace we {
        namespace ui {
            type WELabelLongLimit = InstanceType<typeof WELabelLongLimit>;
        }
    }
}

/**
 * label 文字显示长度限制
 */
@ccclass()
@requireComponent(cc.Label)
@executeInEditMode()
@menu('we/label/WELabelLongLimit(文字超出显示...)')
export default class WELabelLongLimit extends cc.Component {
    @property
    _max_width: number = 300;
    @property({ tooltip: CC_DEV && '显示最大宽度' })
    set max_width(value: number) {
        this._max_width = value;
        this.bUpdate = true;
        if (CC_EDITOR && value < 99) {
            return;
        }
        this.onMessageSizeChanged();
    }
    get max_width(): number {
        return this._max_width;
    }

    private label: cc.Label = null;

    oldLabelString: string = '';

    bUpdate: boolean = true;

    onLoad() {
        this.label = this.node.getComponent(cc.Label);
        this.onMessageSizeChanged();
    }

    start() {
        this.node.on(cc.Node.EventType.SIZE_CHANGED, this.onMessageSizeChanged, this);
    }

    onDestroy() {
        this.node.off(cc.Node.EventType.SIZE_CHANGED, this.onMessageSizeChanged, this);
    }

    onMessageSizeChanged() {
        if (!cc.isValid(this.label)) {
            return;
        }
        this.oldLabelString = this.label.string;
        this.label['_forceUpdateRenderData']();
        if (this.node.width > this.max_width && this.bUpdate == true) {
            this.bUpdate = false;
            const oneLong = this.node.width / this.oldLabelString.length;
            const diff = this.node.width - this.max_width;
            const amount = Math.ceil(diff / oneLong);
            const i = oneLong < 14 ? 2 : 1;
            this.label.string = this.oldLabelString.slice(0, -amount - i) + '...';
            this.label['_forceUpdateRenderData']();
        } else {
            this.bUpdate = true;
        }
    }
}

we.ui.WELabelLongLimit = WELabelLongLimit;
