const { ccclass, property, requireComponent, disallowMultiple, menu } = cc._decorator;
declare global {
    interface IUI {
        WELabelAutoWidth: typeof WELabelAutoWidth;
    }

    namespace we {
        namespace ui {
            type WELabelAutoWidth = InstanceType<typeof WELabelAutoWidth>;
        }
    }
}
/**
 * Label 自动宽度适配器
 * 1、可设置最大宽度，达到最大宽度后文字会进行缩小
 * 2、可设置字体最小字号，当字体缩小到最小字号时，则不会继续缩放，此时可能会超框
 * 3、可设置适配节点，适配节点会跟距label的宽度变化而变化，当label宽度达到设定的最大宽度后不会继续增长，label宽度达到设定的最小宽度后，适配节点的宽度也不会继续缩小
 * 4、fontScaleStep 字号步设置合适的值，值越小递归次数越多，因为每次递归都会强制渲染这个Label，所以请设置合适的步进值
 */
@ccclass
@requireComponent(cc.Label)
@disallowMultiple()
@menu('we/label/WELabelAutoWidth(文字自适应宽度)')
export default class WELabelAutoWidth extends cc.Component {
    @property(cc.Label)
    private _label: cc.Label = null;

    @property({ type: cc.Label, tooltip: CC_DEV && 'Label节点' })
    get label() {
        if (!this._label) {
            this._label = this.node.getComponent(cc.Label);
        }
        return this._label;
    }
    set label(v) {
        this._label = v;
    }

    @property({ tooltip: '' })
    private _maxFontSize: number = -1;

    @property({ tooltip: CC_DEV && '最大字体字号\n一般为设计大小' })
    get maxFontSize() {
        if (this._maxFontSize < 0) {
            this._maxFontSize = this.label?.fontSize ?? 1;
        }
        return this._maxFontSize;
    }
    set maxFontSize(v) {
        v = v <= 0 ? 1 : v;
        this._maxFontSize = v;
        this.label && (this.label.fontSize = v);
    }

    @property({ tooltip: CC_DEV && '最小字体字号\n文字字体最小能缩到多少' })
    minFontSize = 0;

    @property({ tooltip: CC_DEV && '最大宽度\nlabel的最大宽度\n超过宽度后会开始缩小字体' })
    maxWidth: number = 0;

    @property({ tooltip: CC_DEV && '最小宽度\n一般为设计宽度' })
    minWidth: number = 0;

    @property({ tooltip: CC_DEV && '字体缩放步进\n设置适量的步进值，防止递归次数过多，值越小，递归次数越多' })
    fontScaleStep = 0.1;

    @property({ type: cc.Node, tooltip: CC_DEV && '适配节点\n需要适应label宽度的节点' })
    adapterNodes: cc.Node[] = [];

    /** 记录适配节点的原始尺寸 */
    private _adapterOriginSzieMap: Map<cc.Node, cc.Size> = new Map();

    protected __preload() {
        this.init();
    }

    protected onLoad(): void {}

    protected init() {
        // 裁剪模式设置为不裁剪
        if (this.label.overflow !== cc.Label.Overflow.NONE) {
            this.label.overflow = cc.Label.Overflow.NONE;
        }

        // 检查设置的最小字号
        this.minFontSize = this.minFontSize < 0 ? 0 : this.minFontSize;
        // 保留原始尺寸
        for (const item of this.adapterNodes) {
            this._adapterOriginSzieMap.set(item, cc.size(item.width, item.height));
        }

        // 保留原始尺寸大小
        this.maxFontSize = this.label.fontSize;

        // 监听文字宽度变化
        this.proxySizeChange();
    }

    protected proxySizeChange() {
        const size: cc.Size = this.label.node['_contentSize'];
        this.label.node['_contentSize'] = new Proxy(size, {
            set: (t, k, v, r) => {
                const ref = Reflect.set(t, k, v, r);
                k === 'width' && this.widthChange(v);
                return ref;
            },
        });
    }

    private isChangeIngSub = false;
    private isChangeIngAdd = false;
    /**
     * 如果
     */
    private widthChange(width: number) {
        // 检测字号是否减小
        if (this.checkFontSizeSub(width)) {
            return;
        }

        // 检测字号是否增加
        if (this.checkFontSizeAdd(width)) {
            return;
        }

        // 常规匹配
        this.isChangeIngAdd = false;
        this.isChangeIngSub = false;
        this.AdpaterWidth(width);
    }

    /**
     * 检测是否减小字号
     */
    private checkFontSizeSub(labelWidth: number) {
        if (labelWidth <= this.maxWidth) {
            return false;
        }

        if (this.isChangeIngAdd || this.label.fontSize <= 0 || this.label.fontSize <= this.minFontSize) {
            this.isChangeIngSub = false;
            return this.label.fontSize <= this.minFontSize;
        }

        this.isChangeIngSub = true;

        this.AdpaterWidth(labelWidth);
        const fontSize = this.label.fontSize - this.fontScaleStep;
        if (fontSize <= 0) {
            return false;
        }

        this.label.fontSize = fontSize;
        // 强制更新
        this.label['_forceUpdateRenderData']();
        return true;
    }

    /**
     * 检查是否增加字号
     * @param labelWidth
     * @returns
     */
    private checkFontSizeAdd(labelWidth: number) {
        // 检测不通过
        if (labelWidth >= this.maxWidth) {
            return false;
        }

        // 如果字体正在减小，切字体 >= 设定最大字体 则不处理
        if (this.isChangeIngSub || this.label.fontSize >= this.maxFontSize) {
            this.isChangeIngAdd = false;
            return false;
        }

        this.isChangeIngAdd = true;
        this.AdpaterWidth(this.maxWidth);
        let nextSize = this.label.fontSize + this.fontScaleStep;
        nextSize >= this.maxFontSize && (nextSize = this.maxFontSize);
        this.label.fontSize = nextSize;
        // 强制更新
        this.label['_forceUpdateRenderData']();
        return true;
    }

    protected AdpaterWidth(labelWidth: number) {
        if (this.minWidth == this.maxWidth) {
            return;
        }

        // 如果宽度 < 小于最小宽度，则所有被适配的节点保持原始大小
        if (labelWidth <= this.minWidth) {
            this._adapterOriginSzieMap.forEach((v, n) => {
                n.width = v.width;
            });
            return;
        }

        // 这个是新增长度
        const diff = labelWidth - this.minWidth;
        // 刷新长度
        this._adapterOriginSzieMap.forEach((v, n) => {
            const newWidth = v.width + diff;
            n.width = newWidth;
        });
    }
}

we.ui.WELabelAutoWidth = WELabelAutoWidth;
