import { WESuperPageViewHorizontal } from './WESuperPageViewHorizontal';
import WESuperPageViewIndicator from './WESuperPageViewIndicator';
import { dapterCls, OpacityType, VirtuaNode } from './WESuperPageViewTypes';
import { WESuperPageViewVertical } from './WESuperPageViewVertical';

const { ccclass, property, menu } = cc._decorator;

type WESuperPageViewType = typeof WESuperPageView;
declare global {
    interface IUI {
        WESuperPageView: WESuperPageViewType;
    }

    namespace we {
        namespace ui {
            type WESuperPageView = InstanceType<WESuperPageViewType>;
        }
    }
}

@ccclass
@menu('we/scroll/WESuperPageView(页面分页控件)')
export default class WESuperPageView extends cc.Component {
    static Direction = cc.PageView.Direction;
    static SizeMode = cc.PageView.SizeMode;

    @property({ type: cc.Node })
    private _view: cc.Node = null;

    @property({ type: cc.Node, tooltip: CC_DEV && 'view节点' })
    public set view(node: cc.Node) {
        this._view = node;
        // this.initView();
    }
    public get view() {
        return this._view;
    }

    @property({ type: cc.Node })
    private _content: cc.Node = null;

    @property({ type: cc.Node, tooltip: CC_DEV && '内容区' })
    public set content(node: cc.Node) {
        this._content = node;
        // this.initContent();
    }
    public get content() {
        return this._content;
    }

    @property({ type: cc.Enum(cc.PageView.Direction), tooltip: CC_DEV && '滚动方向' })
    public direction: cc.PageView.Direction = cc.PageView.Direction.Horizontal;

    @property({ type: cc.Enum(cc.PageView.SizeMode), tooltip: CC_DEV && '页面大小类型\nFree:页面大小跟元素大小一致\nUnified:每页大小跟view元素大小一致' })
    public sizeMode: cc.PageView.SizeMode = cc.PageView.SizeMode.Unified;

    @property({ tooltip: CC_DEV && '翻页动画时长' })
    public duration: number = 0.25;

    @property({
        type: cc.Enum(OpacityType),
        tooltip: CC_DEV && '透明度类型\n Gradient:透明度随着位置变化\nNormal:透明度要么完全透明，要么不透明',
    })
    public opacityType: OpacityType = OpacityType.Gradient;

    @property({ tooltip: CC_DEV && '是否无限循环' })
    public infinite = false;

    @property({
        tooltip: CC_DEV && '是否开启虚拟分页',
        visible: function () {
            return !this.infinite;
        },
    })
    public virtua = false;

    @property({ type: cc.Node, tooltip: CC_DEV && '上一页按钮' })
    public prevPageBtn: cc.Node = null;

    @property({ type: cc.Node, tooltip: CC_DEV && '下一页按钮' })
    public nextPageBtn: cc.Node = null;

    @property({ type: WESuperPageViewIndicator, tooltip: CC_DEV && '指示器' })
    public indicator: WESuperPageViewIndicator = null;

    private _pageCount = 0;

    public get pageCount() {
        return this._pageCount;
    }

    /**
     * 获取当前页码
     */
    public get pageIndex() {
        return this.adater?.pageIndex ?? 0;
    }

    private adater: dapterCls = null;

    private isRegisterEv = false;

    protected __preload() {
        if (this.direction == cc.PageView.Direction.Horizontal) {
            this.adater = new WESuperPageViewHorizontal({
                node: this.node,
                view: this.view,
                content: this.content,
                sizeMode: this.sizeMode,
                infinite: this.infinite,
                virtua: this.virtua,
                opacityType: this.opacityType,
                indicator: this.indicator,
                duration: this.duration,
            });
        } else {
            this.adater = new WESuperPageViewVertical({
                node: this.node,
                view: this.view,
                content: this.content,
                sizeMode: this.sizeMode,
                infinite: this.infinite,
                virtua: this.virtua,
                opacityType: this.opacityType,
                indicator: this.indicator,
                duration: this.duration,
            });
        }
    }

    protected onLoad(): void {}

    public init(opts: { preCreate?: number; pageCount: number }) {
        this.adater?.start(opts);
        this.registerEv();
        this.indicator?.init(opts.pageCount, this);
        this._pageCount = opts.pageCount;
    }

    public getCurPage() {
        return this.adater.getCurPage();
    }

    private registerEv() {
        if (this.isRegisterEv) {
            return;
        }
        this.isRegisterEv = true;
        this.adater?.registerEvent();
        cc.isValid(this.prevPageBtn) && we.ui.UIViewHelper.onBtnClick(this.prevPageBtn, this.prevPageEv.bind(this), false, this);
        cc.isValid(this.nextPageBtn) && we.ui.UIViewHelper.onBtnClick(this.nextPageBtn, this.nextPageEv.bind(this), false, this);
    }

    private unregisterEv() {
        this.adater?.unregisterEvent();
    }

    public onCreateItem(callback: (pageIndex: number) => cc.Node) {
        this.adater?.onCreateItem(callback);
    }

    public onPutItem(callback: (node: cc.Node, pageIndex: number) => void) {
        this.adater?.onPutItem(callback);
    }

    /**
     * 监听页面移动
     * @param callback (node: 移动的节点, raito: 离开或者进入可视区域的比例 0 - 1，)
     */
    public onPageMove(callback: (node: cc.Node, ratio: number) => void) {
        this.adater?.onPageMove(callback);
    }

    /**
     * 页面改变时
     * @param callBack
     */
    public onPageChange(callBack: (pageIndex: number) => void) {
        this.adater.onPageChange(callBack);
    }

    /**
     * 跳转至某个页面
     * @param index
     * @param duration
     */
    public scrollToPage(index: number, duration = 0) {
        this.adater?.scrollToPage(index, duration);
    }

    private prevPageEv() {
        if (this.prevPageBtn['__iswait']) {
            return;
        }
        this.prevPageBtn['__iswait'] = true;

        this.adater?.scrollToPrevPage();

        this.scheduleOnce(() => {
            this.prevPageBtn['__iswait'] = false;
        }, 0.1);
    }

    private nextPageEv() {
        if (this.nextPageBtn['__iswait']) {
            return;
        }
        this.nextPageBtn['__iswait'] = true;

        this.adater?.scorllToNextPage();

        this.scheduleOnce(() => {
            this.nextPageBtn['__iswait'] = false;
        }, 0.1);
    }

    protected onDestroy(): void {
        this.unregisterEv();
        this.adater.destroy();
    }
}

we.ui.WESuperPageView = WESuperPageView;
