const { ccclass, property, menu } = cc._decorator;

type WESuperPageViewIndicatorType = typeof WESuperPageViewIndicator;
declare global {
    interface IUI {
        WESuperPageViewIndicator: WESuperPageViewIndicatorType;
    }

    namespace we {
        namespace ui {
            type WESuperPageViewIndicator = InstanceType<WESuperPageViewIndicatorType>;
        }
    }
}

/**
 * 选中时正常节点的状态设置
 */
enum CoverTypeEnum {
    /** 隐藏 */
    hide = 0,
    /** 覆盖 */
    cover = 1,
}

enum ChangeTypeEnum {
    /** 动画移动 */
    anim = 1,
    /** 直接设置 */
    set = 2,
}

@ccclass
@menu('we/scroll/WESuperPageViewIndicator(页面分页控件指示器)')
export default class WESuperPageViewIndicator extends cc.Component {
    @property({ type: cc.Node, tooltip: CC_DEV && '选中节点' })
    public select: cc.Node = null;

    @property({ type: cc.Node, tooltip: CC_DEV && '未选中节点' })
    public normal: cc.Node = null;

    @property({
        type: cc.Enum(CoverTypeEnum),
        tooltip:
            CC_DEV &&
            `
        节点选中后默认节点的隐藏方式
        cover: 覆盖在原来节点上
        hide: normal节点隐藏
        默认 cover
        `,
    })
    public coverType: CoverTypeEnum = CoverTypeEnum.cover;

    @property({
        type: cc.Enum(ChangeTypeEnum),
        tooltip:
            CC_DEV &&
            `
        选中时指示器的动画方式
        set: 直接设置
        anim: 动画
        默认值 set
        `,
    })
    public changeType: ChangeTypeEnum = ChangeTypeEnum.set;

    @property({ tooltip: CC_DEV && '点击是否可切换页面' })
    private changeClick = false;

    private _contentNode: cc.Node = null;

    private selectNodes: cc.Node[] = [];

    private _currPageIndex = -1;

    private pageView: we.ui.WESuperPageView = null;

    private tween: cc.Tween = null;

    /**
     * 初始化指示器
     * @param pageCount
     * @returns
     */
    public init(pageCount: number, pageView: we.ui.WESuperPageView) {
        if (!this.select || !this.normal) {
            return;
        }
        this.pageView = pageView;

        !this._contentNode && (this.select.active = false);
        this.normal.active = false;

        const createCount = pageCount - this.selectNodes.length;
        if (createCount == 0) {
            return;
        }
        this.crateContentNode();

        if (createCount < 0 && this.selectNodes.length > 0) {
            for (let i = createCount; i < 0; i++) {
                const node = this.selectNodes.pop();
                node.destroy();
            }

            this.resetPageIndex();
            return;
        }

        if (createCount > 0) {
            for (let i = 0; i < createCount; i++) {
                const index = this.selectNodes.length;
                const node = cc.instantiate(this.normal);
                this._contentNode.addChild(node);
                node.active = true;
                this.selectNodes.push(node);
                node['__pageIndex'] = index;
                this.registerEvent(node);
            }

            this.resetPageIndex();
        }
    }

    /**
     * 注册指示器事件
     * @param node
     * @returns
     */
    private registerEvent(node: cc.Node) {
        if (!this.changeClick) {
            return;
        }
        node.on(cc.Node.EventType.TOUCH_END, this.itemClick, this);
    }

    /**
     * 指示器点击
     * @param event
     */
    private itemClick(event: cc.Event) {
        const node: cc.Node = event.target;
        const pageIndex = node['__pageIndex'];
        this.pageView?.scrollToPage(pageIndex, 0.2);
    }

    /**
     * 设置下标
     * @param index
     */
    public setIndex(index: number) {
        if (!this._contentNode) {
            return;
        }

        index = index >= this.selectNodes.length ? this.selectNodes.length - 1 : index;
        index = index < 0 ? 0 : index;

        const currPageIndex = this._currPageIndex;

        this._currPageIndex = index;

        const normalNode = this.selectNodes[index];

        const pos = this.node.convertToNodeSpaceAR(this._contentNode.convertToWorldSpaceAR(normalNode.getPosition()));

        let isAnim = this.changeType == ChangeTypeEnum.anim;
        this.selectNodes.forEach((node) => {
            node.opacity = 255;
        });

        this.tween?.stop();

        const completeFn = () => {
            this.tween = null;
            const cover = this.coverType == CoverTypeEnum.cover;
            if (cover) {
                return;
            }
            normalNode.opacity = 0;
        };

        // 最后一页指示打第一页指示
        if (currPageIndex == this.pageView.pageCount - 1 && index == 0) {
            isAnim = false;
        } else if (currPageIndex == 0 && index == this.pageView.pageCount - 1) {
            isAnim = false;
        }

        this.tween = cc
            .tween(this.select)
            .delay(0)
            .to(isAnim ? 0.2 : 0, { position: pos, opacity: 255 })
            .call(completeFn)
            .start();
    }

    /**
     * 重置选中位置
     */
    private resetPageIndex() {
        if (this._currPageIndex < 0) {
            this._currPageIndex = 0;
        }

        if (this._currPageIndex >= this.selectNodes.length) {
            this._currPageIndex = this.selectNodes.length - 1;
        }
        this.select.active = true;
        this.scheduleOnce(() => {
            const normalNode = this.selectNodes[this._currPageIndex];
            const pos = this.node.convertToNodeSpaceAR(this._contentNode.convertToWorldSpaceAR(normalNode.getPosition()));
            this.select.setPosition(pos);
        }, 0);
    }

    private crateContentNode() {
        if (this._contentNode) {
            return;
        }
        this._contentNode = new cc.Node('contentNode');
        this.node.addChild(this._contentNode);
        const layout = this._contentNode.addComponent(cc.Layout);

        layout.type = cc.Layout.Type.HORIZONTAL;
        layout.resizeMode = cc.Layout.ResizeMode.CONTAINER;

        this._contentNode.zIndex = 1;
        this.select.zIndex = 2;
    }
}

we.ui.WESuperPageViewIndicator = WESuperPageViewIndicator;
