export interface VirtuaNode extends cc.Node {
    /** 页面虚拟下标 【-∞,+∞】 */
    virtuaPageIndex: number;
    /** 页面宽度 */
    pageWidth: number;
    /** 页面高度 */
    pageHeight: number;
    /** 当前页在Content的位置 */
    pagePos: cc.Vec2;
    worldPos: cc.Vec2;
    /** 在view同级的本地坐标 */
    viewPos: cc.Vec2;
    /** 相交比例 */
    intersectRatio: number;
}

export interface constructorOpts {
    node: cc.Node;
    view: cc.Node;
    content: cc.Node;
    sizeMode: cc.PageView.SizeMode;
    infinite: boolean;
    preCreateCount?: number;
    virtua: boolean;
    opacityType: OpacityType;
    indicator: we.ui.WESuperPageViewIndicator;
    duration: number;
}

export interface dapterCls {
    start(otps: { preCreate?: number; pageCount: number }): void;
    registerEvent(): void;
    unregisterEvent(): void;
    onCreateItem(callback: (pageIndex: number) => cc.Node): void;
    onPutItem(callback: (node: cc.Node, pageIndex: number) => void);
    onPageChange(callBack: (pageIndex: number) => void): void;
    scrollToPage(index: number, duration?: number): void;
    scrollToPrevPage(): void;
    scorllToNextPage(): void;
    getCurPage(): cc.Node;
    /** 监听页面移动 */
    onPageMove(callback: (node: cc.Node, ratio: number) => void): void;
    pageIndex: number;
    destroy(): void;
}

export enum OpacityType {
    /** 跟随位置透明度渐变 */
    Gradient,
    /** 透明度只有完全透明或者不透明 */
    Normal,
}

/** 移动状态 枚举 */
export enum MoveType {
    /** 开始 */
    START,
    /** 可移动 */
    MOVE,
    /** 禁止移动 */
    DISABLE,
}
