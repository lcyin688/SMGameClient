import { constructorOpts, dapterCls, MoveType, OpacityType, VirtuaNode } from './WESuperPageViewTypes';

export class WESuperPageViewVertical implements dapterCls {
    private node: cc.Node = null;

    private view: cc.Node = null;

    private content: cc.Node = null;

    private indicator: we.ui.WESuperPageViewIndicator = null;

    private sizeMode: cc.PageView.SizeMode;
    private infinite: boolean;
    private pageCount: number;
    private virtua: boolean;
    private opacityType: OpacityType = OpacityType.Gradient;
    private duration: number = 0.25;

    /** 节点创建函数 */
    private createFunc = (pageIndex: number) => {
        return null;
    };

    /** 节点回收函数 */
    private putFunc = (node: cc.Node, pageIndex: number) => {};

    /** 移动监听函数 */
    private posChangeFn = (oldY: number, newY: number) => {};

    /**
     * 监听页面移动
     * @param node
     * @param ratio
     */
    private onPageMoveFn = (node: cc.Node, ratio: number) => {};

    /**
     * 页面改变
     * @param pageIndex
     */
    private onPageChangeFn = (pageIndex: number) => {};

    private isActive = false;

    /**
     * 当前虚拟列表节点
     */
    private _virtuaNodeList: Map<number, VirtuaNode> = new Map();

    /**
     * 页码记录
     */
    private _pageIndexList: number[] = [];

    private __pageIndex = 0;

    /**
     * 当前页码
     */
    private set _pageIndex(idx: number) {
        this.__pageIndex = idx;
        this.indicator?.setIndex(this.pageIndex);
        this.onPageChangeFn?.(idx);
    }

    private get _pageIndex() {
        return this.__pageIndex;
    }

    /**
     * 获取当前页码
     */
    public get pageIndex() {
        return this.getPageIndx(this._pageIndex);
    }

    /**
     * 静止时的位置
     */
    private pos: cc.Vec2 = cc.v2(0, 0);

    /**
     * 记录翻页条件是的位置
     */
    private movey = 0;

    /**
     * 实时位置
     */
    private contentPos: cc.Vec2 = null;

    /**
     * 底部对齐位置
     */
    private bottomWidgetY = 0;

    /**
     * 顶部对齐位置
     */
    private topWidgetY = 0;

    // 缓动
    private tween: cc.Tween = null;

    /** 预创建页面数量 */
    public preCreateCount: number = 1;

    private _moveType: MoveType = MoveType.START;

    constructor(opts: constructorOpts) {
        this.node = opts.node;
        this.view = opts.view;
        this.content = opts.content;
        this.sizeMode = opts.sizeMode;
        this.infinite = opts.infinite;
        // 无限循环必然是虚拟列表
        this.virtua = opts.virtua || opts.infinite;

        this.opacityType = opts.opacityType ?? OpacityType.Gradient;
        this.indicator = opts.indicator;
        this.duration = opts.duration || 0.25;
    }

    destroy(): void {
        this?.tween?.stop?.();
    }

    public onCreateItem(callback: (pageIndex: number) => cc.Node) {
        this.createFunc = callback;
    }

    public onPutItem(callback: (node: cc.Node, pageIndex: number) => void) {
        this.putFunc = callback;
    }

    public onPageMove(callback: (node: cc.Node, ratio: number) => void) {
        this.onPageMoveFn = callback;
    }

    public start(otps: { preCreate?: number; pageCount: number }) {
        this.preCreateCount = otps.preCreate ?? 1;
        this.preCreateCount = this.preCreateCount < 1 ? 1 : this.preCreateCount;
        this.pageCount = otps.pageCount;

        this.isActive = cc.isValid(this.view) && cc.isValid(this.content);
        const self = this;

        if (this.infinite) {
            this.posChangeFn = this.testingAddInfinite.bind(this);
        } else if (!this.virtua) {
            this.posChangeFn = this.posChangeFnNoVirtua.bind(this);
        } else {
            this.posChangeFn = this.testingAddInfiniteVirtua.bind(this);
        }

        this.contentPos = new Proxy(cc.v2(0, 0), {
            set(target, key, newValue, receiver) {
                if (key == 'y' && cc.isValid(self.content)) {
                    self.content.setPosition(self.contentPos.x, newValue);
                    self.posChangeFn(self.contentPos.x, newValue);
                    self.updateOpacity(newValue);
                }
                return Reflect.set(target, key, newValue, receiver);
            },
        });

        this.init();
    }

    public registerEvent() {
        // 只有一页时禁止触摸事件
        if (this.pageCount <= 1) {
            return;
        }
        this.content.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.content.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.content.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.content.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
    }

    public unregisterEvent() {
        this.content.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.content.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.content.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.content.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
    }

    /**
     * 页面改变时
     * @param callBack
     */
    public onPageChange(callBack: (pageIndex: number) => void) {
        this.onPageChangeFn = callBack;
    }

    /**
     * 跳转至某个页面
     * @param index
     * @param duration
     */
    public scrollToPage(index: number, duration = 0) {
        index = index < 0 ? 0 : index;
        index = index >= this.pageCount ? this.pageCount - 1 : index;

        // 不是虚拟列表的跳转
        if (!this.virtua && !this.infinite) {
            this.scrollToPage1(index, duration);
            return;
        } else {
            this.scrollToPage2(index, duration);
        }
    }

    /**
     * 跳转到上一页
     */
    public scrollToPrevPage() {
        if (!this.infinite && this._pageIndex <= 0) {
            return;
        }
        const pageIndex = this._pageIndex - 1;
        const page = this._virtuaNodeList.get(pageIndex);
        this.tween = cc.tween(this.contentPos).to(this.duration, { y: page.pagePos.y }, { easing: 'sineOut' }).start();
    }

    /**
     * 下一页
     * @returns
     */
    public scorllToNextPage() {
        if (!this.infinite && this._pageIndex >= this.pageCount - 1) {
            return;
        }
        const pageIndex = this._pageIndex + 1;
        const page = this._virtuaNodeList.get(pageIndex);
        this.tween = cc.tween(this.contentPos).to(this.duration, { y: page.pagePos.y }, { easing: 'sineOut' }).start();
    }

    public getCurPage() {
        const pageIndex = this._pageIndex;
        const page = this._virtuaNodeList.get(pageIndex);
        return page;
    }

    /**
     * 不是无限循环，不是虚拟页面的跳页
     * @param index
     * @param duration
     */
    private scrollToPage1(index: number, duration = 0) {
        const page = this._virtuaNodeList.get(index);
        if (!page) {
            return;
        }
        cc.tween(this.contentPos)
            .to(duration, { y: page.pagePos.y }, { easing: 'sineOut' })
            .call(() => {
                this.contentPos.y = page.pagePos.y;
                this._pageIndex = index;
                this.onPageChangeFn?.(this.pageIndex);
            })
            .start();
    }

    /**
     * 虚拟列表跳转
     * @param index
     * @param duration
     */
    private scrollToPage2(index: number, duration = 0) {
        const currPageIndex = this.pageIndex;
        if (currPageIndex == index) {
            return;
        }
        const addInc = index < currPageIndex ? -1 : 1;
        const nextPageIndex = this._pageIndex + addInc;
        const page = this._virtuaNodeList.get(nextPageIndex);

        cc.tween(this.contentPos)
            .to(duration, { y: page.pagePos.y })
            .call(() => {
                this.scrollToPage2(index, duration);
            })
            .start();
    }

    private init() {
        if (!this.isActive) {
            return;
        }
        this.resetCelar();

        if (this.infinite) {
            this.initInfinite();
        } else {
            this.initNotInfinite2();
        }

        this.updateOpacity(0);
    }

    /**
     * 无限循环滚动初始化
     */
    private initInfinite() {
        this.content.height = 500;
        this.content.anchorY = 0.5;
        this.view.anchorY = 0.5;
        this.content.setPosition(0, 0);
        this.contentPos.x = 0;
        this.contentPos.y = 0;
        this.content.removeAllChildren();

        const firstNode: VirtuaNode = this.createFirstPage();

        this.content.height = firstNode.pageHeight;

        if (this.pageCount <= 1) {
            return;
        }

        for (let i = 0; i < this.preCreateCount; i++) {
            this.addBeforPage(null);
        }

        for (let i = 0; i < this.preCreateCount; i++) {
            this.addAfterPage(null);
        }
    }

    private initNotInfinite2() {
        this.content.anchorY = 0.5;
        this.view.anchorY = 0.5;
        this.content.setPosition(0, 0);
        this.contentPos.x = 0;
        this.contentPos.y = 0;

        // 虚拟列表
        if (this.virtua) {
            this.content.height = 500;
            this.content.removeAllChildren();
            const firstNode: VirtuaNode = this.createFirstPage();
            this.content.height = firstNode.pageHeight;

            if (this.pageCount > 1) {
                for (let i = 0; i < this.preCreateCount; i++) {
                    this.addAfterPage(null);
                }
            }

            this.topWidgetY = 0;

            const lastPage = this._virtuaNodeList.get(this._virtuaNodeList.size - 1);
            this.bottomWidgetY = lastPage.pagePos.y;
        } else {
            const child = this.content.children as VirtuaNode[];
            if (child.length == 0) {
                return;
            }
            this.pageCount = child.length;

            let width = 0;
            child.forEach((node, pageIndex) => {
                if (pageIndex == 0) {
                    this.createFirstPage(node);
                    width += node.pageHeight;
                    return;
                }

                if (this.pageCount <= 1) {
                    return;
                }

                this.addAfterPage(null, false, node);
                width += node.pageHeight;
            });
            this.content.height = width * 2;

            this.topWidgetY = 0;

            const lastPage = this._virtuaNodeList.get(child.length - 1);
            this.bottomWidgetY = lastPage.pagePos.y;
        }
    }

    /**
     * 设置或者创建第一页
     * @param node
     * @returns
     */
    private createFirstPage(node?: VirtuaNode) {
        const viewHeight = this.view.height;
        !cc.isValid(node) && (node = this.createFunc(0));

        if (!node) {
            return;
        }
        if (this.sizeMode == cc.PageView.SizeMode.Unified) {
            node.pageHeight = viewHeight > node.height ? viewHeight : node.height;
        } else {
            node.pageHeight = node.height;
        }

        node.pagePos = cc.v2(0, 0);
        node.virtuaPageIndex = 0;
        node.viewPos = cc.v2(0, 0);

        !node.parent && this.content.addChild(node);

        this._virtuaNodeList.set(0, node);
        !node.viewPos && (node.viewPos = cc.v2(0, 0));
        this._pageIndexList.push(0);

        let y = node.height * (node.anchorY - 0.5);

        node.setPosition(0, y);

        return node;
    }

    /**
     * 重置布局
     */
    private resetCelar() {
        this._virtuaNodeList.forEach((node) => {
            this.putNode(node);
        });

        this._pageIndexList.length = 0;
        this._virtuaNodeList.clear();
        this._pageIndex = 0;
        this.contentPos.y = 0;
        this.movey = 0;
        this.prevTestY = 0;
    }

    private putNode(node: VirtuaNode) {
        const pageIdx = this.getPageIndx(node.virtuaPageIndex);
        this.putFunc?.((<unknown>node) as cc.Node, pageIdx);
    }

    private onTouchStart(ev: cc.EventTarget) {
        this._moveType = MoveType.START;
        this.pos.y = this.movey = this.contentPos.y;
        this.tween?.stop();
        this.tween = null;
    }

    private onTouchMove(event: any) {
        this._moveType == MoveType.START && this.updateMoveDistance(event);
        this._moveType == MoveType.MOVE && this.updateMoveFunc(event);
    }

    private updateMoveDistance(event: any) {
        if (this._moveType != MoveType.START) {
            return;
        }

        const startPoint: cc.Vec2 = event.touch._startPoint;
        const point: cc.Vec2 = event.touch._point;

        const _distanceX = Math.abs(point.x - startPoint.x);
        const _distanceY = Math.abs(point.y - startPoint.y);
        const ratio = _distanceY / _distanceX;

        if (_distanceY > 5 && ratio <= 1) {
            this._moveType = MoveType.DISABLE;
            return;
        }
        _distanceY > 5 && ratio > 1 && (this._moveType = MoveType.MOVE);
    }

    private onTouchEnd(event: any) {
        this._moveType == MoveType.MOVE && this.updateMoveEndFunc();
    }

    /** 横向滚动并且没有无限循环 */
    private updateMoveFunc(event: any) {
        const startPoint: cc.Vec2 = event.touch._startPoint;
        const point: cc.Vec2 = event.touch._point;

        let _distanceY = point.y - startPoint.y;

        let y = this.pos.y + _distanceY;
        const viewHeight = this.view.height / 2;
        const pageNode = this._virtuaNodeList.get(this._pageIndex);

        // 下边超出边界
        if (!this.infinite && y > this.bottomWidgetY) {
            // 滑动前的跟左对齐的距离
            const recSpace = _distanceY - (y - this.bottomWidgetY);

            const space = Math.abs(y - this.bottomWidgetY);
            const ratio = viewHeight / (space + viewHeight);

            // 只对超出部分做缓冲计算
            _distanceY = recSpace + (_distanceY - recSpace) * ratio;
        } else if (!this.infinite && y < this.topWidgetY) {
            const recSpace = _distanceY - (y - this.topWidgetY);

            // 计算超出部分系数，超出越多，系数越小，超出距离跟滑动速度成反比
            const space = Math.abs(y - this.topWidgetY);
            const ratio = viewHeight / (space + viewHeight);

            // 只对超出部分做缓冲计算
            _distanceY = recSpace + (_distanceY - recSpace) * ratio;
        }

        this.contentPos.y = this.pos.y + _distanceY;
    }

    /**
     * 横线滚动拖动结束
     * @param _distanceY
     * @param _distanceY
     */
    private updateMoveEndFunc() {
        this.tweenHorizontalCurrPage();
    }

    private tweenHorizontalCurrPage() {
        const pageNode = this._virtuaNodeList.get(this._pageIndex);
        this.tween = cc.tween(this.contentPos).to(this.duration, { y: pageNode.pagePos.y }, { easing: 'sineOut' }).start();
    }

    // 上一次检测像素
    private prevTestY = 0;

    /**
     * 设置非无限循环的虚拟列表
     * @param oldY
     * @param currY
     */
    private testingAddInfiniteVirtua(oldY: number, currY: number) {
        // 超出边界不检查
        if (currY > this.bottomWidgetY || currY < this.topWidgetY) {
            return false;
        }
        // <小于10像素不检查
        if (Math.abs(currY - this.prevTestY) < 10) {
            return false;
        }

        const fristPage = this._virtuaNodeList.get(this._pageIndexList[0]);
        const lastPage = this._virtuaNodeList.get(this._pageIndexList[this._pageIndexList.length - 1]);

        this.prevTestY += currY - oldY > 0 ? 10 : -10;
        const pageIndex = this._pageIndex;
        const page = this._virtuaNodeList.get(pageIndex);
        // 获取content应该在的位置
        const centerY = page.pagePos.y;

        // 下滑
        if (currY < this.movey && currY <= centerY - this.view.height * 0.25) {
            this.movey = currY;
            if (this._pageIndex - 1 < 0) {
                return;
            }
            this.addBeforPage(null, false);
            !this.intersect(lastPage) && this.removeLastPage();
            this._pageIndex -= 1;
            return;
        }

        // 上滑
        if (currY > this.movey && currY >= centerY + this.view.height * 0.25) {
            this.movey = currY;
            // 页码数量不对
            if (this._pageIndex + 1 >= this.pageCount) {
                return;
            }
            const node = this.addAfterPage(null, false);
            !this.intersect(fristPage) && this.removeFirstPage();
            node && (this.bottomWidgetY = node.pagePos.y);
            this._pageIndex += 1;
            return;
        }
    }

    /**
     * 不是虚拟列表的检测
     * @param oldY
     */
    private posChangeFnNoVirtua(oldY: number, currY: number) {
        // 超出边界不检查
        if (currY > this.bottomWidgetY || currY < this.topWidgetY) {
            return false;
        }

        // <小于10像素不检查
        if (Math.abs(currY - this.prevTestY) < 10) {
            return false;
        }
        this.prevTestY += currY - oldY > 0 ? 10 : -10;

        const pageIndex = this._pageIndex;
        const page = this._virtuaNodeList.get(pageIndex);
        // 获取content应该在的位置
        const centerY = page.pagePos.y;

        // 下滑
        if (currY < this.movey && currY <= centerY - this.view.height * 0.25) {
            this.movey = currY;
            if (this._pageIndex - 1 < 0) {
                return;
            }
            this._pageIndex -= 1;
            return;
        }

        // 上划
        if (currY > this.movey && currY >= centerY + this.view.height * 0.25) {
            this.movey = currY;
            if (this._pageIndex + 1 >= this.pageCount) {
                return;
            }
            this._pageIndex += 1;
            return;
        }
    }

    /**
     * 检测页面的添加与删除
     * @param oldY
     * @param currY
     * @returns
     */
    private testingAddInfinite(oldY: number, currY: number) {
        // <小于10像素不检查
        if (Math.abs(currY - this.prevTestY) < 10) {
            return false;
        }

        this.prevTestY += currY - oldY > 0 ? 10 : -10;

        const pageIndex = this._pageIndexList[this.preCreateCount];

        const page = this._virtuaNodeList.get(pageIndex);
        // 获取content应该在的位置
        const centerY = page.pagePos.y;

        // 下滑
        if (currY < this.movey && currY <= centerY - this.view.height * 0.25) {
            this.movey = currY;
            this.addBeforPage(null, true);
            this._pageIndex -= 1;
            return;
        }

        // 上划
        if (currY > this.movey && currY >= centerY + this.view.height * 0.25) {
            this.movey = currY;
            this.addAfterPage(null, true);
            this._pageIndex += 1;
            return;
        }
    }

    /**
     * 在某个节点之前添加
     * @param prevNode 上一个页面
     * @param removeTest 是否删除第一个元素
     * @returns
     */
    private addBeforPage(prevNode: VirtuaNode | null, removeTest = false) {
        if (!prevNode) {
            const lastIndex = this._pageIndexList[0];
            prevNode = this._virtuaNodeList.get(lastIndex);
        }

        const _virtuaPageIndex = prevNode.virtuaPageIndex - 1;
        if ((!this.infinite && _virtuaPageIndex < 0) || this._virtuaNodeList.has(_virtuaPageIndex)) {
            return null;
        }

        const pageIndex = this.getPageIndx(_virtuaPageIndex);

        const node: VirtuaNode = this.createFunc(pageIndex);
        node.virtuaPageIndex = _virtuaPageIndex;

        this.content.addChild(node);
        this._virtuaNodeList.set(_virtuaPageIndex, node);
        !node.viewPos && (node.viewPos = cc.v2(0, 0));
        this._pageIndexList.unshift(_virtuaPageIndex);

        if (this.sizeMode == cc.PageView.SizeMode.Unified) {
            node.pageHeight = node.height > this.view.height ? node.height : this.view.height;
        } else {
            node.pageHeight = node.height;
        }

        // 获取真实位置
        let y = prevNode.position.y - prevNode.height * (prevNode.anchorY - 0.5);
        y = y + prevNode.pageHeight / 2 + node.pageHeight / 2 + node.height * (node.anchorY - 0.5);
        node.setPosition(0, y);

        let pageY = -(y - node.height * (node.anchorY - 0.5));
        node.pagePos = cc.v2(this.contentPos.x, pageY);

        this.updateContentHeight();

        this.updatePageOpacity(node);

        // 移除最后一个元素
        removeTest && this.removeLastPage();

        return node;
    }

    /**
     * 在之前添加页面
     * @param prevNode 上一个页面
     * @param removeTest 是否删除栈头
     * @returns
     */
    private addAfterPage(prevNode: VirtuaNode | null, removeTest = false, node?: VirtuaNode) {
        if (!prevNode) {
            const lastIndex = this._pageIndexList[this._pageIndexList.length - 1];
            prevNode = this._virtuaNodeList.get(lastIndex);
        }

        const _virtuaPageIndex = prevNode.virtuaPageIndex + 1;

        if ((!this.infinite && _virtuaPageIndex >= this.pageCount) || this._virtuaNodeList.has(_virtuaPageIndex)) {
            return null;
        }

        const pageIndex = this.getPageIndx(_virtuaPageIndex);
        !cc.isValid(node) && (node = this.createFunc(pageIndex));
        node.virtuaPageIndex = _virtuaPageIndex;
        !node.parent && this.content.addChild(node);

        this._virtuaNodeList.set(_virtuaPageIndex, node);
        this._pageIndexList.push(_virtuaPageIndex);
        !node.viewPos && (node.viewPos = cc.v2(0, 0));

        if (this.sizeMode == cc.PageView.SizeMode.Unified) {
            node.pageHeight = node.height > this.view.height ? node.height : this.view.height;
        } else {
            node.pageHeight = node.height;
        }

        // 获取真实位置
        let y = prevNode.position.y - prevNode.height * (prevNode.anchorY - 0.5);
        y = y - prevNode.pageHeight / 2 - node.pageHeight / 2 + node.height * (node.anchorY - 0.5);
        node.setPosition(0, y);

        let pageY = -(y - node.height * (node.anchorY - 0.5));
        node.pagePos = cc.v2(this.contentPos.x, pageY);

        this.updateContentHeight();

        this.updatePageOpacity(node);

        // 移除第一个元素
        removeTest && this.removeFirstPage();
        return node;
    }

    private updateContentHeight() {
        const findex = this._pageIndexList[0];
        const lindex = this._pageIndexList[this._pageIndexList.length - 1];
        const fPage = this._virtuaNodeList.get(findex);
        const lPage = this._virtuaNodeList.get(lindex);
        this.content.height = Math.max((Math.abs(fPage.pagePos.y) + this.view.height) * 2, (Math.abs(lPage.pagePos.y) + this.view.height) * 2);
    }

    /**
     * 获取真实页面下标
     * @param _pageIndex
     * @returns
     */
    private getPageIndx(_pageIndex: number) {
        const index = _pageIndex % this.pageCount;
        return index < 0 ? this.pageCount + index : index;
    }

    /**
     * 更新透明度
     * @param currY
     */
    private updateOpacity(currY: number) {
        // 边界不检测
        if (!this.infinite && (currY > this.bottomWidgetY || currY < this.topWidgetY)) {
            return;
        }

        this._virtuaNodeList.forEach((node, index) => {
            this.updatePageOpacity(node);
        });
    }

    /**
     * 更新摸个节点的透明度
     * @param node
     * @param isFree
     */
    private updatePageOpacity(node: VirtuaNode) {
        const ratio = this.intersectRatio(node);
        let opacity = Math.min((this.opacityType + ratio) * 255, 255);

        opacity = opacity > 155 ? 255 : (opacity / 155) * 255;
        // <10 的透明度直接设置为0，做容错处理；某些尺寸下的位置转换会有误差，导致极限位置是透明度不为0，会增加dc数量
        node.opacity = opacity < 10 ? 0 : opacity;

        this.onPageMoveFn(node, ratio);
    }

    /**
     * 将坐标转换到view父节点坐标系下
     */
    private convertToSpaceAR(node: VirtuaNode) {
        node.parent.convertToWorldSpaceAR(node.getPosition(), node.viewPos);
        this.view.parent.convertToNodeSpaceAR(node.viewPos, node.viewPos);
    }

    /**
     * 获取与view的相交比例
     * @param node 不单纯比较node节点的高度，而是获取包含了子节点的包围盒大小
     */
    private intersectRatio(node: VirtuaNode) {
        this.convertToSpaceAR(node);
        const space = node.height * (node.anchorY - 0.5);
        const viewY = this.view.position.y;
        const intersectHeight = this.view.height / 2 + node.height / 2;

        const currDistance = Math.abs(viewY - node.viewPos.y + space);
        node.intersectRatio = currDistance > intersectHeight ? 0 : 1 - currDistance / intersectHeight;
        return node.intersectRatio;
    }

    /**
     * 检测某个元素是否与view相交
     * @param node
     * @returns
     */
    private intersect(node: VirtuaNode) {
        return node.intersectRatio > 0;
    }

    private removeLastPage() {
        const pageIndex = this._pageIndexList[this._pageIndexList.length - 1];
        const page = this._virtuaNodeList.get(pageIndex);
        page.parent = null;
        this.putNode(page);
        this._virtuaNodeList.delete(pageIndex);
        this._pageIndexList.pop();
    }

    private removeFirstPage() {
        const pageIndex = this._pageIndexList[0];
        const page = this._virtuaNodeList.get(pageIndex);
        page.parent = null;
        this.putNode(page);
        this._virtuaNodeList.delete(pageIndex);
        this._pageIndexList.shift();
    }
}
