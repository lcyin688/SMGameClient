declare global {
    interface IUI {
        WETableView: typeof WETableView;
    }
    namespace we {
        namespace ui {
            type WETableView = InstanceType<typeof WETableView>;
        }
    }
}

const { ccclass, property, menu, requireComponent } = cc._decorator;

/** 布局方式 */
enum LayoutType {
    /** 列表布局 */
    LIST,
    /** 格子布局 */
    GRID,
    /** 瀑布流布局 */
    WATER,
}

/** 布局方向 */
enum LayoutOrientation {
    /** 垂直布局 */
    VERTICAL,
    /** 水平布局 */
    HORIZONTAL,
}

/** 垂直布局时Item方向 */
enum VerticalDirection {
    /** 从上至下 */
    TOP_TO_BOTTOM,
    /** 从下至上 */
    BOTTOM_TO_TOP,
}

/** 横向布局时Item方向 */
enum HorizontalDirection {
    /** 从左至右 */
    LEFT_TO_RIGHT,
    /** 从右至左 */
    RIGHT_TO_LEFT,
}

/** 垂直方向上对齐方式 */
enum VerticalAlign {
    TOP,
    CENTER,
    BOTTOM,
}

/** 水平方向上对齐方式 */
enum HorizontalAlign {
    LEFT,
    CENTER,
    RIGHT,
}

/** cell 基础数据 */
interface CellBaseInfo {
    /** 索引 */
    index: number;
    /** prefab type */
    type: string;
    /** 大小 */
    size: cc.Size;
    /** 位置 */
    position: cc.Vec2;
    /** 矩形区域 */
    rect: cc.Rect;
}

/** cell 变动数据 */
interface CellChangeData {
    /** 类型 */
    type?: string;
    /** 尺寸 */
    size?: cc.Size;
    /** 选择状态 */
    selected?: boolean;
}

/** cell 显示数据 */
export interface CellShowInfo {
    /** 索引 */
    index: number;
    /** 节点 */
    node: cc.Node;
    /** 类型 */
    type: string;
    /** 尺寸 */
    size: cc.Size;
    /** 选择状态 */
    selected: boolean;
}

/** ***********************************************************************************
 * @File        : WETableView.ts
 * @Author      : Frey
 * @Date        : 2025-06-09 16:45:00
 * @Description : 虚拟列表组件 + 排版组件
 **************************************************************************************/

@ccclass
@requireComponent(cc.ScrollView)
@menu('we/scroll/WETableView (WETableView)')
export default class WETableView extends cc.Component {
    /** 布局类型：列表布局，格子布局，瀑布流布局 */
    @property({
        type: cc.Enum(LayoutType),
        tooltip: CC_DEV && '布局类型：\n列表布局，格子布局，瀑布流布局',
    })
    layoutType: LayoutType = LayoutType.LIST;

    /** 布局方向：垂直布局，水平布局 */
    @property({
        type: cc.Enum(LayoutOrientation),
        tooltip: CC_DEV && '布局方向：\n垂直布局，水平布局',
    })
    layoutOrientation: LayoutOrientation = LayoutOrientation.VERTICAL;

    /** 垂直布局时Item的方向: 从上至下，从下至上 */
    @property({
        type: cc.Enum(VerticalDirection),
        tooltip: CC_DEV && '垂直布局时Item的方向\n（从上至下，从下至上）',
        visible() {
            return (this.layoutType == LayoutType.LIST && this.layoutOrientation == LayoutOrientation.VERTICAL) || this.layoutType == LayoutType.GRID;
        },
    })
    verticalDirection: VerticalDirection = VerticalDirection.TOP_TO_BOTTOM;

    /** 水平布局时Item的方向: 从左至右，从右至左 */
    @property({
        type: cc.Enum(HorizontalDirection),
        tooltip: CC_DEV && '水平布局时Item的方向\n（从左至右，从右至左）',
        visible() {
            return (this.layoutType == LayoutType.LIST && this.layoutOrientation == LayoutOrientation.HORIZONTAL) || this.layoutType == LayoutType.GRID;
        },
    })
    horizontalDirection: HorizontalDirection = HorizontalDirection.LEFT_TO_RIGHT;

    /** 垂直方向上对齐方式: 上中下 */
    @property({
        type: cc.Enum(VerticalAlign),
        tooltip: CC_DEV && '垂直方向上对齐方式',
        visible() {
            return (this.layoutType == LayoutType.LIST && this.layoutOrientation == LayoutOrientation.HORIZONTAL) || this.layoutType == LayoutType.GRID;
        },
    })
    verticalAlign: VerticalAlign = VerticalAlign.TOP;

    /** 水平方向上对齐方式: 左中右 */
    @property({
        type: cc.Enum(HorizontalAlign),
        tooltip: CC_DEV && '水平方向上对齐方式',
        visible() {
            return (this.layoutType == LayoutType.LIST && this.layoutOrientation == LayoutOrientation.VERTICAL) || this.layoutType == LayoutType.GRID;
        },
    })
    horizontalAlign: HorizontalAlign = HorizontalAlign.LEFT;

    /** 水平间隔 */
    @property({
        visible() {
            return (this.layoutType == LayoutType.LIST && this.layoutOrientation == LayoutOrientation.HORIZONTAL) || this.layoutType == LayoutType.GRID;
        },
        tooltip: CC_DEV && '水平间隔',
    })
    spaceX: number = 0;

    /** 垂直间隔 */
    @property({
        visible() {
            return (this.layoutType == LayoutType.LIST && this.layoutOrientation == LayoutOrientation.VERTICAL) || this.layoutType == LayoutType.GRID;
        },
        tooltip: CC_DEV && '垂直间隔',
    })
    spaceY: number = 0;

    /** 左侧内边距 */
    @property({
        tooltip: CC_DEV && '左侧内边距',
        visible() {
            return this.horizontalAlign == HorizontalAlign.LEFT || this.layoutOrientation == LayoutOrientation.HORIZONTAL;
        },
    })
    paddingLeft: number = 0;

    /** 右侧内边距 */
    @property({
        tooltip: CC_DEV && '右侧内边距',
        visible() {
            return this.horizontalAlign == HorizontalAlign.RIGHT || this.layoutOrientation == LayoutOrientation.HORIZONTAL;
        },
    })
    paddingRight: number = 0;

    /** 顶部内边距 */
    @property({
        tooltip: CC_DEV && '顶部内边距',
        visible() {
            return this.verticalAlign == VerticalAlign.TOP || this.layoutOrientation == LayoutOrientation.VERTICAL;
        },
    })
    paddingTop: number = 0;

    /** 底部内边距 */
    @property({
        tooltip: CC_DEV && '底部内边距',
        visible() {
            return this.verticalAlign == VerticalAlign.BOTTOM || this.layoutOrientation == LayoutOrientation.VERTICAL;
        },
    })
    paddingBottom: number = 0;

    /** 是否开启多选 */
    @property({
        tooltip: CC_DEV && '是否开启多选模式',
    })
    multiSelectionEnabled: boolean = false;

    /** 是否开启嵌套滑动 */
    @property({
        tooltip: CC_DEV && '是否开启嵌套滑动',
    })
    useWrapper: boolean = true;

    // ////////////////////////////////////////////////////////////// end ////////////////////////////////////////////////////////////////////////////////

    private static readonly HIDDEN_POSITION = 6400;

    /** 获取 cell 数量 */
    private _cellNumberCall: () => number = null;

    /** 获取cell类型 */
    private _cellTypeCall: (index: number) => string = null;

    /** 获取 cell node | prefab */
    private _cellNodeCall: (type: string) => cc.Node | cc.Prefab = null;

    /** 更新当前索引的 cell */
    private _cellUpdateCall: (tbv: WETableView, node: cc.Node, data: CellShowInfo) => void = null;

    /** 获取当前索引cell的Size */
    private _cellSizeCall: (tbv: WETableView, index: number, type: string) => cc.Size = null;

    // ////////////////////////////////////////////////////////////// end ////////////////////////////////////////////////////////////////////////////////

    private _scrollView: cc.ScrollView = null;

    private _currentSelectedIndex: number = -1;

    private _maxItemsPerLine: number = 0;

    /** cell数量 */
    private _totalCellCount: number = 0;

    /** 当前滚动的位置 */
    private _currentScrollPosition = new cc.Vec2(0, 0);

    /** table 可视区域尺寸 */
    private _visibleSize: cc.Size = cc.Size.ZERO;

    /** 缓存的不可见 cell 节点，有分类 */
    private _cellNodePool: { [key: string]: cc.Node[] } = {};

    /** 当前显示的cell */
    private _visibleCells: CellShowInfo[] = [];

    /** 所有的 cellItem 信息，保存位置及矩形信息 */
    private _allCellsLayoutInfo: CellBaseInfo[] = [];

    /** 缓存的 cell 变动数据 */
    private _cellChangeDataMap: Map<number, CellChangeData> = new Map();

    // ////////////////////////////////////////////////////////////// end ////////////////////////////////////////////////////////////////////////////////

    onLoad() {
        this._scrollView = this.node.getComponent(cc.ScrollView);
        if (!this._scrollView) {
            return;
        }

        this._visibleSize = this._scrollView.content.parent.getContentSize();

        // 重置原点位置
        this._scrollView.content.removeAllChildren(true);
        this._scrollView.content.setAnchorPoint(0, 1);
        this._scrollView.content.setPosition(-this._visibleSize.width / 2, this._visibleSize.height / 2);

        // 注册滚动回掉事件
        let scrollViewEventHandler = new cc.Component.EventHandler();
        scrollViewEventHandler.target = this.node;
        scrollViewEventHandler.component = 'WETableView';
        scrollViewEventHandler.handler = 'onScrollEvent';
        this._scrollView.scrollEvents.push(scrollViewEventHandler);
    }

    onDestroy(): void {
        this.unscheduleAllCallbacks();
    }

    /**
     * 注册节点更新回掉
     * @param callBack 回调函数
     */
    registerCellUpdateCall(callBack: (tbv: WETableView, node: cc.Node, data: CellShowInfo) => void) {
        this._cellUpdateCall = callBack;
        return this;
    }

    /**
     * 注册获取节点 Size 回调
     * @param callBack 回调函数
     */
    registerCellSizeCall(callBack: (tbv: WETableView, index: number, type: string) => cc.Size) {
        this._cellSizeCall = callBack;
        return this;
    }

    /**
     * 注册获取节点数量回调
     * @param callBack 回调函数
     */
    registerCellNumberCall(callBack: () => number) {
        this._cellNumberCall = callBack;
        return this;
    }

    /**
     * 注册获取节点类型回调
     * @param callBack 回调函数
     */
    registerCellTypeCall(callBack: (index: number) => string) {
        this._cellTypeCall = callBack;
        return this;
    }

    /**
     * 注册获取节点实例回调
     * @param callBack 回调函数
     */
    registerCellNodeCall(callBack: (type: string) => cc.Node | cc.Prefab) {
        this._cellNodeCall = callBack;
        return this;
    }

    /**
     * 滚动到顶部
     * @param timeInSecond 所需时间（单位秒）
     * @param attenuated 是否使用摩擦力
     */
    scrollToTop(timeInSecond?: number, attenuated?: boolean) {
        this._scrollView.stopAutoScroll();
        this._scrollView.scrollToTop(timeInSecond, attenuated);
        !timeInSecond && this.updateContent();
    }

    /**
     * 滚动到底部
     * @param timeInSecond 所需时间（单位秒）
     * @param attenuated 是否使用摩擦力
     */
    scrollToBottom(timeInSecond?: number, attenuated?: boolean) {
        this._scrollView.stopAutoScroll();
        this._scrollView.scrollToBottom(timeInSecond, attenuated);
        !timeInSecond && this.updateContent();
    }

    /**
     * 滚动到左侧
     * @param timeInSecond 所需时间（单位秒）
     * @param attenuated 是否使用摩擦力
     */
    scrollToLeft(timeInSecond?: number, attenuated?: boolean) {
        this._scrollView.stopAutoScroll();
        this._scrollView.scrollToLeft(timeInSecond, attenuated);
        !timeInSecond && this.updateContent();
    }

    /**
     * 滚动到右侧
     * @param timeInSecond 所需时间（单位秒）
     * @param attenuated 是否使用摩擦力
     */
    scrollToRight(timeInSecond?: number, attenuated?: boolean) {
        this._scrollView.stopAutoScroll();
        this._scrollView.scrollToRight(timeInSecond, attenuated);
        !timeInSecond && this.updateContent();
    }

    /**
     * 滚动到指定位置
     * @param position 位置
     * @param timeInSecond 所需时间（单位秒）
     * @param attenuated 是否使用摩擦力
     */
    scrollToPosition(position: cc.Vec2, timeInSecond?: number, attenuated?: boolean) {
        this._scrollView.stopAutoScroll();
        this._scrollView.scrollToOffset(position, timeInSecond, attenuated);
        !timeInSecond && this.updateContent();
    }

    /**
     * 滚动到指定索引
     * @param index 索引
     * @param timeInSecond 所需时间（单位秒）
     * @param attenuated 是否使用摩擦力
     */
    scrollToIndex(index: number, timeInSecond: number = 0.5, attenuated?: boolean) {
        this._scrollView.stopAutoScroll();
        if (index < 0) {
            index = 0;
        }
        if (index >= this._totalCellCount) {
            index = this._totalCellCount - 1;
        }
        let itemIndex = this._allCellsLayoutInfo.findIndex((item) => {
            return item.index === index;
        });
        if (itemIndex !== -1) {
            let item = this._allCellsLayoutInfo[itemIndex];
            if (this._isOrientationHorizontal()) {
                this._scrollView.scrollToOffset(new cc.Vec2(item.position.x - this._scrollView.node.width / 2, 0), timeInSecond, attenuated);
            } else if (this._isOrientationVertical()) {
                this._scrollView.scrollToOffset(new cc.Vec2(0, -item.position.y - this._scrollView.node.height / 2), timeInSecond, attenuated);
            }
            !timeInSecond && this.updateContent();
        }
    }

    /**
     * 根据 index 刷新当前显示的 cell
     */
    public updateCellByIndex(index: number) {
        const info = this._visibleCells.find((item) => {
            return item.index === index;
        });
        if (info) {
            this._cellUpdateCall(this, info.node.children[0], info);
        }
    }

    /**
     * 刷新当前显示区域 cells
     */
    public updateAllCell() {
        for (let i = 0; i < this._visibleCells.length; i++) {
            const info = this._visibleCells[i];
            this._cellUpdateCall(this, info.node.children[0], info);
        }
    }

    /**
     * 根据 index 更新 cell 基础数据
     * @param index 索引
     * @param info 数据
     */
    public updateCellInfo(index: number, info: CellChangeData) {
        if (!info || index < 0 || index > this._totalCellCount) {
            return;
        }

        const existingInfo = this._cellChangeDataMap.get(index) || {};
        const mergedInfo = { ...existingInfo, ...info };

        if ('selected' in info) {
            if (this.multiSelectionEnabled === true) {
                this._cellChangeDataMap.set(index, mergedInfo);
                // 多选
                this._visibleCells.forEach((item) => {
                    if (item.index === index) {
                        item.selected = info.selected;
                        this._cellUpdateCall(this, item.node.children[0], item);
                    }
                });
            } else {
                this._cellChangeDataMap.forEach((value, key) => {
                    value.selected = false;
                });
                this._cellChangeDataMap.set(index, mergedInfo);
                // 单选
                existingInfo.selected = false;
                this._currentSelectedIndex = index;
                this._visibleCells.forEach((item) => {
                    if (item.index === index) {
                        item.selected = info.selected;
                        this._cellUpdateCall(this, item.node.children[0], item);
                    } else {
                        item.selected = false;
                        this._cellUpdateCall(this, item.node.children[0], item);
                    }
                });
            }
        } else {
            this._cellChangeDataMap.set(index, mergedInfo);
            this.updateView();
        }
    }

    /**
     * 更新选择状态
     * @param index 索引
     * @param selected 是否选中
     * @returns
     */
    public changeSelectedByIndex(index: number, selected: boolean) {
        if (index < 0 || index > this._totalCellCount) {
            return;
        }
        this._cellChangeDataMap.set(index, { selected });

        this._visibleCells.forEach((item) => {
            if (item.index === index) {
                item.selected = selected;
                this._cellUpdateCall(this, item.node.children[0], item);
            }
        });
    }

    /**
     * 获取当前选择的 cells
     */
    public getSelectCells() {
        let arr = [];
        this._cellChangeDataMap.forEach((value, key) => {
            if (value.selected) {
                arr.push(key);
            }
        });
        return arr;
    }

    // ////////////////////////////////////////////////////////////// end ////////////////////////////////////////////////////////////////////////////////

    /**
     * 滚动事件，刷新优化性能，避免频繁刷新
     * @param scrollView scrollView
     * @param eventType 事件类型
     * @param customEventData 自定义Data
     */
    protected onScrollEvent(scrollView: cc.ScrollView, eventType: cc.ScrollView.EventType, customEventData: string) {
        let y = Math.abs(this._currentScrollPosition.y - scrollView.getScrollOffset().y);
        let x = Math.abs(this._currentScrollPosition.x - scrollView.getScrollOffset().x);

        if (this._isOrientationVertical() && y < this.spaceY) {
            return;
        }

        if (this._isOrientationHorizontal() && x < this.spaceX) {
            return;
        }

        this._currentScrollPosition = scrollView.getScrollOffset();
        this.updateContent();
    }

    /**
     * 是否是垂直布局
     */
    protected _isOrientationVertical(): boolean {
        return this.layoutOrientation == LayoutOrientation.VERTICAL;
    }

    /**
     * 是否水平布局
     */
    protected _isOrientationHorizontal(): boolean {
        return this.layoutOrientation == LayoutOrientation.HORIZONTAL;
    }

    /**
     * 获取更新节点壳
     */
    private createOrReuseCellNode(type: string): [cc.Node, cc.Node] {
        let dq = this.getCellFromPool(type);
        let it = dq.getChildByName(type);
        if (!it) {
            it = cc.instantiate(this._cellNodeCall(type)) as cc.Node;
            it.active = true;
            it.name = type;
            it.parent = dq;
        }
        return [dq, it];
    }

    /**
     * 获取可用节点
     */
    private getCellFromPool(type: string): cc.Node {
        const arr = this._cellNodePool[type];
        if (arr && arr.length > 0) {
            return arr.shift();
        }
        const cellNode = new cc.Node(type);
        cellNode.parent = this._scrollView.content;
        return cellNode;
    }

    private getMinAndMaxIndex(): [number, number] {
        let minIndex = Infinity;
        let maxIndex = -Infinity;
        for (const cell of this._visibleCells) {
            if (cell.index < minIndex) {
                minIndex = cell.index;
            }
            if (cell.index > maxIndex) {
                maxIndex = cell.index;
            }
        }
        return [minIndex, maxIndex];
    }

    // ////////////////////////////////////////////////////////////// end ////////////////////////////////////////////////////////////////////////////////

    /**
     * 重新计算并构建整个列表的布局
     * 当数据源发生变化时调用此方法重新排列所有列表项
     * 包括计算位置、尺寸和可见区域
     */
    updateView() {
        this._allCellsLayoutInfo.length = 0;
        let contentWidth = this._visibleSize.width;
        let contentHeight = this._visibleSize.height;

        this._totalCellCount = this._cellNumberCall ? this._cellNumberCall() : 0;

        this._scrollView.vertical = this.layoutOrientation == LayoutOrientation.VERTICAL;
        this._scrollView.horizontal = this.layoutOrientation == LayoutOrientation.HORIZONTAL;

        // 存在元素
        if (this._totalCellCount > 0) {
            // 垂直内边距
            const paddingVertical = this.verticalDirection == VerticalDirection.TOP_TO_BOTTOM ? this.paddingTop : this.paddingBottom;
            // 水平内边距
            const paddingHorizontal = this.horizontalDirection == HorizontalDirection.LEFT_TO_RIGHT ? this.paddingLeft : this.paddingRight;

            const paddingVerticalEnd = this.horizontalDirection == HorizontalDirection.LEFT_TO_RIGHT ? this.paddingRight : this.paddingLeft;

            const paddingHorizontalEnd = this.verticalDirection == VerticalDirection.TOP_TO_BOTTOM ? this.paddingBottom : this.paddingTop;

            let height = paddingVertical;
            let width = paddingHorizontal;

            let rowItemInfos: { items: CellBaseInfo[]; height: number; width: number }[] = [];
            let rowItemInfo: { items: CellBaseInfo[]; height: number; width: number } = null;

            let columnItemInfos: { items: CellBaseInfo[]; height: number; width: number }[] = [];
            let columnItemInfo: { items: CellBaseInfo[]; height: number; width: number } = null;

            // 缓存的高度和宽度，用来计算单行或单列
            let tempHeight = 0;
            let tempWidth = 0;

            // 计算content总高度
            for (let i = 0; i < this._totalCellCount; i++) {
                let selected = false;
                let cellType = this._cellTypeCall ? this._cellTypeCall(i) : 'tv_cell';
                let size = this._cellSizeCall ? this._cellSizeCall(this, i, cellType) : cc.Size.ZERO;

                if (this._cellChangeDataMap.has(i)) {
                    const cellItem = this._cellChangeDataMap.get(i);
                    if (cellItem.size) {
                        size = cellItem.size;
                    }
                    if (cellItem.type) {
                        cellType = cellItem.type;
                    }
                    if (this.multiSelectionEnabled) {
                        selected = cellItem?.selected || false;
                    } else {
                        selected = this._currentSelectedIndex == i;
                    }
                }

                // 新建CellItem
                let cellItem: CellBaseInfo = {
                    index: i,
                    size: size,
                    type: cellType,
                    position: cc.v2(0, 0),
                    rect: cc.rect(0, 0, 0, 0),
                };

                if (this._isOrientationVertical() && rowItemInfo == null) {
                    rowItemInfo = { items: [], height: 0, width: 0 };
                } else if (this._isOrientationHorizontal() && columnItemInfo == null) {
                    columnItemInfo = { items: [], height: 0, width: 0 };
                }

                if (this.layoutType == LayoutType.LIST) {
                    if (this._isOrientationVertical()) {
                        height += size.height + (i != 0 ? this.spaceY : 0);
                        rowItemInfo.items.push(cellItem);
                        rowItemInfo.height = size.height;
                        rowItemInfo.width = size.width;
                        rowItemInfos.push(rowItemInfo);
                        rowItemInfo = null;
                    } else {
                        width += size.width + (i != 0 ? this.spaceX : 0);
                        columnItemInfo.items.push(cellItem);
                        columnItemInfo.height = size.height;
                        columnItemInfo.width = size.width;
                        columnItemInfos.push(columnItemInfo);
                        columnItemInfo = null;
                    }
                } else if (this.layoutType == LayoutType.GRID) {
                    if (this._isOrientationVertical()) {
                        if (tempWidth + paddingHorizontal + size.width + (tempWidth > 0 ? this.spaceX : 0) + paddingHorizontalEnd > this._visibleSize.width) {
                            // 水平区域放不下Item
                            if (tempWidth == 0) {
                                // 如果这一行没有item 则把item放在这一行
                                height += size.height + (rowItemInfos.length == 0 ? 0 : this.spaceY);
                                rowItemInfo.items.push(cellItem);
                                rowItemInfo.height = size.height;
                                rowItemInfo.width = size.width;
                                rowItemInfos.push(rowItemInfo);

                                rowItemInfo = null;
                            } else {
                                // item放到下一行
                                height += rowItemInfo.height + (rowItemInfos.length == 0 ? 0 : this.spaceY);
                                rowItemInfo.width = tempWidth;
                                // 先保存上一行item再新建一行数据
                                rowItemInfos.push(rowItemInfo);
                                rowItemInfo = { items: [cellItem], height: size.height, width: 0 };
                                tempWidth = size.width;
                            }
                        } else {
                            // 正常向后排列
                            tempWidth += size.width + (tempWidth > 0 ? this.spaceX : 0);
                            rowItemInfo.items.push(cellItem);
                            rowItemInfo.height = Math.max(rowItemInfo.height, size.height);
                        }
                    } else if (this._isOrientationHorizontal()) {
                        if (tempHeight + paddingVertical + size.height + (tempHeight > 0 ? this.spaceY : 0) + paddingVerticalEnd > this._visibleSize.height) {
                            // 水平区域放不下Item
                            if (tempHeight == 0) {
                                // 如果这一列没有item 则把item放在这一列
                                width += size.width + (columnItemInfos.length == 0 ? 0 : this.spaceX);

                                columnItemInfo.items.push(cellItem);
                                columnItemInfo.width = size.width;
                                columnItemInfo.height = size.height;
                                columnItemInfos.push(columnItemInfo);

                                columnItemInfo = null;
                            } else {
                                width += columnItemInfo.width + (columnItemInfos.length == 0 ? 0 : this.spaceX);
                                columnItemInfo.height = tempHeight;
                                // 先保存上一列item再新建一列数据
                                columnItemInfos.push(columnItemInfo);
                                columnItemInfo = { items: [cellItem], width: size.width, height: 0 };

                                tempHeight = size.height;
                            }
                        } else {
                            // 正常向下排列
                            tempHeight += size.height + (tempHeight > 0 ? this.spaceY : 0);
                            columnItemInfo.items.push(cellItem);
                            columnItemInfo.width = Math.max(columnItemInfo.width, size.width);
                        }
                    }
                }
            }

            if (this._isOrientationVertical() && rowItemInfo != null) {
                height += rowItemInfo.height + (rowItemInfos.length == 0 ? 0 : this.spaceY);
                rowItemInfo.width = tempWidth;
                rowItemInfos.push(rowItemInfo);
            }

            if (this._isOrientationHorizontal() && columnItemInfo != null) {
                width += columnItemInfo.width + (columnItemInfos.length == 0 ? 0 : this.spaceX);
                columnItemInfo.height = tempHeight;
                columnItemInfos.push(columnItemInfo);
            }

            height += paddingVerticalEnd;
            width += paddingHorizontalEnd;

            if (this._isOrientationVertical()) {
                contentHeight = Math.max(height, this._visibleSize.height);

                if (this.verticalDirection == VerticalDirection.BOTTOM_TO_TOP) {
                    rowItemInfos.reverse();
                }

                let rh = this.paddingTop;
                rowItemInfos.forEach((row) => {
                    let xStart = paddingHorizontal;

                    if (this.horizontalAlign == HorizontalAlign.CENTER) {
                        xStart = this._visibleSize.width / 2 - row.width / 2;
                    } else if (this.horizontalAlign == HorizontalAlign.LEFT) {
                        xStart = this.paddingLeft;
                    } else if (this.horizontalAlign == HorizontalAlign.RIGHT) {
                        xStart = this._visibleSize.width - this.paddingRight - row.width;
                    }

                    if (this.horizontalDirection == HorizontalDirection.RIGHT_TO_LEFT) {
                        row.items.reverse();
                    }

                    if (this.layoutType !== LayoutType.LIST) {
                        if (row.items.length > this._maxItemsPerLine) {
                            this._maxItemsPerLine = row.items.length;
                        }
                    }

                    row.items.forEach((item) => {
                        item.position.x = xStart + item.size.width / 2;

                        xStart += item.size.width + this.spaceX;

                        item.position.y = contentHeight - (rh + item.size.height / 2);

                        item.rect = cc.rect(item.position.x - item.size.width / 2, item.position.y - item.size.height / 2, item.size.width, item.size.height);

                        item.position.y -= contentHeight;
                    });

                    rh += row.height + this.spaceY;

                    this._allCellsLayoutInfo.push(...row.items);
                    row.items.length = 0;
                });

                rowItemInfos.length = 0;
            } else {
                contentWidth = Math.max(width, this._visibleSize.width);

                if (this.horizontalDirection == HorizontalDirection.RIGHT_TO_LEFT) {
                    columnItemInfos.reverse();
                }

                let cw = this.paddingLeft;
                columnItemInfos.forEach((cloumn) => {
                    let yStart = paddingVertical;

                    if (this.verticalAlign == VerticalAlign.CENTER) {
                        yStart = this._visibleSize.height / 2 + cloumn.height / 2;
                    } else if (this.verticalAlign == VerticalAlign.TOP) {
                        yStart = this._visibleSize.height - this.paddingTop;
                    } else if (this.verticalAlign == VerticalAlign.BOTTOM) {
                        yStart = cloumn.height + this.paddingBottom;
                    }

                    if (this.horizontalDirection == HorizontalDirection.RIGHT_TO_LEFT) {
                        cloumn.items.reverse();
                    }

                    if (this.layoutType !== LayoutType.LIST) {
                        if (cloumn.items.length > this._maxItemsPerLine) {
                            this._maxItemsPerLine = cloumn.items.length;
                        }
                    }

                    cloumn.items.forEach((item, index) => {
                        item.position.y = yStart - item.size.height / 2;
                        yStart -= item.size.height + this.spaceY;

                        item.position.x = cw + item.size.width / 2;

                        item.rect = cc.rect(item.position.x - item.size.width / 2, item.position.y - item.size.height / 2, item.size.width, item.size.height);

                        item.position.y -= contentHeight;
                    });

                    cw += cloumn.width + this.spaceX;

                    this._allCellsLayoutInfo.push(...cloumn.items);
                });

                columnItemInfos.length = 0;
            }
        }

        this._scrollView.content.height = contentHeight;
        this._scrollView.content.width = contentWidth;

        this._visibleCells.forEach((cell) => {
            cell.node.setPosition(-WETableView.HIDDEN_POSITION, -WETableView.HIDDEN_POSITION);
            if (this._cellNodePool[cell.type]) {
                this._cellNodePool[cell.type].push(cell.node);
            } else {
                this._cellNodePool[cell.type] = [cell.node];
            }
        });

        this._visibleCells.length = 0;

        this.updateContent();
    }

    /**
     * 刷新显示区域
     */
    updateContent() {
        const offSet = this._scrollView.getScrollOffset();

        let visibleRect = cc.rect(offSet.x, this._scrollView.content.height - offSet.y - this._visibleSize.height, this._visibleSize.width, this._visibleSize.height);
        if (this._isOrientationHorizontal()) {
            visibleRect = cc.rect(-offSet.x, 0, this._visibleSize.width, this._visibleSize.height);
        }

        let arr = [];
        let minIndex = 0;
        let maxIndex = 0;

        if (this._visibleCells.length > 0) {
            [minIndex, maxIndex] = this.getMinAndMaxIndex(); // 279 284

            if (this.verticalDirection === 1 || this.horizontalDirection === 1) {
                let min = minIndex;
                let max = maxIndex;
                maxIndex = this._allCellsLayoutInfo.length - min;
                minIndex = this._allCellsLayoutInfo.length - max;
            }
            arr = this._allCellsLayoutInfo.slice(minIndex > this._maxItemsPerLine ? minIndex - this._maxItemsPerLine : 0, maxIndex + this._maxItemsPerLine);
        } else {
            arr = this._allCellsLayoutInfo;
        }

        for (let i = 0; i < arr.length; i++) {
            let itemInfo = arr[i];
            if (!itemInfo) {
                continue;
            }

            const isVisible = visibleRect.intersects(itemInfo.rect) || visibleRect.containsRect(itemInfo.rect);
            const cellIndex = this._visibleCells.findIndex((c) => {
                return c.index === itemInfo.index;
            });

            if (isVisible && cellIndex === -1) {
                const [node, item] = this.createOrReuseCellNode(itemInfo.type);
                node.setPosition(itemInfo.position);
                // push
                const info: CellShowInfo = { index: itemInfo.index, node: node, type: itemInfo.type, selected: itemInfo.selected, size: itemInfo.size };
                this._cellUpdateCall(this, item, info);
                this._visibleCells.push(info);
            } else if (!isVisible && cellIndex !== -1) {
                const cell = this._visibleCells[cellIndex];
                cell.node.setPosition(WETableView.HIDDEN_POSITION, WETableView.HIDDEN_POSITION);
                // 缓存起来
                const cellType = cell.node.name;
                if (!this._cellNodePool[cellType]) {
                    this._cellNodePool[cellType] = [];
                }
                this._cellNodePool[cellType].push(cell.node);
                this._visibleCells.splice(cellIndex, 1);
            }
        }

        if (this.layoutType === LayoutType.LIST) {
            this._maxItemsPerLine = this._visibleCells.length;
        }
    }

    /**
     * 获取可见节点
     */
    getVisibleItems(): cc.Node[] {
        return this._visibleCells.map((cell) => {
            return cell.node;
        });
    }
}

we.ui.WETableView = WETableView;
