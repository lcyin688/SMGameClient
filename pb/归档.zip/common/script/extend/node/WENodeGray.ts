const { ccclass, menu } = cc._decorator;

declare global {
    interface IUI {
        WENodeGray: typeof WENodeGray;
    }

    namespace we {
        namespace ui {
            type WENodeGray = InstanceType<typeof WENodeGray>;
        }
    }
}

/**
 * 自动让节点下所有的Sprite/label组件使用gray材质置灰
 * 用于表现按钮不可点击等场景
 */
@ccclass
@menu('we/render/WENodeGray(节点置灰组件)')
export class WENodeGray extends cc.Component {
    /**
     * 置灰遮罩颜色
     */
    maskColor = cc.color(147, 147, 147, 255);

    /**
     * 标准颜色
     */
    normalColor = cc.color(255, 255, 255, 255);

    material: cc.Material;

    /**
     * 是否置灰
     */
    isGray: boolean = false;

    /**
     * 设置缓存，当材质没有设置时则缓存设置函数
     */
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    setGrayCache: () => void = null!;

    async setGrayMaterial(materialUrl: string) {
        const material = await we.core.assetMgr.loadAsset(materialUrl, cc.Material, this);

        const sprites = this.getComponentsInChildren(cc.Sprite);
        sprites.forEach((sprite) => {
            sprite.setMaterial(0, material);
            material.setProperty('isGray', 0);
            sprite.node['_twprop'] = { color: this.node.color };
        });

        const labels = this.getComponentsInChildren(cc.Label);
        labels.forEach((label) => {
            label.setMaterial(0, material);
            material.setProperty('isGray', 0);
            label.node['_twprop'] = { color: this.node.color };
        });

        this.isGray = false;

        this.material = material;
        this.setGrayCache?.();
        return this;
    }

    setGray(isGray: boolean, force = false) {
        // 当前状态一致的则不做改变
        if (this.isGray === isGray && !force) {
            return;
        }

        // 材质没加载完则缓存起来
        if (!this.material) {
            this.setGrayCache = () => {
                this.setGray(isGray);
                this.setGrayCache = null;
            };
            return;
        }

        this.isGray = isGray;

        const sprites = this.getComponentsInChildren(cc.Sprite);
        sprites.forEach((sprite) => {
            this.setSpriteGray(sprite, isGray);
        });

        const labels = this.getComponentsInChildren(cc.Label);
        labels.forEach((label) => {
            if (label && !label['customColor']) {
                label['customColor'] = label.node.color;
            }

            this.setTTFLabelGray(label, isGray);

            // 设置描边颜色
            const outline: cc.LabelOutline = label.node.getComponent(cc.LabelOutline);
            if (outline) {
                this.setOutlineGray(outline, isGray);
            }
        });
    }

    private setSpriteGray(sprite: cc.Sprite, isGray: boolean) {
        // 停止所有的缓动
        cc.Tween.stopAllByTarget(sprite.node['_twprop']);
        const transTime = 0.25;
        const color = isGray ? this.maskColor : this.normalColor;
        const easing = 'sineOut';
        // 不是字体或者有自定义字体的文字
        // 使用 node['_twprop'] 自定义属性进行缓动，避免其他人因对此节点进行tween操作导致缓动失效
        cc.tween(sprite.node['_twprop'])
            .delay(0)
            .to(
                transTime,
                { color: color },
                {
                    progress: (start, end, current, t) => {
                        if (!cc.isValid(sprite.node)) {
                            return;
                        }
                        sprite.node.color = sprite.node['_twprop'].color;
                        return start.lerp(end, t, current);
                    },
                    easing: easing,
                }
            )
            .call(() => {
                if (!cc.isValid(sprite.node)) {
                    return;
                }
                sprite.node.color = color;
            })
            .start();
    }

    private setTTFLabelGray(label: cc.Label, isGray: boolean) {
        const transTime = 0.25;
        const easing = 'sineOut';

        if (label && !label['customColor']) {
            label['customColor'] = label.node.color;
        }

        const ratioR = this.maskColor.r / 255;
        const ratioG = this.maskColor.g / 255;
        const ratioB = this.maskColor.b / 255;

        // 设置纯色字体的颜色
        const oColor: cc.Color = label['customColor'];
        const grayColor = cc.color(oColor.r * ratioR, oColor.g * ratioG, oColor.b * ratioB, 255);
        const labColor = isGray ? grayColor : oColor;
        // 使用 node['_twprop'] 自定义属性进行缓动，避免其他人因对此节点进行tween操作导致缓动失效
        cc.Tween.stopAllByTarget(label.node['_twprop']);
        cc.tween(label.node['_twprop'])
            .delay(0)
            .to(
                transTime,
                { color: labColor },
                {
                    progress: (start, end, current, t) => {
                        if (!cc.isValid(label.node)) {
                            return;
                        }
                        label.node.color = label.node['_twprop'].color;
                        return start.lerp(end, t, current);
                    },
                    easing: easing,
                }
            )
            .call(() => {
                if (!cc.isValid(label.node)) {
                    return;
                }
                label.node.color = labColor;
            })
            .start();
    }

    private setOutlineGray(outline: cc.LabelOutline, isGray: boolean) {
        const transTime = 0.25;
        const easing = 'sineOut';

        if (outline && !outline['customColor']) {
            outline['customColor'] = outline.color;
        }

        const ratioR = this.maskColor.r / 255;
        const ratioG = this.maskColor.g / 255;
        const ratioB = this.maskColor.b / 255;

        const oColor = outline['customColor'];
        const grayColor = cc.color(oColor.r * ratioR, oColor.g * ratioG, oColor.b * ratioB, 255);
        const outlineColor = isGray ? grayColor : oColor;
        cc.tween(outline)
            .delay(0)
            .to(transTime, { color: outlineColor }, { easing: easing })
            .call(() => {
                outline.color = outlineColor;
            })
            .start();
    }
}

we.ui.WENodeGray = WENodeGray;
