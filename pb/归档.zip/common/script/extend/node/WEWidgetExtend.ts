const { ccclass, property, requireComponent, menu } = cc._decorator;
/**
 * 仅针对屏幕宽高都适配了的情况下有效
 * 屏幕宽高比 > 设计宽高比 适配宽度
 * 屏幕宽高比 < 设计宽高比 适配高度
 */

declare global {
    interface IUI {
        WEWidgetExtend: typeof WEWidgetExtend;
    }

    namespace we {
        namespace ui {
            type WEWidgetExtend = InstanceType<typeof WEWidgetExtend>;
        }
    }
}

@ccclass
@requireComponent(cc.Widget)
@menu('we/adapt/WEWidgetExtend(宽高都适配对cc.Widget的扩展)')
export default class WEWidgetExtend extends cc.Component {
    @property({ tooltip: CC_DEV && '适配全屏对齐, 仅高度和宽度适配都开启了有效' })
    public isFull: boolean = false;

    @property({
        tooltip: CC_DEV && 'canvas无法适配屏幕时，设置顶部溢出高度，一般发生在高度和宽度同时适配的情况',
        visible: function () {
            return this.isFull == false;
        },
    })
    public topOverflowMax = 0;

    @property({
        tooltip: CC_DEV && 'canvas无法适配屏幕时，设置底部溢出高度，一般发生在高度和宽度同时适配的情况',
        visible: function () {
            return this.isFull == false;
        },
    })
    public bottomOverflowMax = 0;

    @property({
        tooltip: CC_DEV && 'canvas无法适配屏幕时，设置左边溢出宽度，一般发生在高度和宽度同时适配的情况',
        visible: function () {
            return this.isFull == false;
        },
    })
    public leftOverflowMax = 0;

    @property({
        tooltip: CC_DEV && 'canvas无法适配屏幕时，设置右边溢出宽度，一般发生在高度和宽度同时适配的情况',
        visible: function () {
            return this.isFull == false;
        },
    })
    public rightOverflowMax = 0;

    /**
     * 屏幕宽高比 值越小屏幕越高
     */
    private screenRatio = 0;

    /**
     * canvas的宽高比
     */
    private canvasRatio = 0;

    private _widget = {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    };

    protected onLoad(): void {
        this.initSaveParams();
        this.initRatio();
        this.adapter();
    }

    protected onEnable(): void {
        we.event<we.core.EventMsg>().on('WindowResize', this.onChange, this);
    }

    protected onDisable(): void {
        we.event<we.core.EventMsg>().off('WindowResize', this.onChange, this);
    }

    protected onChange() {
        this.scheduleOnce(() => {
            this.initRatio();
            this.adapter();
        }, 0);
    }

    /**
     * 保存widget参数
     */
    private initSaveParams() {
        const widget = this.node.getComponent(cc.Widget);
        this._widget.left = widget.left;
        this._widget.right = widget.right;
        this._widget.top = widget.top;
        this._widget.bottom = widget.bottom;
    }

    /**
     * 初始化比例
     */
    private initRatio() {
        const { width, height } = cc.view.getFrameSize();
        this.screenRatio = width / height;
        this.canvasRatio = cc.Canvas.instance.designResolution.width / cc.Canvas.instance.designResolution.height;
    }

    /**
     * 重置对齐
     */
    private restWidget() {
        const widget = this.node.getComponent(cc.Widget);
        widget.top = this._widget.top;
        widget.left = this._widget.left;
        widget.right = this._widget.right;
        widget.bottom = this._widget.bottom;
    }

    /**
     * 适配
     * @returns
     */
    private adapter() {
        this.restWidget();

        // 横屏不做适配
        if (this.canvasRatio > 1) {
            return;
        }
        if (this.screenRatio == this.canvasRatio) {
            return;
        }

        // 只适配了高度也不做适配
        if (!cc.Canvas.instance.fitHeight || !cc.Canvas.instance.fitWidth) {
            return;
        }

        // 屏幕比例 > 设计比例也不做适配
        if (this.screenRatio < this.canvasRatio) {
            this.adapterHeight();
        } else {
            this.adapterWidth();
        }
    }

    /**
     * 适配高度
     */
    private adapterHeight() {
        // 宽度缩放
        const widthRatio = cc.Canvas.instance.designResolution.width / cc.view.getFrameSize().width;
        const canvasScreenHeight = cc.Canvas.instance.designResolution.height / widthRatio;

        // 获取屏幕实际溢出高度
        const overflowHeight = ((cc.view.getFrameSize().height - canvasScreenHeight) * widthRatio) / 2;

        const widget = this.node.getComponent(cc.Widget);

        // 顶部对齐
        if (widget.isAlignTop) {
            // 获取需要设置的溢出高度
            let overflowTopHeight = Math.max(Math.min(this.isFull ? overflowHeight : this.topOverflowMax, overflowHeight), 0);
            widget.top = this._widget.top - overflowTopHeight;
        }

        // 底部对齐
        if (widget.isAlignBottom) {
            // 获取需要设置的溢出高度
            let overflowBottomHeight = Math.max(Math.min(this.isFull ? overflowHeight : this.bottomOverflowMax, overflowHeight), 0);
            widget.bottom = this._widget.bottom - overflowBottomHeight;
        }
    }

    /**
     * 适配宽度
     */
    private adapterWidth() {
        // 宽度缩放
        const heightRatio = cc.Canvas.instance.designResolution.height / cc.view.getFrameSize().height;
        const canvasScreenWidth = cc.Canvas.instance.designResolution.width / heightRatio;

        // 获取屏幕实际溢出高度
        const overflowWidth = ((cc.view.getFrameSize().height - canvasScreenWidth) * heightRatio) / 2;

        const widget = this.node.getComponent(cc.Widget);

        // 左对齐
        if (widget.isAlignLeft) {
            // 获取需要设置的溢出高度
            let overflowLeftWidth = Math.max(Math.min(this.isFull ? overflowWidth : this.leftOverflowMax, overflowWidth), 0);
            widget.left = this._widget.left - overflowLeftWidth;
        }

        // 右对齐
        if (widget.isAlignRight) {
            // 获取需要设置的溢出高度
            let overflowRightWidth = Math.max(Math.min(this.isFull ? overflowWidth : this.rightOverflowMax, overflowWidth), 0);
            widget.right = this._widget.right - overflowRightWidth;
        }
    }
}

we.ui.WEWidgetExtend = WEWidgetExtend;
