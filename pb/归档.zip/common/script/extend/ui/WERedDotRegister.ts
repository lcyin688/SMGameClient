const { ccclass, executeInEditMode, property, menu } = cc._decorator;

// 创建枚举
const RedTypeEnum = we.core.EnumHelper.convertStringEnumToNumberEnum(we.common.redDot.cfg);

@ccclass
@executeInEditMode
@menu('we/other/WERedDotRegister(注册红点)')
export class WERedDotRegister extends cc.Component {
    @property()
    private _index: number = RedTypeEnum.root;

    @property({ displayName: CC_DEV && '注册数据', type: cc.Enum(RedTypeEnum) })
    protected get index(): number {
        return this._index;
    }

    protected set index(value: number) {
        this._index = value;
    }

    @property()
    private _showType: number = we.common.redDot.type.PURE;

    @property({ displayName: CC_DEV && '显示方式', type: cc.Enum(we.common.redDot.type) })
    protected get showType(): number {
        return this._showType;
    }

    protected set showType(value: number) {
        this._showType = value;
    }

    protected onLoad(): void {
        const key = <string>we.core.EnumHelper.getKeyFromValue(RedTypeEnum, this.index);
        const paths = we.common.redDot.cfg[key];

        if (!paths) {
            we.warn('WERedDotRegister onLoad， path is null');
            return;
        }

        we.common.redDot.red.registeredRedDot({
            paths,
            node: this.node.name === 'notice' ? this.node : this.node.getChildByName('notice'),
            type: this.showType,
        });
    }
}
