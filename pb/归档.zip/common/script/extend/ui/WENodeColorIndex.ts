declare global {
    interface IUI {
        WENodeColorIndex: typeof WENodeColorIndex;
    }
    namespace we {
        namespace ui {
            type WENodeColorIndex = InstanceType<typeof WENodeColorIndex>;
        }
    }
}

const { ccclass, property, executeInEditMode, requireComponent, menu } = cc._decorator;

@ccclass
@menu('we/render/WENodeColorIndex(颜色改变)')
@executeInEditMode
export default class WENodeColorIndex extends cc.Component {
    @property
    private _maxIndex: number = 0;
    @property({ tooltip: CC_DEV && '最大 index' })
    get maxIndex() {
        return this._maxIndex;
    }
    set maxIndex(value: number) {
        this.setMaxIndex(value);
    }

    @property
    private _index: number = 0;
    @property({ tooltip: CC_DEV && '当前颜色索引' })
    get index() {
        return this._index;
    }
    set index(value: number) {
        this.setIndex(value);
    }

    // node 颜色
    @property
    private _isNodeColor: boolean = true;
    @property({ tooltip: CC_DEV && '是否开启 Node 颜色列表' })
    get isNodeColor(): boolean {
        return this._isNodeColor;
    }
    set isNodeColor(b: boolean) {
        this._isNodeColor = b;
        if (this._isNodeColor) {
            this.colors.length = this._maxIndex;
        }
        this.setIndex(this._index);
    }

    @property({
        type: [cc.Color],
        tooltip: CC_DEV && 'Node 颜色列表',
        visible() {
            return this._isNodeColor;
        },
    })
    private colors: cc.Color[] = [];

    // label 描边颜色
    @property
    private _isOutlineColor: boolean = false;
    @property({ tooltip: CC_DEV && '是否开启 Label Outline 颜色列表' })
    get isOutlineColor(): boolean {
        return this._isOutlineColor;
    }
    set isOutlineColor(b: boolean) {
        this._isOutlineColor = b;
        if (this._isOutlineColor) {
            this.outlineColors.length = this._maxIndex;
        }
        this.setIndex(this._index);
    }

    @property({
        type: [cc.Color],
        tooltip: CC_DEV && 'Outline 颜色列表',
        visible() {
            return this._isOutlineColor;
        },
    })
    private outlineColors: cc.Color[] = [];

    // label 阴影颜色
    @property
    private _isShadowColor: boolean = false;
    @property({ tooltip: CC_DEV && '是否开启 Label Shadow 阴影颜色列表' })
    get isShadowColor(): boolean {
        return this._isShadowColor;
    }
    set isShadowColor(b: boolean) {
        this._isShadowColor = b;
        if (this._isShadowColor) {
            this.shadowColors.length = this._maxIndex;
        }
        this.setIndex(this._index);
    }

    @property({
        type: [cc.Color],
        tooltip: CC_DEV && 'Shadow 颜色列表',
        visible() {
            return this._isShadowColor;
        },
    })
    private shadowColors: cc.Color[] = [];

    setMaxIndex(value: number) {
        if (value < 0) {
            return;
        }
        this._maxIndex = value;

        if (this.isNodeColor) {
            this.colors.length = this._maxIndex;
        }

        if (this.isOutlineColor) {
            this.outlineColors.length = this._maxIndex;
        }

        if (this.isShadowColor) {
            this.shadowColors.length = this._maxIndex;
        }

        if (this._index > this._maxIndex) {
            this._index = this._maxIndex;
            this.setIndex(this._index);
        }
    }

    setIndex(value: number) {
        if (value < 0) {
            return;
        }
        this._index = value % this._maxIndex;

        if (this.isNodeColor) {
            this.node.color = this.colors[this._index];
        }

        if (this.isOutlineColor && this.node.getComponent(cc.LabelOutline)) {
            this.node.getComponent(cc.LabelOutline).color = this.outlineColors[this._index];
        }

        if (this.isShadowColor && this.node.getComponent(cc.LabelShadow)) {
            this.node.getComponent(cc.LabelShadow).color = this.shadowColors[this._index];
        }
    }

    next() {
        this.index++;
    }

    previous() {
        this.index--;
    }
}

we.ui.WENodeColorIndex = WENodeColorIndex;
