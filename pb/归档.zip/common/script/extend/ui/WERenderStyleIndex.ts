declare global {
    interface IUI {
        WERenderStyleIndex: typeof WERenderStyleIndex;
    }
    namespace we {
        namespace ui {
            type WERenderStyleIndex = InstanceType<typeof WERenderStyleIndex>;
        }
    }
}

import WENodeColorIndex from './WENodeColorIndex';

const { ccclass, property, executeInEditMode, disallowMultiple, menu } = cc._decorator;

/**
 * UI风格同步组件 WESpriteIndex
 */
@ccclass
@menu('we/render/WERenderStyleIndex(StyleIndex组合)')
@executeInEditMode
@disallowMultiple()
export default class WERenderStyleIndex extends cc.Component {
    @property
    private _index: number = 0;
    @property({
        tooltip: CC_DEV && '当前显示的 index',
        override: true,
    })
    get index() {
        return this._index;
    }
    set index(value: number) {
        this.setIndex(value);
    }

    private frame_coms: we.ui.WESpriteIndex[] = [];
    private color_coms: WENodeColorIndex[] = [];

    protected setIndex(value: number) {
        if (value < 0) {
            return;
        }

        this.frame_coms = this.node.getComponentsInChildren(we.ui.WESpriteIndex);
        this.color_coms = this.node.getComponentsInChildren(WENodeColorIndex);

        this._index = value % this.getMinLength();

        this.frame_coms.forEach((com) => {
            com.index = this._index;
        });

        this.color_coms.forEach((com) => {
            com.index = this._index;
        });
    }

    setIndexAdd(add: number) {
        this._index += add;
        this.setIndex(this._index);
    }

    next() {
        this.index++;
    }

    previous() {
        this.index--;
    }

    private getMinLength() {
        let minFrameIndex = 9999;
        let minColorIndex = 9999;

        if (this.frame_coms.length > 0) {
            minFrameIndex = this.findMinIndex(this.frame_coms, 'maxIndex');
        }

        if (this.color_coms.length > 0) {
            minColorIndex = this.findMinIndex(this.color_coms, 'maxIndex');
        }

        return Math.min(minFrameIndex, minColorIndex);
    }

    private findMinIndex(components: (we.ui.WESpriteIndex | WENodeColorIndex)[], propName: string): number {
        let minIndex = Infinity;
        components.forEach((com) => {
            let maxIndex = com[propName];
            if (maxIndex > 0 && maxIndex < minIndex) {
                minIndex = maxIndex;
            }
        });
        return minIndex === Infinity ? 0 : minIndex;
    }
}

we.ui.WERenderStyleIndex = WERenderStyleIndex;
