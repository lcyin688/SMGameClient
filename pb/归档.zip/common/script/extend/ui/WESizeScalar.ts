declare global {
    interface IUI {
        WESizeScalar: typeof WESizeScalar;
    }
    namespace we {
        namespace ui {
            type WESizeScalar = InstanceType<typeof WESizeScalar>;
        }
    }
}

const { ccclass, disallowMultiple, executeInEditMode, property, menu } = cc._decorator;

/**
 * 缩放模式
 */
export enum ScaleMode {
    /**
     * 不使用任何缩放策略
     */
    NONE,
    /**
     * @en The entire application is visible in the specified area without trying to preserve the original aspect ratio.
     * Distortion can occur, and the application may appear stretched or compressed.
     *
     * @zh 整个应用程序在指定区域可见，无需尝试保留原始纵横比，
     * 可能会发生变形，出现画面拉伸或压缩。
     */
    EXACT_FIT,
    /**
     * @en The entire application fills the specified area, without distortion but possibly with some cropping,
     * while maintaining the original aspect ratio of the application.
     *
     * @zh 整个应用程序填充指定区域，没有变形，但可能有一些裁剪，
     * 同时保持画面的原始纵横比。
     */
    NO_BORDER,
    /**
     * @en The entire application is visible in the specified area without distortion while maintaining the original
     * aspect ratio of the application. Borders can appear on two sides of the application.
     *
     * @zh 整个应用程序在指定区域可见，没有变形，同时保持原始纵横比，
     * 边框可能出现在画面的旁侧。
     */
    SHOW_ALL,
    /**
     * @en The application takes the height of the design resolution size and modifies the width of the internal
     * canvas so that it fits the aspect ratio of the device
     * no distortion will occur however you must make sure your application works on different
     * aspect ratios
     *
     * @zh 该应用程序采用设计分辨率大小的高度并修改内部画布的宽度，使其适合设备的纵横比，不会发生变形，
     * 但是您必须确保您的应用程序在不同的纵横比的设备下工作。
     */
    FIXED_HEIGHT,
    /**
     * @en The application takes the width of the design resolution size and modifies the height of the internal
     * canvas so that it fits the aspect ratio of the device
     * no distortion will occur however you must make sure your application works on different
     * aspect ratios
     *
     * @zh 该应用程序采用设计分辨率大小的宽度并修改内部画布的高度，使其适合设备的纵横比，不会发生变形
     * 但是您必须确保您的应用程序在不同的纵横比的设备下工作。
     */
    FIXED_WIDTH,
}

/**
 * 节点适配组件
 */
@ccclass
@executeInEditMode
@disallowMultiple
@menu('we/adapt/WESizeScalar(节点适配组件)')
export class WESizeScalar extends cc.Component {
    @property({ type: cc.Node })
    target: cc.Node = null;

    @property({ type: cc.Enum(ScaleMode) })
    scaleMode: ScaleMode = ScaleMode.NONE;

    private _targetTransform: cc.Node = null;
    private _thisTransform: cc.Node = null;

    protected onLoad(): void {
        const widget = this.getComponent(cc.Widget);
        if (widget) {
            widget.enabled = false;
        }

        if (!this.target) {
            this.target = this.node.parent;
        }

        this._targetTransform = this.target;
        this._thisTransform = this.node;

        this.updateScale();
    }

    protected onEnable(): void {
        this.target?.on(cc.Node.EventType.SIZE_CHANGED, this.updateScale, this);
        this.node.on(cc.Node.EventType.SIZE_CHANGED, this.updateScale, this);
    }

    protected onDisable(): void {
        this.target?.off(cc.Node.EventType.SIZE_CHANGED, this.updateScale, this);
        this.node.off(cc.Node.EventType.SIZE_CHANGED, this.updateScale, this);
    }

    public updateScale() {
        if (!this._targetTransform || !this._thisTransform) {
            return;
        }

        const targetSize = this._targetTransform.getContentSize();
        const thisSize = this._thisTransform.getContentSize();
        if (thisSize.width <= 0 || thisSize.height <= 0) {
            return;
        }

        let scaleX = 1;
        let scaleY = 1;
        switch (this.scaleMode) {
            case ScaleMode.NONE:
                return;
            case ScaleMode.EXACT_FIT:
                scaleX = targetSize.width / thisSize.width;
                scaleY = targetSize.height / thisSize.height;
                break;
            case ScaleMode.NO_BORDER:
                scaleX = scaleY = Math.max(targetSize.width / thisSize.width, targetSize.height / thisSize.height);
                break;
            case ScaleMode.SHOW_ALL:
                scaleX = scaleY = Math.min(targetSize.width / thisSize.width, targetSize.height / thisSize.height);
                break;
            case ScaleMode.FIXED_HEIGHT:
                scaleX = scaleY = targetSize.height / thisSize.height;
                break;
            case ScaleMode.FIXED_WIDTH:
                scaleX = scaleY = targetSize.width / thisSize.width;
                break;
            default:
                break;
        }
        this.node.setScale(scaleX, scaleY);
    }
}

we.ui.WESizeScalar = WESizeScalar;
