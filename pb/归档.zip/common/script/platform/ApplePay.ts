import { CommonLanguage } from '../const/CommonLanguage';
import PayManager, { PurchaseInfo } from '../manager/PayManager';

declare global {
    interface ICommon {
        applePay: typeof ApplePay;
    }
}
// // error codes for the SKErrorDomain
// typedef NS_ENUM(NSInteger, SKErrorCode) {
//     SKErrorUnknown,
//     SKErrorClientInvalid,                                                                         // client is not allowed to issue the request, etc.
//     SKErrorPaymentCancelled,                                                                      // user cancelled the request, etc.
//     SKErrorPaymentInvalid,                                                                        // purchase identifier was invalid, etc.
//     SKErrorPaymentNotAllowed,                                                                     // this device is not allowed to make the payment
//     SKErrorStoreProductNotAvailable API_AVAILABLE(ios(3.0), macos(10.15)),                        // Product is not available in the current storefront
//     SKErrorCloudServicePermissionDenied API_AVAILABLE(ios(9.3)) API_UNAVAILABLE(macos),           // user has not allowed access to cloud service information
//     SKErrorCloudServiceNetworkConnectionFailed API_AVAILABLE(ios(9.3)) API_UNAVAILABLE(macos),    // the device could not connect to the nework
//     SKErrorCloudServiceRevoked API_AVAILABLE(ios(10.3)) API_UNAVAILABLE(macos),                   // user has revoked permission to use this cloud service
//     SKErrorPrivacyAcknowledgementRequired API_AVAILABLE(ios(12.2), macos(10.14.4)),               // The user needs to acknowledge Apple's privacy policy
//     SKErrorUnauthorizedRequestData API_AVAILABLE(ios(12.2), macos(10.14.4)),                      // The app is attempting to use SKPayment's requestData property, but does not have the appropriate entitlement
//     SKErrorInvalidOfferIdentifier API_AVAILABLE(ios(12.2), macos(10.14.4)),                       // The specified subscription offer identifier is not valid
//     SKErrorInvalidSignature API_AVAILABLE(ios(12.2), macos(10.14.4)),                             // The cryptographic signature provided is not valid
//     SKErrorMissingOfferParams API_AVAILABLE(ios(12.2), macos(10.14.4)),                           // One or more parameters from SKPaymentDiscount is missing
//     SKErrorInvalidOfferPrice API_AVAILABLE(ios(12.2), macos(10.14.4))                             // The price of the selected offer is not valid (e.g. lower than the current base subscription price)
// } API_AVAILABLE(ios(3.0), macos(10.7));

enum APPLE_PAY_CODE {
    // SDK
    SKErrorUnknown = 0,
    SKErrorClientInvalid, // client is not allowed to issue the request, etc.
    SKErrorPaymentCancelled, // user cancelled the request, etc.
    SKErrorPaymentInvalid, // purchase identifier was invalid, etc.
    SKErrorPaymentNotAllowed, // this device is not allowed to make the payment
    SKErrorStoreProductNotAvailable, // Product is not available in the current storefront
    SKErrorCloudServicePermissionDenied, // user has not allowed access to cloud service information
    SKErrorCloudServiceNetworkConnectionFailed, // the device could not connect to the nework
    SKErrorCloudServiceRevoked, // user has revoked permission to use this cloud service
    SKErrorPrivacyAcknowledgementRequired, // The user needs to acknowledge Apple's privacy policy
    SKErrorUnauthorizedRequestData, // The app is attempting to use SKPayment's requestData property, but does not have the appropriate entitlement
    SKErrorInvalidOfferIdentifier, // The specified subscription offer identifier is not valid
    SKErrorInvalidSignature, // The cryptographic signature provided is not valid
    SKErrorMissingOfferParams, // One or more parameters from SKPaymentDiscount is missing
    SKErrorInvalidOfferPrice, // The price of the selected offer is not valid (e.g. lower than the current base subscription price)

    // 自定义
    ErrorCodeProductIdInvalid = 100, // 商品id无效
    ErrorCodeProductListInvalid = 101, // 商品列表无效
    ErrorCodeProductNotExist = 102, // 该商品不存在
    ErrorCodePurchaseListInvalid = 105, // 购买列表无效
    ErrorCodePurchaseNotExist = 106, // 购买信息不存在
    ErrorCodeDeviceUnablePay = 110, // 设备不能进行支付
    ErrorCodePlatformNotSupport = 200, // 平台不支持
}

export default class ApplePay {
    /**
     * 发起内购
     * @param productId 商品id
     * @param payload 透传参数
     */
    public static purchaseInApp(productId: string, payload: string) {
        we.log(`ApplePay purchaseInApp, productId: ${productId}, payload: ${payload}`);

        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'ApplePay purchaseInApp' });

        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS) {
            let className = 'NativeUtil';
            let methodName = 'wegame_applePayPurchaseInApp:payload:';
            jsb.reflection.callStaticMethod(className, methodName, productId, payload);
        } else {
            // @ts-ignore
            cc.onApplePayError(APPLE_PAY_CODE.ErrorCodePlatformNotSupport);
        }
    }

    /**
     * 消耗内购商品
     * @param productId 商品id
     * @param orderId 订单id
     */
    public static consumeInApp(productId: string, orderId: string) {
        we.log(`ApplePay consumeInApp, productId: ${productId}, orderId: ${orderId}`);

        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'ApplePay consumeInApp' });

        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS) {
            let className = 'NativeUtil';
            let methodName = 'wegame_applePayConsumeInApp:orderId:';
            jsb.reflection.callStaticMethod(className, methodName, productId, orderId);
        }
    }

    /**
     * 处理未完成交易
     * @param productId 商品id
     */
    public static processUncompleteTransaction(productId: string = '') {
        we.log(`ApplePay processUncompleteTransaction, productId: ${productId}`);

        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS) {
            let className = 'NativeUtil';
            let methodName = 'wegame_applePayProcessUncompleteTransaction:';
            jsb.reflection.callStaticMethod(className, methodName, productId);
        }
    }
}

/**
 * 支付成功
 */
// @ts-ignore
cc.onApplePayPurchaseSuccess = (purchaseInfo: string) => {
    setTimeout(() => {
        we.log(`AppleLogin onApplePayPurchaseSuccess, purchaseInfo: ${purchaseInfo}`);

        we.commonUI.hideCircleLoading();

        if (!we.core.projectConfig.isLoginComplete) {
            return;
        }

        let purchaseData: PurchaseInfo = null;
        try {
            purchaseData = JSON.parse(purchaseInfo);
            if (purchaseData) {
                purchaseData.payType = PayManager.PAY_TYPE.APPLE;
            }
        } catch (err) {
            we.error(`ApplePay onApplePayPurchaseSuccess, err: ${JSON.stringify(err.message || err)}`);
        }

        if (purchaseData) {
            PayManager.authPurchaseInfo(purchaseData);
        }
    });
};

we.common.applePay = ApplePay;

/**
 * 消耗成功
 */
// @ts-ignore
cc.onApplePayConsumeSuccess = (msg: string) => {
    setTimeout(() => {
        we.log(`AppleLogin onApplePayConsumeSuccess, msg: ${msg}`);

        we.commonUI.hideCircleLoading();

        if (!we.core.projectConfig.isLoginComplete) {
            return;
        }
    });
};

/**
 * 支付错误
 */
// @ts-ignore
cc.onApplePayError = (code: number) => {
    setTimeout(() => {
        we.log(`AppleLogin onApplePayError, code: ${code}`);

        we.commonUI.hideCircleLoading();

        if (!we.core.projectConfig.isLoginComplete) {
            return;
        }

        let tip = '';
        code = Number(code);
        switch (code) {
            case APPLE_PAY_CODE.SKErrorPaymentCancelled:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_PAY_CANCEL);
                break;
            case APPLE_PAY_CODE.SKErrorCloudServiceNetworkConnectionFailed:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_PAY_NO_CONNECT);
                break;
            case APPLE_PAY_CODE.SKErrorPrivacyAcknowledgementRequired:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_PAY_PRIVACY_POLICY);
                break;
            case APPLE_PAY_CODE.SKErrorPaymentNotAllowed:
            case APPLE_PAY_CODE.ErrorCodeDeviceUnablePay:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_PAY_DEVICE_UNABLE_PAY);
                break;
            default:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_PAY_FAIL);
                break;
        }

        we.commonUI.showToast(tip + ': ' + code);

        switch (code) {
            case APPLE_PAY_CODE.SKErrorPaymentCancelled:
                break;
            default:
                setTimeout(() => {
                    PayManager.rechargeFailCountAdd();
                }, 1000);
                break;
        }
    });
};
