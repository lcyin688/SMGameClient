import { CommonLanguage } from '../const/CommonLanguage';
import LoginManager from '../manager/LoginManager';

declare global {
    interface ICommon {
        appleLogin: typeof AppleLogin;
    }
}

// typedef NS_ERROR_ENUM(ASAuthorizationErrorDomain, ASAuthorizationError) {
//     ASAuthorizationErrorUnknown = 1000,
//     ASAuthorizationErrorCanceled = 1001,
//     ASAuthorizationErrorInvalidResponse = 1002,
//     ASAuthorizationErrorNotHandled = 1003,
//     ASAuthorizationErrorFailed = 1004,
// } API_AVAILABLE(ios(13.0), macos(10.15), tvos(13.0), watchos(6.0));

enum APPLE_LOGIN_CODE {
    // SDK
    ASAuthorizationErrorUnknown = 1000,
    ASAuthorizationErrorCanceled = 1001,
    ASAuthorizationErrorInvalidResponse = 1002,
    ASAuthorizationErrorNotHandled = 1003,
    ASAuthorizationErrorFailed = 1004,

    // 自定义
    ErrorCodeSystemInvalid = 100, // 系统无效
    ErrorCodeAuthorizationInvalid = 101, // 授权信息无效
    ErrorCodeAuthorizationError = 102, // 授权信息错误
}

export default class AppleLogin {
    /**
     * 登录
     */
    public static login() {
        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'AppleLogin login' });

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_appleLogin';
                jsb.reflection.callStaticMethod(className, methodName);
            }
        } else {
            // @ts-ignore
            cc.onAppleLoginError(APPLE_LOGIN_CODE.ErrorCodeSystemInvalid);
        }
    }

    /**
     * 登出
     */
    public static logout() {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_appleLogout';
                jsb.reflection.callStaticMethod(className, methodName);
            }
        }
    }
}

we.common.appleLogin = AppleLogin;

/**
 * 登录成功
 */
// @ts-ignore
cc.onAppleLoginSuccess = (authInfo: string) => {
    setTimeout(() => {
        we.log(`AppleLogin cc.onAppleLoginSuccess, authInfo: ${authInfo}`);

        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.APPLE_LOGIN_SUCCESS));
        LoginManager.appleLogin(authInfo);
    });
};

/**
 * 登录错误
 */
// @ts-ignore
cc.onAppleLoginError = (code: string) => {
    setTimeout(() => {
        we.log(`AppleLogin cc.onAppleLoginError, code: ${code}`);

        cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
        we.commonUI.hideCircleLoading();

        let tip = '';
        switch (parseInt(code)) {
            case APPLE_LOGIN_CODE.ASAuthorizationErrorCanceled:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_LOGIN_CANCEL);
                break;
            case APPLE_LOGIN_CODE.ErrorCodeSystemInvalid:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_LOGIN_SYSTEM_INVALID);
                break;
            default:
                tip = we.core.langMgr.getLangText(CommonLanguage.APPLE_LOGIN_FAIL);
                break;
        }

        we.commonUI.showToast(tip + ': ' + code);
    });
};
