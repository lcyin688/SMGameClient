// responseCode
// /** The request has reached the maximum timeout before Google Play responds. */
// int SERVICE_TIMEOUT = -3;
// /** Requested feature is not supported by Play Store on the current device. */
// int FEATURE_NOT_SUPPORTED = -2;
// /**
//  * Play Store service is not connected now - potentially transient state.
//  *
//  * <p>E.g. Play Store could have been updated in the background while your app was still
//  * running. So feel free to introduce your retry policy for such use case. It should lead to a
//  * call to {@link #startConnection} right after or in some time after you received this code.
//  */
// int SERVICE_DISCONNECTED = -1;
// /** Success */
// int OK = 0;
// /** User pressed back or canceled a dialog */
// int USER_CANCELED = 1;
// /** Network connection is down */
// int SERVICE_UNAVAILABLE = 2;
// /** Billing API version is not supported for the type requested */
// int BILLING_UNAVAILABLE = 3;
// /** Requested product is not available for purchase */
// int ITEM_UNAVAILABLE = 4;
// /**
//  * Invalid arguments provided to the API. This error can also indicate that the application was
//  * not correctly signed or properly set up for In-app Billing in Google Play, or does not have
//  * the necessary permissions in its manifest
//  */
// int DEVELOPER_ERROR = 5;
// /** Fatal error during the API action */
// int ERROR = 6;
// /** Failure to purchase since item is already owned */
// int ITEM_ALREADY_OWNED = 7;
// /** Failure to consume since item is not owned */
// int ITEM_NOT_OWNED = 8;

import { CommonLanguage } from '../const/CommonLanguage';
import PayManager, { PurchaseInfo } from '../manager/PayManager';

declare global {
    interface ICommon {
        googlePay: typeof GooglePay;
    }
}

enum GOOGLE_PAY_CODE {
    // SDK
    SERVICE_TIMEOUT = -3,
    FEATURE_NOT_SUPPORTED = -2,
    SERVICE_DISCONNECTED = -1,
    OK = 0,
    USER_CANCELED = 1,
    SERVICE_UNAVAILABLE = 2,
    BILLING_UNAVAILABLE = 3,
    ITEM_UNAVAILABLE = 4,
    DEVELOPER_ERROR = 5,
    ERROR = 6,
    ITEM_ALREADY_OWNED = 7,
    ITEM_NOT_OWNED = 8,

    // 自定义
    PRODUCT_ID_INVALID = 100, // 商品id无效
    PRODUCT_LIST_INVALID = 101, // 商品列表无效
    PRODUCT_NOT_EXIST = 102, // 该商品不存在
    PURCHASE_LIST_INVALID = 105, // 购买列表无效
    PURCHASE_NOT_EXIST = 106, // 购买信息不存在
    PURCHASE_STATE_PENDING = 107, // 购买状态待定
    PURCHASE_STATE_INVALID = 108, // 购买状态无效
    PURCHASE_PAYLOAD_INVALID = 120, // 透传参数无效
    PLATFORM_NOT_SUPPORT = 200, // 平台不支持
}

export default class GooglePay {
    /**
     * 发起内购
     * @param productId 商品id
     * @param payload 透传参数
     */
    public static purchaseInApp(productId: string, payload: string) {
        we.log(`GooglePay purchaseInApp, productId: ${productId}, payload: ${payload}`);

        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'GoogleLogin purchaseInApp' });

        if (!(typeof payload == 'string' && payload.length <= 64)) {
            // @ts-ignore
            cc.onGooglePayError(GOOGLE_PAY_CODE.PURCHASE_PAYLOAD_INVALID);
            return;
        }

        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID) {
            let className = 'org/cocos2dx/game/util/NativeUtil';
            let methodName = 'wegame_googlePayPurchaseInApp';
            let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
            jsb.reflection.callStaticMethod(className, methodName, methodSignature, productId, payload);
        } else {
            // @ts-ignore
            cc.onGooglePayError(GOOGLE_PAY_CODE.PLATFORM_NOT_SUPPORT);
        }
    }

    /**
     * 消耗商品
     * @param productId 商品id
     * @param orderId 订单id
     */
    public static consumeInApp(productId: string, orderId: string) {
        we.log(`GooglePay consumeInApp, productId: ${productId}, orderId: ${orderId}`);

        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'GoogleLogin consumeInApp' });

        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID) {
            let className = 'org/cocos2dx/game/util/NativeUtil';
            let methodName = 'wegame_googlePayConsumeInApp';
            let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
            jsb.reflection.callStaticMethod(className, methodName, methodSignature, productId, orderId);
        }
    }

    /**
     * 处理未完成交易
     * @param productId 商品id
     */
    public static processUncompleteTransaction(productId: string = '') {
        we.log(`GooglePay processUncompleteTransaction, productId: ${productId}`);

        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID) {
            let className = 'org/cocos2dx/game/util/NativeUtil';
            let methodName = 'wegame_googlePayProcessUncompleteTransaction';
            let methodSignature = '(Ljava/lang/String;)V';
            jsb.reflection.callStaticMethod(className, methodName, methodSignature, productId);
        }
    }
}

we.common.googlePay = GooglePay;

/**
 * 支付成功
 */
// @ts-ignore
cc.onGooglePayPurchaseSuccess = (purchaseInfo: string) => {
    setTimeout(() => {
        we.log(`GooglePay onGooglePayPurchaseSuccess, purchaseInfo: ${purchaseInfo}`);

        we.commonUI.hideCircleLoading();

        if (!we.core.projectConfig.isLoginComplete) {
            return;
        }

        let purchaseData: PurchaseInfo = null;
        try {
            purchaseData = JSON.parse(purchaseInfo);
            if (purchaseData) {
                purchaseData.payType = PayManager.PAY_TYPE.GOOGLE;
            }
        } catch (err) {
            we.error(`GooglePay onGooglePayPurchaseSuccess, err: ${JSON.stringify(err.message || err)}`);
        }

        if (purchaseData) {
            PayManager.authPurchaseInfo(purchaseData);
        }
    });
};

/**
 * 消耗成功
 */
// @ts-ignore
cc.onGooglePayConsumeSuccess = (msg: string) => {
    setTimeout(() => {
        we.log(`GooglePay onGooglePayConsumeSuccess, msg: ${msg}`);

        we.commonUI.hideCircleLoading();

        if (!we.core.projectConfig.isLoginComplete) {
            return;
        }
    });
};

/**
 * 支付错误
 */
// @ts-ignore
cc.onGooglePayError = (code: number) => {
    setTimeout(() => {
        we.log(`GooglePay onGooglePayError, code: ${code}`);

        we.commonUI.hideCircleLoading();

        if (!we.core.projectConfig.isLoginComplete) {
            return;
        }

        let tip = '';
        code = Number(code);
        switch (code) {
            case GOOGLE_PAY_CODE.SERVICE_TIMEOUT:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_SERVICE_TIMEOUT);
                break;
            case GOOGLE_PAY_CODE.FEATURE_NOT_SUPPORTED:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_FEATURE_NOT_SUPPORTED);
                break;
            case GOOGLE_PAY_CODE.SERVICE_DISCONNECTED:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_SERVICE_DISCONNECTED);
                break;
            case GOOGLE_PAY_CODE.USER_CANCELED:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_USER_CANCELED);
                break;
            case GOOGLE_PAY_CODE.SERVICE_UNAVAILABLE:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_SERVICE_UNAVAILABLE);
                break;
            case GOOGLE_PAY_CODE.BILLING_UNAVAILABLE:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_BILLING_UNAVAILABLE);
                break;
            case GOOGLE_PAY_CODE.ERROR:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_PERMISSION_BACKGROUND);
                break;
            case GOOGLE_PAY_CODE.PURCHASE_STATE_PENDING:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_PURCHASE_STATE_PENDING);
                break;
            default:
                tip = we.core.langMgr.getLangText(CommonLanguage.GOOGLE_PAY_FAIL);
                break;
        }

        tip = tip + ': ' + code;

        switch (code) {
            case GOOGLE_PAY_CODE.PURCHASE_STATE_PENDING: {
                // let rootNode = we.ui.UILayer.rootNode;
                // if (!(cc.isValid(rootNode) && rootNode.getChildByName('DLG_GOOGLE_PAY_ERROR'))) {
                //     let data = {} as we.ICommonDialog;
                //     data.content = tip;
                //     data.positiveCb = () => {
                //         we.core.nativeUtil.openUrlByApp('https://play.google.com/store/account/orderhistory', 'com.android.vending');
                //     };
                //     CommonMgr.createCommonDialog(data, 'DLG_GOOGLE_PAY_ERROR');
                // }

                we.commonUI.showConfirm({
                    content: tip,
                    isHideCloseBtn: true,
                    yesHandler: we.core.Func.create(() => {
                        we.core.nativeUtil.openUrlByApp('https://play.google.com/store/account/orderhistory', 'com.android.vending');
                    }),
                });
                break;
            }
            default:
                we.commonUI.showToast(tip);
                break;
        }

        switch (code) {
            case GOOGLE_PAY_CODE.USER_CANCELED:
            case GOOGLE_PAY_CODE.PURCHASE_STATE_PENDING:
                break;
            default:
                // 有提示Toast 延迟下
                setTimeout(() => {
                    PayManager.rechargeFailCountAdd();
                }, 1000);
                break;
        }
    });
};
