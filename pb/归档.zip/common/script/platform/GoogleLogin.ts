import { CommonLanguage } from '../const/CommonLanguage';
import LoginManager from '../manager/LoginManager';

declare global {
    interface ICommon {
        googleLogin: typeof GoogleLogin;
    }
}

enum GOOGLE_LOGIN_CODE {
    // 自定义
    ACCOUNT_NULL = 100, // 账号为空
    ERROR = 101, // 其他错误
}

export default class GoogleLogin {
    /**
     * 登录
     */
    public static login() {
        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'GoogleLogin login' });

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_googleLogin';
                let methodSignature = '()V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            }
        } else {
            // @ts-ignore
            cc.onGoogleLoginError(GOOGLE_LOGIN_CODE.ACCOUNT_NULL);
        }
    }

    /**
     * 登出
     */
    public static logout() {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                if (localStorage.getItem('google_login_auth') != '1') {
                    return;
                }

                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_googleLogout';
                let methodSignature = '()V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature);
                localStorage.setItem('google_login_auth', '0');
            }
        }
    }
}

we.common.googleLogin = GoogleLogin;

/**
 * 登录成功
 */
// @ts-ignore
cc.onGoogleLoginSuccess = (authInfo: string) => {
    setTimeout(() => {
        we.log(`GoogleLogin cc.onGoogleLoginSuccess, authInfo: ${authInfo}`);

        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.GOOGLE_LOGIN_SUCCESS));
        LoginManager.googleLogin(authInfo);
        localStorage.setItem('google_login_auth', '1');
    });
};

/**
 * 登录错误
 */
// @ts-ignore
cc.onGoogleLoginError = (code: string) => {
    setTimeout(() => {
        we.log(`GoogleLogin cc.onGoogleLoginError, code: ${code}`);

        cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.GOOGLE_LOGIN_FAIL) + ': ' + code);
    });
};
