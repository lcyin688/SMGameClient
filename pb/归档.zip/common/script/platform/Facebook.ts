import { CommonLanguage } from '../const/CommonLanguage';
import LoginManager from '../manager/LoginManager';

declare global {
    interface ICommon {
        facebook: typeof Facebook;
    }
}

export default class Facebook {
    /**
     * 登录
     */
    public static login() {
        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'Facebook login' });

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_facebookLogin';
                let methodSignature = '()V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_facebookLogin';
                jsb.reflection.callStaticMethod(className, methodName);
            }
        } else {
            let local = cc.sys.isBrowser && window.location.hostname == 'localhost';
            let fbAccount = we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.fbaccount);
            if (local && fbAccount) {
                let authInfo = {
                    user_id: '',
                    access_token: 'fbtest' + '_' + fbAccount,
                };
                (<any>cc).onFacebookLoginSuccess(JSON.stringify(authInfo));
            } else {
                (<any>cc).onFacebookLoginError('-100');
            }
        }
    }

    /**
     * 登出
     */
    public static logout() {
        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_facebookLogout';
                let methodSignature = '()V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_facebookLogout';
                jsb.reflection.callStaticMethod(className, methodName);
            }
        }
    }

    /**
     * 分享链接
     * @param url
     * @param hashtag 话题标签，默认空
     * @param quote 引文，默认空
     */
    public static shareLink(url: string, hashtag: string = '', quote: string = '') {
        we.log(`Facebook shareLink, url: ${url}, hashtag: ${hashtag}, quote: ${quote}`);

        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'Facebook shareLink' });

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_facebookShareLink';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, url, hashtag, quote);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_facebookShareLink:hashtag:quote:';
                jsb.reflection.callStaticMethod(className, methodName, url, hashtag, quote);
            }
        } else {
            we.core.nativeUtil.openUrl('https://www.facebook.com');
            (<any>cc).onFacebookShareSuccess('test');
        }
    }

    /**
     * 分享图片
     * @param imagePath
     * @param hashtag 话题标签，默认空
     */
    public static shareImage(imagePath: string, hashtag: string = '') {
        we.log(`Facebook shareImage, imagePath: ${imagePath}, hashtag: ${hashtag}`);

        we.commonUI.showCircleLoading({ text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING), debug: 'Facebook shareImage' });

        if (cc.sys.isNative) {
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                let className = 'org/cocos2dx/game/util/NativeUtil';
                let methodName = 'wegame_facebookShareImage';
                let methodSignature = '(Ljava/lang/String;Ljava/lang/String;)V';
                jsb.reflection.callStaticMethod(className, methodName, methodSignature, imagePath, hashtag);
            } else if (cc.sys.os == cc.sys.OS_IOS) {
                let className = 'NativeUtil';
                let methodName = 'wegame_facebookShareImage:hashtag:';
                jsb.reflection.callStaticMethod(className, methodName, imagePath, hashtag);
            }
        } else {
            we.core.nativeUtil.openUrl('https://www.facebook.com');
            (<any>cc).onFacebookShareSuccess('test');
        }
    }

    /**
     * 是否启用fb登录
     * @returns
     */
    public static isLoginEnabled(): boolean {
        let chn = we.core.nativeUtil.getChannel();
        let enabledChns: string[] = ['appstore_ios', 'google_android', 'letusdomino_google', 'letusdomino_apple'];

        if (enabledChns.indexOf(chn) != -1) {
            return true;
        }

        return false;
    }
}

we.common.facebook = Facebook;

/**
 * 登录成功
 */
// @ts-ignore
cc.onFacebookLoginSuccess = (authInfo: string) => {
    setTimeout(() => {
        we.log(`Facebook onFacebookLoginSuccess, authInfo: ${authInfo}`);

        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.FACEBOOK_SUCCESS));
        LoginManager.facebookLogin(authInfo);
    });
};

/**
 * 登录取消
 */
// @ts-ignore
cc.onFacebookLoginCancel = () => {
    setTimeout(() => {
        we.log(`Facebook onFacebookLoginCancel`);

        cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.FACEBOOK_CANCEL));
    });
};

/**
 * 登录错误
 */
// @ts-ignore
cc.onFacebookLoginError = (error: string) => {
    setTimeout(() => {
        we.warn(`Facebook onFacebookLoginError, error: ${error}`);

        cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.FACEBOOK_ERROR) + ': ' + error);
    });
};

/**
 * 分享成功
 */
// @ts-ignore
cc.onFacebookShareSuccess = (result: string) => {
    setTimeout(() => {
        we.log(`Facebook onFacebookShareSuccess, result: ${result}`);

        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.FACEBOOK_SHARE_SUCCESS));
        cc.director.emit(we.core.EventName.FACEBOOK_SHARE_SUCCESS);
    });
};

/**
 * 分享取消
 */
// @ts-ignore
cc.onFacebookShareCancel = () => {
    setTimeout(() => {
        we.log(`Facebook onFacebookShareCancel`);

        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.FACEBOOK_SHARE_CANCLE));
    });
};

/**
 * 分享错误
 */
// @ts-ignore
cc.onFacebookShareError = (error: string) => {
    setTimeout(() => {
        we.warn(`Facebook onFacebookShareError, error: ${error}`);

        we.commonUI.hideCircleLoading();
        we.commonUI.showToast(we.core.langMgr.getLangText(CommonLanguage.FACEBOOK_SHARE_ERROR) + ': ' + error);
    });
};
