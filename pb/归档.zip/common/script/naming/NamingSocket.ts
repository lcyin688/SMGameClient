import SocketManager from '../manager/SocketManager';
import NamingProtoFile from '../proto/NamingProtoFile';
import { NamingProtoMsg } from '../proto/NamingProtoMsg';
import CommonProtoBuf from '../socket/CommonProtoBuf';
import CommonSocket from '../socket/CommonSocket';
import { WsCloseCode } from '../socket/SocketCode';
import { NamingActionNType } from './NamingServiceMgr';

export default class NamingSocket {
    public static socketUrl: string = '';
    private static protoBuf: CommonProtoBuf = null;
    private static socket: CommonSocket = null;

    public static init(messageCallback: (msgId: number, msgData: Object) => void) {
        this.close(WsCloseCode.New, `NamingSocket init`);
        this.protoBuf = new CommonProtoBuf(NamingProtoFile, NamingProtoMsg, { enums: Number });

        let onMessage = (data: ArrayBuffer | { msgId: number; msgData: Object }) => {
            let msg = data instanceof ArrayBuffer ? this.protoBuf.decode(data) : data;
            if (msg && NamingProtoMsg[msg.msgId]) {
                we.log(`NamingSocket receive, msgId: ${msg.msgId} msgName: ${NamingProtoMsg[msg.msgId]} \nmsgData: ${JSON.stringify(msg.msgData)}`);

                if (typeof messageCallback == 'function') {
                    messageCallback(msg.msgId, msg.msgData);
                }
            }
        };

        this.socket = SocketManager.get(we.GameId.NAMING);
        this.socket.init(this.socketUrl, onMessage);
    }

    public static close(code: WsCloseCode, reason: string) {
        if (this.socket != null) {
            this.socket.close(code, reason);
            this.socket = null;
            SocketManager.destroy(we.GameId.NAMING);
        }
    }

    public static send(msgId: number, msgData: Object) {
        we.log(`NamingSocket send, msgId: ${msgId} msgName: ${NamingProtoMsg[msgId]} \nmsgData: ${JSON.stringify(msgData)}`);

        let msg = this.protoBuf.encode(msgId, msgData);
        if (this.socket) {
            this.socket.send(msg);
        }
    }

    public static isConnected() {
        if (this.socket) {
            return this.socket.isConnected();
        }

        return false;
    }

    public static reportReq(param: string) {
        let data = {
            Timestamp: new Date().getTime(),
            MsgID: param,
        } as NamingProto.ReportReq;
        this.send(NamingProtoMsg.ReportReq, data);
    }

    public static sendActionNTReq(actionType: NamingActionNType) {
        this.send(NamingProtoMsg.ActionNTReq, { ActionType: actionType });
    }
}
