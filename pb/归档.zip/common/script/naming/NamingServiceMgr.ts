import { CommonEvent } from '../config/CommonEvent';
import { CommonLanguage } from '../const/CommonLanguage';
import CommonMgr from '../manager/CommonMgr';
import MarqueeMgr from '../manager/MarqueeMgr';
import PushMsgMgr from '../manager/PushMsgMgr';
import UserManager from '../manager/UserManager';
import { NamingProtoMsg } from '../proto/NamingProtoMsg';
import { WsCloseCode, WsCode } from '../socket/SocketCode';
import NamingSocket from './NamingSocket';

declare global {
    interface ICommon {
        namingServiceMgr: typeof NamingServiceMgr;
        NamingActionNType: typeof NamingActionNType;
    }
}

/** 推送事件回执名 */
export const ReceiptName = {
    /** 充值上报 */
    payReport: 'PayReport',
};

export enum NamingActionNType {
    /** 从子游戏返回大厅 */
    RETURN_LOBBY_FROM_Game = 0,
}

we.common.NamingActionNType = NamingActionNType;

export default class NamingServiceMgr {
    public static goLoginTag: boolean = false;
    private static checkConnectCount: number = 0;
    private static checkConnectInterval: number = 0;
    private static checkConnectTimer: any = null;
    private static unconnectedCount: number = 0;

    // 缓存首次大厅游戏入口 JP 数据，因为登陆成功后会立即连接 naming，hall 接收 JP 数据监听还未注册
    public static hallGameEntryJpData: NamingProto.JackpotNT = null;

    public static init(): void {
        this.goLoginTag = false;
        this.checkConnectCount = 0;
        this.unconnectedCount = 0;

        if (!UserManager.isLogin()) {
            return;
        }

        NamingSocket.init(this.onSocketMessage.bind(this));
        this.checkConnectStatus();

        cc.director.off(we.core.EventName.NETWORK_ONLINE, this.onNetworkOnline, this);
        cc.director.off(we.core.EventName.NETWORK_OFFLINE, this.onNetworkOffline, this);

        cc.director.on(we.core.EventName.NETWORK_ONLINE, this.onNetworkOnline, this);
        cc.director.on(we.core.EventName.NETWORK_OFFLINE, this.onNetworkOffline, this);
    }

    public static close(code: WsCloseCode, reason: string): void {
        this.hallGameEntryJpData = null;

        NamingSocket.close(code, reason);
    }

    /**
     * 退回登录界面
     */
    public static goLogin(): void {
        if (we.core.gameConfig.curGameId > we.GameId.LAUNCHER) {
            this.goLoginTag = false;
            CommonMgr.goLogin(we.core.langMgr.getLangText(CommonLanguage.ERROR_USUAL_TYPE_300));
        } else {
            this.goLoginTag = true;
        }
    }

    /**
     * 推送上报
     * @param param 参数
     */
    public static reportReq(param: string): void {
        NamingSocket.reportReq(param);
    }

    /**
     * 推送状态
     * @param actionType 状态值
     */
    public static sendActionNTReq(actionType: NamingActionNType): void {
        NamingSocket.sendActionNTReq(actionType);
    }

    private static onNetworkOnline(): void {
        this.init();
    }

    private static onNetworkOffline(): void {
        this.close(we.common.WsCloseCode.NetOffline, 'NamingServiceMgr onNetworkOffline');
    }

    private static onSocketMessage(msgId: NamingProtoMsg, msgData: any): void {
        if (NamingProtoMsg.ErrorST == msgId) {
            this.onErrorSt(msgData);
        } else if (NamingProtoMsg.BroadCastNT == msgId) {
            MarqueeMgr.onPushNewMessage(msgData);
        } else if (NamingProtoMsg.UserNoticeNT == msgId) {
            PushMsgMgr.pushMessageHandle(msgData);
        } else if (NamingProtoMsg.ReportResp == msgId) {
            we.info(`NamingServiceMgr onSocketMessage ReportReq, pushMsg report resp`);
        } else if (NamingProtoMsg.UserAlertNT == msgId) {
            cc.director.emit(CommonEvent.NAMING_ALTER_PUSH_MSG_HANDLE, msgData);
        } else if (NamingProtoMsg.JackpotNT == msgId) {
            // 仅缓存首次
            if (!this.hallGameEntryJpData) {
                this.hallGameEntryJpData = msgData;
            }

            cc.director.emit(CommonEvent.NAMING_JACKPOT_PUSH_MSG_HANDLE, msgData);
        }
    }

    private static onErrorSt(msgData: CommonProto.ErrorST): void {
        switch (msgData?.Code) {
            case WsCode.CLOSE_CODE_TOKEN_NOT_MATCH:
            case WsCode.CLOSE_CODE_SERVICE_UNKNOWN_ERROR:
                UserManager.clearLoginData(false, `naming token err: ${msgData?.Code}, tokenV2: ${UserManager.tokenV2}`);
                this.goLogin();
                break;
            default:
                break;
        }
    }

    /**
     * 检测连接状态
     */
    private static checkConnectStatus(): void {
        this.clearCheckConnectTimer();

        let min = 60_000;
        this.checkConnectCount++;
        if (this.checkConnectCount == 1) {
            this.checkConnectInterval = min;
        } else if (this.checkConnectCount == 2) {
            this.checkConnectInterval = min * 2;
        } else {
            this.checkConnectInterval = min * 5;
        }

        this.checkConnectTimer = setTimeout(this.onCheckConnect.bind(this), this.checkConnectInterval);
    }

    /**
     * 清除检测定时器
     */
    private static clearCheckConnectTimer(): void {
        if (this.checkConnectTimer != null) {
            clearTimeout(this.checkConnectTimer);
            this.checkConnectTimer = null;
        }
    }

    /**
     * 检测
     */
    private static onCheckConnect(): void {
        we.log(`NamingServiceMgr onCheckConnect`);

        if (!UserManager.isLogin()) {
            return;
        }

        let connected = NamingSocket.isConnected();
        if (connected) {
            this.unconnectedCount = 0;
        } else {
            this.unconnectedCount++;

            // 第 2 次和每 5 次上报日志
            if (this.unconnectedCount == 2 || this.unconnectedCount % 5 == 0) {
                let data = {
                    custom: true,
                    monitor: 'naming', // naming 连接异常的监控标记
                    retryCount: this.unconnectedCount, // 重试次数, 呈现状态为 2 5 10 15 20 ...
                };
                we.error(`NamingServiceMgr onCheckConnect, naming connect failed, retryCount: ${this.unconnectedCount}`, data);
            }

            NamingSocket.init(this.onSocketMessage.bind(this));
        }

        this.checkConnectStatus();
    }
}

we.common.namingServiceMgr = NamingServiceMgr;
