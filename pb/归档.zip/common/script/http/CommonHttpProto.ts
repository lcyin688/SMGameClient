import UserManager from '../manager/UserManager';
import CommonUtils from '../utils/CommonUtils';
import CommonHttpBase from './CommonHttpBase';
import CommonProtoBufHttp from './CommonProtoBufHttp';
import HttpProtoError from './HttpProtoError';

export default class CommonHttpProto extends CommonHttpBase {
    private protobuf: CommonProtoBufHttp = null;
    private reqName: string = '';
    private respName: string = '';
    private sign: string = '';
    private aesKey: string = '';
    private signKey: string = '';

    public constructor() {
        super();
        this.protobuf = null;
        this.reqName = '';
        this.respName = '';
        this.sign = '';
        this.aesKey = 'kCBwZSXvpKC6iShm0BKBuw==';
        this.signKey = 'aGVsbG9uaSomZmQyZmZkOThzamd3YQ==';
    }

    /**
     * http请求接口
     * @param host 域名/ip + 端口
     * @param api api路径
     * @param type 请求类型
     * @param protobuf pb
     * @param reqData 请求数据
     * @param reqName req message name
     * @param respName resp message name
     * @param successCallback 成功回调
     * @param errorCallback 失败回调
     * @param loading 是否显示loading
     * @param delayLoading 是否延迟显示loading
     */
    public request(
        host: string,
        api: string,
        type: string,
        protobuf: CommonProtoBufHttp,
        reqData: Object,
        reqName: string,
        respName: string,
        successCallback: Function,
        errorCallback: Function,
        loading: boolean = false,
        delayLoading: boolean = true
    ) {
        if (!(host && api && type && protobuf)) {
            we.error(`CommonHttpProto request, params err`);
            return;
        }

        if (!(reqData == null || typeof reqData == 'object')) {
            we.error(`CommonHttpProto request, reqData err, api: ${api}`);
            return;
        }

        if (!(reqName && typeof reqName == 'string')) {
            we.error(`CommonHttpProto request, reqName err, api: ${api}`);
            return;
        }

        if (!(respName && typeof respName == 'string')) {
            we.error(`CommonHttpProto request, respName err, api: ${api}`);
            return;
        }

        this.host = host;
        this.api = api;
        this.requestType = type;
        this.protobuf = protobuf;
        this.reqData = reqData || {};
        this.reqName = reqName;
        this.respName = respName;
        this.successCallback = successCallback;
        this.errorCallback = errorCallback;
        this.loading = loading;
        this.delayLoading = delayLoading;

        this.showLoading();
        this.buildSendData();
        this.buildRequestUrl(host, api);
        this.startRequest();
    }

    /**
     * 设置超时时长
     * @param timeoutValue 单位 ms
     */
    public setTimeoutValue(timeoutValue: number) {
        this.timeoutValue = timeoutValue;
    }

    /**
     * 构建发送数据
     */
    private buildSendData() {
        let reqHeader = {} as ApiProto.ReqHeader;
        reqHeader.timestamp = new Date().getTime();

        let uid = UserManager.userInfo.userId;
        let token = UserManager.token;
        if (uid && token) {
            reqHeader.userId = uid;
            reqHeader.authToken = token;
        }

        this.reqData['header'] = reqHeader;
        let reqBuffer = this.protobuf.encode(this.reqName, this.reqData);

        this.requestData = this.aesEncrypt(reqBuffer, this.aesKey);
        this.sign = this.md5Digest(reqBuffer, this.deviceInfo, this.signKey);
    }

    /**
     * 构建url
     * @param host
     * @param api
     */
    protected buildRequestUrl(host: string, api: string) {
        super.buildRequestUrl(host, api);
        let params = '?sign=' + this.sign + '&trace_id=' + we.core.utils.generateUUID();
        this.requestUrl += params;
    }

    /**
     * 设置请求头
     */
    protected setRequestHeader() {
        this.httpRequest.setRequestHeader('content-type', 'application/x-protobuf');
        this.httpRequest.setRequestHeader('X-Auth-Track', this.deviceInfo);

        // Bearer Token 认证
        if (UserManager.tokenV2) {
            this.httpRequest.setRequestHeader('Authorization', `Bearer ${UserManager.tokenV2}`);
        }
    }

    /**
     * 设置响应类型
     */
    protected setResponseType() {
        this.httpRequest.responseType = 'arraybuffer';
    }

    /**
     * 发送请求
     */
    protected sendRequest() {
        let reqData = CommonUtils.maskSensitiveData(this.reqData);
        we.log(`CommonHttpProto sendRequest, requestUrl: ${this.requestUrl}\n` + `reqData: ${JSON.stringify(reqData)}`);

        if (this.requestData && this.requestType == 'POST') {
            this.httpRequest.send(this.requestData);
        } else {
            this.httpRequest.send();
        }
    }

    /**
     * 解析响应
     * @param response
     */
    protected parseResponse(response: ArrayBuffer) {
        try {
            let respBuffer = this.aesDecrypt(response, this.aesKey);
            this.respData = this.protobuf.decode(this.respName, respBuffer);
            let respHeader: ApiProto.RespHeader = this.respData['header'];
            let code = respHeader.code;

            we.log(`CommonHttpProto parseResponse, requestUrl: ${this.requestUrl}\n` + `respData: ${JSON.stringify(this.respData)}`);

            if (code == 0) {
                if (typeof this.successCallback == 'function') {
                    // 异步回调，避免回调中的异常抛出到这里
                    setTimeout(() => {
                        this.successCallback(this.respData);
                    });
                }
                this.hideLoading();
            } else {
                this.processError(code);
            }
        } catch (error) {
            this.processError(this.ERROR_CODE_C.RESPONSE_INVALID);
        }
    }

    /**
     * 处理错误
     * @param code
     */
    protected processError(code: string | number) {
        super.processError(code);
        HttpProtoError.processError(code, this.api);
    }

    private aesEncrypt(buffer: Uint8Array, key: string) {
        const cipher = we.npm.crypto.createCipheriv('aes-128-ecb', we.npm.Buffer.from(key, 'base64'), '');
        const crypted = cipher.update(we.npm.Buffer.from(buffer));
        return we.npm.Buffer.concat([we.npm.Buffer.from(crypted), we.npm.Buffer.from(cipher.final())]);
    }

    private aesDecrypt(buffer: Uint8Array | ArrayBuffer, key: string) {
        const cipher = we.npm.crypto.createDecipheriv('aes-128-ecb', we.npm.Buffer.from(key, 'base64'), '');
        const crypted = cipher.update(we.npm.Buffer.from(buffer));
        return we.npm.Buffer.concat([we.npm.Buffer.from(crypted), we.npm.Buffer.from(cipher.final())]);
    }

    private md5Digest(buffer: Uint8Array, deviceInfo: string, key: string) {
        const input = we.npm.Buffer.concat([we.npm.Buffer.from(buffer), we.npm.Buffer.from(deviceInfo), we.npm.Buffer.from(key, 'base64')]);
        const hash = we.npm.crypto.createHash('md5');
        return hash.update(input).digest('hex');
    }
}
