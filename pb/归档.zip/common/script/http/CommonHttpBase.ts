import CommonUtils from '../utils/CommonUtils';
import HttpProtoError from './HttpProtoError';

export default class CommonHttpBase {
    /** 客户端错误码 */
    protected readonly ERROR_CODE_C = cc.Enum({
        /** http超时 */
        HTTP_TIMEOUT: -101,
        /** http错误 */
        HTTP_ERROR: -102,
        /** 业务超时 */
        BUSINESS_TIMEOUT: -103,
        /** 状态错误 */
        STATUS_ERROR: -104,
        /** 响应为空 */
        RESPONSE_NULL: -105,
        /** 响应无效 */
        RESPONSE_INVALID: -106,
    });

    protected host: string = '';
    protected hostList: string[] = null;
    protected api: string = '';
    protected requestUrl: string = '';
    protected requestType: string = '';
    protected requestData: any = null;
    protected reqData: Object = null;
    protected respData: Object = null;
    protected successCallback: Function = null;
    protected errorCallback: Function = null;
    protected httpRequest: XMLHttpRequest = null;

    /** 超时时间 单位 ms */
    protected timeoutValue: number = 0;
    /** 业务超时计时器 */
    protected timerBusiness: any = null;
    /** 是否显示loading */
    protected loading: boolean = false;
    /** 是否延迟loading */
    protected delayLoading: boolean = true;
    /** 是否可以重试 */
    protected isCanRetry: boolean = false;
    /** 设备信息 */
    protected deviceInfo: string = '';
    /** 请求时间戳 */
    protected reqTs: number = 0;
    /** 响应时间戳 */
    protected respTs: number = 0;
    /** 异常锁 */
    private errorLock: boolean = false;
    /** 转圈回话取消 */
    private circleCancelAction: we.core.CancelAction;

    public constructor() {
        this.host = '';
        this.hostList = null;
        this.api = '';
        this.requestUrl = '';
        this.requestType = '';
        this.requestData = null;
        this.reqData = null;
        this.respData = null;
        this.successCallback = null;
        this.errorCallback = null;
        this.httpRequest = null;
        this.timeoutValue = 30_000;
        this.timerBusiness = null;
        this.loading = false;
        this.delayLoading = true;
        this.isCanRetry = false;
        this.deviceInfo = we.core.nativeUtil.getDeviceInfo();
        this.reqTs = new Date().getTime();
        this.errorLock = false;
    }

    /**
     * 构建url
     * @param host
     * @param api
     */
    protected buildRequestUrl(host: string, api: string) {
        this.requestUrl = we.core.utils.joinUrl(host, api);
    }

    /**
     * 开始请求
     */
    protected startRequest() {
        this.httpRequest = new XMLHttpRequest();
        this.httpRequest.timeout = this.timeoutValue;
        this.httpRequest.onreadystatechange = this.onResponse.bind(this);
        this.httpRequest.ontimeout = this.onTimeout.bind(this);
        this.httpRequest.onerror = this.onError.bind(this);
        this.httpRequest.open(this.requestType, this.requestUrl, true);

        this.setRequestHeader();
        this.setResponseType();
        this.sendRequest();
        this.setBusinessTimeout();
    }

    /**
     * 设置请求头
     */
    protected setRequestHeader() {
        we.warn(`CommonHttpBase setRequestHeader, subclasses should override`);
    }

    /**
     * 设置响应类型
     */
    protected setResponseType() {
        we.warn(`CommonHttpBase setResponseType, subclasses should override`);
    }

    /**
     * 发送请求
     */
    protected sendRequest() {
        we.log(`CommonHttpBase sendRequest, requestUrl: ${this.requestUrl}\n` + `requestData: ${this.requestData}`);

        if (this.requestData && this.requestType == 'POST') {
            this.httpRequest.send(this.requestData);
        } else {
            this.httpRequest.send();
        }
    }

    /**
     * 响应回调
     */
    protected onResponse() {
        const readyState = this.httpRequest.readyState;
        if (readyState != 4) {
            return;
        }

        this.clearBusinessTimeout();

        const status = this.httpRequest.status;
        if (!(status >= 200 && status <= 299)) {
            this.processError(this.ERROR_CODE_C.STATUS_ERROR + '.' + status);
            return;
        }

        const response = this.httpRequest.response;
        if (!response) {
            this.processError(this.ERROR_CODE_C.RESPONSE_NULL);
            return;
        }

        this.parseResponse(response);
    }

    /**
     * 解析响应
     * @param response
     */
    protected parseResponse(response: any) {
        we.warn(`CommonHttpBase parseResponse, subclasses should override`);
    }

    /**
     * 超时回调
     */
    protected onTimeout(event) {
        this.clearBusinessTimeout();
        this.processError(this.ERROR_CODE_C.HTTP_TIMEOUT);
        this.switchDomain();
    }

    /**
     * 错误回调
     */
    protected onError(event) {
        this.clearBusinessTimeout();
        this.processError(this.ERROR_CODE_C.HTTP_ERROR);
        this.switchDomain();
    }

    /**
     * 设置业务超时
     */
    protected setBusinessTimeout() {
        if (this.timerBusiness == null) {
            this.timerBusiness = setTimeout(this.onBusinessTimeout.bind(this), this.timeoutValue + 2_000);
        }
    }

    /**
     * 清除业务超时
     */
    protected clearBusinessTimeout() {
        if (this.timerBusiness) {
            clearTimeout(this.timerBusiness);
            this.timerBusiness = null;
        }
    }

    /**
     * 业务超时回调
     */
    protected onBusinessTimeout() {
        this.abortRequest();
        this.processError(this.ERROR_CODE_C.BUSINESS_TIMEOUT);
    }

    /**
     * 处理错误
     * @param code
     */
    protected processError(code: string | number) {
        if (this.errorLock) {
            return;
        }

        this.errorLock = true;
        let reqData = CommonUtils.maskSensitiveData(this.reqData);
        this.respTs = new Date().getTime();
        let exData = {
            custom: true,
            code: code,
            hostname: CommonUtils.getHostName(this.host),
            api: this.api,
            reqTs: this.reqTs,
            respTs: this.respTs,
        };

        if (typeof code == 'string') {
            let codes = code.split('.');
            if (codes.length == 2) {
                if (codes[0] == this.ERROR_CODE_C.STATUS_ERROR.toString()) {
                    exData['status'] = parseInt(codes[1]);
                }
            }
        }

        const msg = `CommonHttpBase processError, requestUrl: ${this.requestUrl}\n` + `code: ${code}\n` + `reqData: ${JSON.stringify(reqData)}\n` + `respData: ${JSON.stringify(this.respData)}`;

        if (HttpProtoError.isNeedReportError(code)) {
            we.warn(msg, exData);
        } else {
            we.warn(msg, exData, we.noup);
        }

        // if (this.retryWithBackupHost(code)) {
        //     return;
        // }

        if (typeof this.errorCallback == 'function') {
            setTimeout(() => {
                this.errorCallback(code);
            });
        }

        this.hideLoading();
    }

    /**
     * 用备用host重试
     * @param code
     * @returns 是否可以重试
     */
    protected retryWithBackupHost(code: number): boolean {
        this.isCanRetry = this.hostList && this.hostList.length > 0;
        if (this.isCanRetry) {
            we.log(`CommonHttpBase retryWithBackupHost, code: ${code}`);

            this.replaceHost();
            this.abortRequest();
            this.startRequest();
        }

        return this.isCanRetry;
    }

    /**
     * 替换host
     */
    protected replaceHost() {
        if (this.hostList && this.hostList.length > 0) {
            let newHost = this.hostList.shift();
            this.requestUrl = CommonUtils.replaceHostName(this.requestUrl, CommonUtils.getHostName(newHost));
        }
    }

    /**
     * 切换域名
     */
    protected switchDomain() {
        we.core.serverMgr.switchDomain(this.requestUrl);
    }

    /**
     * 中止请求
     */
    protected abortRequest() {
        this.httpRequest.abort();
    }

    /**
     * 显示loading
     */
    protected showLoading() {
        if (!this.loading) {
            return;
        }

        this.circleCancelAction = we.core.CancelAction.create();
        this.circleCancelAction.add(() => {
            we.commonUI.hideCircleLoading();
        });
        we.commonUI.showCircleLoading({
            cancel: this.circleCancelAction,
            delay: (this.delayLoading ? 1_000 : 0) / 1000,
            timeout: this.timeoutValue / 1_000,
            text: we.core.langMgr.getLangText(we.launcher.lang.COMMON_LOADING),
            debug: 'CommonHttpBase showLoading',
        });
    }

    /**
     * 隐藏loading
     */
    protected hideLoading() {
        if (!this.loading) {
            return;
        }

        this.circleCancelAction?.cancel();
    }
}
