import { CommonLanguage } from '../const/CommonLanguage';
import UserManager from '../manager/UserManager';
import AppleLogin from '../platform/AppleLogin';
import Facebook from '../platform/Facebook';
import GoogleLogin from '../platform/GoogleLogin';

declare global {
    interface ICommon {
        httpProtoError: typeof HttpProtoError;
    }
}

export default class HttpProtoError {
    /** 错误码 */
    public static readonly ERROR_CODE = cc.Enum({
        /** 非法參數 */
        ERROR_USUAL_TYPE_1: 1,
        /** 訪問受限 */
        ERROR_USUAL_TYPE_2: 2,
        /** 大厅停服 */
        ERROR_USUAL_TYPE_3: 3,
        /** 通道在配置中不存在 */
        ERROR_USUAL_TYPE_4: 4,
        /** 模拟器禁止登陆 */
        ERROR_USUAL_TYPE_5: 5,
        /** 创建账号失败 */
        ERROR_USUAL_TYPE_8: 8,
        /** 請重新登錄 */
        ERROR_USUAL_TYPE_10: 10,
        /** 邮件格式错误 */
        ERROR_USUAL_TYPE_12: 12,
        /** 正在游戏中 */
        ERROR_USUAL_TYPE_13: 13,
        /** 系统维护中 */
        ERROR_USUAL_TYPE_99: 99,

        /** 仅允许登录您的设备绑定过的账号 */
        ERROR_USUAL_TYPE_1002: 1002,
        /** 您的賬號已被封禁 */
        ERROR_USUAL_TYPE_1003: 1003,
        /** 用戶不存在 */
        ERROR_USUAL_TYPE_1004: 1004,
        /** 僅能使用系統頭像 */
        ERROR_USUAL_TYPE_1005: 1005,
        /** Facebook資訊保存失敗 */
        ERROR_USUAL_TYPE_1006: 1006,
        /** fb账号已绑定 */
        ERROR_USUAL_TYPE_1007: 1007,
        /** 您的ip或地区被禁止使用该应用程序 */
        ERROR_USUAL_TYPE_1008: 1008,
        /** 數據包已經收到 */
        ERROR_USUAL_TYPE_1013: 1013,
        /** 获取facebook信息失败 */
        ERROR_USUAL_TYPE_1014: 1014,
        /** 苹果账号已绑定 */
        ERROR_USUAL_TYPE_1015: 1015,
        /** 手机已被使用 */
        ERROR_USUAL_TYPE_1016: 1016,
        /** 邮箱已被使用 */
        ERROR_USUAL_TYPE_1017: 1017,
        /** 谷歌账号已绑定 */
        ERROR_USUAL_TYPE_1018: 1018,
        /** 谷歌验证失败 */
        ERROR_USUAL_TYPE_1019: 1019,
        /** 游客账号不能绑定邮箱 */
        ERROR_USUAL_TYPE_1020: 1020,
        /** 获取不到用户id */
        ERROR_USUAL_TYPE_1021: 1021,
        /** 該銀行賬戶已經在另一個遊戲賬號中綁定 */
        ERROR_USUAL_TYPE_1022: 1022,
        /** 提现账号未绑定 */
        ERROR_USUAL_TYPE_1023: 1023,
        /** 代理功能异常，请稍后再试 */
        ERROR_USUAL_TYPE_1024: 1024,
        /** 游客登录提示 该设备已升级到正式服用户，请使用账号登录 */
        ERROR_USUAL_TYPE_1025: 1025,
        /** 该设备不可登录 */
        ERROR_USUAL_TYPE_1026: 1026,
        /** 正式用户才能参与 */
        ERROR_USUAL_TYPE_1027: 1027,
        /** 功能暂时不可使用，请联系客服 */
        ERROR_USUAL_TYPE_1028: 1028,
        /** 提现绑卡token失效 */
        ERROR_USUAL_TYPE_1029: 1029,
        /** 提现绑卡token必填 */
        ERROR_USUAL_TYPE_1030: 1030,
        /** 登录过于频繁 */
        ERROR_USUAL_TYPE_1031: 1031,
        /** 此收款账号绑定用户数已达上限 */
        ERROR_USUAL_TYPE_1032: 1032,
        /** 提现成功的账号不可修改 */
        ERROR_USUAL_TYPE_1033: 1033,

        /** 密码尝试次数过多 */
        ERROR_USUAL_TYPE_2000: 2000,
        /** 密碼錯誤 */
        ERROR_USUAL_TYPE_2001: 2001,
        /** 驗證碼錯誤 */
        ERROR_USUAL_TYPE_2002: 2002,
        /** 驗證碼發送次數限制 */
        ERROR_USUAL_TYPE_2003: 2003,
        /** 賬戶已存在，請登錄。 */
        ERROR_USUAL_TYPE_2004: 2004,
        /** Kyc信息未完成 */
        ERROR_USUAL_TYPE_2005: 2005,
        /** 無效的電話號碼 */
        ERROR_USUAL_TYPE_2006: 2006,
        /** 玩家沒有足夠的金幣 */
        ERROR_USUAL_TYPE_2007: 2007,
        /** 非法金幣數量 */
        ERROR_USUAL_TYPE_2008: 2008,
        /** 玩家沒有足夠的鑽石 */
        ERROR_USUAL_TYPE_2009: 2009,
        /** 用戶沒有足夠的獎勵輪數 */
        ERROR_USUAL_TYPE_2010: 2010,
        /** 用戶的禮物分享次數不足 */
        ERROR_USUAL_TYPE_2011: 2011,
        /** 邮箱账户已存在 */
        ERROR_USUAL_TYPE_2012: 2012,
        /** 手机号码不支持 */
        ERROR_USUAL_TYPE_2013: 2013,
        /** 邮件已经被撤回 */
        ERROR_USUAL_TYPE_2014: 2014,
        /** 手机号或密码错误 */
        ERROR_USUAL_TYPE_2015: 2015,
        /** 手机号或验证码有误 */
        ERROR_USUAL_TYPE_2016: 2016,
        /** 账户名或密码错误 */
        ERROR_USUAL_TYPE_2017: 2017,
        /** 邮箱或验证码错误 */
        ERROR_USUAL_TYPE_2018: 2018,

        /** 不支持的付款方式 */
        ERROR_USUAL_TYPE_3001: 3001,
        /** 創建充值錯誤 */
        ERROR_USUAL_TYPE_3002: 3002,
        /** 提款失敗 */
        ERROR_USUAL_TYPE_3003: 3003,
        /** 資金不足 */
        ERROR_USUAL_TYPE_3004: 3004,
        /** 您已經收到該物品 */
        ERROR_USUAL_TYPE_3005: 3005,
        /** 沒有可用的支付管道 */
        ERROR_USUAL_TYPE_3006: 3006,
        /** 购买新手礼包发生错误 */
        ERROR_USUAL_TYPE_3007: 3007,
        /** 购买限时礼包发生错误 */
        ERROR_USUAL_TYPE_3008: 3008,
        /** 购买等级礼包发生错误 */
        ERROR_USUAL_TYPE_3009: 3009,
        /** 购买黄金礼包发生错误 */
        ERROR_USUAL_TYPE_3010: 3010,
        /** 购买限时活动黄金锁发生错误 */
        ERROR_USUAL_TYPE_3011: 3011,
        /** 购买解锁财富转盘翻倍发生错误 */
        ERROR_USUAL_TYPE_3012: 3012,
        /** 开运礼包不存在或已过期 */
        ERROR_USUAL_TYPE_3013: 3013,
        /** 超级淘金已解锁 */
        ERROR_USUAL_TYPE_3014: 3014,
        /** 破产礼包条件不满足 */
        ERROR_USUAL_TYPE_3015: 3015,
        /** 挑战双倍积分已生效 */
        ERROR_USUAL_TYPE_3016: 3016,
        /** 充值订单创建频繁 */
        ERROR_USUAL_TYPE_3018: 3018,
        /** 充值订单创建超出每日上限 */
        ERROR_USUAL_TYPE_3019: 3019,
        /** 订单金额不在支付渠道范围内 */
        ERROR_USUAL_TYPE_3020: 3020,
        /** 验证码发送太频繁 */
        ERROR_USUAL_TYPE_3021: 3021,
        /** 订单超过限制 */
        ERROR_USUAL_TYPE_3022: 3022,
        /** 被标记用户不能领取个人返利 */
        ERROR_USUAL_TYPE_3023: 3023,
        /** 被标记用户不能领取代理返利 */
        ERROR_USUAL_TYPE_3024: 3024,
        /** 商品已售罄 */
        ERROR_USUAL_TYPE_3025: 3025,
        /** 购买周卡条件不满足 */
        ERROR_USUAL_TYPE_3026: 3026,
        /** 周卡服务繁忙 */
        ERROR_USUAL_TYPE_3027: 3027,

        /** 遊戲編號錯誤 */
        ERROR_USUAL_TYPE_4002: 4002,
        /** 找不到開關配置 */
        ERROR_USUAL_TYPE_4003: 4003,
        /** 付款狀態失敗 */
        ERROR_USUAL_TYPE_4004: 4004,
        /** 支付通道需要实名制 */
        ERROR_USUAL_TYPE_4005: 4005,

        // tasks
        /** 任務不存在 */
        ERROR_USUAL_TYPE_5001: 5001,
        /** 任務關聯不存在 */
        ERROR_USUAL_TYPE_5002: 5002,

        // friends
        /** 好友數量已達上限 */
        ERROR_USUAL_TYPE_6001: 6001,
        /** 另一個玩家不是您的朋友 */
        ERROR_USUAL_TYPE_6002: 6002,
        /** 禮物ID不存在 */
        ERROR_USUAL_TYPE_6003: 6003,
        /** 请等待你朋友的允许 */
        ERROR_USUAL_TYPE_6004: 6004,
        /** 发送私信过于频繁*/
        ERROR_USUAL_TYPE_6005: 6005,
        /** 查询的用户不存 */
        ERROR_USUAL_TYPE_6006: 6006,
        /** 对面好友已满 */
        ERROR_USUAL_TYPE_6007: 6007,
        /** 已经是好友 */
        ERROR_USUAL_TYPE_6008: 6008,

        /** 礼包码失效 */
        ERROR_USUAL_TYPE_7001: 7001,
        /** 该活动并不存在 */
        ERROR_USUAL_TYPE_7002: 7002,

        /** 道具数量不足 */
        ERROR_USUAL_TYPE_8001: 8001,
        /** 提现还有活动次数，但是银行卡已经不能参与提现了 */
        ERROR_USUAL_TYPE_9003: 9003,
        /** 提现 不满足充值条件无法提现 */
        ERROR_USUAL_TYPE_9009: 9009,

        /** 服务器异常 */
        ERROR_USUAL_TYPE_10000: 10000,
        /** 请重新登录 */
        ERROR_USUAL_TYPE_10001: 10001,
        /** 请求参数错误 */
        ERROR_USUAL_TYPE_10002: 10002,
        /** 使用道具错误 */
        ERROR_USUAL_TYPE_10003: 10003,
        /** 使用道具数量不足 */
        ERROR_USUAL_TYPE_10004: 10004,
        /** 用户不存在 */
        ERROR_USUAL_TYPE_10005: 10005,
        /** 用户被禁言 */
        ERROR_USUAL_TYPE_10006: 10006,
        /** 单次赠送金额超出限制 */
        ERROR_USUAL_TYPE_10082: 10082,
        /** 赠送金额已达上限 */
        ERROR_USUAL_TYPE_10086: 10086,
        /** 相同账号禁止多次赠送 */
        ERROR_USUAL_TYPE_10089: 10089,
        /** 仅能赠送给今天注册的新用户 */
        ERROR_USUAL_TYPE_10090: 10090,
        /** 他人在你的黑名单里 */
        ERROR_USUAL_TYPE_10101: 10101,
        /** 你在他人的黑名单里 */
        ERROR_USUAL_TYPE_10102: 10102,
        /** 他人不在你的黑名单里 */
        ERROR_USUAL_TYPE_10103: 10103,
        /** 每日临时聊天数量超过最大值 */
        ERROR_USUAL_TYPE_10104: 10104,
        /** 单向聊天消息数量超过最大值 */
        ERROR_USUAL_TYPE_10105: 10105,
        /** 每日房间消息数量超过最大值 */
        ERROR_USUAL_TYPE_10201: 10201,
        /** 群组不存在 */
        ERROR_USUAL_TYPE_10202: 10202,
        /** 月签到，奖励领取失败 */
        ERROR_USUAL_TYPE_11000: 11000,
        /** 累计签到次数不足，无法领取奖励 */
        ERROR_USUAL_TYPE_11001: 11001,
        /** 月签到活动关闭，服务器配置错误 */
        ERROR_USUAL_TYPE_11002: 11002,
        /** 奖励已领取 */
        ERROR_USUAL_TYPE_11003: 11003,
        /** 月签到，领取累计签到奖励需当月充值达到XXX */
        ERROR_USUAL_TYPE_11007: 11007,

        /** 您的游戏还未结束，请稍后再试 */
        ERROR_USUAL_TYPE_20081: 20081,
        /** 单次提现不得低于 */
        ERROR_USUAL_TYPE_20082: 20082,
        /** 请绑定邮箱后再试 */
        ERROR_USUAL_TYPE_20083: 20083,
        /** 请先绑定您的提现账号 */
        ERROR_USUAL_TYPE_20084: 20084,
        /** 提現要求的VIP等級不足 */
        ERROR_USUAL_TYPE_20085: 20085,
        /** 提現要求的账号等級不足 */
        ERROR_USUAL_TYPE_20086: 20086,
        /** 提现服务正忙，请稍后再试 */
        ERROR_USUAL_TYPE_20087: 20087,
        /** 今日提现额度或次数不足 */
        ERROR_USUAL_TYPE_20088: 20088,
        /** 今日提现次数超过上限！ */
        ERROR_USUAL_TYPE_20089: 20089,
        /** 提现需要邀请人的总收益达到 才可以使用此功能 */
        ERROR_USUAL_TYPE_20090: 20090,
        /** 您还有未完成的提现订单！ */
        ERROR_USUAL_TYPE_20091: 20091,
        /** 您输入的提现信息已在其他游戏账号绑定 */
        ERROR_USUAL_TYPE_20092: 20092,
        /** 提现 打码量不足提现失败 */
        ERROR_USUAL_TYPE_20093: 20093,
        /** 提现 提现卡号达到最大次数上限 */
        ERROR_USUAL_TYPE_20094: 20094,
        /** 提现 提现卡号达到最大额度上限 */
        ERROR_USUAL_TYPE_20095: 20095,
        /** 提现 提现通道使用额度已达上限 */
        ERROR_USUAL_TYPE_20096: 20096,

        /** 邮件 删除失败，存在未领取附件 */
        ERROR_USUAL_TYPE_40001: 40001,
        /** 邮件 已失效 撤回和已过期状态 */
        ERROR_USUAL_TYPE_40004: 40004,
        /** 邮件 无可领取附件 */
        ERROR_USUAL_TYPE_40005: 40005,
        /** 邮件 附件领取失败 */
        ERROR_USUAL_TYPE_40009: 40009,
    });

    /** code 提示过滤列表 */
    private static readonly codeTipFilters: any[] = [
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1026,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_1027,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_2002,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_2014,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3022,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3023,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_3024,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_4005,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_9003,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_9009,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_11007,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20082,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20085,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20086,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20090,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20094,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20095,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_20096,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40001,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40004,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40005,
        HttpProtoError.ERROR_CODE.ERROR_USUAL_TYPE_40009,
    ];

    /** code 日志上报过滤列表 */
    private static readonly codeUpFilters: any[] = [];

    /** api 提示过滤列表 */
    private static readonly apiTipFilters: string[] = [];

    /**
     * 处理错误码
     * @param code
     * @param api
     */
    public static processError(code: string | number, api: string) {
        switch (code) {
            case this.ERROR_CODE.ERROR_USUAL_TYPE_3:
                this.goLogin(code, false);
                return;
            case this.ERROR_CODE.ERROR_USUAL_TYPE_8:
            case this.ERROR_CODE.ERROR_USUAL_TYPE_10:
            case this.ERROR_CODE.ERROR_USUAL_TYPE_1002:
            case this.ERROR_CODE.ERROR_USUAL_TYPE_1003:
            case this.ERROR_CODE.ERROR_USUAL_TYPE_1004:
                this.goLogin(code, true);
                return;
            default:
                break;
        }

        if (code == this.ERROR_CODE.ERROR_USUAL_TYPE_1007) {
            Facebook.logout();
        } else if (code == this.ERROR_CODE.ERROR_USUAL_TYPE_1015) {
            AppleLogin.logout();
        } else if (code == this.ERROR_CODE.ERROR_USUAL_TYPE_1018) {
            GoogleLogin.logout();
        }

        if (!this.codeTipFilters.includes(code) && !this.apiTipFilters.includes(api)) {
            let tips = '';
            let errorName = this.ERROR_CODE[code];
            if (errorName && CommonLanguage[errorName]) {
                tips = we.core.langMgr.getLangText(CommonLanguage[errorName]);
            } else {
                tips = we.core.langMgr.getLangText(we.launcher.lang.COMMON_NET_TIMEOUT);
            }
            we.commonUI.showToast(tips + ': ' + code);
        }
    }

    /**
     * 去登陆
     * @param tips
     */
    private static goLogin(code: number, clearCache: boolean) {
        UserManager.clearLoginData(clearCache, `HttpProtoError code: ${code}`);

        // 登录界面不弹框
        const curGameId = we.core.gameConfig.curGameId;

        we.commonUI.showConfirm({
            content: we.core.langMgr.getLangText(CommonLanguage[this.ERROR_CODE[code]]) + ': ' + code,
            isHideCloseBtn: true,
            yesHandler: we.core.Func.create(() => {
                if (curGameId != we.GameId.LAUNCHER) {
                    cc.director.emit(we.core.EventName.LOGIN_VIEW_SHOW);
                    UserManager.exitLogin();
                }
            }),
        });
    }

    /**
     * 是否需要上报错误code
     * @param code
     * @returns {boolean} true: 需要上报, false: 不需要上报
     */
    public static isNeedReportError(code: string | number): boolean {
        const numericCode = typeof code === 'string' ? parseInt(code, 10) : code;
        return !this.codeUpFilters.includes(numericCode);
    }
}

we.common.httpProtoError = HttpProtoError;
