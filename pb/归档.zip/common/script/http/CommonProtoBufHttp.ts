const protobuf = require('protobuf');

export default class CommonProtoBufHttp {
    /** pb root */
    private protoRoot: any = null;

    public constructor(protoFile: string) {
        if (!protoFile) {
            we.error(`CommonProtoBufHttp constructor, params err`);
            return;
        }

        protobuf.load(protoFile, (err, root) => {
            if (err || !root) {
                we.error(`CommonProtoBufHttp constructor, load err: ${err}`);
                return;
            }
            this.protoRoot = root;
        });
    }

    /**
     * 序列化
     * @param msgName
     * @param msgData
     */
    public encode(msgName: string, msgData: Object): Uint8Array {
        if (!this.protoRoot) {
            return null;
        }

        let msgType = this.protoRoot.lookup(msgName);
        if (!msgType) {
            we.error(`CommonProtoBufHttp encode, msgType err, msgName: ${msgName}, msgData: ${JSON.stringify(msgData)}`);
            return null;
        }

        let errMsg = msgType.verify(msgData);
        if (errMsg) {
            we.warn(`CommonProtoBufHttp encode, verify err, errMsg: ${errMsg}, msgName: ${msgName}, msgData: ${JSON.stringify(msgData)}`);
        }

        let message = msgType.fromObject(msgData);
        let dataBuffer = msgType.encode(message).finish();

        return dataBuffer;
    }

    /**
     * 反序列化
     * @param msgName
     * @param dataBuffer
     */
    public decode(msgName: string, dataBuffer: ArrayBuffer): Object {
        if (!this.protoRoot) {
            return null;
        }

        let msgType = this.protoRoot.lookup(msgName);
        if (!msgType) {
            we.error(`CommonProtoBufHttp decode, msgType err, msgName: ${msgName}`);
            return null;
        }

        let message = msgType.decode(dataBuffer);
        let msgData = msgType.toObject(message, {
            defaults: true,
            // enums: String,  // enums as string names
            // longs: String,  // longs as strings (requires long.js)
            // bytes: String,  // bytes as base64 encoded strings
            // defaults: true, // includes default values
            // arrays: true,   // populates empty arrays (repeated fields) even if defaults=false
            // objects: true,  // populates empty objects (map fields) even if defaults=false
            // oneofs: true    // includes virtual oneof fields set to the present field's name
        });

        return msgData;
    }
}
