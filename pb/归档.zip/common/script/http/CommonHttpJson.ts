import UserManager from '../manager/UserManager';
import CommonHttpBase from './CommonHttpBase';

export default class CommonHttpJson extends CommonHttpBase {
    public constructor() {
        super();
    }

    /**
     * http请求接口
     * @param host 域名/ip + 端口
     * @param hostList host列表
     * @param api api路径
     * @param type 请求类型
     * @param data 请求数据
     * @param successCallback 成功回调
     * @param errorCallback 失败回调
     * @param loading 是否显示loading
     */
    public request(host: string, hostList: string[], api: string, type: string, data: Object, successCallback: Function, errorCallback: Function, loading: boolean = false, delayLoading: boolean = true) {
        if (!host || !api || !type) {
            we.error('CommonHttpJson request params is invalid');
            return;
        }

        this.host = host;
        this.hostList = hostList;
        this.api = api;
        this.requestType = type;
        this.successCallback = successCallback;
        this.errorCallback = errorCallback;
        this.loading = loading;
        this.delayLoading = delayLoading;

        this.showLoading();
        this.buildSendData(data);
        this.buildRequestUrl(host, api);
        this.startRequest();
    }

    /**
     * 构建发送数据
     */
    private buildSendData(data: Object) {
        if (!data) {
            return;
        }

        this.requestData = '';
        for (const key in data) {
            if (this.requestData != '') {
                this.requestData += '&';
            }
            this.requestData += key + '=' + data[key];
        }
    }

    /**
     * 设置请求头
     */
    protected setRequestHeader() {
        this.httpRequest.setRequestHeader('content-type', 'application/json');
        // this.httpRequest.setRequestHeader('content-type', 'application/x-www-form-urlencoded');
        // this.httpRequest.setRequestHeader('X-Auth-Track', this.deviceInfo);

        let uid = UserManager.userInfo.userId;
        let token = UserManager.token;
        if (uid && token) {
            this.httpRequest.setRequestHeader('X-AUTH-USER', uid.toString());
            this.httpRequest.setRequestHeader('X-AUTH-TOKEN', token.toString());
        }
    }

    /**
     * 设置响应类型
     */
    protected setResponseType() {
        this.httpRequest.responseType = 'text';
    }

    /**
     * 发送请求
     */
    protected sendRequest() {
        we.log(`CommonHttpJson sendRequest, requestUrl: ${this.requestUrl}\n` + `requestData: ${this.requestData}`);

        if (this.requestData && this.requestType == 'POST') {
            this.httpRequest.send(this.requestData);
        } else {
            this.httpRequest.send();
        }
    }

    /**
     * 解析响应
     * @param response
     */
    protected parseResponse(response: string) {
        try {
            let responseJson = JSON.parse(response);
            let code = responseJson.status != null ? responseJson.status : responseJson.code;
            let responseData = responseJson.data;

            we.log(`CommonHttpJson parseResponse, requestUrl: ${this.requestUrl}\n` + `responseData: ${JSON.stringify(responseData)}`);

            if (code == 0) {
                if (typeof this.successCallback == 'function') {
                    setTimeout(() => {
                        this.successCallback(responseData);
                    });
                }
                this.hideLoading();
            } else {
                this.processError(code);
            }
        } catch (error) {
            this.processError(this.ERROR_CODE_C.RESPONSE_INVALID);
        }
    }
}
