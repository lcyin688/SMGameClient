import { CommonRes } from '../config/CommonRes';
import { CommonType } from '../config/CommonType';
import UserManager from '../manager/UserManager';

declare global {
    interface ICommon {
        /** 工具类 Utils */
        utils: typeof CommonUtils;
    }
}

interface FormatAmountOptions {
    /** 是否使用 KMBT 单位，默认是 */
    useUnit?: boolean;
    /** 使用 KMBT 单位，最低值，默认 10_000 */
    useUnitCond?: number;
    /** 保留小数位数, 默认使用全局配置 */
    decimalPlace?: number;
    /** 是否使用逗号，默认是 */
    useComma?: boolean;
}

export default class CommonUtils {
    /**
     * 根据节点名称获取目标节点下的节点，如果遇见多个相同节点，返回第一个
     * @param target 查找根节点
     * @param childName 节点名称，使用/分割
     */
    public static findChildByName(target: cc.Node, childName: string): cc.Node {
        if (!(target instanceof cc.Node && target.isValid)) {
            we.warn(`CommonUtils findChildByName target err: ${childName}`);
            return null;
        }

        if (!(typeof childName == 'string' && childName.length > 0)) {
            we.warn(`CommonUtils findChildByName, childName err: ${childName}`);
            return null;
        }

        let names = childName.split('/');
        let name = names[0];
        let result = target.getChildByName(name);
        if (result == null) {
            we.warn(`CommonUtils findChildByName, result is null, target: ${target.name}, name: ${name}`);
            return null;
        } else {
            names = names.slice(1);
            if (names.length > 0) {
                result = this.findChildByName(result, names.join('/'));
            }
        }
        return result;
    }

    /**
     * 格式化金额
     * @param amount 金额，服务器值
     * @param useUnit 是否使用单位，默认是
     * @param decimalPlace 保留小数位数
     * @param useComma 是否使用逗号，默认是
     * @returns
     */
    public static formatAmount(amount: number, options: FormatAmountOptions): string;
    public static formatAmount(amount: number, useUnit?: boolean, decimalPlace?: number, useComma?: boolean, useUnitCond?: number): string;
    public static formatAmount(amount: number, ...args): string {
        if (typeof amount != 'number' && isNaN(amount)) {
            we.warn('CommonUtils formatAmount, params is invalid');
            return '';
        }

        let options: FormatAmountOptions = null;
        if (we.npm.lodash.isObject(args[0])) {
            options = args[0];
        } else {
            options = {
                useUnit: args[0],
                decimalPlace: args[1],
                useComma: args[2],
                useUnitCond: args[3],
            };
        }

        options.useUnit ??= true;
        options.decimalPlace ??= we.core.flavor.getDecimalPlace();
        options.useComma ??= true;
        options.useUnitCond ??= 10_000;

        let sign = amount < 0 ? '-' : '';
        let amountAbs = Math.abs(amount);
        let precision = we.core.flavor.getAmountPrecision();
        let amountReal = amountAbs / precision;

        options.decimalPlace = typeof options.decimalPlace == 'number' && !isNaN(options.decimalPlace) ? Math.abs(options.decimalPlace) : 0;

        // 方法 Math.floor(1.005 * 1000) / 1000 / 1000 存在结果是 1.004 的问题，使用重写后的 toFixed 方法
        // NumberHelper 重写了 toFixed 方法，不再四舍五入，直接保留小数位数
        amountReal = parseFloat(amountReal.toFixed(options.decimalPlace));

        let unit = '';
        if (options.useUnit && amountReal >= options.useUnitCond) {
            let unitDivisor = 1;
            if (amountReal >= 1_000_000_000_000) {
                // 万亿
                unit = 'T';
                unitDivisor = 1_000_000_000_000;
            } else if (amountReal >= 1_000_000_000) {
                // 十亿
                unit = 'B';
                unitDivisor = 1_000_000_000;
            } else if (amountReal >= 1_000_000) {
                // 百万
                unit = 'M';
                unitDivisor = 1_000_000;
            } else if (amountReal >= options.useUnitCond) {
                // 千 大于1万才使用K单位
                unit = 'K';
                unitDivisor = 1_000;
            }

            // 缩写单位保留小数位数和国家无关，固定 3 位
            let decimalUnit = 3;
            amountReal = amountReal / unitDivisor;
            amountReal = parseFloat(amountReal.toFixed(decimalUnit));
        }

        let strNum = amountReal.toString();
        let str = sign + (options.useComma ? this.formatComma(strNum) : strNum) + unit;
        return str;
    }

    /**
     * 逗号分隔，一般都是每三位一个逗号，但是也有比较特殊的，比如印度货币第一个逗号出现在第三位数字后，此后的毎二位数字一个逗号
     * @param strNum 数字字符串
     * @param firstComma 第一个逗号的位置
     * @param otherComma 其他逗号的位置
     */
    public static formatComma(strNum: string, firstComma: number = 3, otherComma: number = 3): string {
        if (typeof strNum != 'string') {
            we.warn('CommonUtils formatComma, params is invalid');
            return '';
        }

        // 整数部分倒序
        let revArr = strNum.split('.')[0].split('').reverse();
        let tempArr = [];

        for (let i = 0; i < revArr.length; i++) {
            tempArr.push(revArr[i]);
            if (i != revArr.length - 1) {
                if (i < firstComma) {
                    if ((i + 1) % firstComma == 0) {
                        tempArr.push(',');
                    }
                } else {
                    if ((i + 1 - firstComma) % otherComma == 0) {
                        tempArr.push(',');
                    }
                }
            }
        }

        // 整数部分
        let integer = tempArr.reverse().join('');

        // 小数部分
        let decimal = strNum.split('.')[1];
        if (decimal && decimal != '') {
            decimal = '.' + decimal;
        } else {
            decimal = '';
        }

        let str = integer + decimal;
        return str;
    }

    /**
     * 格式化金额 - 支持货币符号
     * @param amount 金额，服务器值
     * @param useUnit 是否使用单位，默认否
     * @param decimalPlace 保留小数位数
     * @param useSymbol 是否使用货币符号，默认是
     * @param useComma 是否使用逗号，默认是
     * @returns
     */
    public static formatAmountCurrency(amount: number, useUnit: boolean = false, decimalPlace: number = we.core.flavor.getDecimalPlace(), useSymbol: boolean = true, useComma: boolean = true): string {
        if (typeof amount != 'number' && isNaN(amount)) {
            we.warn('CommonUtils formatAmountCurrency, params is invalid');
            return '';
        }

        let sign = amount < 0 ? '-' : '';
        let symbol = useSymbol ? we.core.flavor.getCurrencySymbol() : '';
        let str = sign + symbol + `${amount == 0 ? '0' : CommonUtils.formatAmount(Math.abs(amount), useUnit, Math.abs(decimalPlace), useComma)}`;
        return str;
    }

    /**
     * 格式化价格
     * @param price 价格，服务器值
     * @param useSymbol 是否使用货币符号，默认是
     * @param useUnit 是否使用单位，默认是
     * @param useComma 是否使用逗号，默认是
     * @returns
     */
    public static formatPrice(price: number, useSymbol: boolean = true, useUnit: boolean = true, useComma: boolean = true): string {
        if (!(typeof price == 'number' && !isNaN(price))) {
            we.warn('CommonUtils formatPrice, params is invalid');
            return '';
        }

        // price 转为 amount, 再使用 amount 格式化, 结果和 price 格式化一样
        let amount = CommonUtils.priceToAmount(price);
        let symbol = useSymbol ? we.core.flavor.getCurrencySymbol() : '';
        let decimalPlace = we.core.flavor.getDecimalPlace();
        let str = symbol + CommonUtils.formatAmount(amount, useUnit, decimalPlace, useComma);
        return str;
    }

    /**
     * 金额转价格
     * @param amount 金额，服务器值
     * @returns
     */
    public static amountToPrice(amount: number): number {
        if (!(typeof amount == 'number' && !isNaN(amount))) {
            we.warn('CommonUtils amountToPrice, params is invalid');
            return 0;
        }

        let price = (amount / we.core.flavor.getAmountPrecision()) * we.core.flavor.getPricePrecision();
        return price;
    }

    /**
     * 价格转金额
     * @param price 价格，服务器值
     * @returns
     */
    public static priceToAmount(price: number): number {
        if (!(typeof price == 'number' && !isNaN(price))) {
            we.warn('CommonUtils priceToAmount, params is invalid');
            return 0;
        }

        let amount = (price / we.core.flavor.getPricePrecision()) * we.core.flavor.getAmountPrecision();
        return amount;
    }

    /**
     * 格式化昵称
     * @param nickname
     * @param wordLen 字长，1个汉字算2个字符
     */
    public static formatNickname(nickname: string, wordLen = 10): string {
        if (!(nickname && typeof nickname == 'string')) {
            return '';
        }

        let str = '';
        let ellipsis = '…';
        let len = 0;
        for (let i = 0; i < nickname.length; i++) {
            let char = nickname.charAt(i);
            let isEmojiEnd = false;
            if (char.match(/[^\x00-\xff]/gi) != null) {
                len += 2;
                if (len >= wordLen && (nickname.charAt(i - 1) + char).match(/[\ud800-\udbff][\udc00-\udfff]/g) != null) {
                    isEmojiEnd = true;
                }
            } else {
                len += 1;
            }

            if (len != nickname.length && len >= wordLen) {
                // 加上emoji的另一部分
                if (isEmojiEnd) {
                    str += char;
                }
                str += ellipsis;
                break;
            }
            str += char;
        }
        return str;
    }

    /**
     * 格式化时间
     * @param date
     * @param fmt 默认格式 'DD/MM/YYYY hh:mm:ss'
     * @returns
     */
    public static formatDate(date: Date, fmt: string = 'DD/MM/YYYY hh:mm:ss'): string {
        if (!(date instanceof Date)) {
            we.warn(`CommonUtils formatDate, date err`);
            return;
        }

        let opt = {
            'Y+': date.getFullYear(),
            'M+': date.getMonth() + 1,
            'D+': date.getDate(),
            'h+': date.getHours(),
            'm+': date.getMinutes(),
            's+': date.getSeconds(),
        } as {
            [key: string]: number;
        };

        for (const key in opt) {
            let ret = new RegExp('(' + key + ')').exec(fmt);
            if (ret) {
                fmt = fmt.replace(ret[1], opt[key].toString().padStart(ret[1].length, '0'));
            }
        }

        return fmt;
    }

    /**
     * 秒数转化成时间格式
     * @param seconds  number  秒数
     */
    public static formatSeconds(seconds: number): string {
        let theTime = Math.floor(seconds); // 秒
        let middle = 0; // 分
        let hour = 0; // 小时

        if (theTime >= 60) {
            middle = Math.floor(theTime / 60);
            theTime = Math.floor(theTime % 60);
            if (middle >= 60) {
                hour = Math.floor(middle / 60);
                middle = Math.floor(middle % 60);
            }
        }
        let result = '';
        if (theTime < 10) {
            result = '0' + Math.floor(theTime) + '';
        } else {
            result = '' + Math.floor(theTime) + '';
        }

        if (middle < 10) {
            result = '0' + Math.floor(middle) + ':' + result;
        } else {
            result = '' + Math.floor(middle) + ':' + result;
        }

        if (hour > 0) {
            if (hour < 10) {
                result = '0' + Math.floor(hour) + ':' + result;
            } else {
                result = '' + Math.floor(hour) + ':' + result;
            }
        } else {
            result = '00:' + result;
        }

        return result;
    }

    /**
     * 秒数转换为 天时分秒
     * @param seconds 秒数
     */
    public static formatSurplusTime(seconds: number): { day: number | string; hours: number | string; minutes: number | string; second: number | string } {
        let day: number | string = 0,
            hours: number | string = 0,
            minutes: number | string = 0,
            second: number | string = 0;

        if (seconds >= 86400) {
            day = Math.floor(seconds / 86400);
        }
        if (seconds - day * 86400 >= 3600) {
            hours = Math.floor((seconds - day * 86400) / 3600);
        }
        if (seconds - day * 86400 - hours * 3600 >= 60) {
            minutes = Math.floor((seconds - day * 86400 - hours * 3600) / 60);
        }
        second = seconds - day * 86400 - hours * 3600 - minutes * 60;

        if (day < 10) {
            day = '0' + day;
        }
        if (hours < 10) {
            hours = '0' + hours;
        }
        if (minutes < 10) {
            minutes = '0' + minutes;
        }
        if (second >= 0 && second < 10) {
            second = '0' + second;
        }
        return {
            day: day,
            hours: hours,
            minutes: minutes,
            second: second,
        };
    }

    /**
     * 获取字符串字长: 1个汉字算2个字符
     * @param str
     */
    public static getWordLength(str: string): number {
        if (!(str && typeof str == 'string')) {
            return 0;
        }

        let len = 0;
        for (let i = 0; i < str.length; i++) {
            let char = str.charAt(i);
            if (char.match(/[^\x00-\xff]/gi) != null) {
                len += 2;
            } else {
                len += 1;
            }
        }
        return len;
    }

    /**
     * 检查密码是否符合规则
     * @param password
     */
    public static checkUserPassword(password: string): boolean {
        let reg = /^[a-zA-Z0-9!"#$%&'()*+,-./:;<=>?@[\\\]^_`{|}~]{6,20}$/;
        if (!reg.test(password)) {
            return false;
        }
        return true;
    }

    /**
     * 检查验证码是否符合规则
     * @param code
     */
    public static checkUserCode(code: string): boolean {
        if (typeof code != 'string') {
            we.warn('CommonUtils checkUserCode, params is invalid');
            return false;
        }

        if (code.length < 5) {
            return false;
        }
        return true;
    }

    /**
     * 是否单字节
     * @param str
     */
    public static isSingleByte(str: string): boolean {
        let reg = /^[\u0000-\u00ff]+$/;
        if (reg.test(str)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 是否邮箱
     * @param str
     */
    public static isEmail(str: string): boolean {
        let reg = /^([A-Za-z0-9_\-\.\u4e00-\u9fa5])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,8})$/;
        if (reg.test(str)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 判断是不是有效的手机号
     * @param str
     */
    public static isPhoneNumber(str: string): boolean {
        // pattern:/^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(14[0-9]{1})|(16[0-9]{1})|(17[0-9]{1})|(19[0-9]{1})|(12[0-9]{1})|)+\d{8})$/
        if (/^[0-9]{4,15}$/.test(str)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 判断是不是有效的手机号（可选区号）
     * 在 isPhoneNumber 的规则基础上增加了可选本国区号支持
     * 区号必须以 + 或 0 开头
     * TCC - Telephone country code
     * @param {string} str
     * @param {boolean} force
     * @returns {boolean} 号码是否合法
     */
    public static isPhoneWithTCC(str: string, force?: boolean): boolean {
        return RegExp(`^((\\+|0+|\\+0+)${we.core.flavor.getCountryNum()})${force ? '{1}' : '?'}\\d{4,15}$`).test(str);
    }

    /**
     * 判断是不是有效的userId
     * @param str 6~8位
     */
    public static isUserIdNumber(str: string): boolean {
        if (!str.startsWith('0') && /^[0-9]{6,9}$/.test(str)) {
            return true;
        }

        return false;
    }

    /**
     * 判断是不是符合规则的验证码
     * 1.随机生成规则：匹配一个由字母和数字组成的字符串，长度为 4 到 12 个字符 /^[A-Za-z0-9]{4,12}$/
     * 2.手动生成规则：匹配一个由字母、数字和特定特殊符号（如 - / : ? ! . , @ # % & +）组成的字符串，长度为 6 到 10 个字符 /^[A-Za-z0-9\-\/:?!.,@#%&+]{6,10}$/
     * 满足其中一个规则即可
     * @param str
     */
    public static isGiftCode(str: string): boolean {
        if (/^[A-Za-z0-9]{4,12}$|^[A-Za-z0-9\-\/:?!.,@#%&+]{6,10}$/.test(str)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 判断是不是包含网址
     * @param str
     */
    public static isIncludeHttpUrl(str: string): boolean {
        let reg = /http(s)?:\/\/[\w-]+(\.[\w-]+){1,5}(:\d+)?(\/[\.\w-]+)*\/?(\?\w+=.*(&\w+=.*)*)?/;
        if (reg.test(str)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 适配滚动数字组件因字体原因在内容长度不变得情况下会产生抖动
     * 条件(label节点必须设置widget组件)
     * @param label
     * @returns
     */
    public static adaptLabelRoll(label: cc.Label): void {
        const widget = label.node.getComponent(cc.Widget);
        if (!cc.isValid(widget) || label.node['is_adapt']) {
            we.warn('CommonUtils adaptLabelRoll, label node is not widget component OR already adapted');
            return;
        }

        label.node['prv_width'] = label.node.width;

        const adapt = () => {
            if (!cc.isValid(widget)) {
                label.node['is_adapt'] = false;
                label.unschedule(adapt);
                return;
            }

            const avgWidth = label.node.width / label.string.length;

            if (Math.abs(label.node['prv_width'] - label.node.width) > avgWidth + 5) {
                label.node['prv_width'] = label.node.width;
                widget.scheduleOnce(widget.updateAlignment, 0);
            }
        };

        label.node['is_adapt'] = true;
        label.schedule(adapt, 0);
    }

    /**
     * 翻译语言，自动查找全大写命名的控件并翻译
     * @param root
     * @param GameLanguage
     */
    public static transLang(root: cc.Node, GameLanguage: object): void {
        let labels = root.getComponentsInChildren(cc.Label);
        let labName: string = '';
        labels.forEach((lab) => {
            // labName = lab.name.replace('<Label>', '');
            labName = lab.node.name;
            // 忽略label名字包含小写的
            if (labName.search(new RegExp('[a-z]')) != -1) {
                return;
            }

            let keyName = GameLanguage[labName];
            if (keyName) {
                lab.string = we.core.langMgr.getLangText(keyName);
            }
        });
    }

    /**
     * 生成从minNum到maxNum的随机数
     * @param minNum
     * @param maxNum
     */
    public static randomNum(minNum: number, maxNum: number): number {
        switch (arguments.length) {
            case 1:
                return Math.random() * minNum + 1;
            case 2:
                return Math.random() * (maxNum - minNum + 1) + minNum;
            default:
                return 0;
        }
    }

    /**
     * 计算滚动过程中小数位滚动规则
     * @param endAmount 结束金额
     * @param startAmount 开始金额
     * @param time 滚动时间
     * @returns
     */
    public static getRollFormatDecimal(endAmount: number, startAmount: number, time: number): number {
        if (we.core.flavor.getAmountPrecision() == 1) {
            return 0;
        }

        let decimalLen = 0;

        // 起始值有小数位则保留起始位的数据
        if (startAmount > 0) {
            const startFormat = CommonUtils.formatAmount(startAmount, false);
            // 小数长度
            decimalLen = (startFormat.split('.')[1] ?? '').length;
            if (decimalLen > 0) {
                return decimalLen;
            }
        }

        // 开始时整数，结束是整数，并且数字足够大是滚动整数
        if (decimalLen == 0 && endAmount % we.core.flavor.getAmountPrecision() == 0 && endAmount / time / we.core.flavor.getAmountPrecision() > 0.5) {
            return 0;
        }

        /** *********** 如果起始位是整数，则通过结束位结算滚动数值 ************* */

        // 获取元级别的数值
        endAmount = endAmount / we.core.flavor.getAmountPrecision();

        let decimal = 0;

        // 判断当前国家小数保留位数
        const precLen = we.core.flavor.getAmountPrecision().toString().split('');
        precLen.splice(0, 1);
        const len = precLen.length;

        if (endAmount < 10_0000 && len >= 1) {
            decimal = 1;
        } // < 10_0000 保留一位
        if (endAmount < 1000 && len >= 2) {
            decimal = 2;
        } // < 1000 保留2位
        if (endAmount < 10 && len >= 3 && time > 1) {
            decimal = 3; // < 10 保留3位
        } else if (endAmount < 10 && len >= 3) {
            decimal = 2;
        }

        return decimal;
    }

    /**
     * 补齐小数位
     * @param amount
     * @param decimal
     */
    public static completingDecimal(amount: string, decimal: number) {
        if (we.core.flavor.getAmountPrecision() == 1) {
            return amount;
        }

        if (decimal <= 0) {
            return amount;
        }
        const splitArr = amount.split('.');
        const decimalSplitArr = (splitArr[1] ?? '').split('');
        const len = decimal - decimalSplitArr.length;

        // 数字本身超过了长度则不格式化
        if (len < 0) {
            return amount;
        }

        const addArr = new Array(len).fill('0', 0, len);
        if (decimalSplitArr.length == 0) {
            addArr.unshift('.');
        }
        amount = amount + addArr.join('');
        return amount;
    }

    /**
     * 文本数字滚动
     * @param label 文字标签组件
     * @param start 开始数字
     * @param end 结束数字
     * @param duration 持续时间(秒)
     * @param completeCallback 完成回调
     */
    public static labelNumRoll(label: cc.Label, start: number, end: number, duration: number, completeCallback: Function = null, useCode: boolean = false): void {
        if (!cc.isValid(label)) {
            we.warn(`CommonUtils labelNumRoll, label is invalid`);
            return;
        }

        if (typeof start !== 'number' || typeof end !== 'number' || typeof duration !== 'number') {
            we.warn(`CommonUtils labelNumRoll, params err, start: ${start}, end: ${end}, duration: ${duration}, node: ${we.core.utils.getNodePath(label.node)}`);
            return;
        }

        const value = label.node['actions_labelNumRoll_value'];
        if (typeof value == 'number') {
            start = value;
        }

        const decimal = this.getRollFormatDecimal(end, start, duration);
        const setLabelValue = (value: number, isEnd = false) => {
            label.node['actions_labelNumRoll_value'] = value;
            let strNum = this.formatAmountCurrency(value, false, isEnd ? we.core.flavor.getDecimalPlace() : decimal, useCode);
            if (!isEnd && decimal > 0) {
                strNum = this.completingDecimal(strNum, decimal);
            }
            if (cc.isValid(label)) {
                label.string = strNum;
            }
        };

        cc.Tween.stopAllByTarget(label);

        // 创建滚动动画
        if (duration > 0) {
            const loopNum = Math.min(Math.abs(end - start), Math.floor(duration * 20));
            const increment = (end - start) / loopNum;
            for (let i = 1; i <= loopNum; i++) {
                const delay = (i / loopNum) * duration;
                const final = i === loopNum;
                cc.tween(label)
                    .delay(delay)
                    .call(() => {
                        if (!final) {
                            setLabelValue(start + increment * i);
                        } else {
                            setLabelValue(end, true);
                            if (typeof completeCallback === 'function') {
                                completeCallback();
                            }
                        }
                    })
                    .start();
            }
        } else {
            setLabelValue(end, true);
            if (typeof completeCallback === 'function') {
                completeCallback();
            }
        }
    }
    /**
     * 文本点点跳动, …/... 只能在文本末端
     * @param label
     * @param text
     */
    public static labelPointBounce(label: cc.Label | cc.RichText, text: string): void {
        if (!cc.isValid(label)) {
            we.warn(`CommonUtils labelPointBounce, label is invalid`);
            return;
        }

        if (!(typeof text == 'string')) {
            we.warn(`CommonUtils labelPointBounce, text err: ${text}, node: ${we.core.utils.getNodePath(label.node)}`);
            return;
        }

        if (label.node['anchorX_original'] == undefined) {
            label.node['anchorX_original'] = label.node.anchorX;
        }

        if (label.node['posX_original'] == undefined) {
            label.node['posX_original'] = label.node.x;
        }

        let reset = () => {
            label.unscheduleAllCallbacks();
            label.node.anchorX = label.node['anchorX_original'];
            label.node.x = label.node['posX_original'];
        };

        if (text.endsWith('…') || text.endsWith('...')) {
            if (text.endsWith('…')) {
                text = text.substring(0, text.lastIndexOf('…'));
            } else if (text.endsWith('...')) {
                text = text.substring(0, text.lastIndexOf('...'));
            }
        } else {
            reset();
            label.string = text;
            return;
        }

        reset();

        let point = '.';
        label.string = text + point;
        label.scheduleOnce(() => {
            label.node.anchorX = 0;
            label.node.x = label.node['posX_original'] - label.node.width / 2;
            label.schedule(() => {
                if (point.length >= 3) {
                    point = '';
                } else {
                    point += '.';
                }
                label.string = text + point;
            }, 0.5);
        });
    }

    /**
     * 休眠点击，防止按钮多次点击
     * @param node
     * @param time 休眠时间，单位毫秒
     */
    public static sleepClick(node: cc.Node | cc.Button, time: number = 1500): void {
        if (!cc.isValid(node)) {
            we.warn(`CommonUtils sleepClick, node is invalid`);
            return;
        }

        if (node instanceof cc.Button) {
            node = node.node;
        }

        let btn = node.getComponent(cc.Button);
        if (!cc.isValid(btn)) {
            we.warn(`CommonUtils sleepClick, btn is invalid, node: ${we.core.utils.getNodePath(node)}`);
            return;
        }

        btn.interactable = false;
        setTimeout(() => {
            if (cc.isValid(btn)) {
                btn.interactable = true;
            }
        }, time);
    }

    /**
     * 获取 host name
     * @param str
     */
    public static getHostName(str: string): string {
        if (!(str && typeof str == 'string')) {
            we.warn('CommonUtils getHostName, params is err');
            return '';
        }

        if (!this.getHost(str)) {
            we.warn('CommonUtils getHostName, str is err');
            return '';
        }

        let reg = /[\w-]+(\.[\w-]+){1,3}/;
        let array = reg.exec(str);
        let ret = array ? array[0] : '';
        return ret;
    }

    /**
     * 比较 url 域名是否相同
     * @param url1
     * @param url2
     * @returns true -相同, false -不同
     */
    public static compareUrlHostname(url1: string, url2: string): boolean {
        if (!url1 || !url2) {
            we.warn('CommonUtils compareUrlHostname, params is err');
            return false;
        }

        let hostname1 = this.getHostName(url1);
        let hostname2 = this.getHostName(url2);

        return hostname1.length > 0 && hostname1 === hostname2;
    }

    /**
     * 替换 host name
     * @param str 被替换的字符串
     * @param hostname 要替换的 host name
     */
    public static replaceHostName(str: string, hostname: string): string {
        if (!(str && typeof str == 'string' && hostname && typeof hostname == 'string')) {
            we.warn('CommonUtils replaceHostName, params is err');
            return '';
        }

        if (!this.getHost(str)) {
            we.warn('CommonUtils replaceHostName, str is err');
            return '';
        }

        let reg = /[\w-]+(\.[\w-]+){1,3}/g;
        let ret = str.replace(reg, hostname);
        return ret;
    }

    /**
     * 生成二维码
     * @param node
     * @param data
     */
    public static generateQrCode(node: cc.Node, data: string, color?: cc.Color): void {
        if (!cc.isValid(node)) {
            we.warn(`CommonUtils generateQrCode, node is invalid`);
            return;
        }

        if (!(data && typeof data == 'string')) {
            we.warn(`CommonUtils generateQrCode, data is invalid, node: ${we.core.utils.getNodePath(node)}`);
            return;
        }

        let graphics = node.addComponent(cc.Graphics);
        graphics.fillColor = cc.Color.BLACK;

        if (color) {
            graphics.fillColor = color;
        }

        let qr = new we.npm.qrcode.QRCode();
        qr.addData(data);
        qr.make();

        let count = qr.getModuleCount();

        // 块宽高
        let tileW = node.width / count;
        let tileH = node.height / count;

        // 偏移
        let offsetW = node.width * node.anchorX;
        let offsetH = node.height * node.anchorY;

        for (let row = 0; row < count; row++) {
            for (let col = 0; col < count; col++) {
                if (qr.isDark(row, col)) {
                    let x = Math.round(col * tileW) - offsetW;
                    let y = Math.round(row * tileH) - offsetH;
                    let w = Math.ceil((col + 1) * tileW) - Math.floor(col * tileW);
                    let h = Math.ceil((row + 1) * tileW) - Math.floor(row * tileW);
                    graphics.rect(x, y, w, h);
                    graphics.fill();
                }
            }
        }
    }

    /**
     * 适配全屏
     * @param node node上不能挂载cc.Widget，父节点必须为全屏节点
     */
    public static adaptFullScreen(node: cc.Node): void {
        if (!cc.isValid(node)) {
            we.warn(`CommonUtils adaptFullScreen, node is invalid`);
            return;
        }

        if (node.getComponent(cc.Widget)) {
            node.removeComponent(cc.Widget);
            we.warn(`CommonUtils adaptFullScreen, widget err, node: ${we.core.utils.getNodePath(node)}`);
        }

        let widget = node.addComponent(cc.Widget);
        widget.alignMode = cc.Widget.AlignMode.ON_WINDOW_RESIZE;

        let heightOriginal = node.height;
        let widthOriginal = node.width;

        let adapt = () => {
            if (!cc.isValid(widget)) {
                return;
            }

            widget.isAlignTop = false;
            widget.isAlignBottom = false;
            widget.isAlignLeft = false;
            widget.isAlignRight = false;

            if (heightOriginal < cc.winSize.height) {
                widget.isAlignTop = true;
                widget.top = 0;

                widget.isAlignBottom = true;
                widget.bottom = 0;
            }

            if (widthOriginal < cc.winSize.width) {
                widget.isAlignLeft = true;
                widget.left = 0;

                widget.isAlignRight = true;
                widget.right = 0;
            }

            widget.updateAlignment();
        };

        adapt();

        // 节点销毁会自动移除注册事件
        cc.view.on('canvas-resize', adapt, node);
    }

    /**
     * 适配刘海
     * @param node node上必须挂载cc.Widget
     * @param offset 偏移量, 默认0:按照 默认刘海高度 60 偏移, !=0:按照 margin + offset 偏移
     */
    public static adaptNotch(node: cc.Node, offset: number = 0): void {
        if (!cc.isValid(node)) {
            we.warn(`CommonUtils adaptNotch, node is invalid`);
            return;
        }

        if (node instanceof cc.Widget) {
            we.warn(`CommonUtils adaptNotch, please use node, node: ${we.core.utils.getNodePath(node.node)}`);
            node = node.node;
        }

        let widget = node.getComponent(cc.Widget);
        if (!widget) {
            we.warn(`CommonUtils adaptNotch, widget not exist, node: ${we.core.utils.getNodePath(node)}`);
            return;
        }

        if (widget['top_original'] == undefined) {
            widget['top_original'] = widget.top;
        }
        if (widget['bottom_original'] == undefined) {
            widget['bottom_original'] = widget.bottom;
        }
        if (widget['left_original'] == undefined) {
            widget['left_original'] = widget.left;
        }
        if (widget['right_original'] == undefined) {
            widget['right_original'] = widget.right;
        }

        if (typeof offset != 'number' || isNaN(offset)) {
            offset = 0;
        }

        let getMargin = (margin: number, abs: boolean, parent: number) => {
            if (!we.core.projectConfig.isNotch) {
                return margin;
            }

            // 默认刘海高度 60
            let notchHeight = we.core.projectConfig.isNotch ? 60 : 0;

            if (abs) {
                if (offset == 0) {
                    margin = margin < notchHeight ? notchHeight : margin;
                } else {
                    margin = margin + offset;
                }
            } else {
                if (offset == 0) {
                    margin = margin < notchHeight / parent ? notchHeight / parent : margin;
                } else {
                    margin = margin + offset / parent;
                }
            }
            return margin;
        };

        let adapt = () => {
            if (!cc.isValid(widget)) {
                return;
            }

            let orientation = we.core.projectConfig.orientation;
            let target = widget.target || widget.node.parent;

            if (widget.isAlignTop) {
                let margin: number = widget['top_original'];
                if (orientation == we.core.ScreenOrientation.PORTRAIT) {
                    margin = getMargin(margin, widget.isAbsoluteTop, target.height);
                }
                widget.top = margin;
            }

            if (widget.isAlignBottom) {
                let margin: number = widget['bottom_original'];
                if (orientation == we.core.ScreenOrientation.PORTRAIT_UPSIDE_DOWN) {
                    margin = getMargin(margin, widget.isAbsoluteBottom, target.height);
                }
                widget.bottom = margin;
            }

            if (widget.isAlignLeft) {
                let margin: number = widget['left_original'];
                if (orientation == we.core.ScreenOrientation.LANDSCAPE_RIGHT) {
                    margin = getMargin(margin, widget.isAbsoluteLeft, target.width);
                }
                widget.left = margin;
            }

            if (widget.isAlignRight) {
                let margin: number = widget['right_original'];
                if (orientation == we.core.ScreenOrientation.LANDSCAPE_LEFT) {
                    margin = getMargin(margin, widget.isAbsoluteRight, target.width);
                }
                widget.right = margin;
            }

            widget.updateAlignment();
        };

        adapt();

        // 节点销毁会自动移除注册事件
        cc.view.on('canvas-resize', adapt, node);
        cc.director.on(we.core.EventName.SCREEN_ORIENTATION_CHANGED, adapt, widget.node);
    }

    /**
     * 适配精灵尺寸
     * @param sprite
     * @param sourceSize
     */
    public static adaptSpriteSize(sprite: cc.Sprite, sourceSize: cc.Size): void {
        if (!cc.isValid(sprite)) {
            we.warn(`CommonUtils adaptSpriteSize, sprite is err`);
            return;
        }

        if (!(sourceSize instanceof cc.Size)) {
            we.warn(`CommonUtils adaptSpriteSize, sourceSize is err, node: ${we.core.utils.getNodePath(sprite.node)}`);
            return;
        }

        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        sprite.type = cc.Sprite.Type.SIMPLE;

        let size = cc.size(0, 0);
        let designSize = sprite.node.getContentSize();
        let designRatio = designSize.width / designSize.height;
        let sourceRatio = sourceSize.width / sourceSize.height;

        if (designRatio == sourceRatio) {
            size = designSize;
        } else if (designRatio > sourceRatio) {
            size.width = (designSize.height / sourceSize.height) * sourceSize.width;
            size.height = designSize.height;
        } else if (designRatio < sourceRatio) {
            size.width = designSize.width;
            size.height = (designSize.width / sourceSize.width) * sourceSize.height;
        }

        sprite.node.setContentSize(size);
    }

    /**
     * 设置组件精灵
     * @param component node/sprite
     * @param url
     * @param onComplete
     */
    public static setComponentSprite(component: cc.Node | cc.Sprite, url: string, onComplete?: Function): void {
        if (!(cc.isValid(component) && url && typeof url == 'string')) {
            we.warn(`CommonUtils setComponentSprite, params err`);
            return;
        }

        we.core.assetMgr.loadAsset(url, cc.SpriteFrame, component).then((spriteFrame) => {
            if (component instanceof cc.Node) {
                if (component.getComponent(cc.Sprite)) {
                    component.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                }
            } else if (component instanceof cc.Sprite) {
                component.spriteFrame = spriteFrame;
            }

            if (typeof onComplete == 'function') {
                onComplete();
            }
        });
    }

    /**
     * 设置头像精灵
     * @param component node/sprite
     * @param avatar id/url
     * @param gender 1: 男
     * @param useClipCircle 是否使用裁剪圆形shader
     * @param scaleTexture 是否缩放纹理
     * @param removeMask 是否移除Mask
     * @param completeCb 成功
     * @param failedCb 失败
     */
    public static setAvatarSprite(
        component: cc.Node | cc.Sprite,
        avatar: string,
        gender: number | boolean = 1,
        useClipCircle: boolean = true,
        scaleTexture: boolean = false,
        removeMask: boolean = true,
        completeCb: Function = null,
        failedCb: Function = null
    ): void {
        if (!(cc.isValid(component) && (component instanceof cc.Node || component instanceof cc.Sprite) && typeof avatar == 'string')) {
            we.warn(`CommonUtils setAvatarSprite, params is err`);
            failedCb?.();
            return;
        }

        if (we.core.flavor.getSkinCode() === we.core.SkinCode.bg) {
            // todo 不进行纹理压缩
            scaleTexture = false;
        }

        let avatarNode: cc.Node = null;
        if (component instanceof cc.Node) {
            avatarNode = component;
        } else if (component instanceof cc.Sprite) {
            avatarNode = component.node;
        }

        if (useClipCircle) {
            if (!avatarNode.parent.getComponent(cc.Mask) && !avatarNode.parent.getChildByName('avatar_frame')) {
                let avatarSize = avatarNode.getContentSize();

                // 添加头像框
                let avatar_frame = new cc.Node();
                avatar_frame.name = 'avatar_frame';
                let avatar_frameSp = avatar_frame.addComponent(cc.Sprite);
                avatar_frameSp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
                avatar_frame.setContentSize(cc.size(avatarSize.width + 5, avatarSize.height + 5));
                we.core.assetMgr.loadAsset(CommonRes.texture.avatar_frame, cc.SpriteFrame, avatar_frameSp).then((asset) => {
                    avatar_frameSp.spriteFrame = asset;
                });
                avatarNode.parent.addChild(avatar_frame);
                avatar_frame.position = avatarNode.position;
            } else {
                avatarNode.parent.getComponent(cc.Mask) && removeMask && avatarNode.parent.removeComponent(cc.Mask);
            }
        }

        if (avatar.startsWith('image/avatar/')) {
            avatar = we.core.utils.joinUrl(we.core.projectConfig.settingsConfig.downloadUrl, avatar);
        }

        let setAvatar = function (spriteFrame: cc.SpriteFrame) {
            if (!cc.isValid(component)) {
                failedCb?.();
                return;
            }

            if (spriteFrame) {
                spriteFrame.getTexture().packable = false;

                if (scaleTexture) {
                    let sprite = component instanceof cc.Sprite ? component : component.getComponent(cc.Sprite);
                    if (sprite) {
                        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
                        let texture = spriteFrame.getTexture();
                        texture.width = component instanceof cc.Node ? component.width : component.node.width;
                        texture.height = component instanceof cc.Node ? component.height : component.node.height;
                    }
                }

                let sprite: cc.Sprite = null;
                if (component instanceof cc.Node) {
                    sprite = component.getComponent(cc.Sprite);
                } else if (component instanceof cc.Sprite) {
                    sprite = component;
                }
                if (sprite) {
                    sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
                    sprite.spriteFrame = spriteFrame;
                }
                if (useClipCircle && sprite) {
                    we.core.assetMgr.loadAsset(CommonRes.material.Glowing, cc.Material, sprite).then((material) => {
                        sprite.setMaterial(0, material);
                        completeCb?.();
                    });
                } else {
                    completeCb?.();
                }
            } else {
                failedCb?.();
            }
        };

        // 加载 bundles 包的头像资源
        let replaceTexture = function (url) {
            we.core.assetMgr.loadAsset(url, cc.SpriteFrame, component).then((spriteFrame) => {
                setAvatar(spriteFrame);
            });
        };

        if (avatar.startsWith('http')) {
            we.core.assetMgr.loadAssetRemote(avatar, cc.SpriteFrame, component).then((spriteFrame) => {
                if (spriteFrame) {
                    setAvatar(spriteFrame);
                } else {
                    // 远程图片头像失败, 使用默认头像（无需打印加载远端资源失败日志，框架有统一打印）
                    replaceTexture(CommonRes.texture.defaultHead);
                }
            });
        } else {
            let avatarId = avatar;
            let avatarIds = UserManager.avatarArr;
            if (avatarIds.indexOf(avatar) == -1) {
                avatarId = gender ? avatarIds[0] : avatarIds[10];
            }

            let country: string[] = [we.core.CountryCode.ng, we.core.CountryCode.br, we.core.CountryCode.in, we.core.CountryCode.vn, we.core.CountryCode.pk, we.core.CountryCode.bd];
            let curCountryCode = we.core.flavor.getCountryCode();
            let index = country.indexOf(curCountryCode);
            let userHeadPath = CommonRes.texture.userHead + `${index > -1 ? curCountryCode : 'default'}/` + avatarId;
            replaceTexture(userHeadPath);
        }
    }

    /**
     * 设置Spine动画皮肤
     * @param skeleton
     * @param skin 皮肤名，优先级: 传入皮肤配置 -> 查找当前语言皮肤名 -> 设置默认皮肤
     * @returns
     */
    public static setSkeletonSkin(skeleton: sp.Skeleton, skin?: string): void {
        if (!(skeleton instanceof sp.Skeleton && skeleton.isValid)) {
            we.warn('CommonUtils setSkeletonSkin, skeleton err');
            return;
        }

        let skins = this.getSkeletonDataSkins(skeleton.skeletonData);
        let skinName = skin;
        if (!skins.includes(skinName)) {
            skinName = we.core.langMgr.getCurLangCode().toString();
            if (!skins.includes(skinName)) {
                skinName = 'default';
                if (!skins.includes(skinName)) {
                    we.warn('CommonUtils setSkeletonSkin, skinName err');
                    return;
                }
            }
        }

        skeleton.setSkin(skinName);
    }

    /**
     * 截图, native 保存本地, 返回文件绝对路径; web 返回文件 base64
     * @param node 截图节点
     * @param offsetW 偏移宽度, 默认 0 表示 node 原宽度, 大于 0 表示增大 n 宽度, 小于 0 表示减小 n 宽度
     * @param offsetH 偏移高度, 默认 0 表示 node 原高度, 大于 0 表示增大 n 高度, 小于 0 表示减小 n 高度
     * @param dirPath 保存目录, 仅 native 有效, 默认应用缓存目录, 支持自定义(比如公共下载目录)
     * @param preview 是否预览, 调试效果时用
     * @returns
     */
    public static captureImage(node: cc.Node, offsetW: number = 0, offsetH: number = 0, dirPath: string = '', preview: boolean = false): string {
        if (!cc.isValid(node)) {
            we.warn(`CommonUtils captureImage, node err`);
            return '';
        }

        if (offsetW <= -node.width) {
            we.warn(`CommonUtils captureImage, offsetW err, node: ${we.core.utils.getNodePath(node)}`);
            offsetW = 0;
        }

        if (offsetH <= -node.height) {
            we.warn(`CommonUtils captureImage, offsetH err, node: ${we.core.utils.getNodePath(node)}`);
            offsetH = 0;
        }

        // 像素数据为(长 x 高 x 4) 的 Uint8Array，所以长、宽必须为整数
        let width = node.width + offsetW;
        if (width > cc.winSize.width) {
            width = cc.winSize.width;
        }
        width = Math.floor(width);

        let height = node.height + offsetH;
        if (height > cc.winSize.height) {
            height = cc.winSize.height;
        }
        height = Math.floor(height);

        let cameraNode = new cc.Node('camera_node_temp');
        node.addChild(cameraNode);

        let texture = new cc.RenderTexture();
        texture.initWithSize(width, height, (<any>cc).gfx.RB_FMT_S8);

        let camera = cameraNode.addComponent(cc.Camera);
        camera.alignWithScreen = false;
        camera.orthoSize = height / 2;
        camera.targetTexture = texture;
        camera.render(node);

        let pixels = texture.readPixels();
        cameraNode.destroy();

        // flipY
        let data = new Uint8Array(width * height * 4);
        let rowBytes = width * 4;
        for (let row = 0; row < height; row++) {
            let start = (height - 1 - row) * width * 4;
            let reStart = row * width * 4;
            for (let i = 0; i < rowBytes; i++) {
                let index = reStart + i;
                data[index] = pixels[start + i];
                if (index % 4 == 3) {
                    // fillA
                    if (data[index] != 0) {
                        data[index] = 255;
                    }
                }
            }
        }

        if (preview) {
            // 异步预览
            setTimeout(() => {
                if (!cc.isValid(node)) {
                    return;
                }

                let graphicsNode = new cc.Node();
                graphicsNode.parent = node;
                let graphics = graphicsNode.addComponent(cc.Graphics);
                graphics.strokeColor = cc.Color.RED;
                graphics.lineWidth = 5;
                graphics.rect(-width / 2, -height / 2, width, height);
                graphics.stroke();

                let texture = new cc.Texture2D();
                texture.initWithData(<any>data, (<any>cc).gfx.TEXTURE_FMT_RGBA8, width, height);

                let spriteFrame = new cc.SpriteFrame();
                spriteFrame.setTexture(texture);

                let capture = new cc.Node();
                capture.addComponent(cc.Sprite).spriteFrame = spriteFrame;
                capture.parent = cc.director.getScene();
                capture.x = cc.winSize.width / 2;
                capture.y = cc.winSize.height / 2;
                capture.zIndex = cc.macro.MAX_ZINDEX;
                let scaleR = 0.5;
                cc.tween(capture)
                    .to(1, { scale: scaleR, position: cc.v3(cc.winSize.width - (width / 2) * scaleR, (height / 2) * scaleR) })
                    .start();
                capture.on(cc.Node.EventType.TOUCH_END, () => {
                    capture.destroy();
                    graphicsNode.destroy();
                });

                let graphicsCaptureNode = new cc.Node();
                graphicsCaptureNode.parent = capture;
                let graphicsCapture = graphicsCaptureNode.addComponent(cc.Graphics);
                graphicsCapture.strokeColor = cc.Color.RED;
                graphicsCapture.lineWidth = 5;
                graphicsCapture.rect(-capture.width / 2, -capture.height / 2, capture.width, capture.height);
                graphicsCapture.stroke();
            });
        }

        if (cc.sys.isNative) {
            // 保存到可写路径
            if (dirPath && typeof dirPath == 'string') {
                dirPath = dirPath + (dirPath.endsWith('/') ? '' : '/');
            } else {
                dirPath = jsb.fileUtils.getWritablePath() + 'image/capture/';
                if (!jsb.fileUtils.isDirectoryExist(dirPath)) {
                    jsb.fileUtils.createDirectory(dirPath);
                }
            }

            let filePath = dirPath + `${new Date().getTime()}.png`;
            let success = jsb.saveImageData(data, width, height, filePath);
            if (!success) {
                we.warn(`CommonUtils captureImage, saveImageData err, node: ${we.core.utils.getNodePath(node)}`);
            }
            return filePath;
        } else {
            // 生成base64
            let canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;

            let ctx = canvas.getContext('2d');
            let imageData = ctx.createImageData(width, height);
            for (let i = 0; i < data.length; i++) {
                imageData.data[i] = data[i];
            }
            ctx.putImageData(imageData, 0, 0);

            let dataURL = canvas.toDataURL('image/png');
            return dataURL;
        }
    }

    /**
     * 设置材质-正常
     * @param component
     */
    public static setMaterialNormal(component: cc.RenderComponent): void {
        if (!(cc.isValid(component) && component instanceof cc.RenderComponent)) {
            we.warn(`CommonUtils setMaterialNormal, params err`);
            return;
        }

        // @ts-ignore
        let material = cc.Material.getBuiltinMaterial('2d-sprite');
        component.setMaterial(0, material);
    }

    /**
     * 设置材质-灰色
     * @param component
     */
    public static setMaterialGray(component: cc.RenderComponent): void {
        if (!(cc.isValid(component) && component instanceof cc.RenderComponent)) {
            we.warn(`CommonUtils setMaterialGray, params err`);
            return;
        }

        // @ts-ignore
        let material = cc.Material.getBuiltinMaterial('2d-gray-sprite');
        component.setMaterial(0, material);
    }

    /**
     * 功能开关，2s内点击5次
     * @param featureNode 功能节点
     * @param switchNode 开关节点
     */
    public static featureSwitch(featureNode: cc.Node, switchNode: cc.Node): void {
        if (!(cc.isValid(featureNode) && featureNode instanceof cc.Node && cc.isValid(switchNode) && switchNode instanceof cc.Node)) {
            we.warn(`CommonUtils featureSwitch, params is err`);
            return;
        }

        let touchRecord: number[] = [];
        let onTouchStart = () => {
            let seconds = Math.floor(new Date().getTime() / 1000);
            touchRecord.push(seconds);
            if (touchRecord.length >= 5) {
                if (cc.isValid(featureNode)) {
                    let lastFirst = touchRecord[touchRecord.length - 1];
                    let lastFifth = touchRecord[touchRecord.length - 5];
                    if (lastFirst - lastFifth <= 2) {
                        touchRecord = [];
                        featureNode.active = !featureNode.active;
                    }
                }
            }
        };

        switchNode.on(cc.Node.EventType.TOUCH_START, onTouchStart, switchNode);
    }

    /**
     * 数据中敏感 key 对应的 value 进行脱敏处理(仅支持对象处理,谨慎使用)
     * 仅包含匹配 key 非全量
     * @param data 需要脱敏数据对象
     * @param sensitiveKeyArr 默认敏感 key = ['password'],可自定义
     * @param maskStr 默认 maskStr = '******', 可自定义
     * @returns
     */
    public static maskSensitiveData(data: Object, sensitiveKeyArr: string[] = ['password'], maskStr: string = '******'): Object {
        if (typeof data != 'object' || sensitiveKeyArr?.length < 1) {
            return data;
        }

        // 深度拷贝数据，防止脱敏时修改原数据
        let result = we.npm.lodash.cloneDeep(data);
        let fun = (obj: Object) => {
            for (let key in obj) {
                let temp = obj[key];
                if (typeof temp == 'object') {
                    fun(obj[key]);
                } else if (typeof temp == 'string') {
                    for (let i = 0; i < sensitiveKeyArr.length; i++) {
                        if (key.includes(sensitiveKeyArr[i])) {
                            obj[key] = maskStr;
                            break;
                        }
                    }
                }
            }
        };
        fun(result);

        return result;
    }

    /**
     * 获取Spine动画皮肤
     * @param skeletonData
     * @returns
     */
    private static getSkeletonDataSkins(skeletonData: sp.SkeletonData): string[] {
        if (!(skeletonData instanceof sp.SkeletonData && skeletonData.isValid)) {
            we.warn('CommonUtils getSkeletonDataSkins, data is null');
            return null;
        }

        // @ts-ignore
        const skinsData = skeletonData?._skeletonJson?.skins;
        // 获取Spine动画皮肤兼容3.8版本
        if (skinsData instanceof Array) {
            return skinsData.map((item) => {
                return item.name;
            });
        }
        return Object.keys(skinsData || { default: '' });
    }

    private static getHost(str: string): string {
        if (!(str && typeof str == 'string')) {
            we.warn('CommonUtils getHost, params is err');
            return '';
        }

        let reg = /(http(s)?|ws(s)?):\/\/[\w-]+(\.[\w-]+){1,3}(:\d+)?/;
        let array = reg.exec(str);
        let ret = array ? array[0] : '';
        return ret;
    }

    /**
     * 获取账号记录
     * @returns
     */
    public static readAccountRecord(): CommonType.IAccountInfo[] {
        let accountRecord = [];
        accountRecord = we.common.sys.get('sys', 'user_account_record') || [];
        if (accountRecord.length > 0) {
            return accountRecord;
        }

        let accounts = we.common.sys.rw.get('account_record');
        try {
            accountRecord = JSON.parse(accounts) || [];
        } catch {}

        // 字段变更适配
        let accountRecordArr: CommonType.IAccountInfo[] = [];
        for (let i = 0; i < accountRecord.length; i++) {
            const element = accountRecord[i];
            let account = {} as CommonType.IAccountInfo;
            account.userId = element.userId;
            account.phoneNum = element.phoneNum;
            account.email = element.email;
            account.password = element.pwd;
            accountRecordArr.push(account);
        }
        we.common.sys.setById('sys', 'user_account_record', accountRecordArr);

        return accountRecordArr;
    }

    /**
     * 判断功能是否是当天首次打开
     * @param type 功能点类型, 后续 type 多了抽离成字符串枚举
     */
    public static isFirstOpenToday(type: 'ChangeLangTips'): boolean {
        if (!type || typeof type !== 'string') {
            we.warn('Utils isFirstOpenToday, type parameter is invalid', type);
            return false;
        }
        const now = new Date();
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
        const data = CommonType.storage.get('common', 'first_open_timestamp') || {};
        const lastOpenTime = data[type];

        // 如果没有记录或者不是今天，则认为是首次打开
        if (!lastOpenTime || lastOpenTime < todayStart) {
            data[type] = now.getTime();
            CommonType.storage.setById('common', 'first_open_timestamp', data);
            return true;
        }
        return false;
    }
}

we.common.utils = CommonUtils;
