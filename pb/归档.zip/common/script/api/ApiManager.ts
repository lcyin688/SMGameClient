/**
 * http请求（短连接）实现
 * 1、解决了http请求分散在整个项目里的问题，保证在同一个地方，可以看到全部的http请求。
 * 2、解决了同一个http请求，被多处实现的问题
 * 3、多余的http请求代码，以及散在项目各处的http请求，都会被删除
 * 4、删除了以前的CommonApiMgr和很多业务逻辑的ApiMgr（比如HallApiMgr、PayApiMgr等）
 */

import Api, { ApiNoTokenList, ApiRealtimeList } from '../api/Api';
import { CommonRes } from '../config/CommonRes';
import { Bundles } from '../const/Bundles';
import CommonHttpJson from '../http/CommonHttpJson';
import CommonHttpProto from '../http/CommonHttpProto';
import CommonProtoBufHttp from '../http/CommonProtoBufHttp';
import CommonMgr from '../manager/CommonMgr';
import UserManager from '../manager/UserManager';
import ApiProtoFile from '../proto/ApiProtoFile';

declare global {
    interface ICommon {
        apiMgr: typeof ApiManager;
    }
}

export default class ApiManager {
    private static httpType = {
        post: 'POST',
        get: 'GET',
        put: 'PUT',
    };

    private static protoBuf: CommonProtoBufHttp = null;

    /** 时间间隔配置 */
    private static intervalTimeCfg = {
        /** 实时性高 单位: ms */
        realtimeHigh: 0,
        /** 实时性低 单位: ms */
        realtimeLow: 1500,
    };

    /** api 请求记录 */
    private static reqRecordMap = new Map<string, number>();

    public static init() {
        this.protoBuf = new CommonProtoBufHttp(ApiProtoFile);
    }

    /**
     * 请求检测
     * 1.检查是否需要登陆态
     * 2.频率间隔
     * @param api
     * @returns {boolean}
     */
    static checkApiReq(api: string): boolean {
        // 登录态校验
        if (!ApiNoTokenList.includes(api)) {
            let userId = UserManager.userInfo.userId;
            let token = UserManager.token;
            if (!(userId && token)) {
                we.warn(`ApiManager checkApiReq, token err, api: ${api}, userId: ${userId}, token: ${token}`);
                CommonMgr.goLogin(we.core.langMgr.getLangText(we.common.lang.ERROR_USUAL_TYPE_10), '10.1');
                return false;
            }
        }

        // 请求间隔校验
        let timestamp = this.reqRecordMap.get(api);
        if (timestamp > 0) {
            let interval = this.intervalTimeCfg.realtimeLow;
            if (ApiRealtimeList.includes(api)) {
                interval = this.intervalTimeCfg.realtimeHigh;
            }

            let curTimeMs = Date.now();
            if (curTimeMs - timestamp < interval) {
                we.warn(`ApiManager checkApiReq, interval exception, api: ${api}`);
                return false;
            }
        }
        this.reqRecordMap.set(api, Date.now());

        return true;
    }

    // ////////////////////////////////////////////// 子游戏相关 ////////////////////////////////////////////////
    /**
     * http请求接口(json)
     */
    static doHttpRequestJson(gameId: number, api: string, type: string, data: any, sucCb: Function, errorCallback: Function, loading: boolean = false) {
        let http = new CommonHttpJson();
        let host = we.core.serverMgr.getGameHttp(gameId);
        http.request(host, null, api, type, data, sucCb, errorCallback, loading);
    }

    // ////////////////////////////////////////////// 大厅相关 ////////////////////////////////////////////////
    /**
     * http请求接口(protobuf)
     * @param api api
     * @param reqData 请求数据
     * @param reqName req message name
     * @param respName resp message name
     * @param sucCb 成功回调
     * @param errCb 失败回调
     * @param loading 展示 loading 默认：false
     * @param delayLoading 延迟展示 loading 默认：true
     * @param timeoutValue 超时时间 单位 ms
     * @returns
     */
    static doHttpRequestProto(api: string, reqData: Object, reqName: string, respName: string, sucCb: Function, errCb: Function, loading: boolean = false, delayLoading: boolean = true, timeoutValue: number = 0) {
        let result = this.checkApiReq(api);
        if (!result) {
            return;
        }

        let host = we.core.serverMgr.getHallHost();
        // 浏览器支持调试指定模块或单个 api 调试，仅在测试环境生效
        if (we.core.flavor.isTestEnv() && cc.sys.isBrowser) {
            const urlParams = we.core.utils.getLocationUrlParam(we.core.BrowserParamKey.svuhm)?.split(',') || [];
            if (urlParams instanceof Array && urlParams.length == 2) {
                let apiList = [];
                if (urlParams[0].includes('/')) {
                    apiList.push(urlParams[0]);
                } else {
                    let apiConf = Api[urlParams[0]];
                    if (apiConf) {
                        let keys = Object.keys(apiConf);
                        for (let i = 0; i < keys.length; i++) {
                            apiList.push(apiConf[keys[i]]);
                        }
                    }
                }

                // 满足条件，使用指定 host
                for (let i = 0; i < apiList.length; i++) {
                    if (api.includes(apiList[i])) {
                        host = `http://${urlParams[1]}`;
                        break;
                    }
                }
            }
        }

        let http = new CommonHttpProto();
        timeoutValue && http.setTimeoutValue(timeoutValue);
        http.request(host, api, this.httpType.post, this.protoBuf, reqData, reqName, respName, sucCb, errCb, loading, delayLoading);
    }

    /**
     * UI相关配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static loadUIConfig(sucCb: Function, errCb: Function, showLoading?: boolean) {
        this.doHttpRequestProto(Api.launcher.uiConfig, null, 'SettingsReq', 'SettingsResp', sucCb, errCb, showLoading, false);
    }

    /**
     * 自研游戏 获取房间相关配置信息
     * @param gameId we.GameId
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getRoomConfig(gameId: we.GameId, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let data = {} as ApiProto.RoomInfoReq;
        data.gameId = gameId;
        data.userId = UserManager.userInfo.userId;
        data.bundles = [Bundles.main, Bundles.common].concat(CommonRes.gameComBundles);
        this.doHttpRequestProto(Api.lobby.getRoomConfig, data, 'RoomInfoReq', 'RoomInfoResp', sucCb, errCb, showLoading);
    }

    static async getRoomConfigAsync(gameId: we.GameId, showLoading: boolean = true): Promise<ApiProto.RoomInfoResp> {
        const defer = we.core.PromiseHelper.defer<ApiProto.RoomInfoResp>();
        let data = {} as ApiProto.RoomInfoReq;
        data.gameId = gameId;
        data.userId = UserManager.userInfo.userId;
        data.bundles = [Bundles.main, Bundles.common].concat(CommonRes.gameComBundles);
        this.doHttpRequestProto(
            Api.lobby.getRoomConfig,
            data,
            'RoomInfoReq',
            'RoomInfoResp',
            (resp) => {
                defer.resolve(resp);
            },
            (err) => {
                defer.reject(err);
            },
            showLoading
        );

        return await defer.promise();
    }

    /**
     * Api 游戏 获取房间相关配置信息
     * @param gameId
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getApiRoomConfig(gameId: number, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let data = {} as ApiProto.GetApiRoomConfReq;
        data.gameId = gameId;
        data.bundles = [Bundles.comwbg];
        this.doHttpRequestProto(Api.lobby.getApiRoomConfig, data, 'GetApiRoomConfReq', 'GetApiRoomConfResp', sucCb, errCb, showLoading, true, 60_000);
    }

    static async getApiRoomConfigAsync(gameId: we.GameId, showLoading: boolean = true): Promise<ApiProto.GetApiRoomConfResp> {
        const defer = we.core.PromiseHelper.defer<ApiProto.GetApiRoomConfResp>();
        let data = {} as ApiProto.GetApiRoomConfReq;
        data.gameId = gameId;
        data.bundles = [Bundles.comwbg];

        this.doHttpRequestProto(
            Api.lobby.getApiRoomConfig,
            data,
            'GetApiRoomConfReq',
            'GetApiRoomConfResp',
            (resp) => {
                defer.resolve(resp);
            },
            (err) => {
                defer.reject(err);
            },
            showLoading,
            true,
            60_000
        );

        return await defer.promise();
    }

    /**
     * 退出 Api 游戏时向服务器发起退出请求
     * @param gameId
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static exitApiGame(gameId: number, sucCb: Function = null, errCb: Function = null, showLoading: boolean = false) {
        let data = {} as ApiProto.ExitApiGameReq;
        data.gameId = gameId;
        this.doHttpRequestProto(Api.lobby.exitApiGame, data, 'ExitApiGameReq', 'ExitApiGameResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取进入房间限制
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getGameEnterLimitConf(sucCb: Function = null, errCb: Function = null, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.lobby.gameEnterLimit, null, 'GameEnterLimitReq', 'GameEnterLimitResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取是否有未完成的游戏
     * @param sucCb
     * @param errCB
     * @param showLoading
     */
    static getOngoingGame(sucCb: Function, errCB: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.lobby.getOngoingGame, null, 'OngoingGameReq', 'OngoingGameResp', sucCb, errCB, showLoading);
    }

    /**
     * 获取大厅游戏入口 jackpot 奖池数据
     * @param sucCb
     * @param errCb
     */
    static getJackpot(sucCb?: Function, errCb?: Function) {
        this.doHttpRequestProto(Api.lobby.getJackpot, null, 'JackpotReq', 'JackpotResp', sucCb, errCb, false);
    }

    /**
     * 请求牌类游戏房间在线人数
     * @param data
     * @param sucCb
     * @param errCb
     */
    static getGamePlayerCountConfig(data: ApiProto.GetGamePlayerCountReq, sucCb?: Function, errCb?: Function): void {
        this.doHttpRequestProto(Api.lobby.onlineNumber, data, 'GetGamePlayerCountReq', 'GetGamePlayerCountResp', sucCb, errCb, false);
    }

    /**
     * 获取大厅相关静态配置 包含：账号绑定状态和奖励配置/ Vip 等级配置/道具配置/游戏入场限制/大厅Banner/事件中心展示/首次使用指定app奖励状态
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getLobbyStaticConf(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.lobby.static, null, 'LobbyStaticConfigReq', 'LobbyStaticConfigResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取大厅相关动态数据 包含：Vip 奖励状态/持有道具信息/活动数据（每日充值/狂欢活动）
     * /新手礼包/周卡信息/每日签到/大厅游戏入口jackpot/打码返利/代理
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getLobbyDynamicConf(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.lobby.dynamic, null, 'LobbyDynamicConfigReq', 'LobbyDynamicConfigResp', sucCb, errCb, showLoading);
    }

    /**
     * 设置玩家国家数据
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static setUserCountry(data: ApiProto.UserCountryBindReq, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.account.accountCountryBind, data, 'UserCountryBindReq', 'UserCountryBindResp', sucCb, errCb, showLoading);
    }

    /**
     * 上报语言
     * @param data api.accountLangBindReq
     * @param sucCb
     * @param errCb
     */
    static reportLanguage(data: ApiProto.accountLangBindReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.accountLangBind, data, 'accountLangBindReq', 'accountLangBindResp', sucCb, errCb, false);
    }

    /**
     * 设备对应账户状态
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getDeviceAccountStatus(sucCb: Function, errCb: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.account.deviceAccountSt, null, 'DeviceAccountStatusReq', 'DeviceAccountStatusResp', sucCb, errCb, showLoading, false, 30 * 1000);
    }

    /**
     * 获取验证码
     * @param data data: api.VerifyCodeReq
     * @param sucCb
     * @param errCb
     * @returns
     */
    static getNewPhoneCode(data: ApiProto.VerifyCodeReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.getNewPhoneCode, data, 'VerifyCodeReq', 'VerifyCodeResp', sucCb, errCb, true);
    }

    /**
     * 校验短信验证码
     * @param data api.PhoneVerifyReq
     * @param sucCb
     * @param errCb
     * @param showLoading
     * @returns
     */
    static checkVerifyCode(data: ApiProto.PhoneVerifyReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.checkVerifyCode, data, 'PhoneVerifyReq', 'PhoneVerifyResp', sucCb, errCb, true);
    }

    /**
     * 游客登录
     * @param sucCb
     * @param errCb
     * @param showLoading
     * @returns
     */
    static guestLogin(sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let data = {} as ApiProto.AnonymousLoginReq;
        data.trackReportData = we.core.trackMgr.getTrackReportData();

        this.doHttpRequestProto(Api.account.guestLogin, data, 'AnonymousLoginReq', 'AnonymousLoginResp', sucCb, errCb, showLoading, false);
    }

    /**
     * token登录
     * @param sucCb
     * @param errCb
     */
    static tokenLogin(sucCb: Function, errCb: Function) {
        let tmpTokenLogin = we.kit.storage.get('sys', 'user_tmp_token_login_tag') > 0;
        we.kit.storage.del('sys', 'user_tmp_token_login_tag');

        let data = {} as ApiProto.TokenLoginReq;
        data.tmpTokenLogin = tmpTokenLogin;
        let onSuccess = (resp) => {
            sucCb?.(resp, tmpTokenLogin);
        };
        this.doHttpRequestProto(Api.account.tokenLogin, data, 'TokenLoginReq', 'TokenLoginResp', onSuccess, errCb, false, false);
    }

    /**
     * 获取临时登录 token
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    public static getTempToken(sucCb?: Function, errCb?: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.account.getTempToken, null, 'GetTmpTokenReq', 'GetTmpTokenResp', sucCb, errCb, showLoading, false);
    }

    /**
     * facebook 登录
     * @param data api.FacebookLoginReq
     * @param sucCb
     * @param errCb
     */
    static facebookLogin(data: ApiProto.FacebookLoginReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.facebookLogin, data, 'FacebookLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * facebook 绑定
     * @param data
     * @param sucCb
     * @param errCb
     */
    static facebookBind(data: ApiProto.FacebookLoginReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.facebookBind, data, 'FacebookLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * apple 登录
     * @param data api.AppleLoginReq
     * @param sucCb
     * @param errCb
     * @returns
     */
    static appleLogin(data: ApiProto.AppleLoginReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.appleLogin, data, 'AppleLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * apple 绑定
     * @param data api.AppleLoginReq
     * @param sucCb
     * @param errCb
     * @returns
     */
    static appleBind(data: ApiProto.AppleLoginReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.appleBind, data, 'AppleLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * google 登录
     * @param data api.GoogleLoginReq
     * @param sucCb
     * @param errCb
     * @returns
     */
    static googleLogin(data: ApiProto.GoogleLoginReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.googleLogin, data, 'GoogleLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * google 绑定
     * @param data api.GoogleLoginReq
     * @param sucCb
     * @param errCb
     * @returns
     */
    static googleBind(data: ApiProto.GoogleLoginReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.account.googleBind, data, 'GoogleLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * 登录界面注册
     * @param data api.PhonRegisterReq
     * @param sucCb
     * @param errCb
     */
    static phoneRegister(data: ApiProto.PhonRegisterReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        data.trackReportData = we.core.trackMgr.getTrackReportData();
        this.doHttpRequestProto(Api.account.phoneRegister, data, 'PhonRegisterReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * 游戏内绑定注册
     * @param data api.PhonRegisterReq
     * @param sucCb
     * @param errCb
     */
    static phonBind(data: ApiProto.PhonRegisterReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        this.doHttpRequestProto(Api.account.phoneBind, data, 'PhonRegisterReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * phoneNumber 登录
     * @param data api.PhoneLoginReq
     * @param sucCb
     * @param errCb
     */
    static phoneLogin(data: ApiProto.PhoneLoginReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        this.doHttpRequestProto(Api.account.phoneLogin, data, 'PhoneLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * userId 登录
     * @param data
     * @param sucCb
     * @param errCb
     */
    static userIdLogin(data: ApiProto.IdLoginReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        this.doHttpRequestProto(Api.account.userIdLogin, data, 'IdLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * 重置密码(手机登录)
     * @param data
     * @param sucCb
     * @param errCb
     */
    static resetPasswordReq(data: ApiProto.ResetPasswordReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        this.doHttpRequestProto(Api.account.resetPassword, data, 'ResetPasswordReq', 'ResetPasswordResp', sucCb, errCb, true);
    }

    /**
     * 邮箱登录
     * @param data
     * @param sucCb
     * @param errCb
     */
    static emailLogin(data: ApiProto.EmailLoginReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        this.doHttpRequestProto(Api.account.emailLogin, data, 'EmailLoginReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * 邮箱注册账号
     * @param data
     * @param sucCb
     * @param errCb
     */
    static emailRegister(data: ApiProto.EmailRegisterReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        data.trackReportData = we.core.trackMgr.getTrackReportData();
        this.doHttpRequestProto(Api.account.emailRegister, data, 'EmailRegisterReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * 邮箱绑定
     * @param data
     * @param sucCb
     * @param errCb
     */
    static emailBind(data: ApiProto.EmailRegisterReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        this.doHttpRequestProto(Api.account.emailBind, data, 'EmailRegisterReq', 'LoginResp', sucCb, errCb, true);
    }

    /**
     * 获取邮箱验证码
     * @param data
     * @param sucCb
     * @param errCb
     */
    static getEmailCode(data: ApiProto.VerifyEmailCodeReq, sucCb: Function, errCb: Function): void {
        this.doHttpRequestProto(Api.account.getEmailCode, data, 'VerifyEmailCodeReq', 'VerifyEmailCodeResp', sucCb, errCb, true);
    }

    /**
     * 校验邮箱验证码
     * @param data
     * @param sucCb
     * @param errCb
     */
    static verifyEmailCode(data: ApiProto.EmailVerifyReq, sucCb: Function, errCb: Function): void {
        this.doHttpRequestProto(Api.account.verifyEmailCode, data, 'EmailVerifyReq', 'EmailVerifyResp', sucCb, errCb, true);
    }

    /**
     * 邮箱修改密码
     * @param data
     * @param sucCb
     * @param errCb
     */
    static resetPasswordEmail(data: ApiProto.ResetEmailPasswordReq, sucCb: Function, errCb: Function): void {
        data.passwordMd5 = we.core.utils.md5hex(data.passwordMd5);
        this.doHttpRequestProto(Api.account.resetPasswordEmail, data, 'ResetEmailPasswordReq', 'ResetEmailPasswordResp', sucCb, errCb, true);
    }

    /**
     * 获取用户完整信息
     * @param data api.UserInfoReq
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getUserInfo(data: ApiProto.UserInfoReq, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.account.getUserInfo, data, 'UserInfoReq', 'UserInfoResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取设备绑定fb状态
     * @param aid
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getFBExists(aid: string, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        let data = {} as ApiProto.FBExistsReq;
        data.aid = aid;
        this.doHttpRequestProto(Api.account.fbExists, data, 'FBExistsReq', 'FBExistsResp', sucCb, errCb, showLoading);
    }

    /**
     * 修改用户信息
     * @param data api.ModifyUserReq
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static changeUserInfo(data: ApiProto.ModifyUserReq, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.user.changeUserInfo, data, 'ModifyUserReq', 'ModifyUserResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取玩家历史头像
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAvatarHistory(sucCb: Function, errCb: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.user.getAvatarHistory, null, 'AvatarHistoryReq', 'AvatarHistoryResp', sucCb, errCb, showLoading);
    }

    /**
     * 通过用户userId获取信息
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getUserProfileById(data: ApiProto.UserProfileReq, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.user.query_profile, data, 'UserProfileReq', 'UserProfileResp', sucCb, errCb, showLoading);
    }

    /**
     * 收集玩家数据上报服务器
     * @param data
     * @param sucCb
     * @param errCb
     */
    static reportUserExtraInfo(data: ApiProto.UpdateExtraInfoReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.user.updateExtraInfo, data, 'UpdateExtraInfoReq', 'UpdateExtraInfoResp', sucCb, errCb, false);
    }

    /**
     * 请求获取玩家当前金币 刷新金币
     * @param sucCb
     * @param errCb
     */
    static getUserCreditReq(sucCb?: Function, errCb?: Function): void {
        this.doHttpRequestProto(Api.user.getUserCredit, null, 'UserCreditReq', 'UserCreditResp', sucCb, errCb);
    }

    /**
     * 查询Vip等级信息
     * @param sucCb
     * @param errCb
     */
    static getVipInfo(sucCb?: Function, errCb?: Function): void {
        this.doHttpRequestProto(Api.user.getVipInfo, null, 'UserVipInfoReq', 'UserVipInfoResp', sucCb, errCb);
    }

    /**
     * 获取用户实名信息
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getUserContact(sucCb: Function, errCb: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.user.getUserContact, null, 'GetUserContactReq', 'GetUserContactResp', sucCb, errCb, showLoading);
    }

    /**
     * 添加用户实名信息
     * @param param
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static addUserContact(param: ApiProto.UserContactReq, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.user.addUserContact, param, 'UserContactReq', 'UserContactResp', sucCb, errCb, showLoading);
    }

    /**
     * 更新用户实名信息
     * @param param
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static updateUserContact(param: ApiProto.UpdateUserContactReq, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.user.updateUserContact, param, 'UpdateUserContactReq', 'UpdateUserContactResp', sucCb, errCb, showLoading);
    }

    /**
     * 更新用户实名信息
     * @param param
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static clientReportAdjustCallback(param: ApiProto.ClientReportAdjustCallbackReq, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.user.clientReportAdjustCallback, param, 'ClientReportAdjustCallbackReq', 'ClientReportAdjustCallbackResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取充值配置
     * @param vipShop vip 商店
     * @param sucCb
     * @param errCb
     * @param showLoading
     * @returns
     */
    static getShopConfig(vipShop: boolean = false, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let data = {} as ApiProto.ShopConfReq;
        data.userId = UserManager.userInfo.userId;
        data.isVip = vipShop;
        this.doHttpRequestProto(Api.recharge.shopConf, data, 'ShopConfReq', 'ShopConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取充值订单记录
     * @param sucCb
     * @param errCb
     * @param showLoading
     * @returns
     */
    static getOrderListReq(sucCb: Function, errCb: Function, showLoading: boolean = true): void {
        this.doHttpRequestProto(Api.recharge.getOrderList, null, 'GetOrderListReq', 'GetOrderListResp', sucCb, errCb, showLoading);
    }

    /**
     * 支付前检查未完成订单
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static checkOrderReq(sucCb: Function, errCb: Function, showLoading: boolean = true): void {
        this.doHttpRequestProto(Api.recharge.checkOrder, null, 'CheckOrderReq', 'CheckOrderResp', sucCb, errCb, showLoading);
    }

    /**
     * 支付验证
     * @param data api.RechargeAuthReq
     * @param sucCb
     * @param errCb
     * @param showLoading
     * @returns
     */
    static payAuthInfo(data: ApiProto.RechargeAuthReq, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        return;
        this.doHttpRequestProto(Api.recharge.payAuthInfo, data, 'RechargeAuthReq', 'RechargeAuthResp', sucCb, errCb, showLoading, false);
    }

    /**
     * 新手礼包配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getNewbieGiftBagCfg(sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.recharge.newbieGiftConf, null, 'FirstRechargeConfReq', 'FirstRechargeConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 充值商品支持 充值渠道
     * @param productId
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getActiveRechargeType(productId: string, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let req = {} as ApiProto.payTypeReq;
        req.productId = productId;
        this.doHttpRequestProto(Api.recharge.payType, req, 'payTypeReq', 'payTypeResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取多商品充值类型
     * @param productIds
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getPayTypeByProducts(productIds: string[], sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let req = {} as ApiProto.payTypeByProductsReq;
        req.productId = productIds;
        this.doHttpRequestProto(Api.recharge.payTypeByPs, req, 'payTypeByProductsReq', 'payTypeByProductsResp', sucCb, errCb, showLoading);
    }

    /**
     * 充值订单获取
     * @param productId 商品 ID
     * @param payType 充值类型
     * @param bankCode 银行代码 仅有银行充值渠道使用
     * @param amount 商品数量
     * @param position 订单创建位置
     * @param sucCb
     * @param errCb
     */
    static getQueryOrder(productId: string, payType: number, bankCode: string, amount: number, position: string, sucCb: Function, errCb: Function) {
        let req = {} as ApiProto.QueryOrderReq;
        req.productId = productId;
        req.payType = payType;
        req.bankCode = bankCode;
        req.amount = amount;
        req.position = position;
        this.doHttpRequestProto(Api.recharge.queryOrder, req, 'QueryOrderReq', 'QueryOrderResp', sucCb, errCb, true);
    }

    /**
     * 获取VIP充值配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getVipRechargeConfig(sucCb: Function, errCb: Function, showLoading: boolean = false, delayLoading = true) {
        this.doHttpRequestProto(Api.recharge.vipRechargeConfig, null, 'VIPRechargeConfigReq', 'VIPRechargeConfigResp', sucCb, errCb, showLoading, delayLoading);
    }

    /**
     * 创建VIP充值订单
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static createVipRechargeOrder(data: ApiProto.CreateVIPOrderReq, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.recharge.vipRechargeCreate, data, 'CreateVIPOrderReq', 'CreateVIPOrderResp', sucCb, errCb, showLoading);
    }

    /**
     * 确认VIP充值订单
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static affirmVipRechargeOrder(data: ApiProto.VIPOrderAffirmReq, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.recharge.vipRechargeAffirm, data, 'VIPOrderAffirmReq', 'VIPOrderAffirmResp', sucCb, errCb, showLoading);
    }

    /**
     * 取消VIP充值订单
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static cancelVipRechargeOrder(data: ApiProto.VIPOrderCancelReq, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.recharge.vipRechargeCancel, data, 'VIPOrderCancelReq', 'VIPOrderCancelResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取活动中心配置信息
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getActivityConf(sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.activityConf, null, 'ActivityConfReq', 'ActivityConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取活动大厅入口配置信息
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static queryActivityBannerConf(sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.bindAwardConf, null, 'activityBannerReq', 'activityBannerResp', sucCb, errCb, showLoading);
    }

    /**
     * 礼包码领取
     * @param code 兑换码
     * @param sucCb
     * @param code
     */
    static getGiftCodeCoin(code: string, sucCb: Function, errCb: Function) {
        let data = {} as ApiProto.giftReceiveReq;
        data.code = code;
        this.doHttpRequestProto(Api.activity.giftReceive, data, 'giftReceiveReq', 'giftReceiveResp', sucCb, errCb, true);
    }

    /**
     * 获取每日签到配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getDailyFreeAwardConf(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.activity.dailyFreeAwardConf, null, 'DailyFreeAwardConfReq', 'DailyFreeAwardConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取每日签到奖励
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getDailyFreeAward(sucCb?: Function, errCb?: Function, showLoading: boolean = true): void {
        this.doHttpRequestProto(Api.activity.getDailyFreeAward, null, 'GetDailyFreeAwardReq', 'GetDailyFreeAwardResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取周卡开关配置、档位配置信息、购买周卡信息
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getWeekCardConf(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.weekCard.conf, null, 'WeeklyCardConfReq', 'WeeklyCardConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 领取周卡每日奖励
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getWeekCardAward(data: ApiProto.UserWeeklyCardClaimReq, sucCb?: Function, errCb?: Function, showLoading: boolean = true): void {
        this.doHttpRequestProto(Api.weekCard.getAward, data, 'UserWeeklyCardClaimReq', 'UserWeeklyCardClaimResp', sucCb, errCb, showLoading);
    }

    /**
     * 请求大厅/slots游戏选择界面 Banner配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getBannerConfReq(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.activity.bannerConf, null, 'BannerConfReq', 'BannerConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 跨天查询数据
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getConfCrossDay(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        let data = {} as ApiProto.ConfCrossDayReq;
        this.doHttpRequestProto(Api.activity.crossDay, data, 'ConfCrossDayReq', 'ConfCrossDayResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取首次使用指定app奖励配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getOfficialBagBonusConf(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.officialAppAward, null, 'GetBonusConfReq', 'GetBonusConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 领取首次使用指定app奖励
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getOfficialBagAward(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.getOfficialAppAward, null, 'ReceiveBonusReq', 'ReceiveBonusResp', sucCb, errCb, showLoading);
    }

    /**
     * 活动重构后 每日累充活动数据
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getDailyRechargeInfo(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.dailyRechargeInfo, null, 'RechargeTaskProgressReq', 'RechargeTaskProgressResp', sucCb, errCb, showLoading);
    }

    /**
     * 活动重构后 领取任务奖励（每日累充，狂欢活动，独立日活动）
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static drawActivityAward(data: ApiProto.DrawNewTaskAwardReq, sucCb: Function, errCb?: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.activity.drawActivityAward, data, 'DrawNewTaskAwardReq', 'DrawNewTaskAwardResp', sucCb, errCb, showLoading);
    }

    /**
     * 活动重构后 狂欢活动数据
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getCarnivalActivityInfo(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.carnivalActivityInfo, null, 'CarnivalTaskProgressReq', 'CarnivalTaskProgressResp', sucCb, errCb, showLoading);
    }

    /**
     * 活动重构后 独立日活动数据
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getIndependenceActivityInfo(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.independenceActivityInfo, null, 'IndependenceTaskProgressReq', 'IndependenceTaskProgressResp', sucCb, errCb, showLoading);
    }

    /**
     * 请求 Vip 配置数据
     * @param sucCb
     * @param errCb
     */
    static getVipLevelAwardList(sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.vip.getConfig, null, 'VipSysRewardInfoReq', 'VipSysRewardInfoResp', sucCb, errCb, false);
    }

    /**
     * 请求 Vip 奖励领取状态
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getVipAwardStatus(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.vip.getAwardStatus, null, 'VipSysRewardStatusReq', 'VipSysRewardStatusResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取 Vip 相关奖励
     * @param data
     * @param sucCb
     * @param errCb
     */
    static getVipSysAward(data: ApiProto.ReceiveVipSysRewardReq, sucCb?: Function, errCb?: Function) {
        this.doHttpRequestProto(Api.vip.getAward, data, 'ReceiveVipSysRewardReq', 'ReceiveVipSysRewardResp', sucCb, errCb, true);
    }

    /**
     * 邮件->获取邮件列表
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getMailList(data: ApiProto.GetMailListReq, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        this.doHttpRequestProto(Api.mail.list, data, 'GetMailListReq', 'GetMailListResp', sucCb, errCb, showLoading);
    }

    /**
     * 邮件 读取邮件内容
     * @param mailId
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static readMail(mailId: string, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        let data = {} as ApiProto.ReadMailReq;
        data.mailId = mailId;
        this.doHttpRequestProto(Api.mail.read, data, 'ReadMailReq', 'ReadMailResp', sucCb, errCb, showLoading);
    }

    /**
     * 邮件 领取奖励
     * @param mailIds 不传时，读所有有奖并领取邮件奖励
     * @param sucCb
     * @param errCb
     */
    static getMailAward(mailIds?: string[], sucCb?: Function, errCb?: Function) {
        let data = {} as ApiProto.ReadAllMailReq;
        data.mailId = mailIds || [];
        this.doHttpRequestProto(Api.mail.readAll, data, 'ReadAllMailReq', 'ReadAllMailResp', sucCb, errCb, true);
    }

    /**
     * 邮件 删除已读邮件
     * @param mailIds 不传时，读所有有奖并领取邮件奖励
     * @param sucCb
     * @param errCb
     */
    static deleteMails(mailIds?: string[], sucCb?: Function, errCb?: Function) {
        let data = {} as ApiProto.DeleteAllMailReq;
        data.mailId = mailIds || [];
        this.doHttpRequestProto(Api.mail.deleteAll, data, 'DeleteAllMailReq', 'DeleteAllMailResp', sucCb, errCb, true);
    }

    /**
     * 发起提现
     * @param data
     * @param sucCb
     * @param errCb
     */
    static sendWithdrawReq(data: ApiProto.UserBankWithdrawReq, sucCb?: Function, errCb?: Function): void {
        this.doHttpRequestProto(Api.withdraw.sendWithdraw, data, 'UserBankWithdrawReq', 'UserBankWithdrawResp', sucCb, errCb, true);
    }

    /**
     * 提现记录
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     * @returns
     */
    static getBankWithdrawRecord(data: ApiProto.BankWithdrawRecordReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.withdraw.withdrawRecord, data, 'BankWithdrawRecordReq', 'BankWithdrawRecordResp', sucCb, errCb, showLoading);
    }

    /**
     * new 修改提现卡号绑定 v4.1
     * @data data 修改数据
     * @param sucCb
     * @param errCb
     * @param showLoading 默认：true 显示loading
     */
    static modifyWithdrawBindInfo(data: ApiProto.UserBankWithdrawUpdateReq, sucCb: Function, errCb?: Function) {
        this.doHttpRequestProto(Api.withdraw.modifyBindInfo, data, 'UserBankWithdrawUpdateReq', 'UserBankWithdrawUpdateResp', sucCb, errCb, true);
    }

    /**
     * 提现配置，基础配置/提现绑定账号信息等
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getBankWithdrawConf(sucCb: (data: ApiProto.WithdrawInfoQueryResp) => void, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.withdraw.config, null, 'WithdrawInfoQueryReq', 'WithdrawInfoQueryResp', sucCb, errCb, showLoading);
    }

    /**
     * 提现通道
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getWithdrawChannel(sucCb?: (data: ApiProto.ConfWithDrawTypeResp) => void, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.withdraw.channel, null, 'ConfWithDrawTypeReq', 'ConfWithDrawTypeResp', sucCb, errCb, showLoading);
    }

    /**
     * 提现播报最新20条
     * @param sucCb
     * @param errCb
     */
    static getWithdrawBroad(sucCb: Function, errCb?: Function) {
        this.doHttpRequestProto(Api.withdraw.broad, null, 'BankWithdrawBroadReq', 'BankWithdrawBroadResp', sucCb, errCb, true);
    }

    /**
     * 获取打码量变更记录
     * @param page
     * @param pageSize
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getWithdrawScoreInfo(page: number, pageSize: number, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let data = {} as ApiProto.WithdrawScoreReq;
        data.page = page;
        data.pageSize = pageSize;
        this.doHttpRequestProto(Api.withdraw.withdrawScoreInfo, data, 'WithdrawScoreReq', 'WithdrawScoreResp', sucCb, errCb, showLoading);
    }

    /**
     * 提现 确认收款
     * @param data
     * @param sucCb
     * @param errCb
     */
    static vipWithdrawReceivedReq(data: ApiProto.VIPWithdrawReceivedReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.withdraw.received, data, 'VIPWithdrawReceivedReq', 'VIPWithdrawReceivedResp', sucCb, errCb, true);
    }

    /**
     * 提现 未收款
     * @param data
     * @param sucCb
     * @param errCb
     */
    static vipWithdrawNotReceivedReq(data: ApiProto.VIPWithdrawNotReceivedReq, sucCb: Function, errCb: Function) {
        this.doHttpRequestProto(Api.withdraw.notReceived, data, 'VIPWithdrawNotReceivedReq', 'VIPWithdrawNotReceivedResp', sucCb, errCb, true);
    }

    /**
     * 获取提现绑卡token
     * @param data
     * @param sucCb
     * @param errCb
     */
    static getWithdrawVerifyToken(data: ApiProto.GetPasswordVerificationTokenReq, sucCb: Function, errCb?: Function) {
        this.doHttpRequestProto(Api.withdraw.getVerifyToken, data, 'GetPasswordVerificationTokenReq', 'GetPasswordVerificationTokenResp', sucCb, errCb, true);
    }

    /**
     * 领取打码返利
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static ReceiveRebate(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.rebateCode.receiveRebate, null, 'UserRebateGetReq', 'UserRebateGetResp', sucCb, errCb, showLoading);
    }

    /**
     * 用户领取返利奖励记录
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static ReceiveRecode(data, sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.rebateCode.receiveRecord, data, 'UserRebateGetRecordReq', 'UserRebateGetRecordResp', sucCb, errCb, showLoading);
    }

    /**
     * 用户的返利记录
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static RebateRecord(data: ApiProto.UserRebateRecordReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.rebateCode.rebateRecord, data, 'UserRebateRecordReq', 'UserRebateRecordResp', sucCb, errCb, showLoading);
    }

    /**
     * 打码返利的配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static userRebateConfig(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.rebateCode.userRebateConfig, null, 'UserRebateConfReq', 'UserRebateConfNewResp', sucCb, errCb, showLoading);
    }

    /**
     * 用户返利信息的汇总
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static userRebateALLRecode(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.rebateCode.userRebateAllRecord, null, 'UserRebateInfoReq', 'UserRebateInfoNewResp', sucCb, errCb, showLoading);
    }

    /**
     * 所有游戏对应的返利比例配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static userRebateRatioConfig(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.rebateCode.userRebateRatioConfig, null, 'GameRebateRatioConfigReq', 'GameRebateRatioConfigResp', sucCb, errCb, showLoading);
    }

    /**
     * 绑定上级代理
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static bindUpAgent(data: ApiProto.BindAgentReq, sucCb: Function, errCb: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.bindUpAgent, data, 'BindAgentReq', 'BindAgentResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取代理奖励
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentAward(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.drawReward, null, 'AgentDrawRewardReq', 'AgentDrawRewardResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 活动配置说明接
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentRewardConfig(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.rewardConfig, null, 'AgentConfRebateRewardReq', 'AgentConfRebateRewardResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 邀请总览接口
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentInviteRewardInfo(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.inviteRewardInfo, null, 'AgentInviteRewardInfoReq', 'AgentInviteRewardInfoResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 获取每个层级的邀请详情
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentInviteRewardDetail(data: ApiProto.AgentInviteRewardDetailReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.inviteRewardDetails, data, 'AgentInviteRewardDetailReq', 'AgentInviteRewardDetailResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 邀请 人头奖励
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentInvitationRewards(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.invitationReward, null, 'AgentInvitationRewardsReq', 'AgentInvitationRewardsResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 邀请 人头奖励详情
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentInvitationRewardsDetail(data: ApiProto.AgentInvitationRewardsDetailReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.invitationRewardsDetail, data, 'AgentInvitationRewardsDetailReq', 'AgentInvitationRewardsDetailResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 邀请 打码奖励
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentBetAmountRewards(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.betAmountRewards, null, 'AgentBetAmountRewardsReq', 'AgentBetAmountRewardsResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 邀请 打码奖励详情
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentBetAmountRewardsDetail(data: ApiProto.AgentBetAmountRewardsDetailReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.betAmountRewardsDetail, data, 'AgentBetAmountRewardsDetailReq', 'AgentBetAmountRewardsDetailResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 邀请 充值奖励
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentRechargeRewards(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.rechargeRewards, null, 'AgentRechargeRewardsReq', 'AgentRechargeRewardsResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 邀请 充值奖励详情
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getAgentRechargeRewardsDetail(data: ApiProto.AgentRechargeRewardsDetailReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.rechargeRewardsDetail, data, 'AgentRechargeRewardsDetailReq', 'AgentRechargeRewardsDetailResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 有效邀请 人数奖励总览
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getValidAgentRewards(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.validAgentRewards, null, 'ValidAgentRewardsReq', 'ValidAgentRewardsResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 有效邀请 人数详情
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getValidAgentRewardsDetail(data: ApiProto.ValidAgentRewardsDetailReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.validAgentRewardsDetail, data, 'ValidAgentRewardsDetailReq', 'ValidAgentRewardsDetailResp', sucCb, errCb, showLoading);
    }

    /**
     * 代理 领取奖励记录
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getDrawRewardRecord(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.agent.drawRewardRecord, null, 'AgentDrawRewardRecordReq', 'AgentDrawRewardRecordResp', sucCb, errCb, showLoading);
    }

    /**
     * 用户今日和昨日是否可以申请救济金信息列表
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getUserApplyList(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.rescueFunds.userApplyList, null, 'ReliefFundApplyListReq', 'ReliefFundApplyListResp', sucCb, errCb, showLoading);
    }

    /**
     * 用户申请救济金
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static userApplyRescueFunds(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.rescueFunds.userApply, null, 'ReliefFundApplyReq', 'ReliefFundApplyResp', sucCb, errCb, showLoading);
    }

    /**
     * 救济金 申请记录
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getRescueFundsRecord(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.rescueFunds.userApplyRecord, null, 'ReliefFundApplyRecordReq', 'ReliefFundApplyRecordResp', sucCb, errCb, showLoading);
    }

    /**
     * 救援金活动分vip数值列表
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getRescueFundsVipConfig(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.rescueFunds.vipConfig, null, 'UserVipLevelConfReq', 'UserVipLevelConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 下载引导配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getDownloadGuideConf(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.downloadGuide.guideConfig, null, 'ForceLeadDownloadRewardReq', 'ForceLeadDownloadRewardResp', sucCb, errCb, showLoading);
    }

    /**
     * 下载引导获取用户信息
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getDownloadGuideInfo(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.downloadGuide.guideUserInfo, null, 'OfficialUserDetailReq', 'OfficialUserDetailResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取所有表情配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getFaceConfReq(sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.chat.faceConfig, null, 'GetGiItemReq', 'GetGiItemResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取子游戏表情配置
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getSubGameFaceConfReq(data: ApiProto.GetGameGiIdsReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false): void {
        this.doHttpRequestProto(Api.chat.gameFaceConf, data, 'GetGameGiIdsReq', 'GetGameGiIdsResp', sucCb, errCb, showLoading);
    }

    // ////////////////////////////////////////////// 子游戏正在使用大厅 api  ////////////////////////////////////////////////
    /**
     * 获取 jackpot 玩家排行榜
     * @param gameId
     * @param roomIndex
     * @param sucCb
     * @param errCb
     */
    static getJackpotRank(gameId: number, roomIndex: number, sucCb: Function, errCb: Function) {
        let req = {} as ApiProto.JackpotRankReq;
        req.gameId = gameId;
        req.roomIndex = roomIndex;
        this.doHttpRequestProto(Api.subGame.rank, req, 'JackpotRankReq', 'JackpotRankResp', sucCb, errCb, false);
    }

    /**
     * 获取游戏开奖结果统计
     * @param gameId
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getGameLotteryStatics(gameId: number, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let data = {} as ApiProto.GameLotteryStaticsReq;
        data.gameId = gameId;
        this.doHttpRequestProto(Api.subGame.gameLotteryStatics, data, 'GameLotteryStaticsReq', 'GameLotteryStaticsResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取用户在游戏盈亏统计
     * @param gameId
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getUserDrawLotteryStatics(gameId: number, sucCb: Function, errCb: Function, showLoading: boolean = true) {
        let data = {} as ApiProto.UserDrawLotteryStaticsReq;
        data.gameId = gameId;
        this.doHttpRequestProto(Api.subGame.userDrawLotteryStatics, data, 'UserDrawLotteryStaticsReq', 'UserDrawLotteryStaticsResp', sucCb, errCb, showLoading);
    }

    /**
     * 活动重构后 转盘活动数据
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getRodaUndianActivityInfo(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.rodaUndianActivityInfo, null, 'RodaActivityInfoReq', 'RodaActivityInfoResp', sucCb, errCb, showLoading);
    }

    /**
     * 活动重构后 获取旋转转盘后的结果
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getRodaUndianAward(sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.rodaUndianAward, null, 'RodaActivityAwardReq', 'RodaActivityAwardResp', sucCb, errCb, showLoading);
    }

    /**
     * 活动重构后 分页获取转盘历史记录
     * @param params
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getRodaUndianUpPage(params: ApiProto.RodaActivityUpPageReq, sucCb: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.activity.rodaUndianUpPage, params, 'RodaActivityUpPageReq', 'RodaActivityUpPageResp', sucCb, errCb, showLoading);
    }

    /**
     * 银行配置
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getBankConf(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.bank.bankConf, null, 'BankConfReq', 'BankConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 银行个人帐户信息
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getBankInfo(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.bank.bankInfo, null, 'BankInfoReq', 'BankInfoResp', sucCb, errCb, showLoading);
    }

    /**
     * 银行存款
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static bankStockIn(data: ApiProto.BankStockInReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.bank.bankStockIn, data, 'BankStockInReq', 'BankStockInResp', sucCb, errCb, showLoading);
    }

    /**
     * 银行取款
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static bankStockOut(data: ApiProto.BankStockOutReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.bank.bankStockOut, data, 'BankStockOutReq', 'BankStockOutResp', sucCb, errCb, showLoading);
    }

    /**
     * 银行流水记录
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getBankRecord(data: ApiProto.BankRecordReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.bank.bankRecord, data, 'BankRecordReq', 'BankRecordResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取会员交易记录
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getMemberTransactionRecord(data: ApiProto.CoinTransactionRecordReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.member.transactionRecord, data, 'CoinTransactionRecordReq', 'CoinTransactionRecordResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取会员交易记录类型
     * @param data
     * @param sucCb
     * @param errCb
     * @param showLoading
     */
    static getMemberTransactionEnum(data: ApiProto.CoinEnumConfigReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.member.transactionEnum, data, 'CoinEnumConfigReq', 'CoinEnumConfigResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取签到活动配置，按天领取
     */
    static getMonthSignInfo(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign.info, null, 'SignInConfReq', 'SignInConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取每日签到奖励，按天领取
     * @param data
     */
    static getMonthSignDailyReward(data: ApiProto.SignInReceiveDailyRewardReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign.getDailyReward, data, 'SignInReceiveDailyRewardReq', 'SignInReceiveDailyRewardResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取累计签到奖励，按天领取
     * @param data
     */
    static getMonthSignAccumulateReward(data: ApiProto.SignInReceiveCumulativeRewardReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign.getAccumulateReward, data, 'SignInReceiveCumulativeRewardReq', 'SignInMonthlyCumulativeRewardResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取补签奖励，按天领取
     * @param data
     */
    static getMonthSignReSignReward(data: ApiProto.SignInReCheckReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign.getReSignReward, data, 'SignInReCheckReq', 'SignInReCheckResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取签到活动配置，按次数领取
     */
    static getMonthSign2Info(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign2.info, null, 'SignInConfReq', 'NewSignInConfResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取每日签到奖励，按次数领取
     * @param data
     */
    static getMonthSign2DailyReward(data: ApiProto.SignInReceiveDailyRewardReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign2.getDailyReward, data, 'SignInReceiveDailyRewardReq', 'SignInReceiveDailyRewardResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取累计签到奖励，按次数领取
     * @param data
     */
    static getMonthSign2AccumulateReward(data: ApiProto.SignInReceiveCumulativeRewardReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign2.getAccumulateReward, data, 'SignInReceiveCumulativeRewardReq', 'SignInMonthlyCumulativeRewardResp', sucCb, errCb, showLoading);
    }

    /**
     * 获取补签奖励，按次数领取
     * @param data
     */
    static getMonthSign2ReSignReward(data: ApiProto.SignInReCheckReq, sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.MonthSign2.getReSignReward, data, 'SignInReCheckReq', 'SignInReCheckResp', sucCb, errCb, showLoading);
    }

    /**
     * 七日福利 - 请求活动信息
     * @param showLoading
     * @returns
     */
    static getNewBieSevenDayActivityInfo(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.SevenDay.info, <ApiProto.NewBieSevenDayActivityInfoReq>{}, 'NewBieSevenDayActivityInfoReq', 'NewBieSevenDayActivityInfoResp', sucCb, errCb, showLoading);
    }

    /**
     * 七日福利 - 请求登陆奖励
     * @param showLoading
     * @returns
     */
    static getNewBieSevenDayGetDailyAward(sucCb?: Function, errCb?: Function, showLoading: boolean = false) {
        this.doHttpRequestProto(Api.SevenDay.sign, <ApiProto.NewBieSevenDayGetDailyAwardReq>{}, 'NewBieSevenDayGetDailyAwardReq', 'NewBieSevenDayGetDailyAwardResp', sucCb, errCb, showLoading);
    }
}

we.common.apiMgr = ApiManager;
