export default class Api {
    static launcher = {
        /** 功能开关和基础配置 */
        uiConfig: '/api/conf/settings_conf',
    };

    static lobby = {
        /** 获取进入房间限制 */
        gameEnterLimit: '/api/game/game_enter_limit',
        /** 大厅入口 Jackpot */
        getJackpot: '/api/game/get_jack_pot',
        /** 在线人数 */
        onlineNumber: '/api/game/get_player_count',

        /** 未完成的游戏查询 */
        getOngoingGame: '/api/game/get_ongoing_game',
        /** 自研 游戏房间配置 */
        getRoomConfig: '/api/game/get_room_info',
        /** Api 游戏房间配置 */
        getApiRoomConfig: '/api/game-center/v1/get_room_conf',
        /** 退出 Api 游戏 */
        exitApiGame: '/api/game-center/v1/room_exit',

        /** 大厅周边静态配置 */
        static: '/api/de/v1/conf/lobby-static',
        /** 大厅周边动态变更数据 */
        dynamic: '/api/de/v1/conf/lobby-dynamic',
    };

    /** 账号相关 */
    static account = {
        /** 设备对应账户状态 */
        deviceAccountSt: '/api/user/device_account_status',
        /** 校获取短信验证码（新） */
        getNewPhoneCode: '/api/user/verify_code',
        /** 校验验证码 */
        checkVerifyCode: '/api/phone/verify_code',

        /** 游客登录 */
        guestLogin: '/api/user/anonymous_login',
        /** Token登录 */
        tokenLogin: '/api/user/token_login',
        /** 获取临时登录 token */
        getTempToken: '/api/user/get_new_temporary_token',
        /** 查询自己详细信息 */
        getUserInfo: '/api/user/get_user_info',
        /** 上报语言 */
        accountLangBind: '/api/user/account_lang_bind',
        /** 设置玩家国家数据 */
        accountCountryBind: '/api/user/account_country_bind',
        /** 登录界面facebook登录 */
        facebookLogin: '/api/user/fb_login',
        /** 游戏内点击facebook绑定 */
        facebookBind: '/api/user/fb_bind',
        /** 登陆界面apple登录 */
        appleLogin: '/api/user/apple_login',
        /** 游戏内apple绑定登录 */
        appleBind: '/api/user/apple_bind',
        /** 登陆界面google登录 */
        googleLogin: '/api/user/google_login',
        /** 游戏内google绑定登录 */
        googleBind: '/api/user/google_bind',
        /** 登陆界面账号注册 */
        phoneRegister: '/api/user/phone_register',
        /** 登陆界面账号登录 */
        phoneLogin: '/api/user/phone_login',
        /** userId登陆 */
        userIdLogin: '/api/user/id_login',
        /** 游戏内绑定账号 */
        phoneBind: '/api/user/phone_bind',
        /** 重置密码 */
        resetPassword: '/api/user/reset_password',
        /** 设备绑定fb状态 */
        fbExists: '/api/user/fb_exists',
        /** 邮箱登录 */
        emailLogin: '/api/de/v1/user/email_login',
        /** 邮箱注册账号 */
        emailRegister: '/api/de/v1/user/email_register',
        /** 邮箱绑定 */
        emailBind: '/api/de/v1/user/email_bind',
        /** 获取邮箱验证码 */
        getEmailCode: '/api/de/v1/user/verify_email_code',
        /** 校验邮箱验证码 */
        verifyEmailCode: '/api/de/v1/mail/verify_email_code',
        /** 邮箱修改密码 */
        resetPasswordEmail: '/api/de/v1/user/reset_password_email',
    };

    /** 用户 */
    static user = {
        /** 修改玩家信息 */
        changeUserInfo: '/api/user/modify_user_info',
        /** 历史头像 */
        getAvatarHistory: '/api/user/avatar_history',
        /** 刷新玩家余额 */
        getUserCredit: '/api/user/get_user_credit',
        /** 获取vip信息 */
        getVipInfo: '/api/user/get_user_vip_info',
        /** 查询其他人信息 */
        query_profile: '/api/user/query_profile',
        /** 收集玩家数据上报服务器 */
        updateExtraInfo: '/api/user/update_extra_info',
        /** 获取用户实名信息 */
        getUserContact: '/api/de/v1/user/contact/get',
        /** 添加用户实名信息 */
        addUserContact: '/api/de/v1/user/contact',
        /** 更新用户实名信息 */
        updateUserContact: '/api/de/v1/user/contact/update',
        /** 上报完成通知 */
        clientReportAdjustCallback: '/api/de/v1/user/client_report_adjust_callback',
    };

    /** 充值活动 */
    static recharge = {
        /** 商品配置 */
        shopConf: '/api/conf/shop_conf',
        /** 支付验证信息 */
        payAuthInfo: '/api/pay/recharge/auth',
        /** 充值订单 */
        getOrderList: '/api/pay/order/list',
        /** 支付前检查 */
        checkOrder: '/api/pay/check_order',

        /** 新手礼包配置 */
        newbieGiftConf: '/api/conf/first_recharge_conf',
        /** 创建订单 */
        queryOrder: '/api/pay/recharge/query_order',
        /** 查询支付渠道 */
        payType: '/api/conf/pay_type',
        /** 捕鱼 商品配置 */
        payTypeByPs: '/api/conf/pay_type_by_products',
        /** VIP充值配置 */
        vipRechargeConfig: '/api/de-pay/exchanges/vip/recharge/config',
        /** 发起VIP充值 */
        vipRechargeCreate: '/api/de-pay/exchanges/vip/recharge/create',
        /** 确认VIP充值订单 */
        vipRechargeAffirm: '/api/de-pay/exchanges/vip/recharge/affirm',
        /** 取消VIP充值订单 */
        vipRechargeCancel: '/api/de-pay/exchanges/vip/recharge/cancel',
    };

    /** 活动 */
    static activity = {
        /** 事件中心活动配置 */
        activityConf: '/api/conf/activity_conf',
        /** 大厅 banner 配置 */
        bannerConf: '/api/conf/game_banner',
        /** 绑定奖励配置 */
        bindAwardConf: '/api/conf/activity_banner',
        /** 礼包码 */
        giftReceive: '/api/activity/gift_receive',

        /** 跨天数据查询 */
        crossDay: '/api/conf/collection/cross_day',
        /** 获取首次使用指定app奖励配置 */
        officialAppAward: '/api/user/get_bonus_conf',
        /** 领取首次使用指定app奖励 */
        getOfficialAppAward: '/api/user/receive_bonus',

        /** 每日签到奖励配置查询 */
        dailyFreeAwardConf: '/api/user/daily_free_award/conf',
        /** 获取每日签到奖励 */
        getDailyFreeAward: '/api/user/daily_free_award/get',
        /** 周卡奖励 */
        weekCardAward: '/api/user/week_card_award',
        /** 周卡信息查询 */
        weekCardAwardsInfo: '/api/user/week_card_awards_info',

        /** 活动重构后 每日累充任务 */
        dailyRechargeInfo: '/api/de/v1/user/activity/recharge_activity_info',
        /** 活动重构后 领取任务奖励接口 */
        drawActivityAward: '/api/de/v1/user/activity/draw_activity_award',
        /** 活动重构后 狂欢活动任务 */
        carnivalActivityInfo: '/api/de/v1/user/activity/carnival_activity_info',
        /** 活动重构后 狂欢活动任务 */
        independenceActivityInfo: '/api/de/v1/user/activity/independence_activity_info',
        /** 活动重构后 转盘活动 */
        rodaUndianActivityInfo: '/api/de/v1/user/activity/roda_undian_activity_info',
        /** 活动重构后 转动转盘 */
        rodaUndianAward: '/api/de/v1/user/activity/roda_undian_award',
        /** 活动重构后 历史记录翻页 */
        rodaUndianUpPage: '/api/de/v1/user/activity/roda_undian_up_page',
    };

    /** VIP */
    static vip = {
        /** vip配置 */
        getConfig: '/api/de/v1/conf/vip_sys_reward',
        /** 领取vip系统相关奖励 */
        getAward: '/api/de/v1/user/vip_sys_reward/receive',
        /** vip奖励状态查询 */
        getAwardStatus: '/api/de/v1/user/vip_sys_reward/status',
    };

    static mail = {
        /** 邮件列表数据 */
        list: '/api/mail/external/v1/get_mail_list',
        /** 读 邮件 */
        read: '/api/mail/external/v1/read_mail',
        /** 一键读&领取 */
        readAll: '/api/mail/external/v1/read_all',
        /** 一键删除 */
        deleteAll: '/api/mail/external/v1/delete_all',
    };

    /** 提现 */
    static withdraw = {
        /** 玩家提现记录 */
        withdrawRecord: '/api/user/bank_withdraw_record',
        /** 提现播报记录 */
        broad: '/api/user/bank_withdraw_broad',
        /** 打码量变更记录 */
        withdrawScoreInfo: '/api/user/withdraw_score_info',

        /** 基础配置 */
        config: '/api/de/v1/user/base_withdraw/query',
        /** 支持提现渠道 */
        channel: '/api/de/v1/user/withdraw-type',
        /** 修改/新增 提现账号信息 */
        modifyBindInfo: '/api/de/v1/user/bank_withdraw/update',
        /** 发起提现 */
        sendWithdraw: '/api/de/v1/user/bank_withdraw/withdraw',
        /** 确认收款 */
        received: 'api/de-pay/exchanges/vip/withdraw/receive',
        /** 未收款 */
        notReceived: 'api/de-pay/exchanges/vip/withdraw/not-receive',
        /** 获取绑卡token */
        getVerifyToken: '/api/de/v1/password/verification-token/get',
    };

    /** 打码返利 */
    static rebateCode = {
        /** 领取用户返利奖励 */
        receiveRebate: '/api/game/user_rebate_get',
        /** 用户领取返利奖励记录 */
        receiveRecord: '/api/game/user_rebate_get_record',
        /** 用户返利记录 */
        rebateRecord: '/api/game/user_rebate_record',

        /** 打码返利的配置 */
        userRebateConfig: '/api/conf/user_rebate_conf_new',
        /** 用户返利信息汇总 */
        userRebateAllRecord: '/api/game/user_rebate_info_new',
        /** 获取所有游戏对应的返利比例配置 */
        userRebateRatioConfig: '/api/game/rebate_ratio_config',
    };

    /** 代理系统 */
    static agent = {
        /** 绑定上级代理 */
        bindUpAgent: '/api/user/bind_agent',

        /** 活动配置说明接口 */
        rewardConfig: '/api/game/agent_promotion_reward_config',
        /** 邀请总览接口 */
        inviteRewardInfo: '/api/game/invite_reward_info',
        /** 奖励领取接口 */
        drawReward: '/api/game/draw_reward',
        /** 获取每个层级的邀请详情 */
        inviteRewardDetails: '/api/game/invite_reward_detail',
        /** 邀请 人头奖励 */
        invitationReward: '/api/game/invitation_rewards',
        /** 邀请 人头奖励详情 */
        invitationRewardsDetail: '/api/game/invitation_rewards_detail',
        /** 邀请 打码奖励 */
        betAmountRewards: '/api/game/bet_amount_rewards',
        /** 邀请 打码奖励详情 */
        betAmountRewardsDetail: '/api/game/bet_amount_rewards_detail',
        /** 邀请 充值奖励 充值奖励的实现和打码奖励一样 */
        rechargeRewards: '/api/game/recharge_rewards',
        /** 邀请 充值奖励详情 */
        rechargeRewardsDetail: '/api/game/recharge_rewards_detail',
        /** 有效邀请 人数奖励总览  */
        validAgentRewards: '/api/game/valid_agent_rewards',
        /** 有效邀请 人数详情 */
        validAgentRewardsDetail: '/api/game/valid_agent_rewards_detail',
        /** 领取奖励记录 */
        drawRewardRecord: '/api/game/draw_reward_record',
    };

    /** 救援金 */
    static rescueFunds = {
        /** 用户今日和昨日是否可以申请救济金信息列表 */
        userApplyList: '/api/game/user_relief_fund_apply_list',
        /** 用户申请救济金 */
        userApply: '/api/game/user_relief_fund_apply',
        /** 用户申请救济金历史 */
        userApplyRecord: '/api/game/user_relief_fund_apply_record',
        /** 救援金活动分vip数值列表 */
        vipConfig: '/api/game/vip_relief_fund_apply_config',
    };

    /** 下载引导 */
    static downloadGuide = {
        /** 下载引导配置信息 */
        guideConfig: '/api/user/force_download_lead_reward_conf',
        /** 下载引导正式用户信息 */
        guideUserInfo: '/api/user/force_download_lead_user_info',
    };

    /** 聊天 */
    static chat = {
        /** 表情配置 */
        faceConfig: '/api/chat/get_gi_item',
        /** 子游戏拥有表情配置 */
        gameFaceConf: '/api/chat/get_game_gi_ids',
    };

    static subGame = {
        /** slot 子游戏排行榜记录 */
        rank: '/api/user/ranking/jackpot',
        /** 百人场 开奖记录 */
        gameLotteryStatics: '/api/game/game_lottery_statics',
        /** 百人场 玩家盈亏 */
        userDrawLotteryStatics: '/api/game/user_draw_lottery_statics',
    };

    /** 银行 */
    static bank = {
        /** 银行配置 */
        bankConf: '/api/de/v1/bank/conf',
        /** 银行个人帐户信息 */
        bankInfo: '/api/de/v1/bank/info',
        /** 银行存款 */
        bankStockIn: '/api/de/v1/bank/stock_in',
        /** 银行取款 */
        bankStockOut: '/api/de/v1/bank/stock_out',
        /** 银行流水记录 */
        bankRecord: '/api/de/v1/bank/record',
    };

    /** 会员中心 */
    static member = {
        /** 流水记录 */
        transactionRecord: '/api/de/v1/member-center/transaction/record',
        /** 流水类型配置 */
        transactionEnum: '/api/de/v1/conf/coin-enum',
    };

    /** 周卡 */
    static weekCard = {
        /** 档位配置和已购买信息 */
        conf: '/api/de/v1/user/weekly_card/configurations',
        /** 领取周卡每日奖励 */
        getAward: 'api/de/v1/user/weekly_card/claim',
    };

    /** 签到活动，按天领取 **/
    static MonthSign = {
        /** 获取签到活动配置 */
        info: 'api/de/v1/sign-in/conf',
        /** 获取每日签到奖励 */
        getDailyReward: 'api/de/v1/sign-in/daily/receive',
        /** 获取累计签到奖励 */
        getAccumulateReward: 'api/de/v1/sign-in/cumulative/receive',
        /** 获取补签奖励 */
        getReSignReward: 'api/de/v1/sign-in/re-check/receive',
    };

    /** 签到活动，按次数领取 **/
    static MonthSign2 = {
        /** 获取签到活动配置 */
        info: 'api/de/v1/new_sign_in/conf',
        /** 获取每日签到奖励 */
        getDailyReward: 'api/de/v1/new_sign_in/daily/receive',
        /** 获取累计签到奖励 */
        getAccumulateReward: 'api/de/v1/new_sign_in/cumulative/receive',
        /** 获取补签奖励 */
        getReSignReward: 'api/de/v1/new_sign_in/re-check/receive',
    };

    /** 七日福利 */
    static SevenDay = {
        /** 请求活动信息 */
        info: 'api/de/v1/user/activity/newbie_seven_day_activity_info',
        /** 请求登陆奖励 */
        sign: 'api/de/v1/user/activity/newbie_seven_day_daily_award',
    };
}

/** 不需要 token 的 api 列表 */
export const ApiNoTokenList = [
    Api.account.deviceAccountSt,
    Api.account.phoneRegister,
    Api.account.emailRegister,
    Api.account.getNewPhoneCode,
    Api.account.checkVerifyCode,
    Api.account.getEmailCode,
    Api.account.verifyEmailCode,
    Api.account.resetPassword,
    Api.account.resetPasswordEmail,
    Api.account.guestLogin,
    Api.account.userIdLogin,
    Api.account.phoneLogin,
    Api.account.googleLogin,
    Api.account.appleLogin,
    Api.account.facebookLogin,
    Api.account.emailLogin,
];

/**
 * 主要针对登录后需要实时性高的数据的业务 api
 * 1.高实时性配置
 * 2.历史记录
 */
export const ApiRealtimeList = [
    Api.lobby.getRoomConfig,
    Api.user.getUserCredit,
    Api.recharge.shopConf,
    Api.recharge.queryOrder,
    Api.recharge.getOrderList,
    Api.recharge.payType,
    Api.recharge.newbieGiftConf,
    Api.recharge.vipRechargeConfig,
    Api.recharge.vipRechargeCreate,
    Api.withdraw.config,
    Api.withdraw.channel,
    Api.withdraw.withdrawRecord,
    Api.withdraw.withdrawScoreInfo,
    Api.bank.bankConf,
    Api.bank.bankInfo,
    Api.agent.bindUpAgent,
    Api.agent.drawRewardRecord,
    Api.agent.inviteRewardDetails,
    Api.activity.rodaUndianUpPage,
    Api.member.transactionRecord,
    Api.mail.list,
    Api.mail.read,
    Api.rescueFunds.userApplyRecord,
    Api.user.clientReportAdjustCallback,
];
