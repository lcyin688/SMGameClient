/**
 * 协议消息
 */
export enum NamingProtoMsg {
    // ----------------------------客户端请求--------------------------
    /** 推送回执请求, id: 7 */
    ReportReq = 7,
    /** 推送状态，id: 8 */
    ActionNTReq = 8,

    // --------------------------服务端应答------------------------------
    /** 错误信息，id: 100 */
    ErrorST = 100,
    /** IM 广播 id: 106 */
    BroadCastNT = 106,
    /** notice msg id: 109 */
    UserNoticeNT = 109,
    /** notice msg id: 109 */
    ReportResp = 110,
    /** alert推送 msg id: 111 */
    UserAlertNT = 111,
    /** 游戏入口 Jp 数据推送 msg id: 112 */
    JackpotNT = 112,
}
