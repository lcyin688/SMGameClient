import Api from '../api/Api';
import ApiManager from '../api/ApiManager';
import UserManager from '../manager/UserManager';

declare global {
    interface ICommon {
        BundlePreloadTask: typeof BundlePreloadTask;
    }

    namespace we {
        namespace common {
            type BundlePreloadTask = InstanceType<typeof BundlePreloadTask>;
        }
    }
}

type ConfigContext = { bundles: string[] };

/**
 * 资源预加载任务管线组件
 */
@we.decorator.typeRegister('BundlePreloadTask', we.bundles.common)
export class BundlePreloadTask extends we.core.Entity {
    /**
     * 公共包加载管线
     */
    pipeline: we.core.TaskPipeline<ConfigContext>;

    protected async awakeAsync(bundles: string[]): Promise<void> {
        this.pipeline = new we.core.TaskPipeline({ mode: we.core.pipeline.PipelineMode.Task });
        this.pipeline.setCtx({ bundles });
        this.pipeline.addTask(we.core.FuncAsync.create(this.fetchBundleVersion, this), { retry: 1, retryInterval: 2, mode: we.core.pipeline.TaskMode.Abort });
        this.pipeline.addTask(we.core.FuncAsync.create(this.loadBundleConfig, this), { retry: 1, retryInterval: 2, mode: we.core.pipeline.TaskMode.Continue });
        this.pipeline.on('abort', (event) => {
            this.dispose();
            we.warn(`BundlePreloadTask awakeAsync, pipeline aborted: ${JSON.stringify(event.err?.message || event.err)}`, we.noup);
        });

        await this.pipeline.start().finally(() => {
            this.dispose();
        });
    }

    protected destroy(): void {
        this.pipeline?.abort();
    }

    /**
     * 获取bundle包版本配置信息
     * @param ctx 管线上下文
     * @param signal 中断 signal
     * @returns
     */
    private async fetchBundleVersion(ctx: ConfigContext, signal: AbortSignal): Promise<void> {
        if (signal.aborted) {
            return;
        }

        const bundles = ctx.bundles.filter((bundle) => {
            const remoteVersion = we.core.gameConfig.getRemoteVersion(bundle);
            const localVersion = we.core.gameConfig.getLocalVersion(bundle);
            return !localVersion || localVersion === we.core.type.VersionDefault || remoteVersion !== localVersion;
        });

        if (bundles.length === 0) {
            return;
        }

        await new Promise((resolve, reject) => {
            let req = {} as ApiProto.RoomInfoReq;
            req.gameId = we.GameId.MAHJONG;
            req.userId = UserManager.userInfo.userId;
            req.bundles = bundles;

            ApiManager.doHttpRequestProto(
                Api.lobby.getRoomConfig,
                req,
                'RoomInfoReq',
                'RoomInfoResp',
                (resp: ApiProto.RoomInfoResp) => {
                    // 更新公共包版本信息
                    ctx.bundles = Object.keys(resp.bundleInfo);
                    we.core.gameConfig.updateBundleInfo(resp.bundleInfo);
                    resolve(null);
                },
                (code) => {
                    reject(code);
                }
            );
        });
    }

    /**
     * 加载bundle配置
     * @param ctx 管线上下文
     * @param signal 中断 signal
     * @returns
     */
    private async loadBundleConfig(ctx: ConfigContext, signal: AbortSignal): Promise<void> {
        for (const bundle of ctx.bundles) {
            if (signal.aborted) {
                return;
            }
            await we.core.assetMgr.loadCommonBundle(bundle).catch(() => {
                // 忽略预加载失败的资源
            });
            we.log(`BundlePreloadTask loadBundleConfig, load bundle ${bundle} success`);
        }
    }
}

we.common.BundlePreloadTask = BundlePreloadTask;
