import { EventMsg } from '../config/CommonEvent';
import { CommonType } from '../config/CommonType';

declare global {
    interface ICommon {
        GameEventTask: typeof GameEventTask;
    }

    namespace we {
        namespace common {
            type GameEventTask = InstanceType<typeof GameEventTask>;
        }
    }
}

/**
 * 资源预加载任务管线组件
 */
@we.decorator.typeRegister('GameEventTask', we.bundles.common)
export class GameEventTask extends we.core.Entity {
    /**
     * 公共包加载管线
     */
    private pipeline: we.core.TaskPipeline;

    /**
     * 任务执行器
     */
    private taskExecutor: Map<CommonType.GameEvent, new (...args) => we.core.pipeline.IExecutor>;

    protected awake() {
        this.taskExecutor = new Map<CommonType.GameEvent, new (...args) => we.core.pipeline.IExecutor>();
        this.pipeline = new we.core.TaskPipeline({ mode: we.core.pipeline.PipelineMode.Continue });
        we.clientEvent<EventMsg>().on('GameEvent', this.onGameEvent, this);
    }

    protected destroy(): void {
        we.clientEvent<EventMsg>().off('GameEvent', this.onGameEvent, this);
        this.pipeline?.abort();
    }

    public registerExecutor(event: CommonType.GameEvent, executor: new (...args) => we.core.pipeline.IExecutor) {
        this.taskExecutor.set(event, executor);
    }

    /**
     * 大厅在合适时机启动任务
     */
    public async startTask() {
        await this.pipeline.start().finally(() => {
            this.pipeline.reset();
        });
    }

    /**
     * 离开大厅时，中断任务
     */
    public async brokenTask() {
        await this.pipeline?.stop();
    }

    private onGameEvent(event: CommonType.GameEvent) {
        const executor = this.taskExecutor.get(event);
        if (!executor) {
            we.warn(`GameEventTask onGameEvent, no executor found: ${event}`);
            return;
        }

        switch (event) {
            case CommonType.GameEvent.Recharge:
                this.pipeline.addTask(new executor(this.pipeline));
                break;
            default:
                break;
        }
    }
}

we.common.GameEventTask = GameEventTask;
