/**
 * mobx 监听字段定义
 */
export class CommonMobx {}
