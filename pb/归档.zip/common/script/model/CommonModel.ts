import { CommonMobx } from './mobx/CommonMobx';

declare global {
    interface ICommon {
        CommonModel: typeof CommonModel;
    }

    namespace we {
        namespace common {
            type CommonModel = InstanceType<typeof CommonModel>;
        }
    }
}

export interface GameListItem {
    /** 游戏厂商 */
    gameVendor?: we.GameVendor;
    /** 游戏id */
    gameId: we.GameId;
    /** bundle 名称 */
    bundleName: string;
    /** 依赖 bundle */
    dependBundles: string[];
    /** TODO 待删除 场景名称 */
    sceneName?: string;
    /** 游戏分类 */
    gameType: we.GameType;
    /** 屏幕方向,默认横屏 */
    orientation?: ScreenOrientation;
}

/**
 * 无需mobx监听触发更新的数据定义
 */
@we.decorator.typeRegister('CommonModel', we.bundles.common)
export class CommonModel extends we.core.Entity {
    static Inst: CommonModel;
    public store: CommonMobx;

    /**
     * 游戏厂商配置
     * - key ：游戏厂商 id
     * - value ：游戏厂商配置
     */
    private vendorConfig: Record<we.GameVendor, ApiProto.VendorDetail>;

    /**
     * 游戏列表配置
     */
    gameList: GameListItem[];

    protected awake(): void {
        CommonModel.Inst = this;
        this.store = new CommonMobx();
        we.mobx.makeAutoObservable(this.store);
    }

    protected destroy(): void {
        CommonModel.Inst = null;
    }

    /**
     * 设置厂商配置
     * @param data 游戏厂商配置
     */
    setVendorConfig(data: { [k: string]: ApiProto.VendorDetail }) {
        this.vendorConfig = data;
        // TODO api 测试打开点2 厂商配置后端未返回时，需打开
        // this.vendorConfig[1] = {
        //     customized: true,
        //     vendorId: 1,
        //     vendorRatio: 1,
        // };
    }

    /**
     * 获取厂商配置
     * @param vendorId 厂商Id
     * @returns
     */
    getVendorConfig(vendorId: we.GameVendor): ApiProto.VendorDetail | null {
        return this.vendorConfig[vendorId];
    }
}

we.common.CommonModel = CommonModel;
